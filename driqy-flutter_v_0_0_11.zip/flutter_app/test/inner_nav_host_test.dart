import 'package:driqy_flutter/widgets/inner_nav_host.dart';
import 'package:driqy_flutter/widgets/wide_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Route<void> _stacked(String label) => MaterialPageRoute<void>(
      builder: (_) => Scaffold(
        body: SizedBox.expand(key: Key('stacked-$label'), child: Center(child: Text('STACKED $label'))),
      ),
    );

/// Menu (200 dp, fora do miolo) + miolo com Navigator interno, como a HomeShell em tela larga.
Widget _app(GlobalKey<NavigatorState> navKey,
    {bool fullWidth = false, bool withShellNav = true, ValueChanged<int>? onDepth}) {
  final menu = Builder(
    builder: (context) => TextButton(
      key: const Key('menu-push'),
      onPressed: () => shellNavigatorOf(context).push(_stacked('A')),
      child: const Text('MENU'),
    ),
  );
  final row = Row(
    children: [
      SizedBox(width: 200, child: menu),
      Expanded(
        child: InnerNavHost(
          navigatorKey: navKey,
          homeFullWidth: fullWidth,
          onDepthChanged: onDepth,
          homeBuilder: (_) => Builder(
            builder: (context) => SizedBox.expand(
              key: const Key('home-box'),
              child: Center(
                child: TextButton(
                  key: const Key('inner-push'),
                  onPressed: () => Navigator.of(context).push(_stacked('A')),
                  child: const Text('HOME'),
                ),
              ),
            ),
          ),
        ),
      ),
    ],
  );
  return MaterialApp(
    home: Scaffold(body: withShellNav ? ShellNav(navigatorKey: navKey, child: row) : row),
  );
}

void _wideWindow(WidgetTester tester) {
  tester.view.physicalSize = const Size(1400, 900);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.reset);
}

void main() {
  testWidgets('push de dentro do miolo fica no Navigator interno: o menu continua na tela', (tester) async {
    _wideWindow(tester);
    final key = GlobalKey<NavigatorState>();
    await tester.pumpWidget(_app(key));

    await tester.tap(find.byKey(const Key('inner-push')));
    await tester.pumpAndSettle();

    expect(find.text('STACKED A'), findsOneWidget);
    expect(find.text('MENU'), findsOneWidget);
    expect(key.currentState!.canPop(), isTrue);
    // o Navigator raiz continua só com a tela inicial
    expect(Navigator.of(tester.element(find.text('MENU'))).canPop(), isFalse);
  });

  testWidgets('shellNavigatorOf a partir do menu (fora do miolo) empilha no interno', (tester) async {
    _wideWindow(tester);
    final key = GlobalKey<NavigatorState>();
    await tester.pumpWidget(_app(key));

    await tester.tap(find.byKey(const Key('menu-push')));
    await tester.pumpAndSettle();

    expect(find.text('STACKED A'), findsOneWidget);
    expect(find.text('MENU'), findsOneWidget);
    expect(key.currentState!.canPop(), isTrue);
    expect(Navigator.of(tester.element(find.text('MENU'))).canPop(), isFalse);
  });

  testWidgets('sem ShellNav, shellNavigatorOf cai no Navigator raiz (cobre o menu)', (tester) async {
    _wideWindow(tester);
    final key = GlobalKey<NavigatorState>();
    await tester.pumpWidget(_app(key, withShellNav: false));

    await tester.tap(find.byKey(const Key('menu-push')));
    await tester.pumpAndSettle();

    expect(find.text('STACKED A'), findsOneWidget);
    expect(find.text('MENU'), findsNothing); // coberto pela rota raiz
    expect(key.currentState!.canPop(), isFalse);
  });

  testWidgets('botão voltar do sistema fecha a tela empilhada no miolo', (tester) async {
    _wideWindow(tester);
    final key = GlobalKey<NavigatorState>();
    await tester.pumpWidget(_app(key));
    await tester.tap(find.byKey(const Key('inner-push')));
    await tester.pumpAndSettle();
    expect(find.text('STACKED A'), findsOneWidget);

    await tester.binding.handlePopRoute();
    await tester.pumpAndSettle();

    expect(find.text('STACKED A'), findsNothing);
    expect(find.text('HOME'), findsOneWidget);
    expect(find.text('MENU'), findsOneWidget);
    expect(key.currentState!.canPop(), isFalse);
  });

  testWidgets('largura: 620 no miolo; a tela inicial usa tudo só com homeFullWidth e nada empilhado', (tester) async {
    _wideWindow(tester);
    final key = GlobalKey<NavigatorState>();

    // sem homeFullWidth: sempre a coluna de 620
    await tester.pumpWidget(_app(key));
    expect(tester.getSize(find.byKey(const Key('home-box'))).width, kContentMaxWidth);

    // com homeFullWidth: 1400 - 200 do menu = 1200 enquanto nada está empilhado
    final key2 = GlobalKey<NavigatorState>();
    await tester.pumpWidget(_app(key2, fullWidth: true));
    await tester.pumpAndSettle();
    expect(tester.getSize(find.byKey(const Key('home-box'))).width, 1200);

    await tester.tap(find.byKey(const Key('inner-push')));
    await tester.pumpAndSettle();
    expect(tester.getSize(find.byKey(const Key('stacked-A'))).width, kContentMaxWidth);

    key2.currentState!.pop();
    await tester.pumpAndSettle();
    expect(tester.getSize(find.byKey(const Key('home-box'))).width, 1200);
  });

  testWidgets('popUntil(isFirst) e pushAndRemoveUntil mantêm a contagem (largura volta ao fim)', (tester) async {
    _wideWindow(tester);
    final key = GlobalKey<NavigatorState>();
    await tester.pumpWidget(_app(key, fullWidth: true));

    key.currentState!.push(_stacked('A'));
    await tester.pumpAndSettle();
    key.currentState!.push(_stacked('B'));
    await tester.pumpAndSettle();
    expect(tester.getSize(find.byKey(const Key('stacked-B'))).width, kContentMaxWidth);

    key.currentState!.popUntil((r) => r.isFirst);
    await tester.pumpAndSettle();
    expect(find.text('STACKED A'), findsNothing);
    expect(find.text('STACKED B'), findsNothing);
    expect(tester.getSize(find.byKey(const Key('home-box'))).width, 1200);

    // menu: substitui o que estava empilhado (2 telas viram 1)
    key.currentState!.push(_stacked('A'));
    await tester.pumpAndSettle();
    key.currentState!.push(_stacked('B'));
    await tester.pumpAndSettle();
    key.currentState!.pushAndRemoveUntil(_stacked('C'), (r) => r.isFirst);
    await tester.pumpAndSettle();
    expect(find.text('STACKED C'), findsOneWidget);
    expect(find.text('STACKED B'), findsNothing);

    key.currentState!.pop(); // uma só tela por cima da inicial
    await tester.pumpAndSettle();
    expect(find.text('HOME'), findsOneWidget);
    expect(tester.getSize(find.byKey(const Key('home-box'))).width, 1200);
  });

  testWidgets('onDepthChanged avisa 1 ao empilhar e 0 ao voltar (a HomeShell esconde o painel direito)', (tester) async {
    _wideWindow(tester);
    final key = GlobalKey<NavigatorState>();
    final seen = <int>[];
    await tester.pumpWidget(_app(key, onDepth: seen.add));

    await tester.tap(find.byKey(const Key('inner-push')));
    await tester.pumpAndSettle();
    expect(seen, [1]);

    key.currentState!.pop();
    await tester.pumpAndSettle();
    expect(seen, [1, 0]);
  });
}
