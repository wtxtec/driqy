import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_client.dart';
import 'package:driqy_flutter/services/widgets_service.dart';
import 'package:driqy_flutter/widgets/place_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _Service extends WidgetsService {
  _Service() : super(ApiClient());

  @override
  Future<List<PlaceSuggestion>> searchPlaces(String query) async => const [
        PlaceSuggestion(
          name: 'Gramado',
          admin1: 'Rio Grande do Sul',
          country: 'Brasil',
          label: 'Gramado, Rio Grande do Sul, Brasil',
          latitude: -29.37,
          longitude: -50.87,
        ),
      ];
}

void main() {
  testWidgets('digitar mostra sugestões; escolher preenche o campo e avisa', (tester) async {
    final controller = TextEditingController();
    PlaceSuggestion? picked;
    var typed = 0;
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: PlaceField(
          controller: controller,
          service: _Service(),
          onSelected: (p) => picked = p,
          onTyped: () => typed++,
        ),
      ),
    ));
    await tester.enterText(find.byType(TextField), 'gram');
    await tester.pump(const Duration(milliseconds: 400));
    await tester.pump();
    expect(typed, 1);
    expect(find.text('Rio Grande do Sul, Brasil'), findsOneWidget);
    await tester.tap(find.text('Gramado'));
    await tester.pump();
    expect(picked?.latitude, -29.37);
    expect(controller.text, 'Gramado, Rio Grande do Sul, Brasil');
  });
}
