import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_exception.dart';
import 'package:driqy_flutter/widgets/rail/rail_mine.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// Servidor de mentira: guarda o último `data` e devolve como o servidor real (já normalizado).
class _Server {
  CustomWidget w;
  final List<Map<String, dynamic>> saves = [];
  String? failWith;
  bool failLoad = false;

  _Server(this.w);

  Future<CustomWidget> load() async {
    if (failLoad) throw ApiException(500, 'x');
    return w;
  }

  Future<CustomWidget> save({String? title, Map<String, dynamic>? data}) async {
    if (failWith != null) throw ApiException(400, failWith!);
    if (data != null) {
      saves.add(data);
      w = w.copyWith(data: data);
    }
    if (title != null) w = w.copyWith(title: title);
    return w;
  }
}

CustomWidget _w(String kind, Map<String, dynamic> data) =>
    CustomWidget(id: 'custom:1', widgetId: 1, kind: kind, title: 'T', data: data);

Future<void> _pump(WidgetTester t, _Server s, {DateTime? now, ValueChanged<String>? onRenamed}) async {
  await t.pumpWidget(MaterialApp(
    home: Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: SizedBox(
            width: 320,
            child: RailMineWidget(
              key: UniqueKey(),
              kind: s.w.kind,
              load: s.load,
              save: s.save,
              now: now == null ? null : () => now,
              onRenamed: onRenamed,
            ),
          ),
        ),
      ),
    ),
  ));
  await t.pumpAndSettle();
}

void main() {
  test('daysUntil conta dias de calendário e recusa datas que não existem', () {
    final today = DateTime(2026, 11, 3, 23, 59);
    expect(daysUntil('2026-11-03', today), 0);
    expect(daysUntil('2026-11-13', today), 10);
    expect(daysUntil('2026-10-31', today), -3);
    expect(daysUntil('2026-02-31', today), isNull);
    expect(daysUntil('amanhã', today), isNull);
    expect(daysUntil('', today), isNull);
  });

  testWidgets('falha ao carregar mostra "Tentar de novo" e volta a buscar', (t) async {
    final s = _Server(_w('note', {'text': 'a'}))..failLoad = true;
    await _pump(t, s);
    expect(find.text('Não consegui carregar agora.'), findsOneWidget);
    s.failLoad = false;
    await t.tap(find.text('Tentar de novo'));
    await t.pumpAndSettle();
    expect(find.byKey(const Key('mine-note')), findsOneWidget);
  });

  testWidgets('nota: mostra o texto e salva sozinha depois de parar de digitar', (t) async {
    final s = _Server(_w('note', {'text': 'oi'}));
    await _pump(t, s);
    expect(find.text('oi'), findsOneWidget);
    await t.enterText(find.byKey(const Key('mine-note')), 'oi, mundo');
    await t.pump(const Duration(milliseconds: 300));
    expect(s.saves, isEmpty); // ainda digitando
    expect(find.text('Salvando…'), findsOneWidget);
    await t.pump(const Duration(milliseconds: 700));
    await t.pumpAndSettle();
    expect(s.saves, [
      {'text': 'oi, mundo'},
    ]);
    expect(find.text('Salvo'), findsOneWidget);
  });

  testWidgets('nota: o que não foi salvo ainda não se perde ao trocar de widget', (t) async {
    final s = _Server(_w('note', {'text': ''}));
    await _pump(t, s);
    await t.enterText(find.byKey(const Key('mine-note')), 'rascunho');
    await t.pumpWidget(const MaterialApp(home: Scaffold(body: SizedBox())));
    await t.pump();
    expect(s.saves, isNotEmpty);
    expect(s.saves.last, {'text': 'rascunho'});
  });

  testWidgets('tarefas: adicionar, marcar, contar e limpar feitas', (t) async {
    final s = _Server(_w('checklist', {'items': []}));
    await _pump(t, s);
    expect(find.text('Nada por aqui ainda.'), findsOneWidget);
    await t.enterText(find.byKey(const Key('mine-item-input')), 'leite');
    await t.tap(find.byKey(const Key('mine-item-add')));
    await t.pumpAndSettle();
    expect(s.saves.last['items'].length, 1);
    expect(s.saves.last['items'][0]['text'], 'leite');
    expect(s.saves.last['items'][0]['done'], isFalse);
    expect(find.text('leite'), findsOneWidget);
    expect(find.text('0/1'), findsOneWidget);

    final id = s.saves.last['items'][0]['id'] as String;
    await t.tap(find.byKey(Key('mine-check-$id')));
    await t.pumpAndSettle();
    expect(s.saves.last['items'][0]['done'], isTrue);
    expect(find.text('1/1'), findsOneWidget);

    await t.tap(find.byKey(const Key('mine-clear-done')));
    await t.pumpAndSettle();
    expect(s.saves.last['items'], isEmpty);
    expect(find.text('leite'), findsNothing);
  });

  testWidgets('tarefas: texto vazio não cria item e ✕ remove', (t) async {
    final s = _Server(_w('checklist', {
      'items': [
        {'id': 'a1', 'text': 'um', 'done': false},
        {'id': 'b2', 'text': 'dois', 'done': false},
      ],
    }));
    await _pump(t, s);
    await t.enterText(find.byKey(const Key('mine-item-input')), '   ');
    await t.tap(find.byKey(const Key('mine-item-add')));
    await t.pumpAndSettle();
    expect(s.saves, isEmpty);
    await t.tap(find.byKey(const Key('mine-del-a1')));
    await t.pumpAndSettle();
    expect(s.saves.last['items'].length, 1);
    expect(s.saves.last['items'][0]['id'], 'b2');
  });

  testWidgets('atalhos: adiciona e, se o servidor recusa, mostra o erro e não mantém o link', (t) async {
    final s = _Server(_w('links', {'links': []}));
    await _pump(t, s);
    await t.enterText(find.byKey(const Key('mine-link-title')), 'Meu site');
    await t.enterText(find.byKey(const Key('mine-link-url')), 'exemplo.com');
    await t.tap(find.byKey(const Key('mine-link-add')));
    await t.pumpAndSettle();
    expect(s.saves.last['links'], [
      {'title': 'Meu site', 'url': 'exemplo.com'},
    ]);
    expect(find.text('Meu site'), findsOneWidget);

    s.failWith = 'Link inválido.';
    await t.enterText(find.byKey(const Key('mine-link-url')), 'isso não é link');
    await t.tap(find.byKey(const Key('mine-link-add')));
    await t.pumpAndSettle();
    expect(find.byKey(const Key('mine-link-error')), findsOneWidget);
    expect(find.text('Link inválido.'), findsWidgets);
    expect(find.byKey(const Key('mine-link-1')), findsNothing); // não entrou na lista
  });

  testWidgets('atalhos: ✕ remove o atalho', (t) async {
    final s = _Server(_w('links', {
      'links': [
        {'title': 'A', 'url': 'https://a.com'},
        {'title': 'B', 'url': 'https://b.com'},
      ],
    }));
    await _pump(t, s);
    await t.tap(find.byKey(const Key('mine-link-del-0')));
    await t.pumpAndSettle();
    expect(s.saves.last['links'], [
      {'title': 'B', 'url': 'https://b.com'},
    ]);
    expect(find.text('A'), findsNothing);
  });

  testWidgets('contagem: dias que faltam, hoje e dias desde', (t) async {
    final now = DateTime(2026, 11, 3, 10);
    var s = _Server(_w('countdown', {'label': 'Viagem', 'date': '2026-11-13'}));
    await _pump(t, s, now: now);
    expect(find.text('10'), findsOneWidget);
    expect(find.text('dias para Viagem'), findsOneWidget);

    s = _Server(_w('countdown', {'label': '', 'date': '2026-11-03'}));
    await _pump(t, s, now: now);
    expect(find.text('Hoje'), findsOneWidget);

    s = _Server(_w('countdown', {'label': 'a festa', 'date': '2026-11-02'}));
    await _pump(t, s, now: now);
    expect(find.text('1'), findsOneWidget);
    expect(find.text('dia desde a festa'), findsOneWidget);

    s = _Server(_w('countdown', {'label': '', 'date': ''}));
    await _pump(t, s, now: now);
    expect(find.text('Escolha uma data.'), findsOneWidget);
  });

  testWidgets('contagem: rótulo salva ao confirmar e a data pode ser tirada', (t) async {
    final s = _Server(_w('countdown', {'label': '', 'date': '2026-11-13'}));
    await _pump(t, s, now: DateTime(2026, 11, 3));
    await t.enterText(find.byKey(const Key('mine-count-label')), 'Viagem');
    await t.testTextInput.receiveAction(TextInputAction.done);
    await t.pumpAndSettle();
    expect(s.saves.last, {'label': 'Viagem', 'date': '2026-11-13'});
    await t.tap(find.byKey(const Key('mine-clear-date')));
    await t.pumpAndSettle();
    expect(s.saves.last['date'], '');
    expect(find.text('Escolha uma data.'), findsOneWidget);
  });

  testWidgets('contador: soma e subtrai pelo passo, meta e zerar', (t) async {
    final s = _Server(_w('counter', {'value': 5, 'step': 2, 'goal': 10, 'unit': 'km'}));
    await _pump(t, s);
    expect(find.text('5'), findsOneWidget);
    expect(find.text('meta 10'), findsOneWidget);
    expect(find.text('km'), findsOneWidget);
    await t.tap(find.byKey(const Key('mine-inc')));
    await t.pumpAndSettle();
    expect(s.saves.last, {'value': 7, 'step': 2, 'goal': 10, 'unit': 'km'});
    expect(find.text('7'), findsOneWidget);
    await t.tap(find.byKey(const Key('mine-dec')));
    await t.tap(find.byKey(const Key('mine-dec')));
    await t.pumpAndSettle();
    expect(s.saves.last['value'], 3);
    await t.tap(find.byKey(const Key('mine-reset')));
    await t.pumpAndSettle();
    expect(s.saves.last['value'], 0);
  });

  testWidgets('contador: Ajustar muda passo, meta e unidade (meta vazia tira a meta)', (t) async {
    final s = _Server(_w('counter', {'value': 1, 'step': 1, 'goal': 10, 'unit': ''}));
    await _pump(t, s);
    await t.tap(find.byKey(const Key('mine-config')));
    await t.pumpAndSettle();
    await t.enterText(find.byKey(const Key('mine-cfg-step')), '5');
    await t.enterText(find.byKey(const Key('mine-cfg-goal')), '');
    await t.enterText(find.byKey(const Key('mine-cfg-unit')), 'páginas');
    await t.tap(find.byKey(const Key('mine-cfg-ok')));
    await t.pumpAndSettle();
    expect(s.saves.last, {'value': 1, 'step': 5, 'goal': null, 'unit': 'páginas'});
    expect(find.byKey(const Key('mine-counter-bar')), findsNothing);
    expect(find.text('+5'), findsOneWidget);
  });

  testWidgets('falha ao salvar mostra o aviso e a edição continua na tela', (t) async {
    final s = _Server(_w('counter', {'value': 0, 'step': 1, 'goal': null, 'unit': ''}));
    await _pump(t, s);
    s.failWith = 'Conteúdo grande demais.';
    await t.tap(find.byKey(const Key('mine-inc')));
    await t.pumpAndSettle();
    expect(find.text('Conteúdo grande demais.'), findsOneWidget);
    expect(find.text('1'), findsOneWidget);
  });

  testWidgets('Renomear salva o título novo e avisa o painel', (t) async {
    final s = _Server(_w('note', {'text': ''}));
    String? renamed;
    await _pump(t, s, onRenamed: (v) => renamed = v);
    await t.tap(find.byKey(const Key('mine-rename')));
    await t.pumpAndSettle();
    await t.enterText(find.byKey(const Key('mine-rename-input')), 'Compras');
    await t.tap(find.byKey(const Key('mine-rename-ok')));
    await t.pumpAndSettle();
    expect(s.w.title, 'Compras');
    expect(renamed, 'Compras');
  });
}
