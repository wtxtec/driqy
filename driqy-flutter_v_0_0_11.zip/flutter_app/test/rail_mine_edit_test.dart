import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_exception.dart';
import 'package:driqy_flutter/widgets/rail/rail_panel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

List<RailWidgetSpec> _specs() => [
      for (final id in ['a', 'b'])
        RailWidgetSpec(id: id, title: 'W-$id', builder: (_) => Text('corpo-$id')),
      RailWidgetSpec(id: 'custom:1', title: 'Minha nota', custom: true, builder: (_) => const Text('corpo-nota')),
    ];

const _prefs = RailPrefs(order: ['a', 'b', 'custom:1']);

Future<void> _pump(
  WidgetTester t, {
  Future<String> Function(String kind)? create,
  Future<bool> Function(String id)? delete,
  List<RailPrefs>? saved,
  int max = 12,
}) async {
  await t.pumpWidget(MaterialApp(
    home: Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: SizedBox(
            width: 320,
            child: RailPanel(
              specs: _specs(),
              prefs: _prefs,
              customMax: max,
              onCreateCustom: create,
              onDeleteCustom: delete,
              onSavePrefs: (next) async {
                saved?.add(next);
                return true;
              },
            ),
          ),
        ),
      ),
    ),
  ));
  await t.pumpAndSettle();
  await t.tap(find.byKey(const Key('rail-edit')));
  await t.pumpAndSettle();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('sem onCreateCustom não há "Criar o seu" nem lixeira', (t) async {
    await _pump(t);
    expect(find.textContaining('CRIAR O SEU'), findsNothing);
    expect(find.byKey(const Key('rail-ed-delete-custom:1')), findsNothing);
  });

  testWidgets('widgets próprios têm a etiqueta "seu"; os prontos não', (t) async {
    await _pump(t, create: (_) async => 'custom:2', delete: (_) async => true);
    expect(find.byKey(const Key('rail-ed-tag-custom:1')), findsOneWidget);
    expect(find.byKey(const Key('rail-ed-tag-a')), findsNothing);
    expect(find.byKey(const Key('rail-ed-delete-a')), findsNothing);
    expect(find.text('CRIAR O SEU (1/12)'), findsOneWidget);
  });

  testWidgets('criar: o novo entra em "No painel" e abre ao concluir', (t) async {
    final kinds = <String>[];
    final saved = <RailPrefs>[];
    await _pump(t, saved: saved, create: (k) async {
      kinds.add(k);
      return 'custom:2';
    });
    expect(find.text('NO PAINEL (3)'), findsOneWidget);
    await t.tap(find.byKey(const Key('rail-ed-new-checklist')));
    await t.pumpAndSettle();
    expect(kinds, ['checklist']);
    expect(find.text('NO PAINEL (4)'), findsOneWidget);
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(saved.length, 1);
    expect(saved.first.order, ['a', 'b', 'custom:1', 'custom:2']);
    expect(saved.first.disabled, isEmpty);
  });

  testWidgets('criar: erro do servidor aparece no editor e nada entra', (t) async {
    await _pump(t, create: (_) async => throw ApiException(400, 'Limite de 12 widgets próprios atingido.'));
    await t.tap(find.byKey(const Key('rail-ed-new-note')));
    await t.pumpAndSettle();
    expect(find.text('Limite de 12 widgets próprios atingido.'), findsOneWidget);
    expect(find.text('NO PAINEL (3)'), findsOneWidget);
  });

  testWidgets('no limite os botões de criar ficam desligados', (t) async {
    await _pump(t, max: 1, create: (_) async => 'custom:2');
    expect(find.text('Limite de 1 widgets seus atingido.'), findsOneWidget);
    expect(t.widget<ActionChip>(find.byKey(const Key('rail-ed-new-note'))).onPressed, isNull);
  });

  testWidgets('apagar: pede confirmação; Cancelar não apaga', (t) async {
    final deleted = <String>[];
    await _pump(t, create: (_) async => 'custom:2', delete: (id) async {
      deleted.add(id);
      return true;
    });
    await t.tap(find.byKey(const Key('rail-ed-delete-custom:1')));
    await t.pumpAndSettle();
    expect(find.text('Apagar de vez?'), findsOneWidget);
    await t.tap(find.byKey(const Key('rail-ed-delete-no')));
    await t.pumpAndSettle();
    expect(deleted, isEmpty);
    expect(find.text('NO PAINEL (3)'), findsOneWidget);
  });

  testWidgets('apagar: confirmando, o widget some do editor', (t) async {
    final deleted = <String>[];
    await _pump(t, create: (_) async => 'custom:2', delete: (id) async {
      deleted.add(id);
      return true;
    });
    await t.tap(find.byKey(const Key('rail-ed-delete-custom:1')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-delete-yes')));
    await t.pumpAndSettle();
    expect(deleted, ['custom:1']);
    expect(find.text('NO PAINEL (2)'), findsOneWidget);
  });

  testWidgets('apagar: se o servidor falha, o widget fica e há aviso', (t) async {
    await _pump(t, create: (_) async => 'custom:2', delete: (_) async => false);
    await t.tap(find.byKey(const Key('rail-ed-delete-custom:1')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-delete-yes')));
    await t.pumpAndSettle();
    expect(find.text('Não foi possível apagar agora. Tente de novo.'), findsOneWidget);
    expect(find.text('NO PAINEL (3)'), findsOneWidget);
  });
}
