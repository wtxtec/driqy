import 'package:driqy_flutter/models/flash.dart';
import 'package:driqy_flutter/models/user.dart';
import 'package:driqy_flutter/widgets/flash_ring.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('DriqyUser lê has_flash / flash_unseen (e aceita backend antigo)', () {
    final base = {
      'id': 1,
      'username': 'ana',
      'display_name': 'Ana',
      'created_at': '2026-10-27T10:00:00Z',
    };
    expect(DriqyUser.fromJson(base).hasFlash, false);
    final u = DriqyUser.fromJson({...base, 'has_flash': true, 'flash_unseen': true});
    expect(u.hasFlash, true);
    expect(u.flashUnseen, true);
  });

  test('FlashTray.fromJson', () {
    final t = FlashTray.fromJson({
      'me': {
        'user': {'id': 1, 'username': 'ana', 'display_name': 'Ana', 'avatar_url': null},
        'count': 2,
      },
      'items': [
        {
          'user': {'id': 2, 'username': 'beto', 'display_name': 'Beto', 'avatar_url': null},
          'count': 1,
          'unseen': true,
        }
      ],
    });
    expect(t.myCount, 2);
    expect(t.items.single.unseen, true);
  });

  testWidgets('FlashRing só desenha o anel quando há Flash', (tester) async {
    const child = SizedBox(width: 10, height: 10, key: Key('av'));
    await tester.pumpWidget(const MaterialApp(home: FlashRing(hasFlash: false, child: child)));
    expect(find.byType(Container), findsNothing);
    await tester.pumpWidget(const MaterialApp(home: FlashRing(hasFlash: true, child: child)));
    expect(find.byType(Container), findsWidgets);
    expect(find.byKey(const Key('av')), findsOneWidget);
  });
}
