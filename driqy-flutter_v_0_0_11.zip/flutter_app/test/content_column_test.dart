import 'package:driqy_flutter/widgets/wide_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('em tela larga o miolo fica com no máximo 620 e centralizado', (tester) async {
    tester.view.physicalSize = const Size(1600, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: ContentColumn(enabled: true, child: SizedBox.expand(key: Key('c')))),
    ));
    final box = tester.getRect(find.byKey(const Key('c')));
    expect(box.width, kContentMaxWidth);
    expect(box.center.dx, 800);
  });

  testWidgets('desligado não limita a largura', (tester) async {
    tester.view.physicalSize = const Size(1600, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: ContentColumn(enabled: false, child: SizedBox.expand(key: Key('c')))),
    ));
    expect(tester.getRect(find.byKey(const Key('c'))).width, 1600);
  });
}
