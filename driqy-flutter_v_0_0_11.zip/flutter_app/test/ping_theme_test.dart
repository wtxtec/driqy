import 'package:driqy_flutter/theme/ping_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Ping: tema escuro e claro têm fundos diferentes', () {
    expect(PingColors.dark.bg, isNot(PingColors.light.bg));
    expect(PingColors.dark.panel, isNot(PingColors.light.panel));
  });

  test('Ping: painter só redesenha quando a cor muda', () {
    const a = PingPatternPainter(Color(0x21F2A93B));
    expect(a.shouldRepaint(const PingPatternPainter(Color(0x21F2A93B))), isFalse);
    expect(a.shouldRepaint(const PingPatternPainter(Color(0x29C8791B))), isTrue);
  });
}
