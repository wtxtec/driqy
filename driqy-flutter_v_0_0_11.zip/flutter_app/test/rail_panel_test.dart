import 'package:driqy_flutter/widgets/rail/rail_panel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

List<RailWidgetSpec> _specs([int n = 3]) => [
      RailWidgetSpec(id: 'a', title: 'Alfa', builder: (_) => const Text('corpo A')),
      RailWidgetSpec(id: 'b', title: 'Beta', builder: (_) => const Text('corpo B')),
      RailWidgetSpec(id: 'c', title: 'Gama', builder: (_) => const Text('corpo C')),
    ].take(n).toList();

Future<void> _pump(WidgetTester tester, RailPanel panel) async {
  await tester.pumpWidget(MaterialApp(
    home: Scaffold(
      body: SingleChildScrollView(
        // chave nova a cada chamada: um segundo `_pump` no mesmo teste começa com estado novo
        child: Center(child: SizedBox(width: 320, child: KeyedSubtree(key: UniqueKey(), child: panel))),
      ),
    ),
  ));
  await tester.pumpAndSettle();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('com 1 widget: sem setas, grade nem bolinhas', (tester) async {
    await _pump(tester, RailPanel(specs: _specs(1)));
    expect(find.text('Alfa'), findsOneWidget);
    expect(find.text('corpo A'), findsOneWidget);
    expect(find.byKey(const Key('rail-prev')), findsNothing);
    expect(find.byKey(const Key('rail-next')), findsNothing);
    expect(find.byKey(const Key('rail-menu')), findsNothing);
    expect(find.byKey(const Key('rail-dot-0')), findsNothing);
  });

  testWidgets('sem nenhum widget: mensagem de vazio', (tester) async {
    await _pump(tester, const RailPanel(specs: []));
    expect(find.text('Nenhum widget disponível ainda.'), findsOneWidget);
  });

  testWidgets('o cartão de sugestões aparece vazio, ou com o conteúdo passado', (tester) async {
    await _pump(tester, RailPanel(specs: _specs(1)));
    expect(find.text('Sugestões para você'), findsOneWidget);
    expect(find.text('Sem sugestões por enquanto.'), findsOneWidget);

    await _pump(tester, RailPanel(specs: _specs(1), suggestions: const Text('lista de gente')));
    expect(find.text('lista de gente'), findsOneWidget);
    expect(find.text('Sem sugestões por enquanto.'), findsNothing);
  });

  testWidgets('setas ‹ › pulam entre widgets e dão a volta', (tester) async {
    await _pump(tester, RailPanel(specs: _specs()));
    expect(find.text('corpo A'), findsOneWidget);
    expect(find.text('corpo B'), findsNothing); // só o widget atual fica na tela

    await tester.tap(find.byKey(const Key('rail-next')));
    await tester.pumpAndSettle();
    expect(find.text('Beta'), findsOneWidget);
    expect(find.text('corpo B'), findsOneWidget);

    await tester.tap(find.byKey(const Key('rail-prev')));
    await tester.tap(find.byKey(const Key('rail-prev')));
    await tester.pumpAndSettle();
    expect(find.text('Gama'), findsOneWidget); // do primeiro, "anterior" vai para o último
    expect(find.text('corpo C'), findsOneWidget);

    await tester.tap(find.byKey(const Key('rail-next')));
    await tester.pumpAndSettle();
    expect(find.text('Alfa'), findsOneWidget); // do último, "próximo" volta ao primeiro
  });

  testWidgets('bolinhas escolhem o widget', (tester) async {
    await _pump(tester, RailPanel(specs: _specs()));
    await tester.tap(find.byKey(const Key('rail-dot-2')));
    await tester.pumpAndSettle();
    expect(find.text('corpo C'), findsOneWidget);
  });

  testWidgets('a grade abre a lista com todos os widgets', (tester) async {
    await _pump(tester, RailPanel(specs: _specs()));
    await tester.tap(find.byKey(const Key('rail-menu')));
    await tester.pumpAndSettle();
    expect(find.text('Gama'), findsOneWidget);
    await tester.tap(find.text('Gama'));
    await tester.pumpAndSettle();
    expect(find.text('corpo C'), findsOneWidget);
    expect(find.text('corpo A'), findsNothing);
  });

  testWidgets('segue a ordem do servidor e ignora ids que o app não conhece', (tester) async {
    await _pump(
      tester,
      RailPanel(specs: _specs(), loadAvailableIds: () async => ['c', 'zzz', 'a', 'a']),
    );
    expect(find.text('Gama'), findsOneWidget); // primeiro da ordem do servidor
    expect(find.byKey(const Key('rail-dot-1')), findsOneWidget);
    expect(find.byKey(const Key('rail-dot-2')), findsNothing); // 'b' não veio; 'zzz' e o repetido não contam
    await tester.tap(find.byKey(const Key('rail-next')));
    await tester.pumpAndSettle();
    expect(find.text('Alfa'), findsOneWidget);
  });

  testWidgets('servidor fora do ar ou sem ids conhecidos: vale a ordem local', (tester) async {
    await _pump(tester, RailPanel(specs: _specs(), loadAvailableIds: () async => throw Exception('sem rede')));
    expect(find.text('Alfa'), findsOneWidget);
    expect(find.byKey(const Key('rail-dot-2')), findsOneWidget);

    await _pump(tester, RailPanel(specs: _specs(), loadAvailableIds: () async => ['x', 'y']));
    expect(find.text('Alfa'), findsOneWidget);
    expect(find.byKey(const Key('rail-dot-2')), findsOneWidget);
  });

  testWidgets('abre no último widget usado e salva a escolha', (tester) async {
    SharedPreferences.setMockInitialValues({kRailWidgetPrefKey: 'b'});
    await _pump(tester, RailPanel(specs: _specs()));
    expect(find.text('Beta'), findsOneWidget);

    await tester.tap(find.byKey(const Key('rail-next')));
    await tester.pumpAndSettle();
    expect((await SharedPreferences.getInstance()).getString(kRailWidgetPrefKey), 'c');
  });

  testWidgets('id salvo que não existe mais: abre no primeiro', (tester) async {
    SharedPreferences.setMockInitialValues({kRailWidgetPrefKey: 'sumiu'});
    await _pump(tester, RailPanel(specs: _specs()));
    expect(find.text('Alfa'), findsOneWidget);
  });
}
