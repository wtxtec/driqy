import 'package:driqy_flutter/widgets/ping_tab_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('PingTabBar mostra as 4 abas (Chats, Contatos, Chamadas, Menu) e dispara os toques', (tester) async {
    var contacts = 0, calls = 0, menu = 0;
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        bottomNavigationBar: PingTabBar(
          unread: 3,
          onContacts: () => contacts++,
          onCalls: () => calls++,
          onMenu: () => menu++,
        ),
      ),
    ));
    for (final l in ['Chats', 'Contatos', 'Chamadas', 'Menu']) {
      expect(find.text(l), findsOneWidget);
    }
    expect(find.text('3'), findsOneWidget);
    await tester.tap(find.text('Contatos'));
    await tester.tap(find.text('Chamadas'));
    await tester.tap(find.text('Menu'));
    expect([contacts, calls, menu], [1, 1, 1]);
  });

  testWidgets('PingTabBar marca a aba atual e Chats dispara onChats (fase 8)', (tester) async {
    var chats = 0;
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        bottomNavigationBar: PingTabBar(
          current: PingTab.contacts,
          onChats: () => chats++,
          onContacts: () {},
          onCalls: () {},
          onMenu: () {},
        ),
      ),
    ));
    final selected = tester
        .widgetList<Semantics>(find.byType(Semantics))
        .where((w) => w.properties.selected == true && w.properties.label != null)
        .map((w) => w.properties.label)
        .toList();
    expect(selected, ['Contatos']);
    await tester.tap(find.text('Chats'));
    expect(chats, 1);
  });
}
