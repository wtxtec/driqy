import 'package:driqy_flutter/models/rail_extra.dart';
import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_client.dart';
import 'package:driqy_flutter/services/widgets_service.dart';
import 'package:driqy_flutter/widgets/rail/rail_extra.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Serviço de mentira (sem rede): cada teste preenche só o que usa.
class _Fake extends WidgetsService {
  _Fake() : super(ApiClient());

  ClockResult clock = const ClockResult();
  final List<List<String>> clockCalls = [];
  final List<List<int?>> calendarCalls = [];
  MoonInfo? moon;
  SeasonInfo? seasons;
  final List<QuotesResult> quotes = [];
  int quotesCalls = 0;
  final List<String?> calendarCountries = [];
  StatsInfo stats = const StatsInfo();
  List<ExpiringPost> expiring = const [];
  PhraseInfo phrase = const PhraseInfo(text: '');

  @override
  Future<ClockResult> getClock({List<String> zones = const []}) async {
    clockCalls.add(zones);
    return clock;
  }

  @override
  Future<CalendarMonth> getCalendar({int? year, int? month, String? country}) async {
    calendarCalls.add([year, month]);
    calendarCountries.add(country);
    final m = month ?? 11;
    final de = country == 'DE';
    return CalendarMonth(
      year: year ?? 2026,
      month: m,
      monthName: de ? (m == 11 ? 'November' : 'Dezember') : (m == 11 ? 'novembro' : 'dezembro'),
      daysInMonth: m == 11 ? 30 : 31,
      firstWeekday: m == 11 ? 0 : 2,
      weekdays: de ? const ['M', 'D', 'M', 'D', 'F', 'S', 'S'] : const [],
      firstOffset: de ? (m == 11 ? 6 : 1) : null,
      country: de ? 'DE' : 'BR',
      countryName: de ? 'Alemanha' : 'Brasil',
      countryChosen: de,
      countries: const [CalCountry(code: 'BR', name: 'Brasil'), CalCountry(code: 'DE', name: 'Alemanha')],
      today: '2026-11-05',
      holidays: m == 11
          ? const [
              CalHoliday(day: 2, name: 'Finados'),
              CalHoliday(day: 20, name: 'Consciência Negra', kind: 'facultativo'),
            ]
          : const [],
    );
  }

  @override
  Future<MoonInfo> getMoon() async => moon!;

  @override
  Future<SeasonInfo> getSeasons() async => seasons!;

  @override
  Future<QuotesResult> getQuotes() async {
    final i = quotesCalls++;
    return quotes[i < quotes.length ? i : quotes.length - 1];
  }

  @override
  Future<StatsInfo> getStats() async => stats;

  @override
  Future<List<ExpiringPost>> getExpiring() async => expiring;

  @override
  Future<PhraseInfo> getPhrase() async => phrase;
}

Future<void> _pump(WidgetTester t, Widget w) async {
  await t.pumpWidget(MaterialApp(
    home: Scaffold(body: SingleChildScrollView(child: Center(child: SizedBox(width: 320, child: w)))),
  ));
  await t.pumpAndSettle();
}

ClockCity _city(String id, String name, DateTime local, {int day = 0}) =>
    ClockCity(id: id, name: name, utcLabel: 'UTC-3', dayOffset: day, local: local);

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('formatadores do pt-BR', () {
    expect(formatBrl(5.4321), 'R\$ 5,43');
    expect(formatBrl(1234567.8), 'R\$ 1.234.567,80');
    expect(formatBrl(0), 'R\$ 0,00');
    expect(formatInt(0), '0');
    expect(formatInt(999), '999');
    expect(formatInt(1234), '1.234');
    expect(formatInt(1234567), '1.234.567');
    expect(shortDate('2026-11-25'), '25/11');
    expect(timeLeft(30), 'menos de 1 min');
    expect(timeLeft(125), '2 min');
    expect(timeLeft(3600), '1 h 00 min');
    expect(timeLeft(3 * 3600 + 7 * 60), '3 h 07 min');
  });

  test('modelos leem o JSON do servidor', () {
    final c = ClockResult.fromJson({
      'ok': true,
      'cities': [
        {'id': 'x', 'name': 'X', 'utc_label': 'UTC+1', 'local': '2026-11-05T14:03:09-03:00', 'day_offset': 1},
        {'id': 'bad', 'name': 'Sem hora', 'local': 'nada'}, // descartada
      ],
      'available': [
        {'id': 'x', 'name': 'X'},
      ],
    });
    expect(c.ok, isTrue);
    expect(c.cities.length, 1);
    expect(c.cities.single.local, DateTime.utc(2026, 11, 5, 14, 3, 9));
    expect(c.available.single.id, 'x');
    expect(ClockResult.fromJson({'ok': false}).ok, isFalse);

    final q = QuotesResult.fromJson({
      'ok': true,
      'items': [
        {'code': 'USD', 'name': 'Dólar', 'value': 5.43, 'change_pct': -0.5, 'high': 5.5, 'low': 5.4},
      ],
      'updated_at': '2026-11-05T17:30:00Z',
      'stale': true,
    });
    expect(q.ok, isTrue);
    expect(q.items.single.changePct, -0.5);
    expect(q.stale, isTrue);
    expect(QuotesResult.fromJson({'ok': false, 'reason': 'disabled'}).reason, 'disabled');
    expect(const QuotesResult.unavailable().ok, isFalse);

    final cal = CalendarMonth.fromJson({
      'year': 2026, 'month': 11, 'month_name': 'novembro', 'days_in_month': 30, 'first_weekday': 0,
      'today': '2026-11-05', 'holidays': [{'day': 2, 'name': 'Finados', 'kind': 'feriado'}],
    });
    expect(cal.isCurrent, isTrue);
    expect(cal.todayDay, 5);
    expect(CalendarMonth.fromJson({'year': 2026, 'month': 12, 'today': '2026-11-05'}).todayDay, 0);
  });

  testWidgets('relógio: mostra as cidades, a hora anda e "amanhã" aparece', (t) async {
    final f = _Fake()
      ..clock = ClockResult(
        ok: true,
        cities: [
          _city('sp', 'São Paulo', DateTime.utc(2026, 11, 5, 14, 0, 0)),
          _city('tk', 'Tóquio', DateTime.utc(2026, 11, 6, 2, 0, 0), day: 1),
        ],
        available: const [ClockZone(id: 'sp', name: 'São Paulo'), ClockZone(id: 'tk', name: 'Tóquio')],
      );
    var now = DateTime(2026, 11, 5, 10, 0, 0);
    await _pump(t, RailClockWidget(service: f, now: () => now));
    expect(find.text('São Paulo'), findsOneWidget);
    expect(find.text('UTC-3 · amanhã'), findsOneWidget);
    expect(find.text('14:00:00'), findsOneWidget);
    now = now.add(const Duration(seconds: 65));
    await t.pump(const Duration(seconds: 1));
    expect(find.text('14:01:05'), findsOneWidget);
    expect(find.text('02:01:05'), findsOneWidget);
  });

  testWidgets('relógio: base de fusos fora do ar mostra "indisponível"', (t) async {
    final f = _Fake()..clock = const ClockResult(ok: false);
    await _pump(t, RailClockWidget(service: f));
    expect(find.text('Relógio indisponível agora.'), findsOneWidget);
    expect(find.text('Tentar de novo'), findsOneWidget);
  });

  testWidgets('relógio: escolher cidades salva (mín. 1) e Fechar busca de novo com elas', (t) async {
    final f = _Fake()
      ..clock = ClockResult(
        ok: true,
        cities: [
          _city('sp', 'São Paulo', DateTime.utc(2026, 11, 5, 14)),
          _city('lx', 'Lisboa', DateTime.utc(2026, 11, 5, 17)),
        ],
        available: const [
          ClockZone(id: 'sp', name: 'São Paulo'),
          ClockZone(id: 'lx', name: 'Lisboa'),
          ClockZone(id: 'tk', name: 'Tóquio'),
        ],
      );
    await _pump(t, RailClockWidget(service: f));
    await t.tap(find.byKey(const Key('clock-toggle')));
    await t.pumpAndSettle();
    expect(find.text('Até 6 cidades. Toque em Fechar para atualizar.'), findsOneWidget);
    await t.tap(find.byKey(const Key('clock-zone-tk'))); // adiciona
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('clock-zone-sp'))); // tira
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('clock-zone-lx'))); // tira
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('clock-zone-tk'))); // seria a última: recusado
    await t.pumpAndSettle();
    expect((await SharedPreferences.getInstance()).getStringList(kClockZonesKey), ['tk']);
    await t.tap(find.byKey(const Key('clock-zone-lx'))); // volta
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('clock-toggle'))); // Fechar
    await t.pumpAndSettle();
    expect(f.clockCalls.last, ['tk', 'lx']);
  });

  testWidgets('calendário: mês, feriados, navegar e voltar para hoje', (t) async {
    final f = _Fake();
    await _pump(t, RailCalendarWidget(service: f));
    expect(find.text('Novembro 2026'), findsOneWidget);
    expect(find.byKey(const Key('cal-day-30')), findsOneWidget);
    expect(find.byKey(const Key('cal-day-31')), findsNothing);
    expect(find.text('02 · Finados'), findsOneWidget);
    expect(find.text('20 · Consciência Negra (facultativo)'), findsOneWidget);
    expect(find.byKey(const Key('cal-today')), findsNothing); // já é o mês de hoje
    await t.tap(find.byKey(const Key('cal-next')));
    await t.pumpAndSettle();
    expect(f.calendarCalls.last, [2026, 12]);
    expect(find.text('Dezembro 2026'), findsOneWidget);
    expect(find.byKey(const Key('cal-day-31')), findsOneWidget);
    await t.tap(find.byKey(const Key('cal-today')));
    await t.pumpAndSettle();
    expect(f.calendarCalls.last, [null, null]);
    expect(find.text('Novembro 2026'), findsOneWidget);
  });

  testWidgets('calendário: país dos feriados muda nomes e semana, e fica guardado', (t) async {
    final f = _Fake();
    await _pump(t, RailCalendarWidget(service: f));
    expect(find.text('D'), findsOneWidget); // padrão: domingo primeiro, em português
    expect(f.calendarCountries.last, '');
    await t.tap(find.byKey(const Key('cal-country')));
    await t.pumpAndSettle();
    await t.tap(find.text('Alemanha').last);
    await t.pumpAndSettle();
    expect(f.calendarCountries.last, 'DE');
    expect(find.text('November 2026'), findsOneWidget);
    expect(find.text('M'), findsNWidgets(2)); // segunda e quarta
    expect((await SharedPreferences.getInstance()).getString(kCalendarCountryKey), 'DE');
  });

  testWidgets('calendário: escolha guardada é usada na abertura', (t) async {
    SharedPreferences.setMockInitialValues({kCalendarCountryKey: 'DE'});
    final f = _Fake();
    await _pump(t, RailCalendarWidget(service: f));
    expect(f.calendarCountries.first, 'DE');
    expect(find.text('November 2026'), findsOneWidget);
  });

  test('calendário: campos da região e servidor antigo', () {
    final c = CalendarMonth.fromJson({
      'year': 2026, 'month': 11, 'days_in_month': 30, 'first_weekday': 0, 'first_offset': 6, 'country': 'DE',
      'country_name': 'Alemanha', 'country_chosen': true, 'weekdays': ['M', 'D', 'M', 'D', 'F', 'S', 'S'],
      'countries': [{'code': 'DE', 'name': 'Alemanha'}],
    });
    expect(c.blanks, 6);
    expect(c.gridWeekdays.first, 'M');
    expect(c.countryChosen, isTrue);
    expect(c.countries.single.code, 'DE');
    final old = CalendarMonth.fromJson({'year': 2026, 'month': 11, 'days_in_month': 30, 'first_weekday': 3});
    expect(old.blanks, 3);
    expect(old.gridWeekdays, ['D', 'S', 'T', 'Q', 'Q', 'S', 'S']);
  });

  testWidgets('lua: fase, iluminação e próximas datas', (t) async {
    final f = _Fake()
      ..moon = const MoonInfo(
        phase: 'Crescente',
        emoji: '🌓',
        illumination: 52,
        ageDays: 7.4,
        nextFull: '2026-11-24',
        nextNew: '2026-12-09',
        daysToFull: 1,
        daysToNew: 0,
      );
    await _pump(t, RailMoonWidget(service: f));
    expect(find.text('Crescente'), findsOneWidget);
    expect(find.text('52% iluminada · 7,4 dias'), findsOneWidget);
    expect(find.text('🌕 Próxima cheia: 24/11 (amanhã)'), findsOneWidget);
    expect(find.text('🌑 Próxima nova: 09/12 (hoje)'), findsOneWidget);
  });

  testWidgets('lua: tendência, barra da lunação, distância e marcos do ciclo', (t) async {
    final f = _Fake()
      ..moon = MoonInfo.fromJson({
        'phase': 'Lua minguante', 'emoji': '🌘', 'illumination': 13, 'age_days': 26.1,
        'next_full': '2026-11-24', 'next_new': '2026-11-09', 'days_to_full': 19, 'days_to_new': 4,
        'waxing': false, 'trend': 'Minguando', 'cycle_pct': 88.4, 'cycle_days': 29.5,
        'distance_km': 385100, 'distance_label': 'Distância média',
        'events': [
          {'name': 'Lua nova', 'emoji': '🌑', 'date': '2026-11-09', 'days': 4},
          {'name': 'Quarto crescente', 'emoji': '🌓', 'date': '2026-11-17', 'days': 11},
          {'name': 'Lua cheia', 'emoji': '🌕', 'date': '2026-11-24', 'days': 19},
          {'name': 'Quarto minguante', 'emoji': '🌗', 'date': '2026-12-01', 'days': 26},
        ],
      });
    await _pump(t, RailMoonWidget(service: f));
    expect(find.text('↘ Minguando'), findsOneWidget);
    expect(find.byKey(const Key('moon-cycle-bar')), findsOneWidget);
    expect(find.text('88% de 29,5 dias'), findsOneWidget);
    expect(find.text('📏 Distância: 385.100 km · Distância média'), findsOneWidget);
    expect(find.text('🌑 Lua nova'), findsOneWidget);
    expect(find.text('09/11 · em 4 dias'), findsOneWidget);
    expect(find.text('01/12 · em 26 dias'), findsOneWidget);
    expect(find.textContaining('Próxima cheia'), findsNothing); // desenho novo, não o antigo
  });

  testWidgets('lua: nascer/pôr e próximos eclipses', (t) async {
    final f = _Fake()
      ..moon = MoonInfo.fromJson({
        'phase': 'Lua nova', 'emoji': '🌑', 'illumination': 0, 'age_days': 0.2,
        'rise_set': {
          'place': 'Guarapari', 'approximate': false, 'rise': '04:47', 'set': '18:25', 'up_now': true,
          'next': {'label': 'Se põe', 'time': '18:25', 'today': true},
        },
        'eclipses': [
          {'kind': 'solar', 'type': 'anular', 'emoji': '☀️', 'name': 'Eclipse solar anular', 'date': '2027-02-06',
           'time': '12:59', 'days': 89, 'visible_here': null},
          {'kind': 'lunar', 'type': 'penumbral', 'emoji': '🌕', 'name': 'Eclipse lunar penumbral', 'date': '2027-02-20',
           'time': '20:13', 'days': 103, 'visible_here': true, 'magnitude': 0.92},
        ],
      });
    await _pump(t, RailMoonWidget(service: f));
    expect(find.text('🌙↑ Nasce 04:47'), findsOneWidget);
    expect(find.text('Se põe 18:25 ↓'), findsOneWidget);
    expect(find.textContaining('No céu agora · se põe hoje às 18:25 · Guarapari'), findsOneWidget);
    expect(find.text('Próximos eclipses · horário de Brasília'), findsOneWidget); // sem tz_label = Brasília
    expect(find.textContaining('· horário de Brasília'), findsNWidgets(2)); // nota do nascer/pôr + título
    expect(find.text('☀️ Eclipse solar anular'), findsOneWidget);
    expect(find.text('06/02 · em 89 dias'), findsOneWidget);
    expect(find.text('máximo às 12:59'), findsOneWidget);
    expect(find.text('máximo às 20:13 · visível daqui'), findsOneWidget);
  });

  testWidgets('lua: horários no fuso do aparelho mostram o rótulo do fuso', (t) async {
    final f = _Fake()
      ..moon = MoonInfo.fromJson({
        'phase': 'Lua nova', 'emoji': '🌑', 'illumination': 0, 'age_days': 0.2, 'tz_label': 'GMT-5',
        'rise_set': {'place': 'Lima', 'approximate': false, 'rise': '04:47', 'set': '18:25', 'up_now': true},
        'eclipses': [
          {'kind': 'lunar', 'type': 'penumbral', 'emoji': '🌕', 'name': 'Eclipse lunar penumbral', 'date': '2027-02-20',
           'time': '20:13', 'days': 103, 'visible_here': true},
        ],
      });
    await _pump(t, RailMoonWidget(service: f));
    expect(find.textContaining('Lima · seu horário (GMT-5)'), findsOneWidget);
    expect(find.text('Próximos eclipses · seu horário (GMT-5)'), findsOneWidget);
    expect(find.textContaining('horário de Brasília'), findsNothing);
  });

  test('tzWords: Brasília, vazio e outro fuso', () {
    expect(tzWords(''), 'horário de Brasília');
    expect(tzWords('Brasília'), 'horário de Brasília');
    expect(tzWords('GMT+5:30'), 'seu horário (GMT+5:30)');
    expect(MoonInfo.fromJson({'phase': 'x'}).tzLabel, '');
    expect(MoonInfo.fromJson({'phase': 'x', 'tz_label': 'GMT+9'}).tzLabel, 'GMT+9');
  });

  test('lua: nascer/pôr e eclipses ausentes (servidor antigo)', () {
    final m = MoonInfo.fromJson({'phase': 'Lua cheia'});
    expect(m.riseSet, isNull);
    expect(m.eclipses, isEmpty);
    final r = MoonRiseSet.fromJson({'rise': null, 'set': '18:00', 'next': null});
    expect(r.rise, '');
    expect(r.nextLabel, '');
  });

  test('lua: servidor antigo (sem os campos novos) continua válido', () {
    final m = MoonInfo.fromJson({'phase': 'Lua cheia', 'illumination': 100});
    expect(m.events, isEmpty);
    expect(m.cyclePct, isNull);
    expect(m.trend, '');
    expect(m.distanceKm, 0);
  });

  SeasonInfo seasonData({String? alert, int left = 45, String? tz}) => SeasonInfo.fromJson({
        if (tz != null) 'tz_label': tz,
        'hemisphere': 'sul',
        'current': {
          'key': 'primavera', 'name': 'Primavera', 'emoji': '🌸', 'start': '2026-09-22', 'end': '2026-12-21',
          'start_label': '22/09 21:05', 'end_label': '21/12 17:50', 'event': 'Equinócio de setembro',
          'days': 90, 'progress': 49.5, 'status': 'current', 'day_number': 46, 'days_left': left,
        },
        'next': {
          'key': 'verão', 'name': 'Verão', 'emoji': '☀️', 'start': '2026-12-21', 'end': '2027-03-20',
          'start_label': '21/12 17:50', 'end_label': '20/03 17:24', 'event': 'Solstício de dezembro',
          'days': 89, 'progress': 0.0, 'status': 'future',
        },
        'days_to_next': left,
        'year_progress': 87.6,
        'alert': alert,
        'cycle': [
          for (final e in [
            ['verão', 'Verão', '☀️', 100.0, 'past'],
            ['outono', 'Outono', '🍂', 100.0, 'past'],
            ['inverno', 'Inverno', '❄️', 100.0, 'past'],
            ['primavera', 'Primavera', '🌸', 49.5, 'current'],
          ])
            {'key': e[0], 'name': e[1], 'emoji': e[2], 'progress': e[3], 'status': e[4], 'start': '2026-01-01', 'end': '2026-02-01'},
        ],
      });

  testWidgets('estações: atual, progresso, 4 faixas do ano e próxima virada', (t) async {
    final f = _Fake()..seasons = seasonData();
    await _pump(t, RailSeasonsWidget(service: f));
    expect(find.text('Primavera'), findsWidgets);
    expect(find.text('Dia 46 de 90 · faltam 45 dias'), findsOneWidget);
    expect(find.text('49,5%'), findsOneWidget);
    expect(find.text('22/09'), findsOneWidget);
    expect(find.text('21/12'), findsOneWidget);
    for (final k in ['verão', 'outono', 'inverno', 'primavera']) {
      expect(find.byKey(Key('season-seg-$k')), findsOneWidget, reason: k);
    }
    expect(find.byKey(const Key('season-alert')), findsNothing); // longe da virada
    expect(find.textContaining('Próxima: ☀️ Verão em 21/12 às 17:50 (Solstício de dezembro) · ano 87,6%'), findsOneWidget);
  });

  testWidgets('estações: fuso diferente de Brasília aparece na linha da próxima virada', (t) async {
    final f = _Fake()..seasons = seasonData(tz: 'GMT+9');
    await _pump(t, RailSeasonsWidget(service: f));
    expect(find.textContaining('(Solstício de dezembro) · GMT+9 · ano 87,6%'), findsOneWidget);
  });

  testWidgets('estações: aviso aparece quando faltam 3 dias ou menos', (t) async {
    final f = _Fake()..seasons = seasonData(alert: 'Verão começa em 3 dias (21/12)', left: 3);
    await _pump(t, RailSeasonsWidget(service: f));
    expect(find.byKey(const Key('season-alert')), findsOneWidget);
    expect(find.text('☀️ Verão começa em 3 dias (21/12)'), findsOneWidget);
    expect(find.text('Dia 46 de 90 · faltam 3 dias'), findsOneWidget);
  });

  testWidgets('estações: "vira hoje" e "falta 1 dia"', (t) async {
    await _pump(t, RailSeasonsWidget(service: _Fake()..seasons = seasonData(left: 0)));
    expect(find.text('Dia 46 de 90 · vira hoje'), findsOneWidget);
    await _pump(t, RailSeasonsWidget(service: _Fake()..seasons = seasonData(left: 1)));
    expect(find.text('Dia 46 de 90 · falta 1 dia'), findsOneWidget);
  });

  testWidgets('cotações: valores, variação, rodapé e dados antigos', (t) async {
    final f = _Fake()
      ..quotes.add(QuotesResult(
        ok: true,
        stale: true,
        updatedAt: DateTime(2026, 11, 5, 14, 30),
        items: const [
          QuoteItem(code: 'USD', name: 'Dólar', value: 5.43, changePct: -0.5, high: 5.5, low: 5.4),
          QuoteItem(code: 'BTC', name: 'Bitcoin', value: 350123.45, changePct: 1.25),
        ],
      ));
    await _pump(t, RailQuotesWidget(service: f));
    expect(find.text('R\$ 5,43'), findsOneWidget);
    expect(find.text('R\$ 350.123,45'), findsOneWidget);
    expect(find.text('▼ 0,50%'), findsOneWidget);
    expect(find.text('▲ 1,25%'), findsOneWidget);
    expect(find.text('mín R\$ 5,40 · máx R\$ 5,50'), findsOneWidget);
    expect(find.text('Atualizado às 14:30 (dados antigos: sem conexão com a fonte)'), findsOneWidget);
  });

  testWidgets('cotações: desligadas não têm "Tentar de novo"; indisponíveis têm', (t) async {
    var f = _Fake()..quotes.add(const QuotesResult(reason: 'disabled'));
    await _pump(t, RailQuotesWidget(service: f));
    expect(find.text('Cotações desligadas pelo administrador.'), findsOneWidget);
    expect(find.text('Tentar de novo'), findsNothing);
    f = _Fake()..quotes.add(const QuotesResult.unavailable());
    await _pump(t, RailQuotesWidget(key: UniqueKey(), service: f));
    expect(find.text('Cotações indisponíveis agora.'), findsOneWidget);
    expect(find.text('Tentar de novo'), findsOneWidget);
  });

  testWidgets('cotações: atualização automática que falha mantém o que estava bom', (t) async {
    final f = _Fake()
      ..quotes.addAll([
        const QuotesResult(ok: true, items: [QuoteItem(code: 'USD', name: 'Dólar', value: 5.43)]),
        const QuotesResult.unavailable(),
      ]);
    await _pump(t, RailQuotesWidget(service: f, refresh: const Duration(seconds: 10)));
    expect(find.text('R\$ 5,43'), findsOneWidget);
    await t.pump(const Duration(seconds: 10));
    await t.pumpAndSettle();
    expect(f.quotesCalls, 2);
    expect(find.text('R\$ 5,43'), findsOneWidget);
    expect(find.text('Cotações indisponíveis agora.'), findsNothing);
  });

  testWidgets('Seu Driqy: números com milhar e novos seguidores (singular/plural)', (t) async {
    final f = _Fake()..stats = const StatsInfo(followers: 1234, following: 12, postsLive: 3, views: 1000000, likes: 5, comments: 0, newFollowers7d: 1);
    await _pump(t, RailStatsWidget(service: f));
    expect(find.text('1.234'), findsOneWidget);
    expect(find.text('1.000.000'), findsOneWidget);
    expect(find.text('Seguidores'), findsOneWidget);
    expect(find.text('+1 novo seguidor nos últimos 7 dias'), findsOneWidget);
    f.stats = const StatsInfo(newFollowers7d: 3);
    await _pump(t, RailStatsWidget(key: UniqueKey(), service: f));
    expect(find.text('+3 novos seguidores nos últimos 7 dias'), findsOneWidget);
    f.stats = const StatsInfo();
    await _pump(t, RailStatsWidget(key: UniqueKey(), service: f));
    expect(find.byKey(const Key('stats-new')), findsNothing);
  });

  testWidgets('acabando: vazio, lista com contagem e toque abre o post', (t) async {
    final f = _Fake();
    await _pump(t, RailExpiringWidget(service: f));
    expect(find.text('Nenhum post temporário some nas próximas 48 h.'), findsOneWidget);

    f.expiring = const [
      ExpiringPost(id: 7, mine: true, author: RailPerson(username: 'eu'), snippet: 'oi gente', secondsLeft: 3600),
      ExpiringPost(id: 8, author: RailPerson(username: 'ana'), snippet: 'foto', secondsLeft: 20),
    ];
    final opened = <int>[];
    await _pump(t, RailExpiringWidget(key: UniqueKey(), service: f, onOpen: (_, id) => opened.add(id)));
    expect(find.text('Você'), findsOneWidget);
    expect(find.text('@ana'), findsOneWidget);
    expect(find.text('⏳ some em 1 h 00 min'), findsOneWidget);
    expect(find.text('⏳ some em menos de 1 min'), findsOneWidget);
    await t.tap(find.byKey(const Key('expiring-8')));
    expect(opened, [8]);
  });

  testWidgets('frase do dia: texto entre aspas e autor', (t) async {
    final f = _Fake()..phrase = const PhraseInfo(text: 'Devagar se vai ao longe.', author: 'Provérbio');
    await _pump(t, RailPhraseWidget(service: f));
    expect(find.text('“Devagar se vai ao longe.”'), findsOneWidget);
    expect(find.text('— Provérbio'), findsOneWidget);
  });
}
