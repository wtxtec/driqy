import 'package:driqy_flutter/models/chat_group.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('DriqyGroup.fromJson lê lista e detalhe', () {
    final g = DriqyGroup.fromJson({
      'id': 7,
      'name': 'Turma',
      'description': 'oi',
      'avatar_url': null,
      'member_count': 2,
      'my_role': 'admin',
      'prefs': {'pinned': true, 'muted': false, 'archived': false},
      'unread': 3,
      'last_preview': 'Ana: oi',
      'last_activity': '2026-10-28T10:00:00Z',
      'members': [
        {'id': 1, 'username': 'ana', 'display_name': 'Ana', 'role': 'owner'},
        {'id': 2, 'username': 'beto', 'display_name': 'Beto', 'role': 'member'},
      ],
    });
    expect(g.id, 7);
    expect(g.isAdmin, isTrue);
    expect(g.isOwner, isFalse);
    expect(g.prefs.pinned, isTrue);
    expect(g.unread, 3);
    expect(g.members.length, 2);
    expect(g.members.first.role, 'owner');
    expect(g.lastActivity, isNotNull);
  });

  test('DriqyGroupMessage: texto, sistema, resposta e apagada', () {
    final m = DriqyGroupMessage.fromJson({
      'id': 5,
      'kind': 'text',
      'sender': {'id': 1, 'username': 'ana', 'display_name': 'Ana'},
      'content': 'olá',
      'reply_to': {'id': 4, 'sender_name': 'Beto', 'preview': 'e aí', 'deleted': false},
      'client_id': 'abc',
      'created_at': '2026-10-28T10:00:00Z',
      'edited': true,
      'deleted': false,
      'mine': true,
    });
    expect(m.isSystem, isFalse);
    expect(m.replyTo!.senderName, 'Beto');
    expect(m.edited && m.mine, isTrue);
    final s = DriqyGroupMessage.fromJson({'id': 6, 'kind': 'system', 'sender': null, 'content': 'Ana criou o grupo', 'created_at': '2026-10-28T10:00:00Z'});
    expect(s.isSystem, isTrue);
    expect(m.withState('failed').state, 'failed');
  });

  test('DriqyGroup com JSON mínimo usa padrões', () {
    final g = DriqyGroup.fromJson({'id': 1, 'name': 'X'});
    expect(g.memberCount, 0);
    expect(g.myRole, 'member');
    expect(g.prefs.muted, isFalse);
    expect(g.members, isEmpty);
  });
}
