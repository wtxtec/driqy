import 'package:driqy_flutter/services/user_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('ContactsPage.fromJson le usuarios, paginacao e contagens (fase 8)', () {
    final page = ContactsPage.fromJson({
      'users': [
        {
          'id': 2,
          'username': 'beto',
          'display_name': 'Beto',
          'bio': '',
          'location': '',
          'accent_color': 'amber',
          'avatar_url': null,
          'cover_url': null,
          'badge_kind': null,
          'followers_count': 1,
          'following_count': 0,
          'is_following': true,
          'is_me': false,
        },
      ],
      'has_next': true,
      'counts': {'following': 3, 'followers': 1},
    });
    expect(page.users.single.username, 'beto');
    expect(page.hasNext, isTrue);
    expect([page.followingCount, page.followersCount], [3, 1]);
  });

  test('ContactsPage.fromJson tolera resposta sem counts', () {
    final page = ContactsPage.fromJson({'users': [], 'has_next': false});
    expect(page.users, isEmpty);
    expect([page.followingCount, page.followersCount], [0, 0]);
  });
}
