import 'package:driqy_flutter/widgets/scroll_to_top_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('aparece depois de rolar e volta ao topo ao tocar', (tester) async {
    final controller = ScrollController();
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        floatingActionButton: ScrollToTopButton(controller: controller),
        body: ListView.builder(controller: controller, itemCount: 200, itemBuilder: (_, i) => SizedBox(height: 60, child: Text('item $i'))),
      ),
    ));
    expect(tester.widget<AnimatedScale>(find.byType(AnimatedScale)).scale, 0);
    controller.jumpTo(2000);
    await tester.pumpAndSettle();
    expect(tester.widget<AnimatedScale>(find.byType(AnimatedScale)).scale, 1);
    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();
    expect(controller.offset, 0);
  });
}
