import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_client.dart';
import 'package:driqy_flutter/services/news_service.dart';
import 'package:driqy_flutter/services/widgets_service.dart';
import 'package:driqy_flutter/widgets/rail/rail_lists.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _FakeService extends WidgetsService {
  List<TrendingPost> trending = const [];
  List<NewsHeadline> news = const [];
  List<VortexPreviewItem> vortex = const [];
  OnlineResult online = const OnlineResult();
  int failFirst = 0; // quantas chamadas falham antes de dar certo
  int calls = 0;
  final List<int> newsLimits = [];

  _FakeService() : super(ApiClient());

  Future<T> _answer<T>(T value) async {
    calls++;
    if (calls <= failFirst) throw Exception('rede');
    return value;
  }

  @override
  Future<List<TrendingPost>> getTrending() => _answer(trending);
  @override
  Future<List<NewsHeadline>> getNews({int limit = 4}) {
    newsLimits.add(limit);
    return _answer(news.take(limit).toList());
  }
  @override
  Future<List<VortexPreviewItem>> getVortex() => _answer(vortex);
  @override
  Future<OnlineResult> getOnline() => _answer(online);
}

Future<void> _pump(WidgetTester tester, Widget w) async {
  await tester.pumpWidget(MaterialApp(home: Scaffold(body: SingleChildScrollView(child: SizedBox(width: 300, child: w)))));
  await tester.pumpAndSettle();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('Em alta: mostra autor, trecho e contagens; vazio tem mensagem', (tester) async {
    final s = _FakeService()
      ..trending = const [
        TrendingPost(id: 1, author: RailPerson(username: 'ana'), snippet: 'oi mundo', likes: 3, comments: 2),
      ];
    await _pump(tester, RailTrendingWidget(service: s));
    expect(find.text('@ana'), findsOneWidget);
    expect(find.text('oi mundo'), findsOneWidget);
    expect(find.text('♥ 3  ·  💬 2'), findsOneWidget);

    await _pump(tester, RailTrendingWidget(service: _FakeService()));
    expect(find.textContaining('Ainda não há posts em alta'), findsOneWidget);
  });

  testWidgets('falha de rede mostra "Tentar de novo" e o toque busca outra vez', (tester) async {
    final s = _FakeService()
      ..failFirst = 1
      ..trending = const [TrendingPost(id: 1, author: RailPerson(username: 'bia'), snippet: 'x')];
    await _pump(tester, RailTrendingWidget(service: s));
    expect(find.text('Não consegui carregar agora.'), findsOneWidget);
    await tester.tap(find.text('Tentar de novo'));
    await tester.pumpAndSettle();
    expect(find.text('@bia'), findsOneWidget);
    expect(s.calls, 2);
  });

  testWidgets('Notícias: título e fonte; o toque chama onOpen com a manchete', (tester) async {
    final s = _FakeService()..news = const [NewsHeadline(id: 7, title: 'Chuva forte', source: 'Folha')];
    NewsHeadline? opened;
    await _pump(
      tester,
      RailNewsWidget(service: s, news: NewsService(ApiClient()), onOpen: (a) async => opened = a),
    );
    expect(find.text('Folha'), findsOneWidget);
    await tester.tap(find.text('Chuva forte'));
    expect(opened?.id, 7);
  });

  NewsHeadline _n(int i) => NewsHeadline(id: i, title: 'Manchete $i', source: 'Fonte');

  testWidgets('Notícias: dispensar tira a manchete, repõe outra e guarda no aparelho', (tester) async {
    final s = _FakeService()..news = [for (var i = 1; i <= 6; i++) _n(i)];
    await _pump(tester, RailNewsWidget(service: s, news: NewsService(ApiClient())));
    expect(find.text('Manchete 4'), findsOneWidget);
    expect(find.text('Manchete 5'), findsNothing);
    expect(find.byKey(const Key('news-restore')), findsNothing);

    await tester.tap(find.byKey(const Key('news-dismiss-2')));
    await tester.pumpAndSettle();
    expect(find.text('Manchete 2'), findsNothing);
    expect(find.text('Manchete 5'), findsOneWidget); // reposta
    expect(s.newsLimits.last, 5); // pediu uma a mais
    expect(find.text('Mostrar as dispensadas (1)'), findsOneWidget);
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getStringList(kNewsDismissedKey), ['2']);
  });

  testWidgets('Notícias: dispensadas guardadas valem na abertura e "Mostrar as dispensadas" limpa', (tester) async {
    SharedPreferences.setMockInitialValues({kNewsDismissedKey: ['1', '3']});
    final s = _FakeService()..news = [for (var i = 1; i <= 8; i++) _n(i)];
    await _pump(tester, RailNewsWidget(service: s, news: NewsService(ApiClient())));
    expect(s.newsLimits.first, 6); // 4 + 2 dispensadas
    expect(find.text('Manchete 1'), findsNothing);
    expect(find.text('Manchete 3'), findsNothing);
    expect(find.text('Manchete 2'), findsOneWidget);
    expect(find.text('Manchete 6'), findsOneWidget);

    await tester.tap(find.byKey(const Key('news-restore')));
    await tester.pumpAndSettle();
    expect(find.text('Manchete 1'), findsOneWidget);
    expect(find.byKey(const Key('news-restore')), findsNothing);
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getStringList(kNewsDismissedKey), isEmpty);
  });

  testWidgets('Notícias: todas dispensadas mostra aviso com o link de restaurar', (tester) async {
    SharedPreferences.setMockInitialValues({kNewsDismissedKey: ['1']});
    final s = _FakeService()..news = [_n(1)];
    await _pump(tester, RailNewsWidget(service: s, news: NewsService(ApiClient())));
    expect(find.text('Você dispensou as manchetes de agora.'), findsOneWidget);
    expect(find.text('Mostrar as dispensadas (1)'), findsOneWidget);
  });

  testWidgets('Vortex: "Abrir o Vortex" só aparece com callback e chama o callback', (tester) async {
    final s = _FakeService()..vortex = const [VortexPreviewItem(id: 1, thumbUrl: 'http://x.invalid/a.png')];
    await _pump(tester, RailVortexWidget(service: s));
    expect(find.text('Abrir o Vortex'), findsNothing);

    var tapped = 0;
    await _pump(tester, RailVortexWidget(service: s, onOpenVortex: () => tapped++));
    await tester.tap(find.text('Abrir o Vortex'));
    expect(tapped, 1);
  });

  testWidgets('Online: contagem, plural, +N e o aviso de "escondido"', (tester) async {
    final s = _FakeService()
      ..online = const OnlineResult(count: 12, users: [RailPerson(username: 'a'), RailPerson(username: 'b')]);
    await _pump(tester, RailOnlineWidget(service: s));
    expect(find.text('12 pessoas online agora'), findsOneWidget);
    expect(find.text('+10 pessoas'), findsOneWidget);

    s.online = const OnlineResult(count: 1, users: [RailPerson(username: 'a')]);
    await _pump(tester, RailOnlineWidget(service: s));
    expect(find.text('1 pessoa online agora'), findsOneWidget);

    s.online = const OnlineResult(hidden: true);
    await _pump(tester, RailOnlineWidget(service: s));
    expect(find.textContaining('Você escondeu o seu'), findsOneWidget);

    s.online = const OnlineResult();
    await _pump(tester, RailOnlineWidget(service: s));
    expect(find.text('Ninguém online agora.'), findsOneWidget);
  });

  test('modelos aceitam JSON do servidor', () {
    final t = TrendingPost.fromJson({
      'id': 3,
      'author': {'username': 'cy', 'display_name': 'Cy', 'avatar_url': null},
      'snippet': 's',
      'likes': 4,
      'comments': 1,
    });
    expect(t.author.username, 'cy');
    expect(t.likes, 4);
    final o = OnlineResult.fromJson({'hidden': false, 'count': 2, 'users': [{'username': 'u'}]});
    expect(o.users.single.username, 'u');
  });
}
