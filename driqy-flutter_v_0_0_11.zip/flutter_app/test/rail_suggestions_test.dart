import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/models/user.dart';
import 'package:driqy_flutter/services/api_client.dart';
import 'package:driqy_flutter/services/user_service.dart';
import 'package:driqy_flutter/services/widgets_service.dart';
import 'package:driqy_flutter/widgets/rail/rail_suggestions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

SuggestedUser _s(String name, {String reason = 'Segue você'}) => SuggestedUser(
      user: DriqyUser(
        id: name.hashCode,
        username: name,
        displayName: name.toUpperCase(),
        bio: '',
        location: '',
        accentColor: 'amber',
        avatarUrl: null,
        coverUrl: null,
        badgeKind: null,
        followersCount: 0,
        followingCount: 0,
        isFollowing: false,
        isMe: false,
      ),
      reason: reason,
    );

class _FakeWidgets extends WidgetsService {
  final List<List<String>> excludes = [];
  final List<SuggestedUser> pool;
  int firstCalls = 0;

  _FakeWidgets(this.pool) : super(ApiClient());

  @override
  Future<List<SuggestedUser>> getSuggestions({int limit = 5, List<String> exclude = const []}) async {
    excludes.add(exclude);
    final fresh = pool.where((p) => !exclude.contains(p.user.username)).take(limit).toList();
    firstCalls++;
    return fresh;
  }
}

class _FakeUsers extends UserService {
  final List<String> followed = [];
  final List<String> unfollowed = [];
  bool fail = false;
  bool failUnfollow = false;

  _FakeUsers() : super(ApiClient());

  @override
  Future<bool> follow(String username) async {
    if (fail) throw Exception('rede');
    followed.add(username);
    return true;
  }

  @override
  Future<bool> unfollow(String username) async {
    if (failUnfollow) throw Exception('rede');
    unfollowed.add(username);
    return false;
  }
}

Future<void> _pump(WidgetTester tester, Widget w) async {
  await tester.pumpWidget(MaterialApp(home: Scaffold(body: SingleChildScrollView(child: SizedBox(width: 300, child: w)))));
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('mostra 4 pessoas com o motivo e vazio tem mensagem', (tester) async {
    final w = _FakeWidgets([for (final n in ['a', 'b', 'c', 'd', 'e']) _s(n)]);
    await _pump(tester, RailSuggestions(service: w, users: _FakeUsers()));
    expect(find.text('@a'), findsOneWidget);
    expect(find.text('@d'), findsOneWidget);
    expect(find.text('@e'), findsNothing);
    expect(find.text('Segue você'), findsNWidgets(4));

    await _pump(tester, RailSuggestions(service: _FakeWidgets([]), users: _FakeUsers()));
    expect(find.text('Sem sugestões por enquanto.'), findsOneWidget);
  });

  testWidgets('seguir: mostra Seguindo + Desfazer e, passada a janela, a linha some e entra outra', (tester) async {
    final w = _FakeWidgets([for (final n in ['a', 'b', 'c', 'd', 'e']) _s(n)]);
    final u = _FakeUsers();
    await _pump(tester, RailSuggestions(service: w, users: u));
    await tester.tap(find.byKey(const Key('suggest-follow-a')));
    await tester.pumpAndSettle();
    expect(u.followed, ['a']);
    // dentro da janela: a linha continua, com Seguindo e Desfazer, e ninguém foi reposto ainda
    expect(find.text('@a'), findsOneWidget);
    expect(find.text('Seguindo'), findsOneWidget);
    expect(find.byKey(const Key('suggest-undo-a')), findsOneWidget);
    expect(find.byKey(const Key('suggest-follow-a')), findsNothing);
    expect(find.text('@e'), findsNothing);
    await tester.pump(kSuggestUndoWindow + const Duration(milliseconds: 100));
    await tester.pumpAndSettle();
    expect(find.text('@a'), findsNothing);
    expect(find.text('@e'), findsOneWidget);
    expect(w.excludes.last, containsAll(['a', 'b', 'c', 'd']));
  });

  testWidgets('Desfazer: deixa de seguir, volta o botão Seguir e a linha não é trocada', (tester) async {
    final w = _FakeWidgets([for (final n in ['a', 'b', 'c', 'd', 'e']) _s(n)]);
    final u = _FakeUsers();
    await _pump(tester, RailSuggestions(service: w, users: u));
    await tester.tap(find.byKey(const Key('suggest-follow-a')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('suggest-undo-a')));
    await tester.pumpAndSettle();
    expect(u.unfollowed, ['a']);
    expect(find.byKey(const Key('suggest-follow-a')), findsOneWidget);
    expect(find.text('Seguindo'), findsNothing);
    await tester.pump(kSuggestUndoWindow * 2);
    await tester.pumpAndSettle();
    expect(find.text('@a'), findsOneWidget);
    expect(find.text('@e'), findsNothing);
  });

  testWidgets('Desfazer falhou: continua seguindo, aparece aviso e a janela reabre', (tester) async {
    final w = _FakeWidgets([for (final n in ['a', 'b', 'c', 'd', 'e']) _s(n)]);
    final u = _FakeUsers();
    await _pump(tester, RailSuggestions(service: w, users: u));
    await tester.tap(find.byKey(const Key('suggest-follow-a')));
    await tester.pumpAndSettle();
    u.failUnfollow = true;
    await tester.tap(find.byKey(const Key('suggest-undo-a')));
    await tester.pumpAndSettle();
    expect(find.textContaining('Não consegui desfazer'), findsOneWidget);
    expect(find.byKey(const Key('suggest-undo-a')), findsOneWidget);
    expect(find.text('@a'), findsOneWidget);
    await tester.pump(kSuggestUndoWindow + const Duration(milliseconds: 100));
    await tester.pumpAndSettle();
    expect(find.text('@a'), findsNothing); // sem desfazer, passada a janela, a linha é trocada
    expect(find.text('@e'), findsOneWidget);
  });

  testWidgets('seguir falhou: a linha continua e aparece um aviso', (tester) async {
    final w = _FakeWidgets([_s('a'), _s('b')]);
    final u = _FakeUsers()..fail = true;
    await _pump(tester, RailSuggestions(service: w, users: u));
    await tester.tap(find.byKey(const Key('suggest-follow-a')));
    await tester.pumpAndSettle();
    expect(find.text('@a'), findsOneWidget);
    expect(find.textContaining('Não consegui seguir'), findsOneWidget);
  });
}
