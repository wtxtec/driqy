import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/widgets/rail/rail_panel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

List<RailWidgetSpec> _specs() => [
      for (final id in ['a', 'b', 'c'])
        RailWidgetSpec(id: id, title: 'W-$id', builder: (_) => Text('corpo-$id')),
    ];

/// Painel com o lápis ligado. [saved] guarda o que o painel mandou salvar; [ok] simula o servidor.
Future<void> _pump(WidgetTester t, RailPrefs prefs, List<RailPrefs> saved, {bool ok = true}) async {
  await t.pumpWidget(MaterialApp(
    home: Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: SizedBox(
            width: 320,
            child: KeyedSubtree(
              key: UniqueKey(),
              child: RailPanel(
                specs: _specs(),
                prefs: prefs,
                onSavePrefs: (next) async {
                  saved.add(next);
                  return ok;
                },
              ),
            ),
          ),
        ),
      ),
    ),
  ));
  await t.pumpAndSettle();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('sem onSavePrefs não há lápis', (t) async {
    await t.pumpWidget(MaterialApp(home: Scaffold(body: RailPanel(specs: _specs()))));
    await t.pumpAndSettle();
    expect(find.byKey(const Key('rail-edit')), findsNothing);
  });

  testWidgets('o lápis abre o editor e Cancelar descarta', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['a', 'b', 'c']), saved);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    expect(find.text('Editar widgets'), findsOneWidget);
    expect(find.text('NO PAINEL (3)'), findsOneWidget);
    await t.tap(find.byKey(const Key('rail-ed-remove-a')));
    await t.pumpAndSettle();
    expect(find.text('NO PAINEL (2)'), findsOneWidget);
    expect(find.text('DISPONÍVEIS'), findsOneWidget);
    await t.tap(find.byKey(const Key('rail-ed-cancel')));
    await t.pumpAndSettle();
    expect(saved, isEmpty);
    expect(find.text('W-a'), findsOneWidget); // o painel voltou ao que era
  });

  testWidgets('remover, subir e Concluir salvam ordem e removidos', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['a', 'b', 'c'], suggest: false), saved);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-remove-b')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-up-c')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(saved.length, 1);
    expect(saved.first.order, ['c', 'a', 'b']);
    expect(saved.first.disabled, ['b']);
    expect(saved.first.suggest, isFalse); // o resto das preferências não muda
    expect(find.text('W-a'), findsOneWidget); // continua no widget que estava aberto (a), agora na 2ª posição
    expect(find.byKey(const Key('rail-dot-1')), findsOneWidget);
    expect(find.byKey(const Key('rail-dot-2')), findsNothing); // só 2 ativos
  });

  testWidgets('adicionar de volta um removido', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['a', 'b', 'c'], disabled: ['c']), saved);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-add-c')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(saved.single.disabled, isEmpty);
    expect(saved.single.order, ['a', 'b', 'c']);
  });

  testWidgets('sem mudança, Concluir não chama o servidor', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['a', 'b', 'c']), saved);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(saved, isEmpty);
    expect(find.text('Editar widgets'), findsNothing);
  });

  testWidgets('falha ao salvar mantém o editor com aviso', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['a', 'b', 'c']), saved, ok: false);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-remove-a')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(find.text('Não foi possível salvar agora. Tente de novo.'), findsOneWidget);
    expect(find.text('Editar widgets'), findsOneWidget);
  });

  testWidgets('removendo tudo, o cartão fica com o lápis para voltar', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['a', 'b', 'c'], disabled: ['a', 'b', 'c']), saved);
    expect(find.text('Nenhum widget no painel. Use o lápis para adicionar.'), findsOneWidget);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    expect(find.text('DISPONÍVEIS'), findsOneWidget);
    await t.tap(find.byKey(const Key('rail-ed-add-b')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(saved.single.disabled, ['a', 'c']);
    expect(find.text('W-b'), findsOneWidget);
  });

  testWidgets('ids que o app não desenha ainda são preservados ao salvar', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['clock', 'a', 'b', 'c', 'custom:7'], disabled: ['clock']), saved);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    expect(find.text('clock'), findsNothing); // nem aparece no editor
    await t.tap(find.byKey(const Key('rail-ed-remove-a')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(saved.single.order, ['b', 'c', 'a', 'clock', 'custom:7']);
    expect(saved.single.disabled, ['a', 'clock']);
  });

  testWidgets('Restaurar volta tudo ao padrão (ainda precisa Concluir)', (t) async {
    final saved = <RailPrefs>[];
    await _pump(t, const RailPrefs(order: ['c', 'b', 'a'], disabled: ['b']), saved);
    await t.tap(find.byKey(const Key('rail-edit')));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const Key('rail-ed-reset')));
    await t.pumpAndSettle();
    expect(find.text('NO PAINEL (3)'), findsOneWidget);
    expect(saved, isEmpty);
    await t.tap(find.byKey(const Key('rail-ed-done')));
    await t.pumpAndSettle();
    expect(saved.single.order, ['a', 'b', 'c']);
    expect(saved.single.disabled, isEmpty);
  });
}
