import 'package:driqy_flutter/theme/vortex_theme.dart';
import 'package:driqy_flutter/widgets/vortex_tile_actions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Lê as cores do Vortex dentro de um `Theme` simples (sem GoogleFonts, que
/// tentaria baixar fontes no teste).
Future<VortexColors> _colorsFor(WidgetTester tester, ThemeData theme) async {
  late VortexColors result;
  await tester.pumpWidget(MaterialApp(
    theme: theme,
    home: Builder(builder: (context) {
      result = VortexColors.of(context);
      return const SizedBox();
    }),
  ));
  return result;
}

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    // o controlador é um singleton: volta ao padrão antes de cada teste
    VortexThemeController.instance.setBrightness(Brightness.dark);
  });

  test('Vortex: fundo escuro é escuro e fundo claro é claro', () {
    expect(VortexColors.dark.bg.computeLuminance(), lessThan(0.1));
    expect(VortexColors.light.bg.computeLuminance(), greaterThan(0.8));
    expect(VortexColors.dark.bg, isNot(VortexColors.light.bg));
    // texto legível nos dois: o texto é o oposto do fundo
    expect(VortexColors.dark.text.computeLuminance(), greaterThan(VortexColors.dark.bg.computeLuminance()));
    expect(VortexColors.light.text.computeLuminance(), lessThan(VortexColors.light.bg.computeLuminance()));
  });

  testWidgets('Vortex: VortexColors.of acompanha o brilho do tema', (tester) async {
    expect(await _colorsFor(tester, ThemeData.dark()), same(VortexColors.dark));
    expect(await _colorsFor(tester, ThemeData.light()), same(VortexColors.light));
  });

  test('Vortex: controlador troca e salva o tema (mesma chave do site)', () async {
    final c = VortexThemeController.instance;
    await c.setBrightness(Brightness.dark);
    expect(c.isLight, isFalse);

    await c.toggle();
    expect(c.isLight, isTrue);
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getString('driqy-theme'), 'light');

    await c.toggle();
    expect(c.isLight, isFalse);
    expect(prefs.getString('driqy-theme'), 'dark');
  });

  test('Vortex: load lê o tema salvo e ignora valor estranho', () async {
    final c = VortexThemeController.instance;

    SharedPreferences.setMockInitialValues({'driqy-theme': 'light'});
    await c.load();
    expect(c.isLight, isTrue);

    SharedPreferences.setMockInitialValues({'driqy-theme': 'qualquer-coisa'});
    await c.load();
    expect(c.isLight, isFalse);
  });

  testWidgets('Vortex: botão sol/lua alterna o tema', (tester) async {
    final c = VortexThemeController.instance;
    await tester.pumpWidget(const MaterialApp(home: Scaffold(body: VortexThemeButton())));
    expect(c.isLight, isFalse);
    expect(find.byIcon(Icons.light_mode_outlined), findsOneWidget);

    await tester.tap(find.byType(IconButton));
    await tester.pump();
    expect(c.isLight, isTrue);
    expect(find.byIcon(Icons.dark_mode_outlined), findsOneWidget);
  });

  test('Vortex: reações começam vazias e são independentes por tela', () {
    final a = VortexTileReactions();
    final b = VortexTileReactions();
    a.liked.add('c1');
    a.hidden.add('c2');
    expect(b.liked, isEmpty);
    expect(b.hidden, isEmpty);
  });
}
