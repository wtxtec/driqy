import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/widgets/rail/rail_panel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

List<RailWidgetSpec> _specs() => [
      for (final id in ['weather', 'trending', 'news'])
        RailWidgetSpec(id: id, title: 'W-$id', builder: (_) => Text('corpo-$id')),
    ];

Future<void> _pump(WidgetTester t, RailPrefs? prefs) async {
  await t.pumpWidget(MaterialApp(
    home: Scaffold(body: SingleChildScrollView(child: RailPanel(specs: _specs(), prefs: prefs))),
  ));
  await t.pumpAndSettle();
}

void main() {
  test('RailPrefs.fromJson completa a ordem e respeita os removidos', () {
    final p = RailPrefs.fromJson({
      'order': ['news', 'weather'],
      'disabled': ['weather'],
      'suggest': false,
      'rail_hidden': true,
    });
    expect(p.order.first, 'news');
    expect(p.order.toSet(), kRailWidgetIds.toSet());
    expect(p.visibleIds.contains('weather'), isFalse);
    expect(p.suggest, isFalse);
    expect(p.railHidden, isTrue);
    expect(RailPrefs.fromJson(p.toJson()), p);
  });

  testWidgets('a ordem das preferências decide o primeiro widget', (t) async {
    await _pump(t, const RailPrefs(order: ['news', 'weather', 'trending', 'vortex', 'online']));
    expect(find.text('W-news'), findsOneWidget);
    expect(find.text('corpo-news'), findsOneWidget);
  });

  testWidgets('widgets removidos somem do painel', (t) async {
    await _pump(t, const RailPrefs(disabled: ['weather']));
    expect(find.text('W-weather'), findsNothing);
    expect(find.text('W-trending'), findsOneWidget);
  });

  testWidgets('sem sugestões e sem widgets: o painel fica vazio', (t) async {
    await _pump(t, const RailPrefs(disabled: ['weather', 'trending', 'news'], suggest: false));
    expect(find.text('Sugestões para você'), findsNothing);
    expect(find.textContaining('W-'), findsNothing);
  });

  testWidgets('sugestões acima dos widgets', (t) async {
    await _pump(t, const RailPrefs(suggestFirst: true));
    final sug = t.getTopLeft(find.text('Sugestões para você')).dy;
    final wid = t.getTopLeft(find.text('W-weather')).dy;
    expect(sug < wid, isTrue);
  });
}
