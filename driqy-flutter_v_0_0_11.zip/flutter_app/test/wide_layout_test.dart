import 'package:driqy_flutter/widgets/wide_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

final List<bool> _seen = [];

class _Probe extends StatelessWidget {
  const _Probe();

  @override
  Widget build(BuildContext context) {
    _seen.add(WideShell.of(context));
    return const SizedBox();
  }
}

void main() {
  test('pontos de corte e larguras iguais aos do site', () {
    expect(kMenuBoxBreakpoint, 901);
    expect(kRailBreakpoint, 1200);
    expect(kMenuBoxWidth, 260);
    expect(kRailWidth, 320);
    expect(kBoxRadius, 22);
  });

  test('menuBoxFits: caixa do menu a partir de 901', () {
    expect(menuBoxFits(900), isFalse);
    expect(menuBoxFits(901), isTrue);
    expect(menuBoxFits(1440), isTrue);
    expect(menuBoxFits(390), isFalse);
  });

  test('railFits: painel direito só na Home (aba Feed) e a partir de 1200', () {
    expect(railFits(1199, tabIndex: kFeedTabIndex), isFalse);
    expect(railFits(1200, tabIndex: kFeedTabIndex), isTrue);
    expect(railFits(1600, tabIndex: kFeedTabIndex), isTrue);
    expect(railFits(1600, tabIndex: kVortexTabIndex), isFalse);
    expect(railFits(1600, tabIndex: 2), isFalse); // Notificações
  });

  testWidgets('WideShell.of: false fora, e avisa quem depende quando muda', (tester) async {
    _seen.clear();
    await tester.pumpWidget(const Directionality(textDirection: TextDirection.ltr, child: _Probe()));
    expect(_seen.last, isFalse); // fora da HomeShell

    _seen.clear();
    await tester.pumpWidget(const Directionality(
      textDirection: TextDirection.ltr,
      child: WideShell(menuBox: false, child: _Probe()),
    ));
    expect(_seen.last, isFalse);

    _seen.clear();
    await tester.pumpWidget(const Directionality(
      textDirection: TextDirection.ltr,
      child: WideShell(menuBox: true, child: _Probe()),
    ));
    // o filho é o mesmo `const`: só reconstrói porque o WideShell avisou a mudança
    expect(_seen, [true]);
  });
}
