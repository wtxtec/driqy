import 'package:driqy_flutter/widgets/driqy_ring.dart';
import 'package:driqy_flutter/widgets/brand_title.dart';
import 'package:driqy_flutter/widgets/ping_tab_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _app(Widget child, {bool reduceMotion = false}) => MaterialApp(
      builder: (context, c) => MediaQuery(
        data: MediaQuery.of(context).copyWith(disableAnimations: reduceMotion),
        child: c!,
      ),
      home: Scaffold(body: Center(child: child)),
    );

void main() {
  testWidgets('BrandRing é estático (não gira)', (tester) async {
    await tester.pumpWidget(_app(const BrandRing()));
    expect(find.byType(RotationTransition), findsNothing);
    expect(find.byType(DriqyRing), findsOneWidget);
  });

  testWidgets('aba Chats anuncia as nao lidas num unico rotulo (fase 10)', (tester) async {
    final handle = tester.ensureSemantics();
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        bottomNavigationBar: PingTabBar(
          unread: 3,
          onContacts: () {},
          onCalls: () {},
          onMenu: () {},
        ),
      ),
    ));
    expect(find.bySemanticsLabel('Chats, 3 não lidas'), findsOneWidget);
    handle.dispose();
  });
}
