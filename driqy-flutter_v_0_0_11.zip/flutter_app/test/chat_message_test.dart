import 'package:driqy_flutter/models/call.dart';
import 'package:driqy_flutter/models/conversation.dart';
import 'package:driqy_flutter/models/message.dart';
import 'package:driqy_flutter/models/presence.dart';
import 'package:driqy_flutter/services/call_manager.dart';
import 'package:driqy_flutter/services/chat_live.dart';
import 'package:driqy_flutter/widgets/chat/chat_format.dart';
import 'package:driqy_flutter/widgets/chat/file_message.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:driqy_flutter/services/api_exception.dart';

void main() {
  audioTests();
  videoTests();
  actionsTests();
  phase8Tests();
  phase9Tests();
  phase10Tests();
  phase12Tests();
  phase13Tests();
  phase14Tests();
  phase15Tests();
  test('fromJson aceita resposta antiga (só content)', () {
    final m = DriqyMessage.fromJson({
      'id': 1,
      'content': 'oi',
      'sender_id': 2,
      'recipient_id': 3,
      'created_at': '2026-10-16T10:00:00Z',
      'mine': true,
    });
    expect(m.type, MessageType.text);
    expect(m.previewText, 'oi');
    expect(m.deleted, false);
    expect(m.localState, isNull);
  });

  test('previewText de mídia e apagada', () {
    final base = {
      'id': 2,
      'content': '📷 Foto',
      'sender_id': 2,
      'created_at': '2026-10-16T10:00:00Z',
      'msg_type': 'image',
    };
    expect(DriqyMessage.fromJson(base).previewText, '📷 Foto');
    expect(DriqyMessage.fromJson({...base, 'caption': 'olha'}).previewText, '📷 Foto olha');
    expect(DriqyMessage.fromJson({...base, 'deleted': true}).previewText, 'Mensagem apagada');
  });

  test('clientId cabe no limite do servidor e é único', () {
    final a = DriqyMessage.newClientId();
    final b = DriqyMessage.newClientId();
    expect(a.length <= 40, true);
    expect(a == b, false);
  });

  test('chatListTime: hoje, ontem e data', () {
    final now = DateTime(2026, 10, 16, 12, 0);
    expect(chatListTime(DateTime(2026, 10, 15, 15, 0).toUtc(), now: now), 'Ontem');
    expect(chatDayLabel(now.toUtc(), now: now), 'Hoje');
  });

  test('emojiOnlyCount', () {
    expect(emojiOnlyCount('😂'), 1);
    expect(emojiOnlyCount('😂😂😂'), 3);
    expect(emojiOnlyCount('😂 ❤️'), 2);
    expect(emojiOnlyCount('👨\u200D👩\u200D👧'), 1); // família = 1
    expect(emojiOnlyCount('👍🏽'), 1); // tom de pele = 1
    expect(emojiOnlyCount('🇧🇷'), 1); // bandeira = 1
    expect(emojiOnlyCount('oi 😂'), isNull);
    expect(emojiOnlyCount('123'), isNull);
    expect(emojiOnlyCount('   '), isNull);
  });

  test('applyMyReaction: adiciona, troca e remove', () {
    const base = [DriqyReaction(emoji: '👍', count: 2, mine: false)];
    final a = applyMyReaction(base, '👍');
    expect(a.single.count, 3);
    expect(a.single.mine, true);
    final b = applyMyReaction(a, '❤️');
    expect(b.firstWhere((r) => r.emoji == '👍').count, 2);
    expect(b.firstWhere((r) => r.emoji == '❤️').mine, true);
    final c = applyMyReaction(b, null);
    expect(c.any((r) => r.mine), false);
  });
  test('localImage: rótulo, legenda e estado local', () {
    final m = DriqyMessage.localImage(clientId: 'c1', path: '/tmp/a.png');
    expect(m.type, MessageType.image);
    expect(m.id, lessThan(0));
    expect(m.localState, MessageLocalState.sending);
    expect(m.caption, isNull);
    expect(m.previewText, '📷 Foto');
    final c = DriqyMessage.localImage(clientId: 'c2', path: '/tmp/b.gif', caption: 'olha', width: 10, height: 20);
    expect(c.caption, 'olha');
    expect(c.previewText, '📷 Foto olha');
    expect(c.mediaWidth, 10);
    expect(c.isGif, true); // pela extensão (mensagem local)
  });

  test('copyWith preserva localPath (reenvio de imagem que falhou)', () {
    final m = DriqyMessage.localImage(clientId: 'c3', path: '/tmp/c.jpg');
    final failed = m.copyWith(localState: MessageLocalState.failed);
    expect(failed.localPath, '/tmp/c.jpg');
    expect(failed.localState, MessageLocalState.failed);
  });

  test('isGif pelo MIME que o servidor devolve', () {
    final m = DriqyMessage.fromJson({
      'id': 1,
      'content': '📷 Foto',
      'msg_type': 'image',
      'media_url': '/api/v1/messages/media/1',
      'media_mime': 'image/gif',
      'sender_id': 2,
      'created_at': '2026-10-21T10:00:00Z',
    });
    expect(m.isGif, true);
    expect(m.mediaUrl, '/api/v1/messages/media/1');
  });
}

// ---- Fase 5: áudio ----
void audioTests() {
  test('chatDuration formata m:ss', () {
    expect(chatDuration(0), '0:00');
    expect(chatDuration(4200), '0:04');
    expect(chatDuration(65000), '1:05');
    expect(chatDuration(754000), '12:34');
    expect(chatDuration(-5), '0:00');
  });

  test('localAudio: tipo, duração e estado de envio', () {
    final m = DriqyMessage.localAudio(clientId: 'abc', path: '/tmp/a.m4a', durationMs: 9000);
    expect(m.type, MessageType.audio);
    expect(m.mediaDurationMs, 9000);
    expect(m.localPath, '/tmp/a.m4a');
    expect(m.localState, MessageLocalState.sending);
    expect(m.id < 0, isTrue);
    expect(m.copyWith(localState: MessageLocalState.failed).localPath, '/tmp/a.m4a');
  });
}

// ---- Fase 6: vídeo ----
void videoTests() {
  test('localVideo: tipo, duração, legenda e estado de envio', () {
    final m = DriqyMessage.localVideo(
      clientId: 'v1',
      path: '/tmp/v.mp4',
      durationMs: 12000,
      caption: 'olha isso',
      width: 1280,
      height: 720,
    );
    expect(m.type, MessageType.video);
    expect(m.isMedia, isTrue);
    expect(m.mediaDurationMs, 12000);
    expect(m.caption, 'olha isso');
    expect(m.previewText, '🎥 Vídeo olha isso');
    expect(m.localState, MessageLocalState.sending);
    expect(m.copyWith(localState: MessageLocalState.failed).localPath, '/tmp/v.mp4');
  });

  test('fromJson lê media_thumb_url do vídeo', () {
    final m = DriqyMessage.fromJson({
      'id': 5,
      'content': '🎥 Vídeo',
      'msg_type': 'video',
      'media_url': '/api/v1/messages/media/5',
      'media_thumb_url': '/api/v1/messages/media/5/thumb',
      'media_duration_ms': 8000,
      'sender_id': 1,
      'created_at': '2026-10-21T12:00:00Z',
    });
    expect(m.type, MessageType.video);
    expect(m.mediaThumbUrl, '/api/v1/messages/media/5/thumb');
    expect(m.previewText, '🎥 Vídeo');
  });
}

// ---- Fase 7: responder / apagar ----
void actionsTests() {
  DriqyMessage base({String content = 'oi', String type = 'text', String? caption}) => DriqyMessage(
        id: 9,
        content: content,
        caption: caption,
        msgType: type,
        senderId: 3,
        recipientId: 4,
        createdAt: DateTime.utc(2026, 10, 21),
        mine: false,
      );

  test('DriqyReplyRef.fromMessage usa texto, rótulo de mídia e corta em 80', () {
    expect(DriqyReplyRef.fromMessage(base()).preview, 'oi');
    expect(DriqyReplyRef.fromMessage(base(type: 'video', content: '🎥 Vídeo')).preview, '🎥 Vídeo');
    final long = DriqyReplyRef.fromMessage(base(content: 'a' * 200));
    expect(long.preview.length, 80);
    expect(long.id, 9);
    expect(long.senderId, 3);
  });

  test('copyWith(replyTo:) define a resposta e preserva o resto', () {
    final m = DriqyMessage.local(clientId: 'c1', content: 'resposta');
    final r = m.copyWith(replyTo: DriqyReplyRef.fromMessage(base()));
    expect(r.replyTo?.id, 9);
    expect(r.content, 'resposta');
    expect(r.clientId, 'c1');
    expect(r.copyWith(localState: MessageLocalState.failed).replyTo?.id, 9);
  });

  test('fromJson lê can_delete_for_all e reply_to', () {
    final m = DriqyMessage.fromJson({
      'id': 12,
      'content': 'x',
      'sender_id': 1,
      'created_at': '2026-10-21T12:00:00Z',
      'can_delete_for_all': true,
      'reply_to': {'id': 9, 'sender_id': 3, 'msg_type': 'text', 'preview': 'oi'},
    });
    expect(m.canDeleteForAll, isTrue);
    expect(m.replyTo?.preview, 'oi');
    expect(m.copyWith(reactions: const []).canDeleteForAll, isTrue);
  });

  test('mensagem sem o campo novo: canDeleteForAll falso (servidor antigo)', () {
    final m = DriqyMessage.fromJson({
      'id': 1,
      'content': 'oi',
      'sender_id': 1,
      'created_at': '2026-10-21T12:00:00Z',
    });
    expect(m.canDeleteForAll, isFalse);
  });
}


void phase8Tests() {
  Map<String, dynamic> base(Map<String, dynamic> extra) => {
        'id': 9,
        'content': 'texto',
        'sender_id': 2,
        'recipient_id': 3,
        'created_at': '2026-10-21T10:00:00Z',
        'mine': true,
        ...extra,
      };

  test('fase 8: fromJson lê can_edit e forwarded (e servidor antigo = falso)', () {
    final novo = DriqyMessage.fromJson(base({'can_edit': true, 'forwarded': true}));
    expect(novo.canEdit, true);
    expect(novo.forwarded, true);
    final antigo = DriqyMessage.fromJson(base({}));
    expect(antigo.canEdit, false);
    expect(antigo.forwarded, false);
  });

  test('fase 8: copyWith preserva canEdit, forwarded e editedAt', () {
    final m = DriqyMessage.fromJson(
        base({'can_edit': true, 'forwarded': true, 'edited_at': '2026-10-21T10:05:00Z'}));
    final c = m.copyWith(reactions: const []);
    expect(c.canEdit, true);
    expect(c.forwarded, true);
    expect(c.editedAt, isNotNull);
  });

  test('fase 8: foldSearch tira acento e maiúsculas sem mudar o tamanho', () {
    expect(foldSearch('AÇÃO Reunião'), 'acao reuniao');
    const s = 'Ação urgente';
    expect(foldSearch(s).length, s.length);
  });

  test('fase 8: findSearchMatches acha sem acento, sem sobrepor, ignora termo curto', () {
    final r = findSearchMatches('Reunião amanhã, reuniao às 10', 'REUNIAO');
    expect(r.length, 2);
    expect(r.first.start, 0);
    expect(r.first.end, 7);
    expect(findSearchMatches('aaaa', 'aa').length, 2); // sem sobreposição
    expect(findSearchMatches('abc', 'a'), isEmpty);
    expect(findSearchMatches('abc', 'zz'), isEmpty);
  });
}


void phase9Tests() {
  test('fase 9: ChatEvent expõe partner/state/kind e tolera campos ausentes', () {
    const e = ChatEvent('typing', {'partner': 'ana', 'state': 'recording'});
    expect(e.type, 'typing');
    expect(e.partner, 'ana');
    expect(e.state, 'recording');
    expect(e.kind, isNull);
    const u = ChatEvent('update', {'partner': 'beto', 'id': 3, 'kind': 'edit'});
    expect(u.kind, 'edit');
    const r = ChatEvent('ready', {});
    expect(r.partner, isNull);
  });

  test('fase 9: ChatLive começa desconectado e release sem acquire não quebra', () {
    expect(ChatLive.instance.connected, false);
    ChatLive.instance.release();
    ChatLive.instance.reset();
    expect(ChatLive.instance.connected, false);
  });
}


void phase10Tests() {
  test('fase 10: DriqyPresence tolera servidor antigo e lê o horário em UTC', () {
    expect(DriqyPresence.fromJson(null).visible, false);
    final p = DriqyPresence.fromJson({'visible': true, 'online': false, 'last_seen_at': '2026-10-21T17:32:00Z'});
    expect(p.visible, true);
    expect(p.lastSeenAt!.isUtc, true);
    expect(DriqyPresence.fromJson({'visible': true, 'online': true}).lastSeenAt, isNull);
  });

  test('fase 10: presenceLabel (online, hoje, ontem, data, escondido)', () {
    final now = DateTime(2026, 10, 21, 20, 0);
    final fallback = '@ana';
    expect(presenceLabel(DriqyPresence.hidden, fallback, now: now), fallback);
    expect(presenceLabel(const DriqyPresence(visible: true, online: true), fallback, now: now), 'online');
    expect(presenceLabel(const DriqyPresence(visible: true), fallback, now: now), fallback); // sem horário
    String at(DateTime local) =>
        presenceLabel(DriqyPresence(visible: true, lastSeenAt: local.toUtc()), fallback, now: now);
    expect(at(DateTime(2026, 10, 21, 14, 32)), 'visto por último hoje às 14:32');
    expect(at(DateTime(2026, 10, 20, 9, 5)), 'visto por último ontem às 09:05');
    expect(at(DateTime(2026, 10, 3, 9, 5)), 'visto por último em 03/10/2026');
  });

  test('fase 10: DriqyChatPrefs e conversa leem prefs/presence (e aceitam resposta antiga)', () {
    expect(DriqyChatPrefs.fromJson(null).pinned, false);
    final c = DriqyConversation.fromJson({
      'partner': {
        'id': 2,
        'username': 'beto',
        'display_name': 'Beto',
        'created_at': '2026-10-01T10:00:00Z',
        'presence': {'visible': true, 'online': true, 'last_seen_at': null},
      },
      'last_message': null,
      'unread': 2,
      'prefs': {'pinned': true, 'muted': true, 'archived': false},
    });
    expect(c.prefs.pinned, true);
    expect(c.prefs.muted, true);
    expect(c.presence.online, true);
    final old = DriqyConversation.fromJson({
      'partner': {'id': 3, 'username': 'caio', 'display_name': 'Caio', 'created_at': '2026-10-01T10:00:00Z'},
      'unread': 0,
    });
    expect(old.prefs.pinned, false);
    expect(old.presence.visible, false);
    expect(c.prefs.copyWith(archived: true).archived, true);
  });

  test('fase 10: ChatEvent de presença', () {
    const e = ChatEvent('presence', {'partner': 'ana', 'visible': true, 'online': true, 'last_seen_at': null});
    expect(e.visible, true);
    expect(e.online, true);
    expect(e.lastSeenAt, isNull);
    const off = ChatEvent('presence', {'partner': 'ana'});
    expect(off.visible, false);
    expect(off.online, false);
  });

  test('fase 11: DriqyCall.fromJson (viva, com SDP e ICE)', () {
    final c = DriqyCall.fromJson({
      'id': 7,
      'media': 'video',
      'state': 'ringing',
      'direction': 'incoming',
      'partner': {'id': 2, 'username': 'ana', 'display_name': 'Ana', 'created_at': '2026-10-01T10:00:00Z'},
      'created_at': '2026-10-22T10:00:00Z',
      'duration_s': 0,
      'ring_seconds': 45,
      'offer': {'type': 'offer', 'sdp': 'v=0'},
      'ice': [
        {'candidate': 'c1', 'sdpMid': '0'}
      ],
    });
    expect(c.id, 7);
    expect(c.isVideo, true);
    expect(c.outgoing, false);
    expect(c.isActive, true);
    expect(c.offerSdp, 'v=0');
    expect(c.answerSdp, isNull);
    expect(c.ice.single['candidate'], 'c1');
    expect(c.partner.username, 'ana');
  });

  test('fase 11: estados, encerrada e estado desconhecido', () {
    expect(parseCallState('missed'), CallState.missed);
    expect(parseCallState('busy'), CallState.busy);
    expect(parseCallState('algo-novo'), CallState.unknown);
    final c = DriqyCall.fromJson({
      'id': 1,
      'media': 'voice',
      'state': 'ended',
      'end_reason': 'hangup',
      'direction': 'outgoing',
      'partner': {'id': 2, 'username': 'ana', 'display_name': 'Ana', 'created_at': '2026-10-01T10:00:00Z'},
      'duration_s': 65,
    });
    expect(c.isActive, false);
    expect(c.outgoing, true);
    expect(c.durationS, 65);
    expect(c.ice, isEmpty);
  });

  test('fase 11: CallConfig (STUN+TURN) e ChatEvent de chamada', () {
    final cfg = CallConfig.fromJson({
      'enabled': true,
      'turn_configured': true,
      'ice_servers': [
        {'urls': ['stun:a:3478']},
        {'urls': ['turn:b:3478'], 'username': '1:2', 'credential': 'x'},
      ],
    });
    expect(cfg.iceServers.length, 2);
    expect(cfg.iceServers[1].username, '1:2');
    expect(cfg.iceServers[1].toMap()['credential'], 'x');
    expect(cfg.pingSeconds, 20);
    expect(const CallConfig().turnConfigured, false);

    const e = ChatEvent('call_incoming', {
      'call_id': 9,
      'partner': 'ana',
      'media': 'voice',
      'offer': {'type': 'offer', 'sdp': 'v=0'},
    });
    expect(e.isCallEvent, true);
    expect(e.callId, 9);
    expect(e.media, 'voice');
    expect(e.offer!['sdp'], 'v=0');
    expect(const ChatEvent('typing', {}).isCallEvent, false);
  });
}

void phase12Tests() {
  test('fase 12: rótulo do tempo de chamada', () {
    expect(callElapsedLabel(0), '0:00');
    expect(callElapsedLabel(7), '0:07');
    expect(callElapsedLabel(725), '12:05');
    expect(callElapsedLabel(3723), '1:02:03');
    expect(callElapsedLabel(-5), '0:00');
  });

  test('fase 12: mensagem de fim de chamada', () {
    expect(callEndMessage(CallState.declined, null, outgoing: true), 'Chamada recusada.');
    expect(callEndMessage(CallState.missed, 'timeout', outgoing: true), 'Sem resposta.');
    expect(callEndMessage(CallState.missed, 'timeout', outgoing: false), 'Chamada perdida.');
    expect(callEndMessage(CallState.busy, null, outgoing: true), 'Ocupado.');
    expect(callEndMessage(CallState.failed, 'error', outgoing: true), 'A chamada falhou.');
    expect(callEndMessage(CallState.ended, 'stale', outgoing: false), 'Chamada encerrada (sem sinal).');
    expect(callEndMessage(CallState.ended, 'hangup', outgoing: false), 'Chamada encerrada.');
  });

  test('fase 12: ApiException guarda o código (busy / already_in_call)', () {
    final e = ApiException(409, 'Ocupado', code: 'busy');
    expect(e.code, 'busy');
    expect(e.statusCode, 409);
    expect(ApiException(400, 'x').code, isNull);
  });
}

void phase13Tests() {
  test('fase 13: chamada de vídeo é lida do JSON e voz é o padrão', () {
    final base = {
      'id': 7,
      'state': 'ringing',
      'direction': 'incoming',
      'created_at': '2026-10-22T12:00:00Z',
      'partner': {'id': 2, 'username': 'ana', 'display_name': 'Ana'},
    };
    expect(DriqyCall.fromJson({...base, 'media': 'video'}).isVideo, true);
    expect(DriqyCall.fromJson({...base, 'media': 'voice'}).isVideo, false);
    expect(DriqyCall.fromJson(base).isVideo, false);
  });

  test('fase 13: sem sessão, o gerenciador não está em vídeo nem ocupado', () {
    final m = CallManager.instance;
    expect(m.isVideo, false);
    expect(m.busy, false);
    expect(m.remoteVideo, false);
    expect(m.hasLocalVideo, false);
  });
}

void phase14Tests() {
  test('fase 14: mensagem de chamada é lida do JSON (tipo, mime e duração)', () {
    final m = DriqyMessage.fromJson({
      'id': 9,
      'content': '📞 Chamada de voz · 3:12',
      'msg_type': 'call',
      'media_mime': 'call/voice/ended',
      'media_duration_ms': 192000,
      'sender_id': 1,
      'recipient_id': 2,
      'created_at': '2026-10-22T12:00:00Z',
      'mine': true,
    });
    expect(m.type, MessageType.call);
    expect(m.mediaMime, 'call/voice/ended');
    expect(m.mediaDurationMs, 192000);
    expect(chatDuration(m.mediaDurationMs!), '3:12');
    expect(m.isMedia, false);
  });
}

void phase15Tests() {
  Map<String, dynamic> fileJson({String? name, String content = '📎 Arquivo', String? caption}) => {
        'id': 21,
        'content': content,
        'caption': caption,
        'msg_type': 'file',
        'media_url': '/api/v1/messages/media/21',
        'media_mime': 'application/pdf',
        'media_size': 84213,
        'media_name': name,
        'sender_id': 1,
        'recipient_id': 2,
        'created_at': '2026-10-22T12:00:00Z',
        'mine': false,
      };

  test('fase 15: documento lê nome e tamanho do JSON e mostra o nome na prévia', () {
    final m = DriqyMessage.fromJson(fileJson(name: 'Relatório final.pdf'));
    expect(m.type, MessageType.file);
    expect(m.isMedia, true);
    expect(m.mediaName, 'Relatório final.pdf');
    expect(m.previewText, '📎 Relatório final.pdf');
    expect(m.copyWith().mediaName, 'Relatório final.pdf');
  });

  test('fase 15: legenda ganha do nome; servidor antigo (sem nome) cai no rótulo', () {
    final c = DriqyMessage.fromJson(fileJson(name: 'a.pdf', content: 'segue', caption: 'segue'));
    expect(c.previewText, '📎 segue');
    final old = DriqyMessage.fromJson(fileJson());
    expect(old.mediaName, null);
    expect(old.previewText, '📎 Arquivo');
  });

  test('fase 15: localFile nasce enviando, com arquivo local e legenda opcional', () {
    final m = DriqyMessage.localFile(
      clientId: 'abc', path: '/tmp/x.docx', name: 'x.docx', size: 2048, caption: 'olha',
    );
    expect(m.type, MessageType.file);
    expect(m.localState, MessageLocalState.sending);
    expect(m.localPath, '/tmp/x.docx');
    expect(m.mediaName, 'x.docx');
    expect(m.caption, 'olha');
    expect(m.copyWith(localState: MessageLocalState.failed).mediaName, 'x.docx');
    final nocap = DriqyMessage.localFile(clientId: 'b', path: '/tmp/y.pdf', name: 'y.pdf');
    expect(nocap.caption, null);
    expect(nocap.content, '📎 Arquivo');
  });

  test('fase 15: extensão, tamanho legível e ícone por tipo', () {
    expect(fileExt('Relatório.Final.PDF'), 'pdf');
    expect(fileExt('semext'), '');
    expect(fileExt('.oculto'), '');
    expect(fileSizeLabel(512), '512 B');
    expect(fileSizeLabel(84213), '82 KB');
    expect(fileSizeLabel(2400000), '2,3 MB');
    expect(fileSizeLabel(null), '');
    expect(fileIconFor('pdf').tag, 'PDF');
    expect(fileIconFor('xlsx').tag, 'XLS');
    expect(fileIconFor('pptx').tag, 'PPT');
    expect(fileIconFor('zip').tag, 'ZIP');
    expect(fileIconFor('xyz').tag, 'XYZ');
    expect(fileIconFor('').tag, 'ARQ');
  });
}
