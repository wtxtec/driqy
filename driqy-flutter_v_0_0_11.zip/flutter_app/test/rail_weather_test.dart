import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_client.dart';
import 'package:driqy_flutter/services/widgets_service.dart';
import 'package:driqy_flutter/widgets/rail/weather_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// Serviço de mentira: devolve as respostas na ordem (a última se repete) e conta as chamadas.
class _FakeService extends WidgetsService {
  final List<WeatherResult> results;
  int calls = 0;

  _FakeService(this.results) : super(ApiClient());

  @override
  Future<WeatherResult> getWeather({PlaceSuggestion? region}) async {
    final r = results[calls < results.length ? calls : results.length - 1];
    calls++;
    return r;
  }
}

const _ok = WeatherResult(
  ok: true,
  location: 'Porto Alegre, RS',
  temperature: 18,
  feelsLike: 17,
  humidity: 82,
  windKmh: 14,
  tempMin: 12,
  tempMax: 24,
  rainChance: 40,
  condition: 'Parcialmente nublado',
  icon: 'sun-cloud',
);

Future<void> _pump(WidgetTester tester, Widget w) async {
  await tester.pumpWidget(MaterialApp(home: Scaffold(body: SingleChildScrollView(child: w))));
  await tester.pumpAndSettle();
}

void main() {
  group('WeatherResult.fromJson', () {
    test('sucesso: arredonda números e lê os campos', () {
      final r = WeatherResult.fromJson({
        'ok': true,
        'location': 'Vitória',
        'temperature': 27.6,
        'feels_like': 30,
        'humidity': 70,
        'wind_kmh': 9,
        'condition': 'Céu limpo',
        'icon': 'sun',
        'is_day': false,
        'temp_max': 31,
        'temp_min': 22,
        'rain_chance': null,
      });
      expect(r.ok, isTrue);
      expect(r.reason, isNull);
      expect(r.temperature, 28);
      expect(r.feelsLike, 30);
      expect(r.rainChance, isNull);
      expect(r.icon, 'sun');
      expect(r.isDay, isFalse);
    });

    test('falhas guardam o motivo (e o nome da cidade quando vem)', () {
      expect(WeatherResult.fromJson({'ok': false, 'reason': 'no_location'}).reason, 'no_location');
      final nf = WeatherResult.fromJson({'ok': false, 'reason': 'not_found', 'location': 'Xyzland'});
      expect(nf.reason, 'not_found');
      expect(nf.location, 'Xyzland');
      // sem motivo, ou resposta estranha: trata como indisponível
      expect(WeatherResult.fromJson({'ok': false}).reason, 'unavailable');
      expect(const WeatherResult.unavailable().ok, isFalse);
    });
  });

  testWidgets('mostra temperatura, condição, cidade e os detalhes', (tester) async {
    await _pump(tester, RailWeatherWidget(service: _FakeService([_ok])));
    expect(find.text('18°C'), findsOneWidget);
    expect(find.text('Parcialmente nublado'), findsOneWidget);
    expect(find.text('Porto Alegre, RS'), findsOneWidget);
    for (final l in ['Máx.', 'Mín.', 'Sensação', 'Chuva', 'Umidade', 'Vento']) {
      expect(find.text(l), findsOneWidget, reason: l);
    }
    expect(find.text('24°'), findsOneWidget);
    expect(find.text('40%'), findsOneWidget);
    expect(find.text('14 km/h'), findsOneWidget);
  });

  testWidgets('detalhes ausentes não viram linhas vazias', (tester) async {
    const partial = WeatherResult(ok: true, location: 'Guarapari', temperature: 29, condition: 'Sol', icon: 'sun');
    await _pump(tester, RailWeatherWidget(service: _FakeService([partial])));
    expect(find.text('29°C'), findsOneWidget);
    expect(find.text('Máx.'), findsNothing);
    expect(find.text('Vento'), findsNothing);
  });

  testWidgets('sem cidade no perfil: mensagem e botão que abre a edição do perfil', (tester) async {
    final service = _FakeService([const WeatherResult(ok: false, reason: 'no_location'), _ok]);
    var edits = 0;
    await _pump(tester, RailWeatherWidget(service: service, onEditProfile: () async => edits++));
    expect(find.textContaining('Escolha sua cidade no perfil'), findsOneWidget);
    await tester.tap(find.text('Editar perfil'));
    await tester.pumpAndSettle();
    expect(edits, 1);
    expect(service.calls, 2); // ao voltar da edição o clima é buscado de novo
    expect(find.text('18°C'), findsOneWidget);
  });

  testWidgets('cidade não encontrada: cita a cidade e oferece editar o perfil', (tester) async {
    final service = _FakeService([const WeatherResult(ok: false, reason: 'not_found', location: 'Xyzland')]);
    await _pump(tester, RailWeatherWidget(service: service, onEditProfile: () async {}));
    expect(find.textContaining('Xyzland'), findsOneWidget);
    expect(find.text('Editar perfil'), findsOneWidget);
  });

  testWidgets('clima desativado: só a mensagem, sem botão', (tester) async {
    final service = _FakeService([const WeatherResult(ok: false, reason: 'disabled')]);
    await _pump(tester, RailWeatherWidget(service: service));
    expect(find.text('O clima está desativado.'), findsOneWidget);
    expect(find.byType(OutlinedButton), findsNothing);
  });

  testWidgets('indisponível: "Tentar de novo" busca outra vez', (tester) async {
    final service = _FakeService([const WeatherResult.unavailable(), _ok]);
    await _pump(tester, RailWeatherWidget(service: service));
    expect(find.text('Não consegui buscar o clima agora.'), findsOneWidget);
    await tester.tap(find.text('Tentar de novo'));
    await tester.pumpAndSettle();
    expect(service.calls, 2);
    expect(find.text('18°C'), findsOneWidget);
    expect(find.text('Tentar de novo'), findsNothing);
  });

  testWidgets('atualização automática: repete a busca e mantém o clima bom se ela falhar', (tester) async {
    final service = _FakeService([_ok, const WeatherResult.unavailable()]);
    await _pump(tester, RailWeatherWidget(service: service, refreshEvery: const Duration(seconds: 1)));
    expect(service.calls, 1);
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    expect(service.calls, 2);
    expect(find.text('18°C'), findsOneWidget); // a falha silenciosa não troca o clima por erro
    expect(find.text('Não consegui buscar o clima agora.'), findsNothing);
  });

  testWidgets('WeatherIcon desenha todas as condições da API sem quebrar', (tester) async {
    const kinds = ['sun', 'moon', 'sun-cloud', 'moon-cloud', 'cloud', 'fog', 'drizzle', 'rain', 'snow', 'storm', 'desconhecido'];
    await tester.pumpWidget(MaterialApp(
      home: Wrap(children: [for (final k in kinds) WeatherIcon(kind: k, size: 40)]),
    ));
    expect(find.byType(WeatherIcon), findsNWidgets(kinds.length));
    expect(tester.takeException(), isNull);
  });
}
