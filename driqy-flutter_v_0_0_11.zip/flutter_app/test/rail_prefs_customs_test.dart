import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_client.dart';
import 'package:driqy_flutter/services/rail_prefs_controller.dart';
import 'package:driqy_flutter/services/widgets_service.dart';
import 'package:flutter_test/flutter_test.dart';

/// Serviço de mentira (sem rede) que se comporta como o servidor: novo widget entra no fim da ordem.
class _FakeService extends WidgetsService {
  final List<CustomWidget> store = [
    const CustomWidget(id: 'custom:1', widgetId: 1, kind: 'note', title: 'Nota'),
  ];
  bool failDelete = false;
  int _next = 2;

  _FakeService() : super(ApiClient());

  RailPrefs _prefsNow() => RailPrefs(order: [...kRailWidgetIds, for (final w in store) w.id]);

  @override
  Future<RailPrefs?> getPrefs() async => _prefsNow();

  @override
  Future<CustomCatalog> getCustomCatalog() async => CustomCatalog(widgets: [...store], max: 3);

  @override
  Future<CustomWidget> createCustom(String kind, {String? title}) async {
    final w = CustomWidget(id: 'custom:$_next', widgetId: _next, kind: kind, title: 'Novo');
    _next++;
    store.add(w);
    return w;
  }

  @override
  Future<void> deleteCustom(int id) async {
    if (failDelete) throw Exception('x');
    store.removeWhere((w) => w.widgetId == id);
  }
}

void main() {
  test('load traz as preferências e os widgets próprios juntos', () async {
    final c = RailPrefsController(_FakeService());
    expect(c.loaded, isFalse);
    await c.load();
    expect(c.loaded, isTrue);
    expect(c.customs.map((w) => w.id), ['custom:1']);
    expect(c.customMax, 3);
    expect(c.prefs.order.last, 'custom:1');
  });

  test('createCustom devolve o id e a ordem nova já traz o widget', () async {
    final c = RailPrefsController(_FakeService());
    await c.load();
    final id = await c.createCustom('checklist');
    expect(id, 'custom:2');
    expect(c.customs.length, 2);
    expect(c.prefs.visibleIds.last, 'custom:2');
  });

  test('deleteCustom tira da lista e da ordem; se falha, nada muda', () async {
    final s = _FakeService();
    final c = RailPrefsController(s);
    await c.load();
    s.failDelete = true;
    expect(await c.deleteCustom('custom:1'), isFalse);
    expect(c.customs.length, 1);
    s.failDelete = false;
    expect(await c.deleteCustom('custom:1'), isTrue);
    expect(c.customs, isEmpty);
    expect(c.prefs.order.contains('custom:1'), isFalse);
    expect(await c.deleteCustom('weather'), isFalse); // só widgets próprios
  });

  test('renameCustomLocally troca o título e avisa quem escuta', () async {
    final c = RailPrefsController(_FakeService());
    await c.load();
    var n = 0;
    c.addListener(() => n++);
    c.renameCustomLocally('custom:1', 'Compras');
    expect(c.customs.first.title, 'Compras');
    expect(n, 1);
  });

  test('CustomCatalog.fromJson usa os tipos padrão quando não vêm e lê o limite', () {
    final cat = CustomCatalog.fromJson({
      'widgets': [
        {'id': 'custom:4', 'widget_id': 4, 'kind': 'counter', 'title': 'Água', 'data': {'value': 2}},
      ],
      'max': 5,
    });
    expect(cat.widgets.single.widgetId, 4);
    expect(cat.widgets.single.data['value'], 2);
    expect(cat.kinds.length, 5);
    expect(cat.max, 5);
  });
}
