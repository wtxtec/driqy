import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:driqy_flutter/services/api_client.dart';
import 'package:driqy_flutter/services/rail_prefs_controller.dart';
import 'package:driqy_flutter/services/widgets_service.dart';
import 'package:driqy_flutter/widgets/rail/rail_customize.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// Servidor de mentira: ordem com 1 widget próprio conhecido, 1 desconhecido (de outra versão) e guarda o que foi salvo.
class _FakeService extends WidgetsService {
  RailPrefs? saved;

  _FakeService() : super(ApiClient());

  @override
  Future<RailPrefs?> getPrefs() async => const RailPrefs(order: [...kRailWidgetIds, 'custom:1', 'futuro:9']);

  @override
  Future<CustomCatalog> getCustomCatalog() async => const CustomCatalog(
        widgets: [CustomWidget(id: 'custom:1', widgetId: 1, kind: 'note', title: 'Minha nota')],
      );

  @override
  Future<RailPrefs?> savePrefs(RailPrefs prefs) async => saved = prefs;
}

Future<RailPrefsController> _open(WidgetTester tester, _FakeService s) async {
  tester.view.physicalSize = const Size(900, 2400);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.reset);
  final c = RailPrefsController(s);
  await c.load();
  await tester.pumpWidget(MaterialApp(
    home: Builder(
      builder: (context) => Scaffold(
        body: TextButton(onPressed: () => showRailCustomizeDialog(context, c), child: const Text('abrir')),
      ),
    ),
  ));
  await tester.tap(find.text('abrir'));
  await tester.pumpAndSettle();
  return c;
}

void main() {
  testWidgets('lista os 16 prontos e os widgets próprios (com a etiqueta "seu"); id desconhecido fica de fora', (tester) async {
    await _open(tester, _FakeService());
    for (final name in ['O clima hoje', 'Relógio mundial', 'Fase da Lua', 'Respirar', 'Minha nota']) {
      expect(find.text(name, skipOffstage: false), findsOneWidget, reason: name);
    }
    expect(find.byKey(const Key('cz-own-custom:1'), skipOffstage: false), findsOneWidget);
    expect(find.byKey(const Key('cz-own-clock'), skipOffstage: false), findsNothing);
    expect(find.textContaining('futuro', skipOffstage: false), findsNothing);
  });

  testWidgets('desligar um widget próprio salva em "disabled" e mantém o id desconhecido na ordem', (tester) async {
    final s = _FakeService();
    await _open(tester, s);
    await tester.ensureVisible(find.text('Minha nota'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Minha nota'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Salvar'));
    await tester.pumpAndSettle();
    expect(s.saved?.disabled, ['custom:1']);
    expect(s.saved?.order, containsAll(['custom:1', 'futuro:9']));
  });
}
