import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:driqy_flutter/services/messages_prefs.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('opções de som espelham as do site (padrao, ding, pop)', () {
    expect(MessagesPrefs.choices.keys.toList(), ['padrao', 'ding', 'pop']);
  });

  test('começa com som desligado, som padrão e volume máximo; escolha e volume são guardados', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = MessagesPrefs.instance;
    await prefs.load();
    expect(prefs.soundEnabled, isFalse);
    expect(prefs.soundChoice, 'padrao');
    expect(prefs.volume, 1.0);

    prefs.setVolumeLive(5); // acima do máximo → limita em 1.0
    expect(prefs.volume, 1.0);
    prefs.setVolumeLive(-1);
    expect(prefs.volume, 0.0);

    await prefs.setSoundChoice('inexistente'); // ignorada
    expect(prefs.soundChoice, 'padrao');
  });
}
