import 'package:driqy_flutter/widgets/ping_wide.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('breakpoint do Ping igual ao do site (900)', () {
    expect(kPingWideBreakpoint, 900);
  });

  testWidgets('PingWide.of so e true dentro de PingWide', (tester) async {
    bool? inside, outside;
    await tester.pumpWidget(MaterialApp(
      home: Column(children: [
        Builder(builder: (c) {
          outside = PingWide.of(c);
          return const SizedBox();
        }),
        PingWide(child: Builder(builder: (c) {
          inside = PingWide.of(c);
          return const SizedBox();
        })),
      ]),
    ));
    expect([outside, inside], [false, true]);
  });

  testWidgets('estado vazio do painel direito', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: PingEmptyDetail()));
    expect(find.text('Selecione uma conversa para começar'), findsOneWidget);
  });

  testWidgets('PingDetailObserver informa a conversa aberta e limpa ao voltar', (tester) async {
    final seen = <String?>[];
    final key = GlobalKey<NavigatorState>();
    await tester.pumpWidget(MaterialApp(
      home: Navigator(
        key: key,
        observers: [PingDetailObserver(seen.add)],
        onGenerateRoute: (_) => pingFadeRoute<void>(const Text('vazio')),
      ),
    ));
    key.currentState!.pushAndRemoveUntil(
      pingFadeRoute<void>(const Text('conversa'), name: kPingThreadRoute, args: 'beto'),
      (r) => r.isFirst,
    );
    await tester.pumpAndSettle();
    expect(seen.last, 'beto');
    key.currentState!.pop();
    await tester.pumpAndSettle();
    expect(seen.last, isNull);
  });
}
