import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

// O teste de contador do modelo do Flutter foi removido (apontava para uma
// `MyApp` que não existe). O app real inicia Firebase e Providers, então fica
// fora de um teste de widget simples; a lógica do chat é testada em
// chat_message_test.dart.
void main() {
  testWidgets('MaterialApp básico monta', (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(body: Text('ok'))));
    expect(find.text('ok'), findsOneWidget);
  });
}
