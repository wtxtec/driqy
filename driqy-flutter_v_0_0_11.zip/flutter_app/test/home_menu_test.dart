import 'package:driqy_flutter/widgets/driqy_box.dart';
import 'package:driqy_flutter/widgets/home_menu.dart';
import 'package:driqy_flutter/widgets/home_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _host(Widget child) => MaterialApp(
      home: Scaffold(
        body: Align(
          alignment: Alignment.topLeft,
          child: SizedBox(width: 260, child: DriqyBox(child: child)),
        ),
      ),
    );

HomeMenu _menu({
  int selectedTab = 0,
  ValueChanged<int>? onSelectTab,
  VoidCallback? onNews,
  VoidCallback? onMessages,
  VoidCallback? onLogout,
  VoidCallback? onProfile,
  VoidCallback? onClose,
  VoidCallback? onSettings,
  VoidCallback? onWidgets,
}) =>
    HomeMenu(
      selectedTab: selectedTab,
      onSelectTab: onSelectTab ?? (_) {},
      onNews: onNews ?? () {},
      onMessages: onMessages ?? () {},
      onLogout: onLogout ?? () {},
      onProfile: onProfile,
      onClose: onClose,
      onSettings: onSettings,
      onWidgets: onWidgets,
      brand: const Text('driqy'), // o teste não baixa a fonte da marca
    );

void main() {
  testWidgets('"Widgets" só aparece quando a coluna da direita não cabe (onWidgets) e abre a tela', (tester) async {
    await tester.pumpWidget(_host(_menu()));
    expect(find.text('Widgets'), findsNothing);

    var opened = 0;
    await tester.pumpWidget(_host(_menu(onProfile: () {}, onWidgets: () => opened++)));
    expect(find.text('Widgets'), findsOneWidget);
    expect(tester.getTopLeft(find.text('Widgets')).dy, lessThan(tester.getTopLeft(find.text('Meu perfil')).dy));
    await tester.tap(find.text('Widgets'));
    expect(opened, 1);
  });

  testWidgets('menu tem os mesmos links, na mesma ordem, da sidebar do site', (tester) async {
    await tester.pumpWidget(_host(_menu(onProfile: () {})));
    const labels = ['Feed', 'Vortex', 'Notícias', 'Mensagens', 'Notificações', 'Meu perfil', 'Sair'];
    double? last;
    for (final l in labels) {
      expect(find.text(l), findsOneWidget, reason: l);
      final y = tester.getTopLeft(find.text(l)).dy;
      if (last != null) expect(y, greaterThan(last), reason: 'ordem de $l');
      last = y;
    }
  });

  testWidgets('sem usuário carregado não mostra "Meu perfil"', (tester) async {
    await tester.pumpWidget(_host(_menu()));
    expect(find.text('Meu perfil'), findsNothing);
  });

  testWidgets('o item da aba atual fica em negrito', (tester) async {
    Future<FontWeight?> weightOf(String label) async => tester.widget<Text>(find.text(label)).style?.fontWeight;

    await tester.pumpWidget(_host(_menu(selectedTab: 1)));
    expect(await weightOf('Vortex'), FontWeight.w700);
    expect(await weightOf('Feed'), FontWeight.w500);

    await tester.pumpWidget(_host(_menu(selectedTab: 2)));
    expect(await weightOf('Notificações'), FontWeight.w700);
    expect(await weightOf('Vortex'), FontWeight.w500);
  });

  testWidgets('toques disparam o destino certo', (tester) async {
    final tabs = <int>[];
    var news = 0, messages = 0, logout = 0, profile = 0;
    await tester.pumpWidget(_host(_menu(
      onSelectTab: tabs.add,
      onNews: () => news++,
      onMessages: () => messages++,
      onLogout: () => logout++,
      onProfile: () => profile++,
    )));
    await tester.tap(find.text('Feed'));
    await tester.tap(find.text('Vortex'));
    await tester.tap(find.text('Notificações'));
    await tester.tap(find.text('Notícias'));
    await tester.tap(find.text('Mensagens'));
    await tester.tap(find.text('Meu perfil'));
    await tester.tap(find.text('Sair'));
    expect(tabs, [0, 1, 2]);
    expect([news, messages, profile, logout], [1, 1, 1, 1]);
  });

  testWidgets('o botão ✕ só existe no Drawer (com onClose)', (tester) async {
    await tester.pumpWidget(_host(_menu()));
    expect(find.byIcon(Icons.close), findsNothing); // caixa fixa

    var closed = 0;
    await tester.pumpWidget(_host(_menu(onClose: () => closed++)));
    await tester.tap(find.byIcon(Icons.close));
    expect(closed, 1);
  });

  testWidgets('"Personalizar painel" saiu do menu; "Configurações" só aparece com onSettings', (tester) async {
    await tester.pumpWidget(_host(_menu()));
    expect(find.text('Personalizar painel'), findsNothing);
    expect(find.text('Configurações'), findsNothing);

    var opened = 0;
    await tester.pumpWidget(_host(_menu(onSettings: () => opened++)));
    expect(find.text('Personalizar painel'), findsNothing);
    await tester.tap(find.text('Configurações'));
    expect(opened, 1);
  });

  testWidgets('o menu não desenha barra de scroll', (tester) async {
    await tester.pumpWidget(_host(_menu(onProfile: () {}, onSettings: () {})));
    expect(find.byType(Scrollbar), findsNothing);
  });

  testWidgets('diálogo de Configurações tem o "Personalizar painel"', (tester) async {
    var tapped = 0;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: HomeSettingsDialog(onCustomizePanel: () => tapped++))));
    expect(find.text('Configurações'), findsOneWidget);
    await tester.tap(find.text('Personalizar painel'));
    expect(tapped, 1);
  });
}
