import 'package:driqy_flutter/models/app_notification.dart';
import 'package:driqy_flutter/models/rail_widgets.dart';
import 'package:flutter_test/flutter_test.dart';

Map<String, dynamic> _json(String kind, String verb) => {
      'id': 1,
      'kind': kind,
      'verb': verb,
      'actor': {'id': 7, 'username': 'ana', 'display_name': 'Ana'},
      'post_id': null,
      'comment_id': null,
      'snippet': null,
      'is_read': false,
      'created_at': '2026-12-18T11:00:00Z',
    };

void main() {
  test('aviso de estação: reconhece o tipo e tira o emoji do começo do texto', () {
    final n = AppNotification.fromJson(_json('season', '☀️ Verão começa em 3 dias (21/12). Veja o progresso no widget Estações.'));
    expect(n.isSeason, isTrue);
    expect(n.seasonEmoji, '☀️');
    expect(AppNotification.fromJson(_json('season', 'sem emoji aqui')).seasonEmoji, '🍃');
    expect(AppNotification.fromJson(_json('like', 'curtiu seu post')).isSeason, isFalse);
  });

  test('"seasons" está na lista de widgets do painel, logo depois da Lua', () {
    final i = kRailWidgetIds.indexOf('moon');
    expect(kRailWidgetIds[i + 1], 'seasons');
  });
}
