import 'package:driqy_flutter/models/message.dart';
import 'package:flutter_test/flutter_test.dart';

// NÃO rodado (sem SDK no ambiente da IA): conferir com `flutter test`.
Map<String, dynamic> _json({bool viewOnce = true, String? state = 'unopened', bool canOpen = true}) => {
      'id': 7,
      'content': '📷 Foto',
      'msg_type': 'image',
      'media_url': null,
      'sender_id': 2,
      'recipient_id': 1,
      'created_at': '2026-10-25T12:00:00Z',
      'mine': false,
      'view_once': viewOnce,
      'view_once_state': state,
      'can_open_view_once': canOpen,
    };

void main() {
  test('lê os campos de visualização única', () {
    final m = DriqyMessage.fromJson(_json());
    expect(m.viewOnce, isTrue);
    expect(m.viewOnceState, 'unopened');
    expect(m.canOpenViewOnce, isTrue);
    expect(m.mediaUrl, isNull); // o servidor nunca manda a URL na lista
  });

  test('servidor antigo (sem os campos) continua valendo', () {
    final j = _json()..remove('view_once')..remove('view_once_state')..remove('can_open_view_once');
    final m = DriqyMessage.fromJson(j);
    expect(m.viewOnce, isFalse);
    expect(m.canOpenViewOnce, isFalse);
  });

  test('prévia não vaza o tipo/legenda', () {
    expect(DriqyMessage.fromJson(_json()).previewText, '🔒 Visualização única');
  });

  test('copyWith mantém o estado', () {
    final m = DriqyMessage.fromJson(_json(state: 'opened', canOpen: false)).copyWith(clearLocalState: true);
    expect(m.viewOnce, isTrue);
    expect(m.viewOnceState, 'opened');
  });

  test('imagem local de visualização única ignora a legenda', () {
    final m = DriqyMessage.localImage(clientId: 'c', path: '/tmp/a.jpg', caption: 'segredo', viewOnce: true);
    expect(m.viewOnce, isTrue);
    expect(m.caption, isNull);
    expect(m.content, '📷 Foto');
  });

  test('withMedia só serve para o visualizador', () {
    final m = DriqyMessage.fromJson(_json()).withMedia(mediaUrl: '/api/v1/messages/media/7');
    expect(m.mediaUrl, '/api/v1/messages/media/7');
    expect(m.viewOnce, isTrue);
  });
}
