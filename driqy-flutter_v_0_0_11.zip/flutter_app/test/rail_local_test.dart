import 'dart:convert';

import 'package:driqy_flutter/widgets/rail/rail_local.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> _pump(WidgetTester t, Widget w) async {
  await t.pumpWidget(MaterialApp(
    home: Scaffold(body: SingleChildScrollView(child: Center(child: SizedBox(width: 320, child: w)))),
  ));
  await t.pumpAndSettle();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  group('PomoState', () {
    const today = '2026-11-05';

    test('começa em foco, parado, com 25 min', () {
      final s = PomoState.fresh(today);
      expect(s.mode, 'focus');
      expect(s.running, isFalse);
      expect(s.secondsLeft(0), 25 * 60);
    });

    test('iniciar, pausar e continuar', () {
      var s = PomoState.fresh(today).start(1000000);
      expect(s.running, isTrue);
      expect(s.secondsLeft(1000000 + 60 * 1000), 24 * 60);
      s = s.pause(1000000 + 60 * 1000);
      expect(s.running, isFalse);
      expect(s.left, 24 * 60);
      s = s.start(5000000);
      expect(s.endAtMs, 5000000 + 24 * 60 * 1000);
    });

    test('foco concluído conta, e de 4 em 4 a pausa é longa', () {
      var s = PomoState.fresh(today);
      final modes = <String>[];
      var now = 0;
      for (var i = 0; i < 4; i++) {
        s = s.start(now);
        now += 25 * 60 * 1000;
        s = s.advance(now); // acabou o foco
        modes.add(s.mode);
        expect(s.running, isFalse);
        s = s.start(now);
        now += s.left * 1000;
        s = s.advance(now); // acabou a pausa: volta ao foco
        expect(s.mode, 'focus');
      }
      expect(modes, ['short', 'short', 'short', 'long']);
      expect(s.doneN, 4);
    });

    test('advance não mexe antes da hora nem parado', () {
      final s = PomoState.fresh(today).start(0);
      expect(identical(s.advance(1000), s), isTrue);
      final stopped = PomoState.fresh(today);
      expect(identical(stopped.advance(99999999), stopped), isTrue);
    });

    test('fromJson/toJson: guarda e restaura; lixo volta ao começo; dia novo zera a contagem', () {
      final s = PomoState.fresh(today).start(0).advance(25 * 60 * 1000);
      final back = PomoState.fromJson(jsonDecode(jsonEncode(s.toJson())), today);
      expect(back.mode, s.mode);
      expect(back.doneN, 1);
      expect(PomoState.fromJson(jsonDecode(jsonEncode(s.toJson())), '2026-11-06').doneN, 0);
      expect(PomoState.fromJson('lixo', today).mode, 'focus');
      expect(PomoState.fromJson({'mode': 'xx'}, today).mode, 'focus');
      expect(PomoState.fromJson({'mode': 'short', 'left': 99999}, today).left, 5 * 60);
    });
  });

  testWidgets('foco: iniciar, o tempo anda, acaba, avisa e passa para a pausa', (t) async {
    var now = DateTime(2026, 11, 5, 9).millisecondsSinceEpoch;
    var beeps = 0;
    await _pump(t, RailPomodoroWidget(nowMs: () => now, onFinished: () => beeps++));
    expect(find.text('25:00'), findsOneWidget);
    expect(find.text('Iniciar'), findsOneWidget);
    expect(find.text('25 min de foco, 5 de pausa.'), findsOneWidget);
    await t.tap(find.byKey(const Key('pomo-go')));
    await t.pump();
    expect(find.text('Pausar'), findsOneWidget);
    now += 601 * 1000;
    await t.pump(const Duration(seconds: 1));
    expect(find.text('14:59'), findsOneWidget);
    now += 900 * 1000; // passou do fim
    await t.pump(const Duration(seconds: 1));
    expect(beeps, 1);
    expect(find.text('05:00'), findsOneWidget);
    expect(find.text('Hoje: 1 foco concluído'), findsOneWidget);
    expect(find.text('Iniciar'), findsOneWidget);
    await t.pump();
    final saved = jsonDecode((await SharedPreferences.getInstance()).getString(kPomoKey)!) as Map<String, dynamic>;
    expect(saved['mode'], 'short');
    expect(saved['running'], isFalse);
  });

  testWidgets('foco: pausar, continuar, reiniciar e trocar de modo', (t) async {
    var now = DateTime(2026, 11, 5, 9).millisecondsSinceEpoch;
    await _pump(t, RailPomodoroWidget(nowMs: () => now));
    await t.tap(find.byKey(const Key('pomo-go')));
    await t.pump();
    now += 60 * 1000;
    await t.tap(find.byKey(const Key('pomo-go'))); // pausar
    await t.pump();
    expect(find.text('24:00'), findsOneWidget);
    expect(find.text('Continuar'), findsOneWidget);
    await t.tap(find.byKey(const Key('pomo-reset')));
    await t.pump();
    expect(find.text('25:00'), findsOneWidget);
    expect(find.text('Iniciar'), findsOneWidget);
    await t.tap(find.byKey(const Key('pomo-mode-long')));
    await t.pump();
    expect(find.text('15:00'), findsOneWidget);
  });

  testWidgets('foco: abre de onde parou (o estado salvo continua valendo)', (t) async {
    final now = DateTime(2026, 11, 5, 9).millisecondsSinceEpoch;
    final saved = PomoState.fresh('2026-11-05').start(now - 5 * 60 * 1000); // começou há 5 min
    SharedPreferences.setMockInitialValues({kPomoKey: jsonEncode(saved.toJson())});
    await _pump(t, RailPomodoroWidget(nowMs: () => now));
    expect(find.text('20:00'), findsOneWidget);
    expect(find.text('Pausar'), findsOneWidget);
  });

  group('CalcEngine', () {
    CalcEngine run(List<String> keys) {
      final c = CalcEngine();
      for (final k in keys) {
        switch (k) {
          case '=':
            c.equals();
            break;
          case ',':
            c.dot();
            break;
          case 'C':
            c.clear();
            break;
          case '⌫':
            c.back();
            break;
          case '%':
            c.percent();
            break;
          case '±':
            c.negate();
            break;
          case '+':
          case '−':
          case '×':
          case '÷':
            c.setOp(k);
            break;
          default:
            c.digit(k);
        }
      }
      return c;
    }

    test('contas básicas e sem lixo de ponto flutuante', () {
      expect(run(['1', '2', '+', '3', '=']).display, '15');
      expect(run(['0', ',', '1', '+', '0', ',', '2', '=']).display, '0,3');
      expect(run(['9', '×', '9', '=']).display, '81');
      expect(run(['1', '0', '−', '4', '=']).display, '6');
      expect(run(['7', '÷', '2', '=']).display, '3,5');
    });

    test('encadear operações calcula na hora', () {
      final c = run(['2', '+', '3', '×']);
      expect(c.cur, '5');
      expect(c.history, '5 ×');
      expect(run(['2', '+', '3', '×', '4', '=']).display, '20');
    });

    test('1 ÷ 0 dá Erro e o próximo dígito recomeça', () {
      final c = run(['1', '÷', '0', '=']);
      expect(c.display, 'Erro');
      c.digit('5');
      expect(c.display, '5');
    });

    test('porcentagem, sinal, apagar e limpar', () {
      expect(run(['5', '0', '%']).display, '0,5');
      expect(run(['5', '±']).display, '-5');
      expect(run(['5', '±', '±']).display, '5');
      expect(run(['1', '2', '3', '⌫']).display, '12');
      expect(run(['1', '⌫']).display, '0');
      expect(run(['1', '2', '+', '3', 'C']).display, '0');
    });

    test('vírgula só uma vez e limite de 14 dígitos', () {
      expect(run(['1', ',', '5', ',', '2']).display, '1,52');
      final c = run(List.filled(20, '9'));
      expect(c.cur.length, 14);
    });
  });

  testWidgets('calculadora: toca nas teclas e mostra o resultado', (t) async {
    await _pump(t, const RailCalcWidget());
    for (final k in ['1', '2', '+', '3', '=']) {
      await t.tap(find.byKey(Key('calc-key-$k')));
      await t.pump();
    }
    expect(t.widget<Text>(find.byKey(const Key('calc-display'))).data, '15');
    await t.tap(find.byKey(const Key('calc-key-C')));
    await t.pump();
    for (final k in ['8', '÷', '0', '=']) {
      await t.tap(find.byKey(Key('calc-key-$k')));
      await t.pump();
    }
    expect(t.widget<Text>(find.byKey(const Key('calc-display'))).data, 'Erro');
  });

  testWidgets('respirar: inspire, segure, expire e para quando pedir', (t) async {
    await _pump(t, const RailBreatheWidget());
    expect(find.text('Respirar'), findsOneWidget);
    await t.tap(find.byKey(const Key('breathe-go')));
    await t.pump();
    expect(find.text('Inspire'), findsOneWidget);
    expect(find.text('Parar'), findsOneWidget);
    await t.pump(const Duration(seconds: 4));
    expect(find.text('Segure'), findsOneWidget);
    await t.pump(const Duration(seconds: 4));
    expect(find.text('Expire'), findsOneWidget);
    await t.pump(const Duration(seconds: 6));
    expect(find.text('Inspire'), findsOneWidget); // segundo ciclo
    await t.tap(find.byKey(const Key('breathe-go')));
    await t.pumpAndSettle();
    expect(find.text('Parado.'), findsOneWidget);
    expect(find.text('Começar'), findsOneWidget);
  });
}
