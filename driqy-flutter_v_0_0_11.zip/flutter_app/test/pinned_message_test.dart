import 'package:flutter_test/flutter_test.dart';

import 'package:driqy_flutter/services/message_service.dart';

void main() {
  test('DriqyPinned.fromJson lê id e prévia', () {
    final p = DriqyPinned.fromJson({'id': 7, 'preview': 'oi ana', 'mine': false});
    expect(p, isNotNull);
    expect(p!.id, 7);
    expect(p.preview, 'oi ana');
  });

  test('DriqyPinned.fromJson devolve null sem mensagem fixada', () {
    expect(DriqyPinned.fromJson(null), isNull);
    expect(DriqyPinned.fromJson({'preview': 'sem id'}), isNull);
  });

  test('prévia ausente vira texto vazio', () {
    expect(DriqyPinned.fromJson({'id': 1})!.preview, '');
  });
}
