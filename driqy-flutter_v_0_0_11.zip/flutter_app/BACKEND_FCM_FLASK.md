# Backend Flask — push notifications (FCM)

Toda a implementação já está pronta no backend (`push.py`, tabela
`DeviceToken` em `models.py`, rotas `/api/v1/devices/register` e
`/api/v1/devices/unregister` em `api.py`, disparo automático nas
curtidas/comentários/seguidas em `models.py` e nas mensagens em
`api.py`/`chat.py`). **Só falta uma coisa pra push funcionar de
verdade: a chave de serviço do Firebase.**

## 1. Instalar o Admin SDK do Firebase

Já está em `requirements.txt` (`firebase-admin==6.5.0`). Se o
ambiente já estava instalado antes dessa mudança, rode:

```bash
pip install -r requirements.txt
```

## 2. Baixar a chave de serviço (Service Account)

No Firebase Console → engrenagem (⚙) → **Configurações do projeto** →
aba **Contas de serviço** → **Gerar nova chave privada**. Isso baixa um
`.json`.

Salve esse arquivo em:

```
instance/firebase-service-account.json
```

(já está no `.gitignore`, não vai parar no controle de versão por
engano). Se preferir outro caminho, defina a variável de ambiente
`FIREBASE_SERVICE_ACCOUNT` apontando pro arquivo.

## Como funciona sem a chave

Sem o arquivo, o backend continua funcionando 100% normal — curtidas,
comentários, seguidas e mensagens continuam sendo salvos e aparecendo
na aba Notificações/Mensagens do app (via polling). Só o *push* (o
alerta que aparece na bandeja do celular, mesmo com o app fechado)
fica desativado, e o servidor imprime um aviso no log na primeira
tentativa, sem quebrar nada.

## Como testar depois de colocar a chave

1. Reinicie o Flask.
2. No app Flutter, faça login (isso já registra o token do aparelho
   automaticamente via `PushNotificationService.registerDeviceToken`,
   chamado no `main.dart`).
3. Peça pra outra conta seguir/curtir/comentar/mandar mensagem pra essa
   conta, ou faça isso pelo site.
4. A notificação deve aparecer na bandeja do celular — inclusive com
   o app minimizado ou fechado.

Se não aparecer, confira o log do Flask por uma linha começando com
`[push]` — ela explica o motivo (chave ausente, token inválido,
pacote não instalado etc.).

## Sons das notificações (dois canais)

O app cria dois canais no Android, cada um com seu som:

| Canal            | ID               | Som (`res/raw`)        | Usado em                                  |
|------------------|------------------|------------------------|-------------------------------------------|
| Mensagens        | `driqy_messages` | `driqy_message.wav`    | novas mensagens diretas                   |
| Atividade        | `driqy_activity` | `driqy_notification.wav` | curtidas, comentários, respostas, seguidas |

O backend (`push.py`) escolhe o canal pelo campo `data.type` do push
(`message` → mensagens; qualquer outro → atividade). No Android 8+ o som
pertence ao canal e **não muda depois de criado**; por isso os canais têm
IDs novos e o canal antigo (`driqy_default_channel`) é removido na primeira
abertura do app. Pra trocar os sons no futuro, troque os `.wav` e **mude o
ID do canal** (ex.: `driqy_messages_v2`) nos dois lados (app e `push.py`).

No iOS o som só toca se os arquivos `.wav` forem adicionados ao projeto no
Xcode (Runner → Add Files). Sem isso, toca o som padrão.
