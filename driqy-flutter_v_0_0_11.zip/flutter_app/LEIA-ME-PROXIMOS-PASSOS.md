# LEIA-ME — Continuação do app Flutter do Driqy

> **⚠ DOCUMENTO HISTÓRICO (sessões 1–14, anterior ao chat, ao Ping/Mensagens, ao Vortex por gosto e ao layout em caixa).** As listas "O que ainda falta" abaixo estão desatualizadas. O estado atual está nos `PROGRESSO_*.md`; comece por `PROGRESSO_INDICE.md`.


> **Atualização desta sessão (a mais recente) está no topo.** O
> histórico de sessões anteriores foi mantido abaixo, sem alterações,
> para contexto.

## Sessão mais recente 14 — GIFs animando (parte 1 de 4 do plano do Vortex)

Plano completo e status em `PROGRESSO_VORTEX.md`. Nesta sessão: novo
`lib/widgets/driqy_image.dart` (`DriqyImage`/`AnimatedGif`) usado no card do
post, carrossel, lightbox e grade do Vortex; `ApiClient.postMultipart` garante
extensão válida no nome do arquivo de mídia. Use `DriqyImage` (não
`Image.network`) para qualquer mídia de post/Vortex.

## Sessão mais recente 13 — comentários só na página do post (web e Flutter)

Decisão: os comentários nunca aparecem embutidos no feed/perfil, em nenhuma
versão. Só na página própria do post; o botão de comentários e o toque no
post abrem essa página.

- **Flutter**: `PostCard` perdeu a aba de comentários inline (estado,
  carregamento, campo de envio). Botão de comentários → `onCommentsTap`
  (feed/perfil abrem `PostDetailScreen(focusComment: true)`; na própria
  tela do post só foca o campo). Ao voltar, o card atualiza contagens.
- **Web**: `_post_card.html` ganhou `detail` (só `post_detail.html` passa
  `detail=True` e renderiza a seção de comentários, já visível). Feed,
  perfil e fragmentos não renderizam mais comentários. `countdown.js`:
  clique no post ou no botão de comentários navega pra
  `/post/<id>#comments-<id>`; na página do post o botão só foca o campo.
  `sw.js` → cache `driqy-shell-v5` (limpa o JS antigo nos PWAs).

## Sessão mais recente 12 — correção de posicionamento (rodapé, perfil, editar perfil)

- **Rodapé**: o botão Postar (+) tinha `flex: 11` contra 1 dos outros 4
  itens, espremendo os rótulos ("Ho…", "Noti…"). Agora todos têm a mesma
  largura (`home_shell.dart`).
- **Perfil**: "Editar perfil"/"Seguir" ficavam em cima da capa; agora ficam
  logo abaixo dela (só o avatar sobrepõe a capa), como no site.
- **Editar perfil**: "Alterar capa"/"Remover" no canto superior direito da
  capa; avatar sobrepondo a capa com "Alterar foto"/"Remover" ao lado.

## Sessão mais recente 11 — upload de foto de perfil corrigido, editar perfil igual ao site, menu lateral igual, só o coração colorido

- **Bug do upload de foto/capa**: o servidor valida a extensão do *nome* do
  arquivo enviado; caminhos temporários do Android podem vir sem extensão
  válida. `ApiClient.postMultipart` agora sempre envia nome
  (`avatar.ext`/`capa.ext`) e `content-type` explícitos. Novo
  `http_parser` no `pubspec.yaml` (já era dependência transitiva) —
  rode `flutter pub get`.
- **Ajuste no upload (sem botão "Ajustar")**: ao escolher a imagem abre
  `image_crop_screen.dart` (arrastar + pinça + zoom, igual ao modal do
  site; avatar 480x480, capa 1200x400, fundo branco, PNG). O resultado é
  o arquivo enviado.
- **Editar perfil** reescrito igual a `edit_profile.html`: mesma ordem e
  textos (Nome de usuário (@), Nome de exibição, Localização, Bio, Cor de
  marca), botões "Alterar capa/Remover" e "Alterar foto/Remover", topbar e
  botão "Salvar alterações".
- **Menu lateral** igual à `.sidebar-nav`: só texto, ✕ no topo, itens Feed,
  Vortex, Notícias, Mensagens, Notificações, Meu perfil, Sair (sem "Buscar").
- **Cores das ações do post**: só o coração é colorido (rosa, quando
  curtido). Comentários, visualizações e compartilhar ficam cinza. No site:
  `static/css/style.css` (`.like-btn`, `.comment-toggle`, `.views-badge`).

## Sessão mais recente 10 — a mesma barra de cima (logo + busca + mensagens/notificações) agora acompanha em toda página, igual ao site

Pedido do usuário: a barra de cima (logo, caixa de busca, botões de
mensagem e notificação) precisa acompanhar o usuário — só ela — quando
ele rola a página.

### O que realmente estava acontecendo

Não era um bug de "não gruda ao rolar" — no Flutter, o `appBar` de um
`Scaffold` já fica sempre fixo no topo por padrão, isso nunca mudou. O
problema de verdade era outro: **cada tela tinha sua própria barra
diferente** — só o Feed usava a barra completa (`DriqyTopBar`, com
logo, pílula de busca, mensagens e notificações); Busca, Notificações,
Perfil, Vortex e a Caixa de Entrada de mensagens tinham cada uma uma
`AppBar` genérica com só um título de texto. No site (`base.html`), é
o oposto: a mesmíssima `.topbar` (fixa via `position: sticky`) aparece
em **todas** as páginas, sem exceção — só o conteúdo abaixo dela muda.

### Corrigido

Trocada a `AppBar` própria de cada uma dessas telas pela mesma
`DriqyTopBar` do Feed, movendo o título de cada página (quando o site
tinha um, tipo `<h1>Notificações</h1>` ou `<h1>Mensagens</h1>`) pra
dentro do corpo da tela, como conteúdo normal — exatamentente como o
site faz (o título de página do site também não fica dentro da
`.topbar`, fica no `{% block content %}`):

- **Notificações** — ganhou a `DriqyTopBar`; o título "Notificações"
  virou um cabeçalho no corpo, igual ao `<h1>` do `notifications.html`.
- **Perfil** — ganhou a `DriqyTopBar` no lugar do título "@usuário" (o
  nome/@usuário já aparecem em destaque no cabeçalho do perfil mesmo,
  então não precisou de nada a mais).
- **Busca** — ganhou a `DriqyTopBar`; o campo de busca que antes vivia
  dentro da própria AppBar virou um campo de busca de verdade no corpo
  da página, com um cabeçalho "Buscar" — igual ao site, que também tem
  a pílula da topbar E um formulário de busca próprio na página de
  resultados (`search_results.html`).
- **Vortex** — ganhou a `DriqyTopBar` (sem título extra, porque
  `pictures.html` também não tem nenhum título dentro do conteúdo).
- **Caixa de entrada de mensagens** — ganhou a `DriqyTopBar`; o título
  "Mensagens" + o subtítulo viraram conteúdo do corpo, igual ao
  `<h1>`/`<p class="subtitle">` de `messages_inbox.html`.

### O que ficou diferente de propósito (não é omissão)

A tela de **conversa individual** (`message_thread_screen.dart`)
continua com sua própria barra mostrando nome/avatar de quem está
conversando com você, em vez da `DriqyTopBar` genérica — mesmo o site
também estendendo `base.html` ali (então tecnicamente teria a topbar
genérica + um cabeçalho de conversa separado embaixo). Mantive assim
de propósito: um app de chat mostrando o nome de quem você está
conversando na barra é o padrão esperado em qualquer app de mensagens
(WhatsApp, Telegram, etc.), e replicar a topbar genérica ali (com busca
global e ícones que não fazem sentido no meio de uma conversa) deixaria
a tela pior, não mais fiel. O mesmo vale pra `edit_profile_screen.dart`
e `post_detail_screen.dart`: são telas de ação/detalhe com botão de
voltar contextual, não páginas principais — não mexidas.

### Arquivos alterados nesta sessão

- `lib/screens/notifications_screen.dart`
- `lib/screens/profile_screen.dart`
- `lib/screens/search_screen.dart`
- `lib/screens/pictures_screen.dart`
- `lib/screens/messages_inbox_screen.dart`

---

## Sessão mais recente 9 — vídeo tocando sozinho de verdade, bug das bordas quadradas dos posts, e contagem de posts do perfil que nunca chegava no app

Pedido do usuário: vídeo tocando sozinho, bordas dos posts iguais ao
site, e "número de posts" (e outras coisas do perfil) que não
apareciam — mais um pedido geral pra revisar o que mais faltava copiar
do `driqy4.zip`.

### 1. Vídeo tocando sozinho no Vortex — feito, sem precisar de pacote novo

Na sessão 8 eu tinha deixado isso pendente por achar que precisava do
pacote `visibility_detector` (que não está no `pubspec.yaml`, e esse
ambiente não acessa `pub.dev` pra instalar pacote novo). Repensando: dá
pra fazer só com Flutter puro. `PicturesScreen` agora mede a posição de
cada peça de vídeo montada (via `GlobalKey` + `RenderBox.localToGlobal`,
comparado com a altura da tela) toda vez que o usuário rola a lista —
reaproveitando o mesmo `ScrollController` que já existia pra paginação.
Sempre que uma peça de vídeo fica ≥60% visível, ela vira a única a
tocar (mudo, em loop); todas as outras pausam — mesma regra do
`playObserver` de `vortex.js`. Isso é decidido por um
`ValueNotifier<String?>` compartilhado (`_playingVideoKey`) que cada
peça escuta pra saber se é a vez dela. O toque manual pra tocar/pausar
continua funcionando por cima disso.

### 2. Bug real por trás de "os posts não têm curvas" — corrigido

Achei a causa de verdade (não era só falta de copiar o CSS): no
`post_card.dart` da sessão 7, eu tinha posto a faixa de cor do autor
como um lado diferente (`Border(left: ...)`) dentro do mesmo
`BoxDecoration` que tinha `borderRadius: 14`. O Flutter só desenha
borda arredondada corretamente quando os 4 lados de um `Border` são
idênticos — com um lado de cor/largura diferente, ele ignora o
`borderRadius` **silenciosamente em build de release** (em debug daria
um erro barulhento, mas asserts somem no release) e desenha um
retângulo reto por cima do fundo arredondado. Corrigido: a borda do
`BoxDecoration` agora é uniforme (cinza, 1px, nos 4 lados — arredonda
certinho), e a faixa colorida do autor virou uma camada separada por
cima (um `Container` fino de 3px, cortado automaticamente pelas pontas
arredondadas graças ao `clipBehavior` do card) — visualmente idêntico
ao `border-left` do site, mas sem cair nessa armadilha do Flutter.

### 3. "Número de posts" e outras coisas do perfil que nunca apareciam — causa era o backend

Não era um bug de UI: o Flutter (`DriqyUser.fromJson`) já sabia ler
`created_at` e `active_posts_count` desde a sessão 7, com fallback nulo
pra não quebrar — só que o `serialize_user()` do `api.py` **nunca
mandava esses dois campos** (nem `is_staff`, que o modelo Flutter também
espera). Isso afetava todo mundo que usa `serialize_user` — perfil,
posts, comentários, mensagens, ranking, busca — em toda essa gente
faltava "posts ativos", "Entrou em ..." e o `is_staff`. Adicionado
`created_at`, `active_posts_count` e `is_staff` em `serialize_user`
(`api.py`, propriedades que já existiam em `models.py`, só não
apareciam no JSON da API) — **precisa aplicar esse `api.py` no
servidor** pra esses dados aparecerem no app (mesmo arquivo entregue
em `driqy4_backend_api_atualizado.zip`, agora também com essa mudança
além do `created_at` das peças do Vortex da sessão 8).

### O que ainda não existe no Flutter (levantamento do que falta de `driqy4.zip`)

Comparando a lista de páginas do site (`templates/`) com as telas do
Flutter (`lib/screens/`), estas páginas do site **ainda não têm
equivalente no app** — não mexidas nesta sessão por serem telas
inteiras novas (escopo bem maior que os ajustes pontuais pedidos até
aqui), mas ficam anotadas pra próxima:

- **`discover.html`** — grade de "descobrir" pessoas/conteúdo.
- **`ranking.html`** — ranking de usuários.
- **`user_list.html`** — lista de seguidores/seguindo (o app já tem os
  botões "Seguindo"/"Seguidores" no perfil, mas eles não abrem uma tela
  com a lista de verdade ainda).
- **`forgot_password.html` / `reset_password.html`** — recuperação de
  senha (o app só tem login/cadastro).
- **`admin/`** — painel de administração (provavelmente fora de
  escopo mesmo pra um app de usuário final, mas fica registrado).

### Arquivos alterados nesta sessão

- `driqy4/api.py` (em `driqy4_backend_api_atualizado.zip`) —
  `serialize_user` agora manda `created_at`, `active_posts_count` e
  `is_staff`.
- `lib/screens/pictures_screen.dart` — autoplay de vídeo de verdade via
  medição manual de posição na tela (`_playingVideoKey` +
  `_updatePlayingVideo`).
- `lib/widgets/post_card.dart` — corrigido o bug da borda não-uniforme
  que fazia o `borderRadius` ser ignorado; faixa de cor do autor agora é
  uma camada separada.

---

## Sessão mais recente 8 — anel de contagem regressiva de verdade e vídeo real no Vortex (continuação da sessão 7)

Pedido do usuário: "continue a fazer o que falta", referindo-se aos dois
pontos deixados em aberto no fim da sessão 7.

### 1. Anel de contagem regressiva ao vivo nas peças do Vortex — feito

Como documentado na sessão 7, o `CountdownRing` (mesmo widget do feed)
precisa de `createdAt` + `expiresAt` pra calcular a fração
`restante/total`, e o endpoint `/pictures` só mandava `expires_at`.
Adicionei `created_at` na serialização das peças em `api.py`
(`driqy4_backend_api_atualizado.zip` — **é preciso aplicar esse arquivo
no servidor** pra o anel ficar 100% exato; sem ele, o app cai numa
aproximação seguinte: `expires_at - seconds_remaining`, que funciona mas
não é o `created_at` real). No Flutter, `PictureTile` ganhou o campo
`createdAt` (com esse fallback embutido pra não quebrar contra um
servidor ainda não atualizado), e o selo estático no canto de cada peça
virou o `CountdownRing` de verdade — mesmo anel colorido, atualizando a
cada segundo, que já existia no feed.

### 2. Vídeo no Vortex — proporção real, miniatura de verdade e toque pra tocar — feito

Antes, todo vídeo na grade virava uma caixa 4:5 cinza com um ícone de
play estático (nem media real, nem proporção real). Agora cada peça de
vídeo usa um `VideoPlayerController` (o mesmo padrão do
`PostVideoPlayer` já usado no feed): pega a proporção real do arquivo
(`controller.value.aspectRatio`), mostra o primeiro frame como
miniatura, começa mudo e pausado, e tem um botãozinho de play próprio
(que não disputa o toque com o resto da peça, que continua abrindo o
post — antes eu tinha testado usar toque simples pra tocar/pausar e
toque duplo pra abrir o post, mas troquei porque isso deixa o toque
simples "lento" esperando o app decidir se foi toque duplo).

### O que continua faltando (sem mudança desde a sessão 7)

- **Autoplay mudo automático ao rolar a tela** (o vídeo tocar sozinho
  quando ~60% visível, só 1 por vez, como o `vortex.js` faz): ainda não
  dá pra fazer com segurança nesta grade sem o pacote
  `visibility_detector` (não está no `pubspec.yaml`, e adicionar
  dependência nova sem `pub get` rodando aqui é arriscado sem
  conseguir compilar pra conferir). O vídeo agora funciona bem (toca
  ao tocar no botão), só não começa sozinho.
- Sem o Flutter SDK neste ambiente, continua sem `flutter analyze`/
  `flutter run` — conferido por leitura + balanceamento de
  parênteses/chaves, como sempre.

### Arquivos alterados nesta sessão

- `driqy4/api.py` (entregue à parte, em
  `driqy4_backend_api_atualizado.zip`) — endpoint `/pictures` agora
  manda `created_at` por peça.
- `lib/models/picture_tile.dart` — campo `createdAt` (com fallback pra
  servidor antigo).
- `lib/screens/pictures_screen.dart` — `CountdownRing` de verdade no
  lugar do selo estático; vídeo com `VideoPlayerController` real
  (proporção, miniatura, toque pra tocar/pausar).

---

## Sessão mais recente 7 — logo girando com a cor certa, Vortex em 2 colunas round-robin, perfil nas proporções do site, e cor do post (borda esquerda)

Pedido do usuário: comparar com o `driqy4` (site) e fechar 4 pontos que
ainda destoavam do site, com base em dois prints do site rodando no
navegador do celular (`WhatsApp_Image_2026-07-31...jpeg`).

### 1. Anel do logo girando com cor/formato diferente do site — corrigido

Achado o bug real: `AppGradients.brandRing` (`lib/theme/app_colors.dart`),
usado tanto no aneizinho da topbar/Drawer (`brand_title.dart`) quanto no
anel grande do login/cadastro (`brand_mark.dart`), estava definido como
`SweepGradient(colors: [amber, rose, rose, amber], stops: [0, 0.7, 0.7, 1.0])`
— um círculo **cheio**, sem nenhuma transparência. O site usa
`conic-gradient(from -90deg, var(--amber), var(--rose) 75%, transparent 75%)`
(`.brand-ring`/`.login-mark-ring` em `style.css`): 75% do círculo
interpola âmbar→rosa, e os **25% finais ficam transparentes** — é isso
que dá a cara de "C" aberto ao anel, não um círculo fechado. Corrigido
pra `colors: [amber, rose, transparent, transparent]` com
`stops: [0, 0.75, 0.75, 1.0]`, e a espessura do traço (que era um
`padding` fixo em pixels, sem relação com o tamanho do anel) virou
proporcional ao tamanho de cada widget, na mesma razão do CSS
(`4 / 22` pro anel pequeno, `~0.062` pro anel grande do login, calculado
a partir do `radial-gradient(farthest-side, transparent 87.6%, ...)` do
site).

### 2. Vortex — grade em 2 colunas "round-robin" com proporção nativa — corrigido

`lib/screens/pictures_screen.dart` usava um `GridView` de **3** colunas
com `childAspectRatio: 0.75` fixo — nem o número de colunas nem a
proporção das imagens batiam com o site. Estudado `static/js/vortex.js`
+ `style.css` (`.pictures-grid`/`.vortex-col`/`.picture-tile-img`): o
site monta **2 colunas** (celular) como colunas flex empilhadas, e cada
peça nova entra sempre na coluna `índice % 2` (round-robin) — nunca
reordena as que já estão lá quando a rolagem infinita acrescenta mais.
As imagens não são cortadas: ficam com `width: 100%; height: auto`
(proporção nativa do arquivo), sem `object-fit`, sem `border-radius`,
sem espaço nenhum entre peças (`gap: 0`).

Reescrito: duas `Column`s dentro de um `Row` (`Expanded` em cada uma),
distribuindo `_tiles` por `índice % 2`; cada peça (`_VortexTile`) mede a
proporção real da própria imagem com um `ImageStreamListener` (mesma
técnica que `post_card.dart` já usa em `_resolveImageSize`, só que
inline aqui) e usa exatamente essa razão na `AspectRatio` — como a caixa
já nasce do tamanho real, `BoxFit.cover` não corta nada. Vídeo não tem
como medir sem inicializar um player por peça (caro numa grade longa),
então usa uma caixa 4:5 fixa como aproximação, com ícone de play (o
autoplay mudo do site em `vortex.js` não foi replicado — ver "o que
falta" abaixo). Mantive o selo de avatar/@usuário no rodapé de cada
peça (não existe no site, mas não foi pedido pra tirar, e ajuda a saber
de quem é a foto) e troquei o "sem anel" por um selo simples de tempo
restante (sem cronômetro ao vivo por peça — a API de `/pictures` não
manda `created_at`/`duration_minutes`, só `seconds_remaining`, então não
dá pra alimentar o `CountdownRing` de verdade sem estender o backend).

### 3. Perfil nas mesmas proporções do site — corrigido

`lib/screens/profile_screen.dart`: a capa usava `height: 120` fixo (o
site usa `aspect-ratio: 3/1`) e o avatar ficava **ao lado** do nome
numa `Row` só (estilo Twitter) — o site faz diferente:
`.profile-header-top` só tem o avatar (96px, ou 66px no breakpoint
mobile que é o que interessa aqui) e os botões de ação
(editar/seguir+mensagem) numa mesma linha, com o avatar sobrepondo a
capa em `margin-top: -48px` (ou `-33px` mobile); nome, @usuário, bio,
localização/data de entrada e as estatísticas (`Seguindo → Seguidores →
posts ativos`) vêm **abaixo**, em `.profile-identity`, ocupando a
largura toda.

Reescrito `_buildCover`/`_buildHeader` pra seguir essa estrutura, usando
os valores do breakpoint mobile do `style.css`
(`@media (max-width: 640px)`: avatar 66px, borda 3px,
`margin-top: -33px`) já que o app só roda em tela de celular. O botão
"Seguir"/"Seguindo" e o ícone de mensagem foram pro canto superior
direito (ao lado do avatar), igual ao site, em vez de ficarem embaixo
de tudo.

### 4. Cor do post (borda esquerda) — corrigido

Achada a causa: no site, `_post_card.html` define
`style="--author-color: {{ post.author.accent_color|accent_hex }}"` no
`<article class="post-card">`, e o CSS aplica
`border-left: 3px solid var(--author-color, var(--border))` — a cor de
destaque que cada usuário escolhe no perfil (`accent_color`, o mesmo
campo que já existe em `DriqyUser`/`AppColors.accentFromKey`) aparece
como uma faixa de 3px na borda esquerda de **todo** post dele. O
Flutter (`lib/widgets/post_card.dart`) usava um `Card` do Material puro,
sem nenhuma borda colorida. Trocado por um `Container` com
`BoxDecoration.border` — 1px cinza (`--border`) nos outros três lados,
igual antes, e 3px com `AppColors.accentFromKey(post.author.accentColor)`
só na esquerda — mantendo o mesmo raio de canto, fundo e efeito de tap
(`Material` + `InkWell` por dentro, já que trocar `Card` por `Container`
tira o `InkWell` que ganhava o recorte automático do `Card`).
`post_detail_screen.dart` reaproveita o mesmo `PostCard`, então ganhou a
borda de graça.

### O que ainda falta (novo, desta sessão)

1. **Autoplay mudo dos vídeos do Vortex** (`playObserver`/`loadObserver`
   de `vortex.js`): o Flutter hoje só mostra um ícone de play estático
   pra vídeo na grade, sem carregar/tocar nada até o usuário abrir o
   post. Reproduzir o comportamento do site (tocar mudo quando ~60%
   visível, no máximo 1 por vez, carregar/descarregar a mídia perto da
   tela) dá pra fazer com `visibility_detector` ou `NotificationListener`
   de scroll + `VideoPlayerController`, mas é bastante código novo pra
   uma tela só — não mexido por ser risco maior sem conseguir compilar
   aqui.
2. **Anel de contagem regressiva de verdade nas peças do Vortex**: hoje
   é só um selo estático (o tempo restante no momento em que a peça
   chegou, sem contagem ao vivo). Pra ficar 100% igual ao site
   (`countdown.js`, que atualiza a cada segundo usando
   `data-duration`), o endpoint `GET /api/v1/pictures` (`api.py`)
   precisaria mandar também `duration_minutes` (ou `created_at`) por
   peça — hoje só manda `expires_at`/`seconds_remaining`. Mudança de
   backend, fora do escopo desta sessão (só Flutter).
3. **Sempre rodar `flutter analyze`/`flutter run` de verdade** — este
   ambiente continua sem o Flutter SDK (sem acesso a `pub.dev`), então,
   como em todas as sessões anteriores, nada foi compilado. Os arquivos
   tocados foram conferidos com um script de balanceamento de
   `()`/`{}`/`[]` e revisados por leitura, mas isso não substitui o
   compilador.
4. **Testar visualmente** depois do `flutter run` funcionar: conferir
   que o anel do topo/drawer/login gira com o "C" aberto (não mais um
   círculo cheio), que o Vortex mostra 2 colunas onde cada foto mantém
   sua proporção original sem cortar, que o cabeçalho do perfil bate
   com o print do site (avatar sobrepondo a capa, botões no canto
   superior direito, nome/bio/estatísticas abaixo), e que cada post no
   feed/perfil/detalhe mostra a faixa colorida na borda esquerda
   condizente com a cor de destaque escolhida pelo autor em
   "Editar perfil".

### Arquivos alterados nesta sessão

- `lib/theme/app_colors.dart` — `AppGradients.brandRing` corrigido
  (gradiente com vão transparente de 25%, igual ao CSS).
- `lib/widgets/brand_title.dart` — espessura do `BrandRing` proporcional
  ao tamanho.
- `lib/widgets/brand_mark.dart` — espessura do anel grande proporcional
  ao tamanho.
- `lib/screens/pictures_screen.dart` — reescrito: 2 colunas round-robin
  (`_VortexTile` mede a proporção real da imagem), badge de tempo
  restante simples no lugar do anel completo.
- `lib/screens/profile_screen.dart` — `_buildCover`/`_buildHeader`
  reescritos pra seguir a estrutura/proporções do
  `profile.html`+`style.css` (capa 3:1, avatar 66px sobrepondo -33px,
  ações no canto superior direito, identidade abaixo).
- `lib/widgets/post_card.dart` — `Card` trocado por `Container` com
  borda esquerda de 3px na cor de destaque do autor
  (`--author-color`/`accent_color`).

---

## Sessão mais recente 6 — removida a exclusão manual de post (o post só some sozinho, no tempo definido pelo autor)

Correção do usuário: "o autor não pode apagar o post quando quer, o
post apaga sozinho no tempo predefinido pelo autor". Ou seja, o post é
efêmero por natureza (como o `CountdownRing`/anel de contagem
regressiva já mostra) — some sozinho quando o tempo escolhido na
publicação (`duration_minutes`) acaba. Não existe (e não deve existir)
um botão de "apagar agora" no app.

Isso corrige um engano meu de uma sessão anterior: eu tinha registrado
no LEIA-ME que o botão de lixeira era "pro autor do post **ou**
qualquer staff", mas na real o código Flutter só mostrava o botão pra
`isStaff` (nunca pro autor comum) — de qualquer forma, o pedido agora é
**remover esse botão por completo**, já que a sessão anterior também
tirou o item "Moderação" do Drawer (não faz sentido manter uma ação de
moderação avulsa dentro do card do post se a moderação inteira não vai
existir no app).

### O que foi feito

- `lib/widgets/post_card.dart`: removidos o botão de lixeira
  (ícone `Icons.delete_outline`) da barra de ações do post, o método
  `_confirmDelete()` (diálogo de confirmação + chamada à API), o campo
  de estado `_deleting` e a variável `canModerate`
  (`me != null && me.isStaff`) que controlava a visibilidade do botão.
  O post agora só desaparece da tela por um único caminho:
  `_handleExpired()`, chamado pelo `CountdownRing` quando o anel chega
  a zero (`onExpired: _handleExpired` — isso não mudou).
- `lib/services/post_service.dart`: removido o método `deletePost()`
  (chamava `DELETE /api/v1/posts/<id>`). Não há mais nenhum lugar no
  app que chame essa rota.
- Conferido com `grep -rn "deletePost|_confirmDelete|_deleting|canModerate"
  lib` que não sobrou nenhuma referência.

### O que **não** foi mexido (de propósito)

- **`ApiClient.delete()`** (`lib/services/api_client.dart`) continua
  existindo — é só o verbo HTTP genérico (`http.delete`), não uma
  função específica de "apagar post". Fica sem uso por enquanto, mas
  não é um "traço de moderação": é infraestrutura genérica que outra
  feature (ex.: apagar uma mensagem) pode acabar usando depois. Se
  quiser que eu tire ele também, é só pedir.
- **Backend (`api.py`/`admin.py`) não foi tocado** — o endpoint
  `DELETE /api/v1/posts/<id>` (documentado nas sessões anteriores deste
  LEIA-ME) continua existindo do lado do servidor, se ele já estiver
  aplicado aí. O app Flutter simplesmente parou de chamá-lo. Não tive
  acesso ao `driqy4`/backend nesta sessão (só ao projeto Flutter), então
  não posso confirmar nem alterar o que está rodando no seu servidor —
  se quiser remover a rota também por lá, isso é uma mudança separada
  no Flask.
- **`isStaff`** continua existindo em `models/user.dart` (só
  repassando o campo do JSON, sem nenhuma UI usando ele agora — nem
  Drawer, nem botão de apagar). Deixei porque é só um campo de dados,
  sem efeito colateral nenhum; se preferir, posso tirar também.

### Arquivos alterados nesta sessão

- `lib/widgets/post_card.dart` — botão de apagar post, `_confirmDelete`,
  `_deleting` e `canModerate` removidos.
- `lib/services/post_service.dart` — `deletePost()` removido.

---

## Sessão mais recente 5 — item "Moderação" removido do Drawer (decisão do usuário: não vai ser feito)

Pedido do usuário: "remova todo tipo de traço de tela de moderação no
app Android e no iOS pois não vai precisar".

Nunca existiu de fato uma **tela** de moderação no Flutter (nenhum
`moderation_screen.dart`, nenhum `ModerationService` — só tinha sido
planejada em sessões anteriores, ver histórico abaixo). O único
vestígio no código era o item **"Moderação"** no menu lateral
(`lib/screens/home_shell.dart`), visível só pra usuários com
`isStaff == true`, que ao tocar só mostrava um aviso
("Painel de moderação ainda não está disponível neste app — use o
site por enquanto.") em vez de abrir algo de verdade.

### O que foi feito

- **Removido por completo** o `_DrawerItem` de "Moderação" (ícone de
  escudo, cor vermelha, o `SnackBar` de aviso — tudo) de
  `lib/screens/home_shell.dart`. O menu agora vai direto de "Meu
  perfil" pro divisor + "Sair", igual a qualquer usuário (staff ou
  não) — não existe mais nenhuma bifurcação por `isStaff` no Drawer.
- Atualizado o comentário de documentação da classe `HomeShell` (que
  citava "Moderação (se for staff)" na lista de itens do Drawer).
- Confiro com `grep -rniE "moderat" lib` que não sobrou mais nenhuma
  referência a moderação em código Dart, fora deste próprio LEIA-ME
  (que é histórico/documentação, não código).

### O que **não** foi mexido (de propósito)

> **Nota da sessão 6**: o parágrafo abaixo descrevia o botão de apagar
> post que existia nesta época. Esse botão **foi removido na sessão
> 6** (ver topo deste arquivo) — o texto original ficou só por
> histórico, não reflete mais o estado atual do código.

- ~~`isStaff` continua existindo em `models/user.dart` e sendo usado
  em `post_card.dart` (botão de apagar post, visível pro autor **ou**
  staff)~~ — e em `profile_screen.dart`/`search_screen.dart` (só
  repassando o campo do JSON pro modelo, isso continua igual). Isso
  **não é** "tela de moderação" — é
  uma ação pontual dentro do próprio card do post (apagar), separada
  do painel de moderação que a versão web tem em `admin.py`. Não removi
  porque o pedido foi especificamente sobre a *tela*/menu de moderação,
  não sobre a permissão de apagar posts. ~~Se quiser que staff também
  perca esse botão de apagar posts de outras pessoas, é só avisar numa
  próxima sessão — hoje ele continua igual a antes.~~
- **Backend (`api.py`) não foi tocado** — o campo `is_staff` que o
  servidor manda no JSON do usuário continua existindo lá; só o menu no
  app parou de usar ele pra mostrar um item de navegação. Se quiser
  também limpar isso do lado do servidor (ex.: parar de mandar
  `is_staff` no JSON), isso é uma mudança separada no Flask, fora do
  escopo do Flutter.

### Arquivo alterado nesta sessão

- `lib/screens/home_shell.dart` — item "Moderação" removido do Drawer;
  comentário da classe atualizado.

---

## Sessão mais recente 4 — ícone do app, topbar (busca/mensagens/notificações) e proporção real das imagens do feed

Pedido do usuário: o app Flutter ainda não estava igual à versão web —
faltava a barra de busca e os ícones de mensagens/notificações no topo
do Feed, as imagens do feed não respeitavam a proporção das imagens da
versão web, e o app não tinha o logo do Driqy como ícone (ainda usava o
ícone padrão azul do Flutter). O usuário anexou a logo (`aa.PNG`, o
anel âmbar→rosa em fundo preto, 100x100) e dois prints do app rodando
(mostrando a topbar do site que faltava replicar).

### 1. Ícone do app — feito

O ícone padrão do Flutter (o "V" azul) foi substituído em **todas** as
plataformas, gerado a partir do `aa.PNG` anexado (script Python com
Pillow, já que não há `flutter_launcher_icons` disponível sem
`pub.dev`):

- **Android**: `android/app/src/main/res/mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png`
  (48/72/96/144/192px).
- **iOS**: todo o `ios/Runner/Assets.xcassets/AppIcon.appiconset/*.png`
  (20x20 até 1024x1024, todas as densidades @1x/@2x/@3x — convertidas
  pra RGB sem alpha, que é obrigatório pra ícone de App Store).
- **Web**: `web/icons/Icon-192.png`, `Icon-512.png`,
  `Icon-maskable-192.png`, `Icon-maskable-512.png` (as versões
  "maskable" têm ~20% de margem de segurança ao redor da logo, com o
  fundo `#121016` da marca, pro Android não cortar o anel quando aplica
  a máscara adaptactiva) e `web/favicon.png` (16x16).
- **Nome do app**: trocado de "driqy_flutter" pra "Driqy" em
  `android/app/src/main/AndroidManifest.xml` (`android:label`),
  `ios/Runner/Info.plist` (`CFBundleDisplayName`/`CFBundleName`),
  `web/manifest.json` (`name`/`short_name`, além da
  `background_color`/`theme_color` que eram o azul padrão do Flutter
  `#0175C2` e viraram `#121016`, a cor de fundo do site) e
  `web/index.html` (`<title>`, meta de descrição, `apple-mobile-web-app-title`).

**Não mexido**: ícones do macOS/Windows/Linux (`macos/Runner/Assets.xcassets`,
`windows/runner/resources/app_icon.ico`) continuam com o ícone padrão —
o pedido e os prints eram sobre o app mobile; se for publicar versão
desktop, é só repetir o mesmo processo (redimensionar `aa.PNG` pros
tamanhos que cada plataforma pede) — o script usado está descrito
abaixo em "Como o ícone foi gerado", pra não precisar reinventar.

### 2. Topbar do Feed (busca + mensagens + notificações) — feito

Novo arquivo `lib/widgets/driqy_top_bar.dart`, plugado no
`feed_screen.dart` no lugar da AppBar simples de antes (que só tinha
☰ + logo). Espelha o `.topbar` do site (`templates/base.html`):

- **Caixa de busca** ("Buscar no Driqy", com ícone de lupa, pílula com
  fundo `surface2` e borda — visual igual à `.topbar-search` do CSS).
  É **somente toque** (não digita ali): tocar abre a `SearchScreen` de
  verdade, que já tinha o campo de texto funcional. Não implementei o
  dropdown de sugestões ao digitar que o site tem
  (`#search-dropdown`/`search.js`) diretamente na topbar — ver "o que
  falta" abaixo.
- **Ícone de mensagens** (balão de chat) e **ícone de notificações**
  (sino), cada um com um badge vermelho circular de contagem não lida
  — mesma ideia do `.notif-badge` do site. Os dois já tinham o método
  `getUnreadCount()` prontos em `MessageService`/`NotificationService`
  (não usados em lugar nenhum até então); a topbar consulta os dois ao
  abrir e depois a cada 30s (`Timer.periodic`) e de novo ao voltar de
  `MessagesInboxScreen`/`NotificationsScreen` (pra já descontar o que
  acabou de ler). Tocar neles empurra pra tela cheia correspondente
  (as duas já existiam, só não eram alcançáveis por aqui).

Só apliquei essa topbar nova no **Feed** (é a tela do print que o
usuário mandou). `SearchScreen`, `NotificationsScreen` e
`ProfileScreen` continuam com as AppBars simples de antes (a
`SearchScreen`, inclusive, PRECISA continuar com o campo de texto de
verdade dela — não faria sentido pôr a pílula somente-toque lá dentro
também). Se quiser a mesma topbar (com os 2 ícones) nas outras abas
também, dá pra reaproveitar `DriqyTopBar(onOpenMenu: ...)` diretamente
no lugar da AppBar de cada uma — é só trocar, o widget já é
independente.

### 3. Proporção real das imagens do feed — feito

Esse era o problema mais visível dos prints: toda foto do feed
(sozinha ou em carrossel) usava um `AspectRatio(aspectRatio: 4 / 3)`
**fixo**, plantado direto no código, sem nenhuma relação com o
tamanho real do arquivo — por isso fotos verticais (retrato, a maioria
dos posts feitos com celular) apareciam cortadas/espremidas na largura
errada.

A versão web resolve isso em `static/js/media-orient.js`: mede a
proporção real da imagem (`naturalWidth`/`naturalHeight`) assim que ela
carrega e classifica em só 3 molduras fixas (pra não ficar cada post
com uma altura diferente):
- **paisagem** (`largura/altura > 1.15`): caixa 3:2, sem limite de
  largura (`.post-media.media-landscape img` no `style.css`);
- **retrato OU quadrada** (todo o resto): caixa 4:5, com até 420px de
  largura — a versão web explicitamente usa a **mesma** caixa pras
  duas (comentário no `style.css`: "quadrada usa a mesma caixa do
  retrato").

Reescrevi `lib/widgets/post_card.dart` (`_PostMedia`/`_PostImage`,
mais uma classe nova `_MediaBox`) pra fazer a mesma coisa: uma função
`_resolveImageSize()` abre um `ImageStreamListener` no
`NetworkImage` pra descobrir a largura/altura reais antes da imagem
terminar de carregar (equivalente ao `addEventListener("load", ...)`
do JS), e o resultado decide a caixa (`AspectRatio` + `maxWidth` +
`BoxFit.cover`, replicando exatamente as duas molduras acima).
Enquanto a medição não termina, usa a caixa 4:5 como padrão (mesmo
comportamento do CSS antes do JS classificar, que já nasce com uma
caixa razoável). Pro **carrossel** (mais de uma foto), a proporção do
**primeiro item** decide a caixa do carrossel inteiro — os outros
slides só preenchem essa caixa já pronta (`BoxFit.cover`), igual ao
comentário do `media-orient.js` original ("todos os slides precisam
ter a mesma altura pra rolagem funcionar direito").

**Vídeo não foi tocado**: `PostVideoPlayer` continua usando a
proporção nativa do vídeo sem cortar nada (`BoxFit` implícito do
próprio `VideoPlayer`, sem `cover`), diferente do site que também
teria vídeo dentro das mesmas 3 molduras com `object-fit: cover`
(`.video-wrap`/`.feed-video` no CSS). Não mudei porque (a) os prints
do usuário eram só sobre fotos, e (b) cortar vídeo é uma decisão mais
sensível (perde conteúdo nas bordas) que preferi não tomar sem
confirmação. Se quiser paridade 100% com o site aqui também, é só
aplicar a mesma `_MediaBox.classify()` (dá pra pegar a proporção do
vídeo depois de `controller.initialize()`, com
`controller.value.size.width/height`) e trocar o `AspectRatio` do
`PostVideoPlayer` pra usar a caixa em vez da proporção nativa, com
`BoxFit.cover` no `VideoPlayer`.

**`pictures_screen.dart` (Vortex/grade) também não foi tocado**: no
site, `.picture-tile-img` **não** usa nenhuma das 3 molduras — a
imagem mantém a proporção original sem cortar nada (`height: auto`,
sem `object-fit`). O Flutter usa `childAspectRatio: 0.75` fixo no
`GridView`, o que também não bate 100% com o site, mas isso é uma tela
separada que não apareceu nos prints desta sessão — fica registrado
aqui caso seja pedido depois.

### Como o ícone foi gerado (pra repetir em outras plataformas)

```python
from PIL import Image
src = Image.open('aa.PNG').convert('RGBA')  # a logo anexada, 100x100

def resized(size):
    return src.resize((size, size), Image.LANCZOS)

# ícone "normal": só redimensiona
resized(192).save('saida.png')

# ícone "maskable" (Android adaptativo): logo menor no centro, com
# fundo #121016, deixando ~20% de margem de segurança
def maskable(size, pad_ratio=0.20):
    canvas = Image.new('RGBA', (size, size), (18, 16, 22, 255))
    inner = int(size * (1 - pad_ratio))
    logo = src.resize((inner, inner), Image.LANCZOS)
    offset = (size - inner) // 2
    canvas.paste(logo, (offset, offset), logo)
    return canvas
```

Pra iOS, depois de redimensionar, converter pra RGB (`.convert('RGB')`)
antes de salvar — ícone de App Store não pode ter canal alpha.

### Continua bloqueado neste ambiente (sem solução nesta sessão)

Igual a todas as sessões anteriores: **sem Flutter SDK nem acesso de
rede a `pub.dev`/`storage.googleapis.com`**, então nada foi compilado
de verdade nesta sessão também. Todo o código novo foi conferido à mão
(um script Python de balanceamento de `()`/`{}`/`[]` em **todos** os
arquivos `.dart` do projeto, não só os alterados) e revisado por
leitura, mas **isso não substitui o compilador**. Primeiro comando a
rodar antes de mexer em mais qualquer coisa, sempre:

```
flutter pub get
flutter analyze
flutter run
```

Meus melhores palpites de onde pode aparecer algo pequeno pro
`flutter analyze` reclamar (nada estrutural, mas não rodei o
compilador de verdade pra confirmar):
- `driqy_top_bar.dart`: primeira vez que o projeto usa
  `ImageStreamListener`/`NetworkImage.resolve()` diretamente (fora do
  `Image` widget pronto) — a API é estável no Flutter mas vale
  conferir a assinatura exata da versão do SDK que você tiver
  instalada, pode ter mudado entre versões.
- Os três `import '../screens/...'` novos dentro de
  `lib/widgets/driqy_top_bar.dart` (uma pasta `widgets/` importando
  `screens/`) — não é errado em Dart (não existe essa separação
  imposta pelo compilador), mas é diferente do padrão que o resto do
  projeto seguia até aqui (services → screens → widgets, nunca o
  contrário). Deixei assim pra não precisar duplicar as telas de
  Mensagens/Notificações; se preferir manter a convenção, dá pra
  extrair só a navegação pra fora do widget (ex.: `driqy_top_bar.dart`
  recebe `onOpenMessages`/`onOpenNotifications` como callbacks, e quem
  monta esses callbacks — o `feed_screen.dart` ou o `home_shell.dart`
  — é quem importa as telas).

### O que falta (herdado + novo)

1. **Rodar `flutter analyze` de verdade** — sempre a prioridade #1.
2. ~~Tela de Moderação~~ — **decisão da sessão 5: não vai ser feita.**
   O usuário confirmou que o app não vai precisar de tela de moderação.
   O único traço que existia (item "Moderação" no Drawer, que só
   mostrava um aviso "ainda não disponível") foi removido — ver a
   seção da sessão 5 no topo deste arquivo.
3. **Dropdown de sugestões ao digitar na busca da topbar** — o site
   mostra resultados em tempo real embaixo da caixa
   (`#search-dropdown`) sem precisar trocar de tela; o Flutter, por
   enquanto, só abre a `SearchScreen` inteira ao tocar. Funcional, mas
   não é pixel-a-pixel igual ao site.
4. **Aplicar a mesma `DriqyTopBar` (com busca/mensagens/notificações)
   nas outras abas** (Notificações, Perfil), se fizer sentido — hoje
   só o Feed tem. A `SearchScreen` deve continuar com a AppBar dela
   própria (o campo de busca de verdade), não com a pílula
   somente-toque.
5. **Vídeo do feed dentro das mesmas 3 molduras com corte
   (`object-fit: cover`)**, pra bater 100% com o site — ver a seção 3
   acima pra o porquê de não ter mexido e como fazer se for pedido.
6. **Vortex (`pictures_screen.dart`)**: `childAspectRatio: 0.75` fixo
   no grid não é como o site trata essas imagens (lá é altura livre,
   sem cortar) — não mexido por não estar nos prints desta sessão.
7. **Compartilhar nativo de verdade** (`share_plus`, precisa de
   internet pra instalar).
8. **Testar visualmente** depois do `flutter run` funcionar: abrir o
   Feed e conferir que fotos verticais/quadradas aparecem inteiras
   (não mais cortadas em 4:3), fotos horizontais ficam numa caixa mais
   larga e baixa, o carrossel mantém a mesma altura em todos os
   slides, a pílula de busca abre a tela de busca, os badges de
   mensagens/notificações aparecem com o número certo e somem depois
   de ler, e o ícone do app (na tela inicial do celular/aba do
   navegador) já é o anel âmbar→rosa em vez do "V" azul do Flutter.

### Arquivos alterados/criados nesta sessão

- `lib/widgets/driqy_top_bar.dart` — **novo arquivo**: topbar do Feed
  (busca + mensagens + notificações com badge).
- `lib/screens/feed_screen.dart` — troca da AppBar simples pela
  `DriqyTopBar`.
- `lib/widgets/post_card.dart` — `_PostMedia`/`_PostImage` reescritos
  pra classificar a proporção real da imagem em vez do
  `AspectRatio(4/3)` fixo; nova classe `_MediaBox` e função
  `_resolveImageSize()`.
- Ícones: todos os `android/app/src/main/res/mipmap-*/ic_launcher.png`,
  todo o `ios/Runner/Assets.xcassets/AppIcon.appiconset/*.png`, todo o
  `web/icons/*.png` e `web/favicon.png`.
- Nome/tema do app: `android/app/src/main/AndroidManifest.xml`,
  `ios/Runner/Info.plist`, `web/manifest.json`, `web/index.html`.

---

## Sessão mais recente 3 — itens pendentes do LEIA-ME finalizados

Pedido do usuário: "consegue terminar o que falta do leiame".

Da lista de pendências, o que dava pra fechar **sem precisar do Flutter
SDK** (que continua indisponível neste ambiente) foi feito:

### 1. Respostas aninhadas nos comentários (item 5 antigo) — feito

- `lib/widgets/comment_tile.dart`: reescrito. Agora exporta
  `buildCommentTree(List<DriqyComment>)`, que monta a árvore a partir do
  `parent_id` que a API já manda (igual ao `_comment_fragment.html` do
  site), e `CommentTile` virou recursivo — desenha o comentário e,
  indentadas, as respostas dele. Tem um "Responder" embaixo de cada
  comentário.
- `lib/widgets/post_card.dart` (comentários inline do card) e
  `lib/screens/post_detail_screen.dart` (tela de detalhe): os dois agora
  usam `buildCommentTree` + `CommentTile(onReply: ...)`. Tocar em
  "Responder" foca o campo de texto e mostra "Respondendo a @fulano"
  acima dele (com um "x" pra cancelar); o `parentId` vai junto na
  chamada de `PostService.addComment` (esse parâmetro já existia no
  serviço, só não era usado por ninguém).
- Antes disso eu tinha entendido errado que já existia alguma resposta
  "só na tela de detalhe" — na verdade não existia em lugar nenhum
  (nem lá, nem no card). Os dois lugares foram corrigidos juntos.

### 2. Composer também no próprio perfil (item 3 antigo) — feito

- `lib/screens/profile_screen.dart`: quando `user.isMe` é verdadeiro
  (você olhando seu próprio perfil), o mesmo `InlinePostComposer` do
  Feed aparece logo abaixo do cabeçalho — igual ao print
  (`WhatsApp_Image_2026-07-30_at_23_05_59_1_.jpeg`, perfil "@tester" com
  a caixa "O que está acontecendo?"). Publicar recarrega a lista de
  posts do perfil (`_loadPosts(reset: true)`).

### 3. Backend estava desatualizado em relação ao Flutter — corrigido

Ao abrir o `driqy4.rar` pra conferir os endpoints (precisava confirmar
o formato de `parent_id` nos comentários), percebi duas coisas que iam
quebrar recursos que o Flutter **já** tinha pronto:

- `serialize_user()` em `api.py` não devolvia `created_at`,
  `active_posts_count` nem `is_staff` — o modelo `User` já tem tudo
  isso (`models.py`, propriedades `is_staff`/`active_posts_count` e a
  coluna `created_at`), só não estava sendo exposto no JSON. Sem isso,
  o "Entrou em [mês/ano]" do perfil nunca aparece e o item "Moderação"
  do Drawer nunca fica visível pra ninguém (porque `user.isStaff`
  sempre chegava `false`). **Corrigido**: as três chaves foram
  adicionadas em `serialize_user`.
- Não existia `DELETE /api/v1/posts/<id>` — mas o botão de lixeira do
  `post_card.dart` (que já existia, de uma sessão anterior) chama
  exatamente esse endpoint. Sem ele, tocar em "apagar" ia dar erro
  404/405 sempre. **Corrigido**: endpoint novo, espelhando a lógica do
  `admin.delete_post` (apaga os arquivos de mídia do post e o registro),
  mas autenticado por token Bearer (como o resto de `api.py`) em vez de
  sessão de navegador, e liberado pro autor do post **ou** qualquer
  staff (`user.is_staff`).

Esse patch está só em **`api.py`** — é o único arquivo do backend que
mudou. Ele está anexado separadamente a esta entrega
(`api.py`, fora do zip do Flutter) pra você substituir o seu, **sem**
mexer no restante do `driqy4/` (banco, uploads, etc). Se o seu servidor
"de produção" já tiver essas correções feitas de outro jeito, só
compare antes de sobrescrever.

### O que continua bloqueado neste ambiente (sem solução nesta sessão)

1. **`flutter analyze` / compilar de verdade.** Sem Flutter SDK e sem
   acesso de rede a `storage.googleapis.com`/`pub.dev` daqui, não dá
   pra rodar. Todo o código novo foi revisado à mão (imports, chamadas,
   assinaturas de método batendo, nenhuma referência a símbolo
   removido) mas isso não substitui o compilador. **Primeiro comando a
   rodar antes de mexer em mais nada.**
2. **Compartilhar nativo (`share_plus`)**: precisa baixar o pacote,
   sem internet aqui pra isso.
3. **Testar visualmente** — depende do item 1.

### Sobre a Tela de Moderação (não feita — motivo)

Essa é a peça grande que ainda falta pra fechar o menu lateral. Não dá
pra fazer só no Flutter: o `admin.py` do site é **server-rendered**
(HTML + `flask_login` por cookie de sessão), enquanto o app fala com
`api.py` por **token Bearer** — são dois mecanismos de autenticação
diferentes, então o app não consegue chamar as rotas de `/admin/...`
direto. Pra existir no app, precisa de rotas JSON novas em `api.py`
(protegidas por `@api_login_required` + checagem de `user.is_staff`,
igual ao `DELETE /posts/<id>` que acabei de adicionar), espelhando o
que já existe em `admin.py`:

- `GET /api/v1/admin/posts` (lista paginada — reaproveita a query de
  `admin.posts`)
- `GET /api/v1/admin/users` (idem, `admin.users`)
- `POST /api/v1/admin/users/<id>/banir` / `desbanir`
- `POST /api/v1/admin/users/<id>/tornar-moderador` / `remover-moderador`
  (esses dois exigem `is_admin`, não só `is_staff` — olhar
  `admin_required` vs `staff_required` em `admin.py` pra replicar a
  regra certa em cada rota nova)

Do lado do Flutter, aí sim é só depois: uma tela nova
(`moderation_screen.dart`) + `ModerationService` reaproveitando o
padrão de `UserService`/`PostService`, e trocar o `SnackBar` de aviso
que hoje aparece no item "Moderação" do Drawer por
`Navigator.push(... ModerationScreen())`. Não fiz essa parte agora por
ser a maior peça pendente e por envolver decidir regras de permissão
(admin vs moderador) que preferi documentar em vez de adivinhar.

---

## Sessão mais recente 2 — Ranking removido de vez

Pedido do usuário: "remova o ranking, não existe mais no site nem no
app".

O item 4 da lista de pendências (abaixo) ficou resolvido assim: em vez
de decidir onde colocar um link pro Ranking, ele foi **removido por
completo** do Flutter, já que não existe mais no site.

Arquivos apagados:
- `lib/screens/ranking_screen.dart`
- `lib/services/ranking_service.dart`
- `lib/models/ranking_entry.dart`

Nenhum outro arquivo referenciava esses três (o ícone de Ranking na
AppBar do Feed já tinha sido removido na sessão anterior, junto com os
outros 3 ícones) — confirmado com `grep -rn "ranking\|Ranking" lib`
sem nenhum resultado depois da remoção.

---

## Sessão mais recente — rodapé/AppBar removidos + postar direto no feed

Pedido do usuário: "muita coisa no app flutter não tem a ver com a
versão web (`driqy4`); remova os botões do rodapé e os 4 do canto
superior direito do Feed; coloque o modo de postar direto no feed, como
no print do site".

### O que foi feito

1. **Removida a barra inferior (rodapé) da `HomeShell`**
   (`lib/screens/home_shell.dart`). A `NavigationBar` com
   Feed/Buscar/Postar/Avisos/Perfil não existe mais. Toda a navegação
   agora passa pelo Drawer (menu ☰), que já existia. Como o item
   "Buscar" só existia na barra inferior, adicionei um item "Buscar" no
   Drawer pra não perder o acesso a `SearchScreen`.
2. **Removidos os 4 ícones do canto superior direito do Feed**
   (`lib/screens/feed_screen.dart`): Vortex (grade), Ranking
   (troféu/leaderboard), Mensagens (envelope) e Sair (logout). A AppBar
   do Feed agora só tem o ☰ (abre o Drawer) e o logo "Driqy", igual ao
   print (`WhatsApp_Image_2026-07-30_at_23_00...jpeg`). Vortex,
   Mensagens e Sair continuam acessíveis pelo Drawer; Ranking não tinha
   link no site (ver item 6 do histórico anterior) e por isso não foi
   recolocado em lugar nenhum — se for pra manter acessível, precisa de
   uma decisão de onde ele deveria aparecer.
3. **Composer "O que está acontecendo?" direto no topo do Feed**
   — item 3 da lista de pendências da sessão anterior, agora feito.
   Novo widget `lib/widgets/inline_post_composer.dart`:
   - Caixa de texto "O que está acontecendo?", chip "Some em `<duração>`"
     (abre uma lista com os mesmos presets de duração de antes: 1
     minuto até 1 ano), botão "+" pra anexar foto(s) ou vídeo, e botão
     "Postar" com o gradiente da marca (`GradientButton`) — visualmente
     equivalente ao bloco do print
     (`WhatsApp_Image_2026-07-30_at_23_00...jpeg` /
     `..._23_05_59...jpeg`, o card acima do feed com "O que está
     acontecendo?" + "Some em 1 dia" + "+" + "Postar").
   - Ao publicar com sucesso, limpa o campo e chama `onPosted`, que no
     Feed é `_loadFirstPage` — o post novo aparece no topo na hora,
     sem precisar trocar de tela.
   - **Removida** a tela separada `lib/screens/create_post_screen.dart`
     (não é mais usada em lugar nenhum — era só alcançável pelo botão
     "+" da barra inferior, que também foi removida). A constante
     `kDurationPresets` (presets de duração) foi movida pra dentro do
     próprio `inline_post_composer.dart`.
   - O composer só foi colocado no **Feed**, que é o que o print mostra
     e o que foi pedido. O perfil próprio (`profile_screen.dart`) também
     tem um composer igual no site — não mexi lá por não ter sido
     pedido explicitamente; ver "o que falta" abaixo se quiser
     replicar.

### Continua sem Flutter SDK neste ambiente

Assim como nas sessões anteriores, **não há Flutter SDK nem acesso de
rede a `pub.dev`/`storage.googleapis.com`/etc. neste ambiente**, então
nada foi compilado de verdade. Todo o código foi revisado manualmente
(imports, referências a símbolos removidos, chaves/parênteses), mas o
primeiro passo de quem continuar é:

```
flutter pub get
flutter analyze
flutter run
```

Erros esperados de serem pequenos (tipagem, algum import faltando) —
não é código reescrito do zero, foram edições cirúrgicas em cima de um
app que a sessão anterior já vinha testando visualmente pouco a pouco.

### O que falta (herdado + novo)

1. **Rodar `flutter analyze` de verdade** (prioridade #1, igual sempre).
2. **Tela de Moderação** — ainda não existe (ver detalhes no histórico
   abaixo, seção "O que ainda falta" da sessão anterior, item 2).
3. **Replicar o composer inline também no `profile_screen.dart`**, se
   fizer sentido pro fluxo do app — no site o composer aparece tanto no
   feed global quanto no próprio perfil
   (`WhatsApp_Image_2026-07-30_at_23_05_59_1_.jpeg`). É só reaproveitar
   `InlinePostComposer(onPosted: ...)` de novo lá, recarregando os
   posts do perfil depois de postar.
4. **Compartilhar nativo de verdade** (precisa de `share_plus`, sem
   internet pra instalar aqui).
5. **Respostas aninhadas nos comentários inline do card do feed.**
6. **Testar visualmente** depois do `flutter run` funcionar: abrir o
   Drawer em cada aba (Feed/Buscar/Notificações/Perfil agora sem barra
   inferior), postar pelo composer novo do Feed (com e sem mídia,
   trocando a duração), conferir que o post aparece na hora no topo.

### Arquivos alterados/criados nesta sessão

- `lib/screens/home_shell.dart` — removida `bottomNavigationBar`,
  removido fluxo de `_openCreatePost`, adicionado item "Buscar" no
  Drawer.
- `lib/screens/feed_screen.dart` — removidos os 4 `IconButton` da
  AppBar; composer inline inserido no topo do corpo; removidas
  dependências de `MessageService`/`PicturesScreen`/`RankingScreen`
  que só existiam pra alimentar esses ícones.
- `lib/widgets/inline_post_composer.dart` — **novo arquivo**, composer
  "O que está acontecendo?" reutilizável.
- `lib/screens/create_post_screen.dart` — **removido** (tela separada
  de postar, substituída pelo composer inline).

---

## Histórico de sessões anteriores

## Contexto importante (não mudou)

- **Não há Flutter SDK neste ambiente**, nem acesso de rede a `pub.dev`.
  Nenhuma dependência nova foi adicionada — só as que já estavam no
  `pubspec.yaml` (`video_player`, `provider`, `http`, `intl`,
  `shared_preferences`, etc). Todo o código foi revisado visualmente e
  com um script de balanceamento de parênteses/chaves/colchetes, mas
  **nunca foi compilado de fato**. Primeiro passo de quem continuar:
  ```
  flutter pub get
  flutter analyze
  flutter run
  ```
  Corrija qualquer erro de tipo/sintaxe que o `flutter analyze` apontar
  antes de mais nada — é bem provável que apareça algo pequeno, já que
  ninguém rodou o compilador ainda.
- O servidor de referência é o Flask em `driqy4.rar` (backend real por
  trás do app). Ele **não foi alterado nesta sessão** (a sessão anterior
  havia mexido em `api.py` — ver histórico abaixo). Se você tiver o
  servidor rodando localmente, é contra ele que dá pra testar o app.

## O que foi feito nas sessões anteriores (resumo)

### Backend (`server/driqy4/api.py`, sessão anterior)
- `serialize_user()` passou a devolver `created_at`, `active_posts_count`
  e `is_staff`.
- `serialize_post()` passou a devolver `source_client`.
- Novo endpoint `DELETE /api/v1/posts/<id>` (autor ou staff apaga post).

### Flutter (sessão anterior)
- Modelos (`user.dart`, `post.dart`) e serviços atualizados para os
  campos novos acima.
- `post_card.dart`: rótulo "Post via Android/iPhone", comentários
  inline no card, botão de apagar post (staff/autor), player de áudio
  de verdade (`post_audio_player.dart`), lightbox de imagem com zoom
  (`media_lightbox.dart`).
- `profile_screen.dart`: "Entrou em [mês] de [ano]" e "N posts ativos".

Nada disso foi revertido — esta sessão construiu em cima.

## O que foi feito NESTA sessão

O pedido era "o app Flutter não bate com a versão web — imite a versão
web". O maior problema estrutural encontrado: **telas inteiras já
existiam no código Flutter (Mensagens, Vortex/Pictures, Ranking) mas não
tinham como ser abertas** — não estavam em nenhum menu, nenhuma aba,
nenhum botão visível (só alguns ícones soltos na AppBar do Feed). E não
existia nenhum menu lateral (☰) equivalente à sidebar do site
(`templates/base.html`), que é onde ficam Feed / Vortex / Mensagens /
Notificações / Meu perfil / Moderação / Sair — exatamente o que aparece
nos seus prints (`WhatsApp_Image..._23_00...jpeg`).

### 1. Menu lateral (Drawer) — `lib/screens/home_shell.dart`

- Adicionado um `Drawer` na `HomeShell` com os mesmos itens da sidebar
  do site, na mesma ordem:
  **Feed → Vortex → Mensagens → Notificações → Meu perfil → Moderação
  (só aparece se `user.isStaff`) → Sair**.
- "Vortex" abre `PicturesScreen` (já existia, só não era alcançável).
- "Mensagens" abre `MessagesInboxScreen` (idem).
- "Feed", "Notificações" e "Meu perfil" trocam a aba ativa da
  `IndexedStack` (mesmo comportamento da barra inferior).
- "Sair" chama `AuthService.logout()`.
- **Cuidado técnico**: cada aba (`FeedScreen`, `SearchScreen`,
  `NotificationsScreen`, `ProfileScreen`) já tinha a sua própria
  `AppBar`. Para não empilhar duas AppBars, a `HomeShell` **não** ganhou
  uma AppBar própria — em vez disso, cada uma dessas 4 telas ganhou um
  parâmetro opcional `onOpenMenu` (`VoidCallback?`) que, quando
  fornecido, faz aparecer um botão ☰ na AppBar de cada uma (substituindo
  o `leading` padrão). A `HomeShell` guarda um
  `GlobalKey<ScaffoldState>` e passa
  `onOpenMenu: () => _scaffoldKey.currentState?.openDrawer()` pras 4
  telas quando as usa como aba.
  - `ProfileScreen` é reaproveitada também para ver o perfil de
    *outras* pessoas (empurrada com `Navigator.push`, com botão de
    voltar normal) — nesse caso `onOpenMenu` não é passado, então o
    botão de voltar automático continua funcionando normalmente
    (`automaticallyImplyLeading: widget.onOpenMenu == null`).
- Botão "Moderação": como ainda **não existe** nenhuma tela de
  moderação no Flutter (o `admin.py`/`templates/admin/*.html` do site
  são bem extensos — dashboard, lista de posts denunciados, banir
  usuário, logs de ação etc.), o item do menu por enquanto só mostra um
  aviso ("ainda não disponível neste app, use o site") em vez de abrir
  uma tela quebrada. Ver seção "o que falta" abaixo.

### 2. Botão "Seguir" — `lib/screens/profile_screen.dart`

- Antes usava `FilledButton` (cor sólida do Material, sem gradiente) e
  o texto "Deixar de seguir". No site (`templates/profile.html`), o
  botão de seguir usa a classe `.btn` (gradiente âmbar→rosa, o mesmo
  visual da sua screenshot) e quando já está seguindo o texto vira só
  **"Seguindo"** (não "Deixar de seguir").
- Troquei para o widget `GradientButton` que já existia em
  `lib/widgets/gradient_button.dart` (não usado ainda em lugar nenhum
  do perfil) e corrigi o texto pra "Seguindo" / "Seguir", igual ao site.

### 3. Ordem dos contadores — `lib/screens/profile_screen.dart`

- O site mostra **Seguindo → Seguidores → posts ativos**
  (`profile.html`, bloco `.profile-stats`). O Flutter mostrava
  "seguidores" antes de "seguindo", e com inicial minúscula. Corrigido
  pra bater com o site (`Seguindo`, `Seguidores`, `posts ativos`, nessa
  ordem e com a mesma capitalização).

Todos os arquivos editados foram checados com um script Python de
balanceamento de `()`/`{}`/`[]` (não é garantia de que compila, mas
pega erro grosseiro de parênteses/chaves esquecidos).

## O que ainda falta (por ordem de impacto)

1. **Rodar `flutter analyze` de verdade.** Prioridade #1 antes de
   qualquer outra coisa — nada foi compilado nesta sessão nem nas
   anteriores.
2. **Tela de Moderação.** É a peça que falta pra fechar o menu lateral
   por completo. No site fica em `admin.py` +
   `templates/admin/*.html` (dashboard, fila de denúncias, lista/apagar
   posts, banir/promover usuário, log de ações). Dá pra começar pequeno:
   uma tela só com a lista de posts (reaproveitando
   `GET /api/v1/...` — checar se existe endpoint de listagem admin em
   `api.py`, e se não existir, criar um espelhando `admin.posts` do
   Flask) com o botão de apagar que **já existe** em `post_card.dart`.
3. **Composer inline no topo do Feed/Perfil** ("O que está
   acontecendo?", chip "Some em 1 dia", anexar mídia, botão "Postar").
   Hoje o Flutter abre uma tela cheia separada
   (`create_post_screen.dart`) a partir do botão "+" da barra inferior.
   Funciona, mas o layout não é igual ao `_composer.html` do site (que
   tem um painel de duração com grupos "Minutos e horas / Dias e
   semanas / Meses e anos"). Não foi mexido nesta sessão por ser uma
   peça de UI grande e por já existir uma forma funcional de postar.
4. **Compartilhar nativo de verdade**: ainda só copia o link pra área
   de transferência (precisa do pacote `share_plus`, que não dá pra
   instalar sem internet neste ambiente).
5. **Respostas aninhadas nos comentários inline do card do feed**: só
   dá pra responder um comentário específico na tela de detalhe do
   post, não dentro do card do feed.
6. **Comparar telas que eu não tive tempo de auditar visualmente
   contra o site nesta sessão**: `create_post_screen.dart`,
   `edit_profile_screen.dart`, `search_screen.dart`,
   `ranking_screen.dart` (a propósito: `ranking.html` existe no site
   mas **não está linkado em lugar nenhum** da navegação atual do
   `base.html`/`main.py` — parece um recurso órfão ou só acessível de
   outro jeito que eu não achei; não coloquei link pra ele no Drawer por
   causa disso — se ele devia estar acessível, procurar onde no site
   ele é linkado e replicar).
7. **Testar visualmente** (depois do `flutter run` funcionar): abrir o
   Drawer em cada aba, seguir/deixar de seguir alguém e ver o botão
   gradiente, ir em Vortex e Mensagens pelo menu, apagar um post como
   staff, tocar áudio, abrir imagem em tela cheia.

## Arquivos alterados nesta sessão

- `lib/screens/home_shell.dart` (reescrito: Drawer + `GlobalKey`)
- `lib/screens/feed_screen.dart` (parâmetro `onOpenMenu` + botão ☰)
- `lib/screens/search_screen.dart` (idem)
- `lib/screens/notifications_screen.dart` (idem)
- `lib/screens/profile_screen.dart` (parâmetro `onOpenMenu` + botão ☰;
  botão Seguir com `GradientButton`; ordem dos contadores)
