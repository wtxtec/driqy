# Passo a passo — Firebase Console (só você consegue fazer isso)

Todo o código do app e um guia do backend já estão prontos. Falta só
criar o projeto no Firebase (usa sua conta Google) e me devolver 2
arquivos de configuração pra eu colar no lugar certo.

## 1. Android — já feito ✅

O projeto Firebase `driqy-app` já está criado e o app Android já
registrado com o pacote `com.wtxtec.driqy`. O `google-services.json`
já está em `android/app/google-services.json`, e `applicationId`/
`namespace` em `android/app/build.gradle.kts` (e o pacote de
`MainActivity.kt`) já foram ajustados pra bater com ele. Não precisa
repetir esse passo — só falta o iOS, se for publicar na App Store.

## 3. Registrar o app iOS (se for publicar na App Store também)

1. Mesmo projeto → ícone do iOS → **Adicionar app**.
2. **Bundle ID**: o mesmo que está em
   `ios/Runner.xcodeproj/project.pbxproj` (`PRODUCT_BUNDLE_IDENTIFIER`).
3. Baixe o `GoogleService-Info.plist` e me mande de volta — eu coloco em
   `ios/Runner/GoogleService-Info.plist`.
4. **Push no iOS exige uma chave APNs**: no Apple Developer Portal
   (developer.apple.com → Certificates, IDs & Profiles → Keys) crie uma
   **APNs Authentication Key**, baixe o `.p8`, e faça upload dela no
   Firebase Console → engrenagem → Configurações do projeto → aba
   **Cloud Messaging** → seção Apple → "Fazer upload".

## 4. Chave de serviço pro backend (Admin SDK)

Engrenagem → Configurações do projeto → aba **Contas de serviço** →
**Gerar nova chave privada**. Esse `.json` é diferente do
`google-services.json` — é o que o Flask usa pra *enviar* os pushes
(veja `BACKEND_FCM_FLASK.md`). Guarde ele em segredo, nunca no git.

## 5. O que eu faço depois que você me mandar os arquivos

- Colo `google-services.json` em `android/app/`.
- Colo `GoogleService-Info.plist` em `ios/Runner/` (e registro no
  Xcode/target, se necessário).
- Rodamos `flutter pub get` e um build de teste.

## O que já está pronto no código (não precisa mexer)

- `pubspec.yaml`: `firebase_core`, `firebase_messaging`,
  `flutter_local_notifications`.
- Android: plugin `google-services`, permissões (`POST_NOTIFICATIONS`
  etc.), canal de notificação padrão com som, desugaring habilitado.
- iOS: `AppDelegate.swift` com delegate de notificações, `Info.plist`
  com `UIBackgroundModes: remote-notification`.
- `lib/services/push_notification_service.dart`: pede permissão, pega o
  token, registra no backend (`/api/v1/devices/register`), mostra a
  notificação com som quando o app está aberto, escuta toque na
  notificação com app minimizado ou fechado.
- `lib/main.dart`: inicializa o Firebase, registra o handler de
  background (**é esse handler que faltava e é a causa direta de nada
  aparecer com o app minimizado**), navega pra tela certa ao tocar na
  notificação.
- `lib/services/auth_service.dart`: registra o token no login e remove
  no logout.

Falta só o `BACKEND_FCM_FLASK.md` (rotas + envio) no seu Flask, e os 2
arquivos de config do Firebase.
