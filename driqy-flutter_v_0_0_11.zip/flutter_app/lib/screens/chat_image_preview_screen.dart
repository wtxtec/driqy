import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Resultado da pré-visualização: o que será enviado.
class ChatImageDraft {
  final File file;
  final String caption;
  final int? width;
  final int? height;
  final bool viewOnce;

  const ChatImageDraft({
    required this.file,
    this.caption = '',
    this.width,
    this.height,
    this.viewOnce = false,
  });
}

/// Tela cheia antes de enviar uma imagem/GIF no chat: mostra o arquivo (o
/// GIF anima, `Image.file` cuida disso), permite escrever uma legenda e
/// devolve um [ChatImageDraft] (ou null se cancelar).
class ChatImagePreviewScreen extends StatefulWidget {
  final File file;
  final String initialCaption;

  const ChatImagePreviewScreen({super.key, required this.file, this.initialCaption = ''});

  @override
  State<ChatImagePreviewScreen> createState() => _ChatImagePreviewScreenState();
}

class _ChatImagePreviewScreenState extends State<ChatImagePreviewScreen> {
  late final TextEditingController _caption =
      TextEditingController(text: widget.initialCaption);
  int? _width;
  int? _height;
  bool _viewOnce = false;

  @override
  void initState() {
    super.initState();
    _measure();
  }

  @override
  void dispose() {
    _caption.dispose();
    super.dispose();
  }

  /// Descobre largura/altura pra a bolha reservar o espaço certo.
  Future<void> _measure() async {
    try {
      final bytes = await widget.file.readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      _width = frame.image.width;
      _height = frame.image.height;
      frame.image.dispose();
      codec.dispose();
    } catch (_) {
      // sem dimensões: a bolha usa a proporção padrão
    }
  }

  void _send() {
    Navigator.of(context).pop(ChatImageDraft(
      file: widget.file,
      caption: _viewOnce ? '' : _caption.text.trim(),
      width: _width,
      height: _height,
      viewOnce: _viewOnce,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          tooltip: 'Cancelar',
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: InteractiveViewer(
              minScale: 1,
              maxScale: 4,
              child: Center(
                child: Image.file(
                  widget.file,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stack) => const Icon(
                    Icons.broken_image_outlined,
                    color: Colors.white54,
                    size: 48,
                  ),
                ),
              ),
            ),
          ),
          if (_viewOnce)
            Padding(
              padding: EdgeInsets.fromLTRB(16, 6, 16, 0),
              child: Text(
                'Visualização única: a pessoa abre uma vez e some. Sem legenda.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.amber, fontSize: 12.5),
              ),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: TextField(
                        enabled: !_viewOnce,
                        controller: _caption,
                        minLines: 1,
                        maxLines: 4,
                        maxLength: 2000,
                        textCapitalization: TextCapitalization.sentences,
                        style: TextStyle(color: AppColors.text),
                        decoration: InputDecoration(
                          hintText: 'Adicionar legenda…',
                          hintStyle: TextStyle(color: AppColors.textMuted),
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          filled: false,
                          counterText: '',
                          contentPadding: EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Tooltip(
                    message: 'Visualização única',
                    child: GestureDetector(
                      onTap: () => setState(() => _viewOnce = !_viewOnce),
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _viewOnce ? AppColors.amber : AppColors.surface2,
                        ),
                        child: Icon(Icons.looks_one_outlined,
                            color: _viewOnce ? AppColors.onBrand : AppColors.textMuted),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _send,
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        gradient: AppGradients.brand,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.send_rounded, color: AppColors.onBrand),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
