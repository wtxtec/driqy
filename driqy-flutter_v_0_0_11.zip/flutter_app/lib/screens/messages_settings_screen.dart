import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../services/auth_service.dart';
import '../services/messages_prefs.dart';
import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';
import '../theme/vortex_theme.dart';
import 'edit_profile_screen.dart';

/// Configurações de Mensagens (estilo Telegram): cabeçalho com a foto, @ e as linhas
/// Notificações e sons / Privacidade e segurança. Substitui a antiga tela aberta pela foto.
/// O tema (claro/escuro) ainda NÃO existe no Flutter — ver PROGRESSO_MENSAGENS.md.
class MessagesSettingsScreen extends StatelessWidget {
  /// Estado atual de "mostrar online e visto por último" (vem da caixa de entrada).
  final bool showPresence;

  /// Salva no servidor e devolve o valor aceito.
  final Future<bool> Function(bool value) onPresenceChanged;

  const MessagesSettingsScreen({super.key, required this.showPresence, required this.onPresenceChanged});

  @override
  Widget build(BuildContext context) {
    final me = context.read<AuthService>().currentUser;
    final c = PingColors.of(context);
    final name = me?.displayName ?? '';

    Widget card(List<Widget> rows) => Container(
          margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: c.searchBg, borderRadius: BorderRadius.circular(18)),
          child: Column(children: rows),
        );

    return Scaffold(
      backgroundColor: c.panel,
      appBar: AppBar(title: const Text('Configurações'), backgroundColor: c.panel),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          const SizedBox(height: 8),
          Center(
            child: CircleAvatar(
              radius: 52,
              backgroundColor: AppColors.amber,
              foregroundColor: c.onAccent,
              backgroundImage: me?.avatarUrl != null ? NetworkImage(resolveMediaUrl(me!.avatarUrl!)) : null,
              child: me?.avatarUrl == null
                  ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                      style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w700))
                  : null,
            ),
          ),
          const SizedBox(height: 10),
          Center(child: Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
          Center(child: Text('online', style: TextStyle(color: AppColors.textMuted, fontSize: 13))),
          const SizedBox(height: 16),
          card([
            _SettingsRow(
              color: const Color(0xFF4CAF6D),
              icon: Icons.edit_outlined,
              title: me != null ? '@${me.username}' : 'Editar perfil',
              subtitle: 'Editar perfil',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const EditProfileScreen())),
            ),
          ]),
          card([
            _SettingsRow(
              color: const Color(0xFFE5534B),
              icon: Icons.notifications_none,
              title: 'Notificações e sons',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const _SoundSettingsScreen())),
            ),
            _SettingsRow(
              color: const Color(0xFF4A86D6),
              icon: Icons.lock_outline,
              title: 'Privacidade e segurança',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => _PrivacySettingsScreen(initial: showPresence, onChanged: onPresenceChanged),
              )),
            ),
          ]),
        ],
      ),
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;

  const _SettingsRow({required this.color, required this.icon, required this.title, this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      leading: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle!, style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
      onTap: onTap,
    );
  }
}

/// Notificações e sons: interruptor, escolha do som (com prévia) e volume.
class _SoundSettingsScreen extends StatefulWidget {
  const _SoundSettingsScreen();

  @override
  State<_SoundSettingsScreen> createState() => _SoundSettingsScreenState();
}

class _SoundSettingsScreenState extends State<_SoundSettingsScreen> {
  final _prefs = MessagesPrefs.instance;

  @override
  void initState() {
    super.initState();
    _prefs.addListener(_onChange);
    _prefs.load();
  }

  void _onChange() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _prefs.removeListener(_onChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = PingColors.of(context);
    Widget card(List<Widget> rows) => Container(
          margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: c.searchBg, borderRadius: BorderRadius.circular(18)),
          child: Column(children: rows),
        );
    Widget heading(String t) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 6),
          child: Text(t, style: TextStyle(color: AppColors.amber, fontSize: 13, fontWeight: FontWeight.w700)),
        );

    return Scaffold(
      backgroundColor: c.panel,
      appBar: AppBar(title: const Text('Notificações e sons'), backgroundColor: c.panel),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          card([
            SwitchListTile(
              value: _prefs.soundEnabled,
              onChanged: _prefs.setSoundEnabled,
              title: const Text('Som ao receber mensagens'),
              subtitle: Text(
                'Toca com o Mensagens aberto. Por conversa, use Silenciar.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
            ),
          ]),
          heading('Aparência'),
          card([
            AnimatedBuilder(
              animation: VortexThemeController.instance,
              builder: (context, _) => SwitchListTile(
                value: VortexThemeController.instance.isLight,
                onChanged: (v) => VortexThemeController.instance
                    .setBrightness(v ? Brightness.light : Brightness.dark),
                title: const Text('Tema claro'),
                subtitle: Text(
                  'Vale para o app inteiro e fica salvo neste aparelho.',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
              ),
            ),
          ]),
          heading('Som da mensagem'),
          card([
            for (final e in MessagesPrefs.choices.entries)
              ListTile(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                title: Text(e.value),
                trailing: Icon(
                  _prefs.soundChoice == e.key ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                  color: _prefs.soundChoice == e.key ? AppColors.amber : AppColors.textMuted,
                ),
                onTap: () => _prefs.setSoundChoice(e.key),
              ),
          ]),
          heading('Volume'),
          card([
            Slider(
              value: _prefs.volume,
              onChanged: _prefs.setVolumeLive,
              onChangeEnd: (_) => _prefs.commitVolume(),
              divisions: 20,
              label: '${(_prefs.volume * 100).round()}%',
            ),
          ]),
          Padding(
            padding: EdgeInsets.fromLTRB(20, 4, 20, 24),
            child: Text(
              'O som das notificações com o app fechado é o do próprio Android (Configurações do aparelho → Mensagens).',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

/// Privacidade e segurança: online / visto por último (vale no servidor, para os dois lados).
class _PrivacySettingsScreen extends StatefulWidget {
  final bool initial;
  final Future<bool> Function(bool value) onChanged;

  const _PrivacySettingsScreen({required this.initial, required this.onChanged});

  @override
  State<_PrivacySettingsScreen> createState() => _PrivacySettingsScreenState();
}

class _PrivacySettingsScreenState extends State<_PrivacySettingsScreen> {
  late bool _value = widget.initial;

  Future<void> _toggle(bool v) async {
    setState(() => _value = v);
    try {
      final saved = await widget.onChanged(v);
      if (mounted) setState(() => _value = saved);
    } catch (_) {
      if (!mounted) return;
      setState(() => _value = !v);
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Não foi possível salvar.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = PingColors.of(context);
    return Scaffold(
      backgroundColor: c.panel,
      appBar: AppBar(title: const Text('Privacidade e segurança'), backgroundColor: c.panel),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          Container(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(color: c.searchBg, borderRadius: BorderRadius.circular(18)),
            child: SwitchListTile(
              value: _value,
              onChanged: _toggle,
              title: const Text('Mostrar online e visto por último'),
              subtitle: Text(
                'Se você esconder, também deixa de ver o dos outros.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
