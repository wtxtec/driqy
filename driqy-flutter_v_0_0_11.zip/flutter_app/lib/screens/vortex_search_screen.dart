import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/picture_tile.dart';
import '../services/auth_service.dart';
import '../services/pictures_service.dart';
import '../theme/vortex_theme.dart';
import '../widgets/vortex_tile_actions.dart';
import '../widgets/vortex_tile_card.dart';
import 'vortex_detail_screen.dart';

/// Busca no Vortex (itens do crawler: título, tags, descrição, categoria).
/// Aceita prefixo e ignora acento/maiúscula; o servidor avisa quando nenhuma
/// peça tinha TODAS as palavras (`relaxed`) e mostramos as que têm alguma.
///
/// Segue o tema (claro/escuro) do Vortex. Segurar um resultado abre Curtir /
/// Menos disso.
class VortexSearchScreen extends StatelessWidget {
  final String? initialQuery;

  const VortexSearchScreen({super.key, this.initialQuery});

  @override
  Widget build(BuildContext context) {
    return VortexThemeScope(child: _VortexSearchBody(initialQuery: initialQuery));
  }
}

class _VortexSearchBody extends StatefulWidget {
  final String? initialQuery;

  const _VortexSearchBody({this.initialQuery});

  @override
  State<_VortexSearchBody> createState() => _VortexSearchScreenState();
}

class _VortexSearchScreenState extends State<_VortexSearchBody> {
  final VortexTileReactions _reactions = VortexTileReactions();
  late PicturesService _service;
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();

  final List<PictureTile> _tiles = [];
  final Set<String> _keys = {};
  String _query = '';
  String? _type; // null = tudo
  String? _cursor;
  bool _hasNext = false;
  bool _loading = false;
  bool _loadingMore = false;
  bool _searched = false;
  bool _relaxed = false;
  bool _capped = false;
  int _total = 0;
  String? _error;
  int _generation = 0; // descarta respostas de buscas antigas

  @override
  void initState() {
    super.initState();
    _service = PicturesService(context.read<AuthService>().client);
    _scroll.addListener(_onScroll);
    final q = widget.initialQuery?.trim() ?? '';
    if (q.isNotEmpty) {
      _input.text = q;
      WidgetsBinding.instance.addPostFrameCallback((_) => _run(q));
    }
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    _input.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_hasNext || _loadingMore || _loading || !_scroll.hasClients) return;
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 400) _loadMore();
  }

  Future<void> _run(String raw) async {
    final q = raw.trim();
    if (q.length < 2) {
      setState(() => _error = 'Digite pelo menos 2 letras.');
      return;
    }
    final gen = ++_generation;
    setState(() {
      _query = q;
      _loading = true;
      _error = null;
      _tiles.clear();
      _keys.clear();
      _cursor = null;
      _hasNext = false;
    });
    try {
      final page = await _service.search(q, type: _type);
      if (!mounted || gen != _generation) return;
      setState(() {
        _add(page);
        _total = page.total;
        _capped = page.totalCapped;
        _relaxed = page.relaxed;
        _searched = true;
      });
    } catch (_) {
      if (mounted && gen == _generation) setState(() => _error = 'Não foi possível buscar agora.');
    } finally {
      if (mounted && gen == _generation) setState(() => _loading = false);
    }
  }

  void _add(PicturesPage page) {
    for (final t in page.tiles) {
      if (_keys.add(t.key)) _tiles.add(t);
    }
    _cursor = page.nextCursor;
    _hasNext = page.hasNext;
  }

  Future<void> _loadMore() async {
    final gen = _generation;
    setState(() => _loadingMore = true);
    try {
      final page = await _service.search(_query, cursor: _cursor, type: _type);
      if (mounted && gen == _generation) setState(() => _add(page));
    } catch (_) {
      // silencioso
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  void _setType(String? type) {
    if (_type == type) return;
    setState(() => _type = type);
    if (_query.isNotEmpty) _run(_query);
  }

  void _open(PictureTile tile) {
    final id = tile.itemId;
    if (id == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => VortexDetailScreen(itemId: id, initialTile: tile)),
    );
  }

  /// Segurar um resultado: Abrir / Curtir / Menos disso.
  Future<void> _onLongPress(PictureTile tile) {
    return reactToTile(
      context: context,
      service: _service,
      tile: tile,
      reactions: _reactions,
      onOpen: () => _open(tile),
      onChanged: () {
        if (mounted) setState(() {});
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: VortexColors.of(context).bg,
      appBar: AppBar(
        title: TextField(
          controller: _input,
          autofocus: widget.initialQuery == null,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(hintText: 'Buscar no Vortex', border: InputBorder.none),
          onSubmitted: _run,
        ),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: () => _run(_input.text)),
          const VortexThemeButton(),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: [
                for (final entry in const [
                  [null, 'Tudo'],
                  ['photo', 'Fotos'],
                  ['gif', 'GIFs'],
                  ['video', 'Vídeos'],
                ])
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(entry[1]!),
                      selected: _type == entry[0],
                      onSelected: (_) => _setType(entry[0]),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(child: _buildResults()),
        ],
      ),
    );
  }

  Widget _buildResults() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return Center(child: Text(_error!));
    final colors = VortexColors.of(context);
    if (!_searched) {
      return Center(
        child: Text('Busque por assunto: cachoeira, gato, praia...',
            style: TextStyle(color: colors.textMuted)),
      );
    }
    if (_tiles.isEmpty) {
      return Center(child: Text('Nada encontrado para "$_query".'));
    }
    return SingleChildScrollView(
      controller: _scroll,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Text(
              _relaxed
                  ? 'Nenhuma peça tem todas as palavras; mostrando as que têm alguma.'
                  : '${_capped ? '$_total+' : '$_total'} resultados',
              style: TextStyle(color: colors.textMuted, fontSize: 12),
            ),
          ),
          VortexMasonry(
            tiles: _tiles,
            onTap: _open,
            onLongPress: _onLongPress,
            hidden: _reactions.hidden,
            liked: _reactions.liked,
          ),
          if (_hasNext)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(
                child: SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
