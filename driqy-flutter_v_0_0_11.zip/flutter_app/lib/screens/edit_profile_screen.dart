import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/accent_color.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/user_service.dart';
import '../services/widgets_service.dart';
import '../theme/app_colors.dart';
import '../widgets/driqy_top_bar.dart';
import '../widgets/place_field.dart';
import 'image_crop_screen.dart';

/// Tela de editar perfil: mesmos campos de templates/edit_profile.html no
/// site (username, nome de exibição, bio, localização, cor de destaque,
/// avatar e capa), consumindo POST /api/v1/me.
class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late UserService _userService;

  final _usernameController = TextEditingController();
  final _displayNameController = TextEditingController();
  final _bioController = TextEditingController();
  final _locationController = TextEditingController();
  double? _locationLat;
  double? _locationLng;

  List<AccentColorOption> _accentOptions = [];
  String? _accentColor;

  File? _avatarFile;
  File? _coverFile;
  bool _removeAvatar = false;
  bool _removeCover = false;
  String? _existingAvatarUrl;
  String? _existingCoverUrl;

  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _userService = UserService(context.read<AuthService>().client);
    _usernameController.addListener(() {
      if (mounted) setState(() {});
    });
    _load();
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _displayNameController.dispose();
    _bioController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final auth = context.read<AuthService>();
      final username = auth.currentUser!.username;
      final user = await _userService.getProfile(username);
      final colors = await _userService.getAccentColors();
      setState(() {
        _usernameController.text = user.username;
        _displayNameController.text = user.displayName;
        _bioController.text = user.bio;
        _locationController.text = user.location;
        _locationLat = user.locationLat;
        _locationLng = user.locationLng;
        _accentOptions = colors;
        _accentColor = user.accentColor;
        _existingAvatarUrl = user.avatarUrl;
        _existingCoverUrl = user.coverUrl;
      });
    } catch (_) {
      setState(() => _error = 'Não foi possível carregar seu perfil.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Escolhe a imagem e abre o editor de enquadramento (arrastar + zoom),
  /// como o modal do site. O ajuste é feito aqui, no upload.
  Future<File?> _pickAndCrop({required bool circle}) async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked == null || !mounted) return null;
    return Navigator.of(context).push<File>(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => ImageCropScreen(
          file: File(picked.path),
          circle: circle,
          outputWidth: circle ? 480 : 1200,
          outputHeight: circle ? 480 : 400,
          title: circle ? 'Ajustar foto de perfil' : 'Ajustar foto de capa',
        ),
      ),
    );
  }

  Future<void> _pickAvatar() async {
    final file = await _pickAndCrop(circle: true);
    if (file != null) {
      setState(() {
        _avatarFile = file;
        _removeAvatar = false;
      });
    }
  }

  Future<void> _pickCover() async {
    final file = await _pickAndCrop(circle: false);
    if (file != null) {
      setState(() {
        _coverFile = file;
        _removeCover = false;
      });
    }
  }

  void _clearAvatar() {
    setState(() {
      _avatarFile = null;
      _removeAvatar = true;
    });
  }

  void _clearCover() {
    setState(() {
      _coverFile = null;
      _removeCover = true;
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    final username = _usernameController.text.trim();
    if (username.length < 3 || username.length > 20) {
      setState(() => _error = 'Nome de usuário deve ter entre 3 e 20 caracteres.');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      final updated = await _userService.updateProfile(
        username: username,
        displayName: _displayNameController.text.trim(),
        bio: _bioController.text.trim(),
        location: _locationController.text.trim(),
        locationLat: _locationLat,
        locationLng: _locationLng,
        accentColor: _accentColor ?? 'amber',
        avatarFile: _avatarFile,
        coverFile: _coverFile,
        removeAvatar: _removeAvatar,
        removeCover: _removeCover,
      );
      if (mounted) {
        context.read<AuthService>().updateCurrentUser(updated);
        Navigator.of(context).pop(true);
      }
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'Não foi possível salvar agora.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DriqyTopBar(),
      body: _loading ? const Center(child: CircularProgressIndicator()) : _buildForm(),
    );
  }

  Widget _buildForm() {
    final theme = Theme.of(context);
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Editar perfil', style: theme.textTheme.headlineMedium),
            const SizedBox(height: 6),
            Text(
              'Personalize como as pessoas veem @${_usernameController.text}.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 15),
            ),
            const SizedBox(height: 16),
            _buildPhotos(),
            const SizedBox(height: 20),
            _label('Nome de usuário (@)'),
            TextField(
              controller: _usernameController,
              maxLength: 20,
              decoration: const InputDecoration(counterText: ''),
            ),
            _hint(
                'Seu @ atual. 3-20 caracteres, apenas letras, números e underscore. Ao trocar, seus links antigos com o @ anterior deixam de funcionar.'),
            const SizedBox(height: 16),
            _label('Nome de exibição'),
            TextField(
              controller: _displayNameController,
              maxLength: 50,
              decoration: InputDecoration(
                counterText: '',
                hintText: _usernameController.text,
              ),
            ),
            _hint('Aparece acima do seu @${_usernameController.text}. Deixe em branco para usar o nome de usuário.'),
            const SizedBox(height: 16),
            _label('Localização'),
            PlaceField(
              controller: _locationController,
              service: WidgetsService(context.read<AuthService>().client),
              onSelected: (p) => setState(() {
                _locationLat = p.latitude;
                _locationLng = p.longitude;
              }),
              onTyped: () {
                if (_locationLat != null || _locationLng != null) {
                  setState(() {
                    _locationLat = null;
                    _locationLng = null;
                  });
                }
              },
            ),
            _hint(_locationLat != null
                ? '✓ Cidade confirmada: o clima usará este local.'
                : 'Escolha uma das sugestões (cidade, estado e país) para o clima do seu painel mostrar a cidade certa.'),
            const SizedBox(height: 16),
            _label('Bio'),
            TextField(
              controller: _bioController,
              maxLength: 280,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(
                counterText: '',
                hintText: 'Fale um pouco sobre você. Pode usar @usuario para mencionar alguém.',
              ),
            ),
            const SizedBox(height: 16),
            _label('Cor de marca'),
            _buildAccentPicker(),
            _hint(
                'Essa é a sua cor de marca: aparece no seu nome, no seu avatar padrão e na borda de todos os seus posts.'),
            if (_error != null) ...[
              const SizedBox(height: 16),
              Text(_error!, style: TextStyle(color: AppColors.danger)),
            ],
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _loading || _saving ? null : _save,
                child: _saving
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Salvar alterações'),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text, style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.text)),
      );

  Widget _hint(String text) => Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text(text, style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
      );

  Color get _accent => AppColors.accentFromKey(_accentColor);

  BoxDecoration _fallbackGradient({required bool circle}) => BoxDecoration(
        shape: circle ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: circle ? null : BorderRadius.circular(14),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_accent, AppColors.rose],
        ),
      );

  Widget _pillButton(String label, VoidCallback onTap, {bool overlay = false}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: overlay ? Colors.black54 : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: overlay ? Colors.white24 : AppColors.border),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13.5,
            fontWeight: FontWeight.w600,
            color: overlay ? Colors.white : AppColors.text,
          ),
        ),
      ),
    );
  }

  /// Capa + avatar sobreposto + botões "Alterar capa / Remover" e
  /// "Alterar foto / Remover", igual ao `.edit-photos` do site. Não há
  /// botão "Ajustar": o enquadramento é feito logo após escolher a imagem.
  Widget _buildPhotos() {
    ImageProvider? cover;
    if (_coverFile != null) {
      cover = FileImage(_coverFile!);
    } else if (!_removeCover && _existingCoverUrl != null) {
      cover = NetworkImage(resolveMediaUrl(_existingCoverUrl!));
    }
    ImageProvider? avatar;
    if (_avatarFile != null) {
      avatar = FileImage(_avatarFile!);
    } else if (!_removeAvatar && _existingAvatarUrl != null) {
      avatar = NetworkImage(resolveMediaUrl(_existingAvatarUrl!));
    }
    final initial = _usernameController.text.isNotEmpty ? _usernameController.text[0].toUpperCase() : '?';

    const avatarSize = 76.0; // mobile: .edit-avatar-frame 76px, margem -34px
    const sidePad = 14.0;

    return LayoutBuilder(
      builder: (context, constraints) {
        final coverHeight = constraints.maxWidth / 3; // aspect-ratio 3 / 1
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: coverHeight + 54,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // Capa
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    height: coverHeight,
                    child: Container(
                      clipBehavior: Clip.antiAlias,
                      decoration: cover == null
                          ? _fallbackGradient(circle: false)
                          : BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              color: Colors.white,
                              image: DecorationImage(image: cover, fit: BoxFit.cover),
                            ),
                      // `.cover-actions { top: 12px; right: 12px; }`
                      child: Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Wrap(
                            spacing: 8,
                            children: [
                              _pillButton('Alterar capa', _pickCover, overlay: true),
                              if (cover != null) _pillButton('Remover', _clearCover, overlay: true),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Avatar sobrepondo a capa
                  Positioned(
                    top: coverHeight - 34,
                    left: sidePad,
                    child: Container(
                      width: avatarSize,
                      height: avatarSize,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.bg),
                      child: Container(
                        decoration: avatar == null
                            ? _fallbackGradient(circle: true)
                            : BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                                image: DecorationImage(image: avatar, fit: BoxFit.cover),
                              ),
                        alignment: Alignment.center,
                        child: avatar == null
                            ? Text(
                                initial,
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.onBrand,
                                ),
                              )
                            : null,
                      ),
                    ),
                  ),
                  // Alterar foto / Remover: abaixo da capa, ao lado do avatar
                  Positioned(
                    top: coverHeight + 10,
                    left: sidePad + avatarSize + 12,
                    right: 0,
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _pillButton('Alterar foto', _pickAvatar),
                        if (avatar != null) _pillButton('Remover', _clearAvatar),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'PNG, JPG, JPEG ou WEBP. Você pode ajustar o zoom e a posição antes de salvar.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
            ),
          ],
        );
      },
    );
  }

  Widget _buildAccentPicker() {
    if (_accentOptions.isEmpty) {
      return Text('Não foi possível carregar as cores.', style: TextStyle(color: AppColors.textMuted));
    }
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: _accentOptions.map((option) {
        final selected = option.key == _accentColor;
        return InkWell(
          onTap: () => setState(() => _accentColor = option.key),
          borderRadius: BorderRadius.circular(20),
          child: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: option.color,
              shape: BoxShape.circle,
              border: selected ? Border.all(color: AppColors.text, width: 3) : null,
            ),
            child: selected ? const Icon(Icons.check, color: Colors.white, size: 18) : null,
          ),
        );
      }).toList(),
    );
  }
}
