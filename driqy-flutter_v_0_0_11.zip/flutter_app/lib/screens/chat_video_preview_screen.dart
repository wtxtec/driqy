import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../theme/app_colors.dart';
import '../widgets/chat/chat_format.dart';

/// Resultado da pré-visualização de vídeo: o que será enviado.
class ChatVideoDraft {
  final File file;
  final String caption;
  final int durationMs;
  final int? width;
  final int? height;
  final bool viewOnce;

  const ChatVideoDraft({
    required this.file,
    required this.durationMs,
    this.caption = '',
    this.width,
    this.height,
    this.viewOnce = false,
  });
}

/// Tela cheia antes de enviar um vídeo no chat (Fase 6): toca o arquivo local,
/// mede duração/largura/altura pelo próprio player, deixa escrever legenda e
/// devolve um [ChatVideoDraft] (ou null se cancelar).
class ChatVideoPreviewScreen extends StatefulWidget {
  final File file;
  final String initialCaption;

  const ChatVideoPreviewScreen({super.key, required this.file, this.initialCaption = ''});

  @override
  State<ChatVideoPreviewScreen> createState() => _ChatVideoPreviewScreenState();
}

class _ChatVideoPreviewScreenState extends State<ChatVideoPreviewScreen> {
  late final TextEditingController _caption =
      TextEditingController(text: widget.initialCaption);
  late final VideoPlayerController _video = VideoPlayerController.file(widget.file);
  bool _viewOnce = false;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _video.initialize().then((_) {
      if (!mounted) return;
      _video.setLooping(true);
      setState(() => _ready = true);
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
    _video.addListener(() {
      if (mounted) setState(() {}); // atualiza ícone play/pausa e barra
    });
  }

  @override
  void dispose() {
    _caption.dispose();
    _video.dispose();
    super.dispose();
  }

  void _toggle() {
    _video.value.isPlaying ? _video.pause() : _video.play();
  }

  void _send() {
    if (!_ready) return;
    final size = _video.value.size;
    Navigator.of(context).pop(ChatVideoDraft(
      file: widget.file,
      caption: _viewOnce ? '' : _caption.text.trim(),
      viewOnce: _viewOnce,
      durationMs: _video.value.duration.inMilliseconds,
      width: size.width > 0 ? size.width.round() : null,
      height: size.height > 0 ? size.height.round() : null,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final playing = _video.value.isPlaying;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        title: _ready
            ? Text(chatDuration(_video.value.duration.inMilliseconds),
                style: const TextStyle(fontSize: 15))
            : null,
        leading: IconButton(
          tooltip: 'Cancelar',
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: _failed
                  ? const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Não foi possível ler este vídeo.',
                        style: TextStyle(color: Colors.white70),
                      ),
                    )
                  : !_ready
                      ? const CircularProgressIndicator(color: Colors.white)
                      : GestureDetector(
                          onTap: _toggle,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              AspectRatio(
                                aspectRatio: _video.value.aspectRatio,
                                child: VideoPlayer(_video),
                              ),
                              if (!playing)
                                const DecoratedBox(
                                  decoration: BoxDecoration(
                                      color: Colors.black54, shape: BoxShape.circle),
                                  child: Padding(
                                    padding: EdgeInsets.all(14),
                                    child: Icon(Icons.play_arrow_rounded,
                                        color: Colors.white, size: 44),
                                  ),
                                ),
                            ],
                          ),
                        ),
            ),
          ),
          if (_ready)
            VideoProgressIndicator(
              _video,
              allowScrubbing: true,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              colors: VideoProgressColors(
                playedColor: AppColors.amber,
                bufferedColor: Colors.white24,
                backgroundColor: Colors.white12,
              ),
            ),
          if (_viewOnce)
            Padding(
              padding: EdgeInsets.fromLTRB(16, 6, 16, 0),
              child: Text(
                'Visualização única: a pessoa abre uma vez e some. Sem legenda.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.amber, fontSize: 12.5),
              ),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: TextField(
                        enabled: !_viewOnce,
                        controller: _caption,
                        minLines: 1,
                        maxLines: 4,
                        maxLength: 2000,
                        textCapitalization: TextCapitalization.sentences,
                        style: TextStyle(color: AppColors.text),
                        decoration: InputDecoration(
                          hintText: 'Adicionar legenda…',
                          hintStyle: TextStyle(color: AppColors.textMuted),
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          filled: false,
                          counterText: '',
                          contentPadding: EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Tooltip(
                    message: 'Visualização única',
                    child: GestureDetector(
                      onTap: () => setState(() => _viewOnce = !_viewOnce),
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _viewOnce ? AppColors.amber : AppColors.surface2,
                        ),
                        child: Icon(Icons.looks_one_outlined,
                            color: _viewOnce ? AppColors.onBrand : AppColors.textMuted),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _ready ? _send : null,
                    child: Opacity(
                      opacity: _ready ? 1 : 0.4,
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: AppGradients.brand,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.send_rounded, color: AppColors.onBrand),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
