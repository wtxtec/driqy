import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/chat_group.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/group_service.dart';
import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';
import '../widgets/group_avatar.dart';
import 'new_group_screen.dart';

/// "Dados do grupo" (estilo Telegram): foto, nome, descrição, silenciar/fixar/arquivar,
/// participantes (adicionar, remover, tornar admin) e sair/apagar.
/// Fecha com `true` quando a pessoa saiu ou o grupo foi apagado.
class GroupInfoScreen extends StatefulWidget {
  final DriqyGroup group;
  const GroupInfoScreen({super.key, required this.group});

  @override
  State<GroupInfoScreen> createState() => _GroupInfoScreenState();
}

class _GroupInfoScreenState extends State<GroupInfoScreen> {
  late final GroupService _service;
  late DriqyGroup _g = widget.group;
  late final int _myId;

  @override
  void initState() {
    super.initState();
    final auth = context.read<AuthService>();
    _service = GroupService(auth.client);
    _myId = auth.currentUser?.id ?? 0;
    _reload();
  }

  void _snack(String m) => ScaffoldMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(m)));

  Future<void> _run(Future<DriqyGroup> Function() f) async {
    try {
      final g = await f();
      if (mounted) setState(() => _g = g);
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Algo deu errado. Tente de novo.');
    }
  }

  Future<void> _reload() => _run(() => _service.detail(_g.id));

  Future<bool> _confirm(String title, String text, String yes) async =>
      await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(title),
          content: Text(text),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes, style: TextStyle(color: AppColors.danger))),
          ],
        ),
      ) ??
      false;

  Future<void> _edit() async {
    final name = TextEditingController(text: _g.name);
    final desc = TextEditingController(text: _g.description);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Editar grupo'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, maxLength: 60, decoration: const InputDecoration(labelText: 'Nome do grupo')),
          TextField(controller: desc, maxLength: 200, maxLines: 3, decoration: const InputDecoration(labelText: 'Descrição (opcional)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Salvar')),
        ],
      ),
    );
    if (ok == true) await _run(() => _service.update(_g.id, name: name.text.trim(), description: desc.text.trim()));
    name.dispose();
    desc.dispose();
  }

  Future<void> _pickAvatar() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1024, imageQuality: 85);
    if (picked == null) return;
    await _run(() => _service.setAvatar(_g.id, File(picked.path)));
  }

  Future<void> _addPeople() async {
    final names = await Navigator.of(context).push<List<String>>(
      MaterialPageRoute(builder: (_) => NewGroupScreen(existing: _g.members.map((m) => m.username.toLowerCase()).toSet())),
    );
    if (names == null || names.isEmpty) return;
    await _run(() => _service.addMembers(_g.id, names));
  }

  Future<void> _setPrefs({bool? pinned, bool? muted, bool? archived}) async {
    try {
      final p = await _service.setPrefs(_g.id, pinned: pinned, muted: muted, archived: archived);
      if (!mounted) return;
      await _reload();
      if (p.archived && archived == true) _snack('Grupo arquivado');
    } on ApiException catch (e) {
      _snack(e.message);
    }
  }

  Future<void> _leave() async {
    final ok = await _confirm('Sair do grupo?', _g.isOwner ? 'Você é o dono: o grupo passa para outra pessoa.' : 'Você deixa de receber as mensagens.', 'Sair');
    if (!ok) return;
    try {
      await _service.leave(_g.id);
      if (mounted) Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      _snack(e.message);
    }
  }

  Future<void> _deleteGroup() async {
    final ok = await _confirm('Apagar o grupo?', 'Todas as mensagens somem para todo mundo. Não dá para desfazer.', 'Apagar');
    if (!ok) return;
    try {
      await _service.deleteGroup(_g.id);
      if (mounted) Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      _snack(e.message);
    }
  }

  Widget _card(List<Widget> children) {
    final pc = PingColors.of(context);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: pc.panelHover, borderRadius: BorderRadius.circular(16)),
      child: Column(children: children),
    );
  }

  Widget _member(DriqyGroupUser u) {
    final me = _g.myRole;
    final canRemove = u.id != _myId && ((me == 'owner' && u.role != 'owner') || (me == 'admin' && u.role == 'member'));
    final canRole = me == 'owner' && u.id != _myId && u.role != 'owner';
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: u.avatarUrl != null ? NetworkImage(resolveMediaUrl(u.avatarUrl!)) : null,
        child: u.avatarUrl == null ? Text(u.displayName.isNotEmpty ? u.displayName[0].toUpperCase() : '?') : null,
      ),
      title: Text(u.id == _myId ? 'Você' : u.displayName),
      subtitle: Text('@${u.username}'),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        if (u.role != 'member') Text(u.role == 'owner' ? 'dono' : 'admin', style: TextStyle(color: AppColors.amber, fontSize: 12)),
        if (canRemove || canRole)
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'role') {
                await _run(() => _service.setRole(_g.id, u.username, u.role == 'admin' ? 'member' : 'admin'));
              } else if (v == 'remove' && await _confirm('Remover ${u.displayName}?', 'A pessoa sai do grupo.', 'Remover')) {
                await _run(() => _service.removeMember(_g.id, u.username));
              }
            },
            itemBuilder: (_) => [
              if (canRole) PopupMenuItem(value: 'role', child: Text(u.role == 'admin' ? 'Tirar admin' : 'Tornar admin')),
              if (canRemove) const PopupMenuItem(value: 'remove', child: Text('Remover do grupo')),
            ],
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final g = _g;
    final p = g.prefs;
    return Scaffold(
      appBar: AppBar(title: const Text('Dados do grupo')),
      body: ListView(padding: const EdgeInsets.only(bottom: 32), children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 18),
          child: Column(children: [
            GroupAvatar(name: g.name, url: g.avatarUrl, radius: 48),
            const SizedBox(height: 10),
            Text(g.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            Text(g.memberCount == 1 ? '1 participante' : '${g.memberCount} participantes', style: TextStyle(color: AppColors.textMuted)),
            if (g.description.isNotEmpty)
              Padding(padding: const EdgeInsets.fromLTRB(24, 8, 24, 0), child: Text(g.description, textAlign: TextAlign.center, style: TextStyle(color: AppColors.textMuted))),
          ]),
        ),
        _card([
          if (g.isAdmin) ...[
            ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Editar nome e descrição'), onTap: _edit),
            ListTile(leading: const Icon(Icons.photo_outlined), title: const Text('Trocar foto do grupo'), onTap: _pickAvatar),
            if (g.avatarUrl != null) ListTile(leading: const Icon(Icons.delete_outline), title: const Text('Remover foto'), onTap: () => _run(() => _service.removeAvatar(g.id))),
          ],
          ListTile(
            leading: Icon(p.muted ? Icons.notifications_active_outlined : Icons.notifications_off_outlined),
            title: Text(p.muted ? 'Reativar notificações' : 'Silenciar notificações'),
            onTap: () => _setPrefs(muted: !p.muted),
          ),
          ListTile(
            leading: Icon(p.pinned ? Icons.push_pin_outlined : Icons.push_pin),
            title: Text(p.pinned ? 'Desafixar da lista' : 'Fixar na lista'),
            onTap: () => _setPrefs(pinned: !p.pinned),
          ),
          ListTile(
            leading: Icon(p.archived ? Icons.unarchive_outlined : Icons.archive_outlined),
            title: Text(p.archived ? 'Desarquivar' : 'Arquivar'),
            onTap: () => _setPrefs(archived: !p.archived),
          ),
        ]),
        Padding(
          padding: EdgeInsets.fromLTRB(20, 12, 20, 2),
          child: Text('PARTICIPANTES', style: TextStyle(fontSize: 12, letterSpacing: 0.8, color: AppColors.textMuted, fontWeight: FontWeight.w600)),
        ),
        _card([
          if (g.isAdmin) ListTile(leading: const Icon(Icons.person_add_alt_1_outlined), title: const Text('Adicionar participantes'), onTap: _addPeople),
          ...g.members.map(_member),
        ]),
        _card([
          ListTile(leading: Icon(Icons.logout, color: AppColors.danger), title: Text('Sair do grupo', style: TextStyle(color: AppColors.danger)), onTap: _leave),
          if (g.isOwner) ListTile(leading: Icon(Icons.delete_forever_outlined, color: AppColors.danger), title: Text('Apagar grupo', style: TextStyle(color: AppColors.danger)), onTap: _deleteGroup),
        ]),
      ]),
    );
  }
}
