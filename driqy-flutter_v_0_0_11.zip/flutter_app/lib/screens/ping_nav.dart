import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../widgets/ping_tab_bar.dart';
import '../widgets/ping_wide.dart';
import 'calls_history_screen.dart';
import 'ping_contacts_screen.dart';

/// Pede à lista de conversas (`MessagesInboxScreen`) que abra o menu lateral. Usado pela aba
/// "Menu" das telas que ficam POR CIMA da lista (Contatos): elas voltam para a lista e disparam isto.
class PingMenuSignal {
  PingMenuSignal._();
  static final ValueNotifier<int> _tick = ValueNotifier<int>(0);
  static ValueListenable<int> get listenable => _tick;
  static void request() => _tick.value++;
}

/// Navegação da pílula de Mensagens. A lista de conversas (`MessagesInboxScreen`) fica sempre
/// embaixo na pilha; Contatos e Chamadas são UMA tela por cima dela (trocar entre as duas usa
/// `pushReplacement`, então a pilha não cresce). Configurações/Perfil saíram: agora ficam no menu lateral.
class PingNav {
  PingNav._();

  static void go(BuildContext context, {required PingTab from, required PingTab to, int unread = 0}) {
    if (from == to) return;
    final nav = Navigator.of(context);
    switch (to) {
      case PingTab.chats:
        nav.maybePop(); // a lista de conversas está logo abaixo
        break;
      case PingTab.contacts:
      case PingTab.calls:
        final Route<void> route = to == PingTab.contacts
            ? pingRoute<void>(context, PingContactsScreen(unread: unread))
            : MaterialPageRoute<void>(builder: (_) => const CallsHistoryScreen());
        if (from == PingTab.chats) {
          nav.push(route);
        } else {
          nav.pushReplacement(route);
        }
        break;
    }
  }

  /// Aba "Menu" fora da lista: volta para a lista e pede o menu lateral aberto.
  static void openMenu(BuildContext context) {
    Navigator.of(context).maybePop();
    PingMenuSignal.request();
  }

  /// Pílula pronta para as telas que não são a lista de conversas.
  static Widget tabBar(BuildContext context, {required PingTab current, int unread = 0}) {
    return PingTabBar(
      unread: unread,
      current: current,
      onChats: () => go(context, from: current, to: PingTab.chats, unread: unread),
      onContacts: () => go(context, from: current, to: PingTab.contacts, unread: unread),
      onCalls: () => go(context, from: current, to: PingTab.calls, unread: unread),
      onMenu: () => openMenu(context),
    );
  }
}
