import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Editor de enquadramento (arrastar + zoom), espelhando o modal
/// "Ajustar foto de perfil/capa" do site (`profile-editor.js`): o ajuste
/// acontece NO MOMENTO DO UPLOAD, antes de salvar — por isso a tela de
/// editar perfil não precisa de botão "Ajustar".
///
/// Devolve (via `Navigator.pop`) um [File] PNG já recortado no tamanho
/// final (avatar 480x480, capa 1200x400) com fundo branco por baixo, ou
/// `null` se a pessoa cancelar.
class ImageCropScreen extends StatefulWidget {
  final File file;
  final bool circle;
  final int outputWidth;
  final int outputHeight;
  final String title;

  const ImageCropScreen({
    super.key,
    required this.file,
    required this.circle,
    required this.outputWidth,
    required this.outputHeight,
    required this.title,
  });

  @override
  State<ImageCropScreen> createState() => _ImageCropScreenState();
}

class _ImageCropScreenState extends State<ImageCropScreen> {
  ui.Image? _image;
  String? _error;
  bool _applying = false;

  // Tamanho do quadro de recorte na tela (definido no layout).
  Size _box = Size.zero;
  double _baseScale = 1;
  double _zoom = 1;
  Offset _offset = Offset.zero;

  // Estado do gesto em andamento.
  double _gestureStartZoom = 1;
  Offset _gestureStartOffset = Offset.zero;
  Offset _gestureStartFocal = Offset.zero;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  @override
  void dispose() {
    _image?.dispose();
    super.dispose();
  }

  Future<void> _loadImage() async {
    try {
      final bytes = await widget.file.readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      if (!mounted) return;
      setState(() => _image = frame.image);
    } catch (_) {
      if (mounted) setState(() => _error = 'Não foi possível abrir essa imagem.');
    }
  }

  void _setupLayout(Size box) {
    if (_box == box || _image == null) return;
    _box = box;
    _baseScale = math.max(box.width / _image!.width, box.height / _image!.height);
    _zoom = 1;
    _offset = Offset(
      (box.width - _image!.width * _baseScale) / 2,
      (box.height - _image!.height * _baseScale) / 2,
    );
    _clamp();
  }

  double get _scale => _baseScale * _zoom;

  void _clamp() {
    final img = _image;
    if (img == null) return;
    final drawW = img.width * _scale;
    final drawH = img.height * _scale;
    final minX = math.min(0.0, _box.width - drawW);
    final minY = math.min(0.0, _box.height - drawH);
    _offset = Offset(
      _offset.dx.clamp(minX, 0.0),
      _offset.dy.clamp(minY, 0.0),
    );
  }

  /// Muda o zoom mantendo fixo o ponto [focal] (em coordenadas do quadro).
  void _applyZoom(double newZoom, Offset focal) {
    newZoom = newZoom.clamp(1.0, 3.0);
    final oldScale = _scale;
    final newScale = _baseScale * newZoom;
    final imgPoint = (focal - _offset) / oldScale;
    _zoom = newZoom;
    _offset = focal - imgPoint * newScale;
    _clamp();
  }

  Future<void> _apply() async {
    final img = _image;
    if (img == null || _applying) return;
    setState(() => _applying = true);
    try {
      final outW = widget.outputWidth;
      final outH = widget.outputHeight;
      final k = outW / _box.width;

      final recorder = ui.PictureRecorder();
      final canvas = Canvas(recorder, Rect.fromLTWH(0, 0, outW.toDouble(), outH.toDouble()));
      // Base branca: pixels transparentes (PNG/WEBP) não viram preto.
      canvas.drawRect(
        Rect.fromLTWH(0, 0, outW.toDouble(), outH.toDouble()),
        Paint()..color = Colors.white,
      );
      canvas.save();
      canvas.scale(k);
      canvas.translate(_offset.dx, _offset.dy);
      canvas.scale(_scale);
      canvas.drawImage(img, Offset.zero, Paint()..filterQuality = FilterQuality.high);
      canvas.restore();

      final picture = recorder.endRecording();
      final out = await picture.toImage(outW, outH);
      final data = await out.toByteData(format: ui.ImageByteFormat.png);
      out.dispose();
      if (data == null) throw Exception('encode');
      final bytes = Uint8List.view(data.buffer);

      final dir = Directory.systemTemp;
      final name = '${widget.circle ? 'avatar' : 'capa'}_${DateTime.now().millisecondsSinceEpoch}.png';
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(bytes, flush: true);
      if (mounted) Navigator.of(context).pop(file);
    } catch (_) {
      if (mounted) {
        setState(() => _applying = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível aplicar o recorte.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final aspect = widget.outputWidth / widget.outputHeight;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: _applying ? null : () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: _error != null
            ? Center(child: Text(_error!, style: TextStyle(color: AppColors.danger)))
            : _image == null
                ? const Center(child: CircularProgressIndicator())
                : Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Expanded(
                          child: Center(
                            child: LayoutBuilder(
                              builder: (context, constraints) {
                                var w = constraints.maxWidth;
                                var h = w / aspect;
                                if (h > constraints.maxHeight) {
                                  h = constraints.maxHeight;
                                  w = h * aspect;
                                }
                                final size = Size(w, h);
                                _setupLayout(size);
                                return _buildViewport(size);
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Icon(Icons.zoom_out, size: 18, color: AppColors.textMuted),
                            Expanded(
                              child: Slider(
                                min: 1,
                                max: 3,
                                value: _zoom,
                                onChanged: (v) => setState(
                                  () => _applyZoom(v, Offset(_box.width / 2, _box.height / 2)),
                                ),
                              ),
                            ),
                            Icon(Icons.zoom_in, size: 18, color: AppColors.textMuted),
                          ],
                        ),
                        Text(
                          'Arraste a imagem para posicionar e use o controle para o zoom.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: _applying ? null : () => Navigator.of(context).pop(),
                                child: const Text('Cancelar'),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: FilledButton(
                                onPressed: _applying ? null : _apply,
                                child: _applying
                                    ? const SizedBox(
                                        height: 18,
                                        width: 18,
                                        child: CircularProgressIndicator(strokeWidth: 2),
                                      )
                                    : const Text('Aplicar'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }

  Widget _buildViewport(Size size) {
    return GestureDetector(
      onScaleStart: (d) {
        _gestureStartZoom = _zoom;
        _gestureStartOffset = _offset;
        _gestureStartFocal = d.localFocalPoint;
      },
      onScaleUpdate: (d) {
        setState(() {
          _zoom = _gestureStartZoom;
          _offset = _gestureStartOffset + (d.localFocalPoint - _gestureStartFocal);
          if (d.pointerCount > 1 && d.scale != 1) {
            _applyZoom(_gestureStartZoom * d.scale, d.localFocalPoint);
          } else {
            _clamp();
          }
        });
      },
      child: SizedBox(
        width: size.width,
        height: size.height,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(widget.circle ? size.width / 2 : 12),
          child: CustomPaint(
            painter: _CropPainter(image: _image!, scale: _scale, offset: _offset),
          ),
        ),
      ),
    );
  }
}

class _CropPainter extends CustomPainter {
  final ui.Image image;
  final double scale;
  final Offset offset;

  _CropPainter({required this.image, required this.scale, required this.offset});

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    canvas.save();
    canvas.translate(offset.dx, offset.dy);
    canvas.scale(scale);
    canvas.drawImage(image, Offset.zero, Paint()..filterQuality = FilterQuality.medium);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_CropPainter old) =>
      old.image != image || old.scale != scale || old.offset != offset;
}
