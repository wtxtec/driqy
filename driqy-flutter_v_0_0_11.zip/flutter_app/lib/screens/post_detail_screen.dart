import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/comment.dart';
import '../models/post.dart';
import '../services/auth_service.dart';
import '../services/post_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_spacing.dart';
import '../widgets/comment_tile.dart';
import '../widgets/post_card.dart';
import 'profile_screen.dart';

class PostDetailScreen extends StatefulWidget {
  final int postId;

  /// Quando a pessoa chegou aqui pelo botão de comentários, já abre com o
  /// campo de comentário focado.
  final bool focusComment;

  const PostDetailScreen({super.key, required this.postId, this.focusComment = false});

  @override
  State<PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<PostDetailScreen> {
  late PostService _postService;
  DriqyPost? _post;
  List<DriqyComment> _comments = [];
  bool _loading = true;
  bool _sending = false;
  String? _error;
  DriqyComment? _replyingTo;
  final _commentController = TextEditingController();
  final _commentFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _postService = PostService(context.read<AuthService>().client);
    _load();
  }

  @override
  void dispose() {
    _commentController.dispose();
    _commentFocusNode.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        _postService.getPost(widget.postId),
        _postService.getComments(widget.postId),
      ]);
      setState(() {
        _post = results[0] as DriqyPost;
        _comments = results[1] as List<DriqyComment>;
      });
      if (widget.focusComment) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _commentFocusNode.requestFocus();
        });
      }
    } catch (_) {
      setState(() => _error = 'Não foi possível carregar o post.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _toggleLike() async {
    final post = _post;
    if (post == null) return;
    final wasLiked = post.likedByMe;
    setState(() {
      post.likedByMe = !wasLiked;
      post.likesCount += wasLiked ? -1 : 1;
    });
    try {
      final liked = await _postService.toggleLike(post.id);
      if (mounted) setState(() => post.likedByMe = liked);
    } catch (_) {
      if (mounted) {
        setState(() {
          post.likedByMe = wasLiked;
          post.likesCount += wasLiked ? 1 : -1;
        });
      }
    }
  }

  Future<void> _sendComment() async {
    final content = _commentController.text.trim();
    if (content.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final comment = await _postService.addComment(
        widget.postId,
        content,
        parentId: _replyingTo?.id,
      );
      setState(() {
        _comments = [..._comments, comment];
        _post?.commentsCount += 1;
        _commentController.clear();
        _replyingTo = null;
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível enviar o comentário.')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _startReply(DriqyComment comment) {
    setState(() => _replyingTo = comment);
    _commentFocusNode.requestFocus();
  }

  void _cancelReply() => setState(() => _replyingTo = null);

  void _openProfile(String username) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProfileScreen(username: username)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null || _post == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error ?? 'Post não encontrado.'),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _load, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    final post = _post!;
    return Column(
      children: [
        Expanded(
          child: ListView(
            children: [
              PostCard(
                post: post,
                onLikeTap: _toggleLike,
                onAuthorTap: () => _openProfile(post.author.username),
                // Já estamos na página do post: o botão só leva ao campo
                // de comentário.
                onCommentsTap: () => _commentFocusNode.requestFocus(),
                onDelete: () async {
                  await _postService.deletePost(post.id);
                  if (mounted) Navigator.of(context).pop();
                },
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(AppSpacing.gap, 0, AppSpacing.gap, AppSpacing.gap),
                child: Text('Comentários', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              if (_comments.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('Nenhum comentário ainda. Seja o primeiro!')),
                )
              else
                ...buildCommentTree(_comments).map((node) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: CommentTile(node: node, onReply: _startReply),
                    )),
              const SizedBox(height: 80),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_replyingTo != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Respondendo a @${_replyingTo!.author.username}',
                            style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        GestureDetector(
                          onTap: _cancelReply,
                          child: Icon(Icons.close, size: 16, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _commentController,
                        focusNode: _commentFocusNode,
                        decoration: InputDecoration(
                          hintText: _replyingTo == null
                              ? 'Escreva um comentário...'
                              : 'Responder a @${_replyingTo!.author.username}...',
                          border: const OutlineInputBorder(),
                          isDense: true,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        ),
                        minLines: 1,
                        maxLines: 4,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _sendComment(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    _sending
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : IconButton(
                            icon: const Icon(Icons.send),
                            onPressed: _sendComment,
                          ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
