import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/news_article.dart';
import '../services/auth_service.dart';
import '../services/news_service.dart';
import '../theme/app_colors.dart';
import '../widgets/gradient_button.dart';

/// Espelha `news_interests.html`: escolha das categorias que o usuário
/// quer ver mais no feed de notícias (some com o que ele mais clica pra
/// ler, contabilizado automaticamente pelo recomendador no servidor).
class NewsInterestsScreen extends StatefulWidget {
  const NewsInterestsScreen({super.key});

  @override
  State<NewsInterestsScreen> createState() => _NewsInterestsScreenState();
}

class _NewsInterestsScreenState extends State<NewsInterestsScreen> {
  late NewsService _service;
  List<NewsCategory> _categories = [];
  final Set<String> _selected = {};
  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _service = NewsService(context.read<AuthService>().client);
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await _service.getInterests();
      setState(() {
        _categories = data.categories;
        _selected
          ..clear()
          ..addAll(data.selected);
      });
    } catch (_) {
      setState(() => _error = 'Não foi possível carregar seus interesses.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await _service.updateInterests(_selected.toList());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Seus interesses foram atualizados.')),
        );
        Navigator.of(context).pop();
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível salvar. Tente de novo.')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Meus interesses')),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!, style: TextStyle(color: AppColors.textMuted)),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _load, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
          child: Text(
            'Escolha os assuntos que você quer ver mais no seu feed de notícias. '
            'O que você mais clica pra ler também entra na conta automaticamente.',
            style: TextStyle(color: AppColors.textMuted, fontSize: 13.5, height: 1.4),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: [
              for (final category in _categories)
                CheckboxListTile(
                  value: _selected.contains(category.key),
                  onChanged: (checked) {
                    setState(() {
                      if (checked == true) {
                        _selected.add(category.key);
                      } else {
                        _selected.remove(category.key);
                      }
                    });
                  },
                  title: Text(category.label, style: TextStyle(color: AppColors.text)),
                  activeColor: AppColors.amber,
                  checkColor: AppColors.onBrand,
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: GradientButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.onBrand),
                  )
                : const Text('Salvar interesses'),
          ),
        ),
      ],
    );
  }
}
