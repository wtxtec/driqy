import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:photo_manager/photo_manager.dart' show AssetType;
import 'package:open_filex/open_filex.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/call.dart';
import '../models/message.dart';
import '../models/presence.dart';
import '../models/user.dart';
import '../services/api_exception.dart';
import '../services/chat_live.dart';
import '../services/auth_service.dart';
import '../services/call_manager.dart';
import '../services/message_service.dart';
import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';
import '../widgets/ping_wide.dart';
import '../widgets/chat/attach_sheet.dart';
import '../widgets/chat/chat_composer.dart';
import '../widgets/chat/chat_format.dart';
import '../widgets/chat/date_separator.dart';
import '../widgets/chat/emoji_panel.dart';
import '../widgets/chat/file_message.dart';
import '../widgets/chat/message_bubble.dart';
import '../widgets/media_lightbox.dart';
import 'chat_forward_screen.dart';
import 'view_once_viewer.dart';
import 'chat_image_preview_screen.dart';
import 'chat_video_player_screen.dart';
import 'chat_video_preview_screen.dart';

/// Conversa 1-para-1 (Fases 2–7 do chat): balões agrupados, separadores de
/// data, ticks de status, emojis/reações, imagens e GIFs (galeria/câmera com
/// pré-visualização), mensagens de voz (segurar o microfone), vídeos (galeria/câmera com
/// pré-visualização e player), responder (deslizar ou menu), copiar,
/// apagar para mim/para todos, editar texto, encaminhar, buscar na conversa
/// (Fase 8), envio otimista com reenvio e atualização periódica leve. O tempo real de verdade (WebSocket/SSE) é a Fase 9 e
/// substitui o `_pollTimer`.
class MessageThreadScreen extends StatefulWidget {
  final String username;

  const MessageThreadScreen({super.key, required this.username});

  @override
  State<MessageThreadScreen> createState() => _MessageThreadScreenState();
}

/// Item da lista: ou um separador de data ou uma mensagem.
class _Item {
  final String? dayLabel;
  final DriqyMessage? message;
  final bool grouped;

  const _Item.day(this.dayLabel)
      : message = null,
        grouped = false;
  const _Item.message(this.message, {this.grouped = false}) : dayLabel = null;
}

class _MessageThreadScreenState extends State<MessageThreadScreen> with WidgetsBindingObserver {
  static const _pollInterval = Duration(seconds: 8);
  static const _groupGap = Duration(minutes: 5);

  late MessageService _service;
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final _showJumpButton = ValueNotifier<bool>(false);
  final _jumpCount = ValueNotifier<int>(0); // Ping 6b: mensagens novas enquanto estou longe do fim
  DriqyPinned? _pinned; // Ping 6b: mensagem fixada (só para mim)

  DriqyUser? _partner;
  DriqyMessage? _replyingTo; // mensagem que está sendo respondida (Fase 7)
  final Map<int, GlobalKey> _msgKeys = {}; // para rolar até a mensagem citada
  final _composerFocus = FocusNode();
  DriqyMessage? _editing; // mensagem de texto em edição (Fase 8)

  // busca na conversa (Fase 8)
  bool _searching = false;
  final _searchController = TextEditingController();
  final _searchFocus = FocusNode();
  Timer? _searchDebounce;
  int _searchSeq = 0;
  String _searchTerm = ''; // termo do resultado atual (realça nos balões)
  String _searchStatus = '';
  List<int> _searchIds = []; // mais recentes primeiro
  int _searchPos = -1;
  int? _searchCurrentId;
  List<DriqyMessage> _messages = [];
  bool _loading = true;
  bool _refreshing = false;
  String? _error;
  Timer? _pollTimer;

  // tempo real (Fase 9)
  StreamSubscription<ChatEvent>? _liveSub;
  Timer? _liveDebounce;
  Timer? _typingExpire;
  String? _partnerState; // typing | recording | null
  DriqyPresence _presence = DriqyPresence.hidden; // Fase 10: online / visto por último
  DriqyChatPrefs _prefs = const DriqyChatPrefs(); // Fase 10
  Timer? _presenceTick; // reenvelhece o "visto por último" a cada minuto
  DateTime _lastTypingSent = DateTime.fromMillisecondsSinceEpoch(0);
  bool _iAmTyping = false;
  int _pollTick = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final client = context.read<AuthService>().client;
    _service = MessageService(client);
    _scrollController.addListener(_onScroll);
    ChatLive.instance.acquire(client);
    _liveSub = ChatLive.instance.events.listen(_onLive);
    _controller.addListener(_onTextChanged);
    _presenceTick = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });
    _load();
    _startPolling();
  }

  void _onLive(ChatEvent e) {
    final p = e.partner;
    if (e.type == 'presence') {
      if (p == widget.username && mounted) {
        setState(() {
          _presence = DriqyPresence(
            visible: e.visible,
            online: e.online,
            lastSeenAt: e.lastSeenAt != null ? DateTime.tryParse(e.lastSeenAt!) : null,
          );
        });
      }
      return;
    }
    // `prefs` com partner vazio = mudei minha privacidade em outro aparelho: rebusca a presença
    if (e.type == 'prefs' && (p == null || p.isEmpty)) {
      _refresh();
      return;
    }
    if (p != null && p != widget.username) return; // é de outra conversa
    if (e.type == 'typing') {
      _setPartnerState(e.state);
      return;
    }
    if (e.type == 'message') _setPartnerState(null);
    _liveDebounce?.cancel(); // junta rajadas de eventos
    _liveDebounce = Timer(const Duration(milliseconds: 120), () {
      if (mounted) _refresh();
    });
  }

  void _setPartnerState(String? state) {
    _typingExpire?.cancel();
    final active = state == 'typing' || state == 'recording';
    if (mounted) setState(() => _partnerState = active ? state : null);
    if (active) {
      // sumiu o aviso = parou de digitar
      _typingExpire = Timer(const Duration(seconds: 6), () {
        if (mounted) setState(() => _partnerState = null);
      });
    }
  }

  /// Avisa o outro lado que estou digitando (no máx. 1 vez a cada 3 s) e quando paro.
  void _onTextChanged() {
    final has = _controller.text.trim().isNotEmpty && _editing == null;
    if (has) {
      final now = DateTime.now();
      if (now.difference(_lastTypingSent) < const Duration(seconds: 3)) return;
      _lastTypingSent = now;
      _iAmTyping = true;
      _service.sendTyping(widget.username, 'typing');
    } else if (_iAmTyping) {
      _iAmTyping = false;
      _lastTypingSent = DateTime.fromMillisecondsSinceEpoch(0);
      _service.sendTyping(widget.username, 'stop');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pollTimer?.cancel();
    _liveSub?.cancel();
    _liveDebounce?.cancel();
    _presenceTick?.cancel();
    _typingExpire?.cancel();
    ChatLive.instance.release();
    if (_iAmTyping) _service.sendTyping(widget.username, 'stop');
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    _composerFocus.dispose();
    _searchDebounce?.cancel();
    _searchController.dispose();
    _searchFocus.dispose();
    _scrollController.dispose();
    _showJumpButton.dispose();
    _jumpCount.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refresh();
      _startPolling();
    } else {
      _pollTimer?.cancel();
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    // com o stream vivo, o polling vira rede de segurança (a cada ~32 s)
    _pollTimer = Timer.periodic(_pollInterval, (_) {
      if (ChatLive.instance.connected && ++_pollTick % 4 != 0) return;
      _refresh();
    });
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final pos = _scrollController.position;
    _showJumpButton.value = pos.maxScrollExtent - pos.pixels > 300;
    if (_nearBottom && _jumpCount.value != 0) _jumpCount.value = 0;
  }

  bool get _nearBottom {
    if (!_scrollController.hasClients) return true;
    final pos = _scrollController.position;
    return pos.maxScrollExtent - pos.pixels < 120;
  }

  /// Mensagens do servidor + as locais (enviando/falhou) que o servidor
  /// ainda não devolveu — o `client_id` evita duplicar a mesma mensagem.
  List<DriqyMessage> _merge(List<DriqyMessage> server) {
    final serverClientIds = {
      for (final m in server)
        if (m.clientId != null) m.clientId!,
    };
    final locals = _messages.where(
      (m) => m.localState != null && !serverClientIds.contains(m.clientId),
    );
    return [...server, ...locals];
  }

  String _signature(List<DriqyMessage> list) => list
      .map((m) =>
          '${m.id}:${m.readAt?.millisecondsSinceEpoch}:${m.deleted}:${m.localState?.index}:'
          '${m.editedAt?.millisecondsSinceEpoch}:${m.replyTo?.preview}:${m.canEdit}:'
          '${m.reactions.map((r) => '${r.emoji}${r.count}${r.mine}').join(',')}')
      .join('|');

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final thread = await _service.getThread(widget.username);
      if (!mounted) return;
      setState(() {
        _partner = thread.partner;
        _presence = thread.presence;
        _prefs = thread.prefs;
        _pinned = thread.pinned;
        _messages = _merge(thread.messages);
      });
      _scrollToEnd(animated: false);
    } catch (_) {
      if (mounted) setState(() => _error = 'Não foi possível carregar a conversa.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Atualização silenciosa: só mexe na tela se algo mudou.
  Future<void> _refresh() async {
    if (_loading || _refreshing || !mounted) return;
    _refreshing = true;
    try {
      final thread = await _service.getThread(widget.username);
      if (!mounted) return;
      final merged = _merge(thread.messages);
      setState(() {
        _presence = thread.presence;
        _prefs = thread.prefs;
        _pinned = thread.pinned;
      });
      if (_signature(merged) != _signature(_messages)) {
        final stick = _nearBottom;
        final known = {for (final m in _messages) m.id};
        final fresh =
            merged.where((m) => !m.mine && m.localState == null && !known.contains(m.id)).length;
        setState(() => _messages = merged);
        if (stick) {
          _scrollToEnd();
        } else if (fresh > 0) {
          _jumpCount.value += fresh;
        }
      }
    } catch (_) {
      // falha de rede em segundo plano: ignora, tenta de novo no próximo ciclo
    } finally {
      _refreshing = false;
    }
  }

  void _scrollToEnd({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      final target = _scrollController.position.maxScrollExtent;
      if (animated) {
        _scrollController.animateTo(
          target,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      } else {
        _scrollController.jumpTo(target);
      }
    });
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    if (_editing != null) {
      await _submitEdit(text);
      return;
    }
    _controller.clear();
    final local = _withReply(DriqyMessage.local(clientId: DriqyMessage.newClientId(), content: text));
    setState(() => _messages = [..._messages, local]);
    _scrollToEnd();
    await _deliver(local);
  }

  /// Envia (ou reenvia) uma mensagem local. Seguro repetir: o `client_id`
  /// faz o servidor devolver a mesma mensagem se ela já tinha chegado.
  Future<void> _deliver(DriqyMessage local) async {
    try {
      final path = local.localPath;
      final sent = (local.type == MessageType.file && path != null)
          ? await _service.sendFile(
              widget.username,
              File(path),
              name: local.mediaName ?? 'arquivo',
              caption: local.caption ?? '',
              clientId: local.clientId,
              replyToId: local.replyTo?.id,
            )
          : (local.type == MessageType.video && path != null)
          ? await _service.sendVideo(
              widget.username,
              File(path),
              durationMs: local.mediaDurationMs ?? 0,
              caption: local.caption ?? '',
              width: local.mediaWidth,
              height: local.mediaHeight,
              thumb: local.localThumbPath != null ? File(local.localThumbPath!) : null,
              clientId: local.clientId,
              replyToId: local.replyTo?.id,
              viewOnce: local.viewOnce,
            )
          : (local.type == MessageType.audio && path != null)
          ? await _service.sendAudio(
              widget.username,
              File(path),
              durationMs: local.mediaDurationMs ?? 0,
              clientId: local.clientId,
              replyToId: local.replyTo?.id,
              viewOnce: local.viewOnce,
            )
          : (local.type == MessageType.image && path != null)
          ? await _service.sendImage(
              widget.username,
              File(path),
              caption: local.caption ?? '',
              clientId: local.clientId,
              width: local.mediaWidth,
              height: local.mediaHeight,
              replyToId: local.replyTo?.id,
              viewOnce: local.viewOnce,
            )
          : await _service.sendMessage(
              widget.username,
              local.content,
              clientId: local.clientId,
              replyToId: local.replyTo?.id,
            );
      if (!mounted) return;
      setState(() {
        // se o refresh já trouxe a mensagem do servidor, só remove a local
        final already = _messages.any((m) => m.id == sent.id);
        final next = <DriqyMessage>[];
        for (final m in _messages) {
          if (m.clientId == local.clientId && m.localState != null) {
            if (!already) next.add(sent);
          } else {
            next.add(m);
          }
        }
        _messages = next;
      });
      // Fase 15: a gravação de voz era um arquivo temporário; já subiu, pode sair do disco
      if (local.type == MessageType.audio && path != null) {
        try {
          await File(path).delete();
        } catch (_) {/* sem problema: o sistema limpa o cache depois */}
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _messages = [
          for (final m in _messages)
            if (m.clientId == local.clientId && m.localState != null)
              m.copyWith(localState: MessageLocalState.failed)
            else
              m,
        ];
      });
    }
  }

  void _retry(DriqyMessage failed) {
    setState(() {
      _messages = [
        for (final m in _messages)
          if (m.clientId == failed.clientId && m.localState != null)
            m.copyWith(localState: MessageLocalState.sending)
          else
            m,
      ];
    });
    _deliver(failed);
  }

  // ---------- imagens / GIFs (Fase 4) ----------
  static const _maxImageBytes = 15 * 1024 * 1024; // = CHAT_MAX_IMAGE_BYTES do servidor

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  /// Clipe 📎: escolhe Galeria ou Câmera, mostra a pré-visualização com
  /// legenda e só então envia.
  Future<void> _attach() async {
    if (_editing != null) {
      _snack('Termine ou cancele a edição primeiro.');
      return;
    }
    final pick = await showAttachSheet(context);
    if (pick == null || !mounted) return;
    switch (pick.kind) {
      case AttachKind.file:
        await _pickFile();
        return;
      case AttachKind.videoCamera:
        await _pickVideo(ImageSource.camera);
        return;
      case AttachKind.camera:
        await _pickImage(ImageSource.camera);
        return;
      case AttachKind.asset:
        final asset = pick.asset!;
        final f = await asset.originFile; // original: preserva a animação do GIF
        if (f == null || !mounted) {
          _snack('Não foi possível abrir o arquivo.');
          return;
        }
        if (asset.type == AssetType.video) {
          await _videoFromFile(f);
        } else {
          await _imageFromFile(f);
        }
        return;
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      // Câmera: foto grande é reduzida. Galeria vai sem reencodar (mataria o GIF).
      final picked = await ImagePicker().pickImage(
        source: source,
        maxWidth: source == ImageSource.camera ? 2048 : null,
        imageQuality: source == ImageSource.camera ? 88 : null,
      );
      if (picked == null || !mounted) return;
      await _imageFromFile(File(picked.path));
    } catch (_) {
      _snack('Não foi possível abrir a imagem.');
    }
  }

  Future<void> _imageFromFile(File file) async {
    try {
      if (await file.length() > _maxImageBytes) {
        _snack('Imagem grande demais (máx. 15 MB).');
        return;
      }
      if (!mounted) return;
      final draft = await Navigator.of(context).push<ChatImageDraft>(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => ChatImagePreviewScreen(
            file: file,
            initialCaption: _controller.text.trim(),
          ),
        ),
      );
      if (draft == null || !mounted) return;
      if (draft.caption.isNotEmpty && _controller.text.trim() == draft.caption) {
        _controller.clear(); // a legenda veio do campo de texto: não duplica
      }
      await _sendImage(draft);
    } catch (_) {
      _snack('Não foi possível abrir a imagem.');
    }
  }

  Future<void> _sendImage(ChatImageDraft draft) async {
    final local = _withReply(DriqyMessage.localImage(
      clientId: DriqyMessage.newClientId(),
      path: draft.file.path,
      caption: draft.caption,
      width: draft.width,
      height: draft.height,
      viewOnce: draft.viewOnce,
    ));
    setState(() => _messages = [..._messages, local]);
    _scrollToEnd();
    await _deliver(local);
  }

  // ---------- documentos (Fase 15) ----------
  static const _maxFileBytes = 25 * 1024 * 1024; // = CHAT_MAX_FILE_BYTES do servidor
  static const _fileExts = [
    'pdf', 'txt', 'csv', 'json', 'zip', 'rtf', 'doc', 'docx', 'xls', 'xlsx', //
    'ppt', 'pptx', 'odt', 'ods', 'odp', 'heic', 'heif',
  ];
  final Set<int> _downloadingFiles = {};

  /// Escolhe um documento, confere tipo/tamanho (o servidor confere a assinatura de novo),
  /// pede uma legenda opcional e envia como qualquer outra mídia (envio otimista + reenvio).
  Future<void> _pickFile() async {
    try {
      final res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: _fileExts,
        allowMultiple: false,
      );
      final f = (res == null || res.files.isEmpty) ? null : res.files.first;
      if (f == null || f.path == null || !mounted) return;
      final file = File(f.path!);
      final size = await file.length();
      if (size <= 0) {
        _snack('Arquivo vazio.');
        return;
      }
      if (size > _maxFileBytes) {
        _snack('Arquivo grande demais (máx. 25 MB).');
        return;
      }
      if (!mounted) return;
      final caption = await _askFileCaption(f.name, size);
      if (caption == null || !mounted) return;
      final local = _withReply(DriqyMessage.localFile(
        clientId: DriqyMessage.newClientId(),
        path: file.path,
        name: f.name,
        size: size,
        caption: caption,
      ));
      setState(() => _messages = [..._messages, local]);
      _scrollToEnd();
      await _deliver(local);
    } catch (_) {
      _snack('Não foi possível abrir o arquivo.');
    }
  }

  /// Confirmação com legenda. Devolve null se cancelar, '' se enviar sem legenda.
  Future<String?> _askFileCaption(String name, int size) {
    final ctrl = TextEditingController(text: _controller.text.trim());
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Enviar arquivo'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(name, maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 2),
            Text(fileSizeLabel(size), style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              maxLength: 2000,
              maxLines: 3,
              minLines: 1,
              decoration: const InputDecoration(hintText: 'Adicionar legenda…'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: const Text('Enviar'),
          ),
        ],
      ),
    ).then((v) {
      if (v != null && v.isNotEmpty && _controller.text.trim() == v) _controller.clear();
      return v;
    });
  }

  /// Baixa (com Bearer) para a pasta temporária e abre no app do sistema.
  Future<void> _openFile(DriqyMessage m) async {
    if (_downloadingFiles.contains(m.id)) return;
    setState(() => _downloadingFiles.add(m.id));
    try {
      final out = await _service.downloadFile(m);
      final r = await OpenFilex.open(out.path);
      if (r.type != ResultType.done) {
        _snack(r.type == ResultType.noAppToOpen
            ? 'Nenhum app instalado abre este tipo de arquivo.'
            : 'Não foi possível abrir o arquivo.');
      }
    } catch (_) {
      _snack('Falha ao baixar o arquivo.');
    } finally {
      if (mounted) setState(() => _downloadingFiles.remove(m.id));
    }
  }

  // ---------- vídeo (Fase 6) ----------
  static const _maxVideoBytes = 55 * 1024 * 1024; // = CHAT_MAX_VIDEO_BYTES do servidor

  /// Escolhe da galeria ou grava (máx. 5 min), confere o limite de 55 MB do
  /// servidor, mostra a pré-visualização com legenda e só então envia.
  Future<void> _pickVideo(ImageSource source) async {
    try {
      final picked = await ImagePicker().pickVideo(
        source: source,
        maxDuration: const Duration(minutes: 5),
      );
      if (picked == null || !mounted) return;
      await _videoFromFile(File(picked.path));
    } catch (_) {
      _snack('Não foi possível abrir o vídeo.');
    }
  }

  Future<void> _videoFromFile(File file) async {
    try {
      if (await file.length() > _maxVideoBytes) {
        _snack('Vídeo grande demais (máx. 55 MB). Escolha um mais curto.');
        return;
      }
      if (!mounted) return;
      final draft = await Navigator.of(context).push<ChatVideoDraft>(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => ChatVideoPreviewScreen(
            file: file,
            initialCaption: _controller.text.trim(),
          ),
        ),
      );
      if (draft == null || !mounted) return;
      if (draft.caption.isNotEmpty && _controller.text.trim() == draft.caption) {
        _controller.clear();
      }
      final local = _withReply(DriqyMessage.localVideo(
        clientId: DriqyMessage.newClientId(),
        path: draft.file.path,
        durationMs: draft.durationMs,
        caption: draft.caption,
        width: draft.width,
        height: draft.height,
        viewOnce: draft.viewOnce,
      ));
      setState(() => _messages = [..._messages, local]);
      _scrollToEnd();
      await _deliver(local);
    } catch (_) {
      _snack('Não foi possível abrir o vídeo.');
    }
  }

  void _openVideo(DriqyMessage m) {
    ChatVideoPlayerScreen.open(context, m, headers: _service.mediaHeaders);
  }

  // ---------- visualização única ----------
  bool _voiceOnce = false; // próximo áudio gravado vai como visualização única
  bool _openingOnce = false;

  Future<void> _openViewOnce(DriqyMessage m) async {
    if (_openingOnce || !m.canOpenViewOnce || m.mine) return;
    _openingOnce = true;
    try {
      await ViewOnceViewer.open(context, _service, m);
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Não foi possível abrir.');
    } finally {
      _openingOnce = false;
      if (mounted) await _refresh(); // vira "Aberta" na hora (o aviso ao vivo também chega)
    }
  }

  // ---------- áudio (Fase 5) ----------
  static const _maxAudioBytes = 20 * 1024 * 1024; // = CHAT_MAX_AUDIO_BYTES do servidor

  /// Gravação de voz pronta (vinda do compositor): aparece na hora com
  /// relógio e é enviada com o mesmo esquema de reenvio das imagens.
  Future<void> _sendVoice(File file, int durationMs) async {
    if (await file.length() > _maxAudioBytes) {
      _snack('Áudio grande demais (máx. 20 MB).');
      return;
    }
    if (!mounted) return;
    final once = _voiceOnce;
    if (once && mounted) setState(() => _voiceOnce = false); // vale só para este áudio
    final local = _withReply(DriqyMessage.localAudio(
      clientId: DriqyMessage.newClientId(),
      path: file.path,
      durationMs: durationMs,
      viewOnce: once,
    ));
    setState(() => _messages = [..._messages, local]);
    _scrollToEnd();
    await _deliver(local);
  }

  /// Abre o visualizador nas imagens da conversa (deslizar entre elas).
  void _openImage(DriqyMessage tapped) {
    final images = _messages
        .where((m) =>
            m.type == MessageType.image &&
            !m.deleted &&
            m.localState == null &&
            m.mediaUrl != null)
        .toList();
    final index = images.indexWhere((m) => m.id == tapped.id);
    if (index < 0) return;
    MediaLightbox.open(
      context,
      [for (final m in images) m.mediaUrl!],
      initialIndex: index,
      headers: _service.mediaHeaders,
      mediaTypes: [for (final m in images) m.isGif ? 'gif' : null],
    );
  }

  static const _quickReactions = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

  bool _canReact(DriqyMessage m) => m.id > 0 && m.localState == null && !m.deleted;

  // ---------- mensagem fixada (Ping fase 6b) ----------
  bool _canPin(DriqyMessage m) => _canReact(m) && m.type != MessageType.call && !m.viewOnce;

  Future<void> _setPinned(int? messageId) async {
    try {
      final pinned = await _service.setPinnedMessage(widget.username, messageId);
      if (!mounted) return;
      setState(() => _pinned = pinned);
      _snack(messageId == null ? 'Mensagem desafixada.' : 'Mensagem fixada.');
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Não foi possível alterar a mensagem fixada.');
    }
  }

  // ---------- ações (Fase 7): responder, copiar, apagar ----------
  int? get _myId {
    for (final m in _messages) {
      if (m.mine && m.senderId != 0) return m.senderId;
    }
    return null;
  }

  String _replyAuthor(DriqyReplyRef r) =>
      (r.senderId != null && r.senderId == _myId) ? 'Você' : (_partner?.displayName ?? widget.username);

  /// Anexa a resposta em edição à mensagem local e fecha a barra de resposta.
  DriqyMessage _withReply(DriqyMessage local) {
    final r = _replyingTo;
    if (r == null) return local;
    setState(() => _replyingTo = null);
    return local.copyWith(replyTo: DriqyReplyRef.fromMessage(r));
  }

  void _startReply(DriqyMessage m) {
    if (!_canReact(m)) return;
    if (_editing != null) _cancelEdit();
    setState(() => _replyingTo = m);
  }

  // ---------- editar (Fase 8) ----------
  void _startEdit(DriqyMessage m) {
    if (!m.canEdit || m.id <= 0 || m.localState != null) return;
    setState(() {
      _replyingTo = null;
      _editing = m;
    });
    _controller.text = m.content;
    _controller.selection = TextSelection.collapsed(offset: _controller.text.length);
    _composerFocus.requestFocus();
  }

  void _cancelEdit() {
    if (_editing == null) return;
    setState(() => _editing = null);
    _controller.clear();
  }

  Future<void> _submitEdit(String text) async {
    final target = _editing;
    if (target == null) return;
    if (text == target.content) {
      _cancelEdit(); // nada mudou
      return;
    }
    setState(() => _editing = null);
    _controller.clear();
    try {
      final updated = await _service.editMessage(target.id, text);
      if (!mounted) return;
      setState(() {
        _messages = [for (final x in _messages) x.id == target.id ? updated : x];
      });
    } catch (e) {
      if (!mounted) return;
      _snack(e is ApiException ? e.message : 'Não foi possível editar.');
      if (_controller.text.isEmpty) _controller.text = text; // devolve o texto, não perde
    }
  }

  // ---------- encaminhar (Fase 8) ----------
  Future<void> _forward(DriqyMessage m) async {
    if (m.id <= 0 || m.deleted || m.localState != null || m.viewOnce) return;
    final names = await Navigator.of(context).push<List<String>>(
      MaterialPageRoute(builder: (_) => ChatForwardScreen(service: _service, message: m)),
    );
    if (names == null || !mounted) return;
    _snack(names.length > 1 ? 'Encaminhada para ${names.length} conversas.' : 'Mensagem encaminhada.');
    if (names.contains(widget.username)) _refresh(); // caiu nesta conversa
  }

  // ---------- buscar na conversa (Fase 8) ----------
  void _openSearch() {
    setState(() => _searching = true);
    WidgetsBinding.instance.addPostFrameCallback((_) => _searchFocus.requestFocus());
  }

  void _closeSearch() {
    _searchDebounce?.cancel();
    _searchSeq++;
    _searchController.clear();
    setState(() {
      _searching = false;
      _searchTerm = '';
      _searchStatus = '';
      _searchIds = [];
      _searchPos = -1;
      _searchCurrentId = null;
    });
  }

  void _onSearchChanged(String _) {
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 300), _runSearch);
  }

  Future<void> _runSearch() async {
    final q = _searchController.text.trim();
    final seq = ++_searchSeq;
    if (q.length < 2) {
      setState(() {
        _searchTerm = '';
        _searchIds = [];
        _searchPos = -1;
        _searchCurrentId = null;
        _searchStatus = q.isEmpty ? '' : 'Digite 2+ letras';
      });
      return;
    }
    setState(() => _searchStatus = 'Buscando…');
    try {
      final res = await _service.searchThread(widget.username, q);
      if (!mounted || seq != _searchSeq) return; // resposta de uma digitação antiga
      setState(() {
        _searchTerm = q;
        _searchIds = [for (final m in res.messages) m.id];
        _searchPos = -1;
        _searchCurrentId = null;
        _searchStatus = _searchIds.isEmpty ? 'Nada encontrado' : '';
      });
      if (_searchIds.isNotEmpty) _searchGo(0); // começa pela mais recente
    } catch (e) {
      if (!mounted || seq != _searchSeq) return;
      setState(() => _searchStatus = e is ApiException ? e.message : 'Falha na busca.');
    }
  }

  /// [pos] cíclico: ▲ vai para a mais antiga (pos+1), ▼ para a mais nova (pos-1).
  void _searchGo(int pos) {
    if (_searchIds.isEmpty) return;
    final n = _searchIds.length;
    final p = ((pos % n) + n) % n;
    setState(() {
      _searchPos = p;
      _searchCurrentId = _searchIds[p];
      _searchStatus = '${p + 1} de $n${n >= 100 ? '+' : ''}';
    });
    _jumpToMessage(_searchIds[p]);
  }

  /// Rola até a mensagem [id], mesmo que a lista ainda não a tenha montado
  /// (`ListView.builder`): estima a posição pelo índice e refina por alguns quadros.
  Future<void> _jumpToMessage(int id) async {
    for (var attempt = 0; attempt < 8; attempt++) {
      if (!mounted || !_scrollController.hasClients) return;
      final ctx = _msgKeys[id]?.currentContext;
      if (ctx != null) {
        await Scrollable.ensureVisible(ctx,
            alignment: 0.4, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
        return;
      }
      final items = _buildItems();
      final index = items.indexWhere((it) => it.message?.id == id);
      if (index < 0) {
        _snack('Essa mensagem não está mais na conversa.');
        return;
      }
      final pos = _scrollController.position;
      final target = (pos.maxScrollExtent * (index / math.max(1, items.length - 1)))
          .clamp(0.0, pos.maxScrollExtent)
          .toDouble();
      _scrollController.jumpTo(target);
      await WidgetsBinding.instance.endOfFrame;
    }
    _snack('Não consegui rolar até a mensagem. Tente de novo.');
  }

  String _copyable(DriqyMessage m) {
    if (m.viewOnce) return '';
    final t = m.type == MessageType.text ? m.content : (m.caption ?? '');
    return t.trim();
  }

  void _scrollToMessage(int id) {
    final ctx = _msgKeys[id]?.currentContext;
    if (ctx == null) {
      _snack('A mensagem original está mais acima — role a conversa para vê-la.');
      return;
    }
    Scrollable.ensureVisible(ctx,
        alignment: 0.3, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  /// Toque longo: reações rápidas + ações (responder, copiar, apagar).
  Future<void> _openReactionSheet(DriqyMessage m) async {
    if (!_canReact(m)) return;
    final mine = m.reactions.where((r) => r.mine).map((r) => r.emoji).toList();
    final result = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => _ReactionSheet(
        quick: _quickReactions,
        selected: mine,
        canCopy: _copyable(m).isNotEmpty,
        canEdit: m.canEdit,
        canPin: _canPin(m),
        canForward: !m.viewOnce,
        isPinned: _pinned?.id == m.id,
      ),
    );
    if (result == null || !mounted) return;
    switch (result) {
      case _ReactionSheet.actReply:
        _startReply(m);
      case _ReactionSheet.actEdit:
        _startEdit(m);
      case _ReactionSheet.actPin:
        await _setPinned(_pinned?.id == m.id ? null : m.id);
      case _ReactionSheet.actForward:
        await _forward(m);
      case _ReactionSheet.actCopy:
        await Clipboard.setData(ClipboardData(text: _copyable(m)));
        _snack('Copiado.');
      case _ReactionSheet.actDelete:
        await _confirmDelete(m);
      default:
        _react(m, result);
    }
  }

  Future<void> _confirmDelete(DriqyMessage m) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(20, 18, 20, 6),
              child: Text('Apagar mensagem?',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.text)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(
                m.canDeleteForAll
                    ? 'Para todos: vira “Mensagem apagada” para você e para a outra pessoa.'
                    : 'Apagar para mim remove só para você — a outra pessoa continua vendo.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
              ),
            ),
            if (m.canDeleteForAll)
              ListTile(
                leading: Icon(Icons.delete_forever, color: AppColors.danger),
                title: Text('Apagar para todos', style: TextStyle(color: AppColors.danger)),
                onTap: () => Navigator.pop(ctx, 'all'),
              ),
            ListTile(
              leading: Icon(Icons.delete_outline,
                  color: m.canDeleteForAll ? AppColors.text : AppColors.danger),
              title: Text('Apagar para mim',
                  style: TextStyle(color: m.canDeleteForAll ? AppColors.text : AppColors.danger)),
              onTap: () => Navigator.pop(ctx, 'me'),
            ),
            ListTile(
              leading: Icon(Icons.close, color: AppColors.textMuted),
              title: Text('Cancelar', style: TextStyle(color: AppColors.textMuted)),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
    if (choice == null || !mounted) return;
    try {
      final updated = await _service.deleteMessage(m.id, forAll: choice == 'all');
      if (!mounted) return;
      setState(() {
        if (updated == null) {
          _messages = _messages.where((x) => x.id != m.id).toList();
        } else {
          _messages = [for (final x in _messages) x.id == m.id ? updated : x];
        }
        if (_replyingTo?.id == m.id) _replyingTo = null;
        if (_editing?.id == m.id) {
          _editing = null;
          _controller.clear();
        }
        _searchIds = _searchIds.where((i) => i != m.id).toList();
      });
      _refresh(); // atualiza citações que apontavam para ela
    } catch (e) {
      _snack(e is ApiException ? e.message : 'Não foi possível apagar.');
    }
  }

  /// Reagir com o mesmo emoji que já é meu remove a reação (toggle).
  Future<void> _react(DriqyMessage m, String emoji) async {
    final already = m.reactions.any((r) => r.mine && r.emoji == emoji);
    void setLocal(List<DriqyReaction> list) {
      setState(() {
        _messages = [
          for (final x in _messages) x.id == m.id ? x.copyWith(reactions: list) : x,
        ];
      });
    }

    // otimista: aparece já; o servidor devolve a lista oficial
    setLocal(applyMyReaction(m.reactions, already ? null : emoji));
    try {
      final server = already
          ? await _service.removeReaction(m.id)
          : await _service.reactToMessage(m.id, emoji);
      if (mounted) setLocal(server);
    } catch (_) {
      if (!mounted) return;
      setLocal(m.reactions); // desfaz
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Não foi possível reagir.')));
    }
  }

  List<_Item> _buildItems() {
    final items = <_Item>[];
    DriqyMessage? prev;
    for (final m in _messages) {
      final newDay = prev == null || !sameDay(prev.createdAt.toLocal(), m.createdAt.toLocal());
      if (newDay) items.add(_Item.day(chatDayLabel(m.createdAt)));
      final grouped = !newDay &&
          prev.mine == m.mine &&
          m.createdAt.difference(prev.createdAt) < _groupGap;
      items.add(_Item.message(m, grouped: grouped));
      prev = m;
    }
    return items;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // voltar fecha a busca / cancela a edição antes de sair da conversa
      onWillPop: () async {
        if (_searching) {
          _closeSearch();
          return false;
        }
        if (_editing != null) {
          _cancelEdit();
          return false;
        }
        return true;
      },
      child: Scaffold(
        appBar: _searching ? _buildSearchBar() : _buildAppBar(),
        // Ping fase 5a: fundo com padrão de doodles (cor + painter do `ping_theme.dart`)
        body: PingBackground(child: _buildBody()),
      ),
    );
  }

  PreferredSizeWidget _buildSearchBar() {
    return AppBar(
      titleSpacing: 0,
      leading: IconButton(
        tooltip: 'Fechar busca',
        icon: const Icon(Icons.arrow_back),
        onPressed: _closeSearch,
      ),
      title: TextField(
        controller: _searchController,
        focusNode: _searchFocus,
        onChanged: _onSearchChanged,
        onSubmitted: (_) {
          _searchDebounce?.cancel();
          if (_searchPos == -1 || _searchController.text.trim() != _searchTerm) {
            _runSearch();
          } else {
            _searchGo(_searchPos + 1);
          }
        },
        maxLength: 100,
        textInputAction: TextInputAction.search,
        decoration: const InputDecoration(
          hintText: 'Buscar na conversa',
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          counterText: '',
          filled: false,
        ),
      ),
      actions: [
        if (_searchStatus.isNotEmpty)
          Center(
            child: Padding(
              padding: const EdgeInsets.only(right: 4),
              child: Text(_searchStatus,
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
            ),
          ),
        IconButton(
          tooltip: 'Mais antiga',
          icon: const Icon(Icons.keyboard_arrow_up),
          onPressed: _searchIds.isEmpty ? null : () => _searchGo(_searchPos + 1),
        ),
        IconButton(
          tooltip: 'Mais nova',
          icon: const Icon(Icons.keyboard_arrow_down),
          onPressed: _searchIds.isEmpty ? null : () => _searchGo(_searchPos - 1),
        ),
      ],
    );
  }

  /// Tela larga (>= 900dp): cabeçalho em pílula flutuante, como no Telegram Web.
  /// No celular continua a barra reta de antes.
  PreferredSizeWidget _buildAppBar() {
    final bar = _buildAppBarCore();
    if (!PingWide.of(context)) return bar;
    final pc = PingColors.of(context);
    return PreferredSize(
      preferredSize: Size.fromHeight(bar.preferredSize.height + 16),
      child: ColoredBox(
        color: pc.bg,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
          child: Material(
            color: pc.panel,
            elevation: 3,
            shadowColor: Colors.black,
            borderRadius: BorderRadius.circular(20),
            clipBehavior: Clip.antiAlias,
            child: bar,
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBarCore() {
    final partner = _partner;
    final name = partner?.displayName ?? '@${widget.username}';
    return AppBar(
      backgroundColor: PingColors.of(context).panel,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleSpacing: 0,
      title: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: AppColors.surface2,
            backgroundImage: partner?.avatarUrl != null
                ? NetworkImage(resolveMediaUrl(partner!.avatarUrl!))
                : null,
            child: partner?.avatarUrl == null
                ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?')
                : null,
          ),
          const SizedBox(width: 10),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                    ),
                    if (partner?.badgeKind != null) ...[
                      const SizedBox(width: 4),
                      Icon(Icons.verified, size: 14, color: AppColors.badgeColor(partner!.badgeKind)),
                    ],
                    if (_prefs.muted) ...[
                      const SizedBox(width: 6),
                      Icon(Icons.notifications_off, size: 14, color: AppColors.textMuted),
                    ],
                  ],
                ),
                Text(
                  _partnerState == 'recording'
                      ? 'gravando áudio…'
                      : _partnerState == 'typing'
                          ? 'digitando…'
                          : presenceLabel(_presence, '@${widget.username}'),
                  style: TextStyle(
                    fontSize: 11,
                    color: _partnerState != null
                        ? AppColors.amber
                        : (_presence.visible && _presence.online
                            ? const Color(0xFF2ECC71)
                            : AppColors.textMuted),
                    fontStyle: _partnerState != null ? FontStyle.italic : FontStyle.normal,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          tooltip: 'Chamada de vídeo',
          icon: const Icon(Icons.videocam),
          onPressed: _loading || _error != null || CallManager.instance.busy
              ? null
              : () => CallManager.instance.startCall(
                    widget.username,
                    name,
                    partner?.avatarUrl,
                    media: CallMedia.video,
                  ),
        ),
        IconButton(
          tooltip: 'Chamada de voz',
          icon: const Icon(Icons.call),
          onPressed: _loading || _error != null || CallManager.instance.busy
              ? null
              : () => CallManager.instance.startCall(
                    widget.username,
                    name,
                    partner?.avatarUrl,
                  ),
        ),
        IconButton(
          tooltip: 'Buscar na conversa',
          icon: const Icon(Icons.search),
          onPressed: _loading || _error != null ? null : _openSearch,
        ),
      ],
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _load, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    final items = _buildItems();
    return Column(
      children: [
        if (_pinned != null)
          _PinnedBar(
            preview: _pinned!.preview,
            onTap: () => _jumpToMessage(_pinned!.id),
            onClose: () => _setPinned(null),
          ),
        Expanded(
          child: Stack(
            children: [
              items.isEmpty
                  ? Center(
                      child: Container(
                        margin: const EdgeInsets.all(32),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: PingColors.of(context).panel,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          'Nenhuma mensagem ainda. Diga oi! 👋',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w600),
                        ),
                      ),
                    )
                  : ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
                      itemCount: items.length,
                      itemBuilder: (context, index) {
                        final item = items[index];
                        if (item.dayLabel != null) {
                          return DateSeparator(label: item.dayLabel!);
                        }
                        final m = item.message!;
                        final bubble = MessageBubble(
                          key: ValueKey(m.clientId ?? 'm${m.id}'),
                          message: m,
                          grouped: item.grouped,
                          onRetry: () => _retry(m),
                          onLongPress: () => _openReactionSheet(m),
                          onReactionTap: (e) => _react(m, e),
                          mediaHeaders: _service.mediaHeaders,
                          replyAuthor: m.replyTo != null ? _replyAuthor(m.replyTo!) : null,
                          onReplyTap: m.replyTo != null ? () => _scrollToMessage(m.replyTo!.id) : null,
                          highlight: _searchTerm.isEmpty ? null : _searchTerm,
                          searchCurrent: _searchCurrentId != null && _searchCurrentId == m.id,
                          onOpenFile: (m.type == MessageType.file && m.localState == null && m.mediaUrl != null)
                              ? () => _openFile(m)
                              : null,
                          fileBusy: _downloadingFiles.contains(m.id),
                          onCallBack: (m.type == MessageType.call && !m.deleted && !CallManager.instance.busy)
                              ? () => CallManager.instance.startCall(
                                    widget.username,
                                    _partner?.displayName ?? widget.username,
                                    _partner?.avatarUrl,
                                    media: (m.mediaMime ?? '').startsWith('call/video')
                                        ? CallMedia.video
                                        : CallMedia.voice,
                                  )
                              : null,
                          onOpenMedia: m.viewOnce
                              ? ((m.canOpenViewOnce && m.localState == null)
                                  ? () => _openViewOnce(m)
                                  : null)
                              : m.type == MessageType.video
                              ? ((m.localState != MessageLocalState.failed &&
                                      (m.localPath != null || m.mediaUrl != null))
                                  ? () => _openVideo(m)
                                  : null)
                              : (m.localState == null && m.mediaUrl != null)
                                  ? () => _openImage(m)
                                  : null,
                        );
                        // deslizar para a direita responde (a mensagem não sai da lista)
                        final swipeable = Dismissible(
                          key: ValueKey('dm-${m.clientId ?? m.id}'),
                          direction:
                              _canReact(m) ? DismissDirection.startToEnd : DismissDirection.none,
                          dismissThresholds: const {DismissDirection.startToEnd: 0.2},
                          confirmDismiss: (_) async {
                            _startReply(m);
                            return false;
                          },
                          background: Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: EdgeInsets.only(left: 16),
                              child: Icon(Icons.reply, color: AppColors.textMuted),
                            ),
                          ),
                          child: bubble,
                        );
                        return m.id > 0
                            ? KeyedSubtree(
                                key: _msgKeys.putIfAbsent(m.id, () => GlobalKey()),
                                child: swipeable,
                              )
                            : swipeable;
                      },
                    ),
              Positioned(
                right: 12,
                bottom: 12,
                child: ValueListenableBuilder<bool>(
                  valueListenable: _showJumpButton,
                  builder: (context, show, _) => show
                      ? ValueListenableBuilder<int>(
                          valueListenable: _jumpCount,
                          builder: (context, count, _) => Badge(
                            isLabelVisible: count > 0,
                            label: Text(count > 99 ? '99+' : '$count'),
                            backgroundColor: AppColors.rose,
                            child: FloatingActionButton.small(
                              heroTag: 'chat-jump',
                              backgroundColor: PingColors.of(context).panel,
                              foregroundColor: AppColors.text,
                              onPressed: () {
                                _jumpCount.value = 0;
                                _scrollToEnd();
                              },
                              child: const Icon(Icons.keyboard_arrow_down),
                            ),
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
              ),
            ],
          ),
        ),
        if (_editing != null)
          _ReplyBar(
            author: 'Editando mensagem',
            preview: _editing!.content,
            accent: AppColors.rose,
            tooltip: 'Cancelar edição',
            onClose: _cancelEdit,
          )
        else if (_replyingTo != null)
          _ReplyBar(
            author: _replyAuthor(DriqyReplyRef.fromMessage(_replyingTo!)),
            preview: _replyingTo!.previewText,
            onClose: () => setState(() => _replyingTo = null),
          ),
        ChatComposer(
          focusNode: _composerFocus,
          controller: _controller,
          onSend: _send,
          onVoiceRecorded: _sendVoice,
          onVoiceMessage: _snack,
          trailing: [
            IconButton(
              tooltip: _voiceOnce
                  ? 'Próximo áudio: visualização única (toque para desligar)'
                  : 'Próximo áudio como visualização única',
              onPressed: () {
                setState(() => _voiceOnce = !_voiceOnce);
                _snack(_voiceOnce
                    ? 'O próximo áudio vai como visualização única.'
                    : 'Visualização única desligada.');
              },
              icon: Icon(Icons.looks_one_outlined,
                  color: _voiceOnce ? AppColors.amber : AppColors.textMuted),
            ),
            IconButton(
              tooltip: 'Enviar imagem ou GIF',
              onPressed: _attach,
              icon: Icon(Icons.attach_file, color: AppColors.textMuted),
            ),
          ],
        ),
      ],
    );
  }
}

/// Folha do toque longo: reações rápidas e, no "+", o painel completo.
class _ReactionSheet extends StatefulWidget {
  /// Valores devolvidos pela folha além dos emojis.
  static const actReply = '::reply';
  static const actCopy = '::copy';
  static const actDelete = '::delete';
  static const actEdit = '::edit';
  static const actForward = '::forward';
  static const actPin = '::pin';

  final List<String> quick;
  final List<String> selected;
  final bool canCopy;
  final bool canEdit;
  final bool canPin;
  final bool canForward;
  final bool isPinned;

  const _ReactionSheet({
    required this.quick,
    required this.selected,
    this.canCopy = false,
    this.canEdit = false,
    this.canPin = false,
    this.canForward = true,
    this.isPinned = false,
  });

  @override
  State<_ReactionSheet> createState() => _ReactionSheetState();
}

class _ReactionSheetState extends State<_ReactionSheet> {
  bool _full = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 14, 12, 14),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                for (final e in widget.quick)
                  GestureDetector(
                    onTap: () => Navigator.pop(context, e),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: widget.selected.contains(e)
                            ? AppColors.amber.withOpacity(0.25)
                            : Colors.transparent,
                      ),
                      child: Text(e, style: const TextStyle(fontSize: 28)),
                    ),
                  ),
                IconButton(
                  tooltip: 'Mais emojis',
                  icon: Icon(_full ? Icons.expand_more : Icons.add_circle_outline,
                      color: AppColors.textMuted),
                  onPressed: () => setState(() => _full = !_full),
                ),
              ],
            ),
          ),
          if (_full) EmojiPanel(onSelected: (e) => Navigator.pop(context, e)),
          if (!_full) ...[
            Divider(height: 1, color: AppColors.border),
            ListTile(
              dense: true,
              leading: Icon(Icons.reply, color: AppColors.text),
              title: Text('Responder', style: TextStyle(color: AppColors.text)),
              onTap: () => Navigator.pop(context, _ReactionSheet.actReply),
            ),
            if (widget.canCopy)
              ListTile(
                dense: true,
                leading: Icon(Icons.copy, color: AppColors.text),
                title: Text('Copiar', style: TextStyle(color: AppColors.text)),
                onTap: () => Navigator.pop(context, _ReactionSheet.actCopy),
              ),
            if (widget.canEdit)
              ListTile(
                dense: true,
                leading: Icon(Icons.edit_outlined, color: AppColors.text),
                title: Text('Editar', style: TextStyle(color: AppColors.text)),
                onTap: () => Navigator.pop(context, _ReactionSheet.actEdit),
              ),
            if (widget.canPin)
              ListTile(
                dense: true,
                leading: Icon(widget.isPinned ? Icons.push_pin : Icons.push_pin_outlined,
                    color: AppColors.text),
                title: Text(widget.isPinned ? 'Desafixar' : 'Fixar',
                    style: TextStyle(color: AppColors.text)),
                onTap: () => Navigator.pop(context, _ReactionSheet.actPin),
              ),
            if (widget.canForward)
            ListTile(
              dense: true,
              leading: Icon(Icons.forward, color: AppColors.text),
              title: Text('Encaminhar', style: TextStyle(color: AppColors.text)),
              onTap: () => Navigator.pop(context, _ReactionSheet.actForward),
            ),
            ListTile(
              dense: true,
              leading: Icon(Icons.delete_outline, color: AppColors.danger),
              title: Text('Apagar', style: TextStyle(color: AppColors.danger)),
              onTap: () => Navigator.pop(context, _ReactionSheet.actDelete),
            ),
          ],
        ],
      ),
    );
  }
}

/// Faixa da mensagem fixada, logo abaixo do cabeçalho (Ping fase 6b).
class _PinnedBar extends StatelessWidget {
  final String preview;
  final VoidCallback onTap;
  final VoidCallback onClose;

  const _PinnedBar({required this.preview, required this.onTap, required this.onClose});

  @override
  Widget build(BuildContext context) {
    final ping = PingColors.of(context);
    return Material(
      color: ping.panel,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 4, 6),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 34,
                decoration: BoxDecoration(
                  gradient: PingColors.gradient,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Mensagem fixada',
                      style: TextStyle(
                          color: AppColors.amber, fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                    Text(
                      preview,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.text, fontSize: 14),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Desafixar',
                icon: Icon(Icons.close, size: 20, color: AppColors.textMuted),
                onPressed: onClose,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Faixa "Respondendo a…" acima do campo de texto.
class _ReplyBar extends StatelessWidget {
  final String author;
  final String preview;
  final VoidCallback onClose;
  final Color? accent;
  final String tooltip;

  _ReplyBar({
    required this.author,
    required this.preview,
    required this.onClose,
    this.accent,
    this.tooltip = 'Cancelar resposta',
  });

  @override
  Widget build(BuildContext context) {
    final accent = this.accent ?? AppColors.amber;
    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.fromLTRB(12, 8, 4, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 6, 2, 6),
        decoration: BoxDecoration(
          color: AppColors.surface2,
          borderRadius: const BorderRadius.all(Radius.circular(10)),
          border: Border(left: BorderSide(color: accent, width: 3)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(author,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: accent, fontSize: 12, fontWeight: FontWeight.w700)),
                  Text(preview,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                ],
              ),
            ),
            IconButton(
              tooltip: tooltip,
              icon: Icon(Icons.close, size: 20, color: AppColors.textMuted),
              onPressed: onClose,
            ),
          ],
        ),
      ),
    );
  }
}
