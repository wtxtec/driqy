import 'package:flutter/material.dart';

import '../config.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../services/api_exception.dart';
import '../services/message_service.dart';
import '../theme/app_colors.dart';
import '../widgets/chat/chat_format.dart';

/// Fase 8 — escolher para quais conversas encaminhar uma mensagem (até 5).
/// Faz o pedido ao servidor e fecha devolvendo os `@usernames` encaminhados
/// (ou `null` se o usuário voltou sem enviar). Só lista conversas que já
/// existem (a busca de pessoas novas fica para uma fase futura).
class ChatForwardScreen extends StatefulWidget {
  final MessageService service;
  final DriqyMessage message;

  const ChatForwardScreen({super.key, required this.service, required this.message});

  @override
  State<ChatForwardScreen> createState() => _ChatForwardScreenState();
}

class _ChatForwardScreenState extends State<ChatForwardScreen> {
  static const maxTargets = 5;

  final _filter = TextEditingController();
  final _selected = <String>[]; // ordem de escolha
  List<DriqyConversation>? _all;
  String? _error;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _filter.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final inbox = await widget.service.getInbox(all: true);
      if (mounted) setState(() => _all = inbox);
    } catch (_) {
      if (mounted) setState(() => _error = 'Não foi possível carregar as conversas.');
    }
  }

  List<DriqyConversation> get _visible {
    final q = foldSearch(_filter.text.trim());
    final all = _all ?? const <DriqyConversation>[];
    if (q.isEmpty) return all;
    return all
        .where((c) =>
            foldSearch(c.partner.displayName).contains(q) ||
            foldSearch(c.partner.username).contains(q))
        .toList();
  }

  void _toggle(String username) {
    setState(() {
      if (_selected.contains(username)) {
        _selected.remove(username);
      } else if (_selected.length < maxTargets) {
        _selected.add(username);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Limite de $maxTargets conversas por vez.')),
        );
      }
    });
  }

  Future<void> _send() async {
    if (_selected.isEmpty || _sending) return;
    setState(() => _sending = true);
    final names = List<String>.of(_selected);
    try {
      await widget.service.forwardMessage(
        widget.message.id,
        names,
        clientId: DriqyMessage.newClientId(),
      );
      if (mounted) Navigator.pop(context, names);
    } catch (e) {
      if (!mounted) return;
      setState(() => _sending = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(e is ApiException ? e.message : 'Não foi possível encaminhar.'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final rows = _visible;
    return Scaffold(
      appBar: AppBar(title: const Text('Encaminhar para…')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: TextField(
              controller: _filter,
              onChanged: (_) => setState(() {}),
              textInputAction: TextInputAction.search,
              decoration: const InputDecoration(
                hintText: 'Buscar conversa',
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
            ),
          ),
          Expanded(child: _buildList(rows)),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: (_selected.isEmpty || _sending) ? null : _send,
                  child: _sending
                      ? const SizedBox(
                          width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(_selected.length > 1
                          ? 'Encaminhar (${_selected.length})'
                          : 'Encaminhar'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList(List<DriqyConversation> rows) {
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _load, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    if (_all == null) return const Center(child: CircularProgressIndicator());
    if (rows.isEmpty) {
      return Center(
        child: Text('Nenhuma conversa encontrada.', style: TextStyle(color: AppColors.textMuted)),
      );
    }
    return ListView.builder(
      itemCount: rows.length,
      itemBuilder: (context, i) {
        final u = rows[i].partner;
        final on = _selected.contains(u.username);
        return ListTile(
          onTap: () => _toggle(u.username),
          leading: CircleAvatar(
            backgroundColor: AppColors.surface2,
            backgroundImage:
                u.avatarUrl != null ? NetworkImage(resolveMediaUrl(u.avatarUrl!)) : null,
            child: u.avatarUrl == null
                ? Text(u.displayName.isNotEmpty ? u.displayName[0].toUpperCase() : '?')
                : null,
          ),
          title: Text(u.displayName, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('@${u.username}',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
          trailing: Icon(
            on ? Icons.check_circle : Icons.radio_button_unchecked,
            color: on ? AppColors.amber : AppColors.textMuted,
          ),
        );
      },
    );
  }
}
