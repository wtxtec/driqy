import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';
import '../models/chat_group.dart';
import '../models/conversation.dart';
import '../models/user.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/chat_live.dart';
import '../services/group_service.dart';
import '../services/message_service.dart';
import '../services/messages_prefs.dart';
import '../services/search_service.dart';
import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';
import '../widgets/chat/chat_format.dart';
import '../widgets/chat/message_ticks.dart';
import '../widgets/group_avatar.dart';
import '../widgets/ping_app_bar.dart';
import '../widgets/ping_tab_bar.dart';
import '../widgets/ping_wide.dart';
import 'group_thread_screen.dart';
import 'message_thread_screen.dart';
import 'new_group_screen.dart';
import 'messages_settings_screen.dart';
import 'ping_contacts_screen.dart';
import 'ping_nav.dart';

/// Caixa de entrada: lista de conversas, ordenada pela mensagem mais
/// recente em cada uma — igual à página /mensagens do site.
class MessagesInboxScreen extends StatefulWidget {
  final VoidCallback? onOpenMenu;

  /// Fase 10: mostra só as conversas arquivadas (tela aberta pela linha "Arquivadas").
  final bool archivedView;

  const MessagesInboxScreen({super.key, this.onOpenMenu, this.archivedView = false});

  @override
  State<MessagesInboxScreen> createState() => _MessagesInboxScreenState();
}

class _MessagesInboxScreenState extends State<MessagesInboxScreen> {
  late MessageService _service;
  late GroupService _groupService;
  List<DriqyGroup> _groups = []; // Mensagens parte 4
  int? _activeGroupId; // grupo aberto no painel direito (tela larga)
  List<DriqyConversation> _conversations = [];
  int _archivedCount = 0;
  bool _showPresence = true; // privacidade: mostrar online / visto por último
  bool _loading = true;
  String? _error;

  // Fase 9: master-detail em tela larga (>= 900dp): painel direito = Navigator próprio.
  final GlobalKey<NavigatorState> _detailKey = GlobalKey<NavigatorState>();
  late final PingDetailObserver _detailObserver = PingDetailObserver((u) {
    if (mounted && u != _activeUsername) setState(() {
      _activeUsername = u;
      if (u != null) _activeGroupId = null;
    });
  });
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _wide = false;
  String? _activeUsername; // conversa aberta no painel direito (marca a linha)
  StreamSubscription<ChatEvent>? _liveSub;
  Timer? _liveDebounce;

  // Fase 4a: busca (só filtra conversas, no cliente) e aviso dispensável.
  static const _noticePrefKey = 'ping_notice_v1';
  final TextEditingController _search = TextEditingController();
  bool _noticeDismissed = true; // true até ler a preferência (evita piscar)

  @override
  void initState() {
    super.initState();
    _loadNoticePref();
    MessagesPrefs.instance.load();
    PingMenuSignal.listenable.addListener(_onMenuSignal);
    final client = context.read<AuthService>().client;
    _service = MessageService(client);
    _groupService = GroupService(client);
    ChatLive.instance.acquire(client);
    // qualquer coisa nova (mensagem, leitura, entrega, edição…) atualiza a lista na hora
    _liveSub = ChatLive.instance.events.listen((e) {
      if (e.type == 'typing') return;
      _liveDebounce?.cancel();
      _liveDebounce = Timer(const Duration(milliseconds: 200), () {
        if (mounted) _load(silent: true);
      });
    });
    _load();
    if (!widget.archivedView) _loadPrivacy();
  }

  /// A aba "Menu" de Contatos volta para a lista e pede o menu lateral aberto.
  void _onMenuSignal() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !widget.archivedView) _scaffoldKey.currentState?.openDrawer();
    });
  }

  Future<void> _loadNoticePref() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (mounted) setState(() => _noticeDismissed = prefs.getBool(_noticePrefKey) ?? false);
    } catch (_) {
      // sem preferências: mantém o aviso escondido
    }
  }

  Future<void> _dismissNotice() async {
    setState(() => _noticeDismissed = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_noticePrefKey, true);
    } catch (_) {}
  }

  String get _query => _search.text.trim().toLowerCase();

  List<DriqyConversation> get _visible {
    final q = _query;
    if (q.isEmpty) return _conversations;
    return _conversations.where((c) {
      final last = c.lastMessage;
      final hay = '${c.partner.displayName} ${c.partner.username} ${last?.previewText ?? ''}'.toLowerCase();
      return hay.contains(q);
    }).toList();
  }

  List<DriqyGroup> get _visibleGroups {
    final q = _query;
    if (q.isEmpty) return _groups;
    return _groups.where((g) => '${g.name} ${g.lastPreview}'.toLowerCase().contains(q)).toList();
  }

  /// ☰ ao lado da busca (celular e desktop): abre o menu lateral, estilo Telegram.
  Widget _menuButton() {
    return IconButton(
      icon: const Icon(Icons.menu),
      tooltip: 'Menu',
      onPressed: () => _scaffoldKey.currentState?.openDrawer(),
    );
  }

  Widget _searchBar() {
    final c = PingColors.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(widget.archivedView && !_wide ? 16 : 8, 8, 12, 8),
      child: Row(
        children: [
          if (!widget.archivedView)
            _menuButton()
          else if (_wide)
            const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Buscar conversas',
                isDense: true,
                filled: true,
                fillColor: c.searchBg,
                prefixIcon: const Icon(Icons.search, size: 20),
                prefixIconConstraints: const BoxConstraints(minWidth: 44, minHeight: 36),
                suffixIcon: _search.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close, size: 18),
                        tooltip: 'Limpar',
                        onPressed: () => setState(_search.clear),
                      ),
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(28),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _notice() {
    final c = PingColors.of(context);
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      padding: const EdgeInsets.fromLTRB(14, 8, 4, 8),
      decoration: BoxDecoration(color: c.searchBg, borderRadius: BorderRadius.circular(16)),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Organize suas conversas 📌', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                SizedBox(height: 2),
                Text(
                  'Segure uma conversa para fixar, silenciar ou arquivar.',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, size: 18),
            tooltip: 'Dispensar aviso',
            onPressed: _dismissNotice,
          ),
        ],
      ),
    );
  }

  Future<void> _loadPrivacy() async {
    try {
      final v = await _service.getShowPresence();
      if (mounted) setState(() => _showPresence = v);
    } catch (_) {
      // servidor antigo/sem rede: mantém o padrão (visível)
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    PingMenuSignal.listenable.removeListener(_onMenuSignal);
    _liveSub?.cancel();
    _liveDebounce?.cancel();
    _search.dispose();
    ChatLive.instance.release();
    super.dispose();
  }

  int _unreadAudible(List<DriqyConversation> list, [List<DriqyGroup> groups = const []]) =>
      list.where((c) => !c.prefs.muted && !c.prefs.archived).fold<int>(0, (sum, c) => sum + c.unread) +
      groups.where((g) => !g.prefs.muted && !g.prefs.archived).fold<int>(0, (sum, g) => sum + g.unread);

  int get _totalUnread =>
      _conversations.fold<int>(0, (sum, c) => sum + c.unread) + _groups.fold<int>(0, (sum, g) => sum + g.unread);

  Future<void> _load({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final page = await _service.getInboxPage(archived: widget.archivedView);
      // grupos: falha aqui (servidor antigo/sem rede) não derruba a lista de conversas
      GroupInbox? gp;
      try {
        gp = await _groupService.list(archived: widget.archivedView);
      } catch (_) {}
      if (mounted) {
        // som de mensagem nova: o total de não lidas (sem as silenciadas) subiu numa atualização ao vivo
        final before = _unreadAudible(_conversations, _groups);
        final hadList = _conversations.isNotEmpty || _groups.isNotEmpty;
        setState(() {
          _conversations = page.conversations;
          _archivedCount = page.archivedCount + (gp?.archivedCount ?? 0);
          if (gp != null) _groups = gp.groups;
        });
        if (silent && hadList && !widget.archivedView && _unreadAudible(page.conversations, _groups) > before) {
          MessagesPrefs.instance.playIncoming();
        }
      }
    } catch (_) {
      if (mounted && !silent) setState(() => _error = 'Não foi possível carregar as conversas.');
    } finally {
      if (mounted && !silent) setState(() => _loading = false);
    }
  }

  /// Fase 9: em tela larga, abre [page] no painel direito (troca o que estava aberto);
  /// no celular devolve false e o chamador faz o push normal.
  bool _showDetail(Widget page, {String? username}) {
    final nav = _wide ? _detailKey.currentState : null;
    if (nav == null) return false;
    nav.pushAndRemoveUntil(
      pingFadeRoute<void>(page, name: username == null ? null : kPingThreadRoute, args: username),
      (r) => r.isFirst,
    );
    return true;
  }

  Future<void> _openThread(DriqyConversation conv) async {
    if (_showDetail(MessageThreadScreen(key: ValueKey('t:${conv.partner.username}'), username: conv.partner.username),
        username: conv.partner.username)) {
      return; // a lista se atualiza pelos eventos ao vivo
    }
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => MessageThreadScreen(username: conv.partner.username)),
    );
    // ao voltar do chat, as mensagens podem ter sido marcadas como lidas
    _load();
  }

  Future<void> _openGroup(DriqyGroup g) async {
    if (_showDetail(GroupThreadScreen(key: ValueKey('g:${g.id}'), groupId: g.id, initial: g))) {
      setState(() => _activeGroupId = g.id);
      return;
    }
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupThreadScreen(groupId: g.id, initial: g)));
    _load(silent: true);
  }

  /// "Novo grupo" (item do menu lateral; substitui a caneta): nome + pessoas → abre o grupo criado.
  Future<void> _newGroup() async {
    final g = await Navigator.of(context).push<DriqyGroup>(MaterialPageRoute(builder: (_) => const NewGroupScreen()));
    if (g == null || !mounted) return;
    await _load(silent: true);
    if (mounted) _openGroup(g);
  }

  /// Fixar / silenciar / arquivar um grupo (toque longo).
  Future<void> _showGroupActions(DriqyGroup g) async {
    final p = g.prefs;
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (!p.archived)
            ListTile(leading: Icon(p.pinned ? Icons.push_pin_outlined : Icons.push_pin), title: Text(p.pinned ? 'Desafixar' : 'Fixar no topo'), onTap: () => Navigator.pop(ctx, 'pin')),
          ListTile(leading: Icon(p.muted ? Icons.notifications_active : Icons.notifications_off), title: Text(p.muted ? 'Reativar notificações' : 'Silenciar'), onTap: () => Navigator.pop(ctx, 'mute')),
          ListTile(leading: Icon(p.archived ? Icons.unarchive : Icons.archive), title: Text(p.archived ? 'Desarquivar' : 'Arquivar'), onTap: () => Navigator.pop(ctx, 'archive')),
        ]),
      ),
    );
    if (action == null || !mounted) return;
    try {
      await _groupService.setPrefs(g.id,
          pinned: action == 'pin' ? !p.pinned : null, muted: action == 'mute' ? !p.muted : null, archived: action == 'archive' ? !p.archived : null);
      await _load(silent: true);
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Não foi possível salvar. Tente de novo.');
    }
  }

  Widget _buildGroupRow(DriqyGroup g) {
    final pc = PingColors.of(context);
    final unread = g.unread > 0;
    return ListTile(
      onTap: () => _openGroup(g),
      onLongPress: () => _showGroupActions(g),
      tileColor: _wide && _activeGroupId == g.id
          ? Color.alphaBlend(AppColors.amber.withOpacity(0.18), pc.bg)
          : (g.prefs.pinned ? pc.panelHover : null),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14),
      visualDensity: const VisualDensity(vertical: -2),
      horizontalTitleGap: 14,
      leading: GroupAvatar(name: g.name, url: g.avatarUrl),
      title: Text(g.name, style: const TextStyle(fontWeight: FontWeight.w500), overflow: TextOverflow.ellipsis),
      subtitle: Text(
        g.lastPreview.isNotEmpty ? g.lastPreview : '${g.memberCount} pessoas',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(color: unread ? AppColors.text : AppColors.textMuted),
      ),
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(g.lastActivity != null ? chatListTime(g.lastActivity!) : '', style: TextStyle(color: unread ? AppColors.amber : AppColors.textMuted, fontSize: 11)),
        if (unread || g.prefs.pinned || g.prefs.muted) ...[
          const SizedBox(height: 4),
          Row(mainAxisSize: MainAxisSize.min, children: [
            if (g.prefs.muted) Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.notifications_off, size: 13, color: AppColors.textMuted)),
            if (g.prefs.pinned) Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.push_pin, size: 13, color: AppColors.textMuted)),
            if (unread)
              Container(
                constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                padding: const EdgeInsets.symmetric(horizontal: 6),
                decoration: g.prefs.muted
                    ? BoxDecoration(color: pc.badgeMuted, borderRadius: BorderRadius.circular(10))
                    : BoxDecoration(gradient: AppGradients.brand, borderRadius: BorderRadius.circular(10)),
                child: Center(child: Text('${g.unread}', style: TextStyle(fontSize: 10, color: AppColors.onBrand, fontWeight: FontWeight.bold))),
              ),
          ]),
        ],
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Fase 9: arquivadas é sempre tela cheia; a lista normal vira master-detail em >= 900dp.
    if (widget.archivedView) return _buildList(context);
    return LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= kPingWideBreakpoint;
      _wide = wide;
      final list = _buildList(context);
      if (!wide) return list;
      final listWidth = (constraints.maxWidth * 0.36).clamp(320.0, 400.0);
      return PingWide(
        child: WillPopScope(
          // voltar fecha primeiro o que está aberto no painel direito (conversa/contatos/…)
          onWillPop: () async {
            final nav = _detailKey.currentState;
            if (nav != null && await nav.maybePop()) return false;
            return true;
          },
          child: Row(
            children: [
              SizedBox(width: listWidth, child: list),
              VerticalDivider(width: 1, thickness: 1, color: PingColors.of(context).panel),
              Expanded(
                child: ClipRect(
                  child: Navigator(
                    key: _detailKey,
                    observers: [_detailObserver],
                    onGenerateRoute: (_) => pingFadeRoute<void>(const PingEmptyDetail()),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  Widget _buildList(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      // Mensagens é à parte do Driqy (tipo Messenger): sem logo/busca/menu do Driqy,
      // só voltar + "Mensagens" (igual ao `ping_base.html` do site).
      appBar: widget.archivedView
          ? AppBar(title: const Text('Conversas arquivadas')) as PreferredSizeWidget
          : const PingAppBar(),
      drawer: widget.archivedView ? null : _buildDrawer(),
      // Pílula flutuante de Mensagens (Chats, Contatos, Chamadas, Menu); some na visão "arquivadas".
      bottomNavigationBar: widget.archivedView
          ? null
          : PingTabBar(
              unread: _totalUnread,
              onContacts: () => _openTab(PingTab.contacts),
              onCalls: () => _openTab(PingTab.calls),
              onMenu: () => _scaffoldKey.currentState?.openDrawer(),
            ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _searchBar(),
          if (!widget.archivedView && !_noticeDismissed) _notice(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  /// Contatos / Chamadas são telas de Mensagens (a lista fica embaixo na pilha).
  void _openTab(PingTab to) {
    final unread = _totalUnread;
    if (to == PingTab.contacts && _showDetail(PingContactsScreen(unread: unread))) return; // tela larga: painel direito
    PingNav.go(context, from: PingTab.chats, to: to, unread: unread);
  }

  /// "Nova conversa" (item do menu lateral; a caneta foi removida) → escolhe uma pessoa e abre a conversa.
  Future<void> _newConversation() async {
    final client = context.read<AuthService>().client;
    final picked = await showModalBottomSheet<DriqyUser>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _NewPingSheet(service: SearchService(client)),
    );
    if (picked == null || !mounted) return;
    if (_showDetail(MessageThreadScreen(key: ValueKey('t:${picked.username}'), username: picked.username),
        username: picked.username)) {
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => MessageThreadScreen(username: picked.username)),
    );
    _load(silent: true);
  }

  /// Menu lateral (estilo Telegram): perfil no topo e atalhos; "Configurações" abre `MessagesSettingsScreen`.
  /// Substitui a tela de Configurações antiga (que abria ao tocar na foto) e a caneta (FAB).
  Widget _buildDrawer() {
    final me = context.read<AuthService>().currentUser;
    final c = PingColors.of(context);
    final name = me?.displayName ?? '';

    void close() => _scaffoldKey.currentState?.closeDrawer();
    Widget item(IconData icon, String label, VoidCallback onTap) => ListTile(
          leading: Icon(icon, color: AppColors.textMuted),
          title: Text(label),
          onTap: () {
            close();
            onTap();
          },
        );

    return Drawer(
      backgroundColor: c.panel,
      child: SafeArea(
        top: false,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.fromLTRB(18, MediaQuery.of(context).padding.top + 20, 18, 14),
              decoration: BoxDecoration(gradient: AppGradients.brand),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 32,
                    backgroundColor: Colors.white24,
                    foregroundColor: c.onAccent,
                    backgroundImage: me?.avatarUrl != null ? NetworkImage(resolveMediaUrl(me!.avatarUrl!)) : null,
                    child: me?.avatarUrl == null
                        ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700))
                        : null,
                  ),
                  const SizedBox(height: 10),
                  Text(name, style: TextStyle(color: c.onAccent, fontSize: 17, fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis),
                  if (me != null) Text('@${me.username}', style: TextStyle(color: c.onAccent.withOpacity(0.85), fontSize: 13)),
                ],
              ),
            ),
            item(Icons.mark_chat_unread_outlined, 'Nova conversa', _newConversation),
            item(Icons.group_add_outlined, 'Novo grupo', _newGroup),
            item(Icons.person_outline, 'Contatos', () => _openTab(PingTab.contacts)),
            item(Icons.call_outlined, 'Chamadas', () => _openTab(PingTab.calls)),
            if (_archivedCount > 0)
              item(Icons.archive_outlined, 'Arquivadas ($_archivedCount)', _openArchived),
            item(Icons.settings_outlined, 'Configurações', _openSettings),
            const Divider(height: 16),
            item(Icons.arrow_back, 'Voltar para o Driqy', () => Navigator.of(context).maybePop()),
          ],
        ),
      ),
    );
  }

  /// Configurações de Mensagens (estilo Telegram): notificações e sons, privacidade.
  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => MessagesSettingsScreen(
          showPresence: _showPresence,
          onPresenceChanged: (v) async {
            final saved = await _service.setShowPresence(v);
            if (mounted) {
              setState(() => _showPresence = saved);
              _load(silent: true);
            }
            return saved;
          },
        ),
      ),
    );
  }

  Future<void> _openArchived() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const MessagesInboxScreen(archivedView: true)),
    );
    _load(silent: true);
  }

  /// Fixar / silenciar / arquivar (toque longo na conversa).
  Future<void> _showActions(DriqyConversation conv) async {
    final prefs = conv.prefs;
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!prefs.archived)
              ListTile(
                leading: Icon(prefs.pinned ? Icons.push_pin_outlined : Icons.push_pin),
                title: Text(prefs.pinned ? 'Desafixar' : 'Fixar no topo'),
                onTap: () => Navigator.pop(ctx, 'pin'),
              ),
            ListTile(
              leading: Icon(prefs.muted ? Icons.notifications_active : Icons.notifications_off),
              title: Text(prefs.muted ? 'Reativar notificações' : 'Silenciar'),
              onTap: () => Navigator.pop(ctx, 'mute'),
            ),
            ListTile(
              leading: Icon(prefs.archived ? Icons.unarchive : Icons.archive),
              title: Text(prefs.archived ? 'Desarquivar' : 'Arquivar'),
              onTap: () => Navigator.pop(ctx, 'archive'),
            ),
          ],
        ),
      ),
    );
    if (action == null || !mounted) return;
    try {
      final u = conv.partner.username;
      switch (action) {
        case 'pin':
          await _service.setConversationPrefs(u, pinned: !prefs.pinned);
          break;
        case 'mute':
          await _service.setConversationPrefs(u, muted: !prefs.muted);
          break;
        case 'archive':
          await _service.setConversationPrefs(u, archived: !prefs.archived);
          break;
      }
      await _load(silent: true);
    } on ApiException catch (e) {
      _snack(e.message); // ex.: "Você pode fixar até 3 conversas."
    } catch (_) {
      _snack('Não foi possível salvar. Tente de novo.');
    }
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _load, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    final items = _visible;
    final groups = _visibleGroups;
    if (_query.isNotEmpty && items.isEmpty && groups.isEmpty) {
      return Center(
        child: Text('Nenhuma conversa encontrada.', style: TextStyle(color: AppColors.textMuted)),
      );
    }
    final showArchivedRow = !widget.archivedView && _archivedCount > 0 && _query.isEmpty;
    if (_conversations.isEmpty && _groups.isEmpty && !showArchivedRow) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            widget.archivedView
                ? 'Nada arquivado. Segure uma conversa para arquivá-la.'
                : 'Nenhuma conversa ainda. Abra o perfil de alguém e mande uma mensagem.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    final extra = showArchivedRow ? 1 : 0;
    final gHead = groups.isEmpty ? 0 : groups.length + 1; // título "Grupos" + linhas
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: items.length + extra + gHead,
        separatorBuilder: (_, __) => const SizedBox(height: 2),
        itemBuilder: (context, index) {
          if (showArchivedRow && index == 0) {
            return ListTile(
              onTap: _openArchived,
              leading: Icon(Icons.archive_outlined, color: AppColors.amber),
              title: const Text('Arquivadas'),
              trailing: Text('$_archivedCount', style: TextStyle(color: AppColors.textMuted)),
            );
          }
          final k = index - extra;
          if (k < gHead) {
            if (k == 0) {
              return Padding(
                padding: EdgeInsets.fromLTRB(16, 8, 16, 2),
                child: Text('GRUPOS', style: TextStyle(fontSize: 12, letterSpacing: 0.8, color: AppColors.textMuted, fontWeight: FontWeight.w600)),
              );
            }
            return _buildGroupRow(groups[k - 1]);
          }
          return _buildRow(items[k - gHead]);
        },
      ),
    );
  }

  Widget _buildRow(DriqyConversation conv) {
    final partner = conv.partner;
    final last = conv.lastMessage;
    final unread = conv.unread > 0;

    String preview = 'Sem mensagens ainda.';
    String timeLabel = '';
    if (last != null) {
      preview = last.previewText;
      timeLabel = chatListTime(last.createdAt);
    }

    final online = conv.presence.visible && conv.presence.online;
    final pc = PingColors.of(context);
    return ListTile(
      onTap: () => _openThread(conv),
      onLongPress: () => _showActions(conv),
      tileColor: _wide && _activeUsername == partner.username
          ? Color.alphaBlend(AppColors.amber.withOpacity(0.18), pc.bg)
          : (conv.prefs.pinned ? pc.panelHover : null),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14),
      visualDensity: const VisualDensity(vertical: -2), // ~72dp por linha, como o Telegram
      horizontalTitleGap: 14,
      leading: Stack(
        clipBehavior: Clip.none,
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: AppColors.surface2,
            backgroundImage:
                partner.avatarUrl != null ? NetworkImage(resolveMediaUrl(partner.avatarUrl!)) : null,
            child: partner.avatarUrl == null ? Text(partner.displayName[0].toUpperCase()) : null,
          ),
          if (online)
            Positioned(
              right: -1,
              bottom: -1,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: const Color(0xFF2ECC71),
                  shape: BoxShape.circle,
                  border: Border.all(color: Theme.of(context).scaffoldBackgroundColor, width: 2),
                ),
              ),
            ),
        ],
      ),
      title: Row(
        children: [
          Flexible(
            child: Text(
              partner.displayName,
              style: const TextStyle(fontWeight: FontWeight.w500),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (partner.badgeKind != null) ...[
            const SizedBox(width: 4),
            Icon(Icons.verified, size: 14, color: AppColors.badgeColor(partner.badgeKind)),
          ],
        ],
      ),
      subtitle: Row(
        children: [
          // ticks só nas MINHAS mensagens (igual WhatsApp)
          if (last != null && last.mine) ...[
            MessageTicks(
              message: last,
              baseColor: AppColors.textMuted,
              readColor: const Color(0xFF5EC8E0),
              size: 15,
            ),
            const SizedBox(width: 4),
          ],
          Expanded(
            child: Text(
              preview,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: _isMediaPreview(last)
                    ? AppColors.amber
                    : (unread ? AppColors.text : AppColors.textMuted),
              ),
            ),
          ),
        ],
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            timeLabel,
            style: TextStyle(
              color: unread ? AppColors.amber : AppColors.textMuted,
              fontSize: 11,
            ),
          ),
          if (unread || conv.prefs.pinned || conv.prefs.muted) ...[
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (conv.prefs.muted)
                  Padding(
                    padding: EdgeInsets.only(right: 4),
                    child: Icon(Icons.notifications_off, size: 13, color: AppColors.textMuted),
                  ),
                if (conv.prefs.pinned)
                  Padding(
                    padding: EdgeInsets.only(right: 4),
                    child: Icon(Icons.push_pin, size: 13, color: AppColors.textMuted),
                  ),
                if (unread) _unreadBadge(conv),
              ],
            ),
          ],
        ],
      ),
    );
  }

  /// Prévia de foto/vídeo/áudio/arquivo sai em destaque (como no Telegram); chamada e texto não.
  bool _isMediaPreview(dynamic last) {
    if (last == null) return false;
    return const {'image', 'video', 'audio', 'file'}.contains(last.msgType);
  }

  Widget _unreadBadge(DriqyConversation conv) {
    return Container(
      constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
      padding: const EdgeInsets.symmetric(horizontal: 6),
      decoration: conv.prefs.muted
          ? BoxDecoration(color: PingColors.of(context).badgeMuted, borderRadius: BorderRadius.circular(10))
          : BoxDecoration(gradient: AppGradients.brand, borderRadius: BorderRadius.circular(10)),
      child: Center(
        child: Text(
          '${conv.unread}',
          style: TextStyle(fontSize: 10, color: AppColors.onBrand, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

/// Painel "Nova conversa": busca pessoas e devolve a escolhida.
class _NewPingSheet extends StatefulWidget {
  final SearchService service;
  const _NewPingSheet({required this.service});

  @override
  State<_NewPingSheet> createState() => _NewPingSheetState();
}

class _NewPingSheetState extends State<_NewPingSheet> {
  final _q = TextEditingController();
  Timer? _debounce;
  int _seq = 0;
  List<DriqyUser> _users = [];
  bool _searched = false;

  @override
  void dispose() {
    _debounce?.cancel();
    _q.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    _debounce?.cancel();
    if (v.trim().isEmpty) {
      setState(() {
        _users = [];
        _searched = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 250), () async {
      final mine = ++_seq;
      try {
        final r = await widget.service.searchUsers(v);
        if (mounted && mine == _seq) setState(() {
          _users = r;
          _searched = true;
        });
      } catch (_) {
        if (mounted && mine == _seq) setState(() => _searched = true);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = PingColors.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.6,
        child: Column(
          children: [
            TextField(
              controller: _q,
              autofocus: true,
              onChanged: _onChanged,
              decoration: InputDecoration(
                hintText: 'Buscar pessoa',
                isDense: true,
                filled: true,
                fillColor: c.searchBg,
                prefixIcon: const Icon(Icons.search, size: 20),
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _users.isEmpty
                  ? Center(
                      child: Text(
                        _searched ? 'Ninguém encontrado.' : 'Digite um nome ou @usuário.',
                        style: TextStyle(color: AppColors.textMuted),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _users.length,
                      itemBuilder: (_, i) {
                        final u = _users[i];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: AppColors.surface2,
                            backgroundImage: u.avatarUrl != null ? NetworkImage(resolveMediaUrl(u.avatarUrl!)) : null,
                            child: u.avatarUrl == null ? Text(u.displayName[0].toUpperCase()) : null,
                          ),
                          title: Text(u.displayName),
                          subtitle: Text('@${u.username}'),
                          onTap: () => Navigator.pop(context, u),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
