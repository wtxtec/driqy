import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

import '../config.dart';
import '../models/picture_tile.dart';
import '../services/auth_service.dart';
import '../services/pictures_service.dart';
import '../theme/vortex_theme.dart';
import '../widgets/driqy_image.dart';
import '../widgets/vortex_tile_actions.dart';
import '../widgets/vortex_tile_card.dart';
import 'vortex_search_screen.dart';

/// Detalhe de um item do Vortex vindo do crawler: mídia grande, título,
/// perfil-robô, crédito/licença, link da fonte, tags (cada uma abre uma
/// busca) e a grade "Mais como este" com rolagem infinita. Tocar numa
/// sugestão abre outro detalhe por cima (pilha estilo Pinterest).
///
/// Abrir esta tela já conta como clique no servidor (`GET /vortex/item/<id>`).
/// Ficar [_dwellMinSeconds] ou mais olhando manda um sinal `dwell`; os botões
/// o coração de curtir (dentro da imagem) e o "menos disso" mandam `like` e `less`.
///
/// Segue o tema (claro/escuro) do Vortex: o corpo fica num [VortexThemeScope].
/// Nas sugestões, segurar uma peça abre Curtir / Menos disso.
class VortexDetailScreen extends StatelessWidget {
  final int itemId;
  /// Peça da grade, mostrada na hora enquanto o detalhe carrega.
  final PictureTile? initialTile;

  const VortexDetailScreen({super.key, required this.itemId, this.initialTile});

  @override
  Widget build(BuildContext context) {
    return VortexThemeScope(child: _VortexDetailBody(itemId: itemId, initialTile: initialTile));
  }
}

class _VortexDetailBody extends StatefulWidget {
  final int itemId;
  final PictureTile? initialTile;

  const _VortexDetailBody({required this.itemId, this.initialTile});

  @override
  State<_VortexDetailBody> createState() => _VortexDetailScreenState();
}

class _VortexDetailScreenState extends State<_VortexDetailBody> {
  static const int _dwellMinSeconds = 8;

  // Sugestões curtidas / escondidas ("menos disso") nesta tela.
  final VortexTileReactions _reactions = VortexTileReactions();

  late PicturesService _service;
  final ScrollController _scroll = ScrollController();
  final Stopwatch _watch = Stopwatch();

  VortexItemDetail? _detail;
  final List<PictureTile> _related = [];
  final Set<String> _relatedKeys = {};
  String? _relatedCursor;
  bool _relatedHasNext = false;
  bool _loadingMore = false;
  bool _loading = true;
  String? _error;
  bool _liked = false;
  bool _dwellSent = false;

  VideoPlayerController? _video;
  bool _videoFailed = false;

  @override
  void initState() {
    super.initState();
    _service = PicturesService(context.read<AuthService>().client);
    _scroll.addListener(_onScroll);
    _watch.start();
    _load();
  }

  @override
  void dispose() {
    _sendDwell();
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    _video?.dispose();
    super.dispose();
  }

  /// Só conta se a pessoa realmente ficou olhando (não foi um toque sem querer).
  void _sendDwell() {
    if (_dwellSent || _error != null) return;
    if (_watch.elapsed.inSeconds >= _dwellMinSeconds) {
      _dwellSent = true;
      _service.trackInteraction(itemId: widget.itemId, kind: 'dwell');
    }
  }

  Future<void> _load() async {
    try {
      final result = await _service.getItem(widget.itemId);
      if (!mounted) return;
      setState(() {
        _detail = result.detail;
        _addRelated(result.related);
        _loading = false;
      });
      if (result.detail.tile.mediaType == 'video') _initVideo(result.detail.tile.mediaUrl);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Este item não está mais disponível.';
        _loading = false;
      });
    }
  }

  void _addRelated(PicturesPage page) {
    for (final t in page.tiles) {
      // o servidor pode reordenar entre páginas: ignora peça que já está na tela
      if (_relatedKeys.add(t.key)) _related.add(t);
    }
    _relatedCursor = page.nextCursor;
    _relatedHasNext = page.hasNext;
  }

  Future<void> _initVideo(String url) async {
    final controller = VideoPlayerController.networkUrl(Uri.parse(resolveMediaUrl(url)));
    try {
      await controller.initialize();
      controller.setLooping(true);
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() => _video = controller);
      controller.play();
    } catch (_) {
      controller.dispose();
      if (mounted) setState(() => _videoFailed = true);
    }
  }

  void _onScroll() {
    if (!_relatedHasNext || _loadingMore || !_scroll.hasClients) return;
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 400) _loadMore();
  }

  Future<void> _loadMore() async {
    setState(() => _loadingMore = true);
    try {
      final page = await _service.getRelated(widget.itemId, cursor: _relatedCursor);
      if (mounted) setState(() => _addRelated(page));
    } catch (_) {
      // silencioso: tenta de novo no próximo scroll
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  void _openRelated(PictureTile tile) {
    final id = tile.itemId;
    if (id == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => VortexDetailScreen(itemId: id, initialTile: tile)),
    );
  }

  /// Segurar uma sugestão: Abrir / Curtir / Menos disso.
  Future<void> _onRelatedLongPress(PictureTile tile) {
    return reactToTile(
      context: context,
      service: _service,
      tile: tile,
      reactions: _reactions,
      onOpen: () => _openRelated(tile),
      onChanged: () {
        if (mounted) setState(() {});
      },
    );
  }

  void _search(String q) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => VortexSearchScreen(initialQuery: q)),
    );
  }

  Future<void> _like() async {
    setState(() => _liked = true);
    await _service.trackInteraction(itemId: widget.itemId, kind: 'like');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vamos mostrar mais disso.'), duration: Duration(seconds: 2)),
      );
    }
  }

  Future<void> _less() async {
    await _service.trackInteraction(itemId: widget.itemId, kind: 'less');
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Ok, vamos mostrar menos disso.'), duration: Duration(seconds: 2)),
    );
    Navigator.of(context).maybePop();
  }

  Future<void> _openSource(String url) async {
    final uri = Uri.tryParse(url);
    // só http/https: o link vem de um site de terceiros
    if (uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  /// Mídia com o coração de curtir por cima, dentro da própria imagem (no vídeo fica no canto de
  /// cima, para não cobrir o controle de reprodução).
  Widget _buildMediaWithLike(PictureTile tile) {
    final top = tile.mediaType == 'video';
    return Stack(
      children: [
        _buildMedia(tile),
        Positioned(
          right: 12,
          top: top ? 12 : null,
          bottom: top ? null : 12,
          child: Material(
            color: _liked ? const Color(0xFFE5446D) : Colors.black54,
            shape: const CircleBorder(),
            child: IconButton(
              tooltip: _liked ? 'Curtido' : 'Curtir',
              onPressed: _liked ? null : _like,
              icon: Icon(
                _liked ? Icons.favorite : Icons.favorite_border,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMedia(PictureTile tile) {
    final ratio = (tile.knownAspectRatio ?? (4 / 5)).clamp(0.5, 2.0).toDouble();
    Widget child;
    if (tile.mediaType == 'video') {
      final c = _video;
      if (_videoFailed) {
        child = Stack(fit: StackFit.expand, children: [
          if (tile.thumbUrl != null) DriqyImage(url: tile.thumbUrl!, fit: BoxFit.cover),
          const Center(child: Icon(Icons.videocam_off_outlined, color: Colors.white70, size: 40)),
        ]);
      } else if (c == null) {
        child = Stack(fit: StackFit.expand, children: [
          if (tile.thumbUrl != null) DriqyImage(url: tile.thumbUrl!, fit: BoxFit.cover),
          const Center(child: CircularProgressIndicator()),
        ]);
      } else {
        return GestureDetector(
          onTap: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
          child: AspectRatio(
            aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio,
            child: Stack(fit: StackFit.expand, children: [
              VideoPlayer(c),
              if (!c.value.isPlaying)
                const Center(child: Icon(Icons.play_circle_outline, color: Colors.white, size: 56)),
            ]),
          ),
        );
      }
    } else {
      // foto e GIF: a mídia inteira (no detalhe vale a original, não a miniatura)
      child = DriqyImage(url: tile.mediaUrl, mediaType: tile.mediaType, fit: BoxFit.contain);
    }
    return AspectRatio(aspectRatio: ratio, child: child);
  }

  Widget _buildHeader(VortexItemDetail d) {
    final tile = d.tile;
    final theme = Theme.of(context);
    final credit = [
      if (d.attribution != null && d.attribution!.isNotEmpty) d.attribution!,
      if (d.license != null && d.license!.isNotEmpty) d.license!,
    ].join(' • ');
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _ActionChip(icon: Icons.thumb_down_alt_outlined, label: 'Menos disso', onTap: _less),
            ],
          ),
          if (tile.title.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(tile.title, style: theme.textTheme.titleMedium),
          ],
          if (tile.profile != null) ...[
            const SizedBox(height: 8),
            Row(children: [
              CircleAvatar(
                radius: 12,
                backgroundImage: tile.profile!.avatarUrl != null
                    ? NetworkImage(resolveMediaUrl(tile.profile!.avatarUrl!))
                    : null,
                child: tile.profile!.avatarUrl == null
                    ? const Icon(Icons.smart_toy_outlined, size: 14)
                    : null,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '${tile.profile!.displayName}${d.sourceName != null ? ' • ${d.sourceName}' : ''}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall,
                ),
              ),
            ]),
          ],
          if (d.description.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(d.description, style: theme.textTheme.bodyMedium),
          ],
          if (credit.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(credit, style: theme.textTheme.bodySmall?.copyWith(color: VortexColors.of(context).textMuted)),
          ],
          if (d.sourceUrl != null && d.sourceUrl!.isNotEmpty)
            TextButton.icon(
              onPressed: () => _openSource(d.sourceUrl!),
              icon: const Icon(Icons.open_in_new, size: 16),
              label: const Text('Ver na fonte'),
            ),
          if (d.tags.isNotEmpty || tile.category != null) ...[
            const SizedBox(height: 4),
            Wrap(
              spacing: 6,
              runSpacing: 0,
              children: [
                for (final t in d.tags.take(10))
                  ActionChip(label: Text('#$t'), onPressed: () => _search(t)),
              ],
            ),
          ],
          const SizedBox(height: 16),
          Text('Mais como este', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final detail = _detail;
    final tile = detail?.tile ?? widget.initialTile;
    final colors = VortexColors.of(context);
    return Scaffold(
      backgroundColor: colors.bg,
      appBar: AppBar(actions: const [VortexThemeButton()]),
      body: _loading && tile == null
          ? const Center(child: CircularProgressIndicator())
          : _error != null && detail == null
              ? Center(child: Text(_error!))
              : SingleChildScrollView(
                  controller: _scroll,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (tile != null) _buildMediaWithLike(tile),
                      if (detail != null)
                        _buildHeader(detail)
                      else
                        const Padding(
                          padding: EdgeInsets.all(24),
                          child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                        ),
                      if (_related.isEmpty && detail != null && !_loadingMore)
                        Padding(
                          padding: const EdgeInsets.all(24),
                          child: Center(
                            child: Text('Ainda não achamos peças parecidas.',
                                style: TextStyle(color: colors.textMuted)),
                          ),
                        )
                      else
                        VortexMasonry(
                          tiles: _related,
                          onTap: _openRelated,
                          onLongPress: _onRelatedLongPress,
                          hidden: _reactions.hidden,
                          liked: _reactions.liked,
                        ),
                      if (_relatedHasNext)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 24),
                          child: Center(
                            child: SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
    );
  }
}

class _ActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  const _ActionChip({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 16),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 12),
      ),
    );
  }
}
