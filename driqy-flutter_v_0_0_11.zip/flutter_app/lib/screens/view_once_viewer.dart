import 'package:flutter/material.dart';

import '../models/message.dart';
import '../services/message_service.dart';
import '../theme/app_colors.dart';
import '../widgets/chat/audio_message.dart';
import '../widgets/driqy_image.dart';
import 'chat_video_player_screen.dart';

/// Abre uma mensagem de VISUALIZAÇÃO ÚNICA (foto, vídeo ou áudio) recebida.
///
/// Fluxo: `POST /view-once` (o servidor marca como aberta e devolve a URL, que só vale alguns
/// minutos) → mostra → ao fechar, `POST /view-once/close` apaga a mídia do servidor. Tentar abrir
/// de novo dá erro 410 ([ApiException]) — quem chama mostra a mensagem.
///
/// Limite conhecido: o app NÃO bloqueia captura de tela (precisaria de `FLAG_SECURE` no Android,
/// que exige código nativo/plugin). O aviso na tela diz isso de forma honesta.
class ViewOnceViewer {
  static Future<void> open(BuildContext context, MessageService service, DriqyMessage m) async {
    final info = await service.openViewOnce(m.id);
    if (!context.mounted) {
      await service.closeViewOnce(m.id);
      return;
    }
    final shown = m.withMedia(
      mediaUrl: info.mediaUrl,
      mediaMime: info.mediaMime,
      mediaWidth: info.width,
      mediaHeight: info.height,
      mediaDurationMs: info.durationMs,
    );
    try {
      switch (m.type) {
        case MessageType.video:
          await ChatVideoPlayerScreen.open(context, shown, headers: service.mediaHeaders);
        case MessageType.audio:
          await Navigator.of(context).push(MaterialPageRoute(
            fullscreenDialog: true,
            builder: (_) => _ViewOnceAudioScreen(message: shown, headers: service.mediaHeaders),
          ));
        default:
          await Navigator.of(context).push(MaterialPageRoute(
            fullscreenDialog: true,
            builder: (_) => _ViewOnceImageScreen(message: shown, headers: service.mediaHeaders),
          ));
      }
    } finally {
      await service.closeViewOnce(m.id);
    }
  }
}

class _Notice extends StatelessWidget {
  const _Notice();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(24, 8, 24, 16),
      child: Text(
        'Visualização única — some ao fechar. Não dá para reabrir nem encaminhar.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white60, fontSize: 12.5),
      ),
    );
  }
}

class _ViewOnceImageScreen extends StatelessWidget {
  final DriqyMessage message;
  final Map<String, String>? headers;

  const _ViewOnceImageScreen({required this.message, this.headers});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('Visualização única', style: TextStyle(fontSize: 16)),
      ),
      body: Column(
        children: [
          Expanded(
            child: InteractiveViewer(
              minScale: 1,
              maxScale: 4,
              child: Center(
                child: DriqyImage(
                  url: message.mediaUrl!,
                  mediaType: (message.mediaMime == 'image/gif') ? 'gif' : null,
                  headers: headers,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ),
          const SafeArea(top: false, child: _Notice()),
        ],
      ),
    );
  }
}

class _ViewOnceAudioScreen extends StatelessWidget {
  final DriqyMessage message;
  final Map<String, String>? headers;

  const _ViewOnceAudioScreen({required this.message, this.headers});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('Visualização única', style: TextStyle(fontSize: 16)),
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface2,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: AudioMessage(message: message, mine: false, headers: headers),
              ),
            ),
          ),
          const SafeArea(top: false, child: _Notice()),
        ],
      ),
    );
  }
}
