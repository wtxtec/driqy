import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/auth_service.dart';
import '../services/rail_prefs_controller.dart';
import '../services/widgets_service.dart';
import '../theme/app_colors.dart';
import '../widgets/driqy_box.dart';
import '../widgets/home_menu.dart';
import '../widgets/inner_nav_host.dart';
import '../widgets/rail/driqy_rail.dart';
import 'widgets_screen.dart';
import '../widgets/home_settings.dart';
import '../widgets/wide_layout.dart';
import 'feed_screen.dart';
import 'messages_inbox_screen.dart';
import 'news_screen.dart';
import 'notifications_screen.dart';
import 'pictures_screen.dart';
import 'profile_screen.dart';

/// Casca do app: barra inferior com EXATAMENTE os mesmos 5 botões, na
/// mesma ordem, do `.bottom-nav` do site (`templates/base.html`):
/// Home, Vortex, Postar (+), Notificações, Mensagens. O botão "Postar"
/// não é uma aba própria — assim como no site ele leva pra publicação,
/// aqui ele troca pra aba Home e rola até o topo, onde o composer
/// (`InlinePostComposer`) já fica fixo. Notícias e Meu perfil, que não
/// têm botão próprio no site, ficam no menu lateral (Drawer) — igual à
/// `.sidebar-nav`, que tem esses mesmos links a mais.
///
/// Layout (Parte 5A, espelha o site): a partir de [kMenuBoxBreakpoint] (901 dp) o Drawer e a
/// barra inferior somem e o menu vira uma caixa arredondada fixa à esquerda; a partir de
/// [kRailBreakpoint] (1200 dp) aparece também o painel direito (widgets + sugestões), mas SÓ na
/// Home (aba Feed, sem tela empilhada por cima), como no site: nas demais abas e telas ele não existe.
///
/// Rotas empilhadas (Rotas-1): em tela larga o miolo tem um `Navigator` próprio ([InnerNavHost]);
/// Notícias, Perfil, Widgets e tudo que o miolo e o painel direito abrem (post, busca, Vortex...)
/// entram ali e a caixa do menu continua na tela. Mensagens (Ping) e os visualizadores de tela cheia
/// continuam por cima de tudo (Navigator raiz). No celular nada mudou.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  // Aba atual. É um ValueNotifier para a rota inicial do Navigator interno (que o Navigator não
  // reconstrói sozinho) se atualizar quando a aba muda; o `setState` continua redesenhando o resto.
  final ValueNotifier<int> _tab = ValueNotifier<int>(0);
  int get _index => _tab.value;
  set _index(int v) => _tab.value = v;
  final _innerNavKey = GlobalKey<NavigatorState>();
  // Última decisão do LayoutBuilder (tela larga = menu em caixa + Navigator interno).
  bool _wide = false;
  // Telas empilhadas no miolo (tela larga). Com alguma aberta o painel direito some: ele só existe na Home.
  int _innerDepth = 0;
  final _feedKey = GlobalKey<FeedScreenState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  // Guarda o estado das abas (rolagem do feed etc.) quando a tela alterna entre larga e estreita.
  final _contentKey = GlobalKey();
  RailPrefsController? _railPrefs;

  @override
  void initState() {
    super.initState();
    final c = RailPrefsController(WidgetsService(context.read<AuthService>().client));
    _railPrefs = c;
    c.load();
  }

  @override
  void dispose() {
    _railPrefs?.dispose();
    _tab.dispose();
    super.dispose();
  }

  void _openMenu() => _scaffoldKey.currentState?.openDrawer();

  void _closeDrawerIfOpen() {
    if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
      Navigator.of(context).pop();
    }
  }

  void _selectTab(int index) {
    _closeDrawerIfOpen();
    _popInner();
    setState(() => _index = index);
  }

  /// Em tela larga, fecha as telas empilhadas no miolo (volta às abas).
  void _popInner() {
    final inner = _innerNavKey.currentState;
    if (inner != null && inner.canPop()) inner.popUntil((r) => r.isFirst);
  }

  /// Botão "Postar" da barra inferior: vai pra Home e rola até o topo,
  /// onde o composer já está sempre visível — mesmo destino do botão
  /// "Publicar" do site, só que sem precisar de uma tela separada.
  void _goToCompose() {
    _closeDrawerIfOpen();
    _popInner();
    setState(() => _index = 0);
    _feedKey.currentState?.scrollToTop();
  }

  /// Abre [screen] por cima de TUDO (Navigator raiz): telas que não cabem na coluna do miolo.
  void _pushRoot(Widget screen) {
    _closeDrawerIfOpen();
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  /// Abre [screen] a partir de um item do menu. Em tela larga entra no Navigator interno do miolo
  /// (a caixa do menu continua na tela) e SUBSTITUI o que já estava empilhado — clicar de novo num
  /// item do menu não empilha telas. No celular é uma rota normal por cima de tudo.
  void _pushStacked(Widget screen) {
    _closeDrawerIfOpen();
    final route = MaterialPageRoute<void>(builder: (_) => screen);
    final inner = _wide ? _innerNavKey.currentState : null;
    if (inner != null) {
      inner.pushAndRemoveUntil(route, (r) => r.isFirst);
    } else {
      Navigator.of(context).push(route);
    }
  }

  /// Abre o Ping como rota própria (botão voltar leva de volta ao Driqy).
  void _openPing() => _pushRoot(const MessagesInboxScreen());

  Future<void> _logout() async {
    _closeDrawerIfOpen();
    await context.read<AuthService>().logout();
  }

  HomeMenu _menu({required String? username, required bool box, bool customize = false, bool widgets = false}) => HomeMenu(
        selectedTab: _index,
        onSelectTab: _selectTab,
        onNews: () => _pushStacked(const NewsScreen()),
        onMessages: _openPing,
        onProfile: username == null ? null : () => _pushStacked(ProfileScreen(username: username)),
        onLogout: _logout,
        // o ✕ só existe no Drawer; na caixa fixa não há o que fechar
        onClose: box ? null : _closeDrawerIfOpen,
        // o painel direito só existe em tela larga (a caixa fixa); o "Personalizar painel" fica dentro
        // de Configurações, que é também por onde se traz o painel de volta depois de escondê-lo
        // sem a coluna da direita (celular), os widgets abrem em tela própria
        onWidgets: widgets && _railPrefs != null
            ? () => _pushStacked(WidgetsScreen(prefs: _railPrefs!, onOpenVortex: () {
                // celular: fecha a tela de widgets (rota raiz); tela larga: `_selectTab` já fecha a do miolo
                if (!_wide) Navigator.of(context).maybePop();
                _selectTab(kVortexTabIndex);
              }))
            : null,
        onSettings: box && customize && _railPrefs != null ? () => showHomeSettingsDialog(context, _railPrefs!) : null,
      );

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().currentUser;
    final username = user?.username;
    final tabs = <Widget>[
      // Em tela larga o miolo fica numa coluna de 620 (como o site). A árvore tem o mesmo formato
      // nos dois modos, então a rolagem do feed não zera ao redimensionar.
      _ColumnTab(child: FeedScreen(key: _feedKey, onOpenMenu: _openMenu)),
      PicturesScreen(onOpenMenu: _openMenu),
      _ColumnTab(child: NotificationsScreen(onOpenMenu: _openMenu)),
      // O Ping NÃO é mais uma aba: é um app à parte (sem logo/busca/menus do
      // Driqy), aberto como rota própria por `_openPing`.
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = menuBoxFits(constraints.maxWidth);
        _wide = wide;
        if (!wide) _innerDepth = 0; // o Navigator interno só existe em tela larga
        // O painel direito existe SÓ na Home (aba Feed, sem tela empilhada por cima), como no site.
        final railFitsHere = wide && railFits(constraints.maxWidth, tabIndex: _index) && _innerDepth == 0;
        // "Widgets" no menu: só onde a coluna da direita não cabe na largura (celular/tela média).
        final widgetsInMenu = constraints.maxWidth < kRailBreakpoint;
        // Celular: as abas direto no corpo. Tela larga: dentro do Navigator interno (telas
        // empilhadas ficam no miolo). A mesma KeyedSubtree nos dois casos: a rolagem do feed não
        // zera ao redimensionar a janela.
        final content = wide
            ? InnerNavHost(
                navigatorKey: _innerNavKey,
                homeFullWidth: _index == kVortexTabIndex,
                onDepthChanged: (d) {
                  if (mounted) setState(() => _innerDepth = d);
                },
                homeBuilder: (_) => ValueListenableBuilder<int>(
                  valueListenable: _tab,
                  builder: (_, i, __) => KeyedSubtree(
                    key: _contentKey,
                    child: IndexedStack(index: i, children: tabs),
                  ),
                ),
              )
            : KeyedSubtree(
                key: _contentKey,
                child: IndexedStack(index: _index, children: tabs),
              );

        return Scaffold(
          key: _scaffoldKey,
          // Sem AppBar aqui: cada aba já tem a sua própria, e cada uma ganhou
          // um botão de menu (☰) que abre este Drawer — evita duas AppBars
          // empilhadas. Em tela larga o menu é a caixa fixa e não há Drawer.
          drawer: wide
              ? null
              : Drawer(
                  backgroundColor: AppColors.surface,
                  child: SafeArea(child: _menu(username: username, box: false, widgets: widgetsInMenu)),
                ),
          body: ShellNav(
            navigatorKey: _innerNavKey,
            child: WideShell(
              menuBox: wide,
              child: wide
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: kMenuBoxWidth + 2 * kBoxGap,
                          child: SafeArea(
                            right: false,
                            child: Padding(
                              padding: const EdgeInsets.all(kBoxGap),
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: DriqyBox(
                                  child: _menu(
                                    username: username,
                                    box: true,
                                    customize: constraints.maxWidth >= kRailBreakpoint,
                                    widgets: widgetsInMenu,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(child: content),
                        if (railFitsHere && _railPrefs != null)
                          ListenableBuilder(
                            listenable: _railPrefs!,
                            builder: (context, _) => _railPrefs!.prefs.railHidden || !_railPrefs!.loaded
                                ? const SizedBox.shrink()
                                : DriqyRail(
                                    onOpenVortex: () => _selectTab(kVortexTabIndex),
                                    prefs: _railPrefs!.prefs,
                                    onSavePrefs: _railPrefs!.save,
                                    customs: _railPrefs!.customs,
                                    customKinds: _railPrefs!.customKinds,
                                    customMax: _railPrefs!.customMax,
                                    onCreateCustom: _railPrefs!.createCustom,
                                    onDeleteCustom: _railPrefs!.deleteCustom,
                                    onRenameCustom: _railPrefs!.renameCustomLocally,
                                  ),
                          ),
                      ],
                    )
                  : content,
            ),
          ),
          // Em tela larga a barra inferior só repetiria os links do menu (igual ao site).
          bottomNavigationBar: wide
              ? null
              : _BottomNavBar(
                  index: _index,
                  onSelect: _selectTab,
                  onCompose: _goToCompose,
                  onPing: _openPing,
                ),
        );
      },
    );
  }
}

/// Aplica a coluna de largura máxima nas abas de leitura quando o menu está em caixa.
class _ColumnTab extends StatelessWidget {
  final Widget child;

  const _ColumnTab({required this.child});

  @override
  Widget build(BuildContext context) => ContentColumn(enabled: WideShell.of(context), child: child);
}

/// Barra inferior — mesma ordem/ícones do `.bottom-nav` do site: Home,
/// Vortex, Postar (botão redondo com gradiente da marca, sem rótulo,
/// igual ao `.bottom-nav-post-btn`), Notificações, Mensagens.
class _BottomNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onSelect;
  final VoidCallback onCompose;
  final VoidCallback onPing;

  const _BottomNavBar({
    required this.index,
    required this.onSelect,
    required this.onCompose,
    required this.onPing,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 62,
          child: Row(
            children: [
              _BottomNavItem(
                icon: Icons.home_outlined,
                activeIcon: Icons.home,
                label: 'Home',
                selected: index == 0,
                onTap: () => onSelect(0),
              ),
              _BottomNavItem(
                icon: Icons.blur_circular_outlined,
                activeIcon: Icons.blur_circular,
                label: 'Vortex',
                selected: index == 1,
                onTap: () => onSelect(1),
              ),
              _BottomNavPostItem(onTap: onCompose),
              _BottomNavItem(
                icon: Icons.notifications_outlined,
                activeIcon: Icons.notifications,
                label: 'Notificações',
                selected: index == 2,
                onTap: () => onSelect(2),
              ),
              _BottomNavItem(
                icon: Icons.mail_outline,
                activeIcon: Icons.mail,
                label: 'Mensagens',
                selected: false, // abre fora da HomeShell (rota própria)
                onTap: onPing,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _BottomNavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.amber : AppColors.textMuted;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(selected ? activeIcon : icon, color: color, size: 24),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: 9.5,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Botão "Postar" — círculo elevado com o gradiente âmbar→rosa da marca
/// e um "+", sem rótulo embaixo. Espelha `.bottom-nav-post-btn` do CSS
/// (mesmo leve deslocamento pra cima, `translateY(-10px)`, pra ficar em
/// destaque sobre os outros itens da barra).
class _BottomNavPostItem extends StatelessWidget {
  final VoidCallback onTap;

  const _BottomNavPostItem({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: InkWell(
        onTap: onTap,
        child: Center(
          child: Transform.translate(
            offset: const Offset(0, -10),
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                gradient: AppGradients.brand,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: Color(0x59F2A93B), blurRadius: 14, offset: Offset(0, 4)),
                ],
              ),
              child: Icon(Icons.add, color: AppColors.onBrand, size: 26),
            ),
          ),
        ),
      ),
    );
  }
}
