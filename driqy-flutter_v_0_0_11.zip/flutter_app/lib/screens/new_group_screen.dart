import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/chat_group.dart';
import '../models/user.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/group_service.dart';
import '../services/search_service.dart';
import '../theme/app_colors.dart';

/// "Novo grupo" (estilo Telegram): nome + pessoas. Devolve o [DriqyGroup] criado (pop) —
/// quem abriu decide como mostrar a conversa. Também serve para "Adicionar participantes"
/// quando [existing] vem preenchido (devolve a lista de @ escolhidos).
class NewGroupScreen extends StatefulWidget {
  /// Se não nulo: modo "adicionar participantes" (sem nome; ignora quem já está no grupo).
  final Set<String>? existing;

  const NewGroupScreen({super.key, this.existing});

  @override
  State<NewGroupScreen> createState() => _NewGroupScreenState();
}

class _NewGroupScreenState extends State<NewGroupScreen> {
  final _name = TextEditingController();
  final _q = TextEditingController();
  final Map<String, DriqyUser> _picked = {};
  List<DriqyUser> _results = [];
  Timer? _debounce;
  int _seq = 0;
  bool _busy = false;
  String? _error;

  bool get _adding => widget.existing != null;
  bool get _canSubmit => !_busy && _picked.isNotEmpty && (_adding || _name.text.trim().isNotEmpty);

  @override
  void dispose() {
    _debounce?.cancel();
    _name.dispose();
    _q.dispose();
    super.dispose();
  }

  void _onSearch(String v) {
    _debounce?.cancel();
    if (v.trim().isEmpty) {
      setState(() => _results = []);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 250), () async {
      final mine = ++_seq;
      try {
        final r = await SearchService(context.read<AuthService>().client).searchUsers(v.trim());
        if (mounted && mine == _seq) setState(() => _results = r.where((u) => !(widget.existing ?? {}).contains(u.username.toLowerCase())).toList());
      } catch (_) {}
    });
  }

  Future<void> _submit() async {
    if (!_canSubmit) return;
    final names = _picked.keys.toList();
    if (_adding) {
      Navigator.of(context).pop(names);
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final g = await GroupService(context.read<AuthService>().client).create(_name.text.trim(), names);
      if (mounted) Navigator.of(context).pop<DriqyGroup>(g);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Não foi possível criar o grupo.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_adding ? 'Adicionar participantes' : 'Novo grupo')),
      floatingActionButton: _canSubmit
          ? FloatingActionButton(onPressed: _submit, tooltip: _adding ? 'Adicionar' : 'Criar grupo', child: const Icon(Icons.check))
          : null,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (!_adding)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: TextField(
                controller: _name,
                maxLength: 60,
                textCapitalization: TextCapitalization.sentences,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(labelText: 'Nome do grupo', counterText: ''),
              ),
            ),
          if (_picked.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Wrap(
                spacing: 6,
                children: _picked.values
                    .map((u) => InputChip(
                          label: Text(u.displayName),
                          onDeleted: () => setState(() => _picked.remove(u.username)),
                        ))
                    .toList(),
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              controller: _q,
              onChanged: _onSearch,
              decoration: const InputDecoration(hintText: 'Buscar pessoas', prefixIcon: Icon(Icons.search)),
            ),
          ),
          if (_error != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text(_error!, style: TextStyle(color: AppColors.danger))),
          Expanded(
            child: ListView(
              children: _results.map((u) {
                final on = _picked.containsKey(u.username);
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: u.avatarUrl != null ? NetworkImage(resolveMediaUrl(u.avatarUrl!)) : null,
                    child: u.avatarUrl == null ? Text(u.displayName[0].toUpperCase()) : null,
                  ),
                  title: Text(u.displayName),
                  subtitle: Text('@${u.username}'),
                  trailing: Icon(on ? Icons.check_circle : Icons.circle_outlined, color: on ? AppColors.amber : AppColors.textMuted),
                  onTap: () => setState(() => on ? _picked.remove(u.username) : _picked[u.username] = u),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
