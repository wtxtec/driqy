import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/user.dart';
import '../services/auth_service.dart';
import '../services/search_service.dart';
import '../services/user_service.dart';
import '../widgets/driqy_top_bar.dart';
import '../widgets/user_tile.dart';
import 'profile_screen.dart';

class SearchScreen extends StatefulWidget {
  final VoidCallback? onOpenMenu;

  const SearchScreen({super.key, this.onOpenMenu});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late SearchService _searchService;
  late UserService _userService;
  final _controller = TextEditingController();
  Timer? _debounce;

  List<DriqyUser> _results = [];
  bool _loading = false;
  String? _error;
  final Set<String> _followLoadingUsernames = {};

  @override
  void initState() {
    super.initState();
    final client = context.read<AuthService>().client;
    _searchService = SearchService(client);
    _userService = UserService(client);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () => _search(value));
  }

  Future<void> _search(String query) async {
    if (query.trim().isEmpty) {
      setState(() {
        _results = [];
        _error = null;
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await _searchService.searchUsers(query);
      if (mounted) setState(() => _results = results);
    } catch (_) {
      if (mounted) setState(() => _error = 'Não foi possível buscar agora.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _toggleFollow(DriqyUser user) async {
    setState(() => _followLoadingUsernames.add(user.username));
    try {
      final isFollowing = user.isFollowing
          ? await _userService.unfollow(user.username)
          : await _userService.follow(user.username);
      setState(() {
        final index = _results.indexWhere((u) => u.username == user.username);
        if (index != -1) {
          _results[index] = DriqyUser(
            id: user.id,
            username: user.username,
            displayName: user.displayName,
            bio: user.bio,
            location: user.location,
            accentColor: user.accentColor,
            avatarUrl: user.avatarUrl,
            coverUrl: user.coverUrl,
            badgeKind: user.badgeKind,
            followersCount: user.followersCount + (isFollowing ? 1 : -1),
            followingCount: user.followingCount,
            isFollowing: isFollowing,
            isMe: user.isMe,
            createdAt: user.createdAt,
            activePostsCount: user.activePostsCount,
            isStaff: user.isStaff,
          );
        }
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Não foi possível atualizar.')));
      }
    } finally {
      if (mounted) setState(() => _followLoadingUsernames.remove(user.username));
    }
  }

  void _openProfile(String username) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProfileScreen(username: username)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Mesma topbar de toda página (logo + pílula de busca + mensagens/
      // notificações) — igual ao site, que também mantém essa barra fixa
      // aqui e usa um campo de busca PRÓPRIO, separado, dentro do
      // conteúdo da página (ver `search_results.html`: `<h1>Buscar</h1>`
      // + `<form class="search-box">`).
      appBar: DriqyTopBar(onOpenMenu: widget.onOpenMenu),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Buscar', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                TextField(
                  controller: _controller,
                  onChanged: _onChanged,
                  decoration: const InputDecoration(
                    hintText: 'Buscar pessoas...',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
              ],
            ),
          ),
          Expanded(child: _buildResultsArea()),
        ],
      ),
    );
  }

  Widget _buildResultsArea() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(child: Text(_error!));
    }
    if (_controller.text.trim().isEmpty) {
      return const Center(child: Text('Digite um nome ou usuário para buscar.'));
    }
    if (_results.isEmpty) {
      return const Center(child: Text('Nenhum usuário encontrado.'));
    }
    return ListView.builder(
      itemCount: _results.length,
      itemBuilder: (context, index) {
        final user = _results[index];
        return UserTile(
          user: user,
          onTap: () => _openProfile(user.username),
          onFollowTap: () => _toggleFollow(user),
          followLoading: _followLoadingUsernames.contains(user.username),
        );
      },
    );
  }
}
