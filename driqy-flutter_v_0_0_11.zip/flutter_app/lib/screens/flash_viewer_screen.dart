import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/flash.dart';
import '../services/auth_service.dart';
import '../services/flash_service.dart';
import '../theme/app_colors.dart';

/// Visualizador de Flash em tela cheia: barras de progresso (5 s por foto), toque à esquerda
/// volta / à direita avança, segurar pausa, arrastar pra baixo fecha. Passa sozinho para a
/// próxima pessoa da fila. O dono vê o contador de visualizações e pode excluir.
class FlashViewerScreen extends StatefulWidget {
  final List<String> usernames;
  final int startIndex;

  const FlashViewerScreen({super.key, required this.usernames, this.startIndex = 0});

  @override
  State<FlashViewerScreen> createState() => _FlashViewerScreenState();
}

class _FlashViewerScreenState extends State<FlashViewerScreen> with SingleTickerProviderStateMixin {
  static const _photoDuration = Duration(seconds: 5);

  late final FlashService _service;
  late final AnimationController _progress;
  int _userIdx = 0;
  int _flashIdx = 0;
  FlashGroup? _group;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _service = FlashService(context.read<AuthService>().client);
    _userIdx = widget.startIndex;
    _progress = AnimationController(vsync: this, duration: _photoDuration)
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) _next();
      });
    _loadGroup(_userIdx);
  }

  @override
  void dispose() {
    _progress.dispose();
    super.dispose();
  }

  Future<void> _loadGroup(int idx) async {
    _progress.stop();
    setState(() => _loading = true);
    try {
      final g = await _service.ofUser(widget.usernames[idx]);
      if (!mounted) return;
      if (g.flashes.isEmpty) {
        _nextGroup();
        return;
      }
      final firstUnseen = g.flashes.indexWhere((f) => !f.seen);
      setState(() {
        _userIdx = idx;
        _group = g;
        _flashIdx = firstUnseen < 0 ? 0 : firstUnseen;
        _loading = false;
      });
      _startCurrent();
    } catch (_) {
      if (mounted) Navigator.of(context).maybePop();
    }
  }

  void _startCurrent() {
    final f = _group!.flashes[_flashIdx];
    if (!f.seen && !f.isMine) {
      f.seen = true;
      _service.markViewed(f.id);
    }
    _progress
      ..stop()
      ..value = 0;
    // começa quando a imagem carregar (ver frameBuilder); fallback: já inicia
    precacheImage(NetworkImage(resolveMediaUrl(f.imageUrl)), context).whenComplete(() {
      if (mounted && !_loading) _progress.forward(from: 0);
    });
  }

  void _nextGroup() {
    if (_userIdx + 1 < widget.usernames.length) {
      _loadGroup(_userIdx + 1);
    } else {
      Navigator.of(context).maybePop();
    }
  }

  void _next() {
    final g = _group;
    if (g == null) return;
    if (_flashIdx + 1 < g.flashes.length) {
      setState(() => _flashIdx++);
      _startCurrent();
    } else {
      _nextGroup();
    }
  }

  void _prev() {
    if (_flashIdx > 0) {
      setState(() => _flashIdx--);
      _startCurrent();
    } else if (_userIdx > 0) {
      _loadGroup(_userIdx - 1);
    } else {
      _startCurrent();
    }
  }

  String _ago(DateTime t) {
    final m = DateTime.now().toUtc().difference(t.toUtc()).inMinutes;
    if (m < 1) return 'agora';
    if (m < 60) return 'há $m min';
    return 'há ${m ~/ 60} h';
  }

  Future<void> _delete(FlashItem f) async {
    _progress.stop();
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Excluir este Flash?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (yes != true) {
      _progress.forward();
      return;
    }
    await _service.delete(f.id);
    if (!mounted) return;
    final g = _group!;
    g.flashes.remove(f);
    if (g.flashes.isEmpty) {
      Navigator.of(context).maybePop();
      return;
    }
    setState(() => _flashIdx = _flashIdx.clamp(0, g.flashes.length - 1).toInt());
    _startCurrent();
  }

  Future<void> _showViewers(FlashItem f) async {
    _progress.stop();
    final list = await _service.viewers(f.id).catchError((_) => <FlashViewer>[]);
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.all(16),
          children: [
            Text(list.isEmpty ? 'Ninguém viu ainda' : 'Quem viu (${list.length})',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            for (final v in list)
              ListTile(
                dense: true,
                title: Text('@${v.username}'),
                trailing: Text(_ago(v.viewedAt), style: TextStyle(color: AppColors.textMuted)),
              ),
          ],
        ),
      ),
    );
    if (mounted) _progress.forward();
  }

  @override
  Widget build(BuildContext context) {
    final g = _group;
    return Scaffold(
      backgroundColor: Colors.black,
      body: _loading || g == null
          ? const Center(child: CircularProgressIndicator())
          : _buildStory(g),
    );
  }

  Widget _buildStory(FlashGroup g) {
    final f = g.flashes[_flashIdx];
    final width = MediaQuery.of(context).size.width;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapUp: (d) => d.globalPosition.dx < width * 0.35 ? _prev() : _next(),
      onLongPressStart: (_) => _progress.stop(),
      onLongPressEnd: (_) => _progress.forward(),
      onVerticalDragEnd: (d) {
        if ((d.primaryVelocity ?? 0) > 300) Navigator.of(context).maybePop();
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            resolveMediaUrl(f.imageUrl),
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) =>
                const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white54, size: 48)),
          ),
          if (f.caption.isNotEmpty)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: EdgeInsets.fromLTRB(20, 40, 20, 28 + MediaQuery.of(context).padding.bottom),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xCC000000)],
                  ),
                ),
                child: Text(f.caption,
                    textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                  child: Row(
                    children: [
                      for (var i = 0; i < g.flashes.length; i++)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(2),
                              child: i == _flashIdx
                                  ? AnimatedBuilder(
                                      animation: _progress,
                                      builder: (_, __) => LinearProgressIndicator(
                                        value: _progress.value,
                                        minHeight: 3,
                                        backgroundColor: Colors.white30,
                                        valueColor: const AlwaysStoppedAnimation(Colors.white),
                                      ),
                                    )
                                  : LinearProgressIndicator(
                                      value: i < _flashIdx ? 1 : 0,
                                      minHeight: 3,
                                      backgroundColor: Colors.white30,
                                      valueColor: const AlwaysStoppedAnimation(Colors.white),
                                    ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 4, 0),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 17,
                        backgroundColor: AppColors.surface2,
                        backgroundImage: g.user.avatarUrl != null
                            ? NetworkImage(resolveMediaUrl(g.user.avatarUrl!))
                            : null,
                        child: g.user.avatarUrl == null ? Text(g.user.displayName[0].toUpperCase()) : null,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text('${g.user.displayName}  ${_ago(f.createdAt)}',
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white, fontWeight: FontWeight.w600, shadows: [Shadow(blurRadius: 4)])),
                      ),
                      if (f.isMine)
                        IconButton(
                          tooltip: 'Excluir',
                          icon: const Icon(Icons.delete_outline, color: Colors.white),
                          onPressed: () => _delete(f),
                        ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.of(context).maybePop(),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                if (f.isMine)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: TextButton.icon(
                        style: TextButton.styleFrom(
                            backgroundColor: Colors.black54, foregroundColor: Colors.white),
                        onPressed: () => _showViewers(f),
                        icon: const Icon(Icons.visibility_outlined, size: 18),
                        label: Text('${f.viewsCount}'),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
