import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/post.dart';
import '../models/user.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/post_service.dart';
import '../services/user_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_spacing.dart';
import '../widgets/gradient_button.dart';
import '../widgets/inline_post_composer.dart';
import '../widgets/media_lightbox.dart';
import '../widgets/post_card.dart';
import '../widgets/driqy_top_bar.dart';
import '../widgets/flash_ring.dart';
import 'edit_profile_screen.dart';
import 'message_thread_screen.dart';
import 'post_detail_screen.dart';

class ProfileScreen extends StatefulWidget {
  final String username;

  /// Só é passado quando esta tela é a aba "Meu perfil" da HomeShell —
  /// abre o Drawer em vez do botão de voltar (que não existiria mesmo,
  /// já que é uma aba, não uma tela empilhada).
  final VoidCallback? onOpenMenu;

  const ProfileScreen({super.key, required this.username, this.onOpenMenu});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late UserService _userService;
  late PostService _postService;

  DriqyUser? _user;
  final List<DriqyPost> _posts = [];
  int _page = 1;
  bool _hasNext = true;
  bool _loadingProfile = true;
  bool _loadingPosts = false;
  bool _followLoading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final client = context.read<AuthService>().client;
    _userService = UserService(client);
    _postService = PostService(client);
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loadingProfile = true;
      _error = null;
    });
    try {
      final user = await _userService.getProfile(widget.username);
      setState(() => _user = user);
      await _loadPosts(reset: true);
    } catch (_) {
      setState(() => _error = 'Não foi possível carregar o perfil.');
    } finally {
      if (mounted) setState(() => _loadingProfile = false);
    }
  }

  Future<void> _loadPosts({bool reset = false}) async {
    if (_loadingPosts) return;
    setState(() => _loadingPosts = true);
    try {
      final page = reset ? 1 : _page + 1;
      final result = await _userService.getPosts(widget.username, page: page);
      setState(() {
        if (reset) _posts.clear();
        _posts.addAll(result.posts);
        _page = page;
        _hasNext = result.hasNext;
      });
    } catch (_) {
      // silencioso: mantém o que já carregou
    } finally {
      if (mounted) setState(() => _loadingPosts = false);
    }
  }

  Future<void> _toggleFollow() async {
    final user = _user;
    if (user == null || _followLoading) return;
    setState(() => _followLoading = true);
    try {
      final isFollowing = user.isFollowing
          ? await _userService.unfollow(user.username)
          : await _userService.follow(user.username);
      setState(() {
        _user = DriqyUser(
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          bio: user.bio,
          location: user.location,
          accentColor: user.accentColor,
          avatarUrl: user.avatarUrl,
          coverUrl: user.coverUrl,
          badgeKind: user.badgeKind,
          followersCount: user.followersCount + (isFollowing ? 1 : -1),
          followingCount: user.followingCount,
          isFollowing: isFollowing,
          isMe: user.isMe,
          createdAt: user.createdAt,
          activePostsCount: user.activePostsCount,
          isStaff: user.isStaff,
        );
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Não foi possível atualizar.')));
      }
    } finally {
      if (mounted) setState(() => _followLoading = false);
    }
  }

  Future<void> _toggleLike(DriqyPost post) async {
    final wasLiked = post.likedByMe;
    setState(() {
      post.likedByMe = !wasLiked;
      post.likesCount += wasLiked ? -1 : 1;
    });
    try {
      final liked = await _postService.toggleLike(post.id);
      if (liked != post.likedByMe && mounted) setState(() => post.likedByMe = liked);
    } catch (_) {
      if (mounted) {
        setState(() {
          post.likedByMe = wasLiked;
          post.likesCount += wasLiked ? 1 : -1;
        });
      }
    }
  }

  Future<void> _openEditProfile() async {
    final updated = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const EditProfileScreen()),
    );
    if (updated == true) {
      _load();
    }
  }

  void _openMessages() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => MessageThreadScreen(username: widget.username)),
    );
  }

  /// Abre a página do post (onde ficam os comentários). Ao voltar,
  /// atualiza as contagens de curtidas/comentários do card.
  Future<void> _openPost(int postId, {bool focusComment = false}) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PostDetailScreen(postId: postId, focusComment: focusComment)),
    );
    if (!mounted) return;
    try {
      final fresh = await PostService(context.read<AuthService>().client).getPost(postId);
      final i = _posts.indexWhere((p) => p.id == postId);
      if (i != -1 && mounted) {
        setState(() {
          _posts[i].commentsCount = fresh.commentsCount;
          _posts[i].likesCount = fresh.likesCount;
          _posts[i].likedByMe = fresh.likedByMe;
        });
      }
    } on ApiException catch (e) {
      // 404 = o post foi excluído (ex.: pelo autor, na página do post)
      if (e.statusCode == 404 && mounted) {
        setState(() => _posts.removeWhere((p) => p.id == postId));
      }
    } catch (_) {
      // silencioso: mantém as contagens antigas
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Mesma topbar do Feed/Notificações — o site usa a mesma barra
      // (logo + busca + mensagens/notificações) em toda página,
      // inclusive no perfil, em vez de um título "@usuário" na barra.
      appBar: DriqyTopBar(onOpenMenu: widget.onOpenMenu),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loadingProfile) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null || _user == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error ?? 'Usuário não encontrado.'),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _load, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    final user = _user!;
    return RefreshIndicator(
      onRefresh: () => _loadPosts(reset: true),
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (_hasNext &&
              !_loadingPosts &&
              notification.metrics.pixels >= notification.metrics.maxScrollExtent - 300) {
            _loadPosts();
          }
          return false;
        },
        child: ListView(
          children: [
            _buildHeader(user),
            // Composer "O que está acontecendo?" só aparece no próprio
            // perfil (igual ao site) — no perfil de outra pessoa não tem
            // como postar por ela.
            if (user.isMe) InlinePostComposer(onPosted: () => _loadPosts(reset: true)),
            if (_posts.isEmpty && !_loadingPosts)
              const Padding(
                padding: EdgeInsets.all(AppSpacing.gap),
                child: Center(child: Text('Nenhum post por aqui ainda.')),
              )
            else
              ..._posts.map((post) => PostCard(
                    key: ValueKey('post-${post.id}'),
                    post: post,
                    onLikeTap: () => _toggleLike(post),
                    onTap: () => _openPost(post.id),
              onCommentsTap: () => _openPost(post.id, focusComment: true),
                    onExpired: () {
                      if (mounted) setState(() => _posts.removeWhere((p) => p.id == post.id));
                    },
                    onDelete: () async {
                      await _postService.deletePost(post.id);
                      if (mounted) setState(() => _posts.removeWhere((p) => p.id == post.id));
                    },
                  )),
            if (_loadingPosts)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }

  static const _monthsFull = [
    'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
    'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro',
  ];

  String _joinDateLabel(DateTime createdAt) {
    final local = createdAt.toLocal();
    return '${_monthsFull[local.month - 1]} de ${local.year}';
  }

  Widget _buildCoverImage(DriqyUser user) {
    return Container(
      decoration: BoxDecoration(
        gradient: user.coverUrl == null
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.accentFromKey(user.accentColor), AppColors.rose],
              )
            : null,
        image: user.coverUrl != null
            ? DecorationImage(
                image: NetworkImage(resolveMediaUrl(user.coverUrl!)),
                fit: BoxFit.cover,
              )
            : null,
      ),
    );
  }

  Widget _buildAvatar(DriqyUser user, double avatarSize) {
    // `.profile-avatar`: borda de 3px na cor de fundo (breakpoint mobile),
    // criando o "furo" que deixa a capa por trás aparecer ao redor.
    final avatar = Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.bg, width: 3),
      ),
      child: CircleAvatar(
        radius: avatarSize / 2,
        backgroundColor: AppColors.surface2,
        backgroundImage:
            user.avatarUrl != null ? NetworkImage(resolveMediaUrl(user.avatarUrl!)) : null,
        child: user.avatarUrl == null
            ? Text(user.displayName[0].toUpperCase(), style: const TextStyle(fontSize: 24))
            : null,
      ),
    );
    // Com Flash ativo: anel colorido e o toque abre o Flash (como nos stories).
    if (user.hasFlash) {
      return GestureDetector(
        onTap: () => openFlash(context, [user.username]),
        child: FlashRing(hasFlash: true, unseen: user.flashUnseen, thickness: 3, gap: 0, child: avatar),
      );
    }
    // Toque na foto abre ela em tela cheia (mesmo lightbox dos posts),
    // igual ao site. Sem foto cadastrada, não há o que ampliar.
    if (user.avatarUrl == null) return avatar;
    return GestureDetector(
      onTap: () => MediaLightbox.open(context, [user.avatarUrl!]),
      child: avatar,
    );
  }

  Widget _buildHeaderActions(DriqyUser user) {
    // `.profile-header-actions { padding-top: 12px; gap: 10px; }`
    if (user.isMe) {
      return Padding(
        padding: const EdgeInsets.only(top: 12),
        child: OutlinedButton.icon(
          icon: const Icon(Icons.edit_outlined, size: 16),
          label: const Text('Editar perfil'),
          onPressed: _openEditProfile,
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          OutlinedButton(
            onPressed: _openMessages,
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.all(10),
              minimumSize: const Size(0, 0),
              shape: const CircleBorder(),
            ),
            child: const Icon(Icons.mail_outline, size: 17),
          ),
          const SizedBox(width: 10),
          user.isFollowing
              ? OutlinedButton(
                  onPressed: _followLoading ? null : _toggleFollow,
                  style: OutlinedButton.styleFrom(minimumSize: const Size(104, 36)),
                  child: _followLoading
                      ? const SizedBox(
                          height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Seguindo'),
                )
              : GradientButton(
                  height: 36,
                  onPressed: _followLoading ? null : _toggleFollow,
                  child: _followLoading
                      ? SizedBox(
                          height: 16,
                          width: 16,
                          child:
                              CircularProgressIndicator(strokeWidth: 2, color: AppColors.onBrand),
                        )
                      : const Text('Seguir'),
                ),
        ],
      ),
    );
  }

  /// Ícone do selo por tipo, igual às 3 variações desenhadas em
  /// `_badges.html` (estrela pra admin, escudo com check pra mod, check
  /// simples pro selo azul padrão) — antes usava sempre o mesmo ícone
  /// genérico pros 3 casos.
  IconData _badgeIcon(String kind) {
    switch (kind) {
      case 'admin':
        return Icons.star;
      case 'mod':
        return Icons.shield;
      default:
        return Icons.verified;
    }
  }

  Widget _buildIdentity(DriqyUser user) {
    // `.profile-identity`: nome+selo, @usuário, bio, localização/data de
    // entrada e as estatísticas, nessa ordem exata.
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Flexible(
              child: Text(
                user.displayName,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (user.badgeKind != null) ...[
              const SizedBox(width: 4),
              Icon(_badgeIcon(user.badgeKind!), size: 16, color: AppColors.badgeColor(user.badgeKind)),
            ],
          ],
        ),
        Text('@${user.username}', style: TextStyle(color: AppColors.textMuted)),
        if (user.bio.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(user.bio),
        ],
        const SizedBox(height: 12),
        Wrap(
          spacing: 14,
          runSpacing: 4,
          children: [
            if (user.location.isNotEmpty)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.place_outlined, size: 15, color: AppColors.textMuted),
                  const SizedBox(width: 4),
                  Text(user.location, style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                ],
              ),
            if (user.createdAt != null)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.calendar_today_outlined, size: 14, color: AppColors.textMuted),
                  const SizedBox(width: 4),
                  Text('Entrou em ${_joinDateLabel(user.createdAt!)}',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                ],
              ),
          ],
        ),
        const SizedBox(height: 12),
        // `.profile-stats`: Seguindo → Seguidores → posts ativos, nessa
        // ordem exata.
        DefaultTextStyle.merge(
          style: const TextStyle(fontSize: 13.4),
          child: Row(
          children: [
            Text('${user.followingCount}', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(width: 4),
            Text('Seguindo', style: TextStyle(color: AppColors.textMuted)),
            const SizedBox(width: 14),
            Text('${user.followersCount}', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(width: 4),
            Text('Seguidores', style: TextStyle(color: AppColors.textMuted)),
            if (user.activePostsCount != null) ...[
              const SizedBox(width: 14),
              Text('${user.activePostsCount}', style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(width: 4),
              Text('posts ativos', style: TextStyle(color: AppColors.textMuted)),
            ],
          ],
        ),
        ),
      ],
    );
  }

  Widget _buildHeader(DriqyUser user) {
    // Tamanhos do breakpoint mobile do `style.css`
    // (`@media (max-width: 640px)`), já que o app sempre roda numa tela
    // de celular: avatar 66px sobrepondo a capa em -33px (metade do
    // próprio diâmetro).
    const avatarSize = 66.0;
    const sidePad = 18.0; // `.profile-header { padding: 0 18px 20px; }`
    // Altura aproximada da linha do avatar/ações que fica visível ABAIXO
    // da capa (o resto se sobrepõe pra dentro dela) — usada só pra
    // reservar espaço suficiente no Stack antes do bloco de identidade
    // começar, sem depender de medir o layout de verdade.
    const actionsRowHeight = 48.0;

    return LayoutBuilder(
      builder: (context, constraints) {
        // `.profile-cover { aspect-ratio: 3/1 }`: a altura real da capa
        // depende da largura da tela, calculada aqui em vez de um valor
        // fixo, pra bater exatamente com o site em qualquer aparelho.
        final coverHeight = constraints.maxWidth / 3;
        return Container(
          // Mesma distância (AppSpacing.gap) em cima, nos lados e embaixo —
          // igual à do composer e dos cards de post.
          margin: const EdgeInsets.all(AppSpacing.gap),
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            // Espelha a moldura contínua que `.profile-cover` (borda nos
            // lados+topo) e `.profile-header` (borda nos lados+base)
            // formam juntos no site — aqui é só uma borda única ao redor
            // de tudo, já que as duas metades se encontram sem emenda.
            border: Border.all(color: AppColors.border),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  SizedBox(height: coverHeight + actionsRowHeight),
                  Positioned(top: 0, left: 0, right: 0, height: coverHeight, child: _buildCoverImage(user)),
                  // `.profile-header-top`: avatar sobrepondo a capa em
                  // -33px (metade do diâmetro), ações à direita — aqui
                  // isso é um `Positioned` posicionado exatamente em
                  // `coverHeight - avatarSize/2`, o mesmo efeito do
                  // `margin-top` negativo do CSS, só que sem precisar de
                  // nenhum ajuste manual de espaço depois.
                  Positioned(
                    top: coverHeight - avatarSize / 2,
                    left: sidePad,
                    child: _buildAvatar(user, avatarSize),
                  ),
                  // Ações (Editar perfil / Seguir): no site o
                  // `.profile-header-actions` NÃO sobe junto com o avatar
                  // (só o avatar tem margin-top negativo), então ficam
                  // logo abaixo da capa, com 12px de respiro.
                  Positioned(
                    top: coverHeight,
                    right: sidePad,
                    child: _buildHeaderActions(user),
                  ),
                ],
              ),
              Padding(
                // `.profile-identity { margin-top: 12px; }` +
                // `.profile-header { padding: 0 18px 20px; }`: os 20px de
                // baixo mantêm a linha de Seguindo/Seguidores afastada da
                // borda do card, igual ao site.
                padding: const EdgeInsets.fromLTRB(sidePad, 12, sidePad, 20),
                child: _buildIdentity(user),
              ),
            ],
          ),
        );
      },
    );
  }
}
