import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../models/news_article.dart';
import '../services/auth_service.dart';
import '../services/news_service.dart';
import '../theme/app_colors.dart';
import '../widgets/scroll_to_top_button.dart';
import '../widgets/driqy_top_bar.dart';
import '../widgets/fade_in.dart';
import 'news_interests_screen.dart';

/// Aba "Notícias": mesma recomendação do site (`/noticias`), consumindo
/// `/api/v1/news`, apresentada em lista de cards 4:3 (imagem cheia com título
/// por cima). Celular: 1 coluna colada. Tela larga (web/desktop/tablet): 2 a 3
/// colunas, cada card do mesmo tamanho, com leitura da esquerda pra direita.
/// Notícia sem imagem (ou cuja imagem falha) vira um card colorido da
/// categoria em vez de sumir — a lista não encolhe.
class NewsScreen extends StatefulWidget {
  final VoidCallback? onOpenMenu;

  const NewsScreen({super.key, this.onOpenMenu});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  late NewsService _service;
  final List<NewsArticle> _articles = [];
  final ScrollController _scrollController = ScrollController();

  List<NewsCategory> _categories = [];
  String? _categoryFilter;
  int _offset = 0;
  bool _hasNext = true;
  bool _loadingFirstPage = true;
  bool _loadingMore = false;
  String? _error;

  /// Incrementa a cada novo carregamento de primeira página (troca de
  /// categoria, refresh). Respostas de pedidos antigos são descartadas —
  /// antes, tocar rápido em duas categorias (ou trocar de categoria durante
  /// o "carregar mais") misturava notícias de categorias diferentes na lista.
  int _requestGen = 0;

  @override
  void initState() {
    super.initState();
    _service = NewsService(context.read<AuthService>().client);
    _scrollController.addListener(_onScroll);
    _loadFirstPage();
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_hasNext || _loadingMore || !_scrollController.hasClients) return;
    final threshold = _scrollController.position.maxScrollExtent - 300;
    if (_scrollController.position.pixels >= threshold) {
      _loadMore();
    }
  }

  Future<void> _loadFirstPage() async {
    final gen = ++_requestGen;
    setState(() {
      _loadingFirstPage = true;
      _loadingMore = false;
      _error = null;
    });
    try {
      final result = await _service.getFeed(category: _categoryFilter);
      if (!mounted || gen != _requestGen) return;
      setState(() {
        _articles
          ..clear()
          ..addAll(result.articles);
        _offset = result.nextOffset;
        _hasNext = result.hasNext;
        _categories = result.categories;
      });
    } catch (_) {
      if (mounted && gen == _requestGen) {
        setState(() => _error = 'Não foi possível carregar as notícias.');
      }
    } finally {
      if (mounted && gen == _requestGen) {
        setState(() => _loadingFirstPage = false);
        WidgetsBinding.instance.addPostFrameCallback((_) => _fillViewport());
      }
    }
  }

  Future<void> _loadMore() async {
    final gen = _requestGen;
    setState(() => _loadingMore = true);
    try {
      final result = await _service.getFeed(
        category: _categoryFilter,
        offset: _offset,
        seenIds: _articles.map((a) => a.id).toList(),
      );
      if (!mounted || gen != _requestGen) return;
      setState(() {
        _articles.addAll(result.articles);
        _offset = result.nextOffset;
        _hasNext = result.hasNext;
      });
    } catch (_) {
      // silencioso: mantém o que já carregou, tenta de novo no próximo scroll
    } finally {
      if (mounted && gen == _requestGen) {
        setState(() => _loadingMore = false);
        WidgetsBinding.instance.addPostFrameCallback((_) => _fillViewport());
      }
    }
  }

  /// Em tela larga (3 colunas) a primeira página pode não encher a tela, e
  /// sem rolagem não há evento de scroll pra disparar o "carregar mais" —
  /// a lista ficava parada com "Nenhuma notícia a mais". Se ainda cabe na
  /// tela e tem mais, busca a próxima página.
  void _fillViewport() {
    if (!mounted || !_hasNext || _loadingMore || _loadingFirstPage) return;
    if (!_scrollController.hasClients) return;
    if (_scrollController.position.maxScrollExtent <= 0) {
      _loadMore();
    }
  }

  void _selectCategory(String? key) {
    if (key == _categoryFilter) return;
    setState(() => _categoryFilter = key);
    if (_scrollController.hasClients) _scrollController.jumpTo(0);
    _loadFirstPage();
  }

  Future<void> _openInterests() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NewsInterestsScreen()),
    );
    // interesses podem ter mudado a recomendação — recarrega o feed
    _loadFirstPage();
  }

  Future<void> _openArticle(NewsArticle article) async {
    // Registra o clique (mesmo sinal do site) antes de abrir; se o
    // registro falhar por qualquer motivo, ainda assim abre o link —
    // o usuário não deveria ficar sem ler a notícia por isso.
    String url = article.articleUrl;
    try {
      url = await _service.openArticle(article.id);
    } catch (_) {
      // segue com article.articleUrl
    }
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível abrir a notícia.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: ScrollToTopButton(controller: _scrollController),
      appBar: DriqyTopBar(onOpenMenu: widget.onOpenMenu),
      body: Column(
        children: [
          _buildHeader(),
          _buildFilters(),
          Divider(height: 1, color: AppColors.border),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 8, 10),
      child: Row(
        children: [
          Text(
            'Notícias',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.text),
          ),
          const Spacer(),
          TextButton.icon(
            onPressed: _openInterests,
            icon: Icon(Icons.tune, size: 18, color: AppColors.amber),
            label: Text('Meus interesses', style: TextStyle(color: AppColors.amber)),
          ),
        ],
      ),
    );
  }

  Widget _buildFilters() {
    if (_loadingFirstPage && _categories.isEmpty) {
      return const SizedBox(height: 44);
    }
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          _FilterChip(
            label: 'Para você',
            selected: _categoryFilter == null,
            onTap: () => _selectCategory(null),
          ),
          for (final category in _categories)
            _FilterChip(
              label: category.label,
              selected: _categoryFilter == category.key,
              onTap: () => _selectCategory(category.key),
            ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loadingFirstPage) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null && _articles.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!, style: TextStyle(color: AppColors.textMuted)),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _loadFirstPage, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    if (_articles.isEmpty) {
      return Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Nenhuma notícia por aqui ainda. O indexador roda periodicamente — volte daqui a pouco.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textMuted),
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadFirstPage,
      child: ListView(
        controller: _scrollController,
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          ..._buildList(MediaQuery.of(context).size.width),
          if (_hasNext)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Center(
                child: SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// 1 coluna no celular; 2 em tablet; 3 em tela larga (desktop/web). Cada
  /// linha tem o mesmo número de cards do mesmo tamanho, então a ordem de
  /// leitura é esquerda -> direita, cima -> baixo.
  List<Widget> _buildList(double width) {
    final columns = width >= 1100 ? 3 : (width >= 700 ? 2 : 1);

    if (columns == 1) {
      return [
        for (final article in _articles)
          _NewsTile(
            key: ValueKey('news-${article.id}'),
            article: article,
            onTap: () => _openArticle(article),
          ),
      ];
    }

    const gap = 18.0;
    final rows = <Widget>[];
    for (var i = 0; i < _articles.length; i += columns) {
      final chunk = _articles.skip(i).take(columns).toList();
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: gap),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (var c = 0; c < columns; c++) ...[
                if (c > 0) const SizedBox(width: gap),
                Expanded(
                  child: c < chunk.length
                      ? _NewsTile(
                          key: ValueKey('news-${chunk[c].id}'),
                          article: chunk[c],
                          rounded: true,
                          showSummary: true,
                          onTap: () => _openArticle(chunk[c]),
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ],
          ),
        ),
      );
    }
    return [
      Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1320),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(children: rows),
          ),
        ),
      ),
    ];
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
        showCheckmark: false,
        labelStyle: TextStyle(
          color: selected ? AppColors.onBrand : AppColors.textMuted,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          fontSize: 13,
        ),
        backgroundColor: AppColors.surface2,
        selectedColor: AppColors.amber,
        side: BorderSide(color: selected ? Colors.transparent : AppColors.border),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      ),
    );
  }
}

/// Card da lista de notícias — espelha `.news-tile` do CSS do site: proporção
/// 4:3, imagem cobrindo o card e por cima um bloco inferior com gradiente
/// escuro (selo de categoria, título, resumo opcional e a linha
/// fonte · tempo com favicon). Sem imagem, ou se ela falhar ao carregar,
/// vira um card de cor sólida da categoria (nunca some da lista).
class _NewsTile extends StatefulWidget {
  final NewsArticle article;
  final VoidCallback onTap;
  final bool rounded;
  final bool showSummary;

  const _NewsTile({
    super.key,
    required this.article,
    required this.onTap,
    this.rounded = false,
    this.showSummary = false,
  });

  @override
  State<_NewsTile> createState() => _NewsTileState();
}

class _NewsTileState extends State<_NewsTile> {
  bool _imageFailed = false;

  void _markFailed() {
    if (_imageFailed) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) setState(() => _imageFailed = true);
    });
  }

  static const _shadows = [
    Shadow(color: Color(0xD9000000), blurRadius: 3, offset: Offset(0, 1)),
    Shadow(color: Color(0x99000000), blurRadius: 14, offset: Offset(0, 2)),
  ];

  /// O servidor entrega a capa em 480/800/1200px (`?w=`). Pede a menor que
  /// ainda fica nítida na largura real do card x densidade de pixels da
  /// tela — nem baixa foto gigante no celular, nem estica miniatura.
  static String _sizedImageUrl(String raw, double logicalWidth, double dpr) {
    final px = logicalWidth * dpr;
    final w = px <= 480 ? 480 : (px <= 800 ? 800 : 1200);
    final uri = Uri.parse(resolveMediaUrl(raw));
    return uri.replace(queryParameters: {...uri.queryParameters, 'w': '$w'}).toString();
  }

  Widget _fallbackBackground(Color color) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [color, Color.lerp(color, const Color(0xFF100C18), 0.55)!],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final article = widget.article;
    final hasImage =
        !_imageFailed && article.imageUrl != null && article.imageUrl!.isNotEmpty;
    final dpr = MediaQuery.of(context).devicePixelRatio;

    final card = AspectRatio(
      aspectRatio: 4 / 3,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final logicalWidth = constraints.maxWidth.isFinite ? constraints.maxWidth : 400.0;
          return Stack(
            fit: StackFit.expand,
            children: [
              Container(color: AppColors.surface),
              if (hasImage)
                Image.network(
                  _sizedImageUrl(article.imageUrl!, logicalWidth, dpr),
                  fit: BoxFit.cover,
                  alignment: const Alignment(0, -0.3),
                  filterQuality: FilterQuality.high,
                  gaplessPlayback: true,
                  cacheWidth: (logicalWidth * dpr).round(),
                  errorBuilder: (_, __, ___) {
                    _markFailed();
                    return _fallbackBackground(article.categoryColor);
                  },
                )
              else
                _fallbackBackground(article.categoryColor),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: _buildOverlay(article),
              ),
            ],
          );
        },
      ),
    );

    return FadeSlideIn(
      child: GestureDetector(
        onTap: widget.onTap,
        child: widget.rounded
            ? ClipRRect(borderRadius: BorderRadius.circular(14), child: card)
            : card,
      ),
    );
  }

  Widget _buildOverlay(NewsArticle article) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 34, 14, 12),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Color(0xEB000000), Color(0xB3000000), Color(0x00000000)],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.25),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              article.categoryLabel.toUpperCase(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            article.title,
            maxLines: widget.showSummary ? 3 : 2,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.fraunces(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: widget.showSummary ? 18 : 16.3,
              height: 1.28,
              shadows: _shadows,
            ),
          ),
          if (widget.showSummary && article.summary.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              article.summary,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.82),
                fontSize: 13.5,
                shadows: _shadows,
              ),
            ),
          ],
          const SizedBox(height: 6),
          Row(
            children: [
              if (article.faviconUrl != null) ...[
                Container(
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(3),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.network(
                    article.faviconUrl!,
                    width: 18,
                    height: 18,
                    errorBuilder: (_, __, ___) => const SizedBox(width: 18, height: 18),
                  ),
                ),
                const SizedBox(width: 7),
              ],
              Flexible(
                child: Text(
                  article.sourceName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 12.5,
                    shadows: _shadows,
                  ),
                ),
              ),
              if (article.timeAgo.isNotEmpty) ...[
                const SizedBox(width: 7),
                Text('·',
                    style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.7), fontSize: 12.5)),
                const SizedBox(width: 7),
                Text(
                  article.timeAgo,
                  maxLines: 1,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.85),
                    fontSize: 12.5,
                    shadows: _shadows,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
