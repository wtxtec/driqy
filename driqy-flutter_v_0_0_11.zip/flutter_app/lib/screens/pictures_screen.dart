import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import '../config.dart';
import '../models/picture_tile.dart';
import '../services/auth_service.dart';
import '../services/pictures_service.dart';
import '../theme/vortex_theme.dart';
import '../widgets/scroll_to_top_button.dart';
import '../widgets/countdown_ring.dart';
import '../widgets/driqy_image.dart';
import '../widgets/driqy_top_bar.dart';
import '../widgets/vortex_tile_actions.dart';
import '../widgets/vortex_tile_card.dart';
import 'post_detail_screen.dart';
import 'profile_screen.dart';
import 'vortex_detail_screen.dart';
import 'vortex_search_screen.dart';

/// Vortex: grade estilo Pinterest com fotos/GIFs/vídeos indexados da internet
/// (crawler) E posts de usuários ainda ativos, ordenados pelo GOSTO de quem
/// vê (`GET /vortex`), com rolagem infinita por cursor opaco, busca, filtros
/// por tipo/categoria, contador e a faixa "Vistos recentemente".
///
/// Segue o tema escolhido (claro/escuro) só dentro do Vortex: o corpo fica
/// dentro de um [VortexThemeScope]. Segurar uma peça abre Curtir / Menos disso.
class PicturesScreen extends StatelessWidget {
  final VoidCallback? onOpenMenu;

  const PicturesScreen({super.key, this.onOpenMenu});

  @override
  Widget build(BuildContext context) {
    return VortexThemeScope(child: _PicturesBody(onOpenMenu: onOpenMenu));
  }
}

class _PicturesBody extends StatefulWidget {
  final VoidCallback? onOpenMenu;

  const _PicturesBody({this.onOpenMenu});

  @override
  State<_PicturesBody> createState() => _PicturesScreenState();
}

class _PicturesScreenState extends State<_PicturesBody> {
  // Curtidas / escondidas ("menos disso") nesta sessão da tela.
  final VortexTileReactions _reactions = VortexTileReactions();

  late PicturesService _service;
  final List<PictureTile> _tiles = [];
  final ScrollController _scrollController = ScrollController();

  // Chave da peça de vídeo que deve estar tocando agora (só uma por vez,
  // igual ao `vortex.js`) e as `GlobalKey`s usadas pra medir a posição
  // real de cada peça na tela (sem precisar do pacote
  // `visibility_detector` — ver comentário em `_updatePlayingVideo`).
  final ValueNotifier<String?> _playingVideoKey = ValueNotifier<String?>(null);
  final Map<String, GlobalKey> _tileKeys = {};

  // Cursor OPACO do servidor: sempre reenviado exatamente como veio.
  String? _cursor;
  final Set<String> _tileKeysSeen = {};
  bool _hasNext = true;
  String? _type; // null = tudo | photo | gif | video
  String? _category; // slug ou null
  VortexStats? _stats;
  List<VortexCategory> _categories = [];
  List<PictureTile> _recent = [];
  bool _loadingFirstPage = true;
  bool _loadingMore = false;
  String? _error;

  GlobalKey _keyFor(String tileKey) => _tileKeys.putIfAbsent(tileKey, () => GlobalKey());

  // "O que eu já vi não volta": peça >= 50 % visível por 700 ms vira "vista" e é
  // enviada em lote ao servidor (`POST /vortex/seen`, livro de vistos).
  static const _viewMinFraction = 0.5;
  static const _viewMinDuration = Duration(milliseconds: 700);
  final Map<String, DateTime> _visibleSince = {};
  final Set<String> _viewReported = {};
  final Set<String> _viewPending = {};
  Timer? _viewTimer;
  DateTime _lastViewFlush = DateTime.now();

  /// Chave da peça no livro de vistos do servidor ('c<id>' / 'p<id>').
  String? _ledgerKey(PictureTile t) {
    if (t.isCrawler) return t.itemId != null ? 'c${t.itemId}' : null;
    return t.postId != null ? 'p${t.postId}' : null;
  }

  /// Fração (0..1) da peça visível na tela, ou null se não está montada.
  double? _visibleFraction(GlobalKey? key) {
    final renderObject = key?.currentContext?.findRenderObject();
    if (renderObject is! RenderBox || !renderObject.attached || !renderObject.hasSize) return null;
    final height = renderObject.size.height;
    if (height <= 0) return null;
    final media = MediaQuery.of(context);
    final topBound = media.padding.top + kToolbarHeight;
    final top = renderObject.localToGlobal(Offset.zero).dy;
    final bottom = top + height;
    final visibleTop = top < topBound ? topBound : top;
    final visibleBottom = bottom > media.size.height ? media.size.height : bottom;
    final visible = visibleBottom - visibleTop;
    return visible <= 0 ? 0.0 : visible / height;
  }

  void _trackViews() {
    if (!mounted) return;
    // aba escondida (IndexedStack) ou outra tela por cima: nada está sendo visto
    if (!TickerMode.of(context)) return;
    final route = ModalRoute.of(context);
    if (route != null && !route.isCurrent) return;
    final now = DateTime.now();
    for (final tile in _tiles) {
      final lk = _ledgerKey(tile);
      if (lk == null || _viewReported.contains(lk)) continue;
      final fraction = _visibleFraction(_tileKeys[tile.key]);
      if (fraction == null || fraction < _viewMinFraction) {
        _visibleSince.remove(lk);
        continue;
      }
      final since = _visibleSince.putIfAbsent(lk, () => now);
      if (now.difference(since) >= _viewMinDuration) {
        _viewReported.add(lk);
        _visibleSince.remove(lk);
        _viewPending.add(lk);
      }
    }
    if (_viewPending.isNotEmpty &&
        (_viewPending.length >= 8 || now.difference(_lastViewFlush).inSeconds >= 4)) {
      _flushViews();
    }
  }

  void _flushViews() {
    _lastViewFlush = DateTime.now();
    if (_viewPending.isEmpty) return;
    final keys = _viewPending.take(200).toList();
    _viewPending.removeAll(keys);
    _service.markViewed(keys); // fire-and-forget
  }

  @override
  void initState() {
    super.initState();
    _service = PicturesService(context.read<AuthService>().client);
    _scrollController.addListener(_onScroll);
    _viewTimer = Timer.periodic(const Duration(milliseconds: 400), (_) => _trackViews());
    _loadFirstPage();
  }

  @override
  void dispose() {
    _viewTimer?.cancel();
    _flushViews();
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _playingVideoKey.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_hasNext && !_loadingMore) {
      final threshold = _scrollController.position.maxScrollExtent - 300;
      if (_scrollController.position.pixels >= threshold) {
        _loadMore();
      }
    }
    _updatePlayingVideo();
  }

  /// Decide qual vídeo (se algum) deve tocar sozinho agora — mesma ideia
  /// do `playObserver` de `vortex.js` (toca mudo o primeiro vídeo que
  /// fica ~60% visível, só 1 por vez), só que sem o pacote
  /// `visibility_detector`: em vez de um observador de visibilidade de
  /// verdade, mede a posição de cada peça de vídeo montada com
  /// `RenderBox.localToGlobal` (usando a `GlobalKey` de cada uma) e
  /// compara com a altura da tela, chamado a cada tique de rolagem.
  void _updatePlayingVideo() {
    if (!mounted) return;
    final screenHeight = MediaQuery.of(context).size.height;
    // Evita contar como "visível" uma peça escondida atrás da AppBar.
    final topBound = MediaQuery.of(context).padding.top + kToolbarHeight;
    String? bestKey;
    double bestFraction = 0;
    for (final tile in _tiles) {
      if (tile.mediaType != 'video' || tile.isCrawler) continue;
      final key = _tileKeys[tile.key];
      final renderObject = key?.currentContext?.findRenderObject();
      if (renderObject is! RenderBox || !renderObject.attached || !renderObject.hasSize) continue;
      final topLeft = renderObject.localToGlobal(Offset.zero);
      final height = renderObject.size.height;
      if (height <= 0) continue;
      final top = topLeft.dy;
      final bottom = top + height;
      final visibleTop = top < topBound ? topBound : top;
      final visibleBottom = bottom > screenHeight ? screenHeight : bottom;
      final visibleHeight = visibleBottom - visibleTop;
      final fraction = visibleHeight <= 0 ? 0.0 : visibleHeight / height;
      if (fraction >= 0.6 && fraction > bestFraction) {
        bestFraction = fraction;
        bestKey = tile.key;
      }
    }
    if (_playingVideoKey.value != bestKey) {
      _playingVideoKey.value = bestKey;
    }
  }

  Future<void> _loadFirstPage() async {
    _flushViews(); // o que ela viu antes de atualizar não pode voltar na grade nova
    setState(() {
      _loadingFirstPage = true;
      _error = null;
    });
    try {
      final result = await _service.getVortex(category: _category, type: _type);
      setState(() {
        _tiles.clear();
        _tileKeysSeen.clear();
        _addTiles(result);
      });
    } catch (_) {
      setState(() => _error = 'Não foi possível carregar o Vortex.');
    } finally {
      if (mounted) setState(() => _loadingFirstPage = false);
      WidgetsBinding.instance.addPostFrameCallback((_) => _updatePlayingVideo());
    }
    _loadExtras();
  }

  /// Contador, categorias e "vistos recentemente": enfeites. Se falharem, a
  /// grade continua funcionando sem eles.
  Future<void> _loadExtras() async {
    try {
      final stats = await _service.getStats();
      if (mounted) setState(() => _stats = stats);
    } catch (_) {}
    if (_categories.isEmpty) {
      try {
        final cats = await _service.getCategories();
        if (mounted) setState(() => _categories = cats);
      } catch (_) {}
    }
    await _loadRecent();
  }

  Future<void> _loadRecent() async {
    try {
      final recent = await _service.getRecent();
      if (mounted) setState(() => _recent = recent);
    } catch (_) {}
  }

  /// Junta uma página ignorando peças que já estão na tela: o servidor pode
  /// reordenar entre duas páginas se chegou conteúdo novo ou sinal de gosto.
  void _addTiles(PicturesPage page) {
    for (final t in page.tiles) {
      if (_tileKeysSeen.add(t.key)) _tiles.add(t);
    }
    _cursor = page.nextCursor;
    _hasNext = page.hasNext;
    _maybeShowBreakNotice(page);
  }

  /// Aviso de pausa: só reaparece quando o nível sobe (a cada 30 min contínuos).
  int _breakShownLevel = 0;
  void _maybeShowBreakNotice(PicturesPage page) {
    if (page.breakLevel <= _breakShownLevel || !mounted) return;
    _breakShownLevel = page.breakLevel;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Você está no Vortex há ${page.breakMinutes} minutos seguidos. '
            'Que tal uma pausa rápida?'),
        duration: const Duration(seconds: 8),
        action: SnackBarAction(label: 'OK', onPressed: () {}),
      ));
    });
  }

  Future<void> _loadMore() async {
    setState(() => _loadingMore = true);
    try {
      final result = await _service.getVortex(cursor: _cursor, category: _category, type: _type);
      setState(() => _addTiles(result));
    } catch (_) {
      // silencioso: mantém o que já carregou, tenta de novo no próximo scroll
    } finally {
      if (mounted) setState(() => _loadingMore = false);
      WidgetsBinding.instance.addPostFrameCallback((_) => _updatePlayingVideo());
    }
  }

  void _setFilters({String? type, String? category, bool clearType = false, bool clearCategory = false}) {
    final newType = clearType ? null : (type ?? _type);
    final newCategory = clearCategory ? null : (category ?? _category);
    if (newType == _type && newCategory == _category) return;
    _type = newType;
    _category = newCategory;
    if (_scrollController.hasClients) _scrollController.jumpTo(0);
    _loadFirstPage();
  }

  /// Abre a peça certa: item do crawler → detalhe do Vortex (que já conta como
  /// clique no servidor); post de usuário → o post, avisando o servidor. Ao
  /// voltar, atualiza a faixa de vistos recentemente.
  Future<void> _openTile(PictureTile tile) async {
    final Widget screen;
    if (tile.isCrawler && tile.itemId != null) {
      screen = VortexDetailScreen(itemId: tile.itemId!, initialTile: tile);
    } else if (tile.postId != null) {
      // o clique é o principal sinal de gosto do Vortex (não espera a resposta)
      _service.trackInteraction(postId: tile.postId);
      screen = PostDetailScreen(postId: tile.postId!);
    } else {
      return;
    }
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    if (mounted) _loadRecent();
  }

  /// Segurar a peça: Abrir / Curtir / Menos disso. "Menos disso" tira a peça
  /// da grade na hora (sem mexer nas colunas das outras) e o servidor nunca
  /// mais a devolve.
  Future<void> _onTileLongPress(PictureTile tile) {
    return reactToTile(
      context: context,
      service: _service,
      tile: tile,
      reactions: _reactions,
      onOpen: () => _openTile(tile),
      onChanged: () {
        if (!mounted) return;
        setState(() {});
        WidgetsBinding.instance.addPostFrameCallback((_) => _updatePlayingVideo());
      },
    );
  }

  void _openSearch() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VortexSearchScreen()));
  }

  void _openProfile(String username) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProfileScreen(username: username)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: ScrollToTopButton(controller: _scrollController),
      backgroundColor: VortexColors.of(context).bg, // segue o tema (escuro = preto, claro = claro)
      // Mesma topbar de sempre — `pictures.html` também só estende
      // `base.html` sem título de página próprio, então não tem nada
      // além da barra de sempre + a grade.
      appBar: DriqyTopBar(onOpenMenu: widget.onOpenMenu),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loadingFirstPage) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null && _tiles.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _loadFirstPage, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    if (_tiles.isEmpty) {
      return RefreshIndicator(
        onRefresh: _loadFirstPage,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            _buildHeader(),
            const Padding(
              padding: EdgeInsets.all(32),
              child: Center(child: Text('Nada por aqui com esses filtros ainda.')),
            ),
          ],
        ),
      );
    }

    // Mesma distribuição round-robin do `vortex.js` (peça N vai sempre pra
    // coluna N % nº-de-colunas): 2 colunas no celular, igual ao site. Como
    // é recalculado a cada build a partir da ordem de `_tiles` (que só
    // cresce no fim, nunca é embaralhada), peças que já apareceram nunca
    // trocam de coluna quando a rolagem infinita acrescenta mais — mesma
    // garantia do comentário original em vortex.js.
    const columnCount = 2;
    final columns = List.generate(columnCount, (_) => <PictureTile>[]);
    for (var i = 0; i < _tiles.length; i++) {
      columns[i % columnCount].add(_tiles[i]);
    }

    return RefreshIndicator(
      onRefresh: _loadFirstPage,
      child: SingleChildScrollView(
        controller: _scrollController,
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          children: [
            _buildHeader(),
            // `.pictures-grid`: display:flex, gap:0 — sem espaçamento
            // nenhum entre colunas nem entre peças.
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final col in columns)
                  Expanded(
                    child: Column(
                      children: col.map(_buildTile).toList(),
                    ),
                  ),
              ],
            ),
            ),
            if (_hasNext)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(
                  child: SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Center(
                  child: Text('Você chegou ao fim.', style: TextStyle(color: VortexColors.of(context).textMuted)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildTile(PictureTile tile) {
    // "Menos disso": some da grade, mas continua na lista (as outras peças não
    // trocam de coluna). O servidor também não a devolve mais.
    if (_reactions.hidden.contains(tile.key)) return const SizedBox.shrink();
    final liked = _reactions.liked.contains(tile.key);

    if (tile.isCrawler) {
      return KeyedSubtree(
        key: _keyFor(tile.key), // também serve de medidor de visibilidade (_trackViews)
        child: VortexTileCard(
          key: ValueKey(tile.key),
          tile: tile,
          liked: liked,
          onTap: () => _openTile(tile),
          onLongPress: () => _onTileLongPress(tile),
        ),
      );
    }
    return _VortexTile(
      key: _keyFor(tile.key),
      tile: tile,
      liked: liked,
      playingVideoKey: _playingVideoKey,
      onTap: () => _openTile(tile),
      onLongPress: () => _onTileLongPress(tile),
      onAuthorTap: () {
        final username = tile.author?.username;
        if (username != null) _openProfile(username);
      },
    );
  }

  Widget _buildHeader() {
    final stats = _stats;
    final theme = Theme.of(context);
    final colors = VortexColors.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 4, 4),
          child: Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: _openSearch,
                  borderRadius: BorderRadius.circular(24),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: colors.searchBg,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: colors.border),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.search, size: 18, color: colors.textMuted),
                        const SizedBox(width: 8),
                        Text('Buscar no Vortex', style: TextStyle(color: colors.textMuted)),
                      ],
                    ),
                  ),
                ),
              ),
              // sol/lua: troca o tema do Vortex (fica salvo no aparelho)
              const VortexThemeButton(),
            ],
          ),
        ),
        if (stats != null && stats.total > 0)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: Text(
              '${stats.photos} imagens • ${stats.gifs} GIFs • ${stats.videos} vídeos',
              style: theme.textTheme.bodySmall?.copyWith(color: colors.textMuted),
            ),
          ),
        SizedBox(
          height: 46,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            children: [
              for (final entry in const [
                [null, 'Tudo'],
                ['photo', 'Fotos'],
                ['gif', 'GIFs'],
                ['video', 'Vídeos'],
              ])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(entry[1]!),
                    selected: _type == entry[0],
                    onSelected: (_) => entry[0] == null
                        ? _setFilters(clearType: true)
                        : _setFilters(type: entry[0]),
                  ),
                ),
            ],
          ),
        ),
        if (_categories.isNotEmpty)
          SizedBox(
            height: 42,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: const Text('Todas as categorias'),
                    selected: _category == null,
                    onSelected: (_) => _setFilters(clearCategory: true),
                  ),
                ),
                for (final c in _categories)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text('${c.label} (${c.count})'),
                      selected: _category == c.slug,
                      onSelected: (_) => _setFilters(category: c.slug),
                    ),
                  ),
              ],
            ),
          ),
        if (_recent.isNotEmpty && _category == null && _type == null) _buildRecentStrip(),
      ],
    );
  }

  /// "Vistos recentemente": o que a pessoa abriu há pouco, a mais nova primeiro.
  Widget _buildRecentStrip() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 8, 16, 6),
          child: Text('Vistos recentemente', style: TextStyle(fontWeight: FontWeight.w600)),
        ),
        SizedBox(
          height: 96,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: _recent.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, i) {
              final t = _recent[i];
              return GestureDetector(
                onTap: () => _openTile(t),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: SizedBox(
                    width: 96,
                    height: 96,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Container(color: VortexColors.of(context).tileBg),
                        DriqyImage(url: t.gridUrl, mediaType: t.mediaType, fit: BoxFit.cover),
                        if (t.mediaType == 'video')
                          const Center(child: Icon(Icons.play_arrow, color: Colors.white, size: 24)),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
      ],
    );
  }
}

/// Uma peça da grade: mede a proporção real da imagem (`naturalWidth`/
/// `naturalHeight`, via `ImageStreamListener`, equivalente ao evento
/// `load` que `media-orient.js`/CSS usam no site) e usa exatamente essa
/// proporção na caixa — sem cortar nada (`BoxFit.cover` dentro de uma
/// `AspectRatio` que já é a proporção nativa não corta porque as duas
/// batem exatamente), igual ao `.picture-tile-img { height: auto }` do
/// `style.css`. Vídeo usa o mesmo `VideoPlayerController` do
/// `PostVideoPlayer` (proporção real do arquivo, primeiro frame como
/// miniatura, mudo) e toca sozinho quando é a peça escolhida por
/// `playingVideoKey` (calculado em `_PicturesScreenState._updatePlayingVideo`,
/// olhando qual vídeo montado está mais visível na tela) — o mesmo
/// comportamento do `playObserver` de `vortex.js`, só um vídeo tocando
/// por vez. Também dá pra tocar/pausar manualmente tocando na peça.
class _VortexTile extends StatefulWidget {
  final PictureTile tile;
  final ValueNotifier<String?> playingVideoKey;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final VoidCallback onAuthorTap;
  final bool liked;

  const _VortexTile({
    super.key,
    required this.tile,
    required this.playingVideoKey,
    required this.onTap,
    required this.onAuthorTap,
    this.onLongPress,
    this.liked = false,
  });

  @override
  State<_VortexTile> createState() => _VortexTileState();
}

class _VortexTileState extends State<_VortexTile> {
  double? _aspectRatio;
  VideoPlayerController? _videoController;
  bool _videoFailed = false;

  @override
  void initState() {
    super.initState();
    if (widget.tile.mediaType == 'video') {
      widget.playingVideoKey.addListener(_syncAutoplay);
      _initVideo();
    } else {
      _measureImage();
    }
  }

  /// Toca ou pausa este vídeo dependendo se `playingVideoKey` (calculado
  /// pela tela a partir da posição de cada peça na rolagem) escolheu
  /// esta peça como a que deve tocar agora.
  void _syncAutoplay() {
    final controller = _videoController;
    if (controller == null || !mounted) return;
    final shouldPlay = widget.playingVideoKey.value == widget.tile.key;
    if (shouldPlay && !controller.value.isPlaying) {
      controller.play();
      setState(() {});
    } else if (!shouldPlay && controller.value.isPlaying) {
      controller.pause();
      setState(() {});
    }
  }

  Future<void> _measureImage() async {
    final size = await resolveImageSize(widget.tile.mediaUrl, mediaType: widget.tile.mediaType);
    if (mounted && size != null && size.height > 0) {
      setState(() => _aspectRatio = size.width / size.height);
    }
  }

  Future<void> _initVideo() async {
    final controller = VideoPlayerController.networkUrl(
      Uri.parse(resolveMediaUrl(widget.tile.mediaUrl)),
    );
    try {
      await controller.initialize();
      controller.setLooping(true);
      controller.setVolume(0);
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() => _videoController = controller);
      // A peça pode já ser a escolhida pra tocar (calculado antes do
      // vídeo terminar de carregar) — confere assim que fica pronta.
      _syncAutoplay();
    } catch (_) {
      controller.dispose();
      if (mounted) setState(() => _videoFailed = true);
    }
  }

  @override
  void dispose() {
    if (widget.tile.mediaType == 'video') {
      widget.playingVideoKey.removeListener(_syncAutoplay);
    }
    _videoController?.dispose();
    super.dispose();
  }

  void _toggleVideoPlay() {
    final controller = _videoController;
    if (controller == null) return;
    setState(() {
      if (controller.value.isPlaying) {
        controller.pause();
      } else {
        controller.play();
      }
    });
  }

  Widget _buildVideoContent() {
    if (_videoFailed) {
      return Center(child: Icon(Icons.broken_image_outlined, color: VortexColors.of(context).textMuted));
    }
    final controller = _videoController;
    if (controller == null) {
      return Center(
        child: SizedBox(
          height: 18,
          width: 18,
          child: CircularProgressIndicator(strokeWidth: 2, color: VortexColors.of(context).textMuted),
        ),
      );
    }
    return VideoPlayer(controller);
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = widget.tile.mediaType == 'video';
    final videoReady = isVideo && _videoController != null;
    // Enquanto a medição/inicialização não termina, usa uma caixa 4:5
    // provisória — mesma ideia do CSS antes do JS classificar (já nasce
    // com uma proporção razoável em vez de ficar com altura zero).
    final ratio = pinRatio(videoReady
        ? (_videoController!.value.aspectRatio == 0 ? 4 / 5 : _videoController!.value.aspectRatio)
        : (_aspectRatio ?? (4 / 5)));

    return PinFrame(
      onTap: widget.onTap,
      onLongPress: widget.onLongPress,
      aspectRatio: ratio,
      child: Stack(
          fit: StackFit.expand,
          children: [
            Container(color: VortexColors.of(context).tileBg),
            if (isVideo)
              _buildVideoContent()
            else
              DriqyImage(
                url: widget.tile.mediaUrl,
                mediaType: widget.tile.mediaType,
                fit: BoxFit.cover,
              ),
            if (widget.liked)
              const Positioned(left: 6, top: 6, child: IgnorePointer(child: VortexLikedBadge())),
            if (isVideo && videoReady)
              // Botão próprio de tocar/pausar, separado do toque no resto
              // da peça (que abre o post) — evita ficar competindo com o
              // gesto de abrir o post numa mesma área de toque.
              Center(
                child: GestureDetector(
                  onTap: _toggleVideoPlay,
                  child: AnimatedOpacity(
                    opacity: _videoController!.value.isPlaying ? 0 : 1,
                    duration: const Duration(milliseconds: 200),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: Colors.black38,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.play_arrow, size: 26, color: Colors.white),
                    ),
                  ),
                ),
              ),
            // Anel de contagem regressiva no canto (`.countdown-ring-wrap.picture-ring`
            // do site): fundo preto translúcido + o mesmo `CountdownRing`
            // ao vivo usado no card do feed, só que menor.
            if (widget.tile.expiresAt != null)
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.45),
                    shape: BoxShape.circle,
                  ),
                  child: CountdownRing(
                    createdAt: widget.tile.createdAt,
                    expiresAt: widget.tile.expiresAt!,
                    size: 28,
                  ),
                ),
              ),
            Positioned(
              left: 6,
              bottom: 6,
              right: 6,
              child: GestureDetector(
                onTap: widget.onAuthorTap,
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 9,
                      backgroundImage: widget.tile.author!.avatarUrl != null
                          ? NetworkImage(resolveMediaUrl(widget.tile.author!.avatarUrl!))
                          : null,
                      child: widget.tile.author!.avatarUrl == null
                          ? Text(widget.tile.author!.displayName[0].toUpperCase(),
                              style: const TextStyle(fontSize: 9))
                          : null,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        '@${widget.tile.author!.username}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          shadows: [Shadow(blurRadius: 4, color: Colors.black)],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
      ),
    );
  }
}
