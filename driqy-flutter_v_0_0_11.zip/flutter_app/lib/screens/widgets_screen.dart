import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/auth_service.dart';
import '../services/news_service.dart';
import '../services/rail_prefs_controller.dart';
import '../services/user_service.dart';
import '../services/widgets_service.dart';
import '../theme/app_colors.dart';
import '../widgets/rail/driqy_rail.dart';
import '../widgets/rail/rail_panel.dart';
import '../widgets/rail/rail_suggestions.dart';

/// Painel de widgets em tela própria. No celular (e em janelas estreitas) a coluna da direita não
/// cabe, então Clima, Lua, Estações etc. ficam aqui, abertos pelo item "Widgets" do menu.
class WidgetsScreen extends StatelessWidget {
  final RailPrefsController prefs;
  final VoidCallback? onOpenVortex;

  const WidgetsScreen({super.key, required this.prefs, this.onOpenVortex});

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthService>();
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Widgets')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: prefs,
          builder: (context, _) {
            if (!prefs.loaded) return const Center(child: CircularProgressIndicator());
            return SingleChildScrollView(
              key: const Key('widgets-screen-scroll'),
              padding: const EdgeInsets.all(12),
              child: RailPanel(
                // sem `railHidden`: quem escondeu o painel largo ainda pode abrir esta tela
                prefs: prefs.prefs,
                onSavePrefs: prefs.save,
                specs: [
                  ...buildRailSpecs(auth, onOpenVortex: onOpenVortex),
                  ...buildCustomSpecs(WidgetsService(auth.client), prefs.customs, onRenamed: prefs.renameCustomLocally),
                ],
                customKinds: prefs.customKinds,
                customMax: prefs.customMax,
                onCreateCustom: prefs.createCustom,
                onDeleteCustom: prefs.deleteCustom,
                loadAvailableIds: () => WidgetsService(auth.client).getWidgetIds(),
                suggestions: RailSuggestions(
                  service: WidgetsService(auth.client),
                  users: UserService(auth.client),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
