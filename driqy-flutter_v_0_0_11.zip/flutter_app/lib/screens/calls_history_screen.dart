import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/call.dart';
import '../services/auth_service.dart';
import '../services/call_manager.dart';
import '../services/call_service.dart';
import '../theme/app_colors.dart';
import '../widgets/chat/chat_format.dart';
import 'message_thread_screen.dart';

/// Fase 14: histórico de chamadas (`GET /calls`), com "ligar de volta".
class CallsHistoryScreen extends StatefulWidget {
  const CallsHistoryScreen({super.key});

  @override
  State<CallsHistoryScreen> createState() => _CallsHistoryScreenState();
}

class _CallsHistoryScreenState extends State<CallsHistoryScreen> {
  late final CallService _service;
  final List<DriqyCall> _calls = [];
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _service = CallService(context.read<AuthService>().client);
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final page = await _service.history(limit: 30);
      if (!mounted) return;
      setState(() {
        _calls
          ..clear()
          ..addAll(page);
        _hasMore = page.length >= 30;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Não foi possível carregar as chamadas.';
        _loading = false;
      });
    }
  }

  Future<void> _more() async {
    if (_loadingMore || _calls.isEmpty) return;
    setState(() => _loadingMore = true);
    try {
      final page = await _service.history(limit: 30, beforeId: _calls.last.id);
      if (!mounted) return;
      setState(() {
        _calls.addAll(page);
        _hasMore = page.length >= 30;
      });
    } catch (_) {
      // mantém a lista; o usuário pode tentar de novo
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  String _when(DateTime? utc) {
    if (utc == null) return '';
    final d = utc.toLocal();
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final hm = '${two(d.hour)}:${two(d.minute)}';
    final sameDay = d.year == now.year && d.month == now.month && d.day == now.day;
    final y = now.subtract(const Duration(days: 1));
    final yesterday = d.year == y.year && d.month == y.month && d.day == y.day;
    if (sameDay) return 'Hoje, $hm';
    if (yesterday) return 'Ontem, $hm';
    return '${two(d.day)}/${two(d.month)}/${d.year}, $hm';
  }

  /// (texto, é "ruim" = perdida/ocupado/falhou para quem recebeu)
  (String, bool) _status(DriqyCall c) {
    final kind = c.isVideo ? 'vídeo' : 'voz';
    switch (c.state) {
      case CallState.ended:
        return ('Chamada de $kind · ${chatDuration(c.durationS * 1000)}', false);
      case CallState.declined:
        return (c.outgoing ? 'Recusada' : 'Você recusou', false);
      case CallState.missed:
        return (c.outgoing ? 'Sem resposta' : 'Perdida', !c.outgoing);
      case CallState.busy:
        return (c.outgoing ? 'Ocupado' : 'Perdida', !c.outgoing);
      case CallState.failed:
        return ('Falhou', false);
      case CallState.ringing:
      case CallState.accepted:
        return ('Em andamento', false);
      default:
        return ('', false);
    }
  }

  void _callBack(DriqyCall c) {
    if (CallManager.instance.busy) return;
    CallManager.instance.startCall(
      c.partner.username,
      c.partner.displayName,
      c.partner.avatarUrl,
      media: c.isVideo ? CallMedia.video : CallMedia.voice,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chamadas')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_error!, style: TextStyle(color: AppColors.textMuted)),
                      const SizedBox(height: 8),
                      TextButton(onPressed: _load, child: const Text('Tentar de novo')),
                    ],
                  ),
                )
              : _calls.isEmpty
                  ? Center(
                      child: Text('Nenhuma chamada ainda.',
                          style: TextStyle(color: AppColors.textMuted)),
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.builder(
                        itemCount: _calls.length + (_hasMore ? 1 : 0),
                        itemBuilder: (context, i) {
                          if (i == _calls.length) {
                            _more();
                            return const Padding(
                              padding: EdgeInsets.all(16),
                              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                            );
                          }
                          final c = _calls[i];
                          final (text, bad) = _status(c);
                          final u = c.partner;
                          return ListTile(
                            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                                builder: (_) => MessageThreadScreen(username: u.username))),
                            leading: CircleAvatar(
                              backgroundImage: u.avatarUrl != null
                                  ? NetworkImage(resolveMediaUrl(u.avatarUrl!))
                                  : null,
                              child: u.avatarUrl == null
                                  ? Text(u.displayName.isEmpty ? '?' : u.displayName[0].toUpperCase())
                                  : null,
                            ),
                            title: Text(u.displayName,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: bad ? AppColors.danger : null)),
                            subtitle: Row(
                              children: [
                                Icon(
                                  bad
                                      ? Icons.call_missed
                                      : (c.outgoing ? Icons.call_made : Icons.call_received),
                                  size: 14,
                                  color: bad ? AppColors.danger : AppColors.textMuted,
                                ),
                                const SizedBox(width: 4),
                                Flexible(
                                  child: Text('$text · ${_when(c.createdAt)}',
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                          color: AppColors.textMuted, fontSize: 12.5)),
                                ),
                              ],
                            ),
                            trailing: IconButton(
                              tooltip: c.isVideo ? 'Ligar em vídeo' : 'Ligar',
                              icon: Icon(c.isVideo ? Icons.videocam_outlined : Icons.call_outlined),
                              onPressed: CallManager.instance.busy ? null : () => _callBack(c),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
