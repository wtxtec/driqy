import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/user.dart';
import '../services/auth_service.dart';
import '../services/user_service.dart';
import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';
import '../widgets/ping_app_bar.dart';
import '../widgets/ping_tab_bar.dart';
import '../widgets/ping_wide.dart';
import 'message_thread_screen.dart';
import 'ping_nav.dart';
import 'profile_screen.dart';

/// Ping fase 8 — tela "Contatos": quem eu sigo / quem me segue. Tocar na pessoa abre
/// a conversa (igual a `/mensagens/contatos` do site); o ícone à direita abre o perfil.
class PingContactsScreen extends StatefulWidget {
  /// Selo de não lidas da aba Chats (vem da lista de conversas; só decorativo aqui).
  final int unread;

  const PingContactsScreen({super.key, this.unread = 0});

  @override
  State<PingContactsScreen> createState() => _PingContactsScreenState();
}

class _PingContactsScreenState extends State<PingContactsScreen> {
  late final UserService _service;
  final TextEditingController _q = TextEditingController();
  Timer? _debounce;
  int _seq = 0; // descarta respostas antigas quando a busca/aba muda no meio

  bool _followers = false;
  List<DriqyUser> _users = [];
  bool _hasNext = false;
  int _page = 1;
  int _followingCount = 0;
  int _followersCount = 0;
  bool _loading = true;
  bool _loadingMore = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _service = UserService(context.read<AuthService>().client);
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _q.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final mine = ++_seq;
    setState(() {
      _loading = true;
      _error = null;
      _page = 1;
    });
    try {
      final r = await _service.getContacts(followers: _followers, q: _q.text, page: 1);
      if (!mounted || mine != _seq) return;
      setState(() {
        _users = r.users;
        _hasNext = r.hasNext;
        _followingCount = r.followingCount;
        _followersCount = r.followersCount;
        _loading = false;
      });
    } catch (_) {
      if (!mounted || mine != _seq) return;
      setState(() {
        _loading = false;
        _error = 'Não foi possível carregar os contatos.';
      });
    }
  }

  Future<void> _loadMore() async {
    if (_loadingMore || !_hasNext) return;
    final mine = _seq;
    setState(() => _loadingMore = true);
    try {
      final r = await _service.getContacts(followers: _followers, q: _q.text, page: _page + 1);
      if (!mounted || mine != _seq) return;
      setState(() {
        _users = [..._users, ...r.users];
        _hasNext = r.hasNext;
        _page += 1;
        _loadingMore = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  void _onSearch(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), _load);
  }

  void _setTab(bool followers) {
    if (_followers == followers) return;
    setState(() => _followers = followers);
    _load();
  }

  void _openChat(DriqyUser u) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => MessageThreadScreen(username: u.username)),
    );
  }

  void _openProfile(DriqyUser u) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => ProfileScreen(username: u.username)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = PingColors.of(context);
    final wide = PingWide.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      // Fase 9: no painel direito (tela larga) não há barra "Ping" nem pílula — a lista já está ao lado
      appBar: wide
          ? AppBar(
              backgroundColor: c.bg,
              leading: IconButton(
                icon: const Icon(Icons.close),
                tooltip: 'Fechar',
                onPressed: () => Navigator.of(context).maybePop(),
              ),
              title: const Text('Contatos', style: TextStyle(fontWeight: FontWeight.w700)),
            )
          : const PingAppBar(),
      bottomNavigationBar: wide ? null : PingNav.tabBar(context, current: PingTab.contacts, unread: widget.unread),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Text('Contatos', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
          ),
          _segmented(c),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: TextField(
              controller: _q,
              onChanged: _onSearch,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Buscar contatos',
                isDense: true,
                filled: true,
                fillColor: c.searchBg,
                prefixIcon: const Icon(Icons.search, size: 20),
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(child: _body()),
        ],
      ),
    );
  }

  Widget _segmented(PingColors c) {
    Widget item(String label, bool followers) {
      final selected = _followers == followers;
      return Expanded(
        child: Semantics(
          button: true,
          selected: selected,
          child: GestureDetector(
            onTap: () => _setTab(followers),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 9),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: selected ? AppGradients.brand : null,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: selected ? c.onAccent : AppColors.textMuted,
                ),
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: c.searchBg, borderRadius: BorderRadius.circular(999)),
      child: Row(
        children: [
          item('Seguindo · $_followingCount', false),
          item('Seguidores · $_followersCount', true),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!, style: TextStyle(color: AppColors.textMuted)),
            const SizedBox(height: 8),
            TextButton(onPressed: _load, child: const Text('Tentar de novo')),
          ],
        ),
      );
    }
    if (_users.isEmpty) {
      final searching = _q.text.trim().isNotEmpty;
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            searching
                ? 'Nenhum contato encontrado.'
                : _followers
                    ? 'Ninguém te segue ainda.'
                    : 'Você ainda não segue ninguém. Siga pessoas no Driqy para conversar com elas por aqui.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textMuted),
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 12),
      itemCount: _users.length + (_hasNext ? 1 : 0),
      itemBuilder: (_, i) {
        if (i == _users.length) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Center(
              child: _loadingMore
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : TextButton(onPressed: _loadMore, child: const Text('Carregar mais')),
            ),
          );
        }
        final u = _users[i];
        return ListTile(
          onTap: () => _openChat(u),
          leading: CircleAvatar(
            radius: 24,
            backgroundColor: AppColors.surface2,
            backgroundImage: u.avatarUrl != null ? NetworkImage(resolveMediaUrl(u.avatarUrl!)) : null,
            child: u.avatarUrl == null ? Text(u.displayName[0].toUpperCase()) : null,
          ),
          title: Row(
            children: [
              Flexible(
                child: Text(u.displayName,
                    style: const TextStyle(fontWeight: FontWeight.w600), overflow: TextOverflow.ellipsis),
              ),
              if (u.badgeKind != null) ...[
                const SizedBox(width: 4),
                Icon(Icons.verified, size: 15, color: AppColors.badgeColor(u.badgeKind)),
              ],
            ],
          ),
          subtitle: Text('@${u.username}', style: TextStyle(color: AppColors.textMuted)),
          trailing: IconButton(
            tooltip: 'Ver perfil',
            icon: const Icon(Icons.person_outline),
            onPressed: () => _openProfile(u),
          ),
        );
      },
    );
  }
}
