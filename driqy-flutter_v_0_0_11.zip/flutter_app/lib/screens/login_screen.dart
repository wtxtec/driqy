import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../theme/app_colors.dart';
import '../widgets/brand_mark.dart';
import '../widgets/gradient_button.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _identifierController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _loading = false;
  late final TapGestureRecognizer _signUpTap = TapGestureRecognizer()..onTap = _openRegister;
  String? _error;

  @override
  void dispose() {
    _identifierController.dispose();
    _passwordController.dispose();
    _signUpTap.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await context
          .read<AuthService>()
          .login(
            identifier: _identifierController.text.trim(),
            password: _passwordController.text,
          )
          .timeout(const Duration(seconds: 15)); // sem isso o celular espera ~2 min num IP inalcançável
      // navegação acontece automaticamente: main.dart escuta AuthService
      // e troca de tela sozinho quando o status vira "authenticated"
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Não foi possível conectar ao servidor ($kApiBaseUrl).\n\n'
          'Confira: (1) o celular está no mesmo Wi-Fi do PC (dados móveis não alcançam o IP local); '
          '(2) o Flask está rodando com host 0.0.0.0; (3) o firewall libera a porta. '
          'Se o endereço mudou, toque em "Alterar servidor".');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Troca o endereço do servidor sem recompilar (fica salvo no aparelho).
  Future<void> _changeServer() async {
    final c = TextEditingController(text: kApiBaseUrl);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Endereço do servidor'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.url,
          autocorrect: false,
          decoration: const InputDecoration(hintText: 'http://192.168.0.10:5000'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Salvar')),
        ],
      ),
    );
    if (ok != true) return;
    final saved = await saveApiBaseUrl(c.text);
    if (!mounted) return;
    setState(() => _error = saved == null ? 'Endereço inválido.' : null);
  }

  void _openRegister() {
    if (_loading) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RegisterScreen()));
  }

  Future<void> _openForgotPassword() async {
    // Mesma tela de recuperação de senha do site (rota /esqueci-senha).
    await launchUrl(Uri.parse('$kApiBaseUrl/esqueci-senha'), mode: LaunchMode.externalApplication);
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text, style: TextStyle(fontSize: 13, color: AppColors.textMuted)),
      );

  /// Formulário idêntico ao `.login-form-inner` do site.
  Widget _buildForm(double width, double height) {
    final headlineSize = (width * 0.05).clamp(33.6, 48.0).toDouble();
    final brandGap = (height * 0.06).clamp(28.0, 56.0).toDouble();
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 380),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset('assets/brand/driqy_logo.png', height: 34),
            SizedBox(height: brandGap),
            Text(
              'Acontecendo agora.',
              style: GoogleFonts.fraunces(
                fontSize: headlineSize,
                height: 1.08,
                fontWeight: FontWeight.w700,
                color: AppColors.text,
              ),
            ),
            const SizedBox(height: 32),
            _label('Usuário ou e-mail'),
            _PillField(
              controller: _identifierController,
              autofocus: true,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.username],
              textInputAction: TextInputAction.next,
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Informe seu usuário' : null,
            ),
            const SizedBox(height: 16),
            _label('Senha'),
            _PillField(
              controller: _passwordController,
              obscure: true,
              autofillHints: const [AutofillHints.password],
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _loading ? null : _submit(),
              validator: (v) => (v == null || v.isEmpty) ? 'Informe sua senha' : null,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: InkWell(
                onTap: _loading ? null : _openForgotPassword,
                child: Text('Esqueceu sua senha?',
                    style: TextStyle(fontSize: 13, color: AppColors.textMuted)),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 14),
              Text(_error!, style: TextStyle(color: AppColors.danger)),
            ],
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerLeft,
              child: InkWell(
                onTap: _loading ? null : _changeServer,
                child: Text('Servidor: $kApiBaseUrl  ·  Alterar',
                    style: TextStyle(fontSize: 12.5, color: AppColors.textMuted)),
              ),
            ),
            const SizedBox(height: 22),
            GradientButton(
              onPressed: _loading ? null : _submit,
              height: 46,
              fontSize: 15.2,
              child: _loading
                  ? SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation(AppColors.onBrand),
                      ),
                    )
                  : const Text('Entrar', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            const SizedBox(height: 28),
            Text.rich(
              TextSpan(
                style: TextStyle(fontSize: 14.4, color: AppColors.textMuted),
                children: [
                  const TextSpan(text: 'Ainda não tem conta? '),
                  TextSpan(
                    text: 'Cadastre-se',
                    recognizer: _signUpTap,
                    style: TextStyle(color: AppColors.amber, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          // Glows do `.login-page::before` do site (âmbar em 82%/18%, rosa em 92%/55%).
          const Positioned.fill(child: _LoginGlow(alignment: Alignment(0.64, -0.64), color: Color(0x29F2A93B))),
          const Positioned.fill(child: _LoginGlow(alignment: Alignment(0.84, 0.10), color: Color(0x24E85D75))),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, c) {
                final w = c.maxWidth;
                final h = c.maxHeight;
                final wide = w > 860;
                if (wide) {
                  // Desktop: marca à esquerda, formulário à direita.
                  final markSize = (w * 0.6).clamp(0.0, 420.0).toDouble();
                  return Row(
                    children: [
                      Expanded(flex: 11, child: Center(child: AnimatedBrandMark(size: markSize))),
                      Expanded(
                        flex: 10,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: SingleChildScrollView(
                            padding: EdgeInsets.symmetric(horizontal: w * 0.08, vertical: h * 0.06),
                            child: _buildForm(w, h),
                          ),
                        ),
                      ),
                    ],
                  );
                }
                // Mobile: marca no topo, formulário embaixo.
                final markSize = (w * 0.5).clamp(0.0, 220.0).toDouble();
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: h * 0.07, bottom: h * 0.02),
                        child: Center(child: AnimatedBrandMark(size: markSize)),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(w * 0.07, h * 0.02, w * 0.07, h * 0.08),
                        child: Align(alignment: Alignment.centerLeft, child: _buildForm(w, h)),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _LoginGlow extends StatelessWidget {
  final Alignment alignment;
  final Color color;
  const _LoginGlow({required this.alignment, required this.color});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: alignment,
            radius: 0.75,
            colors: [color, Colors.transparent],
            stops: const [0, 1],
          ),
        ),
      ),
    );
  }
}

/// Campo em pílula, igual aos inputs do `.login-form` do site: fundo
/// surface-2, borda sutil e, no foco, borda âmbar com halo de 3px.
class _PillField extends StatefulWidget {
  final TextEditingController controller;
  final bool obscure;
  final bool autofocus;
  final TextInputType? keyboardType;
  final Iterable<String>? autofillHints;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onSubmitted;
  final FormFieldValidator<String>? validator;

  const _PillField({
    required this.controller,
    this.obscure = false,
    this.autofocus = false,
    this.keyboardType,
    this.autofillHints,
    this.textInputAction,
    this.onSubmitted,
    this.validator,
  });

  @override
  State<_PillField> createState() => _PillFieldState();
}

class _PillFieldState extends State<_PillField> {
  final _focus = FocusNode();
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    OutlineInputBorder border(Color color) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(999),
          borderSide: BorderSide(color: color),
        );
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        boxShadow: _focused
            ? [BoxShadow(color: AppColors.amber.withValues(alpha: 0.18), spreadRadius: 3)]
            : const [],
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focus,
        autofocus: widget.autofocus,
        obscureText: widget.obscure,
        keyboardType: widget.keyboardType,
        autofillHints: widget.autofillHints,
        textInputAction: widget.textInputAction,
        onFieldSubmitted: widget.onSubmitted,
        validator: widget.validator,
        style: TextStyle(fontSize: 15.2, color: AppColors.text),
        cursorColor: AppColors.amber,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColors.surface2,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: border(AppColors.border),
          enabledBorder: border(AppColors.border),
          focusedBorder: border(AppColors.amber),
          errorBorder: border(AppColors.danger),
          focusedErrorBorder: border(AppColors.danger),
        ),
      ),
    );
  }
}
