import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/post.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/feed_service.dart';
import '../services/post_service.dart';
import '../widgets/driqy_top_bar.dart';
import '../widgets/fade_in.dart';
import '../widgets/flash_ring.dart';
import '../widgets/inline_post_composer.dart';
import '../widgets/post_card.dart';
import 'post_detail_screen.dart';
import 'profile_screen.dart';

class FeedScreen extends StatefulWidget {
  /// Abre o menu lateral (Drawer) da HomeShell — igual ao botão ☰ do site.
  final VoidCallback? onOpenMenu;

  const FeedScreen({super.key, this.onOpenMenu});

  @override
  State<FeedScreen> createState() => FeedScreenState();
}

class FeedScreenState extends State<FeedScreen> {
  final List<DriqyPost> _posts = [];
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<FlashTrayBarState> _flashTrayKey = GlobalKey<FlashTrayBarState>();

  late FeedService _feedService;
  int _page = 1;
  bool _hasNext = true;
  bool _loadingFirstPage = true;
  bool _loadingMore = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _feedService = FeedService(context.read<AuthService>().client);
    _scrollController.addListener(_onScroll);
    _loadFirstPage();
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_hasNext || _loadingMore) return;
    final threshold = _scrollController.position.maxScrollExtent - 300;
    if (_scrollController.position.pixels >= threshold) {
      _loadMore();
    }
  }

  /// Recarrega o feed do zero. Chamado pela HomeShell depois de publicar
  /// um post novo, pra ele já aparecer no topo.
  Future<void> reload() => _loadFirstPage();

  /// Rola a lista até o topo — chamado pela HomeShell quando o usuário
  /// toca no botão "Publicar" da barra inferior, pra deixar o composer
  /// (primeiro item da lista) bem visível.
  void scrollToTop() {
    if (!_scrollController.hasClients) return;
    _scrollController.animateTo(
      0,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  Future<void> _loadFirstPage() async {
    _flashTrayKey.currentState?.reload();
    setState(() {
      _loadingFirstPage = true;
      _error = null;
    });
    try {
      final result = await _feedService.getFeed(page: 1);
      setState(() {
        _posts
          ..clear()
          ..addAll(result.posts);
        _page = 1;
        _hasNext = result.hasNext;
      });
    } catch (_) {
      setState(() => _error = 'Não foi possível carregar o feed.');
    } finally {
      if (mounted) setState(() => _loadingFirstPage = false);
    }
  }

  Future<void> _loadMore() async {
    setState(() => _loadingMore = true);
    try {
      final nextPage = _page + 1;
      final result = await _feedService.getFeed(page: nextPage);
      setState(() {
        _posts.addAll(result.posts);
        _page = nextPage;
        _hasNext = result.hasNext;
      });
    } catch (_) {
      // silencioso: mantém o que já carregou, tenta de novo no próximo scroll
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  Future<void> _toggleLike(DriqyPost post) async {
    final wasLiked = post.likedByMe;
    setState(() {
      post.likedByMe = !wasLiked;
      post.likesCount += wasLiked ? -1 : 1;
    });
    try {
      final liked = await _feedService.toggleLike(post.id);
      if (liked != post.likedByMe) {
        setState(() => post.likedByMe = liked);
      }
    } catch (_) {
      // desfaz a mudança otimista se a chamada falhar
      setState(() {
        post.likedByMe = wasLiked;
        post.likesCount += wasLiked ? 1 : -1;
      });
    }
  }

  /// Abre a página do post (onde ficam os comentários). Ao voltar,
  /// atualiza as contagens de curtidas/comentários do card.
  Future<void> _openPost(int postId, {bool focusComment = false}) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PostDetailScreen(postId: postId, focusComment: focusComment)),
    );
    if (!mounted) return;
    try {
      final fresh = await PostService(context.read<AuthService>().client).getPost(postId);
      final i = _posts.indexWhere((p) => p.id == postId);
      if (i != -1 && mounted) {
        setState(() {
          _posts[i].commentsCount = fresh.commentsCount;
          _posts[i].likesCount = fresh.likesCount;
          _posts[i].likedByMe = fresh.likedByMe;
        });
      }
    } on ApiException catch (e) {
      // 404 = o post foi excluído (ex.: pelo autor, na página do post)
      if (e.statusCode == 404 && mounted) {
        setState(() => _posts.removeWhere((p) => p.id == postId));
      }
    } catch (_) {
      // silencioso: mantém as contagens antigas
    }
  }

  void _openProfile(String username) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProfileScreen(username: username)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DriqyTopBar(onOpenMenu: widget.onOpenMenu),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    // O composer "O que está acontecendo?" é o primeiro item da própria
    // área rolável (igual ao site): ele fica no topo da página e vai
    // embora junto com o scroll, em vez de ficar fixo acompanhando o
    // usuário. SliverToBoxAdapter mantém o widget vivo mesmo fora da
    // tela, então o texto digitado/mídia escolhida não se perdem.
    return RefreshIndicator(
      onRefresh: _loadFirstPage,
      child: CustomScrollView(
        controller: _scrollController,
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: FlashTrayBar(key: _flashTrayKey)),
          SliverToBoxAdapter(child: InlinePostComposer(onPosted: _loadFirstPage)),
          ..._buildFeedSlivers(),
        ],
      ),
    );
  }

  List<Widget> _buildFeedSlivers() {
    if (_loadingFirstPage) {
      return const [
        SliverFillRemaining(
          hasScrollBody: false,
          child: Center(child: CircularProgressIndicator()),
        ),
      ];
    }
    if (_error != null && _posts.isEmpty) {
      return [
        SliverFillRemaining(
          hasScrollBody: false,
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_error!),
                const SizedBox(height: 12),
                OutlinedButton(onPressed: _loadFirstPage, child: const Text('Tentar de novo')),
              ],
            ),
          ),
        ),
      ];
    }
    if (_posts.isEmpty) {
      return const [
        SliverFillRemaining(
          hasScrollBody: false,
          child: Center(child: Text('Ainda não há posts no feed.')),
        ),
      ];
    }
    return [
      SliverList.builder(
        itemCount: _posts.length + (_hasNext ? 1 : 0),
        itemBuilder: (context, index) {
          if (index >= _posts.length) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(child: CircularProgressIndicator()),
            );
          }
          final post = _posts[index];
          return FadeSlideIn(
            child: PostCard(
              key: ValueKey('post-${post.id}'),
              post: post,
              onLikeTap: () => _toggleLike(post),
              onTap: () => _openPost(post.id),
              onCommentsTap: () => _openPost(post.id, focusComment: true),
              onAuthorTap: () => _openProfile(post.author.username),
              onExpired: () {
                if (mounted) setState(() => _posts.removeWhere((p) => p.id == post.id));
              },
              onDelete: () async {
                await PostService(context.read<AuthService>().client).deletePost(post.id);
                if (mounted) setState(() => _posts.removeWhere((p) => p.id == post.id));
              },
            ),
          );
        },
      ),
    ];
  }
}
