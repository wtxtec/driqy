import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../config.dart';
import '../models/app_notification.dart';
import '../services/auth_service.dart';
import '../services/notification_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_spacing.dart';
import '../widgets/fade_in.dart';
import '../widgets/driqy_top_bar.dart';
import 'post_detail_screen.dart';
import 'profile_screen.dart';

class NotificationsScreen extends StatefulWidget {
  final VoidCallback? onOpenMenu;

  const NotificationsScreen({super.key, this.onOpenMenu});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late NotificationService _service;
  final List<AppNotification> _items = [];
  int _page = 1;
  bool _hasNext = true;
  bool _loading = true;
  bool _loadingMore = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _service = NotificationService(context.read<AuthService>().client);
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await _service.getNotifications(page: 1);
      setState(() {
        _items
          ..clear()
          ..addAll(result.notifications);
        _page = 1;
        _hasNext = result.hasNext;
      });
    } catch (_) {
      setState(() => _error = 'Não foi possível carregar as notificações.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMore() async {
    if (_loadingMore || !_hasNext) return;
    setState(() => _loadingMore = true);
    try {
      final nextPage = _page + 1;
      final result = await _service.getNotifications(page: nextPage);
      setState(() {
        _items.addAll(result.notifications);
        _page = nextPage;
        _hasNext = result.hasNext;
      });
    } catch (_) {
      // silencioso
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  void _onTapNotification(AppNotification notif) {
    if (notif.isSeason) return; // aviso do sistema: não tem para onde ir
    if (notif.kind == AppNotification.kindFollow) {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => ProfileScreen(username: notif.actor.username)),
      );
    } else if (notif.postId != null) {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PostDetailScreen(postId: notif.postId!)),
      );
    }
  }

  IconData _iconFor(String kind) {
    switch (kind) {
      case AppNotification.kindLike:
        return Icons.favorite;
      case AppNotification.kindComment:
      case AppNotification.kindReply:
        return Icons.mode_comment;
      case AppNotification.kindFollow:
        return Icons.person_add;
      case AppNotification.kindSeason:
        return Icons.eco;
      default:
        return Icons.notifications;
    }
  }

  Color _colorFor(String kind) {
    switch (kind) {
      case AppNotification.kindLike:
        return AppColors.rose;
      case AppNotification.kindComment:
      case AppNotification.kindReply:
        return AppColors.badgeVerified;
      case AppNotification.kindFollow:
        return AppColors.green;
      case AppNotification.kindSeason:
        return AppColors.amber;
      default:
        return AppColors.textMuted;
    }
  }

  /// "agora", "há 5 min", "há 3 h", "ontem" ou a data — bem mais legível
  /// que "03/10/2026 02:41" em cada linha.
  String _relativeTime(DateTime when) {
    final now = DateTime.now();
    final local = when.toLocal();
    final diff = now.difference(local);
    if (diff.inSeconds < 60) return 'agora';
    if (diff.inMinutes < 60) return 'há ${diff.inMinutes} min';
    if (diff.inHours < 24 && _dayOf(local) == _dayOf(now)) return 'há ${diff.inHours} h';
    final days = _dayOf(now).difference(_dayOf(local)).inDays;
    if (days == 1) return 'ontem';
    if (days < 7) return 'há $days dias';
    return DateFormat('dd/MM/yyyy').format(local);
  }

  DateTime _dayOf(DateTime d) => DateTime(d.year, d.month, d.day);

  String _sectionOf(DateTime when) {
    final days = _dayOf(DateTime.now()).difference(_dayOf(when.toLocal())).inDays;
    if (days <= 0) return 'Hoje';
    if (days == 1) return 'Ontem';
    if (days < 7) return 'Esta semana';
    return 'Anteriores';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // A mesma topbar do Feed (logo + pílula de busca + mensagens/
      // notificações) aparece em toda página do site (`base.html`), não
      // só na home — por isso usa `DriqyTopBar` aqui também.
      appBar: DriqyTopBar(onOpenMenu: widget.onOpenMenu),
      body: _buildBody(),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.gap + 4, 16, AppSpacing.gap + 4, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Notificações',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 26),
          ),
          const SizedBox(height: 4),
          Text(
            'Curtidas, comentários e novos seguidores.',
            style: TextStyle(color: AppColors.textMuted, fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: NotificationListener<ScrollNotification>(
        onNotification: (n) {
          if (n.metrics.pixels >= n.metrics.maxScrollExtent - 200) _loadMore();
          return false;
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            _buildHeader(),
            if (_error != null && _items.isEmpty)
              _buildMessageState(
                icon: Icons.cloud_off_outlined,
                title: 'Não foi possível carregar',
                subtitle: _error!,
                action: OutlinedButton(onPressed: _load, child: const Text('Tentar de novo')),
              )
            else if (_items.isEmpty)
              _buildMessageState(
                icon: Icons.notifications_none_rounded,
                title: 'Tudo em dia',
                subtitle: 'Quando alguém curtir, comentar ou te seguir, aparece aqui.',
              )
            else
              ..._buildGroupedItems(),
            if (_loadingMore)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageState({
    required IconData icon,
    required String title,
    required String subtitle,
    Widget? action,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 56, 32, 0),
      child: Column(
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.surface,
              border: Border.all(color: AppColors.border),
            ),
            child: Icon(icon, size: 32, color: AppColors.amber),
          ),
          const SizedBox(height: 18),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: AppColors.text),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textMuted, fontSize: 14, height: 1.4),
          ),
          if (action != null) ...[const SizedBox(height: 18), action],
        ],
      ),
    );
  }

  /// Agrupa por dia (Hoje / Ontem / Esta semana / Anteriores) mantendo a
  /// ordem que veio do servidor (mais recentes primeiro).
  List<Widget> _buildGroupedItems() {
    final widgets = <Widget>[];
    String? currentSection;
    for (final notif in _items) {
      final section = _sectionOf(notif.createdAt);
      if (section != currentSection) {
        currentSection = section;
        widgets.add(
          Padding(
            padding: EdgeInsets.fromLTRB(
                AppSpacing.gap + 4, widgets.isEmpty ? 0 : 14, AppSpacing.gap + 4, 8),
            child: Text(
              section.toUpperCase(),
              style: TextStyle(
                fontSize: 10.9,
                letterSpacing: 0.76,
                fontWeight: FontWeight.w600,
                color: AppColors.textMuted,
              ),
            ),
          ),
        );
      }
      widgets.add(FadeSlideIn(child: _buildItem(notif)));
    }
    if (_hasNext) {
      widgets.add(const SizedBox(height: 4));
    }
    return widgets;
  }

  Widget _buildItem(AppNotification notif) {
    final avatarUrl = notif.actor.avatarUrl;
    final kindColor = _colorFor(notif.kind);
    final unread = !notif.isRead;
    final hasSnippet = notif.snippet != null && notif.snippet!.isNotEmpty;

    return Container(
      margin: const EdgeInsets.fromLTRB(AppSpacing.gap, 0, AppSpacing.gap, 8),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: unread ? Color.alphaBlend(AppColors.amber.withValues(alpha: 0.07), AppColors.surface) : AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: unread ? AppColors.amber.withValues(alpha: 0.35) : AppColors.border),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _onTapNotification(notif),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Barra lateral na cor do tipo (igual à dos cards de post).
                Container(width: 3, color: kindColor),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Stack(
                          clipBehavior: Clip.none,
                          children: [
                            CircleAvatar(
                              radius: 23,
                              backgroundColor: AppColors.surface2,
                              backgroundImage: avatarUrl != null && !notif.isSeason
                                  ? NetworkImage(resolveMediaUrl(avatarUrl))
                                  : null,
                              child: notif.isSeason
                                  ? Text(notif.seasonEmoji, style: const TextStyle(fontSize: 22))
                                  : (avatarUrl == null
                                      ? Text(notif.actor.displayName[0].toUpperCase(),
                                          style: TextStyle(color: AppColors.text))
                                      : null),
                            ),
                            Positioned(
                              right: -3,
                              bottom: -3,
                              child: Container(
                                width: 20,
                                height: 20,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: kindColor,
                                  border: Border.all(color: AppColors.surface, width: 2),
                                ),
                                child: Icon(_iconFor(notif.kind), size: 11, color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                  style: TextStyle(
                                      color: AppColors.textMuted, fontSize: 14.5, height: 1.35),
                                  children: [
                                    if (notif.isSeason)
                                      TextSpan(text: notif.verb, style: TextStyle(color: AppColors.text))
                                    else ...[
                                      TextSpan(
                                        text: notif.actor.displayName,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700, color: AppColors.text),
                                      ),
                                      TextSpan(text: ' ${notif.verb}'),
                                    ],
                                  ],
                                ),
                              ),
                              if (hasSnippet) ...[
                                const SizedBox(height: 8),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: AppColors.surface2,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Text(
                                    notif.snippet!,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: AppColors.text, fontSize: 13.5, height: 1.35),
                                  ),
                                ),
                              ],
                              const SizedBox(height: 6),
                              Text(
                                _relativeTime(notif.createdAt),
                                style: TextStyle(fontSize: 12, color: AppColors.textMuted),
                              ),
                            ],
                          ),
                        ),
                        if (unread) ...[
                          const SizedBox(width: 10),
                          Container(
                            margin: const EdgeInsets.only(top: 6),
                            width: 9,
                            height: 9,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: AppGradients.brand,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
