import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/chat_group.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/chat_live.dart';
import '../services/group_service.dart';
import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';
import '../widgets/chat/chat_composer.dart';
import '../widgets/chat/chat_format.dart';
import '../widgets/group_avatar.dart';
import 'group_info_screen.dart';

/// Conversa de grupo (só texto): enviar, responder, editar, apagar, tempo real e "digitando".
/// Toque no cabeçalho abre [GroupInfoScreen] (dados do grupo, participantes, sair).
class GroupThreadScreen extends StatefulWidget {
  final int groupId;
  final DriqyGroup? initial;

  const GroupThreadScreen({super.key, required this.groupId, this.initial});

  @override
  State<GroupThreadScreen> createState() => _GroupThreadScreenState();
}

class _GroupThreadScreenState extends State<GroupThreadScreen> {
  late final GroupService _service;
  final _input = TextEditingController();
  final _scroll = ScrollController(); // reverse: 0 = fim da conversa
  DriqyGroup? _group;
  List<DriqyGroupMessage> _msgs = [];
  bool _hasMore = false;
  bool _loading = true;
  String? _error;
  DriqyGroupMessage? _replyTo;
  DriqyGroupMessage? _editing;
  int _tmp = 0;
  final Map<String, Timer> _typing = {};
  StreamSubscription<ChatEvent>? _sub;
  Timer? _debounce, _poll;
  DateTime _lastTyping = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    final client = context.read<AuthService>().client;
    _service = GroupService(client);
    _group = widget.initial;
    ChatLive.instance.acquire(client);
    _sub = ChatLive.instance.events.listen(_onEvent);
    _poll = Timer.periodic(const Duration(seconds: 10), (_) {
      if (!ChatLive.instance.connected) _loadNew();
    });
    _input.addListener(() {
      if (mounted) setState(() {});
      _onTyping();
    });
    _loadInitial();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _poll?.cancel();
    _debounce?.cancel();
    for (final t in _typing.values) {
      t.cancel();
    }
    ChatLive.instance.release();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  int get _lastId => _msgs.lastWhere((m) => m.id > 0, orElse: () => _empty).id;
  static final _empty = DriqyGroupMessage(id: 0, kind: 'text', sender: null, content: '', createdAt: DateTime.fromMillisecondsSinceEpoch(0));

  void _snack(String m) => ScaffoldMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(m)));

  void _gone(Object e) {
    if (e is ApiException && e.statusCode == 404 && mounted) {
      _snack('Você não faz parte deste grupo.');
      Navigator.of(context).maybePop();
    }
  }

  Future<void> _loadInitial() async {
    try {
      final r = await Future.wait([_service.detail(widget.groupId), _service.messages(widget.groupId)]);
      if (!mounted) return;
      setState(() {
        _group = r[0] as DriqyGroup;
        final page = r[1] as GroupMessagesPage;
        _msgs = page.messages;
        _hasMore = page.hasMore;
        _loading = false;
        _error = null;
      });
      _markRead();
    } catch (e) {
      if (!mounted) return;
      _gone(e);
      setState(() {
        _loading = false;
        _error = 'Não foi possível carregar o grupo.';
      });
    }
  }

  Future<void> _loadNew() async {
    try {
      final page = await _service.messages(widget.groupId, after: _lastId, limit: 100);
      if (!mounted || page.messages.isEmpty) return;
      setState(() => _merge(page.messages));
      _markRead();
    } catch (e) {
      _gone(e);
    }
  }

  Future<void> _refreshWindow() async {
    final first = _msgs.where((m) => m.id > 0).toList();
    if (first.isEmpty) return;
    try {
      final page = await _service.messages(widget.groupId, after: first.first.id - 1, limit: 200);
      if (mounted) setState(() => _merge(page.messages));
    } catch (e) {
      _gone(e);
    }
  }

  Future<void> _loadGroup() async {
    try {
      final g = await _service.detail(widget.groupId);
      if (mounted) setState(() => _group = g);
    } catch (e) {
      _gone(e);
    }
  }

  void _merge(List<DriqyGroupMessage> incoming) {
    for (final m in incoming) {
      final i = _msgs.indexWhere((x) => x.id == m.id || (m.clientId != null && x.clientId == m.clientId));
      if (i >= 0) {
        _msgs[i] = m;
      } else {
        _msgs.add(m);
      }
    }
    _msgs.sort((a, b) => (a.id > 0 && b.id > 0) ? a.id.compareTo(b.id) : 0);
  }

  Future<void> _loadOlder() async {
    final first = _msgs.where((m) => m.id > 0).toList();
    if (first.isEmpty) return;
    try {
      final page = await _service.messages(widget.groupId, before: first.first.id);
      if (mounted) setState(() {
        _msgs = [...page.messages, ..._msgs];
        _hasMore = page.hasMore;
      });
    } catch (_) {
      _snack('Não foi possível carregar as anteriores.');
    }
  }

  void _onEvent(ChatEvent e) {
    if (e.type == 'resync') {
      _loadNew();
      return;
    }
    if (e.type != 'group' || (e.data['group_id'] as num?)?.toInt() != widget.groupId) return;
    final kind = e.kind;
    if (kind == 'typing') {
      final u = e.data['username'] as String? ?? '';
      _typing[u]?.cancel();
      if (e.state == 'stop') {
        setState(() => _typing.remove(u));
      } else {
        setState(() => _typing[u] = Timer(const Duration(seconds: 5), () {
              if (mounted) setState(() => _typing.remove(u));
            }));
      }
      return;
    }
    if (kind == 'removed') {
      _snack('Você saiu deste grupo.');
      Navigator.of(context).maybePop();
      return;
    }
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 150), () {
      if (kind == 'message') {
        _loadNew();
      } else if (kind == 'update') {
        _refreshWindow();
      } else if (kind == 'members' || kind == 'info' || kind == 'prefs') {
        _loadGroup();
        if (kind != 'prefs') _loadNew();
      }
    });
  }

  void _markRead() {
    final id = _lastId;
    if (id > 0) _service.markRead(widget.groupId, id).catchError((_) {});
  }

  // ---- enviar / editar / apagar ----
  void _onTyping() {
    if (_input.text.trim().isEmpty) return;
    final now = DateTime.now();
    if (now.difference(_lastTyping).inSeconds >= 3) {
      _lastTyping = now;
      _service.typing(widget.groupId, 'typing').catchError((_) {});
    }
  }

  Future<void> _submit() async {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    if (_editing != null) {
      final m = _editing!;
      setState(() => _editing = null);
      _input.clear();
      try {
        final upd = await _service.edit(widget.groupId, m.id, text);
        if (mounted) setState(() => _merge([upd]));
      } on ApiException catch (e) {
        _snack(e.message);
      }
      return;
    }
    final me = context.read<AuthService>().currentUser;
    final reply = _replyTo;
    final tmp = DriqyGroupMessage(
      id: -(++_tmp),
      kind: 'text',
      sender: me == null ? null : DriqyGroupUser(id: me.id, username: me.username, displayName: me.displayName),
      content: text,
      createdAt: DateTime.now().toUtc(),
      clientId: 'a${DateTime.now().millisecondsSinceEpoch}$_tmp',
      replyTo: reply == null ? null : DriqyGroupReply(id: reply.id, senderName: reply.mine ? 'Você' : (reply.sender?.displayName ?? ''), preview: reply.content),
      mine: true,
      state: 'sending',
    );
    setState(() {
      _msgs.add(tmp);
      _replyTo = null;
    });
    _input.clear();
    _scrollEnd();
    _deliver(tmp, reply?.id);
  }

  Future<void> _deliver(DriqyGroupMessage tmp, int? replyId) async {
    try {
      final real = await _service.send(widget.groupId, tmp.content, clientId: tmp.clientId, replyToId: replyId);
      if (!mounted) return;
      setState(() {
        _msgs.removeWhere((m) => m.clientId == tmp.clientId && m.id < 0);
        if (!_msgs.any((m) => m.id == real.id)) _msgs.add(real);
        _msgs.sort((a, b) => (a.id > 0 && b.id > 0) ? a.id.compareTo(b.id) : 0);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        final i = _msgs.indexWhere((m) => m.clientId == tmp.clientId && m.id < 0);
        if (i >= 0) _msgs[i] = _msgs[i].withState('failed');
      });
      if (e is ApiException) _snack(e.message);
    }
  }

  void _scrollEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(0, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    });
  }

  Future<void> _actions(DriqyGroupMessage m) async {
    if (m.id < 0 || m.isSystem) return;
    final isAdmin = _group?.isAdmin ?? false;
    final act = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (!m.deleted) ListTile(leading: const Icon(Icons.reply), title: const Text('Responder'), onTap: () => Navigator.pop(ctx, 'reply')),
          if (!m.deleted) ListTile(leading: const Icon(Icons.copy), title: const Text('Copiar'), onTap: () => Navigator.pop(ctx, 'copy')),
          if (m.mine && !m.deleted) ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Editar'), onTap: () => Navigator.pop(ctx, 'edit')),
          if ((m.mine || isAdmin) && !m.deleted)
            ListTile(leading: Icon(Icons.delete_outline, color: AppColors.danger), title: const Text('Apagar para todos'), onTap: () => Navigator.pop(ctx, 'delete')),
        ]),
      ),
    );
    if (act == null || !mounted) return;
    switch (act) {
      case 'reply':
        setState(() {
          _replyTo = m;
          _editing = null;
        });
        break;
      case 'copy':
        await Clipboard.setData(ClipboardData(text: m.content));
        _snack('Copiado');
        break;
      case 'edit':
        setState(() {
          _editing = m;
          _replyTo = null;
          _input.text = m.content;
        });
        break;
      case 'delete':
        try {
          final upd = await _service.deleteMessage(widget.groupId, m.id);
          if (mounted) setState(() => _merge([upd]));
        } on ApiException catch (e) {
          _snack(e.message);
        }
        break;
    }
  }

  Future<void> _openInfo() async {
    final g = _group;
    if (g == null) return;
    final left = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => GroupInfoScreen(group: g)),
    );
    if (!mounted) return;
    if (left == true) {
      Navigator.of(context).maybePop();
    } else {
      _loadGroup();
      _loadNew();
    }
  }

  String get _subtitle {
    if (_typing.isNotEmpty) {
      return _typing.length == 1 ? '${_typing.keys.first} está digitando…' : '${_typing.length} pessoas digitando…';
    }
    final n = _group?.memberCount ?? 0;
    return n == 1 ? '1 participante' : '$n participantes';
  }

  @override
  Widget build(BuildContext context) {
    final pc = PingColors.of(context);
    final g = _group;
    return Scaffold(
      backgroundColor: pc.bg,
      appBar: AppBar(
        titleSpacing: 0,
        title: InkWell(
          onTap: _openInfo,
          child: Row(children: [
            GroupAvatar(name: g?.name ?? '', url: g?.avatarUrl, radius: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(g?.name ?? 'Grupo', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600), overflow: TextOverflow.ellipsis),
                Text(_subtitle, style: TextStyle(fontSize: 12, color: AppColors.textMuted), overflow: TextOverflow.ellipsis),
              ]),
            ),
          ]),
        ),
        actions: [IconButton(icon: const Icon(Icons.info_outline), tooltip: 'Dados do grupo', onPressed: _openInfo)],
      ),
      body: Column(children: [
        Expanded(child: _body(pc)),
        _composer(pc),
      ]),
    );
  }

  Widget _body(PingColors pc) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text(_error!), const SizedBox(height: 12), OutlinedButton(onPressed: _loadInitial, child: const Text('Tentar de novo'))]));
    }
    if (_msgs.isEmpty) return const Center(child: Text('Nenhuma mensagem ainda. Diga oi! 👋'));
    final items = _msgs.reversed.toList(); // reverse: o fim fica embaixo
    return ListView.builder(
      controller: _scroll,
      reverse: true,
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      itemCount: items.length + (_hasMore ? 1 : 0),
      itemBuilder: (context, i) {
        if (i == items.length) {
          return Center(child: TextButton(onPressed: _loadOlder, child: const Text('Carregar mensagens anteriores')));
        }
        final m = items[i];
        final older = i + 1 < items.length ? items[i + 1] : null; // mensagem logo acima
        final newDay = older == null || !sameDay(older.createdAt.toLocal(), m.createdAt.toLocal());
        final grouped = !newDay && older != null && !older.isSystem && !m.isSystem && older.sender?.id == m.sender?.id && m.createdAt.difference(older.createdAt).inMinutes < 5;
        return Column(children: [
          if (newDay) _dayChip(chatDayLabel(m.createdAt)),
          m.isSystem ? _system(m) : _bubble(m, pc, grouped),
        ]);
      },
    );
  }

  Widget _dayChip(String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
          decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(999)),
          child: Text(t, style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
        ),
      );

  Widget _system(DriqyGroupMessage m) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 24),
        child: Text(m.content, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: AppColors.textMuted)),
      );

  Color _nameColor(int id) => HSLColor.fromAHSL(1, ((id * 67) % 360).toDouble(), 0.65, 0.62).toColor();

  Widget _bubble(DriqyGroupMessage m, PingColors pc, bool grouped) {
    final mine = m.mine;
    final textColor = mine ? pc.bubbleOutText : pc.bubbleInText;
    final radius = BorderRadius.only(
      topLeft: const Radius.circular(16),
      topRight: const Radius.circular(16),
      bottomLeft: Radius.circular(mine || grouped ? 16 : 4),
      bottomRight: Radius.circular(!mine || grouped ? 16 : 4),
    );
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: m.state == 'failed' ? () => _deliver(m, m.replyTo?.id) : () => _actions(m),
        onLongPress: () => _actions(m),
        child: Container(
          margin: EdgeInsets.only(top: grouped ? 2 : 8),
          constraints: BoxConstraints(maxWidth: math.min(MediaQuery.of(context).size.width * 0.8, 480.0)),
          padding: const EdgeInsets.fromLTRB(12, 7, 10, 6),
          decoration: BoxDecoration(
            color: mine ? null : pc.bubbleIn,
            gradient: mine ? AppGradients.brand : null,
            borderRadius: radius,
            border: m.state == 'failed' ? Border.all(color: AppColors.danger) : null,
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            if (m.deleted)
              Text('🚫 Mensagem apagada', style: TextStyle(fontStyle: FontStyle.italic, color: textColor.withOpacity(0.7)))
            else ...[
              if (!mine && !grouped && m.sender != null)
                Text(m.sender!.displayName, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _nameColor(m.sender!.id))),
              if (m.replyTo != null)
                Container(
                  margin: const EdgeInsets.only(bottom: 4),
                  padding: const EdgeInsets.fromLTRB(8, 3, 8, 3),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.12), borderRadius: BorderRadius.circular(6), border: Border(left: BorderSide(color: textColor, width: 3))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(m.replyTo!.senderName, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: textColor)),
                    Text(m.replyTo!.deleted ? 'Mensagem apagada' : m.replyTo!.preview, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: textColor.withOpacity(0.9))),
                  ]),
                ),
              // Estilo Telegram: hora na última linha do texto (desce se não couber)
              Stack(children: [
                Text.rich(TextSpan(
                  text: m.content,
                  style: TextStyle(color: textColor, fontSize: 16, height: 1.25),
                  children: [
                    WidgetSpan(
                      alignment: PlaceholderAlignment.middle,
                      child: SizedBox(width: 10 + (m.edited ? 74 : 31) + (m.state == 'failed' ? 120 : 0), height: 1),
                    ),
                  ],
                )),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Text(
                    '${m.edited ? 'editada · ' : ''}${m.state == 'sending' ? '🕓' : m.state == 'failed' ? '⚠️ toque para reenviar' : chatClock(m.createdAt)}',
                    style: TextStyle(fontSize: 11, color: textColor.withOpacity(0.7)),
                  ),
                ),
              ]),
            ],
          ]),
        ),
      ),
    );
  }

  Widget _composer(PingColors pc) {
    final banner = _editing != null ? 'Editando' : (_replyTo != null ? (_replyTo!.mine ? 'Você' : (_replyTo!.sender?.displayName ?? '')) : null);
    final bannerText = _editing?.content ?? _replyTo?.content ?? '';
    return Material(
      color: Colors.transparent,
      child: SafeArea(
        top: false,
        bottom: false, // o ChatComposer já cuida da área segura de baixo
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (banner != null)
            Container(
              color: pc.panel,
              padding: const EdgeInsets.fromLTRB(14, 6, 4, 6),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(banner, style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.amber, fontSize: 13)),
                    Text(bannerText, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                  ]),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  tooltip: 'Cancelar',
                  onPressed: () {
                    if (_editing != null) _input.clear();
                    setState(() {
                      _editing = null;
                      _replyTo = null;
                    });
                  },
                ),
              ]),
            ),
          ChatComposer(controller: _input, onSend: _submit),
        ]),
      ),
    );
  }
}
