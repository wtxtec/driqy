import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../config.dart';
import '../models/message.dart';

/// Player em tela cheia de um vídeo do chat (Fase 6). Toca o arquivo local
/// (mensagem ainda não enviada) ou a mídia privada com `Authorization: Bearer`.
/// O servidor aceita Range, então dá pra avançar sem baixar tudo.
class ChatVideoPlayerScreen extends StatefulWidget {
  final DriqyMessage message;
  final Map<String, String>? headers;

  const ChatVideoPlayerScreen({super.key, required this.message, this.headers});

  static Future<void> open(BuildContext context, DriqyMessage m, {Map<String, String>? headers}) {
    return Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => ChatVideoPlayerScreen(message: m, headers: headers),
    ));
  }

  @override
  State<ChatVideoPlayerScreen> createState() => _ChatVideoPlayerScreenState();
}

class _ChatVideoPlayerScreenState extends State<ChatVideoPlayerScreen> {
  late final VideoPlayerController _video;
  bool _ready = false;
  bool _failed = false;
  bool _controls = true;

  @override
  void initState() {
    super.initState();
    final m = widget.message;
    _video = m.localPath != null
        ? VideoPlayerController.file(File(m.localPath!))
        : VideoPlayerController.networkUrl(
            Uri.parse(resolveMediaUrl(m.mediaUrl!)),
            httpHeaders: widget.headers ?? const {},
          );
    _video.initialize().then((_) {
      if (!mounted) return;
      setState(() => _ready = true);
      _video.play();
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
    _video.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _video.dispose();
    super.dispose();
  }

  void _toggle() => _video.value.isPlaying ? _video.pause() : _video.play();

  @override
  Widget build(BuildContext context) {
    final caption = widget.message.caption;
    final playing = _video.value.isPlaying;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => setState(() => _controls = !_controls),
            child: Center(
              child: _failed
                  ? const Text('Não foi possível reproduzir o vídeo.',
                      style: TextStyle(color: Colors.white70))
                  : !_ready
                      ? const CircularProgressIndicator(color: Colors.white)
                      : AspectRatio(
                          aspectRatio: _video.value.aspectRatio,
                          child: VideoPlayer(_video),
                        ),
            ),
          ),
          if (_controls && _ready) ...[
            Center(
              child: GestureDetector(
                onTap: _toggle,
                child: DecoratedBox(
                  decoration:
                      const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        color: Colors.white, size: 44),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (caption != null && caption.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: Text(caption,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 15)),
                      ),
                    VideoProgressIndicator(
                      _video,
                      allowScrubbing: true,
                      padding: const EdgeInsets.fromLTRB(12, 6, 12, 14),
                      colors: const VideoProgressColors(
                        playedColor: Colors.white,
                        bufferedColor: Colors.white24,
                        backgroundColor: Colors.white12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          Positioned(
            top: 0,
            left: 0,
            child: SafeArea(
              child: IconButton(
                tooltip: 'Fechar',
                icon: const Icon(Icons.close, color: Colors.white),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
