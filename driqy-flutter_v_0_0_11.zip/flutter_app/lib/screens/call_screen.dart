import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../config.dart';
import '../services/call_manager.dart';
import '../theme/app_colors.dart';

/// Tela cheia da chamada de VOZ (Fase 12) e VÍDEO (Fase 13): chamando, recebendo, conectando, em andamento e
/// "encerrada". Em vídeo (fora do toque/encerrada) o vídeo remoto ocupa a tela e a câmera local fica numa miniatura. Quem abre e fecha é o [CallManager] (por cima de qualquer tela).
/// Voltar não desliga por engano: use o botão vermelho.
class CallScreen extends StatelessWidget {
  const CallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final m = CallManager.instance;
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: const Color(0xFF0E0C13),
        body: SafeArea(
          child: AnimatedBuilder(
            animation: m,
            builder: (context, _) {
              final name = m.partnerName;
              final avatar = m.partnerAvatar;
              final ph = m.phase;
              if (m.isVideo && (ph == CallPhase.calling || ph == CallPhase.connecting || ph == CallPhase.active)) {
                return _VideoCall(m: m, phase: ph);
              }
              return Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 420),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                    child: Column(
                      children: [
                        const Spacer(flex: 2),
                        _Avatar(name: name, avatarUrl: avatar, pulse: ph == CallPhase.incoming),
                        const SizedBox(height: 22),
                        Text(
                          name,
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w600, color: Colors.white),
                        ),
                        const SizedBox(height: 8),
                        Semantics(
                          liveRegion: true,
                          child: Text(
                            m.status,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 16, color: Color(0xFFCFC9DA), fontFeatures: [FontFeature.tabularFigures()]),
                          ),
                        ),
                        if (m.warning != null) ...[
                          const SizedBox(height: 10),
                          Text(m.warning!, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.amber)),
                        ],
                        const Spacer(flex: 3),
                        _Actions(m: m, phase: ph),
                        const SizedBox(height: 12),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _Avatar extends StatefulWidget {
  final String name;
  final String? avatarUrl;
  final bool pulse;

  const _Avatar({required this.name, required this.avatarUrl, required this.pulse});

  @override
  State<_Avatar> createState() => _AvatarState();
}

class _AvatarState extends State<_Avatar> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600));

  @override
  void initState() {
    super.initState();
    if (widget.pulse) _c.repeat();
  }

  @override
  void didUpdateWidget(covariant _Avatar old) {
    super.didUpdateWidget(old);
    if (widget.pulse && !_c.isAnimating) {
      _c.repeat();
    } else if (!widget.pulse && _c.isAnimating) {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final url = widget.avatarUrl;
    final initial = widget.name.isNotEmpty ? widget.name[0].toUpperCase() : '?';
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) {
        final t = widget.pulse ? _c.value : 0.0;
        return Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: widget.pulse
                ? [BoxShadow(color: AppColors.amber.withOpacity(0.5 * (1 - t)), blurRadius: 4, spreadRadius: 36 * t)]
                : null,
          ),
          child: child,
        );
      },
      child: CircleAvatar(
        radius: 66,
        backgroundColor: AppColors.surface2,
        backgroundImage: url != null && url.isNotEmpty ? NetworkImage(resolveMediaUrl(url)) : null,
        child: url == null || url.isEmpty ? Text(initial, style: const TextStyle(fontSize: 48, color: Colors.white)) : null,
      ),
    );
  }
}

class _Actions extends StatelessWidget {
  final CallManager m;
  final CallPhase phase;

  const _Actions({required this.m, required this.phase});

  @override
  Widget build(BuildContext context) {
    switch (phase) {
      case CallPhase.incoming:
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _RoundButton(icon: Icons.call_end, label: 'Recusar', color: AppColors.danger, onTap: m.decline),
            _RoundButton(icon: m.isVideo ? Icons.videocam : Icons.call, label: 'Atender', color: const Color(0xFF2FA866), onTap: m.accept),
          ],
        );
      case CallPhase.calling:
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [_RoundButton(icon: Icons.call_end, label: 'Cancelar', color: AppColors.danger, onTap: m.hangup)],
        );
      case CallPhase.connecting:
      case CallPhase.active:
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _RoundButton(
              icon: m.muted ? Icons.mic_off : Icons.mic,
              label: m.muted ? 'Ativar mic' : 'Mudo',
              color: m.muted ? Colors.white : const Color(0xFF4A4556),
              iconColor: m.muted ? const Color(0xFF222222) : Colors.white,
              onTap: m.toggleMute,
            ),
            _RoundButton(
              icon: m.speaker ? Icons.volume_up : Icons.volume_down,
              label: 'Alto-falante',
              color: m.speaker ? Colors.white : const Color(0xFF4A4556),
              iconColor: m.speaker ? const Color(0xFF222222) : Colors.white,
              onTap: m.toggleSpeaker,
            ),
            _RoundButton(icon: Icons.call_end, label: 'Desligar', color: AppColors.danger, onTap: m.hangup),
          ],
        );
      case CallPhase.ended:
      case CallPhase.idle:
        return const SizedBox(height: 76);
    }
  }
}

class _RoundButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final Color iconColor;
  final VoidCallback onTap;
  final double size;

  const _RoundButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
    this.iconColor = Colors.white,
    this.size = 66,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: label,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: size,
              height: size,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              child: Icon(icon, color: iconColor, size: size * 0.45),
            ),
            const SizedBox(height: 8),
            Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFFE8E4EF))),
          ],
        ),
      ),
    );
  }
}

/// Layout de vídeo (Fase 13): vídeo remoto em tela cheia + miniatura da câmera local.
/// Antes de o remoto chegar (chamando/conectando) a própria câmera ocupa a tela, esmaecida.
class _VideoCall extends StatelessWidget {
  final CallManager m;
  final CallPhase phase;

  const _VideoCall({required this.m, required this.phase});

  @override
  Widget build(BuildContext context) {
    final remote = m.remoteVideo;
    final localFull = !remote && m.hasLocalVideo;
    const shadow = [Shadow(color: Color(0xCC000000), blurRadius: 6)];
    return Stack(
      fit: StackFit.expand,
      children: [
        if (remote)
          RTCVideoView(m.remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)
        else if (localFull)
          Opacity(
            opacity: m.camOff ? 0.12 : 0.55,
            child: RTCVideoView(m.localRenderer, mirror: m.frontCam, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
          ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            m.partnerName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Colors.white, shadows: shadow),
                          ),
                          const SizedBox(height: 2),
                          Semantics(
                            liveRegion: true,
                            child: Text(
                              m.status,
                              style: const TextStyle(
                                  fontSize: 14, color: Colors.white, shadows: shadow, fontFeatures: [FontFeature.tabularFigures()]),
                            ),
                          ),
                          if (m.warning != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text(m.warning!, style: TextStyle(fontSize: 12, color: AppColors.amber, shadows: shadow)),
                            ),
                        ],
                      ),
                    ),
                    if (remote && m.hasLocalVideo)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Container(
                          width: 104,
                          height: 148,
                          decoration: BoxDecoration(border: Border.all(color: Colors.white24, width: 2), borderRadius: BorderRadius.circular(14)),
                          child: Opacity(
                            opacity: m.camOff ? 0.25 : 1,
                            child: RTCVideoView(m.localRenderer,
                                mirror: m.frontCam, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
                          ),
                        ),
                      ),
                  ],
                ),
                if (!remote && !localFull) ...[
                  const Spacer(),
                  Center(child: _Avatar(name: m.partnerName, avatarUrl: m.partnerAvatar, pulse: false)),
                ],
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                  decoration: BoxDecoration(color: const Color(0x8C0A080E), borderRadius: BorderRadius.circular(24)),
                  child: phase == CallPhase.calling
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [_RoundButton(icon: Icons.call_end, label: 'Cancelar', color: AppColors.danger, onTap: m.hangup)],
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _RoundButton(
                              size: 56,
                              icon: m.muted ? Icons.mic_off : Icons.mic,
                              label: m.muted ? 'Ativar mic' : 'Mudo',
                              color: m.muted ? Colors.white : const Color(0xFF4A4556),
                              iconColor: m.muted ? const Color(0xFF222222) : Colors.white,
                              onTap: m.toggleMute,
                            ),
                            _RoundButton(
                              size: 56,
                              icon: m.camOff ? Icons.videocam_off : Icons.videocam,
                              label: m.camOff ? 'Ligar câmera' : 'Câmera',
                              color: m.camOff ? Colors.white : const Color(0xFF4A4556),
                              iconColor: m.camOff ? const Color(0xFF222222) : Colors.white,
                              onTap: m.toggleCamera,
                            ),
                            _RoundButton(
                              size: 56,
                              icon: Icons.cameraswitch,
                              label: 'Virar',
                              color: const Color(0xFF4A4556),
                              onTap: m.switchCamera,
                            ),
                            _RoundButton(
                              size: 56,
                              icon: m.speaker ? Icons.volume_up : Icons.volume_down,
                              label: 'Som',
                              color: m.speaker ? Colors.white : const Color(0xFF4A4556),
                              iconColor: m.speaker ? const Color(0xFF222222) : Colors.white,
                              onTap: m.toggleSpeaker,
                            ),
                            _RoundButton(size: 56, icon: Icons.call_end, label: 'Desligar', color: AppColors.danger, onTap: m.hangup),
                          ],
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
