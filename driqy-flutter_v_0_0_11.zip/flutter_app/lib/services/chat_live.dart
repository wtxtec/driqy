import 'dart:async';
import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;

import '../config.dart';
import 'api_client.dart';

/// Evento do chat em tempo real (Fase 9). `type`: ready, message, update, read,
/// read_self, delivered, typing, resync, prefs (Fase 10: fixar/silenciar/arquivar mudou) e
/// presence (Fase 10: online/visto por último). `partner` = @ do outro lado da conversa
/// (vazio em `prefs` quando é a minha privacidade que mudou).
class ChatEvent {
  final String type;
  final Map<String, dynamic> data;

  const ChatEvent(this.type, this.data);

  String? get partner => data['partner'] as String?;
  String? get state => data['state'] as String?;
  String? get kind => data['kind'] as String?;
  bool get online => data['online'] as bool? ?? false;
  bool get visible => data['visible'] as bool? ?? false;
  String? get lastSeenAt => data['last_seen_at'] as String?;

  // Fase 11 (chamadas): call_incoming | call_signal | call_state
  bool get isCallEvent => type == 'call_incoming' || type == 'call_signal' || type == 'call_state';
  int? get callId => (data['call_id'] as num?)?.toInt();
  String? get media => data['media'] as String?; // voice | video
  String? get reason => data['reason'] as String?;
  String? get by => data['by'] as String?;
  Map<String, dynamic>? get offer => data['offer'] as Map<String, dynamic>?;
  Map<String, dynamic>? get answer => data['answer'] as Map<String, dynamic>?;
  Map<String, dynamic>? get candidate => data['candidate'] as Map<String, dynamic>?;
}

/// Conexão SSE única do app com `GET /api/v1/messages/stream` (sem dependência
/// nova: `http` já faz streaming). Várias telas pedem com [acquire]/[release];
/// a conexão existe enquanto houver pelo menos uma tela interessada E o app
/// estiver em primeiro plano. Cai e volta sozinha (espera 1 s, dobra até 30 s).
/// Se o servidor não suportar (503/erro), [connected] fica falso e as telas
/// continuam no polling — nada quebra.
class ChatLive with WidgetsBindingObserver {
  ChatLive._();
  static final ChatLive instance = ChatLive._();

  final _controller = StreamController<ChatEvent>.broadcast();
  Stream<ChatEvent> get events => _controller.stream;

  final ValueNotifier<bool> connectedNotifier = ValueNotifier(false);
  bool get connected => connectedNotifier.value;

  int _refs = 0;
  ApiClient? _client;
  http.Client? _http;
  int _generation = 0;
  int _backoff = 1;
  bool _observing = false;
  bool _foreground = true;

  /// Uma tela passou a querer eventos. Chame [release] no `dispose`.
  void acquire(ApiClient client) {
    if (!_observing) {
      WidgetsBinding.instance.addObserver(this);
      _observing = true;
    }
    _refs++;
    if (_client?.token != client.token) {
      _client = client; // outro login: reconecta com o token novo
      _restart();
    } else if (_http == null) {
      _start();
    }
  }

  void release() {
    if (_refs > 0) _refs--;
    if (_refs == 0) _stop();
  }

  /// Logout: derruba a conexão e esquece o token.
  void reset() {
    _refs = 0;
    _client = null;
    _stop();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _foreground = true;
      if (_refs > 0 && _http == null) _start();
    } else if (state == AppLifecycleState.paused) {
      _foreground = false; // segundo plano: o push (FCM) cuida do aviso
      _stop();
    }
  }

  void _restart() {
    _stop();
    if (_refs > 0) _start();
  }

  void _stop() {
    _generation++;
    _http?.close();
    _http = null;
    _setConnected(false);
  }

  void _start() {
    if (_client == null || !_foreground || _refs == 0) return;
    final gen = ++_generation;
    _backoff = 1;
    _loop(gen);
  }

  void _setConnected(bool v) {
    if (connectedNotifier.value != v) connectedNotifier.value = v;
  }

  Future<void> _loop(int gen) async {
    while (gen == _generation && _refs > 0 && _client != null) {
      final http.Client httpClient = http.Client();
      _http = httpClient;
      try {
        final req = http.Request('GET', Uri.parse('$kApiBaseUrl/api/v1/messages/stream'))
          ..headers.addAll({
            ..._client!.authHeaders,
            'Accept': 'text/event-stream',
            'Cache-Control': 'no-cache',
          });
        final resp = await httpClient.send(req).timeout(const Duration(seconds: 20));
        if (resp.statusCode != 200) {
          // 401/403/503: não adianta martelar; espera mais antes de tentar de novo
          _backoff = 30;
          throw StateError('stream ${resp.statusCode}');
        }
        var event = 'message';
        final data = StringBuffer();
        final lines = resp.stream
            // o servidor manda ": ping" a cada 15 s; 45 s calado = conexão morta
            .timeout(const Duration(seconds: 45), onTimeout: (sink) => sink.close())
            .transform(utf8.decoder)
            .transform(const LineSplitter());
        await for (final line in lines) {
          if (gen != _generation) break;
          if (line.isEmpty) {
            if (data.isNotEmpty) _dispatch(event, data.toString());
            event = 'message';
            data.clear();
          } else if (line.startsWith('event:')) {
            event = line.substring(6).trim();
          } else if (line.startsWith('data:')) {
            if (data.isNotEmpty) data.write('\n');
            data.write(line.substring(5).trimLeft());
          } // ": ping" e "retry:" são ignorados
        }
      } catch (_) {
        // cai pro "reconectar" abaixo
      } finally {
        httpClient.close();
        if (identical(_http, httpClient)) _http = null;
      }
      _setConnected(false);
      if (gen != _generation) return;
      await Future<void>.delayed(Duration(seconds: _backoff));
      _backoff = _backoff >= 30 ? 30 : _backoff * 2;
    }
  }

  void _dispatch(String type, String raw) {
    Map<String, dynamic> data = const {};
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) data = decoded;
    } catch (_) {}
    if (type == 'ready') {
      _backoff = 1;
      _setConnected(true);
    }
    if (!_controller.isClosed) _controller.add(ChatEvent(type, data));
  }
}
