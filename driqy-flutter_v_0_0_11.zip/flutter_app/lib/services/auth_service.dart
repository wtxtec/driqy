import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user.dart';
import 'api_client.dart';
import 'chat_live.dart';
import 'push_notification_service.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

/// Estado de autenticação do app inteiro. Fica no topo da árvore de
/// widgets via Provider — qualquer tela pode ler o token/usuário atual
/// ou chamar login()/logout().
class AuthService extends ChangeNotifier {
  static const _tokenKey = 'driqy_token';

  String? _token;
  DriqyUser? _currentUser;
  AuthStatus _status = AuthStatus.unknown;

  String? get token => _token;
  DriqyUser? get currentUser => _currentUser;
  AuthStatus get status => _status;

  ApiClient get client => ApiClient(token: _token);

  /// Chamado uma vez ao abrir o app: tenta recuperar um token salvo e
  /// validar com o backend antes de decidir se mostra Login ou Feed.
  Future<void> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedToken = prefs.getString(_tokenKey);
    if (savedToken == null) {
      _status = AuthStatus.unauthenticated;
      notifyListeners();
      return;
    }
    _token = savedToken;
    try {
      final data = await client.get('/me');
      _currentUser = DriqyUser.fromJson(data);
      _status = AuthStatus.authenticated;
    } catch (_) {
      // token expirado/inválido: limpa e manda pro login
      await prefs.remove(_tokenKey);
      _token = null;
      _status = AuthStatus.unauthenticated;
    }
    notifyListeners();
  }

  Future<void> login({required String identifier, required String password}) async {
    final data = await ApiClient().post('/auth/login', body: {
      'username': identifier,
      'password': password,
    });
    await _persistSession(data);
  }

  Future<void> register({
    required String username,
    required String email,
    required String password,
  }) async {
    final data = await ApiClient().post('/auth/register', body: {
      'username': username,
      'email': email,
      'password': password,
    });
    await _persistSession(data);
  }

  Future<void> _persistSession(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    _token = data['token'] as String;
    _currentUser = DriqyUser.fromJson(data['user'] as Map<String, dynamic>);
    _status = AuthStatus.authenticated;
    await prefs.setString(_tokenKey, _token!);
    notifyListeners();
  }

  Future<void> logout() async {
    // Antes de derrubar o token de sessão, avisa o backend pra parar
    // de mandar push pra este aparelho nessa conta.
    await PushNotificationService.instance.unregisterDeviceToken(client);
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    ChatLive.instance.reset(); // derruba o stream do chat da conta que saiu
    _token = null;
    _currentUser = null;
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }

  /// Atualiza o usuário guardado em memória (ex: depois de editar perfil),
  /// sem precisar de um novo login.
  void updateCurrentUser(DriqyUser user) {
    _currentUser = user;
    notifyListeners();
  }
}
