import '../models/rail_extra.dart';
import '../models/rail_widgets.dart';
import '../models/user.dart';
import 'api_client.dart';

/// Rotas `/api/v1/widgets/*` do painel direito (as mesmas que o site usa).
/// 5A: lista de widgets e clima. 5B: em alta, notícias, Vortex, online e sugestões (estes
/// deixam a exceção subir, para o widget mostrar "Tentar de novo").
class WidgetsService {
  final ApiClient client;

  WidgetsService(this.client);

  /// Ids dos widgets que o servidor oferece, na ordem do seletor (`GET /widgets`).
  Future<List<String>> getWidgetIds() async {
    final data = await client.get('/widgets');
    final seen = <String>{};
    final ids = <String>[];
    for (final w in (data['widgets'] as List<dynamic>? ?? const [])) {
      final id = (w as Map<String, dynamic>)['id'] as String?;
      if (id != null && seen.add(id)) ids.add(id);
    }
    return ids;
  }

  /// Personalização do painel direito. Falha de rede -> null (vale o padrão).
  Future<RailPrefs?> getPrefs() async {
    try {
      final data = await client.get('/widgets/prefs');
      return RailPrefs.fromJson((data['prefs'] as Map<String, dynamic>?) ?? const {});
    } catch (_) {
      return null;
    }
  }

  /// Salva a personalização; devolve o que o servidor guardou, ou null se falhou.
  Future<RailPrefs?> savePrefs(RailPrefs prefs) async {
    try {
      final data = await client.post('/widgets/prefs', body: prefs.toJson());
      return RailPrefs.fromJson((data['prefs'] as Map<String, dynamic>?) ?? prefs.toJson());
    } catch (_) {
      return null;
    }
  }

  /// Clima da cidade do perfil, ou de [region] (escolhida no widget). Qualquer falha vira `unavailable`.
  Future<WeatherResult> getWeather({PlaceSuggestion? region}) async {
    try {
      final data = await client.get('/widgets/weather', query: {
        if (region != null) ...{'lat': region.latitude, 'lng': region.longitude, 'name': region.label},
      });
      return WeatherResult.fromJson(data);
    } catch (_) {
      return const WeatherResult.unavailable();
    }
  }

  /// Sugestões de cidade/estado/país para [query] (2+ letras). Falha de rede -> lista vazia.
  Future<List<PlaceSuggestion>> searchPlaces(String query) async {
    if (query.trim().length < 2) return const [];
    try {
      final data = await client.get('/places/search', query: {'q': query.trim()});
      return [
        for (final e in (data['places'] as List<dynamic>? ?? const []))
          PlaceSuggestion.fromJson(e as Map<String, dynamic>),
      ];
    } catch (_) {
      return const [];
    }
  }

  List<T> _list<T>(Map<String, dynamic> data, String key, T Function(Map<String, dynamic>) parse) => [
        for (final e in (data[key] as List<dynamic>? ?? const [])) parse(e as Map<String, dynamic>),
      ];

  Future<List<TrendingPost>> getTrending() async =>
      _list(await client.get('/widgets/trending'), 'posts', TrendingPost.fromJson);

  /// [limit] (1..12, padrão 4): quantas manchetes pedir; o painel pede mais para repor as dispensadas.
  Future<List<NewsHeadline>> getNews({int limit = 4}) async =>
      _list(await client.get('/widgets/news?limit=$limit'), 'articles', NewsHeadline.fromJson);

  Future<List<VortexPreviewItem>> getVortex() async =>
      _list(await client.get('/widgets/vortex'), 'items', VortexPreviewItem.fromJson);

  Future<OnlineResult> getOnline() async => OnlineResult.fromJson(await client.get('/widgets/online'));

  /// Sugestões de quem seguir. [exclude]: usernames já mostrados (o servidor aceita até 50).
  Future<List<SuggestedUser>> getSuggestions({int limit = 5, List<String> exclude = const []}) async {
    final data = await client.get('/widgets/suggestions', query: {
      'limit': limit,
      if (exclude.isNotEmpty) 'exclude': exclude.take(50).join(','),
    });
    return _list(data, 'users', SuggestedUser.fromJson);
  }

  // ------------------------------------------------------------------ Minha área (widgets próprios)

  /// Widgets próprios, tipos e limite. Falha de rede -> catálogo vazio (o painel segue sem os próprios).
  Future<CustomCatalog> getCustomCatalog() async {
    try {
      return CustomCatalog.fromJson(await client.get('/widgets/custom'));
    } catch (_) {
      return const CustomCatalog();
    }
  }

  /// Um widget próprio com o conteúdo. Deixa a exceção subir (o widget mostra "Tentar de novo").
  Future<CustomWidget> getCustom(int id) async =>
      CustomWidget.fromJson((await client.get('/widgets/custom/$id'))['widget'] as Map<String, dynamic>);

  /// Cria um widget próprio (vazio). Erros do servidor (limite, tipo) sobem como [ApiException].
  Future<CustomWidget> createCustom(String kind, {String? title}) async {
    final data = await client.post('/widgets/custom', body: {'kind': kind, if (title != null) 'title': title});
    return CustomWidget.fromJson(data['widget'] as Map<String, dynamic>);
  }

  /// Salva título e/ou conteúdo. Devolve o que o servidor guardou (já normalizado).
  Future<CustomWidget> updateCustom(int id, {String? title, Map<String, dynamic>? data}) async {
    final res = await client.put('/widgets/custom/$id', body: {
      if (title != null) 'title': title,
      if (data != null) 'data': data,
    });
    return CustomWidget.fromJson(res['widget'] as Map<String, dynamic>);
  }

  Future<void> deleteCustom(int id) async {
    await client.delete('/widgets/custom/$id');
  }

  // ------------------------------------------------------------------ os 7 widgets novos do servidor

  /// Relógio mundial. [zones]: ids escolhidos (até 6); vazio = as cidades padrão do servidor.
  /// Falha de rede sobe (o widget mostra "Tentar de novo"); `ok: false` = base de fusos indisponível.
  Future<ClockResult> getClock({List<String> zones = const []}) async => ClockResult.fromJson(
        await client.get('/widgets/clock', query: {if (zones.isNotEmpty) 'zones': zones.take(6).join(',')}),
      );

  /// Mês do calendário com feriados; sem [year]/[month] vem o mês de hoje.
  /// O "hoje" é o do fuso do aparelho (`tz_offset` em minutos), onde o usuário estiver.
  /// [country]: país dos feriados escolhido pelo usuário (vazio/nulo = automático).
  Future<CalendarMonth> getCalendar({int? year, int? month, String? country}) async => CalendarMonth.fromJson(
        await client.get('/widgets/calendar', query: {
          if (year != null && month != null) ...{'year': year, 'month': month},
          'tz_offset': DateTime.now().timeZoneOffset.inMinutes,
          if (country != null && RegExp(r'^[A-Za-z]{2}$').hasMatch(country)) 'country': country,
        }),
      );

  /// Fase da Lua; os horários (nascer/pôr, eclipses) vêm no fuso do aparelho (`tz_offset`, em minutos).
  Future<MoonInfo> getMoon() async =>
      MoonInfo.fromJson(await client.get('/widgets/moon', query: {'tz_offset': DateTime.now().timeZoneOffset.inMinutes}));

  /// Estações do ano: atual, progresso, as 4 do ciclo e o aviso de virada (hemisfério pelo perfil).
  /// Datas e horas das estações no fuso do aparelho (`tz_offset`).
  Future<SeasonInfo> getSeasons() async => SeasonInfo.fromJson(
      await client.get('/widgets/seasons', query: {'tz_offset': DateTime.now().timeZoneOffset.inMinutes}));

  /// Cotações. Qualquer falha vira `unavailable` (o widget decide se mantém o que já mostrava).
  Future<QuotesResult> getQuotes() async {
    try {
      return QuotesResult.fromJson(await client.get('/widgets/quotes'));
    } catch (_) {
      return const QuotesResult.unavailable();
    }
  }

  Future<StatsInfo> getStats() async => StatsInfo.fromJson(await client.get('/widgets/stats'));

  Future<List<ExpiringPost>> getExpiring() async => _list(await client.get('/widgets/expiring'), 'posts', ExpiringPost.fromJson);

  Future<PhraseInfo> getPhrase() async => PhraseInfo.fromJson(await client.get('/widgets/phrase'));
}
