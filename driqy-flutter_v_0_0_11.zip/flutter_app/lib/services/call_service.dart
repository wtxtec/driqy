import '../models/call.dart';
import 'api_client.dart';

/// Fase 11: cliente REST da sinalização de chamadas (`/api/v1/calls/...`).
/// A UI e o WebRTC (`flutter_webrtc`) estão em `call_manager.dart`/`call_screen.dart` (Fase 12).
/// Eventos ao vivo (`call_incoming`, `call_signal`, `call_state`) chegam por
/// [ChatLive.events]. Ao abrir o app/conectar, chame [active] para retomar.
class CallService {
  final ApiClient client;

  CallService(this.client);

  Future<CallConfig> getConfig() async => CallConfig.fromJson(await client.get('/calls/config'));

  Future<DriqyCall?> active() async {
    final data = await client.get('/calls/active');
    final c = data['call'];
    return c == null ? null : DriqyCall.fromJson(Map<String, dynamic>.from(c as Map));
  }

  Future<List<DriqyCall>> history({int limit = 30, int? beforeId}) async {
    final data = await client.get('/calls', query: {
      'limit': limit,
      if (beforeId != null) 'before_id': beforeId,
    });
    return [
      for (final c in (data['calls'] as List? ?? const []))
        DriqyCall.fromJson(Map<String, dynamic>.from(c as Map)),
    ];
  }

  /// 409 → `ApiException` (code `busy` = o outro está em chamada; `already_in_call` = eu estou).
  Future<DriqyCall> start(String username, CallMedia media, String offerSdp, {String? clientId}) async {
    final data = await client.post('/calls/$username', body: {
      'media': media == CallMedia.video ? 'video' : 'voice',
      'offer': {'type': 'offer', 'sdp': offerSdp},
      if (clientId != null) 'client_id': clientId,
    });
    return DriqyCall.fromJson(data);
  }

  Future<DriqyCall> get(int id) async => DriqyCall.fromJson(await client.get('/calls/$id'));

  Future<DriqyCall> answer(int id, String answerSdp) async => DriqyCall.fromJson(
        await client.post('/calls/$id/answer', body: {
          'answer': {'type': 'answer', 'sdp': answerSdp},
        }),
      );

  Future<DriqyCall> decline(int id) async => DriqyCall.fromJson(await client.post('/calls/$id/decline'));

  /// `error: true` = a mídia não conectou (o servidor grava `failed`/`error`); só vale com a chamada aceita.
  Future<DriqyCall> end(int id, {bool error = false}) async => DriqyCall.fromJson(
        await client.post('/calls/$id/end', body: error ? {'reason': 'error'} : null),
      );

  /// `candidate` = `RTCIceCandidate.toMap()`; `null` = fim dos candidatos.
  Future<void> sendIce(int id, Map<String, dynamic>? candidate) async {
    await client.post('/calls/$id/ice', body: {'candidate': candidate});
  }

  /// Sinal de vida a cada `CallConfig.pingSeconds` enquanto a chamada está aceita.
  Future<CallState> ping(int id) async {
    final data = await client.post('/calls/$id/ping');
    return parseCallState(data['state'] as String?);
  }
}
