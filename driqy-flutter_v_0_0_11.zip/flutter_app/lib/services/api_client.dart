import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart' show MediaType;

import '../config.dart';
import 'api_exception.dart';

/// Fina camada sobre `http`, cuidando de:
/// - montar a URL a partir de [kApiBaseUrl]
/// - anexar o header Authorization quando há token
/// - decodificar JSON e transformar erros em [ApiException]
class ApiClient {
  final String? token;

  ApiClient({this.token});

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  /// Só o Authorization — para `Image.network`/`VideoPlayerController`, que
  /// precisam do header ao baixar mídia privada (chat).
  Map<String, String> get authHeaders => {
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    return Uri.parse('$kApiBaseUrl/api/v1$path').replace(
      queryParameters: query?.map((k, v) => MapEntry(k, v.toString())),
    );
  }

  dynamic _decode(http.Response response) {
    Map<String, dynamic>? body;
    try {
      body = response.body.isNotEmpty
          ? jsonDecode(response.body) as Map<String, dynamic>
          : null;
    } catch (_) {
      body = null;
    }

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return body;
    }

    final message = body?['error'] as String? ?? 'Erro inesperado (${response.statusCode})';
    throw ApiException(response.statusCode, message, code: body?['code'] as String?);
  }

  Future<Map<String, dynamic>> get(String path, {Map<String, dynamic>? query}) async {
    final response = await http.get(_uri(path, query), headers: _headers);
    return _decode(response) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> post(String path, {Map<String, dynamic>? body}) async {
    final response = await http.post(
      _uri(path),
      headers: _headers,
      body: body != null ? jsonEncode(body) : null,
    );
    return _decode(response) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> put(String path, {Map<String, dynamic>? body}) async {
    final response = await http.put(
      _uri(path),
      headers: _headers,
      body: body != null ? jsonEncode(body) : null,
    );
    return _decode(response) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> patch(String path, {Map<String, dynamic>? body}) async {
    final response = await http.patch(
      _uri(path),
      headers: _headers,
      body: body != null ? jsonEncode(body) : null,
    );
    return _decode(response) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> delete(String path) async {
    final response = await http.delete(_uri(path), headers: _headers);
    return _decode(response) as Map<String, dynamic>;
  }

  /// POST multipart/form-data, usado para criar posts com fotos/vídeos.
  /// [fields] vira campos de formulário comuns (post_type, text_content,
  /// duration_minutes); [files] vira arquivos anexados sob o campo
  /// `media_files` (pode ser mais de um). [namedFiles] serve para campos
  /// de arquivo único com nome próprio, tipo `avatar_file`/`cover_file`
  /// na edição de perfil.
  Future<Map<String, dynamic>> postMultipart(
    String path, {
    Map<String, String>? fields,
    List<File> files = const [],
    Map<String, File>? namedFiles,
  }) async {
    final request = http.MultipartRequest('POST', _uri(path));
    if (token != null) request.headers['Authorization'] = 'Bearer $token';
    if (fields != null) request.fields.addAll(fields);
    for (final file in files) {
      // O servidor decide o tipo (foto/gif/vídeo) pela extensão do NOME do
      // arquivo. Caminhos temporários (galeria/Photo Picker) podem vir sem
      // extensão, e aí o GIF era recusado ou virava foto estática — por
      // isso o nome é garantido aqui, lendo os primeiros bytes se preciso.
      request.files.add(await http.MultipartFile.fromPath(
        'media_files',
        file.path,
        filename: await _uploadFilename(file),
      ));
    }
    if (namedFiles != null) {
      for (final entry in namedFiles.entries) {
        // O servidor valida a extensão do NOME do arquivo enviado
        // (png/jpg/jpeg/webp). Caminhos temporários do Android/iOS podem
        // vir sem extensão ou com uma extensão estranha — era isso que
        // quebrava o upload da foto de perfil. Por isso o nome e o
        // content-type são sempre definidos explicitamente aqui.
        final path = entry.value.path;
        final dot = path.lastIndexOf('.');
        var ext = dot >= 0 ? path.substring(dot + 1).toLowerCase() : '';
        if (!const {'png', 'jpg', 'jpeg', 'webp'}.contains(ext)) ext = 'jpg';
        final subtype = ext == 'jpg' ? 'jpeg' : ext;
        request.files.add(await http.MultipartFile.fromPath(
          entry.key,
          path,
          filename: '${entry.key == 'avatar_file' ? 'avatar' : 'capa'}.$ext',
          contentType: MediaType('image', subtype),
        ));
      }
    }
    final streamed = await request.send();
    final response = await http.Response.fromStream(streamed);
    return _decode(response) as Map<String, dynamic>;
  }

  /// POST multipart com UM arquivo (campo [field], padrão `file`) — usado
  /// pelo chat (imagem agora; áudio e vídeo nas próximas fases). O nome do
  /// arquivo sempre sai com extensão válida (ver [_uploadFilename]).
  Future<Map<String, dynamic>> postFile(
    String path, {
    required File file,
    String field = 'file',
    Map<String, String>? fields,
    File? thumb, // miniatura JPEG de vídeo (campo `thumb`, opcional)
    String? filename, // Fase 15: nome original do documento (senão usa o do caminho)
  }) async {
    final request = http.MultipartRequest('POST', _uri(path));
    if (token != null) request.headers['Authorization'] = 'Bearer $token';
    if (fields != null) request.fields.addAll(fields);
    final name = filename ?? await _uploadFilename(file);
    final ext = name.split('.').last.toLowerCase();
    const imageExts = {'png', 'jpg', 'jpeg', 'webp', 'gif'};
    const videoTypes = {
      'mp4': 'video/mp4',
      'webm': 'video/webm',
      'mov': 'video/quicktime',
    };
    const audioTypes = {
      'm4a': 'audio/mp4',
      'ogg': 'audio/ogg',
      'mp3': 'audio/mpeg',
      'wav': 'audio/wav',
    };
    request.files.add(await http.MultipartFile.fromPath(
      field,
      file.path,
      filename: name,
      // o servidor confere o tipo pelos bytes; isto é só o rótulo do upload
      contentType: imageExts.contains(ext)
          ? MediaType('image', ext == 'jpg' ? 'jpeg' : ext)
          : (audioTypes[ext] ?? videoTypes[ext]) != null
              ? MediaType.parse((audioTypes[ext] ?? videoTypes[ext])!)
              : null,
    ));
    if (thumb != null) {
      request.files.add(await http.MultipartFile.fromPath(
        'thumb',
        thumb.path,
        filename: 'thumb.jpg',
        contentType: MediaType('image', 'jpeg'),
      ));
    }
    final streamed = await request.send();
    final response = await http.Response.fromStream(streamed);
    return _decode(response) as Map<String, dynamic>;
  }

  static const _knownExts = {
    'png', 'jpg', 'jpeg', 'webp', 'gif', 'mp4', 'webm', 'mov',
    'm4a', 'ogg', 'mp3', 'wav', // áudio (Fase 5)
    'pdf', 'txt', 'csv', 'json', 'zip', 'rtf', 'doc', 'docx', 'xls', 'xlsx', // documentos (Fase 15)
    'ppt', 'pptx', 'odt', 'ods', 'odp', 'heic', 'heif',
  };

  /// Nome de upload com extensão válida: usa a do caminho quando é
  /// conhecida; senão identifica o formato pelos bytes iniciais.
  Future<String> _uploadFilename(File file) async {
    final path = file.path;
    final base = path.split(RegExp(r'[\\/]')).last;
    final dot = base.lastIndexOf('.');
    final ext = dot >= 0 ? base.substring(dot + 1).toLowerCase() : '';
    if (_knownExts.contains(ext)) return base;
    final head = await file.openRead(0, 16).fold<List<int>>([], (a, b) => a..addAll(b));
    String guessed = 'jpg';
    if (head.length >= 6 && String.fromCharCodes(head.sublist(0, 4)) == 'GIF8') {
      guessed = 'gif';
    } else if (head.length >= 4 && head[0] == 0x89 && head[1] == 0x50) {
      guessed = 'png';
    } else if (head.length >= 12 &&
        String.fromCharCodes(head.sublist(0, 4)) == 'RIFF' &&
        String.fromCharCodes(head.sublist(8, 12)) == 'WEBP') {
      guessed = 'webp';
    } else if (head.length >= 12 && String.fromCharCodes(head.sublist(4, 8)) == 'ftyp') {
      guessed = 'mp4';
    } else if (head.length >= 4 && head[0] == 0x1A && head[1] == 0x45) {
      guessed = 'webm';
    }
    return '${base.isEmpty ? 'media' : base}.$guessed';
  }
}
