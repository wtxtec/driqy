/// Erro vindo da API (ex: {"error": "Usuário/senha incorretos"}), com o
/// código HTTP junto para quem quiser tratar 401/403 de forma diferente.
class ApiException implements Exception {
  final int statusCode;
  final String message;

  /// Código de máquina opcional (ex.: `busy`, `already_in_call` nas chamadas — Fase 12).
  final String? code;

  ApiException(this.statusCode, this.message, {this.code});

  @override
  String toString() => message;
}
