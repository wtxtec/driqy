import '../models/user.dart';
import 'api_client.dart';

class SearchService {
  final ApiClient client;

  SearchService(this.client);

  Future<List<DriqyUser>> searchUsers(String query) async {
    if (query.trim().isEmpty) return [];
    final data = await client.get('/search', query: {'q': query.trim()});
    return (data['users'] as List<dynamic>)
        .map((u) => DriqyUser.fromJson(u as Map<String, dynamic>))
        .toList();
  }
}
