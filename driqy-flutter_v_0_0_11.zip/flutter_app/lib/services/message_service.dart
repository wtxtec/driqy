import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../config.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../models/presence.dart';
import '../models/user.dart';
import 'api_client.dart';

/// Mensagem fixada no topo da conversa (Ping fase 6b; vale só para mim).
class DriqyPinned {
  final int id;
  final String preview;

  const DriqyPinned({required this.id, required this.preview});

  static DriqyPinned? fromJson(Map<String, dynamic>? json) {
    if (json == null) return null;
    final id = json['id'] as int?;
    if (id == null) return null;
    return DriqyPinned(id: id, preview: json['preview'] as String? ?? '');
  }
}

class MessageThread {
  final DriqyUser partner;
  final List<DriqyMessage> messages;
  final DriqyPresence presence; // Fase 10
  final DriqyChatPrefs prefs; // Fase 10
  final DriqyPinned? pinned; // Ping fase 6b

  MessageThread({
    required this.partner,
    required this.messages,
    this.presence = DriqyPresence.hidden,
    this.prefs = const DriqyChatPrefs(),
    this.pinned,
  });
}

/// Caixa de entrada (Fase 10): lista + quantas conversas estão arquivadas.
class InboxPage {
  final List<DriqyConversation> conversations;
  final int archivedCount;

  const InboxPage({required this.conversations, required this.archivedCount});
}

class ChatSearchResult {
  final int total;
  final bool hasMore;
  final List<DriqyMessage> messages; // mais recentes primeiro

  const ChatSearchResult({required this.total, required this.hasMore, required this.messages});
}

class MessageService {
  final ApiClient client;

  MessageService(this.client);

  /// [all]: inclui as arquivadas (usado pela tela de encaminhar).
  Future<List<DriqyConversation>> getInbox({bool all = false}) async =>
      (await getInboxPage(all: all)).conversations;

  /// Fixadas primeiro (o servidor já ordena). [archived] lista só o arquivo.
  Future<InboxPage> getInboxPage({bool archived = false, bool all = false}) async {
    final data = await client.get('/messages',
        query: all ? {'archived': 'all'} : (archived ? {'archived': '1'} : null));
    return InboxPage(
      conversations: (data['conversations'] as List<dynamic>)
          .map((c) => DriqyConversation.fromJson(c as Map<String, dynamic>))
          .toList(),
      archivedCount: data['archived_count'] as int? ?? 0,
    );
  }

  /// Fixar / silenciar / arquivar (só para mim). Só os campos informados mudam.
  /// Lança [ApiException] se passar do limite de fixadas.
  Future<DriqyChatPrefs> setConversationPrefs(
    String username, {
    bool? pinned,
    bool? muted,
    bool? archived,
  }) async {
    final data = await client.put('/messages/$username/prefs', body: {
      if (pinned != null) 'pinned': pinned,
      if (muted != null) 'muted': muted,
      if (archived != null) 'archived': archived,
    });
    return DriqyChatPrefs.fromJson(data);
  }

  /// Mostrar online / visto por último (quem esconde também deixa de ver o dos outros).
  Future<bool> getShowPresence() async {
    final data = await client.get('/messages/privacy');
    return data['show_presence'] as bool? ?? true;
  }

  Future<bool> setShowPresence(bool value) async {
    final data = await client.put('/messages/privacy', body: {'show_presence': value});
    return data['show_presence'] as bool? ?? value;
  }

  /// Ping fase 6b: fixa a mensagem [messageId] no topo da conversa (null = desafixa).
  /// Só para mim; uma por conversa (fixar outra substitui). Devolve o estado final.
  Future<DriqyPinned?> setPinnedMessage(String username, int? messageId) async {
    final data = messageId == null
        ? await client.delete('/messages/$username/pin')
        : await client.put('/messages/$username/pin', body: {'message_id': messageId});
    return DriqyPinned.fromJson(data['pinned_message'] as Map<String, dynamic>?);
  }

  Future<MessageThread> getThread(String username) async {
    final data = await client.get('/messages/$username');
    return MessageThread(
      presence: DriqyPresence.fromJson(
          (data['partner'] as Map<String, dynamic>)['presence'] as Map<String, dynamic>?),
      prefs: DriqyChatPrefs.fromJson(data['prefs'] as Map<String, dynamic>?),
      pinned: DriqyPinned.fromJson(data['pinned_message'] as Map<String, dynamic>?),
      partner: DriqyUser.fromJson(data['partner'] as Map<String, dynamic>),
      messages: (data['messages'] as List<dynamic>)
          .map((m) => DriqyMessage.fromJson(m as Map<String, dynamic>))
          .toList(),
    );
  }

  /// `clientId` torna o reenvio seguro: o servidor devolve a mesma
  /// mensagem em vez de criar outra.
  Future<DriqyMessage> sendMessage(
    String username,
    String content, {
    String? clientId,
    int? replyToId,
  }) async {
    final data = await client.post('/messages/$username', body: {
      'content': content,
      if (clientId != null) 'client_id': clientId,
      if (replyToId != null) 'reply_to_id': replyToId,
    });
    return DriqyMessage.fromJson(data);
  }

  /// Envia uma imagem/GIF (multipart). [caption] vira a legenda; [width] e
  /// [height] deixam o servidor devolver a proporção (a bolha reserva o
  /// espaço certo antes de a imagem carregar).
  Future<DriqyMessage> sendImage(
    String username,
    File file, {
    String caption = '',
    String? clientId,
    int? width,
    int? height,
    int? replyToId,
    bool viewOnce = false,
  }) async {
    final data = await client.postFile(
      '/messages/$username',
      file: file,
      fields: {
        if (viewOnce) 'view_once': '1',
        if (caption.isNotEmpty && !viewOnce) 'content': caption,
        if (clientId != null) 'client_id': clientId,
        if (width != null) 'width': '$width',
        if (height != null) 'height': '$height',
        if (replyToId != null) 'reply_to_id': '$replyToId',
      },
    );
    return DriqyMessage.fromJson(data);
  }

  /// Envia uma mensagem de voz (multipart). [durationMs] é medido no app
  /// (o servidor não decodifica o áudio) e alimenta a duração da bolha.
  Future<DriqyMessage> sendAudio(
    String username,
    File file, {
    required int durationMs,
    String? clientId,
    int? replyToId,
    bool viewOnce = false,
  }) async {
    final data = await client.postFile(
      '/messages/$username',
      file: file,
      fields: {
        if (viewOnce) 'view_once': '1',
        'duration_ms': '$durationMs',
        if (clientId != null) 'client_id': clientId,
        if (replyToId != null) 'reply_to_id': '$replyToId',
      },
    );
    return DriqyMessage.fromJson(data);
  }

  /// Envia um vídeo (multipart). [durationMs]/[width]/[height] vêm do player
  /// local; [thumb] (JPEG, opcional) vira a miniatura da bolha no destino.
  Future<DriqyMessage> sendVideo(
    String username,
    File file, {
    required int durationMs,
    String caption = '',
    int? width,
    int? height,
    File? thumb,
    String? clientId,
    int? replyToId,
    bool viewOnce = false,
  }) async {
    final data = await client.postFile(
      '/messages/$username',
      file: file,
      thumb: viewOnce ? null : thumb,
      fields: {
        if (viewOnce) 'view_once': '1',
        'duration_ms': '$durationMs',
        if (caption.isNotEmpty && !viewOnce) 'content': caption,
        if (clientId != null) 'client_id': clientId,
        if (width != null) 'width': '$width',
        if (height != null) 'height': '$height',
        if (replyToId != null) 'reply_to_id': '$replyToId',
      },
    );
    return DriqyMessage.fromJson(data);
  }

  /// Envia um documento (Fase 15). [name] = nome original que o destinatário vai ver.
  Future<DriqyMessage> sendFile(
    String username,
    File file, {
    required String name,
    String caption = '',
    String? clientId,
    int? replyToId,
  }) async {
    final data = await client.postFile(
      '/messages/$username',
      file: file,
      filename: name,
      fields: {
        if (caption.isNotEmpty) 'content': caption,
        if (clientId != null) 'client_id': clientId,
        if (replyToId != null) 'reply_to_id': '$replyToId',
      },
    );
    return DriqyMessage.fromJson(data);
  }

  /// Baixa o documento (com Bearer) para a pasta temporária e devolve o arquivo.
  /// O nome é o original (sem barras), dentro de uma subpasta por mensagem.
  Future<File> downloadFile(DriqyMessage m) async {
    final url = m.mediaUrl;
    if (url == null) throw StateError('sem url');
    final res = await http.get(Uri.parse(resolveMediaUrl(url)), headers: client.authHeaders);
    if (res.statusCode != 200) {
      throw StateError('download falhou (${res.statusCode})');
    }
    final safe = (m.mediaName ?? 'arquivo').replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final dir = Directory('${(await getTemporaryDirectory()).path}/driqy_files/${m.id}');
    await dir.create(recursive: true);
    final out = File('${dir.path}/$safe');
    await out.writeAsBytes(res.bodyBytes, flush: true);
    return out;
  }

  /// Headers para baixar a mídia privada (`media_url`) do chat.
  Map<String, String> get mediaHeaders => client.authHeaders;

  /// Reage com [emoji] (troca a reação anterior, se houver).
  Future<List<DriqyReaction>> reactToMessage(int messageId, String emoji) async {
    final data = await client.put('/messages/$messageId/reaction', body: {'emoji': emoji});
    return _parseReactions(data);
  }

  Future<List<DriqyReaction>> removeReaction(int messageId) async {
    final data = await client.delete('/messages/$messageId/reaction');
    return _parseReactions(data);
  }

  List<DriqyReaction> _parseReactions(Map<String, dynamic> data) =>
      (data['reactions'] as List<dynamic>? ?? const [])
          .map((r) => DriqyReaction.fromJson(r as Map<String, dynamic>))
          .toList();

  /// Apaga uma mensagem. [forAll] = true: "apagar para todos" (só o remetente,
  /// dentro da janela do servidor) e devolve a mensagem já como apagada.
  /// [forAll] = false: "apagar para mim" — devolve null (o app só a remove).
  /// Abre UMA vez uma mensagem de visualização única. Lança [ApiException] (410) se já foi aberta,
  /// venceu ou foi apagada. A URL devolvida só vale por alguns minutos.
  Future<ViewOnceMedia> openViewOnce(int messageId) async {
    final data = await client.post('/messages/$messageId/view-once', body: {});
    return ViewOnceMedia.fromJson(data);
  }

  /// Ao fechar o visualizador: o servidor apaga a mídia na hora. Falha de rede não importa —
  /// a janela de alguns minutos e a limpeza periódica apagam do mesmo jeito.
  Future<void> closeViewOnce(int messageId) async {
    try {
      await client.post('/messages/$messageId/view-once/close', body: {});
    } catch (_) {}
  }

  Future<DriqyMessage?> deleteMessage(int messageId, {required bool forAll}) async {
    final data = await client.delete('/messages/$messageId?scope=${forAll ? 'all' : 'me'}');
    if (!forAll) return null;
    return DriqyMessage.fromJson(data['message'] as Map<String, dynamic>);
  }

  /// Edita o texto de uma mensagem minha (Fase 8). Devolve a mensagem já com
  /// `edited_at` e as reações atuais. Erros (janela vencida, não é texto…) viram
  /// `ApiException` com a mensagem do servidor.
  Future<DriqyMessage> editMessage(int messageId, String content) async {
    final data = await client.patch('/messages/$messageId', body: {'content': content});
    return DriqyMessage.fromJson(data);
  }

  /// Encaminha [messageId] para até 5 conversas (Fase 8). A mídia é copiada no
  /// servidor — o app não reenvia o arquivo. [clientId] torna o reenvio seguro.
  /// Devolve as mensagens criadas, na ordem de [usernames].
  Future<List<DriqyMessage>> forwardMessage(
    int messageId,
    List<String> usernames, {
    String? clientId,
  }) async {
    final data = await client.post('/messages/$messageId/forward', body: {
      'usernames': usernames,
      if (clientId != null) 'client_id': clientId,
    });
    return (data['forwarded'] as List<dynamic>? ?? const [])
        .map((e) => DriqyMessage.fromJson((e as Map<String, dynamic>)['message'] as Map<String, dynamic>))
        .toList();
  }

  /// Busca na conversa (Fase 8): sem acento e sem diferenciar maiúsculas, mais
  /// recentes primeiro. [query] precisa de 2+ caracteres.
  Future<ChatSearchResult> searchThread(String username, String query, {int limit = 100}) async {
    final data = await client.get('/messages/$username/search',
        query: {'q': query, 'limit': '$limit'});
    return ChatSearchResult(
      total: data['total'] as int? ?? 0,
      hasMore: data['has_more'] as bool? ?? false,
      messages: (data['results'] as List<dynamic>? ?? const [])
          .map((m) => DriqyMessage.fromJson(m as Map<String, dynamic>))
          .toList(),
    );
  }

  /// "digitando…" (Fase 9). [state]: typing | recording | stop. Falha em silêncio:
  /// é só um aviso, nunca deve atrapalhar a conversa.
  Future<void> sendTyping(String username, String state) async {
    try {
      await client.post('/messages/$username/typing', body: {'state': state});
    } catch (_) {}
  }

  Future<int> getUnreadCount() async {
    final data = await client.get('/messages/unread-count');
    return data['unread'] as int? ?? 0;
  }
}


/// Resposta de `POST /messages/<id>/view-once`: onde buscar a mídia (uma vez).
class ViewOnceMedia {
  final String mediaUrl;
  final String? mediaMime;
  final int? width;
  final int? height;
  final int? durationMs;

  const ViewOnceMedia({required this.mediaUrl, this.mediaMime, this.width, this.height, this.durationMs});

  factory ViewOnceMedia.fromJson(Map<String, dynamic> j) => ViewOnceMedia(
        mediaUrl: j['media_url'] as String,
        mediaMime: j['media_mime'] as String?,
        width: j['media_width'] as int?,
        height: j['media_height'] as int?,
        durationMs: j['media_duration_ms'] as int?,
      );
}
