import 'dart:io';

import '../models/chat_group.dart';
import '../models/presence.dart';
import 'api_client.dart';

class GroupInbox {
  final List<DriqyGroup> groups;
  final int archivedCount;
  const GroupInbox({required this.groups, required this.archivedCount});
}

class GroupMessagesPage {
  final List<DriqyGroupMessage> messages;
  final bool hasMore;
  const GroupMessagesPage({required this.messages, required this.hasMore});
}

/// Grupos (Mensagens parte 4) — usa a API `/groups…` da parte 3.
class GroupService {
  final ApiClient client;
  GroupService(this.client);

  DriqyGroup _g(Map<String, dynamic> d) => DriqyGroup.fromJson(d['group'] as Map<String, dynamic>);

  Future<GroupInbox> list({bool archived = false}) async {
    final d = await client.get('/groups', query: archived ? {'arquivadas': '1'} : null);
    return GroupInbox(
      groups: (d['groups'] as List<dynamic>).map((g) => DriqyGroup.fromJson(g as Map<String, dynamic>)).toList(),
      archivedCount: d['archived_count'] as int? ?? 0,
    );
  }

  Future<DriqyGroup> create(String name, List<String> usernames, {String description = ''}) async =>
      _g(await client.post('/groups', body: {'name': name, 'description': description, 'members': usernames}));

  Future<DriqyGroup> detail(int id) async => _g(await client.get('/groups/$id'));

  Future<DriqyGroup> update(int id, {String? name, String? description}) async => _g(await client.put('/groups/$id', body: {
        if (name != null) 'name': name,
        if (description != null) 'description': description,
      }));

  Future<void> deleteGroup(int id) async {
    await client.delete('/groups/$id');
  }

  Future<DriqyGroup> setAvatar(int id, File file) async =>
      _g(await client.postFile('/groups/$id/avatar', file: file, fields: const {}));

  Future<DriqyGroup> removeAvatar(int id) async => _g(await client.delete('/groups/$id/avatar'));

  Future<DriqyGroup> addMembers(int id, List<String> usernames) async =>
      _g(await client.post('/groups/$id/members', body: {'usernames': usernames}));

  Future<DriqyGroup> removeMember(int id, String username) async =>
      _g(await client.delete('/groups/$id/members/$username'));

  Future<DriqyGroup> setRole(int id, String username, String role) async =>
      _g(await client.put('/groups/$id/members/$username', body: {'role': role}));

  Future<void> leave(int id) async {
    await client.post('/groups/$id/leave');
  }

  Future<GroupMessagesPage> messages(int id, {int? before, int? after, int limit = 50}) async {
    final d = await client.get('/groups/$id/messages', query: {
      'limit': '$limit',
      if (before != null) 'before': '$before',
      if (after != null) 'after': '$after',
    });
    return GroupMessagesPage(
      messages: (d['messages'] as List<dynamic>).map((m) => DriqyGroupMessage.fromJson(m as Map<String, dynamic>)).toList(),
      hasMore: d['has_more'] as bool? ?? false,
    );
  }

  Future<DriqyGroupMessage> send(int id, String content, {String? clientId, int? replyToId}) async {
    final d = await client.post('/groups/$id/messages', body: {
      'content': content,
      if (clientId != null) 'client_id': clientId,
      if (replyToId != null) 'reply_to_id': replyToId,
    });
    return DriqyGroupMessage.fromJson(d['message'] as Map<String, dynamic>);
  }

  Future<DriqyGroupMessage> edit(int id, int mid, String content) async =>
      DriqyGroupMessage.fromJson((await client.put('/groups/$id/messages/$mid', body: {'content': content}))['message'] as Map<String, dynamic>);

  Future<DriqyGroupMessage> deleteMessage(int id, int mid) async =>
      DriqyGroupMessage.fromJson((await client.delete('/groups/$id/messages/$mid'))['message'] as Map<String, dynamic>);

  Future<void> markRead(int id, int upTo) async {
    await client.post('/groups/$id/read', body: {'up_to_id': upTo});
  }

  Future<DriqyChatPrefs> setPrefs(int id, {bool? pinned, bool? muted, bool? archived}) async {
    final d = await client.put('/groups/$id/prefs', body: {
      if (pinned != null) 'pinned': pinned,
      if (muted != null) 'muted': muted,
      if (archived != null) 'archived': archived,
    });
    return DriqyChatPrefs.fromJson(d['prefs'] as Map<String, dynamic>?);
  }

  Future<void> typing(int id, String state) async {
    await client.post('/groups/$id/typing', body: {'state': state});
  }
}
