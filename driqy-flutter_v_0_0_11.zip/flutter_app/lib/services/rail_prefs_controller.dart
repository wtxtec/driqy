import 'package:flutter/foundation.dart';

import '../models/rail_widgets.dart';
import 'widgets_service.dart';

/// Preferências do painel direito (esconder tudo, tirar widgets, ordem, sugestões), guardadas no
/// servidor — as mesmas do site (`GET/POST /api/v1/widgets/prefs`) — e os widgets próprios do
/// usuário ("Minha área", `/api/v1/widgets/custom`). Quem usa escuta com `ListenableBuilder`.
/// Sem rede, vale o padrão e salvar falha sem apagar o que está na tela.
class RailPrefsController extends ChangeNotifier {
  final WidgetsService service;
  RailPrefs _prefs = const RailPrefs();
  CustomCatalog _catalog = const CustomCatalog();
  bool _loaded = false;

  RailPrefsController(this.service);

  RailPrefs get prefs => _prefs;
  bool get loaded => _loaded;

  /// Widgets próprios, na ordem de criação.
  List<CustomWidget> get customs => _catalog.widgets;
  List<CustomKind> get customKinds => _catalog.kinds;
  int get customMax => _catalog.max;

  /// Carrega preferências e widgets próprios; só marca como carregado quando os dois voltaram
  /// (assim o painel já abre com os próprios no lugar certo).
  Future<void> load() async {
    final results = await Future.wait<Object?>([service.getPrefs(), service.getCustomCatalog()]);
    final p = results[0] as RailPrefs?;
    if (p != null) _prefs = p;
    _catalog = results[1] as CustomCatalog;
    _loaded = true;
    notifyListeners();
  }

  /// Salva [next]; devolve false se o servidor não aceitou (a tela continua como estava).
  Future<bool> save(RailPrefs next) async {
    final saved = await service.savePrefs(next);
    if (saved == null) return false;
    _prefs = saved;
    notifyListeners();
    return true;
  }

  /// Cria um widget próprio vazio do tipo [kind] e devolve o id (`custom:N`). Vai ao servidor na
  /// hora (como no site, "Cancelar" do editor não desfaz). Erros sobem como `ApiException`.
  Future<String> createCustom(String kind) async {
    final w = await service.createCustom(kind);
    // o servidor coloca o novo no fim da ordem e ativo; relê para não adivinhar
    final p = await service.getPrefs();
    _catalog = CustomCatalog(widgets: [..._catalog.widgets, w], kinds: _catalog.kinds, max: _catalog.max);
    if (p != null) _prefs = p;
    notifyListeners();
    return w.id;
  }

  /// Apaga de vez o widget próprio [id] (`custom:N`). false se o servidor não aceitou.
  Future<bool> deleteCustom(String id) async {
    final n = _numberOf(id);
    if (n == null) return false;
    try {
      await service.deleteCustom(n);
    } catch (_) {
      return false;
    }
    _catalog = CustomCatalog(
      widgets: [for (final w in _catalog.widgets) if (w.id != id) w],
      kinds: _catalog.kinds,
      max: _catalog.max,
    );
    final p = await service.getPrefs();
    if (p != null) {
      _prefs = p;
    } else {
      _prefs = _prefs.copyWith(
        order: [for (final x in _prefs.order) if (x != id) x],
        disabled: [for (final x in _prefs.disabled) if (x != id) x],
      );
    }
    notifyListeners();
    return true;
  }

  /// Lembra o título novo (o widget próprio já salvou no servidor), para o seletor mostrá-lo.
  void renameCustomLocally(String id, String title) {
    _catalog = CustomCatalog(
      widgets: [for (final w in _catalog.widgets) w.id == id ? w.copyWith(title: title) : w],
      kinds: _catalog.kinds,
      max: _catalog.max,
    );
    notifyListeners();
  }

  static int? _numberOf(String id) => id.startsWith('custom:') ? int.tryParse(id.substring(7)) : null;
}
