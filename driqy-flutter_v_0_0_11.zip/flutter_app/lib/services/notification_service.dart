import '../models/app_notification.dart';
import 'api_client.dart';

class NotificationsPage {
  final List<AppNotification> notifications;
  final bool hasNext;

  NotificationsPage({required this.notifications, required this.hasNext});
}

class NotificationService {
  final ApiClient client;

  NotificationService(this.client);

  Future<NotificationsPage> getNotifications({int page = 1}) async {
    final data = await client.get('/notifications', query: {'page': page});
    final items = (data['notifications'] as List<dynamic>)
        .map((n) => AppNotification.fromJson(n as Map<String, dynamic>))
        .toList();
    return NotificationsPage(notifications: items, hasNext: data['has_next'] as bool? ?? false);
  }

  Future<int> getUnreadCount() async {
    final data = await client.get('/notifications/unread-count');
    return data['unread'] as int? ?? 0;
  }
}
