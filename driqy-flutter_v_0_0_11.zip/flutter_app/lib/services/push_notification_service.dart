import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show Color, WidgetsBinding, WidgetsBindingObserver, AppLifecycleState;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'api_client.dart';

/// Handler de mensagens em BACKGROUND/terminado.
///
/// Precisa ser uma função top-level (fora de qualquer classe) com
/// `@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Fase 14: chamada chega como DATA-ONLY (sem bloco `notification`, ver `push.py`): o app
  // acorda aqui e desenha a notificação de TELA CHEIA (full-screen intent) com Atender/Recusar.
  // Os demais pushes continuam sendo desenhados pelo próprio sistema (têm `notification`).
  if (message.data['type'] == 'call') {
    await PushNotificationService.showIncomingCall(message.data);
    return;
  }
  if (kDebugMode) {
    print('Push recebido em background: ${message.messageId}');
  }
}

/// Resposta a um botão da notificação de chamada com o app FECHADO (isolate separado).
/// Só abre o app (`showsUserInterface`); quem decide é `main.dart` ao subir.
@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse response) {}

/// Centraliza toda a configuração de push notifications:
/// - Pede permissão ao usuário (Android 13+/iOS).
/// - Pega o token do FCM e manda pro backend salvar (associado ao
///   usuário logado), pra ele saber pra quem mandar o push.
/// - Configura o canal de notificação local com som, usado para
///   mostrar o push quando o app está ABERTO em primeiro plano (o FCM
///   sozinho não mostra popup nesse caso, só entrega o dado).
/// - Repassa o toque na notificação pra dentro do app (ex: abrir a tela
///   de notificações ou a conversa).
class PushNotificationService with WidgetsBindingObserver {
  PushNotificationService._();
  static final PushNotificationService instance = PushNotificationService._();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  /// Dois canais, cada um com seu próprio som (no Android 8+ o som é uma
  /// propriedade do canal, e o backend escolhe o canal em cada push — ver
  /// `push.py`). Os IDs precisam bater com os do backend.
  static const _messagesChannel = AndroidNotificationChannel(
    'driqy_messages',
    'Mensagens',
    description: 'Novas mensagens diretas.',
    importance: Importance.high,
    playSound: true,
    sound: RawResourceAndroidNotificationSound('driqy_message'),
    enableVibration: true,
  );

  /// Fase 11: chamadas entrando. Importância máxima; a tela cheia/toque contínuo
  /// (full-screen intent / CallKit) é a Fase 14.
  static const _callsChannel = AndroidNotificationChannel(
    'driqy_calls',
    'Chamadas',
    description: 'Chamadas de voz e vídeo recebidas.',
    importance: Importance.max,
    playSound: true,
    sound: RawResourceAndroidNotificationSound('driqy_message'),
    enableVibration: true,
  );

  static const _activityChannel = AndroidNotificationChannel(
    'driqy_activity',
    'Atividade',
    description: 'Curtidas, comentários, respostas e novos seguidores.',
    importance: Importance.high,
    playSound: true,
    sound: RawResourceAndroidNotificationSound('driqy_notification'),
    enableVibration: true,
  );

  /// Cor de destaque (âmbar) do ícone da notificação.
  static const _accent = Color(0xFFF2A93B);

  /// ID fixo da notificação de chamada (uma por vez) e ids dos botões.
  static const callNotificationId = 2001;
  static const actionAccept = 'call_accept';
  static const actionDecline = 'call_decline';

  /// Fase 14 (Android): notificação de chamada recebida com **full-screen intent** — acende a
  /// tela e abre o app por cima do bloqueio (precisa de `USE_FULL_SCREEN_INTENT` e de
  /// `showWhenLocked`/`turnScreenOn` na MainActivity, já no manifest). Funciona de qualquer
  /// isolate (cria o próprio plugin). Expira em 45 s, igual ao toque no servidor.
  static Future<void> showIncomingCall(Map<String, dynamic> data) async {
    if (!Platform.isAndroid) return;
    final plugin = FlutterLocalNotificationsPlugin();
    await plugin.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('ic_stat_driqy')),
    );
    final android = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(_callsChannel);
    final isVideo = data['media'] == 'video';
    final title = (data['title'] as String?)?.isNotEmpty == true ? data['title'] as String : 'Driqy';
    final body = (data['body'] as String?)?.isNotEmpty == true
        ? data['body'] as String
        : (isVideo ? 'Chamada de vídeo recebida' : 'Chamada de voz recebida');
    await plugin.show(
      callNotificationId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _callsChannel.id,
          _callsChannel.name,
          channelDescription: _callsChannel.description,
          importance: Importance.max,
          priority: Priority.max,
          category: AndroidNotificationCategory.call,
          fullScreenIntent: true,
          ongoing: true,
          autoCancel: false,
          timeoutAfter: 45000,
          playSound: true,
          sound: const RawResourceAndroidNotificationSound('driqy_message'),
          enableVibration: true,
          visibility: NotificationVisibility.public,
          icon: 'ic_stat_driqy',
          color: _accent,
          actions: const [
            AndroidNotificationAction(actionDecline, 'Recusar', showsUserInterface: true, cancelNotification: true),
            AndroidNotificationAction(actionAccept, 'Atender', showsUserInterface: true, cancelNotification: true),
          ],
        ),
      ),
      payload: jsonEncode({...data, 'type': 'call'}),
    );
  }

  /// Some com a notificação de chamada (atendeu, recusou, o outro desligou ou o app abriu).
  Future<void> cancelIncomingCall() async {
    try {
      await _localNotifications.cancel(callNotificationId);
    } catch (_) {}
  }

  /// Última vez que QUALQUER push chegou com o app aberto — evita tocar um
  /// segundo aviso quando a consulta periódica de contadores enxerga o mesmo
  /// evento logo depois.
  DateTime? _lastForegroundPushAt;

  /// Contadores da última consulta (null = ainda sem referência).
  int? _lastUnreadMessages;
  int? _lastUnreadActivity;

  /// O app está na frente (resumed)? O aviso local de "contador subiu" só vale
  /// com o app aberto; em segundo plano quem avisa é o push do sistema (nome +
  /// texto), e um segundo aviso genérico seria duplicado.
  bool _foreground = true;
  bool _wentToBackground = false;

  /// Avisos locais de contador adiados (dão tempo do push FCM chegar primeiro).
  static const _fallbackDelay = Duration(seconds: 7);
  Timer? _msgFallbackTimer;
  Timer? _actFallbackTimer;
  int _msgFallbackBaseline = 0;
  int _actFallbackBaseline = 0;
  DateTime? _msgFallbackSince;
  DateTime? _actFallbackSince;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _foreground = true;
      if (_wentToBackground) {
        _wentToBackground = false;
        // Tudo que chegou com o app fora já foi avisado pelo push do sistema:
        // recomeça a contagem daqui, sem gerar aviso extra.
        _lastUnreadMessages = null;
        _lastUnreadActivity = null;
      }
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      _foreground = false;
      _wentToBackground = true;
      _cancelFallbacks();
    }
  }

  void _cancelFallbacks() {
    _msgFallbackTimer?.cancel();
    _actFallbackTimer?.cancel();
    _msgFallbackTimer = null;
    _actFallbackTimer = null;
  }

  /// Callback chamado quando o usuário toca numa notificação (com o app
  /// aberto, minimizado ou fechado). Definido pelo main.dart pra poder
  /// navegar usando o navigatorKey global.
  void Function(Map<String, dynamic> data)? onNotificationTap;

  /// Fase 12: push `type=call` chegou com o app ABERTO. A tela de chamada já é a "notificação";
  /// não desenhamos o popup local (senão duplica), só avisamos o gerenciador de chamadas.
  void Function(Map<String, dynamic> data)? onCallPush;

  Future<void> init() async {
    WidgetsBinding.instance.addObserver(this);

    // 1) Pede permissão (obrigatório no iOS; no Android 13+ mostra o
    // diálogo do sistema; em versões antigas do Android já vem liberado).
    await _messaging.requestPermission(alert: true, badge: true, sound: true);

    // iOS: mostra o alerta/som mesmo com o app em primeiro plano.
    await _messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    // 2) Configura o plugin de notificação local (usado só pra exibir o
    // push quando o app está aberto, já que nesse caso o SO não desenha
    // nada sozinho).
    const androidInit = AndroidInitializationSettings('ic_stat_driqy');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    await _localNotifications.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
      onDidReceiveNotificationResponse: (response) {
        if (response.payload == null) return;
        final data = jsonDecode(response.payload!) as Map<String, dynamic>;
        // Fase 14: botão da notificação de chamada (Atender/Recusar) vira `_action`.
        if (response.actionId != null && response.actionId!.isNotEmpty) {
          data['_action'] = response.actionId;
        }
        onNotificationTap?.call(data);
      },
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );

    // App aberto pela notificação de tela cheia / botão com o app FECHADO.
    final launch = await _localNotifications.getNotificationAppLaunchDetails();
    if (launch?.didNotificationLaunchApp == true && launch?.notificationResponse?.payload != null) {
      final r = launch!.notificationResponse!;
      final data = jsonDecode(r.payload!) as Map<String, dynamic>;
      if (r.actionId != null && r.actionId!.isNotEmpty) data['_action'] = r.actionId;
      if (data['type'] == 'call') onNotificationTap?.call(data);
    }

    if (Platform.isAndroid) {
      final android = _localNotifications
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      // Canal antigo (som padrão do sistema, que não dá pra trocar depois
      // de criado): removido pra não ficar duplicado nas configurações.
      await android?.deleteNotificationChannel('driqy_default_channel');
      await android?.createNotificationChannel(_messagesChannel);
      await android?.createNotificationChannel(_activityChannel);
      await android?.createNotificationChannel(_callsChannel);
    }

    // 3) App ABERTO (foreground): o FCM só entrega o dado, quem desenha
    // o popup com som somos nós, via flutter_local_notifications.
    FirebaseMessaging.onMessage.listen(_showLocalNotification);

    // 4) App em BACKGROUND (minimizado) e o usuário toca na notificação
    // que o próprio sistema mostrou: abre a tela certa.
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      onNotificationTap?.call(message.data);
    });

    // 5) App estava TOTALMENTE FECHADO e foi aberto a partir de um toque
    // na notificação.
    final initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null) {
      onNotificationTap?.call(initialMessage.data);
    }
  }

  bool _isMessage(Map<String, dynamic> data) => data['type'] == 'message' || data['type'] == 'group_message';

  NotificationDetails _detailsFor({required bool isMessage, String? body}) {
    final channel = isMessage ? _messagesChannel : _activityChannel;
    final soundFile = isMessage ? 'driqy_message' : 'driqy_notification';
    return NotificationDetails(
      android: AndroidNotificationDetails(
        channel.id,
        channel.name,
        channelDescription: channel.description,
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound(soundFile),
        icon: 'ic_stat_driqy',
        color: _accent,
        category: isMessage ? AndroidNotificationCategory.message : AndroidNotificationCategory.social,
        // Texto longo (mensagens) expande em vez de ser cortado em 1 linha.
        styleInformation: body == null ? null : BigTextStyleInformation(body),
      ),
      iOS: DarwinNotificationDetails(
        presentSound: true,
        presentAlert: true,
        presentBadge: true,
        sound: '$soundFile.wav',
      ),
    );
  }

  Future<void> _showLocalNotification(RemoteMessage message) async {
    // Qualquer push com o app aberto prova que o FCM está funcionando: o aviso
    // local de contador (fallback) não deve ser desenhado por cima dele.
    _lastForegroundPushAt = DateTime.now();
    if (message.data['type'] == 'call') {
      onCallPush?.call(message.data);
      return;
    }
    final notification = message.notification;
    if (notification == null) return;
    final isMessage = _isMessage(message.data);
    // Mensagens da mesma pessoa reaproveitam o mesmo ID (a notificação é
    // atualizada em vez de empilhar uma por mensagem).
    final key = isMessage ? 'msg-${message.data['username']}' : null;
    await _localNotifications.show(
      (key ?? notification.hashCode.toString()).hashCode & 0x7fffffff,
      notification.title,
      notification.body,
      _detailsFor(isMessage: isMessage, body: notification.body),
      payload: jsonEncode(message.data),
    );
  }

  /// Chamado pela topbar a cada consulta de contadores. É só um *fallback* para
  /// quando o push do servidor não chega (ex.: Firebase não configurado): se os
  /// contadores subiram, espera alguns segundos e, SE nenhum push FCM apareceu
  /// nesse meio-tempo, o app está na frente e o contador continua maior (ou seja,
  /// a mensagem ainda não foi lida), mostra um aviso local genérico.
  /// Com o push funcionando, nunca aparece o segundo aviso.
  Future<void> onUnreadCounts({required int messages, required int activity}) async {
    final prevMessages = _lastUnreadMessages;
    final prevActivity = _lastUnreadActivity;
    _lastUnreadMessages = messages;
    _lastUnreadActivity = activity;

    if (!_foreground) return;

    if (prevMessages != null && messages > prevMessages && _msgFallbackTimer == null) {
      _msgFallbackBaseline = prevMessages;
      _msgFallbackSince = DateTime.now();
      _msgFallbackTimer = Timer(_fallbackDelay, () => _fireFallback(isMessage: true));
    }
    if (prevActivity != null && activity > prevActivity && _actFallbackTimer == null) {
      _actFallbackBaseline = prevActivity;
      _actFallbackSince = DateTime.now();
      _actFallbackTimer = Timer(_fallbackDelay, () => _fireFallback(isMessage: false));
    }
  }

  Future<void> _fireFallback({required bool isMessage}) async {
    final since = isMessage ? _msgFallbackSince : _actFallbackSince;
    final baseline = isMessage ? _msgFallbackBaseline : _actFallbackBaseline;
    if (isMessage) {
      _msgFallbackTimer = null;
    } else {
      _actFallbackTimer = null;
    }
    if (!_foreground) return;

    // Um push FCM chegou perto desse evento? Então ele já avisou (com nome e texto).
    final lastPush = _lastForegroundPushAt;
    if (lastPush != null && since != null &&
        lastPush.isAfter(since.subtract(const Duration(seconds: 90)))) {
      return;
    }

    // Já leu / abriu? O contador atual não é mais maior que o de antes.
    final current = (isMessage ? _lastUnreadMessages : _lastUnreadActivity) ?? 0;
    final n = current - baseline;
    if (n <= 0) return;

    if (isMessage) {
      await _localNotifications.show(
        1001,
        'Driqy',
        n == 1 ? 'Você recebeu uma nova mensagem' : 'Você recebeu $n novas mensagens',
        _detailsFor(isMessage: true),
        payload: jsonEncode({'type': 'message'}),
      );
    } else {
      await _localNotifications.show(
        1002,
        'Driqy',
        n == 1 ? 'Você tem uma nova notificação' : 'Você tem $n novas notificações',
        _detailsFor(isMessage: false),
        payload: jsonEncode({'type': 'notification'}),
      );
    }
  }

  /// Pega o token atual do FCM e manda pro backend salvar, associado ao
  /// usuário logado (usa o [client] já autenticado com o Bearer token).
  /// Também escuta [onTokenRefresh], porque o FCM pode trocar o token
  /// periodicamente (reinstalação, troca de conta, etc.).
  Future<void> registerDeviceToken(ApiClient client) async {
    _lastUnreadMessages = null;
    _lastUnreadActivity = null;
    _cancelFallbacks();
    final token = await _messaging.getToken();
    if (token != null) {
      await _sendTokenToBackend(client, token);
    }
    _messaging.onTokenRefresh.listen((newToken) => _sendTokenToBackend(client, newToken));
  }

  Future<void> _sendTokenToBackend(ApiClient client, String token) async {
    try {
      await client.post('/devices/register', body: {
        'token': token,
        'platform': Platform.isIOS ? 'ios' : 'android',
      });
    } catch (e) {
      if (kDebugMode) print('Falha ao registrar device token: $e');
    }
  }

  /// Chamar no logout, pra esse aparelho parar de receber pushes de
  /// notificações da conta que acabou de sair.
  Future<void> unregisterDeviceToken(ApiClient client) async {
    _lastUnreadMessages = null;
    _lastUnreadActivity = null;
    _cancelFallbacks();
    try {
      final token = await _messaging.getToken();
      if (token != null) {
        await client.post('/devices/unregister', body: {'token': token});
      }
    } catch (e) {
      if (kDebugMode) print('Falha ao remover device token: $e');
    }
  }
}
