import '../models/picture_tile.dart';
import 'api_client.dart';

/// Uma página de peças. `nextCursor` é OPACO: sempre reenvie como veio
/// (no `/vortex` é texto tipo "t123-30"; na busca e nos similares, "o30").
class PicturesPage {
  final List<PictureTile> tiles;
  final bool hasNext;
  final String? nextCursor;

  /// Aviso de pausa (só `/vortex`): minutos contínuos e nível (sobe a cada 30 min).
  final int breakMinutes;
  final int breakLevel;

  PicturesPage({
    required this.tiles,
    required this.hasNext,
    required this.nextCursor,
    this.breakMinutes = 0,
    this.breakLevel = 0,
  });
}

class VortexSearchPage extends PicturesPage {
  final int total;
  final bool totalCapped;
  final bool relaxed;

  VortexSearchPage({
    required super.tiles,
    required super.hasNext,
    required super.nextCursor,
    required this.total,
    required this.totalCapped,
    required this.relaxed,
  });
}

class VortexItemResult {
  final VortexItemDetail detail;
  final PicturesPage related;

  VortexItemResult({required this.detail, required this.related});
}

class PicturesService {
  final ApiClient client;

  PicturesService(this.client);

  static List<PictureTile> _tiles(dynamic raw) => (raw as List<dynamic>? ?? const [])
      .map((t) => PictureTile.fromJson(t as Map<String, dynamic>))
      .toList();

  static PicturesPage _page(Map<String, dynamic> data) => PicturesPage(
        tiles: _tiles(data['tiles']),
        hasNext: data['has_next'] as bool? ?? false,
        nextCursor: data['next_cursor']?.toString(),
        breakMinutes: _wellbeing(data, 'minutes'),
        breakLevel: _wellbeing(data, 'level'),
      );

  static int _wellbeing(Map<String, dynamic> data, String field) {
    final w = data['wellbeing'];
    if (w is! Map || w['suggest_break'] != true) return 0;
    final v = w[field];
    return v is num ? v.toInt() : 0;
  }

  /// Grade do Vortex (`GET /vortex`): itens do crawler + posts de usuários,
  /// ordenados pelo GOSTO de quem vê. `category` e `type` (photo|gif|video)
  /// são filtros opcionais; com `category`, só itens do crawler.
  Future<PicturesPage> getVortex({String? cursor, String? category, String? type}) async {
    final data = await client.get('/vortex', query: {
      if (cursor != null) 'cursor': cursor,
      if (category != null) 'category': category,
      if (type != null) 'type': type,
    });
    return _page(data);
  }

  /// Faixa "Vistos recentemente": o que ESTA pessoa abriu há pouco.
  Future<List<PictureTile>> getRecent({int limit = 20}) async {
    final data = await client.get('/vortex/recent', query: {'limit': limit});
    return _tiles(data['tiles']);
  }

  /// Detalhe de um item do crawler + 1ª página de "Mais como este". Abrir o
  /// detalhe já conta como clique (`open`) no servidor.
  Future<VortexItemResult> getItem(int itemId) async {
    final data = await client.get('/vortex/item/$itemId');
    final related = data['related'];
    return VortexItemResult(
      detail: VortexItemDetail.fromJson(data['item'] as Map<String, dynamic>),
      related: related is Map<String, dynamic>
          ? _page(related)
          : PicturesPage(tiles: const [], hasNext: false, nextCursor: null),
    );
  }

  Future<PicturesPage> getRelated(int itemId, {String? cursor}) async {
    final data = await client.get(
      '/vortex/item/$itemId/related',
      query: cursor != null ? {'cursor': cursor} : null,
    );
    return _page(data);
  }

  Future<VortexSearchPage> search(String q, {String? cursor, String? category, String? type}) async {
    final data = await client.get('/vortex/search', query: {
      'q': q,
      if (cursor != null) 'cursor': cursor,
      if (category != null) 'category': category,
      if (type != null) 'type': type,
    });
    return VortexSearchPage(
      tiles: _tiles(data['tiles']),
      hasNext: data['has_next'] as bool? ?? false,
      nextCursor: data['next_cursor']?.toString(),
      total: data['total'] as int? ?? 0,
      totalCapped: data['total_capped'] as bool? ?? false,
      relaxed: data['relaxed'] as bool? ?? false,
    );
  }

  Future<VortexStats> getStats() async =>
      VortexStats.fromJson(await client.get('/vortex/stats'));

  Future<List<VortexCategory>> getCategories() async {
    final data = await client.get('/vortex/categories');
    return (data['categories'] as List<dynamic>? ?? const [])
        .map((c) => VortexCategory.fromJson(c as Map<String, dynamic>))
        .toList();
  }

  /// Avisa quais peças ficaram VISÍVEIS na tela (livro de vistos do servidor:
  /// o que já foi visto não volta nas próximas aberturas). `keys` no formato do
  /// servidor: 'c<itemId>' (crawler) ou 'p<postId>' (post de usuário).
  /// Fire-and-forget: falha em silêncio.
  Future<void> markViewed(List<String> keys) async {
    if (keys.isEmpty) return;
    try {
      await client.post('/vortex/seen', body: {'keys': keys});
    } catch (_) {
      // silencioso de propósito
    }
  }

  /// Avisa o servidor o que a pessoa fez, pra o Vortex aprender o gosto dela.
  /// `kind`: 'open' | 'dwell' | 'like' | 'less'. Passe `postId` (post de
  /// usuário) OU `itemId` (peça do crawler — abrir o detalhe via [getItem] já
  /// conta como 'open' sozinho). Fire-and-forget: falha em silêncio.
  Future<void> trackInteraction({int? postId, int? itemId, String kind = 'open'}) async {
    if (postId == null && itemId == null) return;
    try {
      await client.post('/vortex/interact', body: {
        'kind': kind,
        if (postId != null) 'post_id': postId,
        if (itemId != null) 'item_id': itemId,
      });
    } catch (_) {
      // silencioso de propósito
    }
  }
}
