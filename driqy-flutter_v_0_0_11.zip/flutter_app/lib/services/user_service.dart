import 'dart:io';

import '../models/accent_color.dart';
import '../models/post.dart';
import '../models/user.dart';
import 'api_client.dart';

class UserPostsPage {
  final List<DriqyPost> posts;
  final bool hasNext;

  UserPostsPage({required this.posts, required this.hasNext});
}

/// Ping fase 8 — uma página de Contatos (`GET /contacts`).
class ContactsPage {
  final List<DriqyUser> users;
  final bool hasNext;
  final int followingCount;
  final int followersCount;

  ContactsPage({
    required this.users,
    required this.hasNext,
    required this.followingCount,
    required this.followersCount,
  });

  factory ContactsPage.fromJson(Map<String, dynamic> json) {
    final counts = (json['counts'] as Map<String, dynamic>?) ?? const <String, dynamic>{};
    return ContactsPage(
      users: ((json['users'] as List<dynamic>?) ?? const [])
          .map((u) => DriqyUser.fromJson(u as Map<String, dynamic>))
          .toList(),
      hasNext: json['has_next'] as bool? ?? false,
      followingCount: counts['following'] as int? ?? 0,
      followersCount: counts['followers'] as int? ?? 0,
    );
  }
}

class UserService {
  final ApiClient client;

  UserService(this.client);

  Future<DriqyUser> getProfile(String username) async {
    final data = await client.get('/users/$username');
    return DriqyUser.fromJson(data);
  }

  Future<UserPostsPage> getPosts(String username, {int page = 1}) async {
    final data = await client.get('/users/$username/posts', query: {'page': page});
    final posts = (data['posts'] as List<dynamic>)
        .map((p) => DriqyPost.fromJson(p as Map<String, dynamic>))
        .toList();
    return UserPostsPage(posts: posts, hasNext: data['has_next'] as bool? ?? false);
  }

  /// Ping fase 8: quem eu sigo (`followers: false`) ou quem me segue; [q] filtra por @/nome.
  Future<ContactsPage> getContacts({bool followers = false, String q = '', int page = 1}) async {
    final data = await client.get('/contacts', query: {
      'tab': followers ? 'followers' : 'following',
      if (q.trim().isNotEmpty) 'q': q.trim(),
      'page': page,
    });
    return ContactsPage.fromJson(data);
  }

  Future<bool> follow(String username) async {
    final data = await client.post('/users/$username/follow');
    return data['is_following'] as bool;
  }

  Future<bool> unfollow(String username) async {
    final data = await client.post('/users/$username/unfollow');
    return data['is_following'] as bool;
  }

  Future<List<AccentColorOption>> getAccentColors() async {
    final data = await client.get('/accent-colors');
    return (data['colors'] as List<dynamic>)
        .map((c) => AccentColorOption.fromJson(c as Map<String, dynamic>))
        .toList();
  }

  /// Atualiza o perfil do usuário logado. [avatarFile]/[coverFile] são
  /// opcionais (só entram na requisição se não forem nulos);
  /// [removeAvatar]/[removeCover] pedem pra apagar a imagem atual (só tem
  /// efeito quando o arquivo correspondente não foi enviado).
  Future<DriqyUser> updateProfile({
    required String username,
    required String displayName,
    required String bio,
    required String location,
    double? locationLat,
    double? locationLng,
    required String accentColor,
    File? avatarFile,
    File? coverFile,
    bool removeAvatar = false,
    bool removeCover = false,
  }) async {
    final fields = {
      'username': username,
      'display_name': displayName,
      'bio': bio,
      'location': location,
      if (locationLat != null && locationLng != null) ...{
        'location_lat': '$locationLat',
        'location_lng': '$locationLng',
      },
      'accent_color': accentColor,
      'remove_avatar': removeAvatar ? '1' : '0',
      'remove_cover': removeCover ? '1' : '0',
    };
    final namedFiles = <String, File>{
      if (avatarFile != null) 'avatar_file': avatarFile,
      if (coverFile != null) 'cover_file': coverFile,
    };
    final data = await client.postMultipart('/me', fields: fields, namedFiles: namedFiles);
    return DriqyUser.fromJson(data);
  }
}
