import 'dart:io';

import '../models/flash.dart';
import 'api_client.dart';

class FlashService {
  final ApiClient client;

  FlashService(this.client);

  Future<FlashTray> tray() async => FlashTray.fromJson(await client.get('/flashes/tray'));

  Future<FlashGroup> ofUser(String username) async =>
      FlashGroup.fromJson(await client.get('/users/$username/flashes'));

  Future<void> markViewed(int id) async {
    try {
      await client.post('/flashes/$id/view');
    } catch (_) {
      // "visto" é só estatística: não atrapalha a tela
    }
  }

  Future<void> delete(int id) async {
    await client.delete('/flashes/$id');
  }

  Future<List<FlashViewer>> viewers(int id) async {
    final data = await client.get('/flashes/$id/viewers');
    return ((data['viewers'] as List<dynamic>?) ?? const [])
        .map((v) => FlashViewer.fromJson(v as Map<String, dynamic>))
        .toList();
  }

  Future<void> publish(File file, {String caption = ''}) async {
    await client.postFile('/flashes', file: file, fields: {'caption': caption});
  }
}
