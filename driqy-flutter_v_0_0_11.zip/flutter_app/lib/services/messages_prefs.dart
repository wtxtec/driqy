import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Preferências do Mensagens guardadas no aparelho (espelham `settings.js` do site):
/// som ao receber mensagem, som escolhido e volume. A privacidade (online/visto por último)
/// continua no servidor (`MessageService.setShowPresence`).
class MessagesPrefs extends ChangeNotifier {
  MessagesPrefs._();
  static final MessagesPrefs instance = MessagesPrefs._();

  static const _kSound = 'msg_sound_enabled';
  static const _kChoice = 'msg_sound_choice';
  static const _kVolume = 'msg_sound_volume';

  /// Opções de som (chave → rótulo → asset). Mesmas chaves do site: padrao, ding, pop.
  static const choices = <String, String>{'padrao': 'Padrão', 'ding': 'Ding', 'pop': 'Pop'};
  static const _assets = <String, String>{
    'padrao': 'assets/sounds/message.mp3',
    'ding': 'assets/sounds/ding.wav',
    'pop': 'assets/sounds/pop.wav',
  };

  bool _soundEnabled = false; // igual ao site: começa desligado
  String _choice = 'padrao';
  double _volume = 1.0;
  bool _loaded = false;
  AudioPlayer? _player;
  DateTime _lastPlayed = DateTime.fromMillisecondsSinceEpoch(0);

  bool get soundEnabled => _soundEnabled;
  String get soundChoice => _choice;
  double get volume => _volume;

  Future<void> load() async {
    if (_loaded) return;
    try {
      final p = await SharedPreferences.getInstance();
      _soundEnabled = p.getBool(_kSound) ?? false;
      final c = p.getString(_kChoice);
      _choice = c != null && choices.containsKey(c) ? c : 'padrao';
      _volume = (p.getDouble(_kVolume) ?? 1.0).clamp(0.0, 1.0);
    } catch (_) {}
    _loaded = true;
    notifyListeners();
  }

  Future<void> setSoundEnabled(bool v) async {
    _soundEnabled = v;
    notifyListeners();
    await _save((p) => p.setBool(_kSound, v));
    if (v) preview();
  }

  Future<void> setSoundChoice(String key) async {
    if (!choices.containsKey(key)) return;
    _choice = key;
    notifyListeners();
    await _save((p) => p.setString(_kChoice, key));
    preview();
  }

  void setVolumeLive(double v) {
    _volume = v.clamp(0.0, 1.0);
    notifyListeners();
  }

  /// Ao soltar o controle de volume: grava e toca uma prévia.
  Future<void> commitVolume() async {
    await _save((p) => p.setDouble(_kVolume, _volume));
    preview();
  }

  Future<void> _save(Future<bool> Function(SharedPreferences p) fn) async {
    try {
      await fn(await SharedPreferences.getInstance());
    } catch (_) {}
  }

  /// Toca o som escolhido agora (prévia), mesmo com o interruptor desligado.
  Future<void> preview([String? key]) => _play(key ?? _choice);

  /// Mensagem nova recebida: toca se o som estiver ligado (com intervalo mínimo entre toques).
  Future<void> playIncoming() async {
    if (!_soundEnabled) return;
    final now = DateTime.now();
    if (now.difference(_lastPlayed).inMilliseconds < 400) return;
    _lastPlayed = now;
    await _play(_choice);
  }

  Future<void> _play(String key) async {
    if (_volume <= 0) return;
    try {
      final player = _player ??= AudioPlayer();
      await player.setAsset(_assets[key] ?? _assets['padrao']!);
      await player.setVolume(_volume);
      await player.seek(Duration.zero);
      await player.play();
    } catch (_) {
      // som nunca pode derrubar o chat
    }
  }
}
