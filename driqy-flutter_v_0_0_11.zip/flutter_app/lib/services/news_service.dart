import '../models/news_article.dart';
import 'api_client.dart';

class NewsFeedPage {
  final List<NewsArticle> articles;
  final bool hasNext;
  final int nextOffset;
  final List<NewsCategory> categories;
  final List<String> userInterests;

  NewsFeedPage({
    required this.articles,
    required this.hasNext,
    required this.nextOffset,
    required this.categories,
    required this.userInterests,
  });
}

class NewsInterestsData {
  final List<NewsCategory> categories;
  final List<String> selected;

  NewsInterestsData({required this.categories, required this.selected});
}

class NewsService {
  final ApiClient client;

  NewsService(this.client);

  Future<NewsFeedPage> getFeed({
    String? category,
    int offset = 0,
    List<int> seenIds = const [],
  }) async {
    final data = await client.get('/news', query: {
      if (category != null) 'categoria': category,
      'offset': offset,
      if (seenIds.isNotEmpty) 'vistos': seenIds.join(','),
    });
    final articles = (data['articles'] as List<dynamic>)
        .map((a) => NewsArticle.fromJson(a as Map<String, dynamic>))
        .toList();
    final categories = (data['categories'] as List<dynamic>)
        .map((c) => NewsCategory.fromJson(c as Map<String, dynamic>))
        .toList();
    return NewsFeedPage(
      articles: articles,
      hasNext: data['has_next'] as bool? ?? false,
      nextOffset: data['next_offset'] as int? ?? (offset + articles.length),
      categories: categories,
      userInterests: (data['user_interests'] as List<dynamic>? ?? [])
          .map((c) => c as String)
          .toList(),
    );
  }

  Future<NewsInterestsData> getInterests() async {
    final data = await client.get('/news/interests');
    return NewsInterestsData(
      categories: (data['categories'] as List<dynamic>)
          .map((c) => NewsCategory.fromJson(c as Map<String, dynamic>))
          .toList(),
      selected: (data['selected'] as List<dynamic>? ?? []).map((c) => c as String).toList(),
    );
  }

  Future<List<String>> updateInterests(List<String> categories) async {
    final data = await client.post('/news/interests', body: {'categories': categories});
    return (data['selected'] as List<dynamic>? ?? []).map((c) => c as String).toList();
  }

  /// Registra o clique (mesmo sinal usado pelo recomendador no site) e
  /// devolve a URL de origem pro app abrir no navegador do aparelho.
  Future<String> openArticle(int articleId) async {
    final data = await client.post('/news/$articleId/abrir');
    return data['url'] as String;
  }
}
