import '../models/post.dart';
import 'api_client.dart';

class FeedPage {
  final List<DriqyPost> posts;
  final bool hasNext;

  FeedPage({required this.posts, required this.hasNext});
}

class FeedService {
  final ApiClient client;

  FeedService(this.client);

  Future<FeedPage> getFeed({int page = 1}) async {
    final data = await client.get('/feed', query: {'page': page});
    final posts = (data['posts'] as List<dynamic>)
        .map((p) => DriqyPost.fromJson(p as Map<String, dynamic>))
        .toList();
    return FeedPage(posts: posts, hasNext: data['has_next'] as bool? ?? false);
  }

  Future<bool> toggleLike(int postId) async {
    final data = await client.post('/posts/$postId/like');
    return data['liked'] as bool;
  }
}
