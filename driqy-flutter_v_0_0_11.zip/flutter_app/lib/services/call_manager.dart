import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../models/call.dart';
import '../screens/call_screen.dart';
import '../widgets/chat/audio_message.dart';
import 'api_client.dart';
import 'api_exception.dart';
import 'call_service.dart';
import 'chat_live.dart';

enum CallPhase { idle, calling, incoming, connecting, active, ended }

class _Soft implements Exception {
  final String msg;
  _Soft(this.msg);
}

/// Estado de UMA chamada (voz ou vídeo) neste aparelho.
class _Session {
  int? id;
  final bool outgoing;
  final String username;
  String name;
  String? avatar;
  final CallMedia media;
  String? offerSdp;
  RTCPeerConnection? pc;
  MediaStream? stream;
  bool remoteSet = false;
  bool answering = false;
  bool noCam = false; // pediu vídeo mas a câmera falhou: segue só com áudio
  final List<Map<String, dynamic>> pendIce = [];
  final List<Map<String, dynamic>> outIce = [];
  final Set<String> seenIce = {};
  DateTime? startedAt;
  Timer? pollTimer, pingTimer, clock, discTimer, ringTimer;
  final String clientId = 'c${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}';

  _Session({required this.outgoing, required this.username, required this.name, this.avatar, this.media = CallMedia.voice});
}

/// Chamada de VOZ (Fase 12) e VÍDEO (Fase 13): WebRTC (`flutter_webrtc`) + sinalização da Fase 11.
///
/// Vídeo vale para chamadas que COMEÇAM como vídeo (sem renegociação). Dá para desligar a câmera e
/// alternar frontal/traseira; se a câmera falhar, a chamada segue só com áudio (com aviso).
///
/// Uma instância global ([instance]). `attach` é chamado quando o usuário loga (liga o stream de
/// eventos `call_incoming/call_signal/call_state` do [ChatLive]); `detach` no logout.
/// A tela é a [CallScreen], aberta por cima de tudo pelo `navigatorKey`.
/// Sem SSE ligado, um polling leve de `GET /calls/<id>` cobre answer, ICE e estado.
/// NÃO compilado pela IA (sem SDK Flutter no ambiente) — rodar `flutter pub get` + `flutter analyze`.
class CallManager extends ChangeNotifier with WidgetsBindingObserver {
  CallManager._();
  static final CallManager instance = CallManager._();

  ApiClient? _client;
  CallService? _svc;
  GlobalKey<NavigatorState>? _nav;
  StreamSubscription<ChatEvent>? _sub;
  bool _acquired = false;
  bool _observing = false;
  Future<CallConfig>? _cfgFuture;
  bool _turnMissing = false;
  final Set<int> _seen = {};
  Timer? _ringTimer;
  Route<void>? _route;
  _Session? _s;

  CallPhase _phase = CallPhase.idle;
  String _status = '';
  String? _warning;
  bool _muted = false;
  bool _speaker = false;
  bool _camOff = false;
  bool _frontCam = true;
  bool _remoteVideo = false;
  bool _renderersReady = false;
  // lazy: só nascem quando há vídeo (o singleton não toca o plugin em testes)
  late final RTCVideoRenderer localRenderer = RTCVideoRenderer();
  late final RTCVideoRenderer remoteRenderer = RTCVideoRenderer();

  CallPhase get phase => _phase;
  String get status => _status;
  String? get warning => _warning;
  bool get muted => _muted;
  bool get speaker => _speaker;
  bool get isVideo => _s?.media == CallMedia.video;
  bool get camOff => _camOff;
  bool get frontCam => _frontCam;
  bool get remoteVideo => _remoteVideo;
  bool get hasLocalVideo => (_s?.stream?.getVideoTracks().isNotEmpty ?? false);
  bool get busy => _s != null;
  String get partnerName => _s?.name ?? '';
  String? get partnerAvatar => _s?.avatar;

  /// Dispara e esquece: erro de rede num "desligar"/ICE não pode derrubar o app.
  static void _quiet(Future<dynamic>? f) => f?.then((_) {}, onError: (_) {});

  // ---------------------------------------------------------------- ligação ao app

  void attach(ApiClient client, GlobalKey<NavigatorState> navigatorKey) {
    final sameUser = _client?.token == client.token && _sub != null;
    _client = client;
    _svc = CallService(client);
    _nav = navigatorKey;
    if (sameUser) return;
    _sub?.cancel();
    _cfgFuture = null;
    if (!_observing) {
      WidgetsBinding.instance.addObserver(this);
      _observing = true;
    }
    if (!_acquired) {
      ChatLive.instance.acquire(client);
      _acquired = true;
    }
    _sub = ChatLive.instance.events.listen(_onEvent);
    checkActive();
  }

  /// Logout: derruba a chamada (se houver) sem avisar a tela.
  void detach() {
    _sub?.cancel();
    _sub = null;
    final id = _s?.id;
    if (id != null) _quiet(_svc?.end(id));
    _finish('', silent: true);
    if (_acquired) {
      ChatLive.instance.release();
      _acquired = false;
    }
    _client = null;
    _svc = null;
    _cfgFuture = null;
    _seen.clear();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _svc != null) {
      if (_s != null) {
        _poll();
      } else {
        checkActive();
      }
    }
  }

  Future<CallConfig> _config() {
    return _cfgFuture ??= _svc!.getConfig().catchError((Object e) {
      _cfgFuture = null;
      throw e;
    });
  }

  /// Retoma toque ou limpa chamada órfã. Chamado ao logar, ao voltar do segundo plano e
  /// ao tocar/receber o push `type=call`.
  Future<void> checkActive() async {
    final svc = _svc;
    if (svc == null || _s != null) return;
    try {
      final call = await svc.active();
      if (call == null || _s != null) return;
      if (call.state == CallState.ringing && !call.outgoing) {
        final full = call.offerSdp != null ? call : await svc.get(call.id);
        _startIncoming(full.id, full.partner.username, full.partner.displayName, full.partner.avatarUrl,
            full.media, full.offerSdp, full.ringSeconds);
      } else if (call.isActive) {
        await svc.end(call.id); // sem peer connection aqui: ficou órfã (app reiniciou)
      }
    } catch (_) {}
  }

  /// Fase 14: veio da notificação de tela cheia (app estava fechado). `accept` atende assim que
  /// o toque estiver na tela; `decline` recusa pelo REST sem nem abrir a tela de chamada.
  /// Tenta por ~8 s: o login/ChatLive podem ainda estar subindo.
  Future<void> handleNotificationAction(String? action, int? callId) async {
    for (var i = 0; i < 16 && _svc == null; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 500));
    }
    final svc = _svc;
    if (svc == null) return;
    if (action == 'call_decline') {
      try {
        final id = callId ?? (await svc.active())?.id;
        if (id != null) await svc.decline(id);
      } catch (_) {}
      return;
    }
    await checkActive();
    if (action == 'call_accept' && _s != null && !_s!.outgoing) {
      // dá um respiro para a tela montar; `accept()` pede o microfone
      await Future<void>.delayed(const Duration(milliseconds: 300));
      if (_s != null && !_s!.outgoing) await accept();
    }
  }

  /// Push `type=call` com o app aberto: o SSE normalmente já avisou; isto é a rede de segurança.
  void onCallPush(Map<String, dynamic> data) => checkActive();

  // ---------------------------------------------------------------- eventos ao vivo

  void _onEvent(ChatEvent e) {
    if (!e.isCallEvent) return;
    switch (e.type) {
      case 'call_incoming':
        final id = e.callId;
        if (id == null) return;
        _startIncoming(id, e.partner ?? '', e.partner ?? '', null, e.media == 'video' ? CallMedia.video : CallMedia.voice,
            e.offer?['sdp'] as String?, (e.data['ring_seconds'] as num?)?.toInt() ?? 45);
        break;
      case 'call_signal':
        final s = _s;
        if (s == null || e.callId != s.id || s.pc == null) return;
        if (e.kind == 'answer') {
          _applyAnswer(s, e.answer?['sdp'] as String?);
        } else if (e.kind == 'ice') {
          _addRemoteIce(s, e.candidate);
        }
        break;
      case 'call_state':
        final s = _s;
        if (s == null || e.callId != s.id) return;
        final st = parseCallState(e.state);
        if (_isEnded(st)) {
          final silent = _phase == CallPhase.incoming && !s.outgoing && (e.by ?? '').isNotEmpty && st != CallState.missed;
          _finish(callEndMessage(st, e.reason, outgoing: s.outgoing), silent: silent);
        } else if (st == CallState.accepted) {
          if (!s.outgoing && _phase == CallPhase.incoming && !s.answering) {
            _finish('', silent: true); // atendida em outro aparelho
          } else if (s.outgoing && _phase == CallPhase.calling) {
            _setStatus('Conectando…');
          }
        }
        break;
    }
  }

  bool _isEnded(CallState s) =>
      s == CallState.ended || s == CallState.declined || s == CallState.missed || s == CallState.failed || s == CallState.busy;

  // ---------------------------------------------------------------- estado / UI

  void _setPhase(CallPhase p, [String? status]) {
    _phase = p;
    if (status != null) _status = status;
    notifyListeners();
  }

  void _setStatus(String t) {
    _status = t;
    notifyListeners();
  }

  void _openScreen() {
    if (_route != null) return;
    final nav = _nav?.currentState;
    if (nav == null) return;
    final route = MaterialPageRoute<void>(fullscreenDialog: true, builder: (_) => const CallScreen());
    _route = route;
    nav.push(route).then((_) => _route = null);
  }

  void _closeScreen() {
    final r = _route;
    _route = null;
    if (r != null && r.isActive) _nav?.currentState?.removeRoute(r);
  }

  void _pauseChatMedia() {
    try {
      AudioMessage.pauseAll();
    } catch (_) {}
  }

  void _ringStart() {
    _ringStop();
    void beep() {
      SystemSound.play(SystemSoundType.alert);
      HapticFeedback.vibrate();
    }

    beep();
    _ringTimer = Timer.periodic(const Duration(milliseconds: 2200), (_) => beep());
  }

  void _ringStop() {
    _ringTimer?.cancel();
    _ringTimer = null;
  }

  // ---------------------------------------------------------------- WebRTC

  static const _audioC = {'echoCancellation': true, 'noiseSuppression': true, 'autoGainControl': true};

  Future<MediaStream> _getMic() async {
    try {
      return await navigator.mediaDevices.getUserMedia({'audio': _audioC, 'video': false});
    } catch (_) {
      throw _Soft('Não foi possível usar o microfone. Libere a permissão do Driqy nas configurações do aparelho.');
    }
  }

  /// Áudio (+ vídeo 640×480 a 24 fps, frontal). Câmera falhou → só áudio, com aviso (não derruba a chamada).
  Future<MediaStream> _getMedia(_Session s) async {
    if (s.media != CallMedia.video) return _getMic();
    try {
      return await navigator.mediaDevices.getUserMedia({
        'audio': _audioC,
        'video': {'facingMode': 'user', 'width': 640, 'height': 480, 'frameRate': 24},
      });
    } catch (_) {
      final st = await _getMic();
      s.noCam = true;
      _warning = 'Câmera indisponível: a outra pessoa não vai te ver (só áudio).';
      return st;
    }
  }

  Future<void> _ensureRenderers() async {
    if (_renderersReady) return;
    await localRenderer.initialize();
    await remoteRenderer.initialize();
    _renderersReady = true;
  }

  Future<void> _showLocal(_Session s) async {
    if (s.media != CallMedia.video) return;
    try {
      await _ensureRenderers();
      if (_s != s) return;
      localRenderer.srcObject = s.stream;
    } catch (_) {}
    notifyListeners();
  }

  Future<RTCPeerConnection> _makePc(_Session s, CallConfig cfg) async {
    final pc = await createPeerConnection({
      'iceServers': [for (final x in cfg.iceServers) x.toMap()],
      'sdpSemantics': 'unified-plan',
    });
    s.pc = pc;
    for (final t in s.stream!.getTracks()) {
      await pc.addTrack(t, s.stream!);
    }
    pc.onTrack = (RTCTrackEvent ev) async {
      if (_s != s || ev.track.kind != 'video' || ev.streams.isEmpty) return;
      try {
        await _ensureRenderers();
        remoteRenderer.srcObject = ev.streams.first;
        _remoteVideo = true;
        notifyListeners();
      } catch (_) {}
    };
    pc.onIceCandidate = (RTCIceCandidate c) {
      final cand = c.candidate;
      if (cand == null || cand.isEmpty) return;
      final m = Map<String, dynamic>.from(c.toMap() as Map);
      final id = s.id;
      if (id != null) {
        _quiet(_svc?.sendIce(id, m));
      } else {
        s.outIce.add(m);
      }
    };
    pc.onConnectionState = (RTCPeerConnectionState st) {
      if (_s != s) return;
      switch (st) {
        case RTCPeerConnectionState.RTCPeerConnectionStateConnected:
          _onConnected(s);
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateDisconnected:
          _onDisconnected(s);
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateFailed:
          _fail('Não foi possível conectar a chamada.${_turnMissing ? ' (Servidor TURN não configurado: veja COTURN.md.)' : ''}');
          break;
        default:
          break;
      }
    };
    // Algumas versões do Android não entregam onConnectionState; o ICE cobre.
    pc.onIceConnectionState = (RTCIceConnectionState st) {
      if (_s != s) return;
      if (st == RTCIceConnectionState.RTCIceConnectionStateConnected || st == RTCIceConnectionState.RTCIceConnectionStateCompleted) {
        _onConnected(s);
      } else if (st == RTCIceConnectionState.RTCIceConnectionStateFailed) {
        _fail('Não foi possível conectar a chamada.${_turnMissing ? ' (Servidor TURN não configurado: veja COTURN.md.)' : ''}');
      }
    };
    return pc;
  }

  void _onConnected(_Session s) {
    s.discTimer?.cancel();
    if (_phase == CallPhase.active) return;
    s.startedAt = DateTime.now();
    _ringStop();
    _muted = false;
    _speaker = s.media == CallMedia.video; // vídeo: o aparelho está longe do ouvido
    try {
      Helper.setSpeakerphoneOn(_speaker);
    } catch (_) {}
    s.clock?.cancel();
    s.clock = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_s == s && _phase == CallPhase.active) _setStatus(_elapsed(s));
    });
    _setPhase(CallPhase.active, '0:00');
  }

  void _onDisconnected(_Session s) {
    _setStatus('Reconectando…');
    s.discTimer?.cancel();
    s.discTimer = Timer(const Duration(seconds: 12), () {
      final st = s.pc?.connectionState;
      if (_s == s && st != RTCPeerConnectionState.RTCPeerConnectionStateConnected) _fail('A conexão caiu.');
    });
  }

  String _elapsed(_Session s) => callElapsedLabel(DateTime.now().difference(s.startedAt ?? DateTime.now()).inSeconds);

  void _flushOutIce(_Session s) {
    final id = s.id;
    if (id == null) return;
    final q = List<Map<String, dynamic>>.from(s.outIce);
    s.outIce.clear();
    for (final c in q) {
      _quiet(_svc?.sendIce(id, c));
    }
  }

  void _addRemoteIce(_Session s, Map<String, dynamic>? c) {
    if (c == null) return;
    final key = '${c['candidate']}|${c['sdpMid']}|${c['sdpMLineIndex']}';
    if (!s.seenIce.add(key)) return;
    if (!s.remoteSet) {
      s.pendIce.add(c);
      return;
    }
    _addCandidate(s, c);
  }

  void _addCandidate(_Session s, Map<String, dynamic> c) {
    try {
      s.pc?.addCandidate(RTCIceCandidate(c['candidate'] as String?, c['sdpMid'] as String?, (c['sdpMLineIndex'] as num?)?.toInt()));
    } catch (_) {}
  }

  void _flushPendIce(_Session s) {
    final q = List<Map<String, dynamic>>.from(s.pendIce);
    s.pendIce.clear();
    for (final c in q) {
      _addCandidate(s, c);
    }
  }

  Future<void> _applyAnswer(_Session s, String? sdp) async {
    if (s.outgoing != true || s.remoteSet || sdp == null || s.pc == null) return;
    s.remoteSet = true; // trava reentrada (evento + polling trazem a mesma resposta)
    try {
      await s.pc!.setRemoteDescription(RTCSessionDescription(sdp, 'answer'));
      if (_s != s) return;
      _flushPendIce(s);
      if (_phase == CallPhase.calling) {
        _ringStop();
        _setPhase(CallPhase.connecting, 'Conectando…');
      }
    } catch (_) {
      s.remoteSet = false;
      _fail('Resposta da chamada inválida.');
    }
  }

  // ---------------------------------------------------------------- polling / ping

  void _startTimers(_Session s) {
    s.pollTimer?.cancel();
    s.pollTimer = Timer.periodic(const Duration(milliseconds: 2500), (_) => _poll());
    _config().then((c) {
      if (_s != s) return;
      s.pingTimer?.cancel();
      s.pingTimer = Timer.periodic(Duration(seconds: c.pingSeconds < 5 ? 5 : c.pingSeconds), (_) async {
        final id = s.id;
        if (_s != s || id == null) return;
        try {
          final st = await _svc!.ping(id);
          if (_s == s && _isEnded(st)) _finish(callEndMessage(st, null, outgoing: s.outgoing));
        } on ApiException catch (e) {
          if (e.statusCode == 404 && _s == s) _finish('Chamada encerrada.');
        } catch (_) {}
      });
    }).catchError((_) {});
  }

  bool _polling = false;
  Future<void> _poll() async {
    final s = _s;
    final id = s?.id;
    if (s == null || id == null || _polling || _phase == CallPhase.incoming) return;
    if (_phase == CallPhase.active && ChatLive.instance.connected) return; // SSE vivo: o ping basta
    _polling = true;
    try {
      final d = await _svc!.get(id);
      if (_s != s) return;
      if (_isEnded(d.state)) {
        _finish(callEndMessage(d.state, d.endReason, outgoing: s.outgoing));
        return;
      }
      if (d.answerSdp != null) _applyAnswer(s, d.answerSdp);
      for (final c in d.ice) {
        _addRemoteIce(s, c);
      }
    } on ApiException catch (e) {
      if (e.statusCode == 404 && _s == s) _finish('Chamada encerrada.');
    } catch (_) {
    } finally {
      _polling = false;
    }
  }

  // ---------------------------------------------------------------- ações

  /// Liga para [username] (voz por padrão; [media] = `CallMedia.video` para vídeo).
  Future<void> startCall(String username, String name, String? avatarUrl, {CallMedia media = CallMedia.voice}) async {
    if (_s != null) {
      _openScreen();
      return;
    }
    final svc = _svc;
    if (svc == null) return;
    final me = _Session(outgoing: true, username: username, name: name, avatar: avatarUrl, media: media);
    _s = me;
    _muted = false;
    _speaker = false;
    _camOff = false;
    _frontCam = true;
    _remoteVideo = false;
    _warning = null;
    _setPhase(CallPhase.calling, 'Preparando…');
    _openScreen();
    _pauseChatMedia();
    try {
      final cfg = await _config();
      if (!cfg.enabled) throw _Soft('As chamadas estão desativadas no servidor.');
      _turnMissing = !cfg.turnConfigured;
      if (_turnMissing) {
        _warning = 'Modo de teste: sem servidor TURN, a chamada pode ficar muda em algumas redes.';
        notifyListeners();
      }
      final stream = await _getMedia(me);
      if (_s != me) {
        await _disposeStream(stream);
        return;
      }
      me.stream = stream;
      await _showLocal(me);
      final pc = await _makePc(me, cfg);
      final offer = await pc.createOffer({'offerToReceiveAudio': 1, 'offerToReceiveVideo': media == CallMedia.video ? 1 : 0});
      await pc.setLocalDescription(offer);
      final call = await svc.start(username, media, offer.sdp!, clientId: me.clientId);
      if (_s != me) {
        _quiet(svc.end(call.id));
        return;
      }
      me.id = call.id;
      _seen.add(call.id);
      _setStatus('Chamando…');
      _flushOutIce(me);
      _startTimers(me);
      me.ringTimer = Timer(Duration(seconds: call.ringSeconds + 3), () {
        if (_s == me && _phase == CallPhase.calling) _poll();
      });
    } on _Soft catch (e) {
      if (_s == me) _finish(e.msg);
    } on ApiException catch (e) {
      final msg = switch (e.code) {
        'busy' => 'Está em outra chamada.',
        'already_in_call' => 'Você já está em uma chamada.',
        _ => e.statusCode == 404
            ? 'Usuário não encontrado.'
            : e.statusCode == 503
                ? 'As chamadas estão desativadas no servidor.'
                : 'Não foi possível iniciar a chamada.',
      };
      if (_s == me) _finish(msg);
    } catch (_) {
      if (_s == me) _finish('Não foi possível iniciar a chamada.');
    }
  }

  void _startIncoming(int id, String username, String name, String? avatar, CallMedia media, String? offerSdp, int ringSeconds) {
    if (_seen.contains(id)) return;
    _seen.add(id);
    if (_s != null) return; // já em chamada: o servidor já respondeu "ocupado"
    final me = _Session(outgoing: false, username: username, name: name, avatar: avatar, media: media)
      ..id = id
      ..offerSdp = offerSdp;
    _s = me;
    _muted = false;
    _speaker = false;
    _camOff = false;
    _frontCam = true;
    _remoteVideo = false;
    _warning = null;
    _setPhase(CallPhase.incoming, media == CallMedia.video ? 'Chamada de vídeo recebida' : 'Chamada de voz recebida');
    _openScreen();
    _pauseChatMedia();
    _ringStart();
    // Completa nome/avatar (o evento só traz o @) e a offer (push/retomada).
    _svc?.get(id).then((c) {
      if (_s != me) return;
      me.name = c.partner.displayName;
      me.avatar = c.partner.avatarUrl;
      me.offerSdp ??= c.offerSdp;
      notifyListeners();
    }).catchError((_) {});
    me.ringTimer = Timer(Duration(seconds: ringSeconds + 5), () {
      if (_s == me && _phase == CallPhase.incoming) _finish('Chamada perdida.');
    });
  }

  Future<void> accept() async {
    final me = _s;
    final svc = _svc;
    if (me == null || svc == null || _phase != CallPhase.incoming || me.answering) return;
    me.answering = true;
    _ringStop();
    _setPhase(CallPhase.connecting, 'Conectando…');
    try {
      final cfg = await _config();
      _turnMissing = !cfg.turnConfigured;
      final stream = await _getMedia(me);
      if (_s != me) {
        await _disposeStream(stream);
        return;
      }
      me.stream = stream;
      await _showLocal(me);
      String? offer = me.offerSdp;
      offer ??= (await svc.get(me.id!)).offerSdp;
      if (offer == null) throw _Soft('A chamada não está mais disponível.');
      final pc = await _makePc(me, cfg);
      await pc.setRemoteDescription(RTCSessionDescription(offer, 'offer'));
      me.remoteSet = true;
      final answer = await pc.createAnswer({'offerToReceiveAudio': 1, 'offerToReceiveVideo': me.media == CallMedia.video ? 1 : 0});
      await pc.setLocalDescription(answer);
      await svc.answer(me.id!, answer.sdp!);
      if (_s != me) return;
      _flushOutIce(me);
      _startTimers(me);
      final call = await svc.get(me.id!);
      if (_s == me) {
        for (final c in call.ice) {
          _addRemoteIce(me, c);
        }
        _flushPendIce(me);
      }
    } on _Soft catch (e) {
      if (_s == me) {
        final id = me.id;
        if (id != null) _quiet(svc.end(id));
        _finish(e.msg);
      }
    } on ApiException catch (e) {
      if (_s == me) {
        if (e.statusCode != 409 && me.id != null) _quiet(svc.end(me.id!));
        _finish(e.statusCode == 409 ? 'Esta chamada não está mais tocando.' : 'Não foi possível atender.');
      }
    } catch (_) {
      if (_s == me) {
        if (me.id != null) _quiet(svc.end(me.id!));
        _finish('Não foi possível atender.');
      }
    }
  }

  void decline() {
    final id = _s?.id;
    if (id != null) _quiet(_svc?.decline(id));
    _finish('', silent: true);
  }

  void hangup() {
    final id = _s?.id;
    if (id != null) _quiet(_svc?.end(id));
    _finish('Chamada encerrada.');
  }

  void _fail(String msg) {
    final id = _s?.id;
    if (id != null) _quiet(_svc?.end(id, error: true));
    _finish(msg);
  }

  void toggleMute() {
    final s = _s;
    if (s?.stream == null) return;
    _muted = !_muted;
    for (final t in s!.stream!.getAudioTracks()) {
      t.enabled = !_muted;
    }
    notifyListeners();
  }

  /// Liga/desliga o envio da imagem (a trilha continua; a outra pessoa vê preto/congelado, e a
  /// miniatura local fica apagada).
  void toggleCamera() {
    final s = _s;
    final tracks = s?.stream?.getVideoTracks() ?? <MediaStreamTrack>[];
    if (tracks.isEmpty) return;
    _camOff = !_camOff;
    for (final t in tracks) {
      t.enabled = !_camOff;
    }
    notifyListeners();
  }

  /// Alterna entre câmera frontal e traseira.
  Future<void> switchCamera() async {
    final tracks = _s?.stream?.getVideoTracks() ?? <MediaStreamTrack>[];
    if (tracks.isEmpty) return;
    try {
      await Helper.switchCamera(tracks.first);
      _frontCam = !_frontCam;
      notifyListeners();
    } catch (_) {}
  }

  void toggleSpeaker() {
    _speaker = !_speaker;
    try {
      Helper.setSpeakerphoneOn(_speaker);
    } catch (_) {}
    notifyListeners();
  }

  Future<void> _disposeStream(MediaStream? stream) async {
    try {
      for (final t in stream?.getTracks() ?? <MediaStreamTrack>[]) {
        await t.stop();
      }
      await stream?.dispose();
    } catch (_) {}
  }

  void _cleanup(_Session s) {
    s.pollTimer?.cancel();
    s.pingTimer?.cancel();
    s.clock?.cancel();
    s.discTimer?.cancel();
    s.ringTimer?.cancel();
    _ringStop();
    final pc = s.pc;
    s.pc = null;
    pc?.onConnectionState = null;
    pc?.onIceConnectionState = null;
    pc?.onIceCandidate = null;
    pc?.close();
    _disposeStream(s.stream);
    s.stream = null;
    if (_renderersReady) {
      localRenderer.srcObject = null;
      remoteRenderer.srcObject = null;
    }
    _remoteVideo = false;
    _camOff = false;
    _frontCam = true;
  }

  /// Encerra a sessão local. Com [silent] (ou sem mensagem) fecha a tela na hora; senão mostra a
  /// mensagem (+ duração) por ~1,8 s.
  void _finish(String msg, {bool silent = false}) {
    final s = _s;
    if (s == null) return;
    final dur = _phase == CallPhase.active ? _elapsed(s) : '';
    _cleanup(s);
    _s = null;
    if (silent || msg.isEmpty) {
      _setPhase(CallPhase.idle, '');
      _closeScreen();
      return;
    }
    _setPhase(CallPhase.ended, dur.isEmpty ? msg : '$msg · $dur');
    Future<void>.delayed(const Duration(milliseconds: 1800), () {
      if (_s == null && _phase == CallPhase.ended) {
        _setPhase(CallPhase.idle, '');
        _closeScreen();
      }
    });
  }
}
