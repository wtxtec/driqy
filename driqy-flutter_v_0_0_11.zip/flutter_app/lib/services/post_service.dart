import 'dart:io';

import '../models/comment.dart';
import '../models/post.dart';
import 'api_client.dart';

class PostService {
  final ApiClient client;

  PostService(this.client);

  Future<DriqyPost> getPost(int postId) async {
    final data = await client.get('/posts/$postId');
    return DriqyPost.fromJson(data);
  }

  Future<bool> toggleLike(int postId) async {
    final data = await client.post('/posts/$postId/like');
    return data['liked'] as bool;
  }

  Future<List<DriqyComment>> getComments(int postId) async {
    final data = await client.get('/posts/$postId/comments');
    return (data['comments'] as List<dynamic>)
        .map((c) => DriqyComment.fromJson(c as Map<String, dynamic>))
        .toList();
  }

  Future<DriqyComment> addComment(int postId, String content, {int? parentId}) async {
    final data = await client.post('/posts/$postId/comments', body: {
      'content': content,
      if (parentId != null) 'parent_id': parentId,
    });
    return DriqyComment.fromJson(data);
  }

  /// Exclui um post do próprio usuário (permanente ou temporário).
  Future<void> deletePost(int postId) async {
    await client.delete('/posts/$postId');
  }

  /// Cria um post de texto (sem mídia).
  Future<DriqyPost> createTextPost({
    required String textContent,
    int? durationMinutes, // null/0 = post permanente (sem expiração)
  }) async {
    final data = await client.post('/posts', body: {
      'post_type': 'text',
      'text_content': textContent,
      if (durationMinutes != null && durationMinutes > 0) 'duration_minutes': durationMinutes,
    });
    return DriqyPost.fromJson(data);
  }

  /// Cria um post com uma ou mais fotos/vídeos anexados.
  Future<DriqyPost> createMediaPost({
    required String postType, // photo | video | gif
    required String textContent,
    int? durationMinutes, // null/0 = post permanente (sem expiração)
    required List<File> files,
  }) async {
    final data = await client.postMultipart(
      '/posts',
      fields: {
        'post_type': postType,
        'text_content': textContent,
        if (durationMinutes != null && durationMinutes > 0)
          'duration_minutes': durationMinutes.toString(),
      },
      files: files,
    );
    return DriqyPost.fromJson(data);
  }
}
