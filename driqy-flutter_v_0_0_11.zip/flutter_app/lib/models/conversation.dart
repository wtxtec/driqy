import 'message.dart';
import 'presence.dart';
import 'user.dart';

/// Uma linha da caixa de entrada: com quem é a conversa, a última
/// mensagem trocada e quantas mensagens ainda não foram lidas.
class DriqyConversation {
  final DriqyUser partner;
  final DriqyMessage? lastMessage;
  final int unread;
  final DriqyPresence presence; // Fase 10
  final DriqyChatPrefs prefs; // Fase 10: fixada / silenciada / arquivada

  DriqyConversation({
    required this.partner,
    required this.lastMessage,
    required this.unread,
    this.presence = DriqyPresence.hidden,
    this.prefs = const DriqyChatPrefs(),
  });

  factory DriqyConversation.fromJson(Map<String, dynamic> json) {
    return DriqyConversation(
      partner: DriqyUser.fromJson(json['partner'] as Map<String, dynamic>),
      lastMessage: json['last_message'] != null
          ? DriqyMessage.fromJson(json['last_message'] as Map<String, dynamic>)
          : null,
      unread: json['unread'] as int? ?? 0,
      presence: DriqyPresence.fromJson(
          (json['partner'] as Map<String, dynamic>)['presence'] as Map<String, dynamic>?),
      prefs: DriqyChatPrefs.fromJson(json['prefs'] as Map<String, dynamic>?),
    );
  }
}
