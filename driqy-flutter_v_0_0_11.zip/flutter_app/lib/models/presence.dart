/// Presença do outro lado da conversa (Fase 10): online / visto por último.
/// `visible == false` quando ele (ou eu) escondeu — nesse caso nada é mostrado.
class DriqyPresence {
  final bool visible;
  final bool online;
  final DateTime? lastSeenAt; // UTC

  const DriqyPresence({this.visible = false, this.online = false, this.lastSeenAt});

  static const DriqyPresence hidden = DriqyPresence();

  /// Servidor antigo (sem o campo) → escondido, a tela mostra só o @.
  factory DriqyPresence.fromJson(Map<String, dynamic>? json) {
    if (json == null) return hidden;
    final raw = json['last_seen_at'] as String?;
    return DriqyPresence(
      visible: json['visible'] as bool? ?? false,
      online: json['online'] as bool? ?? false,
      lastSeenAt: raw != null ? DateTime.tryParse(raw) : null,
    );
  }

  DriqyPresence copyWith({bool? visible, bool? online, DateTime? lastSeenAt}) => DriqyPresence(
        visible: visible ?? this.visible,
        online: online ?? this.online,
        lastSeenAt: lastSeenAt ?? this.lastSeenAt,
      );
}

/// Fixar / silenciar / arquivar a conversa — só vale para mim (Fase 10).
class DriqyChatPrefs {
  final bool pinned;
  final bool muted;
  final bool archived;

  const DriqyChatPrefs({this.pinned = false, this.muted = false, this.archived = false});

  factory DriqyChatPrefs.fromJson(Map<String, dynamic>? json) {
    if (json == null) return const DriqyChatPrefs();
    return DriqyChatPrefs(
      pinned: json['pinned'] as bool? ?? false,
      muted: json['muted'] as bool? ?? false,
      archived: json['archived'] as bool? ?? false,
    );
  }

  DriqyChatPrefs copyWith({bool? pinned, bool? muted, bool? archived}) => DriqyChatPrefs(
        pinned: pinned ?? this.pinned,
        muted: muted ?? this.muted,
        archived: archived ?? this.archived,
      );
}
