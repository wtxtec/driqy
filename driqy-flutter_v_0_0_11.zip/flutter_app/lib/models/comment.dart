import 'user.dart';

class DriqyComment {
  final int id;
  final DriqyUser author;
  final String content;
  final DateTime createdAt;
  final int? parentId;

  DriqyComment({
    required this.id,
    required this.author,
    required this.content,
    required this.createdAt,
    required this.parentId,
  });

  factory DriqyComment.fromJson(Map<String, dynamic> json) {
    return DriqyComment(
      id: json['id'] as int,
      author: DriqyUser.fromJson(json['author'] as Map<String, dynamic>),
      content: json['content'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      parentId: json['parent_id'] as int?,
    );
  }
}
