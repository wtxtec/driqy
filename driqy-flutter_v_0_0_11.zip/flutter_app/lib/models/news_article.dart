import 'package:flutter/material.dart';

/// Categoria de notícia (chave + rótulo), espelhando `NEWS_CATEGORIES`
/// em `config.py` no servidor.
class NewsCategory {
  final String key;
  final String label;

  NewsCategory({required this.key, required this.label});

  factory NewsCategory.fromJson(Map<String, dynamic> json) {
    return NewsCategory(key: json['key'] as String, label: json['label'] as String);
  }
}

/// Uma notícia indexada, no formato devolvido por `/api/v1/news` — mesmo
/// artigo mostrado no mosaico do site (`_news_card.html`), só que em
/// JSON. `tileSize` já vem decidido pelo servidor (large/wide/tall/normal)
/// pra manter o mesmo ritmo de mosaico do site.
class NewsArticle {
  final int id;
  final String title;
  final String summary;
  final String category;
  final String categoryLabel;
  final Color categoryColor;
  final String? imageUrl;
  final String? faviconUrl;
  final String sourceName;
  final String domain;
  final String articleUrl;
  final DateTime? publishedAt;
  final String tileSize; // large | wide | tall | normal

  NewsArticle({
    required this.id,
    required this.title,
    required this.summary,
    required this.category,
    required this.categoryLabel,
    required this.categoryColor,
    required this.imageUrl,
    required this.faviconUrl,
    required this.sourceName,
    required this.domain,
    required this.articleUrl,
    required this.publishedAt,
    required this.tileSize,
  });

  factory NewsArticle.fromJson(Map<String, dynamic> json) {
    return NewsArticle(
      id: json['id'] as int,
      title: json['title'] as String,
      summary: json['summary'] as String? ?? '',
      category: json['category'] as String,
      categoryLabel: json['category_label'] as String? ?? json['category'] as String,
      categoryColor: _parseHexColor(json['category_color'] as String?),
      imageUrl: json['image_url'] as String?,
      faviconUrl: json['favicon_url'] as String?,
      sourceName: json['source_name'] as String? ?? '',
      domain: json['domain'] as String? ?? '',
      articleUrl: json['article_url'] as String,
      publishedAt: json['published_at'] != null
          ? DateTime.tryParse(json['published_at'] as String)
          : null,
      tileSize: json['tile_size'] as String? ?? 'normal',
    );
  }

  static Color _parseHexColor(String? hex) {
    if (hex == null || hex.isEmpty) return const Color(0xFF8F9BBF);
    final cleaned = hex.replaceFirst('#', '');
    final value = int.tryParse(cleaned, radix: 16);
    if (value == null) return const Color(0xFF8F9BBF);
    return Color(0xFF000000 | value);
  }

  /// Tempo relativo curto ("agora mesmo", "há 3 min", "há 2h"...), mesma
  /// ideia do filtro `time_ago` do site — calculado no cliente porque o
  /// "agora" muda a cada rebuild sem precisar de nova chamada à API.
  String get timeAgo {
    final published = publishedAt;
    if (published == null) return '';
    final seconds = DateTime.now().toUtc().difference(published).inSeconds;
    if (seconds < 60) return 'agora mesmo';
    final minutes = seconds ~/ 60;
    if (minutes < 60) return 'há $minutes min';
    final hours = minutes ~/ 60;
    if (hours < 24) return 'há ${hours}h';
    final days = hours ~/ 24;
    if (days < 7) return 'há $days dia${days > 1 ? 's' : ''}';
    final weeks = days ~/ 7;
    if (weeks < 5) return 'há $weeks semana${weeks > 1 ? 's' : ''}';
    final months = days ~/ 30;
    return 'há ${months < 1 ? 1 : months} mês${months > 1 ? 'es' : ''}';
  }
}
