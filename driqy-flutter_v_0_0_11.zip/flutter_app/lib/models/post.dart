import 'user.dart';

class PostMedia {
  final String url;
  final String mediaType; // photo | video | gif | audio

  PostMedia({required this.url, required this.mediaType});

  factory PostMedia.fromJson(Map<String, dynamic> json) {
    return PostMedia(
      url: json['url'] as String,
      mediaType: json['media_type'] as String,
    );
  }
}

class DriqyPost {
  final int id;
  final DriqyUser author;
  final String postType;
  final String textContent;
  final List<PostMedia> media;
  final DateTime createdAt;
  /// null = post permanente (sem expiração); só posts temporários têm prazo.
  final DateTime? expiresAt;
  final int? secondsRemaining;
  final String expiresLabel;
  final int viewsCount;
  int likesCount;
  int commentsCount;
  bool likedByMe;
  final String? sourceClient; // "android" | "iphone" | "web" | null

  DriqyPost({
    required this.id,
    required this.author,
    required this.postType,
    required this.textContent,
    required this.media,
    required this.createdAt,
    required this.expiresAt,
    required this.secondsRemaining,
    required this.expiresLabel,
    required this.viewsCount,
    required this.likesCount,
    required this.commentsCount,
    required this.likedByMe,
    this.sourceClient,
  });

  bool get isTemporary => expiresAt != null;

  factory DriqyPost.fromJson(Map<String, dynamic> json) {
    return DriqyPost(
      id: json['id'] as int,
      author: DriqyUser.fromJson(json['author'] as Map<String, dynamic>),
      postType: json['post_type'] as String,
      textContent: json['text_content'] as String? ?? '',
      media: (json['media'] as List<dynamic>? ?? [])
          .map((m) => PostMedia.fromJson(m as Map<String, dynamic>))
          .toList(),
      createdAt: DateTime.parse(json['created_at'] as String),
      expiresAt: json['expires_at'] != null ? DateTime.parse(json['expires_at'] as String) : null,
      secondsRemaining: json['seconds_remaining'] as int?,
      expiresLabel: json['expires_label'] as String? ?? '',
      viewsCount: json['views_count'] as int? ?? 0,
      likesCount: json['likes_count'] as int? ?? 0,
      commentsCount: json['comments_count'] as int? ?? 0,
      likedByMe: json['liked_by_me'] as bool? ?? false,
      sourceClient: json['source_client'] as String?,
    );
  }
}
