import 'user.dart';

/// Fase 11: chamada de voz/vídeo (sinalização). A mídia (WebRTC) está em `call_manager.dart` (Fase 12).
enum CallMedia { voice, video }

enum CallState { ringing, accepted, declined, missed, ended, failed, busy, unknown }

CallState parseCallState(String? raw) => switch (raw) {
      'ringing' => CallState.ringing,
      'accepted' => CallState.accepted,
      'declined' => CallState.declined,
      'missed' => CallState.missed,
      'ended' => CallState.ended,
      'failed' => CallState.failed,
      'busy' => CallState.busy,
      _ => CallState.unknown,
    };

class DriqyCall {
  final int id;
  final CallMedia media;
  final CallState state;
  final String? endReason; // canceled|timeout|hangup|declined|busy|stale|error
  final bool outgoing;
  final DriqyUser partner;
  final DateTime? createdAt; // UTC
  final DateTime? answeredAt;
  final DateTime? endedAt;
  final int durationS;
  final int ringSeconds;

  /// Só enquanto a chamada está viva (e só para quem precisa).
  final String? offerSdp; // callee
  final String? answerSdp; // caller, depois de atender
  final List<Map<String, dynamic>> ice; // candidatos já enviados pelo outro lado

  const DriqyCall({
    required this.id,
    required this.media,
    required this.state,
    required this.outgoing,
    required this.partner,
    this.endReason,
    this.createdAt,
    this.answeredAt,
    this.endedAt,
    this.durationS = 0,
    this.ringSeconds = 45,
    this.offerSdp,
    this.answerSdp,
    this.ice = const [],
  });

  bool get isActive => state == CallState.ringing || state == CallState.accepted;
  bool get isVideo => media == CallMedia.video;

  factory DriqyCall.fromJson(Map<String, dynamic> json) {
    DateTime? dt(String k) => json[k] is String ? DateTime.tryParse(json[k] as String) : null;
    final offer = json['offer'] as Map<String, dynamic>?;
    final answer = json['answer'] as Map<String, dynamic>?;
    return DriqyCall(
      id: (json['id'] as num).toInt(),
      media: json['media'] == 'video' ? CallMedia.video : CallMedia.voice,
      state: parseCallState(json['state'] as String?),
      endReason: json['end_reason'] as String?,
      outgoing: json['direction'] == 'outgoing',
      partner: DriqyUser.fromJson(json['partner'] as Map<String, dynamic>),
      createdAt: dt('created_at'),
      answeredAt: dt('answered_at'),
      endedAt: dt('ended_at'),
      durationS: (json['duration_s'] as num?)?.toInt() ?? 0,
      ringSeconds: (json['ring_seconds'] as num?)?.toInt() ?? 45,
      offerSdp: offer?['sdp'] as String?,
      answerSdp: answer?['sdp'] as String?,
      ice: [
        for (final c in (json['ice'] as List? ?? const [])) Map<String, dynamic>.from(c as Map),
      ],
    );
  }
}

/// Um servidor ICE (STUN/TURN) — vira `iceServers` do `RTCPeerConnection` (Fase 12).
class DriqyIceServer {
  final List<String> urls;
  final String? username;
  final String? credential;

  const DriqyIceServer({required this.urls, this.username, this.credential});

  factory DriqyIceServer.fromJson(Map<String, dynamic> json) {
    final u = json['urls'];
    return DriqyIceServer(
      urls: u is List ? [for (final x in u) x.toString()] : [u.toString()],
      username: json['username'] as String?,
      credential: json['credential'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'urls': urls,
        if (username != null) 'username': username,
        if (credential != null) 'credential': credential,
      };
}

class CallConfig {
  final bool enabled;
  final List<DriqyIceServer> iceServers;
  final bool turnConfigured; // false = só STUN: falha em ~10–20% das redes
  final int ringSeconds;
  final int pingSeconds;

  const CallConfig({
    this.enabled = true,
    this.iceServers = const [],
    this.turnConfigured = false,
    this.ringSeconds = 45,
    this.pingSeconds = 20,
  });

  factory CallConfig.fromJson(Map<String, dynamic> json) => CallConfig(
        enabled: json['enabled'] as bool? ?? true,
        iceServers: [
          for (final s in (json['ice_servers'] as List? ?? const []))
            DriqyIceServer.fromJson(Map<String, dynamic>.from(s as Map)),
        ],
        turnConfigured: json['turn_configured'] as bool? ?? false,
        ringSeconds: (json['ring_seconds'] as num?)?.toInt() ?? 45,
        pingSeconds: (json['ping_seconds'] as num?)?.toInt() ?? 20,
      );
}

/// "0:07", "12:03", "1:02:03" — tempo de chamada.
String callElapsedLabel(int seconds) {
  final s = seconds < 0 ? 0 : seconds;
  final h = s ~/ 3600, m = (s % 3600) ~/ 60, r = s % 60;
  String two(int n) => n < 10 ? '0$n' : '$n';
  return h > 0 ? '$h:${two(m)}:${two(r)}' : '$m:${two(r)}';
}

/// Texto mostrado quando a chamada termina (espelha `endText` do site).
String callEndMessage(CallState state, String? reason, {required bool outgoing}) {
  switch (state) {
    case CallState.declined:
      return 'Chamada recusada.';
    case CallState.missed:
      return outgoing ? 'Sem resposta.' : 'Chamada perdida.';
    case CallState.busy:
      return 'Ocupado.';
    case CallState.failed:
      return 'A chamada falhou.';
    default:
      return reason == 'stale' ? 'Chamada encerrada (sem sinal).' : 'Chamada encerrada.';
  }
}
