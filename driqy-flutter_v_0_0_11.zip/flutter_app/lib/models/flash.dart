/// Flash — foto de 24h estilo "stories" (backend: `flashes.py`).
class FlashOwner {
  final int id;
  final String username;
  final String displayName;
  final String? avatarUrl;

  FlashOwner({
    required this.id,
    required this.username,
    required this.displayName,
    required this.avatarUrl,
  });

  factory FlashOwner.fromJson(Map<String, dynamic> json) => FlashOwner(
        id: json['id'] as int,
        username: json['username'] as String,
        displayName: json['display_name'] as String? ?? json['username'] as String,
        avatarUrl: json['avatar_url'] as String?,
      );
}

class FlashItem {
  final int id;
  final String imageUrl;
  final String caption;
  final DateTime createdAt;
  final DateTime expiresAt;
  bool seen;

  /// Só vem preenchido para o DONO do Flash (null para quem assiste).
  final int? viewsCount;

  FlashItem({
    required this.id,
    required this.imageUrl,
    required this.caption,
    required this.createdAt,
    required this.expiresAt,
    required this.seen,
    required this.viewsCount,
  });

  bool get isMine => viewsCount != null;

  factory FlashItem.fromJson(Map<String, dynamic> json) => FlashItem(
        id: json['id'] as int,
        imageUrl: json['image_url'] as String,
        caption: json['caption'] as String? ?? '',
        createdAt: DateTime.parse(json['created_at'] as String),
        expiresAt: DateTime.parse(json['expires_at'] as String),
        seen: json['seen'] as bool? ?? false,
        viewsCount: json['views_count'] as int?,
      );
}

class FlashGroup {
  final FlashOwner user;
  final List<FlashItem> flashes;

  FlashGroup({required this.user, required this.flashes});

  factory FlashGroup.fromJson(Map<String, dynamic> json) => FlashGroup(
        user: FlashOwner.fromJson(json['user'] as Map<String, dynamic>),
        flashes: ((json['flashes'] as List<dynamic>?) ?? const [])
            .map((f) => FlashItem.fromJson(f as Map<String, dynamic>))
            .toList(),
      );
}

class FlashTrayEntry {
  final FlashOwner user;
  final int count;
  final bool unseen;

  FlashTrayEntry({required this.user, required this.count, required this.unseen});

  factory FlashTrayEntry.fromJson(Map<String, dynamic> json) => FlashTrayEntry(
        user: FlashOwner.fromJson(json['user'] as Map<String, dynamic>),
        count: json['count'] as int? ?? 0,
        unseen: json['unseen'] as bool? ?? false,
      );
}

class FlashTray {
  final FlashOwner me;
  final int myCount;
  final List<FlashTrayEntry> items;

  FlashTray({required this.me, required this.myCount, required this.items});

  factory FlashTray.fromJson(Map<String, dynamic> json) {
    final mine = json['me'] as Map<String, dynamic>;
    return FlashTray(
      me: FlashOwner.fromJson(mine['user'] as Map<String, dynamic>),
      myCount: mine['count'] as int? ?? 0,
      items: ((json['items'] as List<dynamic>?) ?? const [])
          .map((e) => FlashTrayEntry.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

class FlashViewer {
  final String username;
  final DateTime viewedAt;

  FlashViewer({required this.username, required this.viewedAt});

  factory FlashViewer.fromJson(Map<String, dynamic> json) => FlashViewer(
        username: json['username'] as String,
        viewedAt: DateTime.parse(json['viewed_at'] as String),
      );
}
