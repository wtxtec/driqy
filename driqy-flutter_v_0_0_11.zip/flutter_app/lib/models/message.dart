import 'dart:math';

/// Tipos de mensagem aceitos pelo backend (`msg_type`). Tipos
/// desconhecidos (de versões futuras do servidor) caem em [text].
enum MessageType { text, image, video, audio, file, call }

/// Estado local, só do app: mensagem ainda sendo enviada ou que falhou.
/// Mensagens que já estão no servidor têm `localState == null`.
enum MessageLocalState { sending, failed }

/// Uma reação agrupada por emoji: quantas pessoas usaram e se uma delas sou eu.
class DriqyReaction {
  final String emoji;
  final int count;
  final bool mine;

  const DriqyReaction({required this.emoji, required this.count, required this.mine});

  factory DriqyReaction.fromJson(Map<String, dynamic> json) => DriqyReaction(
        emoji: json['emoji'] as String,
        count: json['count'] as int? ?? 1,
        mine: json['mine'] as bool? ?? false,
      );
}

/// Aplica a minha reação sobre a lista atual (pra atualizar a tela antes da
/// resposta do servidor). `emoji == null` remove a minha reação. A
/// reação é única por pessoa: reagir com outro emoji troca o anterior.
List<DriqyReaction> applyMyReaction(List<DriqyReaction> current, String? emoji) {
  final out = <DriqyReaction>[];
  for (final r in current) {
    if (r.mine) {
      if (r.count > 1) out.add(DriqyReaction(emoji: r.emoji, count: r.count - 1, mine: false));
    } else {
      out.add(r);
    }
  }
  if (emoji != null) {
    final i = out.indexWhere((r) => r.emoji == emoji);
    if (i >= 0) {
      out[i] = DriqyReaction(emoji: emoji, count: out[i].count + 1, mine: true);
    } else {
      out.add(DriqyReaction(emoji: emoji, count: 1, mine: true));
    }
  }
  out.sort((a, b) => b.count.compareTo(a.count));
  return out;
}

/// Resumo da mensagem respondida (`reply_to` do backend).
class DriqyReplyRef {
  final int id;
  final int? senderId;
  final String msgType;
  final String preview;

  const DriqyReplyRef({
    required this.id,
    required this.senderId,
    required this.msgType,
    required this.preview,
  });

  /// Referência a uma mensagem que está sendo respondida (antes de o
  /// servidor confirmar o envio): o texto/legenda ou o rótulo da mídia.
  factory DriqyReplyRef.fromMessage(DriqyMessage m) => DriqyReplyRef(
        id: m.id,
        senderId: m.senderId,
        msgType: m.msgType,
        preview: m.previewText.length > 80 ? m.previewText.substring(0, 80) : m.previewText,
      );

  factory DriqyReplyRef.fromJson(Map<String, dynamic> json) {
    return DriqyReplyRef(
      id: json['id'] as int,
      senderId: json['sender_id'] as int?,
      msgType: json['msg_type'] as String? ?? 'text',
      preview: json['preview'] as String? ?? '',
    );
  }
}

/// Mensagem direta trocada entre dois usuários (chat 1-para-1).
///
/// Todos os campos novos (Fase 1 do backend) são opcionais: um servidor
/// antigo, que só manda `content`, continua funcionando.
class DriqyMessage {
  final int id;
  final String content;
  final String? caption;
  final String msgType;
  final String? mediaUrl; // relativa: precisa de base da API + header Bearer
  final String? mediaMime;
  final String? mediaThumbUrl; // miniatura de vídeo (relativa, precisa de Bearer)
  final int? mediaSize;
  final int? mediaDurationMs;
  final int? mediaWidth;
  final int? mediaHeight;
  /// Fase 15: nome ORIGINAL de um documento (`msg_type=file`).
  final String? mediaName;
  final DriqyReplyRef? replyTo;
  final String? clientId;
  final int senderId;
  final int? recipientId;
  final DateTime createdAt;
  final DateTime? deliveredAt;
  final DateTime? readAt;
  final DateTime? editedAt;
  final bool deleted;
  /// O servidor diz se ainda dá para "apagar para todos" (janela de 48 h, só remetente).
  final bool canDeleteForAll;
  /// Fase 8: o servidor diz se ainda dá para editar (só texto, só o remetente, janela de 24 h).
  final bool canEdit;
  /// Fase 8: mensagem encaminhada (mostra "Encaminhada" no balão).
  final bool forwarded;
  /// Visualização única (foto/vídeo/áudio): o servidor NÃO manda a URL da mídia na lista.
  /// `viewOnceState`: unopened | opened | expired. `canOpenViewOnce`: só o destinatário, antes de abrir.
  final bool viewOnce;
  final String? viewOnceState;
  final bool canOpenViewOnce;
  final bool isRead;
  final bool mine;
  final MessageLocalState? localState;
  final List<DriqyReaction> reactions;

  /// Arquivo no aparelho de uma mídia ainda não enviada (ou que falhou):
  /// a bolha mostra ele direto, sem baixar de novo, e o reenvio reaproveita.
  final String? localPath;

  /// Miniatura JPEG local de um vídeo ainda não enviado (opcional).
  final String? localThumbPath;

  DriqyMessage({
    required this.id,
    required this.content,
    required this.senderId,
    required this.recipientId,
    required this.createdAt,
    required this.mine,
    this.caption,
    this.msgType = 'text',
    this.mediaUrl,
    this.mediaMime,
    this.mediaThumbUrl,
    this.mediaSize,
    this.mediaDurationMs,
    this.mediaWidth,
    this.mediaHeight,
    this.mediaName,
    this.replyTo,
    this.clientId,
    this.deliveredAt,
    this.readAt,
    this.editedAt,
    this.deleted = false,
    this.canDeleteForAll = false,
    this.canEdit = false,
    this.forwarded = false,
    this.viewOnce = false,
    this.viewOnceState,
    this.canOpenViewOnce = false,
    this.isRead = false,
    this.localState,
    this.reactions = const [],
    this.localPath,
    this.localThumbPath,
  });

  factory DriqyMessage.fromJson(Map<String, dynamic> json) {
    DateTime? date(String key) =>
        json[key] != null ? DateTime.tryParse(json[key] as String) : null;
    return DriqyMessage(
      id: json['id'] as int,
      content: json['content'] as String? ?? '',
      caption: json['caption'] as String?,
      msgType: json['msg_type'] as String? ?? 'text',
      mediaUrl: json['media_url'] as String?,
      mediaMime: json['media_mime'] as String?,
      mediaThumbUrl: json['media_thumb_url'] as String?,
      mediaSize: json['media_size'] as int?,
      mediaDurationMs: json['media_duration_ms'] as int?,
      mediaWidth: json['media_width'] as int?,
      mediaHeight: json['media_height'] as int?,
      mediaName: json['media_name'] as String?,
      replyTo: json['reply_to'] != null
          ? DriqyReplyRef.fromJson(json['reply_to'] as Map<String, dynamic>)
          : null,
      clientId: json['client_id'] as String?,
      senderId: json['sender_id'] as int,
      recipientId: json['recipient_id'] as int?,
      createdAt: DateTime.parse(json['created_at'] as String),
      deliveredAt: date('delivered_at'),
      readAt: date('read_at'),
      editedAt: date('edited_at'),
      deleted: json['deleted'] as bool? ?? false,
      canDeleteForAll: json['can_delete_for_all'] as bool? ?? false,
      canEdit: json['can_edit'] as bool? ?? false,
      forwarded: json['forwarded'] as bool? ?? false,
      viewOnce: json['view_once'] as bool? ?? false,
      viewOnceState: json['view_once_state'] as String?,
      canOpenViewOnce: json['can_open_view_once'] as bool? ?? false,
      isRead: json['is_read'] as bool? ?? false,
      mine: json['mine'] as bool? ?? false,
      reactions: (json['reactions'] as List<dynamic>? ?? const [])
          .map((r) => DriqyReaction.fromJson(r as Map<String, dynamic>))
          .toList(),
    );
  }

  /// Mensagem de texto criada no aparelho, antes de o servidor confirmar.
  /// `id` negativo = ainda não existe no servidor.
  factory DriqyMessage.local({required String clientId, required String content}) {
    return DriqyMessage(
      id: -DateTime.now().microsecondsSinceEpoch,
      content: content,
      senderId: 0,
      recipientId: null,
      createdAt: DateTime.now().toUtc(),
      mine: true,
      clientId: clientId,
      localState: MessageLocalState.sending,
    );
  }

  /// Imagem/GIF escolhida no aparelho, antes de o servidor confirmar.
  factory DriqyMessage.localImage({
    required String clientId,
    required String path,
    String caption = '',
    int? width,
    int? height,
    bool viewOnce = false,
  }) {
    if (viewOnce) caption = ''; // visualização única não tem legenda
    return DriqyMessage(
      id: -DateTime.now().microsecondsSinceEpoch,
      content: caption.isEmpty ? '📷 Foto' : caption,
      caption: caption.isEmpty ? null : caption,
      viewOnce: viewOnce,
      viewOnceState: viewOnce ? 'unopened' : null,
      msgType: 'image',
      mediaWidth: width,
      mediaHeight: height,
      senderId: 0,
      recipientId: null,
      createdAt: DateTime.now().toUtc(),
      mine: true,
      clientId: clientId,
      localState: MessageLocalState.sending,
      localPath: path,
    );
  }

  /// Documento escolhido no aparelho, antes de o servidor confirmar (Fase 15).
  factory DriqyMessage.localFile({
    required String clientId,
    required String path,
    required String name,
    int? size,
    String caption = '',
  }) {
    return DriqyMessage(
      id: -DateTime.now().microsecondsSinceEpoch,
      content: caption.isEmpty ? '📎 Arquivo' : caption,
      caption: caption.isEmpty ? null : caption,
      msgType: 'file',
      mediaName: name,
      mediaSize: size,
      senderId: 0,
      recipientId: null,
      createdAt: DateTime.now().toUtc(),
      mine: true,
      clientId: clientId,
      localState: MessageLocalState.sending,
      localPath: path,
    );
  }

  /// Vídeo escolhido/gravado no aparelho, antes de o servidor confirmar.
  factory DriqyMessage.localVideo({
    required String clientId,
    required String path,
    required int durationMs,
    String caption = '',
    int? width,
    int? height,
    String? thumbPath,
    bool viewOnce = false,
  }) {
    if (viewOnce) caption = '';
    return DriqyMessage(
      viewOnce: viewOnce,
      viewOnceState: viewOnce ? 'unopened' : null,
      id: -DateTime.now().microsecondsSinceEpoch,
      content: caption.isEmpty ? '🎥 Vídeo' : caption,
      caption: caption.isEmpty ? null : caption,
      msgType: 'video',
      mediaDurationMs: durationMs,
      mediaWidth: width,
      mediaHeight: height,
      senderId: 0,
      recipientId: null,
      createdAt: DateTime.now().toUtc(),
      mine: true,
      clientId: clientId,
      localState: MessageLocalState.sending,
      localPath: path,
      localThumbPath: thumbPath,
    );
  }

  /// Mensagem de voz gravada no aparelho, antes de o servidor confirmar.
  factory DriqyMessage.localAudio({
    required String clientId,
    required String path,
    required int durationMs,
    bool viewOnce = false,
  }) {
    return DriqyMessage(
      viewOnce: viewOnce,
      viewOnceState: viewOnce ? 'unopened' : null,
      id: -DateTime.now().microsecondsSinceEpoch,
      content: '🎤 Áudio',
      msgType: 'audio',
      mediaDurationMs: durationMs,
      senderId: 0,
      recipientId: null,
      createdAt: DateTime.now().toUtc(),
      mine: true,
      clientId: clientId,
      localState: MessageLocalState.sending,
      localPath: path,
    );
  }

  /// Id único por mensagem enviada. O servidor usa pra não duplicar se o
  /// app reenviar (rede ruim). Limite do backend: 40 caracteres.
  static String newClientId() {
    final t = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
    final r = Random().nextInt(1 << 31).toRadixString(36);
    return '$t-$r';
  }

  DriqyMessage copyWith({
    MessageLocalState? localState,
    bool clearLocalState = false,
    List<DriqyReaction>? reactions,
    DriqyReplyRef? replyTo,
  }) {
    return DriqyMessage(
      id: id,
      content: content,
      caption: caption,
      msgType: msgType,
      mediaUrl: mediaUrl,
      mediaMime: mediaMime,
      mediaThumbUrl: mediaThumbUrl,
      mediaSize: mediaSize,
      mediaDurationMs: mediaDurationMs,
      mediaWidth: mediaWidth,
      mediaHeight: mediaHeight,
      mediaName: mediaName,
      replyTo: replyTo ?? this.replyTo,
      clientId: clientId,
      senderId: senderId,
      recipientId: recipientId,
      createdAt: createdAt,
      deliveredAt: deliveredAt,
      readAt: readAt,
      editedAt: editedAt,
      deleted: deleted,
      canDeleteForAll: canDeleteForAll,
      canEdit: canEdit,
      forwarded: forwarded,
      viewOnce: viewOnce,
      viewOnceState: viewOnceState,
      canOpenViewOnce: canOpenViewOnce,
      isRead: isRead,
      mine: mine,
      localState: clearLocalState ? null : (localState ?? this.localState),
      reactions: reactions ?? this.reactions,
      localPath: localPath,
      localThumbPath: localThumbPath,
    );
  }

  /// Cópia só para o visualizador de visualização única: a URL veio de `POST /view-once`
  /// (a lista nunca traz). Não volta para a lista de mensagens.
  DriqyMessage withMedia({String? mediaUrl, String? mediaMime, int? mediaWidth, int? mediaHeight, int? mediaDurationMs}) {
    return DriqyMessage(
      id: id, content: content, senderId: senderId, recipientId: recipientId,
      createdAt: createdAt, mine: mine, msgType: msgType,
      mediaUrl: mediaUrl ?? this.mediaUrl, mediaMime: mediaMime ?? this.mediaMime,
      mediaWidth: mediaWidth ?? this.mediaWidth, mediaHeight: mediaHeight ?? this.mediaHeight,
      mediaDurationMs: mediaDurationMs ?? this.mediaDurationMs,
      viewOnce: viewOnce, viewOnceState: viewOnceState,
    );
  }

  /// GIF animado? Pelo MIME que o servidor deriva da assinatura do arquivo
  /// (ou, numa mensagem local, pela extensão).
  bool get isGif =>
      mediaMime == 'image/gif' || (localPath?.toLowerCase().endsWith('.gif') ?? false);

  MessageType get type {
    switch (msgType) {
      case 'image':
        return MessageType.image;
      case 'video':
        return MessageType.video;
      case 'audio':
        return MessageType.audio;
      case 'file':
        return MessageType.file;
      case 'call':
        return MessageType.call;
      default:
        return MessageType.text;
    }
  }

  bool get isMedia =>
      type == MessageType.image ||
      type == MessageType.video ||
      type == MessageType.audio ||
      type == MessageType.file;

  bool get isRemoteRead => isRead || readAt != null;

  static const _labels = {
    MessageType.image: '📷 Foto',
    MessageType.video: '🎥 Vídeo',
    MessageType.audio: '🎤 Áudio',
    MessageType.file: '📎 Arquivo',
    MessageType.call: '📞 Chamada',
  };

  /// Texto curto pra caixa de entrada, resposta e notificação.
  String get previewText {
    if (deleted) return 'Mensagem apagada';
    if (viewOnce) return '🔒 Visualização única';
    final label = _labels[type];
    if (label == null) return content;
    final c = caption;
    if (c != null && c.isNotEmpty) return '$label $c';
    final n = mediaName;
    if (type == MessageType.file && n != null && n.isNotEmpty) return '$label $n';
    return label;
  }
}
