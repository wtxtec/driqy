import 'package:flutter/foundation.dart';

import 'user.dart';

/// Resposta de `GET /api/v1/widgets/weather`.
///
/// Sucesso: `ok == true` e os números vêm preenchidos (qualquer um pode ser null se o provedor
/// de previsão não mandou). Falha: `ok == false` e [reason] é um de
/// `no_location | not_found | unavailable | disabled`.
class WeatherResult {
  final bool ok;
  final String? reason;
  final String location;
  final int? temperature;
  final int? feelsLike;
  final int? humidity;
  final int? windKmh;
  final int? tempMin;
  final int? tempMax;
  final int? rainChance;
  final String condition;

  /// sun, moon, sun-cloud, moon-cloud, cloud, fog, drizzle, rain, snow, storm.
  final String icon;
  final bool isDay;

  const WeatherResult({
    required this.ok,
    this.reason,
    this.location = '',
    this.temperature,
    this.feelsLike,
    this.humidity,
    this.windKmh,
    this.tempMin,
    this.tempMax,
    this.rainChance,
    this.condition = '',
    this.icon = 'cloud',
    this.isDay = true,
  });

  /// Falha de rede / servidor fora do ar: nunca vira erro na tela, só o estado "tentar de novo".
  const WeatherResult.unavailable() : this(ok: false, reason: 'unavailable');

  factory WeatherResult.fromJson(Map<String, dynamic> json) {
    int? n(dynamic v) => v is num ? v.round() : null;
    final ok = json['ok'] == true;
    return WeatherResult(
      ok: ok,
      reason: ok ? null : (json['reason'] as String? ?? 'unavailable'),
      location: json['location'] as String? ?? '',
      temperature: n(json['temperature']),
      feelsLike: n(json['feels_like']),
      humidity: n(json['humidity']),
      windKmh: n(json['wind_kmh']),
      tempMin: n(json['temp_min']),
      tempMax: n(json['temp_max']),
      rainChance: n(json['rain_chance']),
      condition: json['condition'] as String? ?? '',
      icon: json['icon'] as String? ?? 'cloud',
      isDay: json['is_day'] as bool? ?? true,
    );
  }
}

/// Ids dos widgets do painel, na ordem padrão (igual ao servidor).
const List<String> kRailWidgetIds = [
  'weather',
  'trending',
  'news',
  'vortex',
  'online',
  'clock',
  'calendar',
  'moon',
  'seasons',
  'quotes',
  'stats',
  'expiring',
  'phrase',
  'pomodoro',
  'calc',
  'breathe',
];

/// Personalização do painel direito (`GET/POST /api/v1/widgets/prefs`).
class RailPrefs {
  /// Esconde o painel inteiro.
  final bool railHidden;

  /// Ordem dos widgets (todos os ids, inclusive os removidos).
  final List<String> order;

  /// Widgets que o usuário tirou.
  final List<String> disabled;

  /// Mostra o cartão "Sugestões para você".
  final bool suggest;

  /// Cartão de sugestões acima do cartão de widgets.
  final bool suggestFirst;

  const RailPrefs({
    this.railHidden = false,
    this.order = kRailWidgetIds,
    this.disabled = const [],
    this.suggest = true,
    this.suggestFirst = false,
  });

  /// Widgets visíveis, na ordem escolhida.
  List<String> get visibleIds => [for (final id in order) if (!disabled.contains(id)) id];

  factory RailPrefs.fromJson(Map<String, dynamic> json) {
    List<String> ids(dynamic v) => [for (final e in (v as List<dynamic>? ?? const [])) e.toString()];
    final order = ids(json['order']);
    return RailPrefs(
      railHidden: json['rail_hidden'] == true,
      order: [...order, for (final id in kRailWidgetIds) if (!order.contains(id)) id],
      disabled: ids(json['disabled']),
      suggest: json['suggest'] != false,
      suggestFirst: json['suggest_first'] == true,
    );
  }

  Map<String, dynamic> toJson() => {
        'rail_hidden': railHidden,
        'order': order,
        'disabled': disabled,
        'suggest': suggest,
        'suggest_first': suggestFirst,
      };

  RailPrefs copyWith({bool? railHidden, List<String>? order, List<String>? disabled, bool? suggest, bool? suggestFirst}) =>
      RailPrefs(
        railHidden: railHidden ?? this.railHidden,
        order: order ?? this.order,
        disabled: disabled ?? this.disabled,
        suggest: suggest ?? this.suggest,
        suggestFirst: suggestFirst ?? this.suggestFirst,
      );

  @override
  bool operator ==(Object other) =>
      other is RailPrefs &&
      other.railHidden == railHidden &&
      other.suggest == suggest &&
      other.suggestFirst == suggestFirst &&
      listEquals(other.order, order) &&
      listEquals(other.disabled, disabled);

  @override
  int get hashCode => Object.hash(railHidden, suggest, suggestFirst, Object.hashAll(order), Object.hashAll(disabled));
}

/// Sugestão de cidade (`GET /api/v1/places/search`): "Gramado, Rio Grande do Sul, Brasil".
class PlaceSuggestion {
  final String name;
  final String admin1;
  final String country;
  final String label;
  final double latitude;
  final double longitude;

  const PlaceSuggestion({
    required this.name,
    required this.admin1,
    required this.country,
    required this.label,
    required this.latitude,
    required this.longitude,
  });

  factory PlaceSuggestion.fromJson(Map<String, dynamic> json) => PlaceSuggestion(
        name: json['name'] as String? ?? '',
        admin1: json['admin1'] as String? ?? '',
        country: json['country'] as String? ?? '',
        label: json['label'] as String? ?? (json['name'] as String? ?? ''),
        latitude: (json['latitude'] as num).toDouble(),
        longitude: (json['longitude'] as num).toDouble(),
      );

  String get subtitle => [admin1, country].where((e) => e.isNotEmpty).join(', ');
}

/// Pessoa resumida dos widgets (`author` de Em alta, usuários de Quem está online).
class RailPerson {
  final String username;
  final String displayName;
  final String? avatarUrl;

  const RailPerson({required this.username, this.displayName = '', this.avatarUrl});

  factory RailPerson.fromJson(Map<String, dynamic> json) => RailPerson(
        username: json['username'] as String? ?? '',
        displayName: json['display_name'] as String? ?? '',
        avatarUrl: json['avatar_url'] as String?,
      );
}

/// Item de `GET /widgets/trending`.
class TrendingPost {
  final int id;
  final RailPerson author;
  final String snippet;
  final int likes;
  final int comments;

  const TrendingPost({
    required this.id,
    required this.author,
    this.snippet = '',
    this.likes = 0,
    this.comments = 0,
  });

  factory TrendingPost.fromJson(Map<String, dynamic> json) => TrendingPost(
        id: json['id'] as int,
        author: RailPerson.fromJson((json['author'] as Map<String, dynamic>?) ?? const {}),
        snippet: json['snippet'] as String? ?? '',
        likes: (json['likes'] as num?)?.toInt() ?? 0,
        comments: (json['comments'] as num?)?.toInt() ?? 0,
      );
}

/// Item de `GET /widgets/news`.
class NewsHeadline {
  final int id;
  final String title;
  final String source;
  final String? imageUrl;

  const NewsHeadline({required this.id, required this.title, this.source = '', this.imageUrl});

  factory NewsHeadline.fromJson(Map<String, dynamic> json) => NewsHeadline(
        id: json['id'] as int,
        title: json['title'] as String? ?? '',
        source: json['source'] as String? ?? '',
        imageUrl: json['image_url'] as String?,
      );
}

/// Item de `GET /widgets/vortex`.
class VortexPreviewItem {
  final int id;
  final String thumbUrl;
  final String title;

  const VortexPreviewItem({required this.id, required this.thumbUrl, this.title = ''});

  factory VortexPreviewItem.fromJson(Map<String, dynamic> json) => VortexPreviewItem(
        id: json['id'] as int,
        thumbUrl: json['thumb_url'] as String? ?? '',
        title: json['title'] as String? ?? '',
      );
}

/// Resposta de `GET /widgets/online`. [hidden]: o usuário escondeu o próprio "online" e por
/// isso também não vê os outros.
class OnlineResult {
  final bool hidden;
  final int count;
  final List<RailPerson> users;

  const OnlineResult({this.hidden = false, this.count = 0, this.users = const []});

  factory OnlineResult.fromJson(Map<String, dynamic> json) => OnlineResult(
        hidden: json['hidden'] == true,
        count: (json['count'] as num?)?.toInt() ?? 0,
        users: [
          for (final u in (json['users'] as List<dynamic>? ?? const []))
            RailPerson.fromJson(u as Map<String, dynamic>),
        ],
      );
}

/// Item de `GET /widgets/suggestions`: o usuário completo (como em `/users/<u>`) + o motivo.
class SuggestedUser {
  final DriqyUser user;
  final String reason;

  const SuggestedUser({required this.user, this.reason = ''});

  factory SuggestedUser.fromJson(Map<String, dynamic> json) =>
      SuggestedUser(user: DriqyUser.fromJson(json), reason: json['reason'] as String? ?? '');
}

// ---------------------------------------------------------------------------------------------
// "Minha área": widgets criados pelo próprio usuário (`/api/v1/widgets/custom`).

/// Tipos de widget próprio que o servidor oferece (`kinds` de `GET /widgets/custom`).
class CustomKind {
  final String kind;
  final String title;
  final String desc;

  const CustomKind({required this.kind, required this.title, this.desc = ''});

  factory CustomKind.fromJson(Map<String, dynamic> json) => CustomKind(
        kind: json['kind'] as String? ?? '',
        title: json['title'] as String? ?? '',
        desc: json['desc'] as String? ?? '',
      );
}

/// Os mesmos 5 tipos do servidor, para o caso de a lista não chegar (o servidor sempre revalida).
const List<CustomKind> kDefaultCustomKinds = [
  CustomKind(kind: 'note', title: 'Nota', desc: 'Um bloco de texto livre'),
  CustomKind(kind: 'checklist', title: 'Tarefas', desc: 'Lista com itens para marcar'),
  CustomKind(kind: 'links', title: 'Atalhos', desc: 'Seus links favoritos'),
  CustomKind(kind: 'countdown', title: 'Contagem', desc: 'Quantos dias faltam para uma data'),
  CustomKind(kind: 'counter', title: 'Contador', desc: 'Some e subtraia, com meta opcional'),
];

/// Um widget próprio. [id] é o id público do seletor (`custom:7`); [widgetId] é o número (7) das rotas.
/// [data] já vem normalizado pelo servidor e tem o formato do [kind]:
/// note `{text}` · checklist `{items:[{id,text,done}]}` · links `{links:[{title,url}]}` ·
/// countdown `{label,date}` · counter `{value,step,goal,unit}`.
class CustomWidget {
  final String id;
  final int widgetId;
  final String kind;
  final String title;
  final Map<String, dynamic> data;

  const CustomWidget({
    required this.id,
    required this.widgetId,
    required this.kind,
    required this.title,
    this.data = const {},
  });

  factory CustomWidget.fromJson(Map<String, dynamic> json) {
    final n = json['widget_id'];
    final wid = n is num ? n.toInt() : int.tryParse('${json['id']}'.replaceFirst('custom:', '')) ?? 0;
    return CustomWidget(
      id: json['id'] as String? ?? 'custom:$wid',
      widgetId: wid,
      kind: json['kind'] as String? ?? 'note',
      title: json['title'] as String? ?? '',
      data: Map<String, dynamic>.from((json['data'] as Map?) ?? const {}),
    );
  }

  CustomWidget copyWith({String? title, Map<String, dynamic>? data}) =>
      CustomWidget(id: id, widgetId: widgetId, kind: kind, title: title ?? this.title, data: data ?? this.data);
}

/// Resposta de `GET /widgets/custom`: os widgets do usuário, os tipos e o limite.
class CustomCatalog {
  final List<CustomWidget> widgets;
  final List<CustomKind> kinds;
  final int max;

  const CustomCatalog({this.widgets = const [], this.kinds = kDefaultCustomKinds, this.max = 12});

  factory CustomCatalog.fromJson(Map<String, dynamic> json) {
    final kinds = [
      for (final e in (json['kinds'] as List<dynamic>? ?? const [])) CustomKind.fromJson(e as Map<String, dynamic>),
    ];
    final max = json['max'];
    return CustomCatalog(
      widgets: [
        for (final e in (json['widgets'] as List<dynamic>? ?? const [])) CustomWidget.fromJson(e as Map<String, dynamic>),
      ],
      kinds: kinds.isEmpty ? kDefaultCustomKinds : kinds,
      max: max is num && max > 0 ? max.toInt() : 12,
    );
  }
}
