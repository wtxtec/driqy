import 'user.dart';

/// Notificação (like, comentário, follow). Chamada de "AppNotification"
/// pra não colidir com a classe Notification do Flutter/dart:html.
class AppNotification {
  static const kindLike = 'like';
  static const kindComment = 'comment';
  static const kindFollow = 'follow';
  static const kindReply = 'reply';

  /// Aviso do sistema (virada de estação). Sem autor de verdade: `actor` é o próprio usuário e o texto
  /// inteiro vem em [verb], começando pelo emoji da estação.
  static const kindSeason = 'season';

  final int id;
  final String kind;
  final String verb;
  final DriqyUser actor;
  final int? postId;
  final int? commentId;
  final String? snippet;
  final bool isRead;
  final DateTime createdAt;

  AppNotification({
    required this.id,
    required this.kind,
    required this.verb,
    required this.actor,
    required this.postId,
    required this.commentId,
    required this.snippet,
    required this.isRead,
    required this.createdAt,
  });

  bool get isSeason => kind == kindSeason;

  /// Emoji que abre o texto de um aviso de estação (🌸 ☀️ 🍂 ❄️); 🍃 se não houver.
  String get seasonEmoji {
    final first = verb.split(' ').first;
    return first.isEmpty || first.runes.first < 128 ? '🍃' : first;
  }

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: json['id'] as int,
      kind: json['kind'] as String,
      verb: json['verb'] as String? ?? '',
      actor: DriqyUser.fromJson(json['actor'] as Map<String, dynamic>),
      postId: json['post_id'] as int?,
      commentId: json['comment_id'] as int?,
      snippet: json['snippet'] as String?,
      isRead: json['is_read'] as bool? ?? false,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }
}
