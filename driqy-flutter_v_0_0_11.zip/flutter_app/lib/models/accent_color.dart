import 'dart:ui';

/// Opção de cor de destaque de perfil (espelha config.py ACCENT_COLORS).
class AccentColorOption {
  final String key;
  final Color color;

  AccentColorOption({required this.key, required this.color});

  factory AccentColorOption.fromJson(Map<String, dynamic> json) {
    return AccentColorOption(
      key: json['key'] as String,
      color: _parseHex(json['hex'] as String),
    );
  }

  static Color _parseHex(String hex) {
    final cleaned = hex.replaceFirst('#', '');
    return Color(int.parse('FF$cleaned', radix: 16));
  }
}
