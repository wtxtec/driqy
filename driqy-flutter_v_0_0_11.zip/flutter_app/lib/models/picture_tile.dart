import 'user.dart';

/// Perfil-robô do Vortex (quem "publicou" um item vindo do crawler).
class VortexProfile {
  final String handle;
  final String displayName;
  final String? avatarUrl;
  final String? sourceSite;

  VortexProfile({
    required this.handle,
    required this.displayName,
    this.avatarUrl,
    this.sourceSite,
  });

  factory VortexProfile.fromJson(Map<String, dynamic> json) => VortexProfile(
        handle: json['handle'] as String? ?? '',
        displayName: json['display_name'] as String? ?? (json['handle'] as String? ?? ''),
        avatarUrl: json['avatar_url'] as String?,
        sourceSite: json['source_site'] as String?,
      );
}

/// Uma peça da grade do Vortex. Pode ser:
/// - `source == 'user'`: a primeira foto/gif/vídeo de um post ainda ativo
///   (tem [postId] e [author]);
/// - `source == 'crawler'`: item indexado da internet (tem [itemId] e
///   [profile]; não tem post nem autor).
class PictureTile {
  final String key;
  final String source; // user | crawler
  final int? postId;
  final int? itemId;
  final String mediaUrl;
  /// Foto: versão ~600 px; vídeo: capa; usuário: null.
  final String? thumbUrl;
  final String mediaType; // photo | gif | video
  final int? width;
  final int? height;
  final int? durationSeconds;
  final String title;
  final String? category;
  final DriqyUser? author;
  final VortexProfile? profile;
  final DateTime createdAt;
  /// null = sem anel de contagem (post permanente ou item do crawler).
  final DateTime? expiresAt;
  final int? secondsRemaining;

  PictureTile({
    required this.key,
    this.source = 'user',
    this.postId,
    this.itemId,
    required this.mediaUrl,
    this.thumbUrl,
    required this.mediaType,
    this.width,
    this.height,
    this.durationSeconds,
    this.title = '',
    this.category,
    this.author,
    this.profile,
    required this.createdAt,
    required this.expiresAt,
    required this.secondsRemaining,
  });

  bool get isCrawler => source == 'crawler';

  /// Proporção conhecida pelo servidor (largura/altura), se houver.
  double? get knownAspectRatio {
    final w = width, h = height;
    if (w == null || h == null || w <= 0 || h <= 0) return null;
    return w / h;
  }

  /// O que mostrar na grade: miniatura quando existe (fotos do crawler e capa
  /// de vídeo), senão a própria mídia (GIF animado, posts de usuários).
  String get gridUrl {
    if (mediaType == 'gif') return mediaUrl;
    return thumbUrl ?? mediaUrl;
  }

  factory PictureTile.fromJson(Map<String, dynamic> json) {
    final expiresRaw = json['expires_at'] as String?;
    final expiresAt = expiresRaw != null ? DateTime.parse(expiresRaw) : null;
    final secondsRemaining = json['seconds_remaining'] as int?;
    final createdAtRaw = json['created_at'] as String?;
    final authorJson = json['author'];
    final profileJson = json['profile'];
    final source = json['source'] as String? ?? (profileJson != null ? 'crawler' : 'user');
    return PictureTile(
      key: json['key'] as String,
      source: source,
      postId: json['post_id'] as int?,
      itemId: json['item_id'] as int?,
      mediaUrl: json['media_url'] as String,
      thumbUrl: json['thumb_url'] as String?,
      mediaType: json['media_type'] as String,
      width: json['width'] as int?,
      height: json['height'] as int?,
      durationSeconds: json['duration_seconds'] as int?,
      title: json['title'] as String? ?? '',
      category: json['category'] as String?,
      author: authorJson is Map<String, dynamic> ? DriqyUser.fromJson(authorJson) : null,
      profile: profileJson is Map<String, dynamic> ? VortexProfile.fromJson(profileJson) : null,
      createdAt: createdAtRaw != null
          ? DateTime.parse(createdAtRaw)
          : (expiresAt != null
              ? expiresAt.subtract(Duration(seconds: secondsRemaining ?? 0))
              : DateTime.now()),
      expiresAt: expiresAt,
      secondsRemaining: secondsRemaining,
    );
  }
}

/// Detalhe de um item do crawler (`GET /vortex/item/<id>`).
class VortexItemDetail {
  final PictureTile tile;
  final String description;
  final List<String> tags;
  final List<String> visualTags;
  final String? sourceUrl;
  final String? sourceName;
  final String? license;
  final String? attribution;

  VortexItemDetail({
    required this.tile,
    this.description = '',
    this.tags = const [],
    this.visualTags = const [],
    this.sourceUrl,
    this.sourceName,
    this.license,
    this.attribution,
  });

  factory VortexItemDetail.fromJson(Map<String, dynamic> json) {
    List<String> strings(dynamic v) =>
        (v as List<dynamic>? ?? const []).map((e) => e.toString()).toList();
    return VortexItemDetail(
      tile: PictureTile.fromJson(json),
      description: json['description'] as String? ?? '',
      tags: strings(json['tags']),
      visualTags: strings(json['visual_tags']),
      sourceUrl: json['source_url'] as String?,
      sourceName: json['source_name'] as String?,
      license: json['license'] as String?,
      attribution: json['attribution'] as String?,
    );
  }
}

class VortexStats {
  final int total;
  final int photos;
  final int gifs;
  final int videos;

  VortexStats({required this.total, required this.photos, required this.gifs, required this.videos});

  factory VortexStats.fromJson(Map<String, dynamic> json) => VortexStats(
        total: json['total'] as int? ?? 0,
        photos: json['photos'] as int? ?? 0,
        gifs: json['gifs'] as int? ?? 0,
        videos: json['videos'] as int? ?? 0,
      );
}

class VortexCategory {
  final String slug;
  final String label;
  final int count;

  VortexCategory({required this.slug, required this.label, required this.count});

  factory VortexCategory.fromJson(Map<String, dynamic> json) => VortexCategory(
        slug: json['slug'] as String,
        label: json['label'] as String? ?? json['slug'] as String,
        count: json['count'] as int? ?? 0,
      );
}
