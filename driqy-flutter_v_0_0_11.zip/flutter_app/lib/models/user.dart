class DriqyUser {
  final int id;
  final String username;
  final String displayName;
  final String bio;
  final String location;

  /// Coordenadas da cidade escolhida nas sugestões (só vêm para o próprio usuário).
  final double? locationLat;
  final double? locationLng;
  final String accentColor;
  final String? avatarUrl;
  final String? coverUrl;
  final String? badgeKind; // "admin" | "mod" | "verified" | null
  final int followersCount;
  final int followingCount;
  final bool isFollowing;
  final bool isMe;
  final DateTime? createdAt;
  final int? activePostsCount;
  final bool isStaff;

  /// Flash (stories de 24h): tem Flash ativo / ainda tem algum que EU não vi.
  final bool hasFlash;
  final bool flashUnseen;

  DriqyUser({
    required this.id,
    required this.username,
    required this.displayName,
    required this.bio,
    required this.location,
    this.locationLat,
    this.locationLng,
    required this.accentColor,
    required this.avatarUrl,
    required this.coverUrl,
    required this.badgeKind,
    required this.followersCount,
    required this.followingCount,
    required this.isFollowing,
    required this.isMe,
    this.createdAt,
    this.activePostsCount,
    this.isStaff = false,
    this.hasFlash = false,
    this.flashUnseen = false,
  });

  factory DriqyUser.fromJson(Map<String, dynamic> json) {
    return DriqyUser(
      id: json['id'] as int,
      username: json['username'] as String,
      displayName: json['display_name'] as String? ?? json['username'] as String,
      bio: json['bio'] as String? ?? '',
      location: json['location'] as String? ?? '',
      locationLat: (json['location_lat'] as num?)?.toDouble(),
      locationLng: (json['location_lng'] as num?)?.toDouble(),
      accentColor: json['accent_color'] as String? ?? 'amber',
      avatarUrl: json['avatar_url'] as String?,
      coverUrl: json['cover_url'] as String?,
      badgeKind: json['badge_kind'] as String?,
      followersCount: json['followers_count'] as int? ?? 0,
      followingCount: json['following_count'] as int? ?? 0,
      isFollowing: json['is_following'] as bool? ?? false,
      isMe: json['is_me'] as bool? ?? false,
      // Campos novos: podem não vir de um backend mais antigo, então
      // sempre com fallback nulo/false pra não quebrar a compatibilidade.
      createdAt: json['created_at'] != null ? DateTime.tryParse(json['created_at'] as String) : null,
      activePostsCount: json['active_posts_count'] as int?,
      isStaff: json['is_staff'] as bool? ?? false,
      hasFlash: json['has_flash'] as bool? ?? false,
      flashUnseen: json['flash_unseen'] as bool? ?? false,
    );
  }
}
