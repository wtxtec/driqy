import 'presence.dart';

DateTime? _dt(dynamic v) => v is String ? DateTime.tryParse(v) : null;

/// Pessoa dentro de um grupo (membro ou remetente).
class DriqyGroupUser {
  final int id;
  final String username;
  final String displayName;
  final String? avatarUrl;
  final String role; // owner | admin | member (só nos membros)

  const DriqyGroupUser({
    required this.id,
    required this.username,
    required this.displayName,
    this.avatarUrl,
    this.role = 'member',
  });

  factory DriqyGroupUser.fromJson(Map<String, dynamic> j) => DriqyGroupUser(
        id: j['id'] as int,
        username: j['username'] as String? ?? '',
        displayName: j['display_name'] as String? ?? j['username'] as String? ?? '',
        avatarUrl: j['avatar_url'] as String?,
        role: j['role'] as String? ?? 'member',
      );
}

class DriqyGroupReply {
  final int id;
  final String senderName;
  final String preview;
  final bool deleted;

  const DriqyGroupReply({required this.id, required this.senderName, required this.preview, this.deleted = false});

  static DriqyGroupReply? fromJson(Map<String, dynamic>? j) => j == null
      ? null
      : DriqyGroupReply(
          id: j['id'] as int,
          senderName: j['sender_name'] as String? ?? '',
          preview: j['preview'] as String? ?? '',
          deleted: j['deleted'] as bool? ?? false,
        );
}

/// Mensagem de grupo (só texto). `kind` = text | system.
class DriqyGroupMessage {
  final int id; // negativo = ainda não enviada (otimista)
  final String kind;
  final DriqyGroupUser? sender;
  final String content;
  final DriqyGroupReply? replyTo;
  final String? clientId;
  final DateTime createdAt;
  final bool edited;
  final bool deleted;
  final bool mine;
  final String? state; // sending | failed (só local)

  const DriqyGroupMessage({
    required this.id,
    required this.kind,
    required this.sender,
    required this.content,
    required this.createdAt,
    this.replyTo,
    this.clientId,
    this.edited = false,
    this.deleted = false,
    this.mine = false,
    this.state,
  });

  bool get isSystem => kind == 'system';

  factory DriqyGroupMessage.fromJson(Map<String, dynamic> j) => DriqyGroupMessage(
        id: j['id'] as int,
        kind: j['kind'] as String? ?? 'text',
        sender: j['sender'] != null ? DriqyGroupUser.fromJson(j['sender'] as Map<String, dynamic>) : null,
        content: j['content'] as String? ?? '',
        replyTo: DriqyGroupReply.fromJson(j['reply_to'] as Map<String, dynamic>?),
        clientId: j['client_id'] as String?,
        createdAt: _dt(j['created_at']) ?? DateTime.now().toUtc(),
        edited: j['edited'] as bool? ?? false,
        deleted: j['deleted'] as bool? ?? false,
        mine: j['mine'] as bool? ?? false,
      );

  DriqyGroupMessage withState(String? s) => DriqyGroupMessage(
        id: id, kind: kind, sender: sender, content: content, createdAt: createdAt, replyTo: replyTo,
        clientId: clientId, edited: edited, deleted: deleted, mine: mine, state: s,
      );
}

class DriqyGroup {
  final int id;
  final String name;
  final String description;
  final String? avatarUrl;
  final int memberCount;
  final String myRole; // owner | admin | member
  final DriqyChatPrefs prefs;
  final int unread;
  final String lastPreview;
  final DateTime? lastActivity;
  final List<DriqyGroupUser> members; // só no detalhe

  const DriqyGroup({
    required this.id,
    required this.name,
    this.description = '',
    this.avatarUrl,
    this.memberCount = 0,
    this.myRole = 'member',
    this.prefs = const DriqyChatPrefs(),
    this.unread = 0,
    this.lastPreview = '',
    this.lastActivity,
    this.members = const [],
  });

  bool get isAdmin => myRole == 'owner' || myRole == 'admin';
  bool get isOwner => myRole == 'owner';

  factory DriqyGroup.fromJson(Map<String, dynamic> j) => DriqyGroup(
        id: j['id'] as int,
        name: j['name'] as String? ?? '',
        description: j['description'] as String? ?? '',
        avatarUrl: j['avatar_url'] as String?,
        memberCount: j['member_count'] as int? ?? 0,
        myRole: j['my_role'] as String? ?? 'member',
        prefs: DriqyChatPrefs.fromJson(j['prefs'] as Map<String, dynamic>?),
        unread: j['unread'] as int? ?? 0,
        lastPreview: j['last_preview'] as String? ?? '',
        lastActivity: _dt(j['last_activity']),
        members: ((j['members'] as List<dynamic>?) ?? const [])
            .map((m) => DriqyGroupUser.fromJson(m as Map<String, dynamic>))
            .toList(),
      );
}
