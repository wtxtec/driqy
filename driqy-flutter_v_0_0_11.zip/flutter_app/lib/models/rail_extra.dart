import 'rail_widgets.dart';

/// Modelos dos 7 widgets do painel que vêm do servidor (`/api/v1/widgets/clock|calendar|moon|quotes|
/// stats|expiring|phrase`). Os outros 3 (foco, calculadora, respirar) rodam só no aparelho.

int _int(dynamic v, [int d = 0]) => v is num ? v.toInt() : (int.tryParse('${v ?? ''}') ?? d);
double? _dbl(dynamic v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}');

/// Cidade do relógio mundial. [local] é a hora da cidade NA HORA DA RESPOSTA (tratada como UTC só
/// para guardar os campos); o app soma o tempo que passou desde a resposta.
class ClockCity {
  final String id;
  final String name;
  final String utcLabel;
  final int dayOffset; // em relação a Brasília: -1 ontem, 0 hoje, 1 amanhã
  final DateTime local;

  const ClockCity({required this.id, required this.name, this.utcLabel = '', this.dayOffset = 0, required this.local});

  /// "2026-11-05T14:03:09" (com ou sem fuso no fim) -> DateTime UTC com esses mesmos campos. null se inválido.
  static DateTime? parseLocal(String s) {
    final m = RegExp(r'(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)').firstMatch(s);
    if (m == null) return null;
    int g(int i) => int.parse(m.group(i)!);
    return DateTime.utc(g(1), g(2), g(3), g(4), g(5), g(6));
  }

  static ClockCity? fromJson(Map<String, dynamic> json) {
    final local = parseLocal('${json['local'] ?? ''}');
    if (local == null) return null;
    return ClockCity(
      id: '${json['id'] ?? ''}',
      name: '${json['name'] ?? ''}',
      utcLabel: '${json['utc_label'] ?? ''}',
      dayOffset: _int(json['day_offset']),
      local: local,
    );
  }
}

class ClockZone {
  final String id;
  final String name;

  const ClockZone({required this.id, required this.name});
}

/// `GET /widgets/clock`.
class ClockResult {
  final bool ok;
  final List<ClockCity> cities;
  final List<ClockZone> available;

  const ClockResult({this.ok = false, this.cities = const [], this.available = const []});

  factory ClockResult.fromJson(Map<String, dynamic> json) {
    final cities = <ClockCity>[
      for (final e in (json['cities'] as List<dynamic>? ?? const []))
        if (ClockCity.fromJson(e as Map<String, dynamic>) != null) ClockCity.fromJson(e)!,
    ];
    return ClockResult(
      ok: json['ok'] == true && cities.isNotEmpty,
      cities: cities,
      available: [
        for (final e in (json['available'] as List<dynamic>? ?? const []))
          ClockZone(id: '${(e as Map)['id'] ?? ''}', name: '${e['name'] ?? ''}'),
      ],
    );
  }
}

class CalHoliday {
  final int day;
  final String name;
  final String kind; // feriado | facultativo | data

  const CalHoliday({required this.day, required this.name, this.kind = 'feriado'});
}

/// País da lista de feriados do calendário (`countries` de `GET /widgets/calendar`).
class CalCountry {
  final String code;
  final String name;

  const CalCountry({required this.code, required this.name});
}

/// `GET /widgets/calendar`.
class CalendarMonth {
  final int year;
  final int month;
  final String monthName;
  final int daysInMonth;
  final int firstWeekday; // 0 = domingo
  final String today; // AAAA-MM-DD (Brasília)
  final List<CalHoliday> holidays;

  // --- região (calendário global, parte 3); servidor antigo: vazio e o app cai no padrão pt/domingo
  final List<String> weekdays; // 7 iniciais, já na ordem da grade
  final int? firstOffset; // casas em branco antes do dia 1 nessa ordem
  final String country; // código do país dos feriados (BR, US...)
  final String countryName;
  final bool countryChosen; // true = escolha do usuário; false = automático
  final List<CalCountry> countries;

  const CalendarMonth({
    required this.year,
    required this.month,
    this.monthName = '',
    required this.daysInMonth,
    this.firstWeekday = 0,
    this.today = '',
    this.holidays = const [],
    this.weekdays = const [],
    this.firstOffset,
    this.country = '',
    this.countryName = '',
    this.countryChosen = false,
    this.countries = const [],
  });

  factory CalendarMonth.fromJson(Map<String, dynamic> json) => CalendarMonth(
        year: _int(json['year']),
        month: _int(json['month'], 1),
        monthName: '${json['month_name'] ?? ''}',
        daysInMonth: _int(json['days_in_month'], 30),
        firstWeekday: _int(json['first_weekday']) % 7,
        today: '${json['today'] ?? ''}',
        holidays: [
          for (final e in (json['holidays'] as List<dynamic>? ?? const []))
            CalHoliday(
              day: _int((e as Map)['day']),
              name: '${e['name'] ?? ''}',
              kind: '${e['kind'] ?? 'feriado'}',
            ),
        ],
        weekdays: [
          for (final w in (json['weekdays'] as List<dynamic>? ?? const [])) '$w',
        ],
        firstOffset: json['first_offset'] == null ? null : _int(json['first_offset']) % 7,
        country: '${json['country'] ?? ''}',
        countryName: '${json['country_name'] ?? ''}',
        countryChosen: json['country_chosen'] == true,
        countries: [
          for (final c in (json['countries'] as List<dynamic>? ?? const []))
            CalCountry(code: '${(c as Map)['code'] ?? ''}', name: '${c['name'] ?? ''}'),
        ],
      );

  /// Iniciais dos dias na ordem da grade (7); sem dado do servidor, domingo primeiro em português.
  List<String> get gridWeekdays =>
      weekdays.length == 7 ? weekdays : const ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

  /// Casas em branco antes do dia 1.
  int get blanks => firstOffset ?? firstWeekday;

  /// O mês mostrado é o mês de "hoje"?
  bool get isCurrent {
    final p = today.split('-');
    return p.length == 3 && int.tryParse(p[0]) == year && int.tryParse(p[1]) == month;
  }

  /// Dia de hoje dentro deste mês (0 se o mês mostrado não é o atual).
  int get todayDay => isCurrent ? (int.tryParse(today.split('-')[2]) ?? 0) : 0;
}

/// Um marco do ciclo da Lua (nova, quarto crescente, cheia, quarto minguante).
class MoonEvent {
  final String name;
  final String emoji;
  final String date; // AAAA-MM-DD
  final int days;

  const MoonEvent({required this.name, this.emoji = '🌙', this.date = '', this.days = 0});

  factory MoonEvent.fromJson(Map<String, dynamic> json) => MoonEvent(
        name: '${json['name'] ?? ''}',
        emoji: '${json['emoji'] ?? '🌙'}',
        date: '${json['date'] ?? ''}',
        days: _int(json['days']),
      );
}

/// Nascer/pôr da Lua de hoje (horário de Brasília). [rise]/[set] vazios = não acontece hoje.
class MoonRiseSet {
  final String place;
  final bool approximate; // true = sem local no perfil (usou Brasília)
  final String rise; // "HH:MM" | ""
  final String set;
  final bool upNow;
  final String nextLabel; // "Nasce" | "Se põe" | ""
  final String nextTime;
  final bool nextToday;

  const MoonRiseSet({
    this.place = '',
    this.approximate = false,
    this.rise = '',
    this.set = '',
    this.upNow = false,
    this.nextLabel = '',
    this.nextTime = '',
    this.nextToday = true,
  });

  factory MoonRiseSet.fromJson(Map<String, dynamic> json) {
    final next = json['next'];
    return MoonRiseSet(
      place: '${json['place'] ?? ''}',
      approximate: json['approximate'] as bool? ?? false,
      rise: '${json['rise'] ?? ''}',
      set: '${json['set'] ?? ''}',
      upNow: json['up_now'] as bool? ?? false,
      nextLabel: next is Map ? '${next['label'] ?? ''}' : '',
      nextTime: next is Map ? '${next['time'] ?? ''}' : '',
      nextToday: next is Map ? (next['today'] as bool? ?? true) : true,
    );
  }
}

/// Texto do fuso ao lado dos horários: "horário de Brasília" ou "seu horário (GMT-5)".
String tzWords(String label) => label.isEmpty || label == 'Brasília' ? 'horário de Brasília' : 'seu horário ($label)';

/// Um eclipse futuro. [visibleHere]: só eclipse lunar (Lua acima do horizonte no máximo); null = não se sabe.
class EclipseInfo {
  final String kind; // solar | lunar
  final String type; // total | parcial | anular | híbrido | penumbral
  final String name;
  final String emoji;
  final String date; // AAAA-MM-DD (no fuso pedido; padrão Brasília)
  final String time; // HH:MM (máximo do eclipse, no fuso pedido)
  final int days;
  final bool? visibleHere;

  const EclipseInfo({
    required this.name,
    this.kind = 'lunar',
    this.type = '',
    this.emoji = '🌕',
    this.date = '',
    this.time = '',
    this.days = 0,
    this.visibleHere,
  });

  factory EclipseInfo.fromJson(Map<String, dynamic> json) => EclipseInfo(
        name: '${json['name'] ?? ''}',
        kind: '${json['kind'] ?? 'lunar'}',
        type: '${json['type'] ?? ''}',
        emoji: '${json['emoji'] ?? '🌕'}',
        date: '${json['date'] ?? ''}',
        time: '${json['time'] ?? ''}',
        days: _int(json['days']),
        visibleHere: json['visible_here'] as bool?,
      );
}

/// `GET /widgets/moon`. Os campos depois de [daysToNew] são mais recentes: servidor antigo não manda,
/// e o widget cai no desenho simples (só cheia e nova).
class MoonInfo {
  final String phase;
  final String emoji;
  final int illumination;
  final double ageDays;
  final String nextFull; // AAAA-MM-DD
  final String nextNew;
  final int daysToFull;
  final int daysToNew;

  /// Crescendo (true) ou minguando.
  final bool waxing;
  final String trend; // "Crescendo" | "Minguando" | "" (servidor antigo)
  /// Quanto da lunação (nova -> nova) já passou, 0..100; null = servidor antigo.
  final double? cyclePct;
  final double cycleDays;
  final int distanceKm;
  final String distanceLabel;

  /// Próximos marcos, do mais perto ao mais longe.
  final List<MoonEvent> events;

  /// Nascer/pôr da Lua e próximos eclipses; null/vazio = servidor antigo.
  final MoonRiseSet? riseSet;
  final List<EclipseInfo> eclipses;

  /// Fuso dos horários: "Brasília" (padrão) ou "GMT-5"; vazio = servidor antigo (Brasília).
  final String tzLabel;

  const MoonInfo({
    required this.phase,
    this.emoji = '🌙',
    this.illumination = 0,
    this.ageDays = 0,
    this.nextFull = '',
    this.nextNew = '',
    this.daysToFull = 0,
    this.daysToNew = 0,
    this.waxing = true,
    this.trend = '',
    this.cyclePct,
    this.cycleDays = 29.5,
    this.distanceKm = 0,
    this.distanceLabel = '',
    this.events = const [],
    this.riseSet,
    this.eclipses = const [],
    this.tzLabel = '',
  });

  factory MoonInfo.fromJson(Map<String, dynamic> json) => MoonInfo(
        phase: '${json['phase'] ?? ''}',
        emoji: '${json['emoji'] ?? '🌙'}',
        illumination: _int(json['illumination']),
        ageDays: _dbl(json['age_days']) ?? 0,
        nextFull: '${json['next_full'] ?? ''}',
        nextNew: '${json['next_new'] ?? ''}',
        daysToFull: _int(json['days_to_full']),
        daysToNew: _int(json['days_to_new']),
        waxing: json['waxing'] as bool? ?? true,
        trend: '${json['trend'] ?? ''}',
        cyclePct: _dbl(json['cycle_pct']),
        cycleDays: _dbl(json['cycle_days']) ?? 29.5,
        distanceKm: _int(json['distance_km']),
        distanceLabel: '${json['distance_label'] ?? ''}',
        events: [
          for (final e in (json['events'] as List? ?? const []))
            if (e is Map<String, dynamic>) MoonEvent.fromJson(e),
        ],
        tzLabel: '${json['tz_label'] ?? ''}',
        riseSet: json['rise_set'] is Map<String, dynamic> ? MoonRiseSet.fromJson(json['rise_set'] as Map<String, dynamic>) : null,
        eclipses: [
          for (final e in (json['eclipses'] as List? ?? const []))
            if (e is Map<String, dynamic>) EclipseInfo.fromJson(e),
        ],
      );
}

/// Uma estação do ano em `GET /widgets/seasons`. [progress] é 0..100; [status]: past | current | future.
class SeasonPart {
  final String key;
  final String name;
  final String emoji;
  final String start; // AAAA-MM-DD (Brasília)
  final String end;
  final String startLabel; // "22/09 21:05"
  final String endLabel;
  final String event; // "Equinócio de setembro"
  final int days;
  final double progress;
  final String status;

  /// Só na estação atual: em que dia dela estamos e quantos faltam para a virada.
  final int dayNumber;
  final int daysLeft;

  const SeasonPart({
    required this.name,
    this.key = '',
    this.emoji = '🍃',
    this.start = '',
    this.end = '',
    this.startLabel = '',
    this.endLabel = '',
    this.event = '',
    this.days = 0,
    this.progress = 0,
    this.status = 'future',
    this.dayNumber = 0,
    this.daysLeft = 0,
  });

  factory SeasonPart.fromJson(Map<String, dynamic> json) => SeasonPart(
        key: '${json['key'] ?? ''}',
        name: '${json['name'] ?? ''}',
        emoji: '${json['emoji'] ?? '🍃'}',
        start: '${json['start'] ?? ''}',
        end: '${json['end'] ?? ''}',
        startLabel: '${json['start_label'] ?? ''}',
        endLabel: '${json['end_label'] ?? ''}',
        event: '${json['event'] ?? ''}',
        days: _int(json['days']),
        progress: (_dbl(json['progress']) ?? 0).clamp(0, 100).toDouble(),
        status: '${json['status'] ?? 'future'}',
        dayNumber: _int(json['day_number']),
        daysLeft: _int(json['days_left']),
      );

  /// Hora da virada, "21:05" (os 5 últimos caracteres de [startLabel]).
  String get startTime => startLabel.length >= 5 ? startLabel.substring(startLabel.length - 5) : '';
}

/// `GET /widgets/seasons`: estação atual, a próxima e as 4 do ciclo (Dez -> Dez).
class SeasonInfo {
  final String hemisphere; // sul | norte
  final SeasonPart current;
  final SeasonPart next;
  final int daysToNext;
  final List<SeasonPart> cycle;
  final double yearProgress;

  /// "Verão começa em 3 dias (21/12)" quando a virada está a 3 dias ou menos; senão null.
  final String? alert;

  /// Fuso dos horários (ver [MoonInfo.tzLabel]).
  final String tzLabel;

  const SeasonInfo({
    required this.current,
    required this.next,
    this.hemisphere = 'sul',
    this.daysToNext = 0,
    this.cycle = const [],
    this.yearProgress = 0,
    this.alert,
    this.tzLabel = '',
  });

  factory SeasonInfo.fromJson(Map<String, dynamic> json) => SeasonInfo(
        hemisphere: '${json['hemisphere'] ?? 'sul'}',
        current: SeasonPart.fromJson(json['current'] as Map<String, dynamic>? ?? const {}),
        next: SeasonPart.fromJson(json['next'] as Map<String, dynamic>? ?? const {}),
        daysToNext: _int(json['days_to_next']),
        cycle: [
          for (final c in (json['cycle'] as List? ?? const []))
            if (c is Map<String, dynamic>) SeasonPart.fromJson(c),
        ],
        yearProgress: _dbl(json['year_progress']) ?? 0,
        alert: json['alert'] as String?,
        tzLabel: '${json['tz_label'] ?? ''}',
      );
}

class QuoteItem {
  final String code;
  final String name;
  final double value;
  final double changePct;
  final double? high;
  final double? low;

  const QuoteItem({required this.code, required this.name, required this.value, this.changePct = 0, this.high, this.low});
}

/// `GET /widgets/quotes`. [reason]: `unavailable` | `disabled` quando [ok] é false.
class QuotesResult {
  final bool ok;
  final String? reason;
  final List<QuoteItem> items;
  final DateTime? updatedAt;
  final bool stale;

  const QuotesResult({this.ok = false, this.reason, this.items = const [], this.updatedAt, this.stale = false});

  const QuotesResult.unavailable() : this(reason: 'unavailable');

  factory QuotesResult.fromJson(Map<String, dynamic> json) {
    final ok = json['ok'] == true;
    if (!ok) return QuotesResult(reason: json['reason'] as String? ?? 'unavailable');
    final items = <QuoteItem>[
      for (final e in (json['items'] as List<dynamic>? ?? const []))
        if (_dbl((e as Map)['value']) != null)
          QuoteItem(
            code: '${e['code'] ?? ''}',
            name: '${e['name'] ?? ''}',
            value: _dbl(e['value'])!,
            changePct: _dbl(e['change_pct']) ?? 0,
            high: _dbl(e['high']),
            low: _dbl(e['low']),
          ),
    ];
    return QuotesResult(
      ok: items.isNotEmpty,
      reason: items.isEmpty ? 'unavailable' : null,
      items: items,
      updatedAt: DateTime.tryParse('${json['updated_at'] ?? ''}')?.toLocal(),
      stale: json['stale'] == true,
    );
  }
}

/// `GET /widgets/stats`.
class StatsInfo {
  final int followers;
  final int following;
  final int newFollowers7d;
  final int postsLive;
  final int views;
  final int likes;
  final int comments;

  const StatsInfo({
    this.followers = 0,
    this.following = 0,
    this.newFollowers7d = 0,
    this.postsLive = 0,
    this.views = 0,
    this.likes = 0,
    this.comments = 0,
  });

  factory StatsInfo.fromJson(Map<String, dynamic> json) => StatsInfo(
        followers: _int(json['followers']),
        following: _int(json['following']),
        newFollowers7d: _int(json['new_followers_7d']),
        postsLive: _int(json['posts_live']),
        views: _int(json['views']),
        likes: _int(json['likes']),
        comments: _int(json['comments']),
      );
}

/// Item de `GET /widgets/expiring`.
class ExpiringPost {
  final int id;
  final bool mine;
  final RailPerson author;
  final String snippet;
  final int secondsLeft;

  const ExpiringPost({required this.id, this.mine = false, required this.author, this.snippet = '', this.secondsLeft = 0});

  factory ExpiringPost.fromJson(Map<String, dynamic> json) => ExpiringPost(
        id: _int(json['id']),
        mine: json['mine'] == true,
        author: RailPerson.fromJson((json['author'] as Map<String, dynamic>?) ?? const {}),
        snippet: '${json['snippet'] ?? ''}',
        secondsLeft: _int(json['seconds_left']),
      );
}

/// `GET /widgets/phrase`.
class PhraseInfo {
  final String text;
  final String? author;

  const PhraseInfo({required this.text, this.author});

  factory PhraseInfo.fromJson(Map<String, dynamic> json) =>
      PhraseInfo(text: '${json['text'] ?? ''}', author: json['author'] as String?);
}
