import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_colors.dart';

/// Cores do Vortex nos dois temas. Espelham o site: escuro = fundo escuro,
/// claro = fundo claro (`[data-theme="light"]` do `style.css`).
///
/// Só o FUNDO e os textos da própria tela mudam. O que fica POR CIMA da mídia
/// (play, duração, nome do perfil, anel de contagem) continua branco/preto
/// fixo, porque depende da foto e não do tema.
class VortexColors {
  final Color bg;

  /// Cor de fundo da peça enquanto a mídia carrega (ou se falhar).
  final Color tileBg;

  /// Caixa "Buscar no Vortex".
  final Color searchBg;
  final Color border;
  final Color text;
  final Color textMuted;

  const VortexColors._({
    required this.bg,
    required this.tileBg,
    required this.searchBg,
    required this.border,
    required this.text,
    required this.textMuted,
  });

  /// Escuro: preto (visual Pinterest que o usuário pediu). Para usar o fundo
  /// padrão do app (#121016), troque `bg` por `AppColors.bg`.
  static const dark = VortexColors._(
    bg: Color(0xFF000000),
    tileBg: Color(0xFF24212D),
    searchBg: Color(0xFF24212D),
    border: Color(0xFF322E3D),
    text: Color(0xFFEDEAE3),
    textMuted: Color(0xFF948DA3),
  );

  static const light = VortexColors._(
    bg: Color(0xFFF7F4EE),
    tileBg: Color(0xFFE6E0D3),
    searchBg: Color(0xFFF0ECE3),
    border: Color(0xFFDDD6C8),
    text: Color(0xFF241F2B),
    textMuted: Color(0xFF726B7A),
  );

  /// Cores do tema que está valendo neste ponto da árvore (use dentro de um
  /// [VortexThemeScope]; fora dele o app é sempre escuro, e é isso que volta).
  static VortexColors of(BuildContext context) =>
      Theme.of(context).brightness == Brightness.light ? light : dark;
}

/// Guarda se o APP (e o Vortex) está no tema claro ou escuro. Mesma chave que o site usa
/// no navegador (`driqy-theme`, valores `dark` | `light`), padrão escuro.
///
/// O app inteiro segue este controlador: `main.dart` liga `themeMode` do
/// `MaterialApp` a ele e [AppColors.brightness] é atualizado a cada troca (os
/// tokens de `AppColors` leem essa chave). O nome ficou por compatibilidade.
class VortexThemeController extends ChangeNotifier {
  VortexThemeController._();

  static final VortexThemeController instance = VortexThemeController._();

  static const String prefsKey = 'driqy-theme';

  Brightness _brightness = Brightness.dark;

  Brightness get brightness => _brightness;
  bool get isLight => _brightness == Brightness.light;

  /// Lê a escolha salva (chame no `main`, antes do `runApp`). Falha em silêncio:
  /// sem preferência salva o Vortex fica escuro.
  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(prefsKey);
      final next = saved == 'light' ? Brightness.light : Brightness.dark;
      if (next != _brightness) {
        _brightness = next;
        AppColors.brightness = next;
        notifyListeners();
      }
    } catch (_) {
      // sem preferência salva: segue escuro
    }
  }

  Future<void> setBrightness(Brightness value) async {
    if (value == _brightness) return;
    _brightness = value;
    AppColors.brightness = value; // ANTES de avisar: quem reconstrói já lê o tema novo
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(prefsKey, value == Brightness.light ? 'light' : 'dark');
    } catch (_) {
      // a troca já valeu nesta sessão; só não ficou salva
    }
  }

  Future<void> toggle() => setBrightness(isLight ? Brightness.dark : Brightness.light);
}

/// Antes colocava o tema claro/escuro só em volta das telas do Vortex. Agora o app
/// inteiro segue o tema (ver `main.dart`), então isto só devolve o filho; fica para
/// não quebrar as telas que já o usam.
class VortexThemeScope extends StatelessWidget {
  final Widget child;

  const VortexThemeScope({super.key, required this.child});

  @override
  Widget build(BuildContext context) => child;
}

/// Botão sol/lua que troca o tema do Vortex (mostra o tema para o qual vai).
class VortexThemeButton extends StatelessWidget {
  const VortexThemeButton({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = VortexThemeController.instance;
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) => IconButton(
        tooltip: controller.isLight ? 'Tema escuro' : 'Tema claro',
        icon: Icon(controller.isLight ? Icons.dark_mode_outlined : Icons.light_mode_outlined),
        onPressed: controller.toggle,
      ),
    );
  }
}
