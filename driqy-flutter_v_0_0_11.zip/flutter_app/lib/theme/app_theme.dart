import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';
import 'app_spacing.dart';

/// Monta o `ThemeData` do app, reproduzindo a identidade visual do site
/// Driqy: fundo escuro profundo, botões em pílula com gradiente âmbar→rosa,
/// e as mesmas três fontes usadas no CSS (Baloo 2 para a marca, Fraunces
/// para títulos de destaque e Inter para o corpo do texto).
class AppTheme {
  AppTheme._();

  static TextTheme _textTheme(TextTheme base, {Color textColor = _Dk.text}) {
    return GoogleFonts.interTextTheme(base).copyWith(
      headlineMedium: GoogleFonts.fraunces(
        fontWeight: FontWeight.w600,
        color: textColor,
      ),
      headlineSmall: GoogleFonts.fraunces(
        fontWeight: FontWeight.w600,
        color: textColor,
      ),
      titleLarge: GoogleFonts.baloo2(
        fontWeight: FontWeight.w700,
        color: textColor,
      ),
    );
  }

  /// Estilo usado para o wordmark "driqy" (Baloo 2, igual ao `.brand-name`).
  static TextStyle brandWordmark({double fontSize = 22, Color? color}) {
    return GoogleFonts.baloo2(
      fontSize: fontSize,
      fontWeight: FontWeight.w700,
      color: color ?? AppColors.text,
      letterSpacing: 0.2,
    );
  }

  static ThemeData dark() {
    final base = ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      scaffoldBackgroundColor: _Dk.bg,
      colorScheme: const ColorScheme.dark(
        brightness: Brightness.dark,
        primary: _Dk.amber,
        secondary: _Dk.rose,
        surface: _Dk.surface,
        error: _Dk.danger,
        onPrimary: _Dk.onBrand,
        onSecondary: _Dk.onBrand,
        onSurface: _Dk.text,
        onError: Colors.white,
      ),
    );

    return base.copyWith(
      textTheme: _textTheme(base.textTheme),
      appBarTheme: AppBarTheme(
        backgroundColor: _Dk.bg.withValues(alpha: 0.92),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: _Dk.text,
        titleTextStyle: brandWordmark(),
        iconTheme: const IconThemeData(color: _Dk.text),
      ),
      cardTheme: const CardThemeData(
        color: _Dk.surface,
        elevation: 0,
        margin: EdgeInsets.fromLTRB(AppSpacing.gap, 0, AppSpacing.gap, AppSpacing.gap),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(14)),
          side: BorderSide(color: _Dk.border),
        ),
      ),
      dividerTheme: const DividerThemeData(color: _Dk.border, thickness: 1),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: _Dk.surface2,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _Dk.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _Dk.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _Dk.amber, width: 1.6),
        ),
        labelStyle: const TextStyle(color: _Dk.textMuted),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: _Dk.amber,
          foregroundColor: _Dk.onBrand,
          minimumSize: const Size.fromHeight(48),
          shape: const StadiumBorder(),
          textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: _Dk.text,
          side: const BorderSide(color: _Dk.border),
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: _Dk.amber,
        ),
      ),
      iconTheme: const IconThemeData(color: _Dk.textMuted),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: _Dk.surface,
        indicatorColor: _Dk.amber.withValues(alpha: 0.18),
        surfaceTintColor: Colors.transparent,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 11,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected ? _Dk.amber : _Dk.textMuted,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return IconThemeData(color: selected ? _Dk.amber : _Dk.textMuted);
        }),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(color: _Dk.amber),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: _Dk.surface2,
        contentTextStyle: TextStyle(color: _Dk.text),
      ),
      badgeTheme: const BadgeThemeData(backgroundColor: _Dk.rose),
      splashColor: _Dk.amber.withValues(alpha: 0.08),
      highlightColor: _Dk.amber.withValues(alpha: 0.05),
    );
  }

  /// Tema CLARO (mesmos tokens de `[data-theme="light"]` do `style.css`).
  /// Vale para o app inteiro quando a pessoa escolhe o tema claro
  /// (ver `vortex_theme.dart` e `AppColors.brightness`).
  static ThemeData light() {
    const bg = Color(0xFFF7F4EE);
    const surface = Color(0xFFFFFFFF);
    const surface2 = Color(0xFFF0ECE3);
    const border = Color(0xFFDDD6C8);
    const text = Color(0xFF241F2B);
    const muted = Color(0xFF726B7A);
    const amber = Color(0xFFC8791B);
    const rose = Color(0xFFC8425C);
    const danger = Color(0xFFC8324B);
    const onBrand = Color(0xFFFFFFFF);

    final base = ThemeData(
      brightness: Brightness.light,
      useMaterial3: true,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.light(
        primary: amber,
        secondary: rose,
        surface: surface,
        error: danger,
        onPrimary: onBrand,
        onSecondary: onBrand,
        onSurface: text,
        onError: Colors.white,
      ),
    );

    return base.copyWith(
      textTheme: _textTheme(
        base.textTheme.apply(bodyColor: text, displayColor: text),
        textColor: text,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bg.withValues(alpha: 0.92),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: text,
        titleTextStyle: brandWordmark(color: text),
        iconTheme: const IconThemeData(color: text),
      ),
      cardTheme: const CardThemeData(
        color: surface,
        elevation: 0,
        margin: EdgeInsets.fromLTRB(AppSpacing.gap, 0, AppSpacing.gap, AppSpacing.gap),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(14)),
          side: BorderSide(color: border),
        ),
      ),
      dividerTheme: const DividerThemeData(color: border, thickness: 1),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface2,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: amber, width: 1.6),
        ),
        labelStyle: const TextStyle(color: muted),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: amber,
          foregroundColor: onBrand,
          minimumSize: const Size.fromHeight(48),
          shape: const StadiumBorder(),
          textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: text,
          side: const BorderSide(color: border),
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: amber),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: surface,
        selectedColor: amber.withValues(alpha: 0.18),
        side: const BorderSide(color: border),
        labelStyle: const TextStyle(color: text),
      ),
      iconTheme: const IconThemeData(color: muted),
      progressIndicatorTheme: const ProgressIndicatorThemeData(color: amber),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: text,
        contentTextStyle: TextStyle(color: bg),
      ),
      badgeTheme: const BadgeThemeData(backgroundColor: rose),
      splashColor: amber.withValues(alpha: 0.08),
      highlightColor: amber.withValues(alpha: 0.05),
    );
  }
}

/// Tokens do tema ESCURO como constantes (o `ThemeData` escuro é montado com `const`,
/// então não pode ler os getters de [AppColors], que mudam com o tema).
class _Dk {
  _Dk._();
  static const bg = Color(0xFF121016);
  static const surface = Color(0xFF1C1A24);
  static const surface2 = Color(0xFF24212D);
  static const border = Color(0xFF322E3D);
  static const text = Color(0xFFEDEAE3);
  static const textMuted = Color(0xFF948DA3);
  static const amber = Color(0xFFF2A93B);
  static const rose = Color(0xFFE85D75);
  static const danger = Color(0xFFE2536B);
  static const onBrand = Color(0xFF1A1420);
}
