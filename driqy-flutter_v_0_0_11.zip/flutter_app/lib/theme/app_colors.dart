import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Paleta oficial do Driqy, espelhando os tokens definidos em
/// `static/css/style.css` (tema escuro, que é o padrão do site).
class AppColors {
  AppColors._();

  /// Tema que está valendo no app inteiro. Quem muda é o `VortexThemeController`
  /// (`vortex_theme.dart`); os tokens abaixo seguem esta chave. Como dependem do
  /// tema, NÃO são `const`: não use `const` em widget que os receba.
  static Brightness brightness = Brightness.dark;
  static bool get isLight => brightness == Brightness.light;

  // Superfícies e textos: mesmos tokens de `[data-theme="dark"|"light"]` do style.css.
  static Color get bg => isLight ? const Color(0xFFF7F4EE) : const Color(0xFF121016);
  static Color get surface => isLight ? const Color(0xFFFFFFFF) : const Color(0xFF1C1A24);
  static Color get surface2 => isLight ? const Color(0xFFF0ECE3) : const Color(0xFF24212D);
  static Color get border => isLight ? const Color(0xFFDDD6C8) : const Color(0xFF322E3D);

  static Color get text => isLight ? const Color(0xFF241F2B) : const Color(0xFFEDEAE3);
  static Color get textMuted => isLight ? const Color(0xFF726B7A) : const Color(0xFF948DA3);

  // Destaques: no claro ficam um pouco mais escuros para ter contraste no fundo claro.
  static Color get amber => isLight ? const Color(0xFFC8791B) : const Color(0xFFF2A93B);
  static Color get rose => isLight ? const Color(0xFFC8425C) : const Color(0xFFE85D75);
  static const green = Color(0xFF6FBF8B);
  static Color get danger => isLight ? const Color(0xFFC8324B) : const Color(0xFFE2536B);

  /// Cores dos selos de verificação (mesmas do `_badges.html`).
  static const badgeVerified = Color(0xFF1D9BF0);
  static const badgeMod = Color(0xFF17BF63);
  static const badgeAdmin = Color(0xFFF2B90C);

  /// Cor de texto usada sobre os elementos com o gradiente de marca
  /// (botões, selo de "postar" etc.) — igual ao `#1a1420` do CSS.
  static Color get onBrand => isLight ? const Color(0xFFFFFFFF) : const Color(0xFF1A1420);

  static Color badgeColor(String? kind) {
    switch (kind) {
      case 'admin':
        return badgeAdmin;
      case 'mod':
        return badgeMod;
      default:
        return badgeVerified;
    }
  }

  /// Mapeia a chave de cor de destaque do perfil (ex: "violet", "teal")
  /// pro tom real, espelhando `ACCENT_COLORS` em `config.py` no servidor.
  static const Map<String, Color> _accentByKey = {
    'amber': Color(0xFFF2A93B),
    'rose': Color(0xFFE85D75),
    'violet': Color(0xFF9B7BD8),
    'teal': Color(0xFF4FB6A8),
    'blue': Color(0xFF5B9BD8),
    'lime': Color(0xFFA3C95A),
    'coral': Color(0xFFF2765C),
    'fuchsia': Color(0xFFD858B8),
    'gold': Color(0xFFD8B354),
    'sky': Color(0xFF5EC8E0),
    'mint': Color(0xFF5FD6A0),
    'slate': Color(0xFF8F9BBF),
  };

  static Color accentFromKey(String? key) => _accentByKey[key] ?? amber;
}

/// Gradientes de marca reutilizados em botões, anéis e destaques.
class AppGradients {
  AppGradients._();

  static LinearGradient get brand => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [AppColors.amber, AppColors.rose],
  );

  /// Espelha `conic-gradient(from -90deg, var(--amber), var(--rose) 75%,
  /// transparent 75%)` do site (`.brand-ring`/`.login-mark-ring` no
  /// `style.css`): 0%→75% interpola âmbar→rosa, e os 25% finais ficam
  /// totalmente transparentes (o "vão" que dá o efeito de anel aberto,
  /// tipo "C"). A versão anterior não tinha esse trecho transparente
  /// (interpolava de volta rosa→âmbar), por isso o anel do app parecia
  /// uma cor/formato diferente do anel do site.
  static SweepGradient get brandRing => SweepGradient(
    startAngle: 0,
    endAngle: 6.28318530718, // 2*pi — volta completa
    transform: const GradientRotation(-math.pi / 2), // "from -90deg" do CSS
    colors: [
      AppColors.amber,
      AppColors.rose,
      Colors.transparent,
      Colors.transparent,
    ],
    stops: const [0.0, 0.75, 0.75, 1.0],
  );
}
