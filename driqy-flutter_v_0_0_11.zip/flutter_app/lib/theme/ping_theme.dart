import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'app_colors.dart';

/// Tokens do Ping (chat estilo Telegram nas cores do Driqy). Espelha o bloco
/// "Tokens do Ping" de `static/css/style.css` — mantenha os dois sincronizados.
/// Fase 2 do PROGRESSO_PING.md: só tokens; as fases 3–7 aplicam.
class PingColors {
  final Color onAccent;
  final Color bg;
  final Color panel;
  final Color panelHover;
  final Color searchBg;
  final Color bubbleIn;
  final Color bubbleInText;
  final Color bubbleOutText;
  final Color badgeMuted;
  final Color pill;
  final Color patternStroke;

  const PingColors._({
    required this.onAccent,
    required this.bg,
    required this.panel,
    required this.panelHover,
    required this.searchBg,
    required this.bubbleIn,
    required this.bubbleInText,
    required this.bubbleOutText,
    required this.badgeMuted,
    required this.pill,
    required this.patternStroke,
  });

  static const dark = PingColors._(
    onAccent: Color(0xFF1A1420),
    bg: Color(0xFF121016),
    panel: Color(0xFF1C1A24),
    panelHover: Color(0xFF24212D),
    searchBg: Color(0xFF24212D),
    bubbleIn: Color(0xFF24212D),
    bubbleInText: Color(0xFFEDEAE3),
    bubbleOutText: Color(0xFF1A1420),
    badgeMuted: Color(0xFF3A3646),
    pill: Color(0xEB1C1A24), // 92%
    patternStroke: Color(0x21F2A93B), // âmbar ~13%
  );

  static const light = PingColors._(
    onAccent: Color(0xFFFFFFFF),
    bg: Color(0xFFF7F4EE),
    panel: Color(0xFFFFFFFF),
    panelHover: Color(0xFFF0ECE3),
    searchBg: Color(0xFFF0ECE3),
    bubbleIn: Color(0xFFFFFFFF),
    bubbleInText: Color(0xFF241F2B),
    bubbleOutText: Color(0xFFFFFFFF),
    badgeMuted: Color(0xFFCFC8BA),
    pill: Color(0xF0FFFFFF), // 94%
    patternStroke: Color(0x29C8791B), // âmbar escuro ~16%
  );

  /// Gradiente de marca (âmbar → rosa): balão enviado, item selecionado, FAB.
  static final LinearGradient gradient = AppGradients.brand;

  static const double radiusPanel = 22;
  static const double radiusPill = 28;

  static PingColors of(BuildContext context) =>
      Theme.of(context).brightness == Brightness.light ? light : dark;
}

/// Fundo do painel da conversa: cor lisa + doodles (estrela, coração, balão,
/// anel, etc.) desenhados em traço fino nas cores do Driqy.
class PingBackground extends StatelessWidget {
  final Widget? child;

  const PingBackground({super.key, this.child});

  @override
  Widget build(BuildContext context) {
    final c = PingColors.of(context);
    return ColoredBox(
      color: c.bg,
      child: Stack(
        fit: StackFit.expand,
        children: [
          RepaintBoundary(
            child: CustomPaint(painter: PingPatternPainter(c.patternStroke)),
          ),
          if (child != null) child!,
        ],
      ),
    );
  }
}

class PingPatternPainter extends CustomPainter {
  final Color stroke;

  const PingPatternPainter(this.stroke);

  static const double _cell = 80;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = stroke
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true;

    final cols = (size.width / _cell).ceil() + 1;
    final rows = (size.height / _cell).ceil() + 1;
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        final i = r * 31 + c * 17; // "aleatório" determinístico: não pisca ao redesenhar
        // Deslocamento de meia célula em linhas alternadas (padrão em tijolo).
        final cx = c * _cell + (r.isOdd ? _cell / 2 : 0) + _cell / 2;
        final cy = r * _cell + _cell / 2;
        canvas.save();
        canvas.translate(cx, cy);
        canvas.rotate(((i % 7) - 3) * 0.18);
        _doodle(canvas, paint, i % 8);
        canvas.restore();
      }
    }
  }

  void _doodle(Canvas canvas, Paint paint, int kind) {
    switch (kind) {
      case 0:
        canvas.drawCircle(Offset.zero, 7, paint);
        break;
      case 1:
        final star = Path();
        for (var k = 0; k < 10; k++) {
          final rad = k.isEven ? 9.0 : 4.0;
          final a = -math.pi / 2 + k * math.pi / 5;
          final pt = Offset(rad * math.cos(a), rad * math.sin(a));
          if (k == 0) {
            star.moveTo(pt.dx, pt.dy);
          } else {
            star.lineTo(pt.dx, pt.dy);
          }
        }
        star.close();
        canvas.drawPath(star, paint);
        break;
      case 2:
        final heart = Path()
          ..moveTo(0, 8)
          ..cubicTo(-14, -2, -8, -12, 0, -5)
          ..cubicTo(8, -12, 14, -2, 0, 8)
          ..close();
        canvas.drawPath(heart, paint);
        break;
      case 3:
        final r = RRect.fromRectAndRadius(
          const Rect.fromLTWH(-10, -8, 20, 14),
          const Radius.circular(4),
        );
        canvas.drawRRect(r, paint);
        canvas.drawPath(
          Path()
            ..moveTo(-5, 6)
            ..lineTo(-8, 11)
            ..lineTo(0, 6),
          paint,
        );
        break;
      case 4:
        // Anel aberto, como a logo.
        canvas.drawArc(
          Rect.fromCircle(center: Offset.zero, radius: 9),
          -2.2,
          5.0,
          false,
          paint..strokeWidth = 2.4,
        );
        paint.strokeWidth = 1.4;
        break;
      case 5:
        canvas.drawLine(const Offset(-6, 0), const Offset(6, 0), paint);
        canvas.drawLine(const Offset(0, -6), const Offset(0, 6), paint);
        break;
      case 6:
        final wave = Path()..moveTo(-12, 0);
        wave.quadraticBezierTo(-8, -7, -4, 0);
        wave.quadraticBezierTo(0, 7, 4, 0);
        wave.quadraticBezierTo(8, -7, 12, 0);
        canvas.drawPath(wave, paint);
        break;
      default:
        canvas.drawLine(const Offset(-5, -5), const Offset(5, 5), paint);
        canvas.drawLine(const Offset(5, -5), const Offset(-5, 5), paint);
    }
  }

  @override
  bool shouldRepaint(covariant PingPatternPainter old) => old.stroke != stroke;
}
