/// Espaçamento único do app. TODO bloco de conteúdo (cabeçalho de perfil,
/// caixa de postar, cards de post) usa este mesmo valor tanto nas laterais
/// quanto na distância de um bloco para o outro — assim a distância entre
/// os objetos é sempre idêntica.
class AppSpacing {
  AppSpacing._();

  static const double gap = 12;
}
