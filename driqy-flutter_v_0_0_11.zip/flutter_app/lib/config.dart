import 'package:shared_preferences/shared_preferences.dart';

/// Endereço base do backend Flask.
///
/// - Emulador Android apontando pro Flask rodando no seu PC: use
///   'http://10.0.2.2:5000' (10.0.2.2 é como o emulador Android enxerga
///   o "localhost" da máquina host).
/// - iOS Simulator ou Flutter Web rodando na mesma máquina: use
///   'http://127.0.0.1:5000'.
/// - Celular físico na mesma rede Wi-Fi: use o IP local do seu PC, ex.
///   'http://192.168.0.10:5000'.
/// - Produção: troque pelo domínio real, com https.
///
/// Pode ser trocado dentro do app (tela de login → "Alterar servidor"); o valor
/// fica salvo no aparelho. [kDefaultApiBaseUrl] é só o valor de fábrica.
const String kDefaultApiBaseUrl = 'http://192.168.15.84:5000';
String kApiBaseUrl = kDefaultApiBaseUrl;

const String _kApiBasePrefKey = 'driqy-api-base-url';

/// Lê o endereço salvo (chamar no `main`, antes do `runApp`).
Future<void> loadApiBaseUrl() async {
  try {
    final saved = (await SharedPreferences.getInstance()).getString(_kApiBasePrefKey);
    if (saved != null && saved.isNotEmpty) kApiBaseUrl = saved;
  } catch (_) {/* sem storage: fica o padrão */}
}

/// Normaliza ("192.168.0.10:5000" → "http://192.168.0.10:5000") e salva.
/// Devolve o endereço final ou `null` se for inválido.
Future<String?> saveApiBaseUrl(String raw) async {
  var v = raw.trim();
  while (v.endsWith('/')) {
    v = v.substring(0, v.length - 1);
  }
  if (v.isEmpty) return null;
  if (!v.startsWith('http://') && !v.startsWith('https://')) v = 'http://$v';
  final uri = Uri.tryParse(v);
  if (uri == null || uri.host.isEmpty) return null;
  kApiBaseUrl = v;
  try {
    await (await SharedPreferences.getInstance()).setString(_kApiBasePrefKey, v);
  } catch (_) {}
  return v;
}

/// A API devolve URLs de mídia relativas (ex: "/uploads/foo.jpg"), já que
/// quem serve o arquivo é o mesmo backend Flask. Pra usar num Image.network
/// ou VideoPlayerController precisamos completar com [kApiBaseUrl].
/// Se a URL já vier absoluta (começando com http), devolve como está.
String resolveMediaUrl(String url) {
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  return '$kApiBaseUrl$url';
}
