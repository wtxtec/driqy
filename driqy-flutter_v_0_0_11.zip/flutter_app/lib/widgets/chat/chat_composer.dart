import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../theme/app_colors.dart';
import '../../theme/ping_theme.dart';
import 'chat_format.dart';
import 'emoji_panel.dart';
import 'voice_recorder.dart';

/// Barra de digitação: botão de emoji + campo arredondado + botão de enviar.
///
/// Fase 5: com o campo vazio, o botão de enviar vira **microfone** — segurar
/// grava, soltar envia, deslizar pra esquerda cancela, deslizar pra cima
/// trava (mãos livres; aí o botão vira enviar e aparece a lixeira).
///
/// O painel de emojis abre no lugar do teclado (e o botão vira "teclado").
/// Voltar fecha o painel antes de sair da tela. `leading`/`trailing` seguem
/// como encaixes pras próximas fases (anexo 4, microfone/câmera 5/6);
/// quando vazios não aparece nada — sem botão morto na tela.
class ChatComposer extends StatefulWidget {
  final TextEditingController controller;
  final VoidCallback onSend;
  final List<Widget> leading;
  final List<Widget> trailing;
  final FocusNode? focusNode;

  /// Chamado quando uma gravação de voz termina e deve ser enviada. Nulo =
  /// sem microfone (o botão de enviar fica sempre como botão de enviar).
  final Future<void> Function(File file, int durationMs)? onVoiceRecorded;

  /// Avisos curtos da gravação (permissão negada, gravação curta demais).
  final ValueChanged<String>? onVoiceMessage;

  const ChatComposer({
    super.key,
    required this.controller,
    required this.onSend,
    this.leading = const [],
    this.trailing = const [],
    this.focusNode,
    this.onVoiceRecorded,
    this.onVoiceMessage,
  });

  @override
  State<ChatComposer> createState() => _ChatComposerState();
}

class _ChatComposerState extends State<ChatComposer> {
  static const _cancelDx = 110.0; // deslizar pra esquerda cancela
  static const _lockDy = 80.0; // deslizar pra cima trava
  static const _minVoiceMs = 800;
  static const _maxVoiceMs = 15 * 60 * 1000;

  late final FocusNode _focus = widget.focusNode ?? FocusNode();
  bool _emojiOpen = false;

  final VoiceRecorder _voice = VoiceRecorder();
  StreamSubscription<double>? _levelSub;
  Timer? _tick;
  bool _holding = false;
  bool _starting = false;
  bool _recording = false;
  bool _locked = false;
  Offset _origin = Offset.zero;
  double _dx = 0;
  int _elapsedMs = 0;
  DateTime _recStart = DateTime.now();
  final List<double> _levels = List<double>.filled(28, 0.05, growable: true);

  @override
  void dispose() {
    _tick?.cancel();
    _levelSub?.cancel();
    if (_recording) {
      unawaited(_voice.cancel().whenComplete(_voice.dispose));
    } else {
      unawaited(_voice.dispose());
    }
    if (widget.focusNode == null) _focus.dispose();
    super.dispose();
  }

  void _voiceNotice(String text) => widget.onVoiceMessage?.call(text);

  Future<void> _onMicDown(PointerDownEvent e) async {
    if (_recording && _locked) {
      await _finishVoice(send: true); // travada: tocar no botão envia
      return;
    }
    if (_starting || _recording) return;
    _holding = true;
    _origin = e.position;
    _dx = 0;
    _starting = true;
    if (_emojiOpen) setState(() => _emojiOpen = false);
    _focus.unfocus();
    final result = await _voice.start();
    _starting = false;
    if (!mounted) {
      await _voice.cancel();
      return;
    }
    if (result != VoiceStart.started) {
      _holding = false;
      _voiceNotice(result == VoiceStart.denied
          ? 'Permita o uso do microfone nas configurações do aparelho para gravar.'
          : 'Não foi possível iniciar a gravação.');
      return;
    }
    HapticFeedback.mediumImpact();
    _recStart = DateTime.now();
    for (var i = 0; i < _levels.length; i++) {
      _levels[i] = 0.05;
    }
    setState(() {
      _recording = true;
      _locked = false;
      _elapsedMs = 0;
    });
    _levelSub = _voice.levels().listen((v) {
      if (!mounted) return;
      setState(() {
        _levels.add(v < 0.05 ? 0.05 : v);
        _levels.removeAt(0);
      });
    }, onError: (_) {});
    _tick = Timer.periodic(const Duration(milliseconds: 200), (_) {
      if (!mounted || !_recording) return;
      final ms = DateTime.now().difference(_recStart).inMilliseconds;
      setState(() => _elapsedMs = ms);
      if (ms >= _maxVoiceMs) _finishVoice(send: true); // limite: envia o que gravou
    });
    // soltou o dedo antes de a gravação começar (ex.: durante o pedido de permissão)
    if (!_holding && !_locked) await _finishVoice(send: true);
  }

  void _onMicMove(PointerMoveEvent e) {
    if (!_recording || _locked) return;
    final dx = e.position.dx - _origin.dx;
    final dy = _origin.dy - e.position.dy;
    if (dx < -_cancelDx) {
      _finishVoice(send: false);
      return;
    }
    if (dy > _lockDy) {
      HapticFeedback.selectionClick();
      setState(() => _locked = true);
      return;
    }
    setState(() => _dx = dx);
  }

  void _onMicUp() {
    _holding = false;
    if (_recording && !_locked) _finishVoice(send: true);
  }

  Future<void> _finishVoice({required bool send}) async {
    if (!_recording) return;
    final ms = DateTime.now().difference(_recStart).inMilliseconds;
    // desliga o estado ANTES de qualquer await (evita finalizar duas vezes)
    setState(() {
      _recording = false;
      _locked = false;
      _dx = 0;
    });
    _holding = false;
    _tick?.cancel();
    await _levelSub?.cancel();
    _levelSub = null;
    if (!send) {
      await _voice.cancel();
      return;
    }
    final file = await _voice.stop();
    if (file == null) {
      _voiceNotice('Não foi possível salvar a gravação.');
      return;
    }
    if (ms < _minVoiceMs) {
      try {
        await file.delete();
      } catch (_) {}
      _voiceNotice('Segure o microfone para gravar.');
      return;
    }
    await widget.onVoiceRecorded?.call(file, ms);
  }

  void _toggleEmoji() {
    if (_emojiOpen) {
      setState(() => _emojiOpen = false);
      _focus.requestFocus();
    } else {
      _focus.unfocus(); // esconde o teclado
      setState(() => _emojiOpen = true);
    }
  }

  Future<bool> _onWillPop() async {
    if (_recording) {
      await _finishVoice(send: false);
      return false;
    }
    if (_emojiOpen) {
      setState(() => _emojiOpen = false);
      return false;
    }
    return true;
  }

  Widget _buildMicButton() {
    final active = _recording && !_locked;
    return Semantics(
      button: true,
      label: _locked ? 'Enviar áudio' : 'Segure para gravar áudio',
      child: Listener(
        key: const ValueKey('chat-mic'), // mesma chave: o toque continua após reconstruir
        behavior: HitTestBehavior.opaque,
        onPointerDown: _onMicDown,
        onPointerMove: _onMicMove,
        onPointerUp: (_) => _onMicUp(),
        onPointerCancel: (_) => _onMicUp(),
        child: AnimatedScale(
          scale: active ? 1.35 : 1,
          duration: const Duration(milliseconds: 120),
          child: Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              gradient: AppGradients.brand,
              shape: BoxShape.circle,
            ),
            child: Icon(
              _locked ? Icons.send_rounded : Icons.mic,
              color: AppColors.onBrand,
              size: 22,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRecordingBar() {
    final fade = (1 - (-_dx) / _cancelDx).clamp(0.25, 1.0).toDouble();
    return Container(
      constraints: const BoxConstraints(minHeight: 48),
      decoration: BoxDecoration(
        color: PingColors.of(context).panel,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          if (_locked)
            IconButton(
              tooltip: 'Cancelar gravação',
              onPressed: () => _finishVoice(send: false),
              icon: Icon(Icons.delete_outline, color: AppColors.danger),
            )
          else
            const SizedBox(width: 14),
          const _PulsingDot(),
          const SizedBox(width: 8),
          Text(
            chatDuration(_elapsedMs),
            style: const TextStyle(
              fontSize: 15,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _locked
                ? _LevelBars(levels: _levels)
                : Opacity(
                    opacity: fade,
                    child: Row(
                      children: [
                        Icon(Icons.chevron_left, size: 18, color: AppColors.textMuted),
                        Flexible(
                          child: Text(
                            'Deslize para cancelar',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
          if (!_locked)
            Padding(
              padding: EdgeInsets.only(right: 10),
              child: Icon(Icons.lock_outline, size: 18, color: AppColors.textMuted),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Material(
        // Ping 5b: o compositor flutua sobre o fundo com padrão da conversa
        color: Colors.transparent,
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: _recording
                          ? _buildRecordingBar()
                          : Container(
                        decoration: BoxDecoration(
                          color: PingColors.of(context).panel,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            IconButton(
                              tooltip: _emojiOpen ? 'Teclado' : 'Emojis',
                              onPressed: _toggleEmoji,
                              icon: Icon(
                                _emojiOpen ? Icons.keyboard : Icons.emoji_emotions_outlined,
                                color: AppColors.textMuted,
                              ),
                            ),
                            ...widget.leading,
                            Expanded(
                              child: TextField(
                                controller: widget.controller,
                                focusNode: _focus,
                                minLines: 1,
                                maxLines: 6,
                                maxLength: 2000,
                                keyboardType: TextInputType.multiline,
                                textCapitalization: TextCapitalization.sentences,
                                onTap: () {
                                  if (_emojiOpen) setState(() => _emojiOpen = false);
                                },
                                decoration: InputDecoration(
                                  hintText: 'Mensagem',
                                  hintStyle: TextStyle(color: AppColors.textMuted),
                                  border: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  filled: false,
                                  counterText: '',
                                  isDense: true,
                                  contentPadding: EdgeInsets.only(
                                    left: 0, // o botão de emoji ocupa o lado esquerdo
                                    right: widget.trailing.isEmpty ? 16 : 4,
                                    top: 12,
                                    bottom: 12,
                                  ),
                                ),
                              ),
                            ),
                            ...widget.trailing,
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ValueListenableBuilder<TextEditingValue>(
                      valueListenable: widget.controller,
                      builder: (context, value, _) {
                        final enabled = value.text.trim().isNotEmpty;
                        if (widget.onVoiceRecorded != null && (!enabled || _recording)) {
                          return _buildMicButton();
                        }
                        return GestureDetector(
                          onTap: enabled ? widget.onSend : null,
                          child: AnimatedOpacity(
                            duration: const Duration(milliseconds: 150),
                            opacity: enabled ? 1 : 0.45,
                            child: Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                gradient: AppGradients.brand,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(Icons.send_rounded, color: AppColors.onBrand, size: 22),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              if (_emojiOpen) EmojiPanel(controller: widget.controller),
            ],
          ),
        ),
      ),
    );
  }
}

/// Bolinha vermelha piscando (indicador de gravação).
class _PulsingDot extends StatefulWidget {
  const _PulsingDot();

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
        ..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween<double>(begin: 0.25, end: 1).animate(_c),
      child: Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(color: AppColors.danger, shape: BoxShape.circle),
      ),
    );
  }
}

/// Barrinhas que acompanham o volume do microfone (gravação travada).
class _LevelBars extends StatelessWidget {
  final List<double> levels;

  const _LevelBars({required this.levels});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 28,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          for (final v in levels)
            Expanded(
              child: Center(
                child: Container(
                  width: 3,
                  height: 3 + 25 * v,
                  decoration: BoxDecoration(
                    color: AppColors.amber,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
