import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../../theme/ping_theme.dart';

/// Painel de emojis no tema do Driqy. Com [controller], o próprio picker
/// insere no cursor e trata o apagar; com [onSelected], só avisa o emoji
/// escolhido (usado na folha de reações).
///
/// Escrito contra `emoji_picker_flutter` 3.x. Se o `flutter pub get`
/// resolver outra major, os nomes de `Config`/`*ViewConfig` podem mudar.
class EmojiPanel extends StatelessWidget {
  final TextEditingController? controller;
  final ValueChanged<String>? onSelected;
  final double height;

  const EmojiPanel({super.key, this.controller, this.onSelected, this.height = 280});

  @override
  Widget build(BuildContext context) {
    final ping = PingColors.of(context);
    return EmojiPicker(
      textEditingController: controller,
      onEmojiSelected: onSelected == null ? null : (category, emoji) => onSelected!(emoji.emoji),
      config: Config(
        height: height,
        // Telegram: abas de categoria no topo, grade de emojis, barra inferior com buscar e apagar
        emojiViewConfig: EmojiViewConfig(
          backgroundColor: ping.panel,
          columns: 8,
          emojiSizeMax: 30,
        ),
        categoryViewConfig: CategoryViewConfig(
          backgroundColor: ping.panel,
          indicatorColor: AppColors.amber,
          iconColor: AppColors.textMuted,
          iconColorSelected: AppColors.amber,
        ),
        searchViewConfig: SearchViewConfig(
          backgroundColor: ping.panel,
          hintText: 'Buscar Emojis',
        ),
        bottomActionBarConfig: BottomActionBarConfig(
          backgroundColor: ping.panel,
          buttonColor: ping.panel,
          buttonIconColor: AppColors.textMuted,
        ),
      ),
    );
  }
}
