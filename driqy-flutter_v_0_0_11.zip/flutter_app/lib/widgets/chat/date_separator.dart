import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../../theme/ping_theme.dart';

/// Pílula centralizada ("Hoje", "Ontem", "12/10") entre mensagens de dias diferentes.
class DateSeparator extends StatelessWidget {
  final String label;

  const DateSeparator({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: PingColors.of(context).panel.withOpacity(0.9),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
        ),
      ),
    );
  }
}
