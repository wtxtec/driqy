import 'package:flutter/material.dart';

import '../../models/message.dart';

/// Indicador de status de uma mensagem MINHA: relógio (enviando), alerta
/// (falhou), ✓ (enviada), ✓✓ (lida, colorida).
///
/// Obs.: hoje o backend só preenche `delivered_at` junto com `read_at`;
/// "entregue sem ler" (✓✓ cinza) passa a existir na Fase 8 (tempo real).
class MessageTicks extends StatelessWidget {
  final DriqyMessage message;
  final Color baseColor;
  final Color readColor;
  final double size;

  const MessageTicks({
    super.key,
    required this.message,
    required this.baseColor,
    required this.readColor,
    this.size = 14,
  });

  @override
  Widget build(BuildContext context) {
    if (message.localState == MessageLocalState.sending) {
      return Icon(Icons.access_time, size: size - 2, color: baseColor);
    }
    if (message.localState == MessageLocalState.failed) {
      return Icon(Icons.error_outline, size: size + 2, color: Colors.redAccent);
    }
    if (message.isRemoteRead) {
      return Icon(Icons.done_all, size: size, color: readColor);
    }
    if (message.deliveredAt != null) {
      return Icon(Icons.done_all, size: size, color: baseColor);
    }
    return Icon(Icons.done, size: size, color: baseColor);
  }
}
