import 'package:flutter/material.dart';

import '../../models/message.dart';

/// Extensão em minúsculas ('' se não houver).
String fileExt(String? name) {
  final n = name ?? '';
  final i = n.lastIndexOf('.');
  return (i > 0 && i < n.length - 1) ? n.substring(i + 1).toLowerCase() : '';
}

/// Tamanho legível: 512 B · 84 KB · 2,3 MB.
String fileSizeLabel(int? bytes) {
  if (bytes == null || bytes < 0) return '';
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).round()} KB';
  final mb = bytes / (1024 * 1024);
  return '${mb.toStringAsFixed(mb < 10 ? 1 : 0).replaceAll('.', ',')} MB';
}

/// Sigla + cor do ícone por tipo de documento.
({String tag, Color color}) fileIconFor(String ext) {
  switch (ext) {
    case 'pdf':
      return (tag: 'PDF', color: const Color(0xFFD64545));
    case 'doc':
    case 'docx':
    case 'rtf':
    case 'odt':
    case 'txt':
      return (tag: 'DOC', color: const Color(0xFF3B76D4));
    case 'xls':
    case 'xlsx':
    case 'csv':
    case 'ods':
      return (tag: 'XLS', color: const Color(0xFF2E9E5B));
    case 'ppt':
    case 'pptx':
    case 'odp':
      return (tag: 'PPT', color: const Color(0xFFE08A2C));
    case 'zip':
      return (tag: 'ZIP', color: const Color(0xFF8A6BD6));
    case 'heic':
    case 'heif':
      return (tag: 'IMG', color: const Color(0xFFC04A9A));
    default:
      return (
        tag: ext.isEmpty ? 'ARQ' : (ext.length > 4 ? ext.substring(0, 4) : ext).toUpperCase(),
        color: const Color(0xFF7A7A8C),
      );
  }
}

/// Cartão de documento dentro do balão (Fase 15): ícone por tipo, nome, tamanho e ação.
/// Toque = baixar/abrir (quem chama decide). [busy] mostra o progresso enquanto baixa.
class FileMessage extends StatelessWidget {
  final DriqyMessage message;
  final Color textColor;
  final VoidCallback? onOpen;
  final bool busy;

  const FileMessage({
    super.key,
    required this.message,
    required this.textColor,
    this.onOpen,
    this.busy = false,
  });

  @override
  Widget build(BuildContext context) {
    final name = (message.mediaName?.isNotEmpty ?? false) ? message.mediaName! : 'arquivo';
    final ext = fileExt(name);
    final icon = fileIconFor(ext);
    final meta = [fileSizeLabel(message.mediaSize), if (ext.isNotEmpty) ext.toUpperCase()]
        .where((s) => s.isNotEmpty)
        .join(' · ');
    final sending = message.localState == MessageLocalState.sending;
    return Semantics(
      button: onOpen != null,
      label: 'Arquivo $name${meta.isEmpty ? '' : ', $meta'}${onOpen != null ? '. Toque para abrir' : ''}',
      excludeSemantics: true,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: (busy || sending) ? null : onOpen,
        child: ConstrainedBox(
          constraints: const BoxConstraints(minWidth: 210, maxWidth: 290),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 48,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: icon.color,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    icon.tag,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: textColor,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      if (meta.isNotEmpty)
                        Text(
                          meta,
                          style: TextStyle(color: textColor.withOpacity(0.8), fontSize: 12),
                        ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 28,
                  height: 28,
                  child: (busy || sending)
                      ? Padding(
                          padding: const EdgeInsets.all(4),
                          child: CircularProgressIndicator(strokeWidth: 2.2, color: textColor),
                        )
                      : Icon(Icons.download_rounded, size: 22, color: textColor),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
