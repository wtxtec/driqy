import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../../config.dart';
import '../../models/message.dart';
import '../../theme/app_colors.dart';
import 'chat_format.dart';

/// Coordena o player: só um áudio toca por vez e a velocidade (1x/1,5x/2x)
/// vale pra todos (em memória; volta pra 1x ao reabrir o app).
class _AudioHub {
  static final ValueNotifier<Object?> current = ValueNotifier<Object?>(null);
  static final ValueNotifier<double> speed = ValueNotifier<double>(1.0);
  static const speeds = [1.0, 1.5, 2.0];
}

/// Conteúdo da bolha de áudio: play/pausa, onda (toque/arraste pra avançar),
/// tempo e velocidade. O `AudioPlayer` só é criado quando a pessoa toca em
/// play (conversa com dezenas de áudios não abre dezenas de players). Baixa
/// com `Authorization: Bearer` (mídia privada); mensagem local toca o
/// arquivo do aparelho.
class AudioMessage extends StatefulWidget {
  final DriqyMessage message;
  final Map<String, String>? headers;
  final bool mine;

  const AudioMessage({super.key, required this.message, required this.mine, this.headers});

  /// Pausa qualquer áudio do chat que esteja tocando (ex.: chegou uma chamada — Fase 12).
  static void pauseAll() => _AudioHub.current.value = Object();

  @override
  State<AudioMessage> createState() => _AudioMessageState();
}

class _AudioMessageState extends State<AudioMessage> {
  static const _barCount = 32;

  AudioPlayer? _player;
  final _subs = <StreamSubscription<dynamic>>[];
  Duration _pos = Duration.zero;
  Duration? _serverDuration;
  bool _playing = false;
  bool _loading = false;
  bool _error = false;
  late List<double> _bars = _makeBars();

  List<double> _makeBars() {
    final seed = (widget.message.clientId ?? '${widget.message.id}').hashCode;
    final rnd = math.Random(seed);
    return List.generate(_barCount, (_) => 0.25 + rnd.nextDouble() * 0.75);
  }

  String get _sourceKey =>
      widget.message.localPath ?? widget.message.mediaUrl ?? '';

  Duration get _total {
    final ms = widget.message.mediaDurationMs;
    if (ms != null && ms > 0) return Duration(milliseconds: ms);
    return _serverDuration ?? Duration.zero;
  }

  @override
  void initState() {
    super.initState();
    _AudioHub.current.addListener(_onHub);
    _AudioHub.speed.addListener(_onSpeed);
  }

  @override
  void didUpdateWidget(covariant AudioMessage old) {
    super.didUpdateWidget(old);
    final oldKey = old.message.localPath ?? old.message.mediaUrl ?? '';
    if (oldKey != _sourceKey && !_playing) {
      // a mensagem local virou a do servidor: recarrega do endereço novo
      _disposePlayer();
      _pos = Duration.zero;
      _error = false;
    }
    final oldSeed = old.message.clientId ?? '${old.message.id}';
    final newSeed = widget.message.clientId ?? '${widget.message.id}';
    if (oldSeed != newSeed) _bars = _makeBars();
  }

  @override
  void dispose() {
    _AudioHub.current.removeListener(_onHub);
    _AudioHub.speed.removeListener(_onSpeed);
    if (_AudioHub.current.value == this) _AudioHub.current.value = null;
    _disposePlayer();
    super.dispose();
  }

  void _disposePlayer() {
    for (final s in _subs) {
      s.cancel();
    }
    _subs.clear();
    _player?.dispose();
    _player = null;
    _playing = false;
  }

  void _onHub() {
    if (_AudioHub.current.value != this && _playing) _player?.pause();
  }

  void _onSpeed() {
    _player?.setSpeed(_AudioHub.speed.value);
  }

  AudioSource? _source() {
    final m = widget.message;
    if (m.localPath != null) return AudioSource.uri(Uri.file(m.localPath!));
    if (m.mediaUrl != null) {
      return AudioSource.uri(Uri.parse(resolveMediaUrl(m.mediaUrl!)), headers: widget.headers);
    }
    return null;
  }

  Future<bool> _ensurePlayer() async {
    if (_player != null) return true;
    final src = _source();
    if (src == null) return false;
    final p = AudioPlayer();
    setState(() {
      _loading = true;
      _error = false;
    });
    try {
      _serverDuration = await p.setAudioSource(src);
    } catch (_) {
      await p.dispose();
      if (mounted) {
        setState(() {
          _loading = false;
          _error = true;
        });
      }
      return false;
    }
    if (!mounted) {
      await p.dispose();
      return false;
    }
    _player = p;
    // posição a cada ~100 ms enquanto toca (createPositionStream emite sozinho; o positionStream
    // comum só emitia em eventos e deixava o relógio parado em 0:00 em arquivo local)
    _subs.add(p
        .createPositionStream(
          minPeriod: const Duration(milliseconds: 100),
          maxPeriod: const Duration(milliseconds: 200),
        )
        .listen((d) {
      if (mounted && (p.playing || d > Duration.zero)) setState(() => _pos = d);
    }));
    _subs.add(p.playerStateStream.listen((st) {
      if (!mounted) return;
      if (st.processingState == ProcessingState.completed) {
        p.pause();
        p.seek(Duration.zero);
        setState(() {
          _playing = false;
          _pos = Duration.zero;
        });
        return;
      }
      setState(() => _playing = st.playing);
    }));
    setState(() => _loading = false);
    return true;
  }

  Future<void> _toggle() async {
    if (_loading) return;
    if (!await _ensurePlayer()) return;
    final p = _player!;
    if (_playing) {
      await p.pause();
    } else {
      _AudioHub.current.value = this;
      await p.setSpeed(_AudioHub.speed.value);
      setState(() => _playing = true); // já mostra "tocando" sem esperar o evento do player
      p.play(); // o Future só completa no fim da reprodução: não esperar
    }
  }

  Future<void> _seek(double ratio) async {
    final total = _total;
    if (total == Duration.zero) return;
    if (!await _ensurePlayer()) return;
    final target = Duration(milliseconds: (total.inMilliseconds * ratio.clamp(0.0, 1.0)).round());
    await _player!.seek(target);
    if (mounted) setState(() => _pos = target);
  }

  void _cycleSpeed() {
    final speeds = _AudioHub.speeds;
    final next = speeds[(speeds.indexOf(_AudioHub.speed.value) + 1) % speeds.length];
    _AudioHub.speed.value = next;
  }

  @override
  Widget build(BuildContext context) {
    final mine = widget.mine;
    final fg = mine ? AppColors.onBrand : AppColors.text;
    final playBg = mine ? AppColors.onBrand : AppColors.amber;
    final playFg = mine ? AppColors.amber : AppColors.onBrand;
    final total = _total;
    final ratio = total.inMilliseconds == 0
        ? 0.0
        : (_pos.inMilliseconds / total.inMilliseconds).clamp(0.0, 1.0).toDouble();
    final showPos = _playing || _pos > Duration.zero;
    final label = _error
        ? 'Indisponível'
        : chatDuration((showPos ? _pos : total).inMilliseconds);

    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 230),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Semantics(
            button: true,
            label: _playing ? 'Pausar áudio' : 'Reproduzir áudio',
            child: GestureDetector(
              onTap: _toggle,
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: playBg, shape: BoxShape.circle),
                child: _loading
                    ? Padding(
                        padding: const EdgeInsets.all(11),
                        child: CircularProgressIndicator(strokeWidth: 2.5, color: playFg),
                      )
                    : Icon(
                        _error
                            ? Icons.error_outline
                            : (_playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                        color: playFg,
                        size: 26,
                      ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                LayoutBuilder(
                  builder: (context, c) => GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTapDown: (d) => _seek(d.localPosition.dx / c.maxWidth),
                    onHorizontalDragUpdate: (d) => _seek(d.localPosition.dx / c.maxWidth),
                    child: SizedBox(
                      height: 30,
                      width: double.infinity,
                      child: CustomPaint(
                        painter: _WavePainter(bars: _bars, progress: ratio, color: fg),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        color: fg.withOpacity(0.75),
                        fontSize: 11,
                        fontFeatures: const [FontFeature.tabularFigures()],
                      ),
                    ),
                    const Spacer(),
                    ValueListenableBuilder<double>(
                      valueListenable: _AudioHub.speed,
                      builder: (context, speed, _) => GestureDetector(
                        onTap: _cycleSpeed,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 1),
                          decoration: BoxDecoration(
                            color: fg.withOpacity(0.18),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            speed == 1.5 ? '1,5×' : '${speed.toInt()}×',
                            style: TextStyle(
                              color: fg,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  final List<double> bars;
  final double progress;
  final Color color;

  _WavePainter({required this.bars, required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final n = bars.length;
    final slot = size.width / n;
    final barW = math.max(2.0, slot * 0.58);
    final played = (progress * n).round();
    for (var i = 0; i < n; i++) {
      final h = math.max(3.0, size.height * bars[i]);
      final x = i * slot + (slot - barW) / 2;
      final paint = Paint()..color = color.withOpacity(i < played ? 0.95 : 0.32);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, (size.height - h) / 2, barW, h),
          const Radius.circular(2),
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _WavePainter old) =>
      old.progress != progress || old.color != color || old.bars != bars;
}
