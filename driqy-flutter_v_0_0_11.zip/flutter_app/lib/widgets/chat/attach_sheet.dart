import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';

import '../../theme/app_colors.dart';
import '../../theme/ping_theme.dart';

/// O que a pessoa escolheu na folha de anexo.
enum AttachKind { camera, videoCamera, file, asset }

class AttachPick {
  final AttachKind kind;
  final AssetEntity? asset;
  const AttachPick(this.kind, [this.asset]);
}

/// Folha de anexo estilo Telegram: grade da galeria com a **câmera ao vivo**
/// no primeiro quadrado, e abas Galeria / Arquivo / Vídeo embaixo.
/// Tocar na câmera tira foto (câmera do sistema); tocar numa miniatura escolhe
/// aquela foto/vídeo/GIF. Sem permissão da galeria, ainda dá pra usar câmera e arquivo.
Future<AttachPick?> showAttachSheet(BuildContext context) {
  return showModalBottomSheet<AttachPick>(
    context: context,
    isScrollControlled: true,
    backgroundColor: PingColors.of(context).panel,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (_) => const _AttachSheet(),
  );
}

class _AttachSheet extends StatefulWidget {
  const _AttachSheet();

  @override
  State<_AttachSheet> createState() => _AttachSheetState();
}

class _AttachSheetState extends State<_AttachSheet> {
  CameraController? _cam;
  List<AssetEntity> _assets = [];
  bool _loading = true;
  bool _denied = false;

  @override
  void initState() {
    super.initState();
    _initCamera();
    _loadGallery();
  }

  @override
  void dispose() {
    _cam?.dispose();
    super.dispose();
  }

  Future<void> _initCamera() async {
    try {
      final cams = await availableCameras();
      if (cams.isEmpty) return;
      final back = cams.firstWhere((c) => c.lensDirection == CameraLensDirection.back, orElse: () => cams.first);
      final c = CameraController(back, ResolutionPreset.low, enableAudio: false);
      await c.initialize();
      if (!mounted) {
        await c.dispose();
        return;
      }
      setState(() => _cam = c);
    } catch (_) {/* sem permissão/câmera: o quadrado mostra só o ícone */}
  }

  Future<void> _loadGallery() async {
    try {
      final ps = await PhotoManager.requestPermissionExtend();
      if (!ps.hasAccess) {
        if (mounted) setState(() { _denied = true; _loading = false; });
        return;
      }
      final paths = await PhotoManager.getAssetPathList(onlyAll: true, type: RequestType.common);
      final list = paths.isEmpty ? <AssetEntity>[] : await paths.first.getAssetListPaged(page: 0, size: 120);
      if (mounted) setState(() { _assets = list; _loading = false; });
    } catch (_) {
      if (mounted) setState(() { _denied = true; _loading = false; });
    }
  }

  Widget _cameraTile() {
    final c = _cam;
    return GestureDetector(
      onTap: () => Navigator.pop(context, const AttachPick(AttachKind.camera)),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Stack(fit: StackFit.expand, children: [
          if (c != null && c.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              clipBehavior: Clip.hardEdge,
              child: SizedBox(
                width: c.value.previewSize?.height ?? 100,
                height: c.value.previewSize?.width ?? 100,
                child: CameraPreview(c),
              ),
            )
          else
            Container(color: Colors.black26),
          const Center(child: Icon(Icons.photo_camera, color: Colors.white, size: 30)),
        ]),
      ),
    );
  }

  Widget _assetTile(AssetEntity a) {
    return GestureDetector(
      onTap: () => Navigator.pop(context, AttachPick(AttachKind.asset, a)),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Stack(fit: StackFit.expand, children: [
          _AssetThumb(asset: a),
          if (a.type == AssetType.video)
            Positioned(
              left: 4,
              bottom: 4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
                child: Text(_dur(a.duration), style: const TextStyle(color: Colors.white, fontSize: 11)),
              ),
            ),
        ]),
      ),
    );
  }

  String _dur(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';

  Widget _tab(IconData icon, String label, AttachKind? kind, {bool on = false}) {
    final color = on ? AppColors.amber : AppColors.textMuted;
    return Expanded(
      child: InkWell(
        onTap: kind == null ? null : () => Navigator.pop(context, AttachPick(kind)),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: color),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: color, fontSize: 12)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pc = PingColors.of(context);
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.6,
      minChildSize: 0.35,
      maxChildSize: 0.95,
      builder: (ctx, scroll) => Column(children: [
        Container(
          margin: const EdgeInsets.only(top: 8, bottom: 8),
          width: 36,
          height: 4,
          decoration: BoxDecoration(color: AppColors.textMuted.withOpacity(0.5), borderRadius: BorderRadius.circular(2)),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : GridView.builder(
                  controller: scroll,
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 3,
                    crossAxisSpacing: 3,
                  ),
                  itemCount: _assets.length + 1 + (_denied ? 1 : 0),
                  itemBuilder: (_, i) {
                    if (i == 0) return _cameraTile();
                    if (_denied) {
                      return Padding(
                        padding: const EdgeInsets.all(8),
                        child: TextButton(
                          onPressed: PhotoManager.openSetting,
                          child: const Text('Permitir acesso à galeria', textAlign: TextAlign.center),
                        ),
                      );
                    }
                    return _assetTile(_assets[i - 1]);
                  },
                ),
        ),
        Material(
          color: pc.panel,
          child: SafeArea(
            top: false,
            child: Row(children: [
              _tab(Icons.photo_library, 'Galeria', null, on: true),
              _tab(Icons.insert_drive_file_outlined, 'Arquivo', AttachKind.file),
              _tab(Icons.videocam_outlined, 'Vídeo', AttachKind.videoCamera),
            ]),
          ),
        ),
      ]),
    );
  }
}

/// Miniatura de um item da galeria (só usa o `photo_manager`, sem pacote extra).
class _AssetThumb extends StatefulWidget {
  final AssetEntity asset;
  const _AssetThumb({required this.asset});

  @override
  State<_AssetThumb> createState() => _AssetThumbState();
}

class _AssetThumbState extends State<_AssetThumb> {
  late final Future<Uint8List?> _data = widget.asset.thumbnailDataWithSize(const ThumbnailSize.square(260));

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List?>(
      future: _data,
      builder: (_, snap) {
        final bytes = snap.data;
        if (bytes == null) return Container(color: Colors.black26);
        return Image.memory(bytes, fit: BoxFit.cover, gaplessPlayback: true);
      },
    );
  }
}
