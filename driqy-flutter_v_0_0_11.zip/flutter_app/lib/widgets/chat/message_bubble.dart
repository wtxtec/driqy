import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../models/message.dart';
import '../../theme/app_colors.dart';
import '../../theme/ping_theme.dart';
import '../driqy_image.dart';
import 'audio_message.dart';
import 'chat_format.dart';
import 'file_message.dart';
import 'message_ticks.dart';

/// Balão de uma mensagem. `grouped` = continua uma sequência do mesmo
/// remetente (margem menor, sem "rabinho"). O corpo escolhe o visual pelo
/// tipo: imagem/GIF já aparece como miniatura (Fase 4) e áudio tem player
/// com onda (Fase 5); vídeo/arquivo ainda mostram só um espaço reservado
/// (rótulo + legenda) — player de vídeo na Fase 6.
class MessageBubble extends StatelessWidget {
  final DriqyMessage message;
  final bool grouped;
  final VoidCallback? onRetry;
  final VoidCallback? onLongPress;
  final ValueChanged<String>? onReactionTap;

  /// Toque na imagem (abre o visualizador). Nulo = não abre (ex.: falhou).
  final VoidCallback? onOpenMedia;

  /// Headers pra baixar a mídia privada (Authorization: Bearer).
  final Map<String, String>? mediaHeaders;

  /// Quem escreveu a mensagem citada ("Você" ou o nome do contato) e o que
  /// fazer ao tocar na citação (rolar até a original).
  final String? replyAuthor;
  final VoidCallback? onReplyTap;

  /// Fase 8: termo da busca na conversa (realça nos textos) e se este é o
  /// resultado atual (borda âmbar).
  final String? highlight;
  final bool searchCurrent;

  /// Fase 14: "Ligar de volta" no balão de chamada (nulo = sem botão, ex.: já em chamada).
  final VoidCallback? onCallBack;

  /// Fase 15: toque no documento (baixar/abrir) e se está baixando agora.
  final VoidCallback? onOpenFile;
  final bool fileBusy;

  const MessageBubble({
    super.key,
    required this.message,
    this.grouped = false,
    this.onRetry,
    this.onLongPress,
    this.onReactionTap,
    this.onOpenMedia,
    this.mediaHeaders,
    this.replyAuthor,
    this.onReplyTap,
    this.highlight,
    this.searchCurrent = false,
    this.onCallBack,
    this.onOpenFile,
    this.fileBusy = false,
  });

  @override
  Widget build(BuildContext context) {
    final mine = message.mine;
    final ping = PingColors.of(context);
    final textColor = mine ? ping.bubbleOutText : ping.bubbleInText;
    final subtle = mine ? AppColors.onBrand.withOpacity(0.6) : AppColors.textMuted;
    final failed = message.localState == MessageLocalState.failed;

    // 1–3 emojis sem texto: aparecem grandes, sem balão (como no WhatsApp)
    final emojiCount = (message.type == MessageType.text &&
            !message.deleted &&
            message.replyTo == null)
        ? emojiOnlyCount(message.content)
        : null;
    if (emojiCount != null && emojiCount <= 3) {
      return _wrap(_buildEmojiOnly(emojiCount), failed);
    }

    // imagem: o balão é quase só a foto (borda fina em volta)
    final isImage = (message.type == MessageType.image || message.type == MessageType.video) &&
        !message.deleted &&
        !message.viewOnce &&
        (message.localPath != null || message.mediaUrl != null);

    // texto puro (sem mídia/chamada/arquivo/visualização única): hora dentro da última linha
    final inlineMeta = message.type == MessageType.text &&
        !message.deleted &&
        !message.viewOnce &&
        !message.isMedia &&
        !isImage;

    final bubble = Container(
      margin: EdgeInsets.only(top: grouped ? 2 : 8),
      padding: isImage
          ? const EdgeInsets.fromLTRB(3, 3, 3, 5)
          : const EdgeInsets.fromLTRB(12, 8, 10, 6),
      // foto/vídeo: o balão tem EXATAMENTE a largura da foto (+3px de moldura de cada lado).
      // Sem isso o Align do horário esticava o balão até 78% da tela e sobrava gradiente nas laterais.
      width: isImage ? _imageBoxW(context) + 6 : null,
      constraints: BoxConstraints(maxWidth: math.min(MediaQuery.of(context).size.width * 0.8, 480.0)),
      decoration: BoxDecoration(
        gradient: mine ? AppGradients.brand : null,
        color: mine ? null : ping.bubbleIn,
        border: searchCurrent ? Border.all(color: AppColors.amber, width: 2) : null,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18),
          topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(mine || grouped ? 18 : 5),
          bottomRight: Radius.circular(!mine || grouped ? 18 : 5),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (message.forwarded && !message.deleted)
            Padding(
              padding: EdgeInsets.fromLTRB(isImage ? 6 : 0, isImage ? 3 : 0, 0, 3),
              child: Text('↪ Encaminhada',
                  style: TextStyle(color: subtle, fontSize: 11, fontStyle: FontStyle.italic)),
            ),
          if (message.replyTo != null && !message.deleted)
            Padding(
              padding: isImage ? const EdgeInsets.all(4) : EdgeInsets.zero,
              child: _buildReply(textColor, subtle),
            ),
          if (inlineMeta)
            // Estilo Telegram: a hora fica na última linha do texto; se não couber, desce pra linha de baixo.
            Stack(
              children: [
                _rich(message.content, TextStyle(color: textColor, fontSize: 16, height: 1.25),
                    tail: _metaWidth()),
                Positioned(right: 0, bottom: 0, child: _metaRow(subtle)),
              ],
            )
          else ...[
            _buildBody(context, textColor, subtle),
            const SizedBox(height: 3),
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: isImage ? const EdgeInsets.only(right: 7) : EdgeInsets.zero,
                child: _metaRow(subtle),
              ),
            ),
          ],
        ],
      ),
    );

    return _wrap(bubble, failed);
  }

  /// Largura reservada no fim do texto para a hora (+ "editada" + ticks).
  double _metaWidth() =>
      10 + 31 + (message.editedAt != null ? 44 : 0) + (message.mine ? 19 : 0);

  /// "editada", hora e ticks (só nas minhas).
  Widget _metaRow(Color subtle) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (message.editedAt != null && !message.deleted) ...[
          Text('editada', style: TextStyle(color: subtle, fontSize: 11)),
          const SizedBox(width: 4),
        ],
        Text(chatClock(message.createdAt), style: TextStyle(color: subtle, fontSize: 11)),
        if (message.mine) ...[
          const SizedBox(width: 4),
          MessageTicks(
            message: message,
            baseColor: subtle,
            // azul escuro: legível sobre o gradiente âmbar→rosa
            readColor: const Color(0xFF0A4A8F),
          ),
        ],
      ],
    );
  }

  /// Casca comum: alinhamento, toque (reenviar), toque longo (reagir),
  /// chips de reação e aviso de falha.
  Widget _wrap(Widget content, bool failed) {
    final mine = message.mine;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: failed ? onRetry : null,
        onLongPress: onLongPress,
        child: Column(
          crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            content,
            if (message.reactions.isNotEmpty) _buildReactions(),
            if (failed)
              const Padding(
                padding: EdgeInsets.only(top: 2),
                child: Text(
                  'Não enviada — toque para tentar de novo',
                  style: TextStyle(color: Colors.redAccent, fontSize: 11),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildReactions() {
    return Padding(
      padding: const EdgeInsets.only(top: 3),
      child: Wrap(
        spacing: 4,
        runSpacing: 4,
        children: [
          for (final r in message.reactions)
            GestureDetector(
              onTap: onReactionTap == null ? null : () => onReactionTap!(r.emoji),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: r.mine ? AppColors.amber.withOpacity(0.22) : AppColors.surface2,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: r.mine ? AppColors.amber : AppColors.border),
                ),
                child: Text(
                  r.count > 1 ? '${r.emoji} ${r.count}' : r.emoji,
                  style: TextStyle(fontSize: 12, color: AppColors.text),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEmojiOnly(int count) {
    final size = count == 1 ? 52.0 : (count == 2 ? 42.0 : 34.0);
    return Container(
      margin: EdgeInsets.only(top: grouped ? 2 : 8),
      child: Column(
        crossAxisAlignment: message.mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(message.content.trim(), style: TextStyle(fontSize: size, height: 1.15)),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                chatClock(message.createdAt),
                style: TextStyle(color: AppColors.textMuted, fontSize: 10),
              ),
              if (message.mine) ...[
                const SizedBox(width: 4),
                MessageTicks(
                  message: message,
                  baseColor: AppColors.textMuted,
                  readColor: const Color(0xFF5EC8E0),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildReply(Color textColor, Color subtle) {
    final reply = message.replyTo!;
    final author = replyAuthor;
    return GestureDetector(
      onTap: reply.id > 0 ? onReplyTap : null,
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.12),
          borderRadius: BorderRadius.circular(8),
          border: Border(left: BorderSide(color: textColor.withOpacity(0.7), width: 3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (author != null)
              Text(
                author,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: textColor.withOpacity(0.95),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            Text(
              reply.preview,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: textColor.withOpacity(0.85), fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  /// Miniatura do vídeo: arquivo local, miniatura do servidor (com Bearer) ou,
  /// sem nenhuma, um fundo escuro com ícone (o ▶ é desenhado por cima).
  Widget _videoThumb() {
    Widget placeholder() => const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2A2430), Color(0xFF111015)],
            ),
          ),
          child: Center(child: Icon(Icons.movie_outlined, color: Colors.white24, size: 40)),
        );
    if (message.localThumbPath != null) {
      return Image.file(File(message.localThumbPath!),
          fit: BoxFit.cover, errorBuilder: (c, e, s) => placeholder());
    }
    if (message.mediaThumbUrl != null) {
      return DriqyImage(
        url: message.mediaThumbUrl!,
        headers: mediaHeaders,
        fit: BoxFit.cover,
        errorBuilder: (_) => placeholder(),
      );
    }
    return placeholder();
  }

  /// Miniatura da imagem/GIF: proporção real (`media_width/height`) com
  /// limites pra não ficar enorme/minúscula; local (enviando) mostra o
  /// arquivo do aparelho, remoto baixa com Bearer (mídia privada).
  double _imageRatio() {
    final w = message.mediaWidth, h = message.mediaHeight;
    return ((w != null && h != null && h > 0) ? w / h : 4 / 3).clamp(0.55, 2.0).toDouble();
  }

  /// Largura da caixa da foto: segue a PROPORÇÃO (em pé fica mais estreita, limite de altura;
  /// deitada ocupa até maxW). Usada pela imagem e pelo balão, para os dois terem a mesma largura.
  double _imageBoxW(BuildContext context) {
    final media = MediaQuery.of(context).size;
    final maxW = math.min(media.width * 0.66, 300.0);
    final maxH = math.min(media.height * 0.5, 380.0);
    return math.max(math.min(maxW, maxH * _imageRatio()), math.min(maxW, 150.0));
  }

  Widget _buildImage(BuildContext context, Color textColor) {
    final ratio = _imageRatio();
    final boxW = _imageBoxW(context);
    Widget broken(BuildContext _) => const Center(
          child: Icon(Icons.broken_image_outlined, color: Colors.white54, size: 36),
        );
    final isVideo = message.type == MessageType.video;
    final Widget image = isVideo
        ? _videoThumb()
        : message.localPath != null
        ? Image.file(
            File(message.localPath!),
            fit: BoxFit.cover,
            errorBuilder: (c, e, s) => broken(c),
          )
        : DriqyImage(
            url: message.mediaUrl!,
            mediaType: message.isGif ? 'gif' : null,
            headers: mediaHeaders,
            fit: BoxFit.cover,
            errorBuilder: broken,
          );
    final caption = message.caption;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: onOpenMedia,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(13),
            child: SizedBox(
              width: boxW,
              child: AspectRatio(
                aspectRatio: ratio,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    ColoredBox(color: Colors.black26, child: image),
                    if (message.localState == MessageLocalState.sending)
                      const ColoredBox(
                        color: Colors.black38,
                        child: Center(
                          child: SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white),
                          ),
                        ),
                      ),
                    if (isVideo && message.localState == null)
                      const Center(
                        child: DecoratedBox(
                          decoration: BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                          child: Padding(
                            padding: EdgeInsets.all(10),
                            child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 34),
                          ),
                        ),
                      ),
                    if (isVideo && (message.mediaDurationMs ?? 0) > 0)
                      Positioned(
                        left: 6,
                        bottom: 6,
                        child: DecoratedBox(
                          decoration: const BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              const Icon(Icons.videocam, color: Colors.white, size: 12),
                              const SizedBox(width: 3),
                              Text(chatDuration(message.mediaDurationMs!),
                                  style: const TextStyle(color: Colors.white, fontSize: 11)),
                            ]),
                          ),
                        ),
                      ),
                    if (message.isGif && message.localState == null)
                      const Positioned(
                        left: 6,
                        bottom: 6,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                          ),
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                            child: Text('GIF',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (caption != null && caption.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(7, 5, 7, 0),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: boxW - 14),
              child: _rich(caption, TextStyle(color: textColor, fontSize: 15, height: 1.25)),
            ),
          ),
      ],
    );
  }

  /// Visualização única: nunca mostra miniatura. Destinatário toca para abrir (uma vez);
  /// remetente só vê o estado (não aberta / aberta / expirada).
  Widget _buildViewOnce(Color textColor, Color subtle) {
    final kind = message.type == MessageType.video
        ? 'Vídeo'
        : (message.type == MessageType.audio ? 'Áudio' : 'Foto');
    final state = message.viewOnceState ?? 'unopened';
    final sending = message.localState == MessageLocalState.sending;
    final canOpen = message.canOpenViewOnce && !message.mine && onOpenMedia != null;
    final String sub;
    final IconData icon;
    if (sending) {
      sub = 'Enviando…';
      icon = Icons.looks_one_outlined;
    } else if (state == 'opened') {
      sub = 'Aberta';
      icon = Icons.check_circle_outline;
    } else if (state == 'expired') {
      sub = 'Expirada';
      icon = Icons.timer_off_outlined;
    } else {
      sub = message.mine ? 'Não aberta' : 'Toque para abrir';
      icon = Icons.looks_one_outlined;
    }
    final dim = state != 'unopened' && !sending;
    final color = dim ? subtle : textColor;
    return Semantics(
      button: canOpen,
      label: '$kind de visualização única, $sub',
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: canOpen ? onOpenMedia : null,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: color, width: 1.6),
                ),
                child: Icon(icon, size: 22, color: color),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(kind,
                      style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w600)),
                  Text(sub, style: TextStyle(color: subtle, fontSize: 12)),
                ],
              ),
              const SizedBox(width: 6),
            ],
          ),
        ),
      ),
    );
  }

  /// Fase 14: balão de chamada. `media_mime` = `call/<voice|video>/<estado>`;
  /// `media_duration_ms` = duração. Quem ligou é o remetente (`mine`).
  Widget _buildCall(Color textColor, Color subtle) {
    final parts = (message.mediaMime ?? '').split('/');
    final video = parts.length > 1 && parts[1] == 'video';
    final state = parts.length > 2 ? parts[2] : 'ended';
    final mine = message.mine;
    final bad = state == 'missed' || state == 'busy' || state == 'failed';
    final kind = video ? 'vídeo' : 'voz';
    String title;
    String? detail;
    switch (state) {
      case 'ended':
        title = 'Chamada de $kind';
        detail = chatDuration(message.mediaDurationMs ?? 0);
        break;
      case 'declined':
        title = mine ? 'Chamada recusada' : 'Você recusou a chamada';
        detail = kind[0].toUpperCase() + kind.substring(1);
        break;
      case 'failed':
        title = 'Chamada de $kind falhou';
        break;
      case 'busy':
        title = mine ? 'Ocupado' : 'Chamada de $kind perdida';
        break;
      default: // missed
        title = mine ? 'Sem resposta' : 'Chamada de $kind perdida';
        detail = mine ? kind[0].toUpperCase() + kind.substring(1) : null;
    }
    final iconColor = (bad && !mine) ? AppColors.danger : textColor;
    final icon = bad && !mine
        ? Icons.call_missed
        : (mine ? Icons.call_made : Icons.call_received);
    return Semantics(
      label: '$title${detail != null ? ', $detail' : ''}',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(video ? Icons.videocam : Icons.call, size: 22, color: iconColor),
              const SizedBox(width: 8),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(title,
                        style: TextStyle(
                            color: (bad && !mine) ? AppColors.danger : textColor,
                            fontSize: 15,
                            fontWeight: FontWeight.w600)),
                    if (detail != null)
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(icon, size: 13, color: subtle),
                          const SizedBox(width: 4),
                          Text(detail, style: TextStyle(color: subtle, fontSize: 12)),
                        ],
                      ),
                  ],
                ),
              ),
            ],
          ),
          if (onCallBack != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: InkWell(
                onTap: onCallBack,
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Text('Ligar de volta',
                      style: TextStyle(
                          color: textColor, fontSize: 13, fontWeight: FontWeight.w700)),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context, Color textColor, Color subtle) {
    if (message.deleted) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.block, size: 14, color: subtle),
          const SizedBox(width: 6),
          Text(
            'Mensagem apagada',
            style: TextStyle(color: subtle, fontStyle: FontStyle.italic, fontSize: 14),
          ),
        ],
      );
    }
    if (message.viewOnce) return _buildViewOnce(textColor, subtle);
    if ((message.type == MessageType.image || message.type == MessageType.video) &&
        (message.localPath != null || message.mediaUrl != null)) {
      return _buildImage(context, textColor);
    }
    if (message.type == MessageType.audio &&
        (message.localPath != null || message.mediaUrl != null)) {
      final caption = message.caption;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          AudioMessage(message: message, mine: message.mine, headers: mediaHeaders),
          if (caption != null && caption.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: _rich(caption, TextStyle(color: textColor, fontSize: 15)),
            ),
        ],
      );
    }
    if (message.type == MessageType.call) {
      return _buildCall(textColor, subtle);
    }
    if (message.type == MessageType.file &&
        (message.localPath != null || message.mediaUrl != null)) {
      final caption = message.caption;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          FileMessage(
            message: message,
            textColor: textColor,
            onOpen: message.localState == null ? onOpenFile : null,
            busy: fileBusy,
          ),
          if (caption != null && caption.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: _rich(caption, TextStyle(color: textColor, fontSize: 15)),
            ),
        ],
      );
    }
    if (message.isMedia) {
      final caption = message.caption;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            message.previewText.split(' ').first, // só o emoji do rótulo
            style: const TextStyle(fontSize: 28),
          ),
          if (caption != null && caption.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: _rich(caption, TextStyle(color: textColor, fontSize: 15)),
            )
          else
            Text(
              // rótulo sem o emoji (o emoji já aparece grande acima)
              message.content.contains(' ')
                  ? message.content.substring(message.content.indexOf(' ') + 1)
                  : message.content,
              style: TextStyle(color: textColor.withOpacity(0.8), fontSize: 13),
            ),
        ],
      );
    }
    return _rich(message.content, TextStyle(color: textColor, fontSize: 16, height: 1.25));
  }

  /// Texto com o termo da busca realçado (sem acento/maiúsculas).
  Widget _rich(String text, TextStyle style, {double tail = 0}) {
    final term = highlight;
    final ranges = (term == null || term.isEmpty) ? const <TextRange>[] : findSearchMatches(text, term);
    final tailSpan = tail > 0
        ? <InlineSpan>[
            WidgetSpan(alignment: PlaceholderAlignment.middle, child: SizedBox(width: tail, height: 1)),
          ]
        : const <InlineSpan>[];
    if (ranges.isEmpty) {
      if (tailSpan.isEmpty) return Text(text, style: style);
      return Text.rich(TextSpan(text: text, style: style, children: tailSpan));
    }
    final spans = <TextSpan>[];
    var last = 0;
    for (final r in ranges) {
      if (r.start > last) spans.add(TextSpan(text: text.substring(last, r.start)));
      spans.add(TextSpan(
        text: text.substring(r.start, r.end),
        style: TextStyle(
          backgroundColor: AppColors.amber.withOpacity(0.55),
          color: AppColors.onBrand,
        ),
      ));
      last = r.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
    return Text.rich(TextSpan(style: style, children: [...spans, ...tailSpan]));
  }
}
