import 'package:flutter/painting.dart';
import 'package:intl/intl.dart';

import '../../models/presence.dart';

bool sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// Rótulo do separador de data dentro da conversa.
String chatDayLabel(DateTime utc, {DateTime? now}) {
  final d = utc.toLocal();
  final today = now ?? DateTime.now();
  if (sameDay(d, today)) return 'Hoje';
  if (sameDay(d, today.subtract(const Duration(days: 1)))) return 'Ontem';
  if (d.year == today.year) return DateFormat('dd/MM').format(d);
  return DateFormat('dd/MM/yyyy').format(d);
}

/// Horário curto da caixa de entrada: hoje → hora; ontem → "Ontem"; resto → data.
String chatListTime(DateTime utc, {DateTime? now}) {
  final d = utc.toLocal();
  final today = now ?? DateTime.now();
  if (sameDay(d, today)) return DateFormat('HH:mm').format(d);
  if (sameDay(d, today.subtract(const Duration(days: 1)))) return 'Ontem';
  if (d.year == today.year) return DateFormat('dd/MM').format(d);
  return DateFormat('dd/MM/yy').format(d);
}

String chatClock(DateTime utc) => DateFormat('HH:mm').format(utc.toLocal());

/// Texto do cabeçalho da conversa (Fase 10): "online", "visto por último hoje às 14:32",
/// "…ontem às 14:32" ou "…em 03/10/2026". Escondido (por ele ou por mim) → [fallback] (o @).
String presenceLabel(DriqyPresence p, String fallback, {DateTime? now}) {
  if (!p.visible) return fallback;
  if (p.online) return 'online';
  final seen = p.lastSeenAt;
  if (seen == null) return fallback;
  final d = seen.toLocal();
  final today = now ?? DateTime.now();
  final hm = DateFormat('HH:mm').format(d);
  if (sameDay(d, today)) return 'visto por último hoje às $hm';
  if (sameDay(d, today.subtract(const Duration(days: 1)))) return 'visto por último ontem às $hm';
  return 'visto por último em ${DateFormat('dd/MM/yyyy').format(d)}';
}

bool _isEmojiRune(int r) =>
    r >= 0x1F000 || // emojis "novos" (rostos, objetos, bandeiras, símbolos)
    (r >= 0x2190 && r <= 0x21FF) ||
    (r >= 0x2300 && r <= 0x23FF) ||
    (r >= 0x2600 && r <= 0x27BF) ||
    (r >= 0x2900 && r <= 0x297F) ||
    (r >= 0x2B00 && r <= 0x2BFF) ||
    r == 0x00A9 ||
    r == 0x00AE ||
    r == 0x203C ||
    r == 0x2049 ||
    r == 0x2122 ||
    r == 0x2139 ||
    r == 0x3030 ||
    r == 0x303D ||
    r == 0x3297 ||
    r == 0x3299;

/// Quantos emojis tem o texto, SE ele for só emoji (espaços ignorados);
/// `null` se tiver qualquer outro caractere. Aproximação por code points:
/// ZWJ (👨‍👩‍👧), seletor de variação, tom de pele e par de bandeira contam como 1.
int? emojiOnlyCount(String text) {
  final t = text.trim();
  if (t.isEmpty) return null;
  var count = 0;
  var regional = 0;
  var afterZwj = false;
  for (final r in t.runes) {
    if (r == 0x20) continue;
    if (r == 0x200D) {
      afterZwj = true;
      continue;
    }
    if (r == 0xFE0F || (r >= 0x1F3FB && r <= 0x1F3FF)) continue;
    if (!_isEmojiRune(r)) return null;
    if (r >= 0x1F1E6 && r <= 0x1F1FF) {
      regional++;
      if (regional.isOdd) count++;
      afterZwj = false;
      continue;
    }
    if (afterZwj) {
      afterZwj = false;
      continue;
    }
    count++;
  }
  return count > 0 ? count : null;
}

/// Duração de áudio/vídeo: 0:07, 1:05, 12:30 (a partir de milissegundos).
String chatDuration(int ms) {
  final total = (ms / 1000).round().clamp(0, 359999).toInt();
  final m = total ~/ 60;
  final sec = total % 60;
  return '$m:${sec.toString().padLeft(2, '0')}';
}

// ---------- busca na conversa (Fase 8) ----------

const _accentFrom = 'àáâãäåāăąçćčďèéêëēĕėęěìíîïĩīĭįıñńňòóôõöøōŏőŕřśšşťùúûüũūŭůűųýÿźżž';
const _accentTo = 'aaaaaaaaacccdeeeeeeeeeiiiiiiiiinnnooooooooorrssstuuuuuuuuuuyyzzz';

/// Minúscula e sem acento, caractere a caractere (o comprimento NÃO muda, então os
/// índices do texto dobrado valem para o original). Mesma ideia do servidor.
String foldSearch(String text) {
  final out = StringBuffer();
  for (final unit in text.toLowerCase().split('')) {
    final i = _accentFrom.indexOf(unit);
    out.write(i >= 0 ? _accentTo[i] : unit);
  }
  return out.toString();
}

/// Trechos de [text] que casam com [term] (sem acento/maiúsculas), sem sobreposição.
/// Termo com menos de 2 caracteres não realça nada.
List<TextRange> findSearchMatches(String text, String term) {
  final needle = foldSearch(term.trim());
  if (needle.length < 2) return const [];
  final hay = foldSearch(text);
  if (hay.length != text.length) return const []; // seguro: índices não bateriam
  final out = <TextRange>[];
  var from = 0;
  while (true) {
    final i = hay.indexOf(needle, from);
    if (i < 0) break;
    out.add(TextRange(start: i, end: i + needle.length));
    from = i + needle.length;
  }
  return out;
}
