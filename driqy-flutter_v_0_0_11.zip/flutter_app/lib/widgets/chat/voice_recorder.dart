import 'dart:async';
import 'dart:io';

import 'package:record/record.dart';

/// Resultado de uma gravação de voz concluída.
class VoiceResult {
  final File file;
  final int durationMs;

  const VoiceResult(this.file, this.durationMs);
}

enum VoiceStart { started, denied, error }

/// Envoltório fino do pacote `record` (API 5.x): grava em AAC/m4a mono
/// (~64 kbps ≈ 0,5 MB por minuto), que o servidor aceita como `audio/mp4`.
/// Se o `pub get` resolver outra major do `record` e der erro de compilação,
/// o ajuste é só neste arquivo.
class VoiceRecorder {
  final AudioRecorder _rec = AudioRecorder();

  /// Pede permissão (se preciso) e começa a gravar num arquivo temporário.
  Future<VoiceStart> start() async {
    try {
      if (!await _rec.hasPermission()) return VoiceStart.denied;
      final path =
          '${Directory.systemTemp.path}/driqy_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _rec.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
          numChannels: 1,
        ),
        path: path,
      );
      return VoiceStart.started;
    } catch (_) {
      return VoiceStart.error;
    }
  }

  /// Nível do microfone de 0 a 1 (pra animar as barrinhas da gravação).
  Stream<double> levels() => _rec
      .onAmplitudeChanged(const Duration(milliseconds: 80))
      .map((a) => ((a.current + 50) / 50).clamp(0.0, 1.0).toDouble());

  /// Para e devolve o arquivo (null se algo falhou). A duração é medida por
  /// quem chama (relógio entre `start` e `stop`).
  Future<File?> stop() async {
    try {
      final path = await _rec.stop();
      return path == null ? null : File(path);
    } catch (_) {
      return null;
    }
  }

  /// Para e apaga o arquivo.
  Future<void> cancel() async {
    try {
      await _rec.cancel();
    } catch (_) {
      // nada a fazer: já não estava gravando
    }
  }

  Future<void> dispose() async {
    try {
      await _rec.dispose();
    } catch (_) {}
  }
}
