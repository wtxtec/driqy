import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Anel da marca Driqy, idêntico à logo original: aberto no canto
/// superior esquerdo, pontas arredondadas e gradiente vertical
/// amarelo (topo) → rosa (base).
///
/// Medidas tiradas da logo oficial (1024px): espessura ≈ 13,4% do
/// diâmetro; o arco vai de ~323° até ~287° (graus no sentido horário a
/// partir do topo), deixando o vão no canto superior esquerdo.
class DriqyRing extends StatelessWidget {
  final double size;
  final double strokeFactor;

  const DriqyRing({super.key, required this.size, this.strokeFactor = 0.134});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size.square(size),
      painter: DriqyRingPainter(strokeFactor: strokeFactor),
    );
  }
}

class DriqyRingPainter extends CustomPainter {
  final double strokeFactor;
  final Color? solidColor; // usado só se quiser uma versão monocromática

  const DriqyRingPainter({this.strokeFactor = 0.134, this.solidColor});

  static const _top = Color(0xFFFAB92D);
  static const _bottom = Color(0xFFEC4881);

  // Ângulos em graus, sentido horário a partir do topo (12h).
  static const double _startDeg = -37; // ponta de cima do vão (37° à esquerda do topo)
  static const double _endDeg = 287; // ponta de baixo do vão

  @override
  void paint(Canvas canvas, Size size) {
    final d = math.min(size.width, size.height);
    final stroke = d * strokeFactor;
    final radius = (d - stroke) / 2;
    final center = Offset(size.width / 2, size.height / 2);
    final rect = Rect.fromCircle(center: center, radius: radius);

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..isAntiAlias = true;
    if (solidColor != null) {
      paint.color = solidColor!;
    } else {
      paint.shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [_top, _bottom],
      ).createShader(Rect.fromLTWH(center.dx - d / 2, center.dy - d / 2, d, d));
    }

    // Canvas.drawArc: 0 rad = 3h (sentido horário); topo = -90°.
    final start = (_startDeg - 90) * math.pi / 180;
    final sweep = (_endDeg - _startDeg) * math.pi / 180;
    canvas.drawArc(rect, start, sweep, false, paint);
  }

  @override
  bool shouldRepaint(covariant DriqyRingPainter old) =>
      old.strokeFactor != strokeFactor || old.solidColor != solidColor;
}
