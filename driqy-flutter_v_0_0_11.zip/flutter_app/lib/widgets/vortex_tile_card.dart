import 'package:flutter/material.dart';

import '../models/picture_tile.dart';
import '../theme/vortex_theme.dart';
import 'driqy_image.dart';
import 'vortex_tile_actions.dart';

/// Medidas do Pinterest (largura/altura): pin mais alto = 1:2,1, mais largo = 16:9.
/// Fora disso a imagem é cortada (cover), nunca esticada.
const double kPinMinRatio = 0.48;
const double kPinMaxRatio = 1.78;
const double kPinRadius = 16;
const double kPinGap = 4; // de cada lado => 8 entre peças

double pinRatio(double raw) => raw.clamp(kPinMinRatio, kPinMaxRatio).toDouble();

/// Moldura de peça: cantos arredondados + respiro, como no Pinterest.
class PinFrame extends StatelessWidget {
  final double aspectRatio;
  final VoidCallback? onTap;

  /// Segurar a peça: abre Curtir / Menos disso (`reactToTile`).
  final VoidCallback? onLongPress;
  final Widget child;

  const PinFrame({
    super.key,
    required this.aspectRatio,
    required this.child,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Padding(
        padding: const EdgeInsets.all(kPinGap),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(kPinRadius),
          child: AspectRatio(aspectRatio: aspectRatio, child: child),
        ),
      ),
    );
  }
}

/// Peça do Vortex vinda do crawler, usada na grade principal, na busca e em
/// "Mais como este". Foto = miniatura; GIF = arquivo animado; vídeo = capa +
/// ícone de play (SEM autoplay: dezenas de mp4 na grade pesam demais — o vídeo
/// toca no detalhe). Mantém a proporção real, sem cortar.
class VortexTileCard extends StatefulWidget {
  final PictureTile tile;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  /// Mostra o coração de "curtido" no canto da peça.
  final bool liked;

  const VortexTileCard({
    super.key,
    required this.tile,
    required this.onTap,
    this.onLongPress,
    this.liked = false,
  });

  @override
  State<VortexTileCard> createState() => _VortexTileCardState();
}

class _VortexTileCardState extends State<VortexTileCard> {
  double? _measured;

  @override
  void initState() {
    super.initState();
    if (widget.tile.knownAspectRatio == null) _measure();
  }

  Future<void> _measure() async {
    final size = await resolveImageSize(widget.tile.gridUrl, mediaType: widget.tile.mediaType);
    if (mounted && size != null && size.height > 0) {
      setState(() => _measured = size.width / size.height);
    }
  }

  String _duration(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final tile = widget.tile;
    final raw = tile.knownAspectRatio ?? _measured ?? (4 / 5);
    // evita colunas absurdas (faixas muito altas/largas) sem cortar o conteúdo útil
    final ratio = pinRatio(raw);
    final isVideo = tile.mediaType == 'video';
    final name = tile.profile?.displayName ?? '';

    final colors = VortexColors.of(context);

    return PinFrame(
      onTap: widget.onTap,
      onLongPress: widget.onLongPress,
      aspectRatio: ratio,
      child: Stack(
          fit: StackFit.expand,
          children: [
            Container(color: colors.tileBg),
            DriqyImage(
              url: tile.gridUrl,
              mediaType: tile.mediaType,
              fit: BoxFit.cover,
              errorBuilder: (_) => Center(
                child: Icon(
                  isVideo ? Icons.videocam_outlined : Icons.broken_image_outlined,
                  color: colors.textMuted,
                ),
              ),
            ),
            if (widget.liked)
              const Positioned(left: 6, top: 6, child: IgnorePointer(child: VortexLikedBadge())),
            if (isVideo)
              Center(
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: Colors.black45, shape: BoxShape.circle),
                  child: const Icon(Icons.play_arrow, size: 26, color: Colors.white),
                ),
              ),
            if (isVideo && tile.durationSeconds != null)
              Positioned(
                top: 6,
                right: 6,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _duration(tile.durationSeconds!),
                    style: const TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ),
              ),
            if (name.isNotEmpty)
              Positioned(
                left: 6,
                right: 6,
                bottom: 6,
                child: Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    shadows: [Shadow(blurRadius: 4, color: Colors.black)],
                  ),
                ),
              ),
          ],
      ),
    );
  }
}

/// Grade em colunas (distribuição round-robin: a peça N vai sempre pra coluna
/// N % colunas, então peças já mostradas nunca trocam de coluna quando a
/// rolagem infinita acrescenta mais). Não rola sozinha: ponha dentro de um
/// scroll.
class VortexMasonry extends StatelessWidget {
  final List<PictureTile> tiles;
  final void Function(PictureTile tile) onTap;

  /// Segurar uma peça (Curtir / Menos disso). Opcional.
  final void Function(PictureTile tile)? onLongPress;

  /// Peças que não devem aparecer (as que ganharam "menos disso").
  final Set<String> hidden;

  /// Peças curtidas (ganham o coração).
  final Set<String> liked;
  final int columns;

  const VortexMasonry({
    super.key,
    required this.tiles,
    required this.onTap,
    this.onLongPress,
    this.hidden = const {},
    this.liked = const {},
    this.columns = 2,
  });

  @override
  Widget build(BuildContext context) {
    final cols = List.generate(columns, (_) => <PictureTile>[]);
    for (var i = 0; i < tiles.length; i++) {
      cols[i % columns].add(tiles[i]);
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final col in cols)
          Expanded(
            child: Column(
              children: [
                for (final t in col)
                  // escondida = some, mas continua na lista: assim as outras
                  // peças não trocam de coluna
                  if (!hidden.contains(t.key))
                    VortexTileCard(
                      key: ValueKey(t.key),
                      tile: t,
                      onTap: () => onTap(t),
                      onLongPress: onLongPress == null ? null : () => onLongPress!(t),
                      liked: liked.contains(t.key),
                    ),
              ],
            ),
          ),
      ],
    ),
    );
  }
}
