import 'dart:async';
import 'dart:collection';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../config.dart';

/// Diz se uma mídia deve ser tratada como GIF animado: pelo tipo que a API
/// informou ou pela extensão da URL (ignora a query string, então
/// `https://x.com/a.gif?w=300` também conta).
bool isGifMedia(String url, [String? mediaType]) {
  if (mediaType == 'gif') return true;
  final path = Uri.tryParse(url)?.path.toLowerCase() ?? url.toLowerCase();
  return path.endsWith('.gif');
}

/// Cache em memória dos bytes dos GIFs (LRU, ~40 MB) com deduplicação de
/// downloads simultâneos: o mesmo GIF aparece no feed, no Vortex e no
/// lightbox sem ser baixado de novo.
class GifBytesCache {
  GifBytesCache._();

  static const int _maxBytes = 40 * 1024 * 1024;
  static final LinkedHashMap<String, Uint8List> _cache = LinkedHashMap();
  static final Map<String, Future<Uint8List>> _inflight = {};
  static int _size = 0;

  /// [headers] extras (ex.: Authorization da mídia privada do chat) entram só
  /// na requisição; a chave do cache continua sendo a URL.
  static Future<Uint8List> get(String resolvedUrl, {Map<String, String>? headers}) {
    final hit = _cache.remove(resolvedUrl);
    if (hit != null) {
      _cache[resolvedUrl] = hit; // marca como o mais recente
      return Future.value(hit);
    }
    return _inflight.putIfAbsent(resolvedUrl, () async {
      try {
        final response = await http.get(
          Uri.parse(resolvedUrl),
          // Alguns hosts externos (crawler do Vortex) recusam requisições sem UA.
          headers: {
            'User-Agent': 'Mozilla/5.0 (Driqy App)',
            'Accept': 'image/gif,image/*;q=0.8,*/*;q=0.5',
            ...?headers,
          },
        );
        if (response.statusCode != 200 || response.bodyBytes.isEmpty) {
          throw Exception('HTTP ${response.statusCode}');
        }
        final bytes = response.bodyBytes;
        _cache[resolvedUrl] = bytes;
        _size += bytes.length;
        while (_size > _maxBytes && _cache.length > 1) {
          final oldest = _cache.keys.first;
          _size -= _cache.remove(oldest)!.length;
        }
        return bytes;
      } finally {
        _inflight.remove(resolvedUrl);
      }
    });
  }
}

/// Descobre largura/altura da mídia. Para GIF usa o cache de bytes (sem
/// baixar duas vezes); para o resto usa o decodificador padrão do Flutter.
Future<Size?> resolveImageSize(String url, {String? mediaType}) async {
  final resolved = resolveMediaUrl(url);
  try {
    if (isGifMedia(url, mediaType)) {
      final bytes = await GifBytesCache.get(resolved);
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      final size = Size(frame.image.width.toDouble(), frame.image.height.toDouble());
      frame.image.dispose();
      codec.dispose();
      return size;
    }
    final completer = Completer<Size?>();
    final stream = NetworkImage(resolved).resolve(const ImageConfiguration());
    late final ImageStreamListener listener;
    listener = ImageStreamListener(
      (info, _) {
        if (!completer.isCompleted) {
          completer.complete(Size(info.image.width.toDouble(), info.image.height.toDouble()));
        }
        stream.removeListener(listener);
      },
      onError: (error, stack) {
        if (!completer.isCompleted) completer.complete(null);
        stream.removeListener(listener);
      },
    );
    stream.addListener(listener);
    return completer.future;
  } catch (_) {
    return null;
  }
}

/// Imagem de rede do Driqy. GIFs passam pelo [AnimatedGif] (animação
/// controlada por nós, que não depende do ImageStream/ImageCache do
/// Flutter); o resto continua sendo um `Image.network` normal.
class DriqyImage extends StatelessWidget {
  final String url;
  final String? mediaType;
  final BoxFit fit;
  final double? width;
  final double? height;
  final WidgetBuilder? errorBuilder;
  final Map<String, String>? headers; // ex.: Bearer, pra mídia privada

  const DriqyImage({
    super.key,
    required this.url,
    this.mediaType,
    this.headers,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.errorBuilder,
  });

  Widget _error(BuildContext context) =>
      errorBuilder?.call(context) ??
      const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white54));

  @override
  Widget build(BuildContext context) {
    final resolved = resolveMediaUrl(url);
    if (isGifMedia(url, mediaType)) {
      return AnimatedGif(
        url: resolved,
        headers: headers,
        fit: fit,
        width: width,
        height: height,
        errorBuilder: _error,
      );
    }
    return Image.network(
      resolved,
      headers: headers,
      fit: fit,
      width: width,
      height: height,
      errorBuilder: (context, error, stack) => _error(context),
    );
  }
}

/// Baixa o GIF, decodifica com `dart:ui` e troca os quadros num `Timer`
/// respeitando a duração de cada quadro. Pausa sozinho quando a aba/rota
/// não está ativa (`TickerMode`) e libera tudo no `dispose`.
class AnimatedGif extends StatefulWidget {
  final String url; // já resolvida (http...)
  final BoxFit fit;
  final double? width;
  final double? height;
  final WidgetBuilder? errorBuilder;
  final Map<String, String>? headers;

  const AnimatedGif({
    super.key,
    required this.url,
    this.headers,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.errorBuilder,
  });

  @override
  State<AnimatedGif> createState() => _AnimatedGifState();
}

class _AnimatedGifState extends State<AnimatedGif> {
  ui.Codec? _codec;
  ui.Image? _frame;
  Timer? _timer;
  int _generation = 0;
  bool _failed = false;
  bool _active = true; // TickerMode
  bool _resumePending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final active = TickerMode.of(context);
    if (active != _active) {
      _active = active;
      if (_active && _resumePending) {
        _resumePending = false;
        _showNextFrame(_generation);
      }
    }
  }

  @override
  void didUpdateWidget(AnimatedGif old) {
    super.didUpdateWidget(old);
    if (old.url != widget.url) _load();
  }

  Future<void> _load() async {
    final generation = ++_generation;
    _timer?.cancel();
    _codec?.dispose();
    _codec = null;
    _failed = false;
    try {
      final bytes = await GifBytesCache.get(widget.url, headers: widget.headers);
      if (!mounted || generation != _generation) return;
      final codec = await ui.instantiateImageCodec(bytes);
      if (!mounted || generation != _generation) {
        codec.dispose();
        return;
      }
      _codec = codec;
      await _showNextFrame(generation);
    } catch (_) {
      if (mounted && generation == _generation) setState(() => _failed = true);
    }
  }

  Future<void> _showNextFrame(int generation) async {
    final codec = _codec;
    if (codec == null || !mounted || generation != _generation) return;
    try {
      final info = await codec.getNextFrame();
      if (!mounted || generation != _generation) {
        info.image.dispose();
        return;
      }
      final old = _frame;
      setState(() => _frame = info.image);
      if (old != null) {
        // só descarta o quadro anterior depois que o novo foi pintado
        WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
      }
      if (codec.frameCount > 1) {
        // navegadores tratam quadros de <=10 ms como 100 ms; fazemos igual
        var delay = info.duration;
        if (delay.inMilliseconds <= 10) delay = const Duration(milliseconds: 100);
        _timer = Timer(delay, () {
          if (!mounted || generation != _generation) return;
          if (_active) {
            _showNextFrame(generation);
          } else {
            _resumePending = true;
          }
        });
      }
    } catch (_) {
      if (mounted && generation == _generation && _frame == null) {
        setState(() => _failed = true);
      }
    }
  }

  @override
  void dispose() {
    _generation++;
    _timer?.cancel();
    _codec?.dispose();
    _frame?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) {
      // última tentativa: o decodificador padrão (mostra o 1º quadro se
      // não animar, mas pelo menos aparece alguma coisa).
      return Image.network(
        widget.url,
        headers: widget.headers,
        fit: widget.fit,
        width: widget.width,
        height: widget.height,
        errorBuilder: (context, error, stack) =>
            widget.errorBuilder?.call(context) ??
            const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white54)),
      );
    }
    final frame = _frame;
    if (frame == null) {
      return SizedBox(width: widget.width, height: widget.height);
    }
    return RawImage(
      image: frame,
      fit: widget.fit,
      width: widget.width,
      height: widget.height,
      filterQuality: FilterQuality.low,
    );
  }
}
