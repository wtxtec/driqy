import 'package:flutter/material.dart';

import '../services/rail_prefs_controller.dart';
import '../theme/app_colors.dart';
import 'rail/rail_customize.dart';

/// "Configurações" do menu lateral (tela larga). Por enquanto guarda o "Personalizar painel",
/// que antes ficava solto no menu da esquerda (no site é a mesma coisa: dentro de Configurações).
Future<void> showHomeSettingsDialog(BuildContext context, RailPrefsController controller) {
  return showDialog<void>(
    context: context,
    builder: (dialogContext) => HomeSettingsDialog(
      onCustomizePanel: () {
        // fecha as Configurações e abre o diálogo de personalização no lugar
        Navigator.of(dialogContext).pop();
        showRailCustomizeDialog(context, controller);
      },
    ),
  );
}

class HomeSettingsDialog extends StatelessWidget {
  final VoidCallback onCustomizePanel;

  const HomeSettingsDialog({super.key, required this.onCustomizePanel});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text('Configurações',
                        style: TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                  IconButton(
                    tooltip: 'Fechar',
                    icon: Icon(Icons.close, size: 20, color: AppColors.textMuted),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text('Painel direito',
                  style: TextStyle(color: AppColors.text, fontSize: 15, fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              Text(
                'Esconda o painel, tire widgets, troque a ordem e escolha onde ficam as sugestões.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerLeft,
                child: OutlinedButton(onPressed: onCustomizePanel, child: const Text('Personalizar painel')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
