import 'package:flutter/widgets.dart';

/// Largura mínima (dp) para o menu virar uma caixa fixa à esquerda (sem Drawer e sem barra
/// inferior). Mesmo corte do site: `@media (min-width: 901px)` do `style.css`.
const double kMenuBoxBreakpoint = 901;

/// Largura mínima (dp) para aparecer o painel direito (widgets + sugestões). Site: `min-width: 1200px`.
const double kRailBreakpoint = 1200;

/// Larguras das colunas (iguais às do site: 260px / conteúdo / 320px) e o respiro entre as caixas.
const double kMenuBoxWidth = 260;
const double kRailWidth = 320;
const double kBoxGap = 16;

/// Raio das caixas (`border-radius: 22px` de `.sidebar` e `.rail-card`).
const double kBoxRadius = 22;

/// Largura máxima do miolo (feed, notificações) em tela larga — `.content { max-width: 620px }` do site.
const double kContentMaxWidth = 620;

/// Aba do Feed (a Home) na `HomeShell`: o único lugar onde o painel direito existe.
const int kFeedTabIndex = 0;

/// Aba do Vortex na `HomeShell`. Como `body.pictures-page` no site, ela usa a largura toda
/// (o menu em caixa continua).
const int kVortexTabIndex = 1;

/// O menu em caixa cabe nesta largura?
bool menuBoxFits(double width) => width >= kMenuBoxBreakpoint;

/// O painel direito cabe nesta largura e a aba atual é a Home? O painel (widgets + sugestões) existe
/// SÓ na Home, como no site (`body.home-page`): nas outras abas e nas telas empilhadas ele não aparece.
bool railFits(double width, {required int tabIndex}) =>
    width >= kRailBreakpoint && tabIndex == kFeedTabIndex;

/// Avisa as telas dentro da `HomeShell` que o menu está numa caixa fixa (tela larga). Quem lê
/// (ex.: `DriqyTopBar`) esconde o botão ☰ e a marca, que já aparecem na caixa. Fora da
/// `HomeShell` (rotas empilhadas) [of] é false.
class WideShell extends InheritedWidget {
  final bool menuBox;

  const WideShell({super.key, required this.menuBox, required super.child});

  static bool of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<WideShell>()?.menuBox ?? false;

  @override
  bool updateShouldNotify(WideShell oldWidget) => oldWidget.menuBox != menuBox;
}

/// Em tela larga centraliza o miolo com no máximo [kContentMaxWidth]; a aba do Vortex (que usa a
/// largura toda) não passa por aqui. Se [enabled] for false não limita a largura.
class ContentColumn extends StatelessWidget {
  final bool enabled;
  final Widget child;

  const ContentColumn({super.key, required this.enabled, required this.child});

  @override
  Widget build(BuildContext context) {
    // A árvore tem sempre o mesmo formato (só muda o limite), para a rolagem do feed não zerar
    // quando a janela passa de larga para estreita.
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: enabled ? kContentMaxWidth : double.infinity),
        child: child,
      ),
    );
  }
}

/// Guarda a chave do `Navigator` interno do miolo (só existe em tela larga, dentro da `HomeShell`;
/// ver [InnerNavHost]). As caixas que ficam FORA dele (o menu à esquerda e o painel de widgets à
/// direita) usam [shellNavigatorOf] para abrir telas por dentro do miolo, mantendo o menu na tela.
class ShellNav extends InheritedWidget {
  final GlobalKey<NavigatorState>? navigatorKey;

  const ShellNav({super.key, required this.navigatorKey, required super.child});

  /// A chave, ou null fora da `HomeShell`.
  static GlobalKey<NavigatorState>? keyOf(BuildContext context) =>
      context.getInheritedWidgetOfExactType<ShellNav>()?.navigatorKey;

  @override
  bool updateShouldNotify(ShellNav oldWidget) => oldWidget.navigatorKey != navigatorKey;
}

/// `Navigator` onde abrir uma tela "dentro" do app: o interno do miolo quando ele existe (tela
/// larga: o menu em caixa continua visível), senão o `Navigator` normal do contexto (celular,
/// testes, qualquer tela fora da `HomeShell`). Chamado de dentro do próprio miolo devolve o mesmo
/// `Navigator` interno que `Navigator.of(context)` já devolveria.
NavigatorState shellNavigatorOf(BuildContext context) =>
    ShellNav.keyOf(context)?.currentState ?? Navigator.of(context);
