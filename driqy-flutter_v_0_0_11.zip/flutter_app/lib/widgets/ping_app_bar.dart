import 'package:flutter/material.dart';

import '../theme/ping_theme.dart';

/// Barra de Mensagens (antigo "Ping"): é um app À PARTE do Driqy (tipo Messenger), então
/// aqui NÃO tem logo, busca nem menu do Driqy — só o botão de voltar (que
/// sai do Ping de volta pro Driqy) e o nome "Mensagens".
class PingAppBar extends StatelessWidget implements PreferredSizeWidget {
  final List<Widget> actions;

  const PingAppBar({super.key, this.actions = const []});

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: PingColors.of(context).bg,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        tooltip: 'Voltar para o Driqy',
        onPressed: () => Navigator.of(context).maybePop(),
      ),
      title: const Text('Mensagens', style: TextStyle(fontWeight: FontWeight.w700)),
      actions: actions,
    );
  }
}
