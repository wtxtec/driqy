import 'package:flutter/material.dart';

import '../config.dart';
import '../models/comment.dart';
import '../theme/app_colors.dart';

/// Monta a árvore de comentários a partir da lista "achatada" que a API
/// devolve (cada item já tem `parent_id`), igual ao que o site faz em
/// `_comment_fragment.html`. Comentários cujo `parent_id` aponta pra algo
/// que não está mais na lista (ex: o pai foi apagado) viram raiz, pra não
/// sumir da tela.
class CommentNode {
  final DriqyComment comment;
  final List<CommentNode> replies;
  CommentNode(this.comment, this.replies);
}

List<CommentNode> buildCommentTree(List<DriqyComment> flat) {
  final byId = <int, CommentNode>{
    for (final c in flat) c.id: CommentNode(c, <CommentNode>[]),
  };
  final roots = <CommentNode>[];
  for (final c in flat) {
    final node = byId[c.id]!;
    final parent = c.parentId != null ? byId[c.parentId] : null;
    if (parent != null) {
      parent.replies.add(node);
    } else {
      roots.add(node);
    }
  }
  return roots;
}

/// Uma "folha" da árvore de comentários: o comentário em si + (recursivamente)
/// as respostas dele, indentadas — igual ao aninhamento do site.
class CommentTile extends StatelessWidget {
  final CommentNode node;
  final int depth;
  final void Function(DriqyComment comment)? onReply;

  const CommentTile({
    super.key,
    required this.node,
    this.depth = 0,
    this.onReply,
  });

  @override
  Widget build(BuildContext context) {
    final comment = node.comment;
    return Padding(
      padding: EdgeInsets.only(left: depth * 24.0, top: 8, bottom: 0, right: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: depth == 0 ? 16 : 13,
                backgroundImage: comment.author.avatarUrl != null
                    ? NetworkImage(resolveMediaUrl(comment.author.avatarUrl!))
                    : null,
                child: comment.author.avatarUrl == null
                    ? Text(comment.author.displayName[0].toUpperCase(), style: const TextStyle(fontSize: 12))
                    : null,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(comment.author.displayName,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        ),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text('@${comment.author.username}',
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(comment.content, style: const TextStyle(fontSize: 14)),
                    if (onReply != null) ...[
                      const SizedBox(height: 2),
                      GestureDetector(
                        onTap: () => onReply!(comment),
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 4),
                          child: Text(
                            'Responder',
                            style: TextStyle(
                              color: AppColors.textMuted,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          for (final reply in node.replies)
            CommentTile(node: reply, depth: depth + 1, onReply: onReply),
        ],
      ),
    );
  }
}
