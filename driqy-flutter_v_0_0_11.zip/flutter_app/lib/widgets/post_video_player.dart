import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

import '../config.dart';
import '../theme/app_colors.dart';

/// Player de vídeo do feed/post: toca sozinho e sem som quando está
/// visível na tela (igual autoplay de rede social / versão web), pausa ao
/// sair da tela, toque pausa/retoma e o botão de mudo liga o som. Se o
/// vídeo não carregar, mostra o motivo, "Tentar de novo" e "Abrir no
/// navegador" (útil quando o codec não é suportado pelo aparelho).
class PostVideoPlayer extends StatefulWidget {
  final String url;

  /// Toca sozinho quando ≥ 60% do vídeo está visível (padrão). Com `false`
  /// só toca quando a pessoa toca no vídeo.
  final bool autoPlay;

  const PostVideoPlayer({super.key, required this.url, this.autoPlay = true});

  @override
  State<PostVideoPlayer> createState() => _PostVideoPlayerState();
}

class _PostVideoPlayerState extends State<PostVideoPlayer> {
  VideoPlayerController? _controller;
  ScrollPosition? _scrollPosition;
  bool _muted = true;
  bool _userPaused = false; // pausa manual: o autoplay respeita
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _attachScroll();
  }

  /// Acha o scroll VERTICAL mais próximo (o PageView do carrossel é
  /// horizontal e não serve pra medir visibilidade no feed).
  void _attachScroll() {
    ScrollableState? scrollable = Scrollable.maybeOf(context);
    while (scrollable != null && scrollable.widget.axis != Axis.vertical) {
      scrollable = Scrollable.maybeOf(scrollable.context);
    }
    final position = scrollable?.position;
    if (identical(position, _scrollPosition)) return;
    _scrollPosition?.removeListener(_checkVisibility);
    _scrollPosition = position;
    _scrollPosition?.addListener(_checkVisibility);
  }

  Future<void> _init() async {
    setState(() => _error = null);
    final controller = VideoPlayerController.networkUrl(
      Uri.parse(resolveMediaUrl(widget.url)),
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    try {
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(_muted ? 0 : 1);
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() => _controller = controller);
      // espera o primeiro layout pra medir a visibilidade
      WidgetsBinding.instance.addPostFrameCallback((_) => _checkVisibility());
    } catch (e) {
      debugPrint('PostVideoPlayer: falha ao carregar ${widget.url}: $e');
      controller.dispose();
      if (mounted) setState(() => _error = e.toString());
    }
  }

  /// Fração do vídeo visível dentro do scroll vertical (0..1).
  double _visibleFraction() {
    final box = context.findRenderObject();
    if (box is! RenderBox || !box.attached || !box.hasSize) return 0;
    final scrollable = _scrollPosition?.context.storageContext.findRenderObject();
    if (scrollable is! RenderBox || !scrollable.hasSize) return 1; // sem scroll: sempre visível
    final top = box.localToGlobal(Offset.zero, ancestor: scrollable).dy;
    final height = box.size.height;
    if (height <= 0) return 0;
    final maxH = scrollable.size.height;
    final visible = (top + height).clamp(0.0, maxH) - top.clamp(0.0, maxH);
    return (visible / height).clamp(0.0, 1.0).toDouble();
  }

  void _checkVisibility() {
    final controller = _controller;
    if (controller == null || !mounted || !widget.autoPlay) return;
    final shouldPlay = _visibleFraction() >= 0.6 && !_userPaused;
    if (shouldPlay && !controller.value.isPlaying) {
      controller.play();
      setState(() {});
    } else if (!shouldPlay && controller.value.isPlaying) {
      controller.pause();
      setState(() {});
    }
  }

  void _togglePlay() {
    final controller = _controller;
    if (controller == null) return;
    setState(() {
      if (controller.value.isPlaying) {
        _userPaused = true;
        controller.pause();
      } else {
        _userPaused = false;
        controller.play();
      }
    });
  }

  void _toggleMute() {
    final controller = _controller;
    if (controller == null) return;
    setState(() {
      _muted = !_muted;
      controller.setVolume(_muted ? 0 : 1);
    });
  }

  Future<void> _openExternally() async {
    final uri = Uri.tryParse(resolveMediaUrl(widget.url));
    if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  void dispose() {
    _scrollPosition?.removeListener(_checkVisibility);
    _controller?.dispose();
    super.dispose();
  }

  Widget _placeholder({required Widget child}) => AspectRatio(
        aspectRatio: 16 / 9,
        child: Container(color: AppColors.surface2, child: Center(child: child)),
      );

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return _placeholder(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline, size: 36, color: AppColors.textMuted),
            const SizedBox(height: 6),
            Text('Não foi possível reproduzir o vídeo.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextButton(onPressed: _init, child: const Text('Tentar de novo')),
                TextButton(onPressed: _openExternally, child: const Text('Abrir no navegador')),
              ],
            ),
          ],
        ),
      );
    }
    final controller = _controller;
    if (controller == null) {
      return _placeholder(child: const CircularProgressIndicator());
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: AspectRatio(
        aspectRatio: controller.value.aspectRatio == 0 ? 16 / 9 : controller.value.aspectRatio,
        child: Stack(
          alignment: Alignment.center,
          children: [
            GestureDetector(
              onTap: _togglePlay,
              child: VideoPlayer(controller),
            ),
            if (!controller.value.isPlaying)
              const IgnorePointer(
                child: Icon(Icons.play_arrow, size: 56, color: Colors.white70),
              ),
            Positioned(
              right: 8,
              bottom: 8,
              child: InkWell(
                onTap: _toggleMute,
                child: CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.black45,
                  child: Icon(_muted ? Icons.volume_off : Icons.volume_up, size: 18, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
