import 'package:flutter/material.dart';

import 'driqy_image.dart';

/// Visualizador de imagem em tela cheia com zoom (pinça/duplo toque),
/// equivalente ao lightbox de mídia da versão web
/// (`static/js/media-lightbox.js`). Não depende de nenhum pacote extra —
/// usa só `InteractiveViewer`, que já vem com o Flutter.
class MediaLightbox extends StatefulWidget {
  final List<String> imageUrls;
  final int initialIndex;
  final Map<String, String>? headers; // mídia privada (chat): Authorization
  final List<String?>? mediaTypes; // 'gif' faz o item animar (URL do chat não tem extensão)

  const MediaLightbox({
    super.key,
    required this.imageUrls,
    this.initialIndex = 0,
    this.headers,
    this.mediaTypes,
  });

  static void open(
    BuildContext context,
    List<String> imageUrls, {
    int initialIndex = 0,
    Map<String, String>? headers,
    List<String?>? mediaTypes,
  }) {
    // raiz: o visualizador cobre a janela toda (em tela larga o miolo tem um Navigator próprio)
    Navigator.of(context, rootNavigator: true).push(
      PageRouteBuilder(
        opaque: false,
        barrierColor: Colors.black,
        pageBuilder: (context, animation, secondary) => FadeTransition(
          opacity: animation,
          child: MediaLightbox(
            imageUrls: imageUrls,
            initialIndex: initialIndex,
            headers: headers,
            mediaTypes: mediaTypes,
          ),
        ),
      ),
    );
  }

  @override
  State<MediaLightbox> createState() => _MediaLightboxState();
}

class _MediaLightboxState extends State<MediaLightbox> {
  late final PageController _controller = PageController(initialPage: widget.initialIndex);
  late int _index = widget.initialIndex;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          PageView.builder(
            controller: _controller,
            itemCount: widget.imageUrls.length,
            onPageChanged: (i) => setState(() => _index = i),
            itemBuilder: (context, index) {
              return InteractiveViewer(
                minScale: 1,
                maxScale: 4,
                child: Center(
                  child: DriqyImage(
                    url: widget.imageUrls[index],
                    mediaType: widget.mediaTypes != null && index < widget.mediaTypes!.length
                        ? widget.mediaTypes![index]
                        : null,
                    headers: widget.headers,
                    fit: BoxFit.contain,
                    errorBuilder: (context) => const Icon(
                      Icons.broken_image_outlined,
                      color: Colors.white54,
                      size: 48,
                    ),
                  ),
                ),
              );
            },
          ),
          Positioned(
            top: 16,
            right: 16,
            child: SafeArea(
              child: InkWell(
                onTap: () => Navigator.of(context).pop(),
                borderRadius: BorderRadius.circular(20),
                child: const CircleAvatar(
                  radius: 18,
                  backgroundColor: Colors.black45,
                  child: Icon(Icons.close, color: Colors.white),
                ),
              ),
            ),
          ),
          if (widget.imageUrls.length > 1)
            Positioned(
              bottom: 24,
              left: 0,
              right: 0,
              child: Center(
                child: Text(
                  '${_index + 1} / ${widget.imageUrls.length}',
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
