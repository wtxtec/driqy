import 'package:flutter/material.dart';

import '../config.dart';
import '../models/user.dart';
import '../theme/app_colors.dart';

class UserTile extends StatelessWidget {
  final DriqyUser user;
  final VoidCallback? onTap;
  final VoidCallback? onFollowTap;
  final bool followLoading;

  const UserTile({
    super.key,
    required this.user,
    this.onTap,
    this.onFollowTap,
    this.followLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: CircleAvatar(
        radius: 22,
        backgroundImage:
            user.avatarUrl != null ? NetworkImage(resolveMediaUrl(user.avatarUrl!)) : null,
        child: user.avatarUrl == null ? Text(user.displayName[0].toUpperCase()) : null,
      ),
      title: Row(
        children: [
          Flexible(
            child: Text(user.displayName,
                style: const TextStyle(fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis),
          ),
          if (user.badgeKind != null) ...[
            const SizedBox(width: 4),
            Icon(Icons.verified, size: 15, color: AppColors.badgeColor(user.badgeKind)),
          ],
        ],
      ),
      subtitle: Text('@${user.username}', style: TextStyle(color: AppColors.textMuted)),
      trailing: user.isMe || onFollowTap == null
          ? null
          : OutlinedButton(
              onPressed: followLoading ? null : onFollowTap,
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(0, 32),
                padding: const EdgeInsets.symmetric(horizontal: 12),
                foregroundColor: user.isFollowing ? AppColors.textMuted : AppColors.amber,
                side: BorderSide(color: user.isFollowing ? AppColors.border : AppColors.amber),
              ),
              child: followLoading
                  ? const SizedBox(
                      height: 14,
                      width: 14,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Text(user.isFollowing ? 'Seguindo' : 'Seguir'),
            ),
    );
  }
}
