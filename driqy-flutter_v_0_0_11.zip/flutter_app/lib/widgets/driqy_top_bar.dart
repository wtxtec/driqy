import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../screens/messages_inbox_screen.dart';
import '../screens/notifications_screen.dart';
import '../screens/search_screen.dart';
import '../services/auth_service.dart';
import '../services/chat_live.dart';
import '../services/message_service.dart';
import '../services/notification_service.dart';
import '../services/push_notification_service.dart';
import '../theme/app_colors.dart';
import '../theme/vortex_theme.dart';
import 'brand_title.dart';
import 'wide_layout.dart';

/// AppBar completa do Feed, espelhando o `.topbar` da versão web
/// (`templates/base.html`): botão de menu, marca, caixa de busca
/// ("Buscar no Driqy") e os ícones de mensagens/notificações com o
/// mesmo badge vermelho de contagem (`.notif-badge`).
///
/// Em tela larga (dentro da `HomeShell` com o menu em caixa fixa, ver [WideShell]) o botão ☰ e a
/// marca somem daqui: já aparecem na caixa do menu, igual ao `.topbar > .brand` do site.
///
/// A caixa de busca é somente-toque (não digita aqui, igual a maioria
/// dos apps mobile): tocar nela abre a `SearchScreen`, que já tem o
/// campo de texto de verdade.
class DriqyTopBar extends StatefulWidget implements PreferredSizeWidget {
  final VoidCallback? onOpenMenu;

  const DriqyTopBar({super.key, this.onOpenMenu});

  @override
  State<DriqyTopBar> createState() => _DriqyTopBarState();

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}

class _DriqyTopBarState extends State<DriqyTopBar> {
  Timer? _pollTimer;
  StreamSubscription<ChatEvent>? _liveSub;
  int _unreadMessages = 0;
  int _unreadNotifications = 0;

  @override
  void initState() {
    super.initState();
    _refreshBadges();
    // Fase 9: nova mensagem / leitura em outro aparelho atualiza o selo na hora
    final client = context.read<AuthService>().client;
    ChatLive.instance.acquire(client);
    _liveSub = ChatLive.instance.events.listen((e) {
      if (e.type == 'message' || e.type == 'read_self' || e.type == 'ready' || e.type == 'resync') {
        _refreshBadges();
      }
    });
    // Igual ao site (que reconsulta o sino/envelope periodicamente):
    // reconsulta a cada 30s enquanto a topbar estiver visível.
    _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _refreshBadges());
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _liveSub?.cancel();
    ChatLive.instance.release();
    super.dispose();
  }

  Future<void> _refreshBadges() async {
    final client = context.read<AuthService>().client;
    try {
      final results = await Future.wait([
        MessageService(client).getUnreadCount(),
        NotificationService(client).getUnreadCount(),
      ]);
      // Toca o som (mensagem x outras) se algum contador subiu. O serviço é
      // um singleton, então várias topbars abertas ao mesmo tempo não
      // duplicam o som.
      PushNotificationService.instance
          .onUnreadCounts(messages: results[0], activity: results[1]);
      if (!mounted) return;
      setState(() {
        _unreadMessages = results[0];
        _unreadNotifications = results[1];
      });
    } catch (_) {
      // silencioso: os badges só deixam de atualizar, sem quebrar a topbar
    }
  }

  void _openSearch() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen()));
  }

  Future<void> _openMessages() async {
    // raiz: o Ping é um app à parte, em tela cheia (não cabe na coluna do miolo)
    await Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(builder: (_) => const MessagesInboxScreen()),
    );
    _refreshBadges();
  }

  Future<void> _openNotifications() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NotificationsScreen()),
    );
    _refreshBadges();
  }

  @override
  Widget build(BuildContext context) {
    final wide = WideShell.of(context);
    final showMenu = widget.onOpenMenu != null && !wide;
    return AppBar(
      titleSpacing: showMenu ? 0 : 16,
      leading: showMenu
          ? IconButton(
              icon: const Icon(Icons.menu),
              tooltip: 'Abrir menu',
              onPressed: widget.onOpenMenu,
            )
          : null,
      title: Row(
        children: [
          if (!wide) ...[
            const BrandTitle(fontSize: 19),
            const SizedBox(width: 10),
          ],
          Expanded(child: _SearchPill(onTap: _openSearch)),
        ],
      ),
      actions: [
        _TopBarIconButton(
          icon: Icons.chat_bubble_outline,
          tooltip: 'Mensagens',
          unreadCount: _unreadMessages,
          onTap: _openMessages,
        ),
        _TopBarIconButton(
          icon: Icons.notifications_outlined,
          tooltip: 'Notificações',
          unreadCount: _unreadNotifications,
          onTap: _openNotifications,
        ),
        const SizedBox(width: 4),
      ],
    );
  }
}

/// Caixa de busca somente-toque, igual à `.topbar-search` do site
/// (pílula com ícone de lupa + placeholder "Buscar no Driqy").
class _SearchPill extends StatelessWidget {
  final VoidCallback onTap;

  const _SearchPill({required this.onTap});

  @override
  Widget build(BuildContext context) {
    // No tema escuro (o do app todo) as cores são as mesmas de antes; dentro do
    // Vortex em tema claro a caixa também clareia.
    final colors = VortexColors.of(context);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        height: 36,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: colors.searchBg,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: colors.border),
        ),
        child: Row(
          children: [
            Icon(Icons.search, size: 17, color: colors.textMuted),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Buscar no Driqy',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: colors.textMuted, fontSize: 13.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Ícone de ação da topbar (mensagens/sino) com o mesmo badge circular
/// vermelho de contagem do `.notif-badge` do site.
class _TopBarIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final int unreadCount;
  final VoidCallback onTap;

  const _TopBarIconButton({
    required this.icon,
    required this.tooltip,
    required this.unreadCount,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        IconButton(
          icon: Icon(icon),
          tooltip: tooltip,
          onPressed: onTap,
        ),
        if (unreadCount > 0)
          Positioned(
            top: 6,
            right: 6,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
              constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
              decoration: BoxDecoration(
                color: AppColors.danger,
                borderRadius: BorderRadius.circular(999),
              ),
              alignment: Alignment.center,
              child: Text(
                unreadCount > 99 ? '99+' : '$unreadCount',
                style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700),
                textAlign: TextAlign.center,
              ),
            ),
          ),
      ],
    );
  }
}
