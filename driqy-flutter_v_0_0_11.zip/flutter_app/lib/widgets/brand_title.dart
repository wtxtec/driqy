import 'package:flutter/material.dart';

import 'driqy_ring.dart';
import '../theme/app_theme.dart';

/// Pequeno anel da marca (idêntico à logo original, aberto no canto
/// superior esquerdo), estático, igual ao `.brand-ring` do topbar do site.
class BrandRing extends StatelessWidget {
  final double size;

  const BrandRing({super.key, this.size = 20});

  @override
  Widget build(BuildContext context) => DriqyRing(size: size, strokeFactor: 0.18);
}

/// Marca completa usada no título das AppBars: anel giratório + "driqy"
/// em Baloo 2, como o `.brand` do site.
class BrandTitle extends StatelessWidget {
  final double fontSize;

  const BrandTitle({super.key, this.fontSize = 22});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        BrandRing(size: fontSize * 0.9),
        const SizedBox(width: 8),
        Text('driqy', style: AppTheme.brandWordmark(fontSize: fontSize)),
      ],
    );
  }
}
