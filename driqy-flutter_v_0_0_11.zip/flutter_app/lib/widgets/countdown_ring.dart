import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Formata segundos restantes num rótulo curto pro selo do anel
/// ("6d", "3h", "45m", "12s"), igual à função `formatRemaining` de
/// `static/js/countdown.js` na versão web.
String formatRemaining(num totalSeconds) {
  if (totalSeconds <= 0) return '0s';
  final seconds = totalSeconds.floor();
  final days = seconds ~/ 86400;
  final hours = (seconds % 86400) ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;
  final secs = seconds % 60;

  if (days > 0) return '${days}d';
  if (hours > 0) return '${hours}h';
  if (minutes > 0) return '${minutes}m';
  return '${secs}s';
}

/// Rótulo completo pro rodapé do post ("Expira em 3 dias"), igual à
/// função `formatRemainingFull` da versão web.
String formatRemainingFull(num totalSeconds) {
  if (totalSeconds <= 0) return 'Expirado';
  final seconds = totalSeconds.floor();
  final days = seconds ~/ 86400;
  final hours = (seconds % 86400) ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;

  if (days > 0) return 'Expira em $days dia${days != 1 ? 's' : ''}';
  if (hours > 0) return 'Expira em $hours hora${hours != 1 ? 's' : ''}';
  if (minutes > 0) return 'Expira em $minutes minuto${minutes != 1 ? 's' : ''}';
  return 'Expira em instantes';
}

/// Tempo decorrido desde a publicação ("há 5 min"), igual à função
/// `formatElapsed` da versão web usada no cabeçalho do post.
String formatElapsed(Duration elapsed) {
  final seconds = elapsed.inSeconds < 0 ? 0 : elapsed.inSeconds;
  if (seconds < 45) return 'agora';
  final minutes = seconds ~/ 60;
  if (minutes < 60) return 'há $minutes min';
  final hours = minutes ~/ 60;
  if (hours < 24) return 'há ${hours}h';
  final days = hours ~/ 24;
  if (days < 7) return 'há ${days}d';
  final weeks = days ~/ 7;
  return 'há $weeks sem';
}

/// Anel de contagem regressiva animado que mostra quanto tempo falta
/// pro post expirar — espelha o `.countdown-ring-wrap` da versão web
/// (`static/js/countdown.js` + estilos em `style.css`), incluindo o
/// estado "urgente" quando resta 10% ou menos do tempo total.
class CountdownRing extends StatefulWidget {
  final DateTime createdAt;
  final DateTime expiresAt;
  final double size;

  /// Chamado uma única vez quando o post expira, pra quem estiver
  /// exibindo a lista poder remover o card (com uma animação de saída),
  /// igual ao comportamento da versão web.
  final VoidCallback? onExpired;

  const CountdownRing({
    super.key,
    required this.createdAt,
    required this.expiresAt,
    this.size = 40,
    this.onExpired,
  });

  @override
  State<CountdownRing> createState() => _CountdownRingState();
}

class _CountdownRingState extends State<CountdownRing> {
  Timer? _timer;
  double _remainingSeconds = 0;
  double _totalSeconds = 1;
  bool _expiredNotified = false;

  @override
  void initState() {
    super.initState();
    _tick();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  @override
  void didUpdateWidget(covariant CountdownRing oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.createdAt != widget.createdAt || oldWidget.expiresAt != widget.expiresAt) {
      _expiredNotified = false;
      _tick();
    }
  }

  void _tick() {
    final total = widget.expiresAt.difference(widget.createdAt).inMilliseconds / 1000;
    final remaining = widget.expiresAt.difference(DateTime.now()).inMilliseconds / 1000;
    if (!mounted) return;
    setState(() {
      _totalSeconds = total <= 0 ? 1 : total;
      _remainingSeconds = remaining < 0 ? 0 : remaining;
    });
    if (_remainingSeconds <= 0 && !_expiredNotified) {
      _expiredNotified = true;
      widget.onExpired?.call();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fraction = (_remainingSeconds / _totalSeconds).clamp(0.0, 1.0);
    final urgent = fraction <= 0.1 && _remainingSeconds > 0;
    return Tooltip(
      message: 'Tempo restante até o post expirar',
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              size: Size(widget.size, widget.size),
              painter: _CountdownRingPainter(fraction: fraction, urgent: urgent),
            ),
            Text(
              formatRemaining(_remainingSeconds),
              style: TextStyle(
                fontSize: widget.size * 0.24,
                fontWeight: FontWeight.w600,
                color: urgent ? AppColors.danger : AppColors.text,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CountdownRingPainter extends CustomPainter {
  final double fraction;
  final bool urgent;

  _CountdownRingPainter({required this.fraction, required this.urgent});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (math.min(size.width, size.height) / 2) - 3;
    const strokeWidth = 3.0;

    final bgPaint = Paint()
      ..color = AppColors.border
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;
    canvas.drawCircle(center, radius, bgPaint);

    if (fraction <= 0) return;

    final rect = Rect.fromCircle(center: center, radius: radius);
    final fgPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    if (urgent) {
      fgPaint.color = AppColors.danger;
    } else {
      fgPaint.shader = SweepGradient(
        colors: [AppColors.amber, AppColors.rose],
      ).createShader(rect);
    }

    const startAngle = -math.pi / 2;
    final sweepAngle = 2 * math.pi * fraction;
    canvas.drawArc(rect, startAngle, sweepAngle, false, fgPaint);
  }

  @override
  bool shouldRepaint(covariant _CountdownRingPainter oldDelegate) {
    return oldDelegate.fraction != fraction || oldDelegate.urgent != urgent;
  }
}
