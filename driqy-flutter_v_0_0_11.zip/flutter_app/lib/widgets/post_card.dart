import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../config.dart';
import '../models/post.dart';
import '../theme/app_colors.dart';
import '../theme/app_spacing.dart';
import 'countdown_ring.dart';
import 'driqy_image.dart';
import 'flash_ring.dart';
import 'media_lightbox.dart';
import 'post_audio_player.dart';
import 'post_video_player.dart';

/// Card de post que espelha o `_post_card.html` da versão web: cabeçalho
/// com avatar/nome/@usuario/tempo decorrido, anel de contagem regressiva
/// animado, mídia (com carrossel quando há mais de um item), ações
/// (curtir/comentar/visualizações/compartilhar) e o rodapé com "Expira em"
/// + "Publicado em".
class PostCard extends StatefulWidget {
  final DriqyPost post;
  final VoidCallback onLikeTap;
  final VoidCallback? onTap;
  final VoidCallback? onAuthorTap;

  /// Toque no botão de comentários. Os comentários NÃO aparecem mais
  /// dentro do card: o botão abre a página do post (mesmo destino do
  /// toque no card). Na própria página do post, quem usa o card passa
  /// aqui uma função que só foca o campo de comentário.
  final VoidCallback? onCommentsTap;

  /// Chamado quando o post expira (o anel chega a zero), pra quem estiver
  /// exibindo a lista poder remover o card — igual ao post sumindo
  /// sozinho do feed na versão web.
  final VoidCallback? onExpired;

  /// Exclusão pelo autor (post permanente ou temporário). Quem usa o card
  /// faz a chamada à API e remove o card da lista. Se for nulo, o menu
  /// "Excluir" não aparece.
  final Future<void> Function()? onDelete;

  const PostCard({
    super.key,
    required this.post,
    required this.onLikeTap,
    this.onTap,
    this.onAuthorTap,
    this.onCommentsTap,
    this.onExpired,
    this.onDelete,
  });

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  bool _expiring = false;

  void _handleExpired() {
    if (_expiring) return;
    setState(() => _expiring = true);
    Future.delayed(const Duration(milliseconds: 550), () {
      if (mounted) widget.onExpired?.call();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: _expiring ? 0 : 1,
      duration: const Duration(milliseconds: 500),
      child: AnimatedSize(
        duration: const Duration(milliseconds: 500),
        child: _expiring
            ? const SizedBox.shrink()
            : Container(
                margin: const EdgeInsets.fromLTRB(AppSpacing.gap, 0, AppSpacing.gap, AppSpacing.gap),
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  // IMPORTANTE: essa borda tem que ficar uniforme (mesma cor/
                  // largura nos 4 lados). O Flutter só desenha a borda
                  // arredondada corretamente quando os 4 lados de um `Border`
                  // são idênticos — com um lado diferente (cor/largura), ele
                  // ignora silenciosamente o `borderRadius` em build de
                  // release e desenha um retângulo reto por cima do fundo
                  // arredondado, deixando o card com "cara quadrada". Por
                  // isso a faixa de cor do autor vira uma camada separada
                  // logo abaixo, e não um lado diferente deste `Border`.
                  border: Border.all(color: AppColors.border),
                ),
                child: Stack(
                  children: [
                    Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: widget.onTap,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildHeader(),
                              if (widget.post.textContent.isNotEmpty) ...[
                                const SizedBox(height: 8),
                                Text(widget.post.textContent,
                                    style: TextStyle(fontSize: 15, color: AppColors.text)),
                              ],
                              if (widget.post.media.isNotEmpty) ...[
                                const SizedBox(height: 8),
                                _PostMedia(media: widget.post.media),
                              ],
                              const SizedBox(height: 10),
                              _buildActions(),
                              const SizedBox(height: 8),
                              _buildFooterMeta(),
                            ],
                          ),
                        ),
                      ),
                    ),
                    // Espelha `border-left: 3px solid var(--author-color, var(--border))`
                    // do `.post-card` no site: a cor de destaque escolhida pelo
                    // autor no perfil aparece como uma faixa na borda esquerda
                    // do card, por cima do 1px cinza. O próprio `clipBehavior`
                    // do `Container` acima já corta essa faixa nas pontas
                    // arredondadas, então ela acompanha a curva sem precisar
                    // de nada a mais aqui.
                    Positioned(
                      left: 0,
                      top: 0,
                      bottom: 0,
                      child: Container(
                        width: 3,
                        color: AppColors.accentFromKey(widget.post.author.accentColor),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  String _sourceClientLabel(String key) {
    switch (key) {
      case 'android':
        return 'Android';
      case 'iphone':
      case 'ios':
        return 'iPhone';
      default:
        return key;
    }
  }

  Widget _buildHeader() {
    final post = widget.post;
    final avatarUrl = post.author.avatarUrl;
    final elapsed = _ElapsedLabel(createdAt: post.createdAt);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          // tocar no avatar leva direto ao perfil da pessoa (com ou sem Flash ativo)
          onTap: widget.onAuthorTap,
          borderRadius: BorderRadius.circular(24),
          child: FlashRing(
            hasFlash: post.author.hasFlash,
            unseen: post.author.flashUnseen,
            child: CircleAvatar(
              radius: 18,
              backgroundColor: AppColors.surface2,
              backgroundImage: avatarUrl != null ? NetworkImage(resolveMediaUrl(avatarUrl)) : null,
              child: avatarUrl == null
                  ? Text(post.author.displayName[0].toUpperCase())
                  : null,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: InkWell(
            onTap: widget.onAuthorTap,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        post.author.displayName,
                        style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.text),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (post.author.badgeKind != null) ...[
                      const SizedBox(width: 4),
                      Icon(Icons.verified, size: 15, color: AppColors.badgeColor(post.author.badgeKind)),
                    ],
                  ],
                ),
                Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text('@${post.author.username}',
                        style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                    Text(' · ', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                    elapsed,
                    if (post.sourceClient != null && post.sourceClient != 'web') ...[
                      Text(' · ', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                      Text(
                        'Post via ${_sourceClientLabel(post.sourceClient!)}',
                        style: TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 8),
        if (post.expiresAt != null)
          CountdownRing(
            createdAt: post.createdAt,
            expiresAt: post.expiresAt!,
            onExpired: _handleExpired,
          ),
        if (post.author.isMe && widget.onDelete != null) _buildOwnerMenu(),
      ],
    );
  }

  Widget _buildOwnerMenu() {
    return PopupMenuButton<String>(
      tooltip: 'Mais opções',
      padding: EdgeInsets.zero,
      iconSize: 20,
      icon: Icon(Icons.more_horiz, color: AppColors.textMuted),
      color: AppColors.surface2,
      onSelected: (value) {
        if (value == 'delete') _confirmDelete();
      },
      itemBuilder: (_) => [
        PopupMenuItem<String>(
          value: 'delete',
          child: Text('Excluir post', style: TextStyle(color: AppColors.rose)),
        ),
      ],
    );
  }

  Future<void> _confirmDelete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Excluir post?'),
        content: const Text('Essa ação não pode ser desfeita.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('Excluir', style: TextStyle(color: AppColors.rose)),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      await widget.onDelete!();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Não foi possível excluir o post agora.')));
    }
  }

  Widget _buildActions() {
    final post = widget.post;
    return Row(
      children: [
        InkWell(
          onTap: widget.onLikeTap,
          child: Row(
            children: [
              Icon(
                post.likedByMe ? Icons.favorite : Icons.favorite_border,
                size: 20,
                color: post.likedByMe ? AppColors.rose : AppColors.textMuted,
              ),
              const SizedBox(width: 4),
              Text('${post.likesCount}', style: TextStyle(color: AppColors.textMuted)),
            ],
          ),
        ),
        const SizedBox(width: 20),
        InkWell(
          onTap: widget.onCommentsTap ?? widget.onTap,
          child: Row(
            children: [
              Icon(
                Icons.mode_comment_outlined,
                size: 20,
                color: AppColors.textMuted,
              ),
              const SizedBox(width: 4),
              Text('${post.commentsCount}', style: TextStyle(color: AppColors.textMuted)),
            ],
          ),
        ),
        const SizedBox(width: 20),
        Icon(Icons.visibility_outlined, size: 20, color: AppColors.textMuted),
        const SizedBox(width: 4),
        Text('${post.viewsCount}', style: TextStyle(color: AppColors.textMuted)),
        const Spacer(),
        const SizedBox(width: 12),
        _ShareButton(postId: post.id),
      ],
    );
  }

  Widget _buildFooterMeta() {
    final post = widget.post;
    return _FooterMeta(createdAt: post.createdAt, expiresAt: post.expiresAt);
  }
}

/// Rótulo de tempo decorrido ("há 5 min") que se atualiza sozinho, igual
/// ao `.post-elapsed` da versão web (atualizado a cada 30s no JS).
class _ElapsedLabel extends StatefulWidget {
  final DateTime createdAt;

  const _ElapsedLabel({required this.createdAt});

  @override
  State<_ElapsedLabel> createState() => _ElapsedLabelState();
}

class _ElapsedLabelState extends State<_ElapsedLabel> {
  @override
  void initState() {
    super.initState();
    _scheduleTick();
  }

  void _scheduleTick() {
    Future.delayed(const Duration(seconds: 30), () {
      if (!mounted) return;
      setState(() {});
      _scheduleTick();
    });
  }

  @override
  Widget build(BuildContext context) {
    final elapsed = DateTime.now().difference(widget.createdAt);
    return Text(
      formatElapsed(elapsed),
      style: TextStyle(color: AppColors.textMuted, fontSize: 12.5),
    );
  }
}

/// Rodapé com "Expira em X dias" (atualiza a cada minuto) e a data/hora
/// de publicação, igual ao `.post-footer-meta` da versão web.
class _FooterMeta extends StatefulWidget {
  final DateTime createdAt;
  final DateTime? expiresAt; // null = post permanente (sem linha "Expira em")

  const _FooterMeta({required this.createdAt, required this.expiresAt});

  @override
  State<_FooterMeta> createState() => _FooterMetaState();
}

class _FooterMetaState extends State<_FooterMeta> {
  @override
  void initState() {
    super.initState();
    _scheduleTick();
  }

  void _scheduleTick() {
    Future.delayed(const Duration(seconds: 60), () {
      if (!mounted) return;
      setState(() {});
      _scheduleTick();
    });
  }

  static const _months = [
    'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
    'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez',
  ];

  String _publishedLabel(DateTime createdAt) {
    final local = createdAt.toLocal();
    final day = local.day.toString();
    final month = _months[local.month - 1];
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return 'Publicado em $day de $month de ${local.year} às $hour:$minute';
  }

  @override
  Widget build(BuildContext context) {
    final expiresAt = widget.expiresAt;
    final publishedLabel = _publishedLabel(widget.createdAt);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (expiresAt != null) ...[
          Row(
            children: [
              Icon(Icons.schedule, size: 14, color: AppColors.textMuted),
              const SizedBox(width: 4),
              Text(
                formatRemainingFull(expiresAt.difference(DateTime.now()).inSeconds),
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 2),
        ],
        Text(publishedLabel, style: TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
      ],
    );
  }
}

/// Botão de "Compartilhar" que copia o link do post pra área de
/// transferência (a versão Flutter não tem o plugin de share nativo, então
/// segue o mesmo fallback usado pelo navegador na versão web).
class _ShareButton extends StatefulWidget {
  final int postId;

  const _ShareButton({required this.postId});

  @override
  State<_ShareButton> createState() => _ShareButtonState();
}

class _ShareButtonState extends State<_ShareButton> {
  bool _copied = false;

  Future<void> _copyLink() async {
    final url = '$kApiBaseUrl/post/${widget.postId}';
    await Clipboard.setData(ClipboardData(text: url));
    if (!mounted) return;
    setState(() => _copied = true);
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: _copyLink,
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: Row(
          children: [
            Icon(
              _copied ? Icons.check : Icons.share_outlined,
              size: 18,
              color: _copied ? AppColors.green : AppColors.textMuted,
            ),
            if (_copied) ...[
              const SizedBox(width: 4),
              const Text('Link copiado!',
                  style: TextStyle(color: AppColors.green, fontSize: 12, fontWeight: FontWeight.w600)),
            ],
          ],
        ),
      ),
    );
  }
}

/// Caixa fixa que a mídia deve ocupar, espelhando as 3 "molduras" do CSS
/// (`.post-media img` / `.video-wrap` em `style.css`) calculadas a partir
/// da proporção REAL do arquivo — igual ao `static/js/media-orient.js`:
///   - paisagem (largura/altura > 1.15): caixa 3:2, sem limite de largura;
///   - retrato OU quadrada (as demais): caixa 4:5, com largura máxima de
///     420 (a versão web usa a mesma caixa pras duas, ver comentário no
///     `style.css` original).
class _MediaBox {
  final double aspectRatio;
  final double? maxWidth;

  const _MediaBox({required this.aspectRatio, this.maxWidth});

  static const portraitOrSquare = _MediaBox(aspectRatio: 4 / 5, maxWidth: 420);
  static const landscape = _MediaBox(aspectRatio: 3 / 2, maxWidth: null);

  static _MediaBox classify(double width, double height) {
    if (height <= 0) return portraitOrSquare;
    final ratio = width / height;
    if (ratio > 1.15) return landscape;
    return portraitOrSquare;
  }
}

/// Uma única foto do post: mede a proporção real antes de decidir a
/// caixa (paisagem x retrato/quadrada), aplicando `BoxFit.cover` pra
/// preencher a caixa inteira sem tarja cinza — igual ao `.post-media img`
/// do site.
class _PostImage extends StatefulWidget {
  final String url;
  final VoidCallback onTap;
  final String? mediaType;

  const _PostImage({required this.url, required this.onTap, this.mediaType});

  @override
  State<_PostImage> createState() => _PostImageState();
}

class _PostImageState extends State<_PostImage> {
  _MediaBox _box = _MediaBox.portraitOrSquare;

  @override
  void initState() {
    super.initState();
    _measure();
  }

  Future<void> _measure() async {
    final size = await resolveImageSize(widget.url, mediaType: widget.mediaType);
    if (mounted && size != null) {
      setState(() => _box = _MediaBox.classify(size.width, size.height));
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Align(
        alignment: Alignment.centerLeft,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: _box.maxWidth ?? double.infinity),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
              aspectRatio: _box.aspectRatio,
              child: DriqyImage(
                url: widget.url,
                mediaType: widget.mediaType,
                fit: BoxFit.cover,
                width: double.infinity,
                errorBuilder: (context) => Container(
                  color: AppColors.surface2,
                  child: Icon(Icons.broken_image_outlined, color: AppColors.textMuted),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Mídia do post: uma única imagem/vídeo/áudio ocupa o espaço todo; mais
/// de um item vira um carrossel com bolinhas e contador, igual ao
/// `.post-carousel` da versão web. A caixa do carrossel usa a proporção
/// do primeiro item pra decidir a moldura (paisagem x retrato/quadrada),
/// igual ao `media-orient.js`, pra todos os slides terem a mesma altura.
class _PostMedia extends StatefulWidget {
  final List<PostMedia> media;

  const _PostMedia({required this.media});

  @override
  State<_PostMedia> createState() => _PostMediaState();
}

class _PostMediaState extends State<_PostMedia> {
  late final PageController _controller = PageController();
  int _index = 0;
  _MediaBox _carouselBox = _MediaBox.portraitOrSquare;

  @override
  void initState() {
    super.initState();
    if (widget.media.length > 1) _measureCarouselBox();
  }

  Future<void> _measureCarouselBox() async {
    final first = widget.media.first;
    if (first.mediaType == 'video' || first.mediaType == 'audio') return;
    final size = await resolveImageSize(first.url, mediaType: first.mediaType);
    if (mounted && size != null) {
      setState(() => _carouselBox = _MediaBox.classify(size.width, size.height));
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  List<String> get _imageUrls => widget.media
      .where((x) => x.mediaType != 'video' && x.mediaType != 'audio')
      .map((x) => x.url)
      .toList();

  Widget _buildItem(PostMedia m, {bool inCarousel = false}) {
    switch (m.mediaType) {
      case 'video':
        return PostVideoPlayer(url: m.url);
      case 'audio':
        return PostAudioPlayer(url: m.url);
      default:
        final imageUrls = _imageUrls;
        final tapIndex = imageUrls.indexOf(m.url);
        final onTap = () => MediaLightbox.open(
              context,
              imageUrls,
              initialIndex: tapIndex < 0 ? 0 : tapIndex,
            );
        if (!inCarousel) return _PostImage(url: m.url, mediaType: m.mediaType, onTap: onTap);
        // Dentro do carrossel todos os slides compartilham a mesma caixa
        // (calculada a partir do primeiro item), então aqui é só um
        // Image.network normal preenchendo a caixa já dimensionada pelo pai.
        return GestureDetector(
          onTap: onTap,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: DriqyImage(
              url: m.url,
              mediaType: m.mediaType,
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
              errorBuilder: (context) => Container(
                color: AppColors.surface2,
                child: Icon(Icons.broken_image_outlined, color: AppColors.textMuted),
              ),
            ),
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.media.length == 1) {
      return _buildItem(widget.media.first);
    }

    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: _carouselBox.maxWidth ?? double.infinity),
            child: AspectRatio(
              aspectRatio: _carouselBox.aspectRatio,
              child: PageView.builder(
                controller: _controller,
                itemCount: widget.media.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (context, i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: _buildItem(widget.media[i], inCarousel: true),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: 8,
          right: 8,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text('${_index + 1} / ${widget.media.length}',
                style: const TextStyle(color: Colors.white, fontSize: 11)),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(widget.media.length, (i) {
              final active = i == _index;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 2),
                width: active ? 8 : 6,
                height: active ? 8 : 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: active ? AppColors.amber : Colors.white54,
                ),
              );
            }),
          ),
        ),
      ],
    );
  }
}



