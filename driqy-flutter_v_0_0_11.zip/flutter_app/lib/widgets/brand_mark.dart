import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import 'driqy_ring.dart';

/// "login-mark" do site: anel da marca (fixo, igual à logo original) com
/// brilho pulsante atrás e flutuação suave (sem girar). Usado em login e cadastro.
class AnimatedBrandMark extends StatefulWidget {
  final double size;

  const AnimatedBrandMark({super.key, this.size = 180});

  @override
  State<AnimatedBrandMark> createState() => _AnimatedBrandMarkState();
}

class _AnimatedBrandMarkState extends State<AnimatedBrandMark> with SingleTickerProviderStateMixin {
  // Ciclo de 12s: flutuação (6s) e brilho (4s) fecham sem salto. O anel não gira.
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final t = _c.value * 12; // segundos
        final floatDy = -14 * (0.5 - 0.5 * math.cos(2 * math.pi * t / 6));
        final glow = 0.5 - 0.5 * math.cos(2 * math.pi * t / 4);
        return Transform.translate(
          offset: Offset(0, floatDy * (s / 220)),
          child: SizedBox(
            width: s,
            height: s,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Opacity(
                  opacity: 0.55 + 0.45 * glow,
                  child: Transform.scale(
                    scale: 1 + 0.08 * glow,
                    child: Container(
                      width: s * 0.76,
                      height: s * 0.76,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [AppColors.amber.withValues(alpha: 0.16), Colors.transparent],
                          stops: const [0, 0.7],
                        ),
                      ),
                    ),
                  ),
                ),
                DriqyRing(size: s), // anel estático na posição correta (só flutua)
              ],
            ),
          ),
        );
      },
    );
  }
}
