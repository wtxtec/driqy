import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import '../wide_layout.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../models/rail_extra.dart';
import '../../screens/post_detail_screen.dart';
import '../../services/widgets_service.dart';
import '../../theme/app_colors.dart';
import 'rail_common.dart';

/// Os 8 widgets do painel que vêm do servidor (clock, calendar, moon, seasons, quotes, stats, expiring,
/// phrase). Mesmos títulos, textos e regras do `rail-new.js` do site.

String _pad(int n) => n < 10 ? '0$n' : '$n';

/// "2026-11-05" -> "05/11".
String shortDate(String iso) {
  final p = iso.split('-');
  return p.length == 3 ? '${p[2]}/${p[1]}' : iso;
}

/// 1234567 -> "1.234.567" (separador de milhar do pt-BR).
String formatInt(int n) {
  final s = n.abs().toString();
  final b = StringBuffer(n < 0 ? '-' : '');
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('.');
    b.write(s[i]);
  }
  return b.toString();
}

/// 5432.1 -> "R$ 5.432,10".
String formatBrl(double v) {
  final parts = v.abs().toStringAsFixed(2).split('.');
  final ip = parts[0];
  final b = StringBuffer();
  for (var i = 0; i < ip.length; i++) {
    if (i > 0 && (ip.length - i) % 3 == 0) b.write('.');
    b.write(ip[i]);
  }
  return '${v < 0 ? '-' : ''}R\$ $b,${parts[1]}';
}

TextStyle _muted([double size = 12]) => TextStyle(color: AppColors.textMuted, fontSize: size);

Widget _link(String label, VoidCallback onTap, {Key? key}) => TextButton(
      key: key,
      onPressed: onTap,
      style: TextButton.styleFrom(
        foregroundColor: AppColors.textMuted,
        minimumSize: Size.zero,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        textStyle: const TextStyle(fontSize: 12.5),
      ),
      child: Text(label),
    );

// ----------------------------------------------------------------------------- Relógio mundial

/// Chave onde as cidades escolhidas ficam salvas (a mesma do site: `driqy-rail-clock-zones`).
const String kClockZonesKey = 'driqy-rail-clock-zones';
/// País dos feriados do calendário (mesma chave do site; cada aparelho guarda a sua).
const String kCalendarCountryKey = 'driqy.cal.country';

class RailClockWidget extends StatefulWidget {
  final WidgetsService service;

  /// Relógio do aparelho (para teste).
  final DateTime Function()? now;

  const RailClockWidget({super.key, required this.service, this.now});

  @override
  State<RailClockWidget> createState() => _RailClockWidgetState();
}

class _RailClockWidgetState extends State<RailClockWidget> {
  ClockResult? _data;
  bool _loading = true;
  bool _failed = false;
  bool _picking = false;
  List<String> _zones = const [];
  late DateTime _fetchedAt;
  Timer? _timer;
  int _req = 0;

  DateTime _now() => (widget.now ?? DateTime.now)();

  @override
  void initState() {
    super.initState();
    _fetchedAt = _now();
    _load();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final mine = ++_req;
    setState(() {
      _loading = true;
      _failed = false;
    });
    try {
      try {
        _zones = (await SharedPreferences.getInstance()).getStringList(kClockZonesKey) ?? const [];
      } catch (_) {
        _zones = const [];
      }
      final d = await widget.service.getClock(zones: _zones);
      if (!mounted || mine != _req) return;
      _fetchedAt = _now();
      setState(() {
        _data = d;
        _loading = false;
      });
      _timer?.cancel();
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        // a cada ~30 min busca de novo (horário de verão)
        if (_now().difference(_fetchedAt) > const Duration(minutes: 30)) {
          _load();
        } else {
          setState(() {});
        }
      });
    } catch (_) {
      if (!mounted || mine != _req) return;
      setState(() {
        _failed = true;
        _loading = false;
      });
    }
  }

  Future<void> _toggleZone(String id, bool on) async {
    final cur = [..._zones.isEmpty ? [for (final c in _data!.cities) c.id] : _zones];
    if (on && !cur.contains(id)) cur.add(id);
    if (!on) cur.remove(id);
    if (cur.isEmpty || cur.length > 6) return; // no mínimo 1, no máximo 6
    setState(() => _zones = cur);
    try {
      await (await SharedPreferences.getInstance()).setStringList(kClockZonesKey, cur);
    } catch (_) {}
  }

  String _hms(DateTime base) {
    final t = base.add(_now().difference(_fetchedAt));
    return '${_pad(t.hour)}:${_pad(t.minute)}:${_pad(t.second)}';
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _data == null) return const RailMessage(text: 'Carregando…');
    if (_failed) return RailMessage(text: 'Não consegui carregar agora.', actionLabel: 'Tentar de novo', onAction: _load);
    final d = _data;
    if (d == null || !d.ok) {
      return RailMessage(text: 'Relógio indisponível agora.', actionLabel: 'Tentar de novo', onAction: _load);
    }
    final sel = _zones.isEmpty ? [for (final c in d.cities) c.id] : _zones;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final c in d.cities)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              key: Key('clock-row-${c.id}'),
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w700)),
                      Text(
                        c.utcLabel + (c.dayOffset == 1 ? ' · amanhã' : c.dayOffset == -1 ? ' · ontem' : ''),
                        style: _muted(11.5),
                      ),
                    ],
                  ),
                ),
                Text(_hms(c.local),
                    key: Key('clock-time-${c.id}'),
                    style: TextStyle(
                      color: AppColors.text,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    )),
              ],
            ),
          ),
        Align(
          alignment: Alignment.centerRight,
          child: _link(_picking ? 'Fechar' : 'Cidades', () {
            final closing = _picking;
            setState(() => _picking = !_picking);
            if (closing) _load();
          }, key: const Key('clock-toggle')),
        ),
        if (_picking) ...[
          for (final z in d.available)
            InkWell(
              key: Key('clock-zone-${z.id}'),
              onTap: () => _toggleZone(z.id, !sel.contains(z.id)),
              child: Row(
                children: [
                  SizedBox(
                    width: 34,
                    height: 30,
                    child: Checkbox(
                      value: sel.contains(z.id),
                      visualDensity: VisualDensity.compact,
                      activeColor: AppColors.amber,
                      onChanged: (v) => _toggleZone(z.id, v ?? false),
                    ),
                  ),
                  Expanded(child: Text(z.name, style: TextStyle(color: AppColors.text, fontSize: 13.5))),
                ],
              ),
            ),
          Text('Até 6 cidades. Toque em Fechar para atualizar.', style: _muted()),
        ],
      ],
    );
  }
}

// ------------------------------------------------------------------------------- Calendário

class RailCalendarWidget extends StatefulWidget {
  final WidgetsService service;

  const RailCalendarWidget({super.key, required this.service});

  @override
  State<RailCalendarWidget> createState() => _RailCalendarWidgetState();
}

class _RailCalendarWidgetState extends State<RailCalendarWidget> {
  int? _y;
  int? _m;
  String _country = ''; // vazio = automático
  bool _prefsLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadCountry();
  }

  Future<void> _loadCountry() async {
    var c = '';
    try {
      c = (await SharedPreferences.getInstance()).getString(kCalendarCountryKey) ?? '';
    } catch (_) {
      c = '';
    }
    if (!mounted) return;
    setState(() {
      _country = RegExp(r'^[A-Za-z]{2}$').hasMatch(c) ? c.toUpperCase() : '';
      _prefsLoaded = true;
    });
  }

  Future<void> _pickCountry(String code) async {
    setState(() => _country = code);
    try {
      final p = await SharedPreferences.getInstance();
      if (code.isEmpty) {
        await p.remove(kCalendarCountryKey);
      } else {
        await p.setString(kCalendarCountryKey, code);
      }
    } catch (_) {
      // sem armazenamento: vale só agora
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_prefsLoaded) return const Center(child: Padding(padding: EdgeInsets.all(12), child: Text('Carregando…')));
    // a chave por mês/país refaz a busca ao navegar (e volta ao mês de hoje com "Hoje")
    return KeyedSubtree(
      key: ValueKey('cal-$_y-$_m-$_country'),
      child: RailLoader<CalendarMonth>(
        load: () => widget.service.getCalendar(year: _y, month: _m, country: _country),
        builder: (context, d) => _CalendarView(
          data: d,
          country: _country,
          onCountry: _pickCountry,
          onGo: (delta) {
            var mm = d.month + delta;
            var yy = d.year;
            if (mm < 1) {
              mm = 12;
              yy--;
            }
            if (mm > 12) {
              mm = 1;
              yy++;
            }
            setState(() {
              _y = yy;
              _m = mm;
            });
          },
          onToday: () => setState(() {
            _y = null;
            _m = null;
          }),
        ),
      ),
    );
  }
}

class _CalendarView extends StatelessWidget {
  final CalendarMonth data;
  final void Function(int delta) onGo;
  final VoidCallback onToday;
  final String country; // escolha atual (vazio = automático)
  final void Function(String code) onCountry;

  const _CalendarView({
    required this.data,
    required this.onGo,
    required this.onToday,
    this.country = '',
    required this.onCountry,
  });

  @override
  Widget build(BuildContext context) {
    final d = data;
    final hol = {for (final h in d.holidays) h.day: h};
    final cells = <Widget>[
      for (var i = 0; i < d.blanks; i++) const SizedBox(height: 30),
      for (var day = 1; day <= d.daysInMonth; day++) _cell(day, hol[day], day == d.todayDay),
    ];
    while (cells.length % 7 != 0) {
      cells.add(const SizedBox(height: 30));
    }
    final title = d.monthName.isEmpty ? '${d.month}' : d.monthName[0].toUpperCase() + d.monthName.substring(1);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            IconButton(
              key: const Key('cal-prev'),
              icon: const Icon(Icons.chevron_left, size: 20),
              tooltip: 'Mês anterior',
              color: AppColors.textMuted,
              visualDensity: VisualDensity.compact,
              onPressed: () => onGo(-1),
            ),
            Expanded(
              child: Text('$title ${d.year}',
                  key: const Key('cal-title'),
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w700)),
            ),
            IconButton(
              key: const Key('cal-next'),
              icon: const Icon(Icons.chevron_right, size: 20),
              tooltip: 'Próximo mês',
              color: AppColors.textMuted,
              visualDensity: VisualDensity.compact,
              onPressed: () => onGo(1),
            ),
          ],
        ),
        Row(
          children: [
            for (final w in d.gridWeekdays)
              Expanded(child: Center(child: Text(w, style: _muted(11.5)))),
          ],
        ),
        for (var r = 0; r < cells.length; r += 7)
          Row(children: [for (var c = r; c < r + 7; c++) Expanded(child: cells[c])]),
        if (d.holidays.isNotEmpty) ...[
          const SizedBox(height: 8),
          for (final h in d.holidays)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.5),
              child: Text(
                '${_pad(h.day)} · ${h.name}${h.kind == 'facultativo' ? ' (facultativo)' : ''}',
                style: TextStyle(color: AppColors.text, fontSize: 12.5),
              ),
            ),
        ],
        if (d.countries.isNotEmpty) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              Text('Feriados: ', style: _muted(12)),
              Expanded(
                child: DropdownButton<String>(
                  key: const Key('cal-country'),
                  isExpanded: true,
                  isDense: true,
                  value: country.isNotEmpty && d.countries.any((c) => c.code == country) ? country : '',
                  style: TextStyle(color: AppColors.text, fontSize: 12.5),
                  items: [
                    DropdownMenuItem(value: '', child: Text('Automático (${d.countryName})')),
                    for (final c in d.countries) DropdownMenuItem(value: c.code, child: Text(c.name)),
                  ],
                  onChanged: (v) {
                    if (v != null) onCountry(v);
                  },
                ),
              ),
            ],
          ),
        ],
        if (!d.isCurrent) Align(alignment: Alignment.centerRight, child: _link('Hoje', onToday, key: const Key('cal-today'))),
      ],
    );
  }

  Widget _cell(int day, CalHoliday? h, bool today) {
    final isHoliday = h != null && h.kind == 'feriado';
    final soft = h != null && !isHoliday;
    final color = today
        ? AppColors.onBrand
        : isHoliday
            ? AppColors.rose
            : soft
                ? AppColors.amber
                : AppColors.text;
    final cell = Container(
      key: Key('cal-day-$day'),
      height: 30,
      alignment: Alignment.center,
      decoration: today ? BoxDecoration(color: AppColors.amber, shape: BoxShape.circle) : null,
      child: Text('$day',
          style: TextStyle(
            color: color,
            fontSize: 12.5,
            fontWeight: today || h != null ? FontWeight.w700 : FontWeight.w500,
          )),
    );
    return h == null ? cell : Tooltip(message: h.name, child: cell);
  }
}

// --------------------------------------------------------------------------------- Fase da Lua

/// Barra de progresso do painel (0..100), igual à `.wx-bar` do site.
class RailProgressBar extends StatelessWidget {
  final double value;
  final double height;
  final bool muted; // estação que já passou: cinza em vez do degradê

  const RailProgressBar({super.key, required this.value, this.height = 8, this.muted = false});

  @override
  Widget build(BuildContext context) {
    final v = value.clamp(0, 100).toDouble();
    return Semantics(
      label: 'Progresso',
      value: '${v.round()}%',
      child: Container(
        height: height,
        decoration: BoxDecoration(
          color: AppColors.surface2,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: AppColors.border),
        ),
        clipBehavior: Clip.antiAlias,
        child: Align(
          alignment: Alignment.centerLeft,
          child: FractionallySizedBox(
            widthFactor: v / 100,
            heightFactor: 1,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(999),
                color: muted ? AppColors.textMuted.withValues(alpha: 0.55) : null,
                gradient: muted ? null : LinearGradient(colors: [AppColors.amber, AppColors.rose]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// 49.5 -> "49,5"; 100.0 -> "100".
String _fmtPct(double v) => v == v.roundToDouble() ? '${v.round()}' : v.toStringAsFixed(1).replaceAll('.', ',');

// --------------------------------------------------------------------------------- Fase da Lua

class RailMoonWidget extends StatelessWidget {
  final WidgetsService service;

  const RailMoonWidget({super.key, required this.service});

  static String when(int n) => n <= 0 ? 'hoje' : n == 1 ? 'amanhã' : 'em $n dias';

  @override
  Widget build(BuildContext context) {
    return RailLoader<MoonInfo>(
      load: service.getMoon,
      builder: (context, d) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(child: Text(d.emoji, style: const TextStyle(fontSize: 48))),
          Center(
            child: Text(d.phase,
                key: const Key('moon-phase'),
                style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.w700)),
          ),
          Center(
            child: Text('${d.illumination}% iluminada · ${d.ageDays.toString().replaceAll('.', ',')} dias', style: _muted(12.5)),
          ),
          if (d.trend.isNotEmpty)
            Center(child: Text('${d.waxing ? '↗' : '↘'} ${d.trend}', key: const Key('moon-trend'), style: _muted(12))),
          if (d.cyclePct != null) ...[
            const SizedBox(height: 10),
            RailProgressBar(key: const Key('moon-cycle-bar'), value: d.cyclePct!),
            const SizedBox(height: 3),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('🌑 nova', style: _muted(11)),
                Text('${d.cyclePct!.round()}% de ${_fmtPct(d.cycleDays)} dias', style: _muted(11)),
                Text('nova 🌑', style: _muted(11)),
              ],
            ),
          ],
          if (d.distanceKm > 0) ...[
            const SizedBox(height: 8),
            Text('📏 Distância: ${formatInt(d.distanceKm)} km · ${d.distanceLabel}',
                key: const Key('moon-distance'), style: _muted(12.5)),
          ],
          if (d.riseSet != null) ..._riseSetRows(d.riseSet!, d.tzLabel),
          const SizedBox(height: 8),
          if (d.events.isNotEmpty) ...[
            for (var i = 0; i < d.events.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${d.events[i].emoji} ${d.events[i].name}',
                        style: TextStyle(
                            color: AppColors.text, fontSize: 12.5, fontWeight: i == 0 ? FontWeight.w700 : FontWeight.w400)),
                    Text('${shortDate(d.events[i].date)} · ${when(d.events[i].days)}', style: _muted(12)),
                  ],
                ),
              ),
          ] else ...[
            // servidor antigo: só cheia e nova
            Text('🌕 Próxima cheia: ${shortDate(d.nextFull)} (${when(d.daysToFull)})',
                style: TextStyle(color: AppColors.text, fontSize: 12.5)),
            const SizedBox(height: 2),
            Text('🌑 Próxima nova: ${shortDate(d.nextNew)} (${when(d.daysToNew)})',
                style: TextStyle(color: AppColors.text, fontSize: 12.5)),
          ],
          if (d.eclipses.isNotEmpty) ..._eclipseRows(d.eclipses, d.tzLabel),
        ],
      ),
    );
  }

  /// Nascer e pôr da Lua de hoje (no fuso do aparelho; [tzLabel] diz qual) + se está no céu agora.
  static List<Widget> _riseSetRows(MoonRiseSet r, String tzLabel) => [
        const SizedBox(height: 10),
        Row(
          key: const Key('moon-rise-set'),
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('🌙↑ Nasce ${r.rise.isEmpty ? '—' : r.rise}',
                key: const Key('moon-rise'), style: TextStyle(color: AppColors.text, fontSize: 12.5)),
            Text('Se põe ${r.set.isEmpty ? '—' : r.set} ↓',
                key: const Key('moon-set'), style: TextStyle(color: AppColors.text, fontSize: 12.5)),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          '${r.upNow ? 'No céu agora' : 'Abaixo do horizonte'}'
          '${r.nextLabel.isEmpty ? '' : ' · ${r.nextLabel.toLowerCase()} ${r.nextToday ? 'hoje' : 'amanhã'} às ${r.nextTime}'}'
          ' · ${r.approximate ? 'Brasília (defina sua cidade no perfil)' : r.place} · ${tzWords(tzLabel)}',
          key: const Key('moon-rise-note'),
          style: _muted(11),
        ),
      ];

  /// Próximos eclipses, o mais perto em destaque.
  static List<Widget> _eclipseRows(List<EclipseInfo> list, String tzLabel) => [
        const SizedBox(height: 10),
        Text('Próximos eclipses · ${tzWords(tzLabel)}', key: const Key('moon-eclipses-title'), style: TextStyle(color: AppColors.text, fontSize: 12.5, fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        for (var i = 0; i < list.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                      child: Text('${list[i].emoji} ${list[i].name}',
                          style: TextStyle(
                              color: AppColors.text, fontSize: 12.5, fontWeight: i == 0 ? FontWeight.w700 : FontWeight.w400)),
                    ),
                    Text('${shortDate(list[i].date)} · ${when(list[i].days)}', style: _muted(12)),
                  ],
                ),
                Text(
                  'máximo às ${list[i].time}'
                  '${list[i].visibleHere == true ? ' · visível daqui' : list[i].visibleHere == false ? ' · não visível daqui' : ''}',
                  style: _muted(11),
                ),
              ],
            ),
          ),
      ];
}

// ------------------------------------------------------------------------------------- Estações

/// Estação atual com barra de progresso, o ano em 4 faixas (cheia = passou, parcial = atual) e o aviso
/// de virada quando faltam 3 dias ou menos. Mesmos textos do `renderSeasons` do site.
class RailSeasonsWidget extends StatelessWidget {
  final WidgetsService service;

  const RailSeasonsWidget({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return RailLoader<SeasonInfo>(
      load: service.getSeasons,
      builder: (context, d) {
        final c = d.current;
        final left = c.daysLeft == 0 ? 'vira hoje' : c.daysLeft == 1 ? 'falta 1 dia' : 'faltam ${c.daysLeft} dias';
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Text(c.emoji, style: const TextStyle(fontSize: 38)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(c.name,
                          key: const Key('season-name'),
                          style: TextStyle(color: AppColors.text, fontSize: 17, fontWeight: FontWeight.w700)),
                      Text('Dia ${c.dayNumber} de ${c.days} · $left', key: const Key('season-days'), style: _muted(12.5)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            RailProgressBar(key: const Key('season-bar'), value: c.progress),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(shortDate(c.start), style: _muted(12)),
                Text('${_fmtPct(c.progress)}%', key: const Key('season-pct'), style: _muted(12)),
                Text(shortDate(c.end), style: _muted(12)),
              ],
            ),
            if (d.alert != null) ...[
              const SizedBox(height: 10),
              Container(
                key: const Key('season-alert'),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.surface2,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.amber),
                ),
                child: Text('${d.next.emoji} ${d.alert}', style: TextStyle(color: AppColors.text, fontSize: 12.5)),
              ),
            ],
            if (d.cycle.isNotEmpty) ...[
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (var i = 0; i < d.cycle.length; i++) ...[
                    if (i > 0) const SizedBox(width: 4),
                    Expanded(
                      child: Tooltip(
                        message: '${d.cycle[i].name} · ${shortDate(d.cycle[i].start)} a ${shortDate(d.cycle[i].end)}',
                        child: Column(
                          children: [
                            RailProgressBar(
                              key: Key('season-seg-${d.cycle[i].key}'),
                              value: d.cycle[i].progress,
                              height: 7,
                              muted: d.cycle[i].status == 'past',
                            ),
                            const SizedBox(height: 4),
                            Text('${d.cycle[i].emoji} ${d.cycle[i].name}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: d.cycle[i].status == 'current' ? AppColors.text : AppColors.textMuted,
                                  fontSize: 10.5,
                                  fontWeight: d.cycle[i].status == 'current' ? FontWeight.w700 : FontWeight.w400,
                                )),
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
            const SizedBox(height: 8),
            Text(
              'Próxima: ${d.next.emoji} ${d.next.name} em ${shortDate(d.next.start)} às ${d.next.startTime} '
              '(${d.next.event})${d.tzLabel.isEmpty || d.tzLabel == 'Brasília' ? '' : ' · ${d.tzLabel}'} · ano ${_fmtPct(d.yearProgress)}%',
              style: _muted(12),
            ),
          ],
        );
      },
    );
  }
}

// ------------------------------------------------------------------------------------ Cotações

class RailQuotesWidget extends StatefulWidget {
  final WidgetsService service;

  /// De quanto em quanto tempo atualiza sozinho (padrão 5 min, como o site).
  final Duration refresh;

  const RailQuotesWidget({super.key, required this.service, this.refresh = const Duration(minutes: 5)});

  @override
  State<RailQuotesWidget> createState() => _RailQuotesWidgetState();
}

class _RailQuotesWidgetState extends State<RailQuotesWidget> {
  QuotesResult? _r;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(widget.refresh, (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent && _r != null) setState(() => _r = null);
    final r = await widget.service.getQuotes();
    if (!mounted) return;
    // uma atualização automática que falha não troca o que está bom por mensagem de erro
    if (r.ok || _r == null || !_r!.ok) setState(() => _r = r);
  }

  @override
  Widget build(BuildContext context) {
    final r = _r;
    if (r == null) return const RailMessage(text: 'Carregando…');
    if (!r.ok) {
      final off = r.reason == 'disabled';
      return RailMessage(
        text: off ? 'Cotações desligadas pelo administrador.' : 'Cotações indisponíveis agora.',
        actionLabel: off ? null : 'Tentar de novo',
        onAction: off ? null : _load,
      );
    }
    final t = r.updatedAt;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final q in r.items)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              key: Key('quote-${q.code}'),
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(q.name, style: TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w700)),
                      if (q.high != null && q.low != null)
                        Text('mín ${formatBrl(q.low!)} · máx ${formatBrl(q.high!)}', style: _muted(11)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(formatBrl(q.value), style: TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w700)),
                    Text(
                      '${q.changePct > 0 ? '▲ ' : q.changePct < 0 ? '▼ ' : ''}${q.changePct.abs().toStringAsFixed(2).replaceAll('.', ',')}%',
                      key: Key('quote-change-${q.code}'),
                      style: TextStyle(
                        fontSize: 12,
                        color: q.changePct > 0
                            ? AppColors.green
                            : q.changePct < 0
                                ? AppColors.danger
                                : AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        Text(
          '${t == null ? '' : 'Atualizado às ${_pad(t.hour)}:${_pad(t.minute)}'}${r.stale ? ' (dados antigos: sem conexão com a fonte)' : ''}',
          key: const Key('quotes-footer'),
          style: _muted(),
        ),
      ],
    );
  }
}

// -------------------------------------------------------------------------------- Seu Driqy

class RailStatsWidget extends StatelessWidget {
  final WidgetsService service;

  const RailStatsWidget({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return RailLoader<StatsInfo>(
      load: service.getStats,
      builder: (context, d) {
        final tiles = <MapEntry<String, int>>[
          MapEntry('Seguidores', d.followers),
          MapEntry('Seguindo', d.following),
          MapEntry('Posts no ar', d.postsLive),
          MapEntry('Visualizações', d.views),
          MapEntry('Curtidas', d.likes),
          MapEntry('Comentários', d.comments),
        ];
        Widget tile(MapEntry<String, int> e) => Expanded(
              child: Container(
                key: Key('stat-${e.key}'),
                margin: const EdgeInsets.all(3),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(12)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(formatInt(e.value), style: TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w800)),
                    Text(e.key, maxLines: 1, overflow: TextOverflow.ellipsis, style: _muted(11.5)),
                  ],
                ),
              ),
            );
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var i = 0; i < tiles.length; i += 2) Row(children: [tile(tiles[i]), tile(tiles[i + 1])]),
            if (d.newFollowers7d > 0)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  '+${formatInt(d.newFollowers7d)}${d.newFollowers7d == 1 ? ' novo seguidor' : ' novos seguidores'} nos últimos 7 dias',
                  key: const Key('stats-new'),
                  style: _muted(12.5),
                ),
              ),
          ],
        );
      },
    );
  }
}

// ------------------------------------------------------------------------------------ Acabando

/// 59 -> "menos de 1 min", 3600 -> "1 h 00 min", 125 -> "2 min".
String timeLeft(int sec) {
  if (sec < 60) return 'menos de 1 min';
  final m = sec ~/ 60;
  final h = m ~/ 60;
  return h > 0 ? '$h h ${_pad(m % 60)} min' : '$m min';
}

class RailExpiringWidget extends StatelessWidget {
  final WidgetsService service;

  /// Abre o post (para teste, troca a navegação).
  final void Function(BuildContext context, int postId)? onOpen;

  const RailExpiringWidget({super.key, required this.service, this.onOpen});

  @override
  Widget build(BuildContext context) {
    return RailLoader<List<ExpiringPost>>(
      load: service.getExpiring,
      builder: (context, posts) {
        if (posts.isEmpty) return const RailMessage(text: 'Nenhum post temporário some nas próximas 48 h.');
        return _ExpiringList(
          posts: posts,
          onOpen: (id) => onOpen != null
              ? onOpen!(context, id)
              : shellNavigatorOf(context).push(MaterialPageRoute<void>(builder: (_) => PostDetailScreen(postId: id))),
        );
      },
    );
  }
}

class _ExpiringList extends StatefulWidget {
  final List<ExpiringPost> posts;
  final void Function(int id) onOpen;

  const _ExpiringList({required this.posts, required this.onOpen});

  @override
  State<_ExpiringList> createState() => _ExpiringListState();
}

class _ExpiringListState extends State<_ExpiringList> {
  final DateTime _t0 = DateTime.now();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    // a contagem anda sozinha, sem buscar de novo
    _timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dt = DateTime.now().difference(_t0).inSeconds;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final p in widget.posts)
          InkWell(
            key: Key('expiring-${p.id}'),
            borderRadius: BorderRadius.circular(12),
            onTap: () => widget.onOpen(p.id),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RailAvatar(username: p.author.username, avatarUrl: p.author.avatarUrl, size: 30),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.mine ? 'Você' : '@${p.author.username}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: AppColors.text, fontSize: 13.5, fontWeight: FontWeight.w700)),
                        if (p.snippet.isNotEmpty)
                          Text(p.snippet,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: AppColors.text, fontSize: 13, height: 1.25)),
                        Text(
                          '⏳ ${p.secondsLeft - dt <= 0 ? 'acabou' : 'some em ${timeLeft(p.secondsLeft - dt)}'}',
                          key: Key('expiring-left-${p.id}'),
                          style: TextStyle(color: AppColors.amber, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// --------------------------------------------------------------------------------- Frase do dia

class RailPhraseWidget extends StatelessWidget {
  final WidgetsService service;

  const RailPhraseWidget({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return RailLoader<PhraseInfo>(
      load: service.getPhrase,
      builder: (context, d) => Container(
        padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
        decoration: BoxDecoration(border: Border(left: BorderSide(color: AppColors.amber, width: 3))),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('“${d.text}”',
                key: const Key('phrase-text'),
                style: TextStyle(color: AppColors.text, fontSize: 15, height: 1.35, fontStyle: FontStyle.italic)),
            if (d.author != null) ...[
              const SizedBox(height: 6),
              Text('— ${d.author}', style: _muted(12.5)),
            ],
          ],
        ),
      ),
    );
  }
}
