import 'package:flutter/material.dart';

import '../../models/rail_widgets.dart';
import '../../services/rail_prefs_controller.dart';
import '../../theme/app_colors.dart';

/// Nomes dos widgets na tela de personalização (mesmos do site).
const Map<String, String> kRailWidgetNames = {
  'weather': 'O clima hoje',
  'trending': 'Em alta',
  'news': 'Notícias',
  'vortex': 'Vortex',
  'online': 'Quem está online',
  'clock': 'Relógio mundial',
  'calendar': 'Calendário',
  'moon': 'Fase da Lua',
  'seasons': 'Estações',
  'quotes': 'Cotações',
  'stats': 'Seu Driqy',
  'expiring': 'Acabando',
  'phrase': 'Frase do dia',
  'pomodoro': 'Foco',
  'calc': 'Calculadora',
  'breathe': 'Respirar',
};

/// "Personalizar painel": mostrar/esconder o painel direito, tirar widgets, arrastar para trocar a
/// ordem e escolher se (e onde) fica o cartão de sugestões. Salva no servidor, como no site.
Future<void> showRailCustomizeDialog(BuildContext context, RailPrefsController controller) {
  return showDialog<void>(
    context: context,
    builder: (_) => _RailCustomizeDialog(controller: controller),
  );
}

class _RailCustomizeDialog extends StatefulWidget {
  final RailPrefsController controller;

  const _RailCustomizeDialog({required this.controller});

  @override
  State<_RailCustomizeDialog> createState() => _RailCustomizeDialogState();
}

class _RailCustomizeDialogState extends State<_RailCustomizeDialog> {
  late RailPrefs _p = widget.controller.prefs;
  bool _saving = false;
  String? _error;

  Future<void> _save() async {
    setState(() {
      _saving = true;
      _error = null;
    });
    final ok = await widget.controller.save(_p);
    if (!mounted) return;
    if (ok) {
      Navigator.of(context).pop();
    } else {
      setState(() {
        _saving = false;
        _error = 'Não foi possível salvar agora. Tente de novo.';
      });
    }
  }

  void _toggle(String id, bool on) {
    final d = [..._p.disabled]..remove(id);
    if (!on) d.add(id);
    setState(() => _p = _p.copyWith(disabled: d));
  }

  /// Widgets próprios ("Minha área", `custom:N`): id -> título.
  Map<String, String> get _customTitles => {for (final w in widget.controller.customs) w.id: w.title};

  /// Só o que o app sabe desenhar: os widgets prontos e os próprios do usuário (o servidor pode ter
  /// ids que esta versão ainda não mostra; esses ficam guardados na ordem, sem aparecer aqui).
  bool _known(String id) => kRailWidgetNames.containsKey(id) || _customTitles.containsKey(id);

  List<String> get _shown => [for (final id in _p.order) if (_known(id)) id];

  String _nameOf(String id) => kRailWidgetNames[id] ?? _customTitles[id] ?? id;

  void _reorder(int oldIndex, int newIndex) {
    final list = [..._shown];
    if (newIndex > oldIndex) newIndex -= 1;
    list.insert(newIndex, list.removeAt(oldIndex));
    final foreign = [for (final id in _p.order) if (!_known(id)) id];
    setState(() => _p = _p.copyWith(order: [...list, ...foreign]));
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420, maxHeight: 620),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Personalizar painel',
                  style: TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Mostrar o painel da direita'),
                value: !_p.railHidden,
                onChanged: (v) => setState(() => _p = _p.copyWith(railHidden: !v)),
              ),
              if (_p.railHidden)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    'O painel fica escondido. Para voltar, use “Personalizar painel” em Configurações.',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                  ),
                )
              else
                Flexible(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const SizedBox(height: 8),
                        Text('Widgets (arraste para mudar a ordem)',
                            style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                        ReorderableListView(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          buildDefaultDragHandles: false,
                          onReorder: _reorder,
                          children: [
                            for (var i = 0; i < _shown.length; i++)
                              CheckboxListTile(
                                key: ValueKey(_shown[i]),
                                contentPadding: EdgeInsets.zero,
                                controlAffinity: ListTileControlAffinity.leading,
                                title: Row(
                                  children: [
                                    Flexible(child: Text(_nameOf(_shown[i]), overflow: TextOverflow.ellipsis)),
                                    if (_customTitles.containsKey(_shown[i]))
                                      Container(
                                        key: Key('cz-own-${_shown[i]}'),
                                        margin: const EdgeInsets.only(left: 6),
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                        decoration: BoxDecoration(
                                          border: Border.all(color: AppColors.amber),
                                          borderRadius: BorderRadius.circular(999),
                                        ),
                                        child: Text('seu',
                                            style: TextStyle(
                                                color: AppColors.amber, fontSize: 10.5, fontWeight: FontWeight.w600)),
                                      ),
                                  ],
                                ),
                                value: !_p.disabled.contains(_shown[i]),
                                onChanged: (v) => _toggle(_shown[i], v ?? true),
                                secondary: ReorderableDragStartListener(
                                  index: i,
                                  child: Icon(Icons.drag_handle, color: AppColors.textMuted),
                                ),
                              ),
                          ],
                        ),
                        const Divider(),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('Mostrar “Sugestões para você”'),
                          value: _p.suggest,
                          onChanged: (v) => setState(() => _p = _p.copyWith(suggest: v)),
                        ),
                        if (_p.suggest)
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('Sugestões acima dos widgets'),
                            value: _p.suggestFirst,
                            onChanged: (v) => setState(() => _p = _p.copyWith(suggestFirst: v)),
                          ),
                      ],
                    ),
                  ),
                ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_error!, style: const TextStyle(color: Color(0xFFE5484D), fontSize: 13)),
                ),
              const SizedBox(height: 12),
              Wrap(
                alignment: WrapAlignment.end,
                spacing: 8,
                children: [
                  TextButton(
                    onPressed: _saving ? null : () => setState(() => _p = const RailPrefs()),
                    child: const Text('Restaurar padrão'),
                  ),
                  TextButton(
                    onPressed: _saving ? null : () => Navigator.of(context).pop(),
                    child: const Text('Cancelar'),
                  ),
                  FilledButton(
                    onPressed: _saving ? null : _save,
                    child: Text(_saving ? 'Salvando…' : 'Salvar'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
