import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../models/rail_widgets.dart';
import '../../services/api_exception.dart';
import '../../theme/app_colors.dart';
import '../driqy_box.dart';
import '../wide_layout.dart';

/// Chave onde o último widget usado fica salvo (a mesma do site: `driqy-rail-widget`).
const String kRailWidgetPrefKey = 'driqy-rail-widget';

/// Um widget que o seletor sabe desenhar. [id] é o mesmo de `GET /api/v1/widgets`.
class RailWidgetSpec {
  final String id;
  final String title;
  final WidgetBuilder builder;

  /// Widget criado pelo próprio usuário ("Minha área", id `custom:N`): ganha a etiqueta \"seu\" e
  /// o botão de apagar de vez no editor.
  final bool custom;

  const RailWidgetSpec({required this.id, required this.title, required this.builder, this.custom = false});
}

/// Painel da direita: cartão de widgets (título, setas ‹ ›, grade com todos e bolinhas) e
/// cartão "Sugestões para você". Espelha o `_rail.html` + `rail.js` do site.
///
/// - [specs]: tudo o que o app sabe desenhar.
/// - [loadAvailableIds]: ids que o servidor oferece, na ordem do seletor. Ids que o app não
///   conhece são ignorados; se a chamada falhar (ou nenhum id servir), vale a ordem de [specs].
/// - [suggestions]: conteúdo do cartão de sugestões (`RailSuggestions`). null = "Sem sugestões por enquanto.".
///
/// Setas, grade e bolinhas só aparecem com 2+ widgets. O primeiro desenho espera a ordem do
/// servidor e o último widget usado, para não buscar o clima à toa.
class RailPanel extends StatefulWidget {
  final List<RailWidgetSpec> specs;
  final Future<List<String>> Function()? loadAvailableIds;
  final Widget? suggestions;

  /// Personalização do usuário. Quando vem, ela decide a ordem e quais widgets aparecem (no lugar
  /// da lista do servidor), se o cartão de sugestões existe e se ele fica acima dos widgets.
  final RailPrefs? prefs;

  /// Salva a personalização feita no modo editar (lápis do cartão). Devolve false se o servidor
  /// não aceitou. Sem isso o lápis não aparece (e, sem widgets ativos, o cartão some como antes).
  final Future<bool> Function(RailPrefs next)? onSavePrefs;

  /// \"Criar o seu\" no editor: tipos oferecidos, limite de widgets próprios e as ações. Sem
  /// [onCreateCustom] a seção não aparece. [onCreateCustom] devolve o id novo (`custom:N`) e
  /// pode lançar `ApiException` (a mensagem aparece no editor); [onDeleteCustom] devolve false
  /// se o servidor não apagou. Criar e apagar vão ao servidor na hora; só ordem e ocultar esperam o \"Concluir\".
  final List<CustomKind> customKinds;
  final int customMax;
  final Future<String> Function(String kind)? onCreateCustom;
  final Future<bool> Function(String id)? onDeleteCustom;

  const RailPanel({
    super.key,
    required this.specs,
    this.loadAvailableIds,
    this.suggestions,
    this.prefs,
    this.onSavePrefs,
    this.customKinds = kDefaultCustomKinds,
    this.customMax = 12,
    this.onCreateCustom,
    this.onDeleteCustom,
  });

  @override
  State<RailPanel> createState() => _RailPanelState();
}

class _RailPanelState extends State<RailPanel> {
  List<RailWidgetSpec> _active = const [];
  int _index = 0;
  bool _ready = false;

  // modo editar (lápis): listas de trabalho, só valem depois de "Concluir"
  bool _editing = false;
  bool _saving = false;
  String? _editError;
  List<String> _edActive = const [];
  List<String> _edOff = const [];
  bool _creating = false;
  String? _justCreated; // aberto ao sair do editor (como o site)

  bool get _canEdit => widget.onSavePrefs != null && widget.specs.isNotEmpty;

  List<RailWidgetSpec> _fromPrefs(RailPrefs p) {
    final byId = {for (final s in widget.specs) s.id: s};
    return [for (final id in p.visibleIds) if (byId[id] != null) byId[id]!];
  }

  void _startEdit() {
    final known = [for (final s in widget.specs) s.id];
    final active = [for (final s in _active) s.id];
    final base = widget.prefs?.order ?? known;
    final off = <String>[
      for (final id in base)
        if (known.contains(id) && !active.contains(id)) id,
      for (final id in known)
        if (!active.contains(id) && !base.contains(id)) id,
    ];
    setState(() {
      _editing = true;
      _saving = false;
      _creating = false;
      _justCreated = null;
      _editError = null;
      _edActive = active;
      _edOff = off.toSet().toList();
    });
  }

  void _edMove(int i, int delta) {
    final j = i + delta;
    if (j < 0 || j >= _edActive.length) return;
    final list = [..._edActive];
    final t = list[i];
    list[i] = list[j];
    list[j] = t;
    setState(() => _edActive = list);
  }

  void _edRemove(String id) => setState(() {
        _edActive = [..._edActive]..remove(id);
        _edOff = [id, ..._edOff];
      });

  void _edAdd(String id) => setState(() {
        _edOff = [..._edOff]..remove(id);
        _edActive = [..._edActive, id];
      });

  void _edReset() => setState(() {
        _edActive = [for (final s in widget.specs) s.id];
        _edOff = const [];
      });

  int get _customCount => widget.specs.where((s) => s.custom).length;

  Future<void> _create(String kind) async {
    final create = widget.onCreateCustom;
    if (create == null || _creating || _saving || _customCount >= widget.customMax) return;
    setState(() {
      _creating = true;
      _editError = null;
    });
    try {
      final id = await create(kind);
      if (!mounted) return;
      setState(() {
        _creating = false;
        _justCreated = id;
        if (!_edActive.contains(id) && !_edOff.contains(id)) _edActive = [..._edActive, id];
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _creating = false;
        _editError = e is ApiException ? e.message : 'Não foi possível criar agora.';
      });
    }
  }

  Future<void> _delete(String id) async {
    final remove = widget.onDeleteCustom;
    if (remove == null || _saving) return;
    final title = widget.specs.where((s) => s.id == id).map((s) => s.title).firstOrNull ?? 'este widget';
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Apagar de vez?'),
        content: Text('\u201c$title\u201d e tudo o que está nele serão apagados.'),
        actions: [
          TextButton(
            key: const Key('rail-ed-delete-no'),
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            key: const Key('rail-ed-delete-yes'),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Apagar'),
          ),
        ],
      ),
    );
    if (sure != true || !mounted) return;
    final ok = await remove(id);
    if (!mounted) return;
    setState(() {
      if (ok) {
        _edActive = [..._edActive]..remove(id);
        _edOff = [..._edOff]..remove(id);
        if (_justCreated == id) _justCreated = null;
        _editError = null;
      } else {
        _editError = 'Não foi possível apagar agora. Tente de novo.';
      }
    });
  }

  /// Preferências finais: o que o usuário montou + os ids que este app ainda não sabe desenhar
  /// (ficam como estavam, para não se perderem).
  RailPrefs _compose() {
    final base = widget.prefs ?? const RailPrefs();
    final known = {for (final s in widget.specs) s.id};
    final foreign = [for (final id in base.order) if (!known.contains(id)) id];
    final foreignOff = [for (final id in base.disabled) if (!known.contains(id)) id];
    return base.copyWith(
      order: [..._edActive, ..._edOff, ...foreign],
      disabled: [..._edOff, ...foreignOff],
    );
  }

  void _cancelEdit() {
    setState(() {
      _editing = false;
      // um widget criado no editor já existe no servidor: abre-o mesmo cancelando
      final k = _active.indexWhere((s) => s.id == _justCreated);
      if (k >= 0) _index = k;
    });
  }

  Future<void> _saveEdit() async {
    final next = _compose();
    if (next == (widget.prefs ?? const RailPrefs())) {
      setState(() => _editing = false);
      return;
    }
    setState(() {
      _saving = true;
      _editError = null;
    });
    var ok = false;
    try {
      ok = await widget.onSavePrefs!(next);
    } catch (_) {/* vira o aviso abaixo */}
    if (!mounted) return;
    if (!ok) {
      setState(() {
        _saving = false;
        _editError = 'Não foi possível salvar agora. Tente de novo.';
      });
      return;
    }
    final keep = _justCreated ?? (_index < _active.length ? _active[_index].id : null);
    final order = _fromPrefs(next);
    setState(() {
      _editing = false;
      _saving = false;
      _active = order;
      final k = order.indexWhere((s) => s.id == keep);
      _index = k >= 0 ? k : 0;
    });
  }

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void didUpdateWidget(covariant RailPanel old) {
    super.didUpdateWidget(old);
    final p = widget.prefs;
    final byId = {for (final s in widget.specs) s.id: s};
    final keep = _index < _active.length ? _active[_index].id : null;
    // com preferências, elas decidem a ordem (e widgets próprios que chegam depois entram);
    // sem elas, só se atualizam os specs que já estavam (ex.: título novo depois de Renomear)
    final order = p != null
        ? [for (final id in p.visibleIds) if (byId[id] != null) byId[id]!]
        : [for (final s in _active) if (byId[s.id] != null) byId[s.id]!];
    setState(() {
      _active = order;
      final k = order.indexWhere((s) => s.id == keep);
      _index = k >= 0 ? k : (_index < order.length ? _index : 0);
    });
  }

  Future<void> _init() async {
    var order = List<RailWidgetSpec>.of(widget.specs);
    final loader = widget.loadAvailableIds;
    final p = widget.prefs;
    if (p != null) {
      final byId = {for (final s in widget.specs) s.id: s};
      order = [for (final id in p.visibleIds) if (byId[id] != null) byId[id]!];
    } else if (loader != null) {
      try {
        final ids = await loader();
        final byId = {for (final s in widget.specs) s.id: s};
        final seen = <String>{};
        final fromServer = <RailWidgetSpec>[
          for (final id in ids)
            if (byId[id] != null && seen.add(id)) byId[id]!,
        ];
        if (fromServer.isNotEmpty) order = fromServer;
      } catch (_) {/* sem rede: fica a ordem local */}
    }
    var index = 0;
    try {
      final saved = (await SharedPreferences.getInstance()).getString(kRailWidgetPrefKey);
      final found = order.indexWhere((s) => s.id == saved);
      if (found >= 0) index = found;
    } catch (_) {/* sem storage: abre no primeiro */}
    if (!mounted) return;
    setState(() {
      _active = order;
      _index = index;
      _ready = true;
    });
  }

  Future<void> _select(int i) async {
    final n = _active.length;
    if (n == 0) return;
    final next = ((i % n) + n) % n;
    setState(() => _index = next);
    try {
      await (await SharedPreferences.getInstance()).setString(kRailWidgetPrefKey, _active[next].id);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.prefs;
    // sem lápis (nada para salvar), com todos os widgets removidos o cartão some; com lápis ele
    // fica, porque é por ele que se adiciona de volta
    final showWidgets = !(p != null && _ready && _active.isEmpty && !_canEdit);
    final showSuggest = p?.suggest ?? true;
    final widgetsCard = DriqyBox(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      child: _buildWidgetsCard(context),
    );
    final suggestCard = DriqyBox(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          const _RailTitle('Sugestões para você'),
          const SizedBox(height: 10),
          widget.suggestions ??
              Text(
                'Sem sugestões por enquanto.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13.5),
              ),
        ],
      ),
    );
    final cards = <Widget>[
      if (showWidgets) widgetsCard,
      if (showSuggest) suggestCard,
    ];
    if (p?.suggestFirst ?? false) cards.setAll(0, cards.reversed.toList());
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < cards.length; i++) ...[
          if (i > 0) const SizedBox(height: kBoxGap),
          cards[i],
        ],
      ],
    );
  }

  Widget _buildWidgetsCard(BuildContext context) {
    if (!_ready) {
      return const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          _RailTitle('Widgets'),
          SizedBox(
            height: 96,
            child: Center(
              child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)),
            ),
          ),
        ],
      );
    }
    if (_editing) return _buildEditor(context);
    if (_active.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Expanded(child: _RailTitle('Widgets')),
              if (_canEdit)
                _RailCircleButton(
                  key: const Key('rail-edit'),
                  icon: Icons.edit_outlined,
                  tooltip: 'Editar widgets',
                  onTap: _startEdit,
                ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _canEdit ? 'Nenhum widget no painel. Use o lápis para adicionar.' : 'Nenhum widget disponível ainda.',
            style: TextStyle(color: AppColors.textMuted, fontSize: 13.5),
          ),
        ],
      );
    }

    final current = _active[_index];
    final multi = _active.length > 1;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(child: _RailTitle(current.title)),
            if (multi) ...[
              _RailCircleButton(
                key: const Key('rail-prev'),
                icon: Icons.chevron_left,
                tooltip: 'Widget anterior',
                onTap: () => _select(_index - 1),
              ),
              const SizedBox(width: 6),
              _RailCircleButton(
                key: const Key('rail-next'),
                icon: Icons.chevron_right,
                tooltip: 'Próximo widget',
                onTap: () => _select(_index + 1),
              ),
              const SizedBox(width: 6),
              PopupMenuButton<int>(
                key: const Key('rail-menu'),
                tooltip: 'Todos os widgets',
                color: AppColors.surface2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                position: PopupMenuPosition.under,
                onSelected: _select,
                itemBuilder: (_) => [
                  for (var i = 0; i < _active.length; i++)
                    PopupMenuItem<int>(
                      value: i,
                      child: Text(
                        _active[i].title,
                        style: TextStyle(
                          color: i == _index ? AppColors.text : AppColors.textMuted,
                          fontWeight: i == _index ? FontWeight.w700 : FontWeight.w500,
                        ),
                      ),
                    ),
                ],
                child: const _RailCircle(icon: Icons.grid_view_rounded),
              ),
            ],
            if (_canEdit) ...[
              const SizedBox(width: 6),
              _RailCircleButton(
                key: const Key('rail-edit'),
                icon: Icons.edit_outlined,
                tooltip: 'Editar widgets',
                onTap: _startEdit,
              ),
            ],
          ],
        ),
        const SizedBox(height: 10),
        ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 96),
          // a chave por id recria o estado ao trocar de widget (o clima busca de novo, como no site)
          child: KeyedSubtree(key: ValueKey(current.id), child: current.builder(context)),
        ),
        if (multi) ...[
          const SizedBox(height: 8),
          // com 15+ widgets as bolinhas não cabem numa linha só: quebram para a de baixo
          Wrap(
            alignment: WrapAlignment.center,
            children: [
              for (var i = 0; i < _active.length; i++)
                Semantics(
                  button: true,
                  selected: i == _index,
                  label: _active[i].title,
                  child: GestureDetector(
                    key: Key('rail-dot-$i'),
                    behavior: HitTestBehavior.opaque,
                    onTap: () => _select(i),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i == _index ? AppColors.amber : AppColors.border,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ],
    );
  }

  /// Modo editar do cartão (o lápis): "No painel" com subir/descer/remover e "Disponíveis" com +.
  /// Só mexe em listas de trabalho; "Concluir" salva (uma chamada) e "Cancelar" descarta.
  Widget _buildEditor(BuildContext context) {
    final byId = {for (final s in widget.specs) s.id: s};

    Widget sub(String t) => Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 6),
          child: Text(
            t,
            style: TextStyle(color: AppColors.textMuted, fontSize: 11.5, fontWeight: FontWeight.w600, letterSpacing: 0.6),
          ),
        );

    Widget iconBtn(Key key, IconData icon, String tip, VoidCallback? onTap) => IconButton(
          key: key,
          icon: Icon(icon, size: 18),
          tooltip: tip,
          color: AppColors.textMuted,
          visualDensity: VisualDensity.compact,
          constraints: const BoxConstraints.tightFor(width: 34, height: 34),
          padding: EdgeInsets.zero,
          onPressed: _saving ? null : onTap,
        );

    Widget row(String id, List<Widget> actions) {
      final custom = byId[id]?.custom ?? false;
      return Container(
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.fromLTRB(12, 3, 4, 3),
        decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            Expanded(
              child: Row(
                children: [
                  Flexible(
                    child: Text(
                      byId[id]?.title ?? id,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                  ),
                  if (custom)
                    Container(
                      key: Key('rail-ed-tag-$id'),
                      margin: const EdgeInsets.only(left: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 1),
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColors.border),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text('seu', style: TextStyle(color: AppColors.textMuted, fontSize: 10.5, fontWeight: FontWeight.w600)),
                    ),
                ],
              ),
            ),
            ...actions,
            if (custom && widget.onDeleteCustom != null)
              iconBtn(Key('rail-ed-delete-$id'), Icons.delete_outline, 'Apagar de vez', () => _delete(id)),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        const _RailTitle('Editar widgets'),
        sub('NO PAINEL (${_edActive.length})'),
        if (_edActive.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text('Nada no painel. Adicione abaixo.', style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
          ),
        for (var i = 0; i < _edActive.length; i++)
          row(_edActive[i], [
            iconBtn(Key('rail-ed-up-${_edActive[i]}'), Icons.keyboard_arrow_up, 'Subir', i == 0 ? null : () => _edMove(i, -1)),
            iconBtn(Key('rail-ed-down-${_edActive[i]}'), Icons.keyboard_arrow_down, 'Descer',
                i == _edActive.length - 1 ? null : () => _edMove(i, 1)),
            iconBtn(Key('rail-ed-remove-${_edActive[i]}'), Icons.close, 'Remover do painel', () => _edRemove(_edActive[i])),
          ]),
        if (_edOff.isNotEmpty) sub('DISPONÍVEIS'),
        for (final id in _edOff)
          row(id, [iconBtn(Key('rail-ed-add-$id'), Icons.add, 'Adicionar ao painel', () => _edAdd(id))]),
        if (widget.onCreateCustom != null) ...[
          sub('CRIAR O SEU ($_customCount/${widget.customMax})'),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final k in widget.customKinds)
                ActionChip(
                  key: Key('rail-ed-new-${k.kind}'),
                  label: Text(k.title),
                  tooltip: k.desc.isEmpty ? null : k.desc,
                  avatar: const Icon(Icons.add, size: 14),
                  visualDensity: VisualDensity.compact,
                  onPressed: _saving || _creating || _customCount >= widget.customMax ? null : () => _create(k.kind),
                ),
            ],
          ),
          if (_customCount >= widget.customMax)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('Limite de ${widget.customMax} widgets seus atingido.',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
            ),
        ],
        if (_editError != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(_editError!, style: const TextStyle(color: Color(0xFFE5484D), fontSize: 13)),
          ),
        const SizedBox(height: 8),
        Wrap(
          alignment: WrapAlignment.end,
          spacing: 4,
          children: [
            TextButton(key: const Key('rail-ed-reset'), onPressed: _saving ? null : _edReset, child: const Text('Restaurar')),
            TextButton(
              key: const Key('rail-ed-cancel'),
              onPressed: _saving ? null : _cancelEdit,
              child: const Text('Cancelar'),
            ),
            FilledButton(
              key: const Key('rail-ed-done'),
              onPressed: _saving ? null : _saveEdit,
              child: Text(_saving ? 'Salvando…' : 'Concluir'),
            ),
          ],
        ),
      ],
    );
  }
}

/// `.rail-title` do site (1rem, 700).
class _RailTitle extends StatelessWidget {
  final String text;

  const _RailTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.w700),
    );
  }
}

/// Bolinha de 28px com ícone (`.rail-nav-btn`), só visual.
class _RailCircle extends StatelessWidget {
  final IconData icon;

  const _RailCircle({required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.surface2,
        border: Border.all(color: AppColors.border),
      ),
      child: Icon(icon, size: 16, color: AppColors.textMuted),
    );
  }
}

class _RailCircleButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  const _RailCircleButton({super.key, required this.icon, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkResponse(
        onTap: onTap,
        radius: 18,
        child: _RailCircle(icon: icon),
      ),
    );
  }
}
