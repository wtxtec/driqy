import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/auth_service.dart';
import '../../models/rail_widgets.dart';
import '../../services/news_service.dart';
import '../../services/user_service.dart';
import '../../services/widgets_service.dart';
import '../wide_layout.dart';
import 'rail_extra.dart';
import 'rail_lists.dart';
import 'rail_local.dart';
import 'rail_mine.dart';
import 'rail_panel.dart';
import 'rail_suggestions.dart';
import 'weather_widget.dart';

/// Widgets que o app sabe desenhar, na ordem local (a ordem do servidor tem prioridade).
/// Mesma ordem e mesmos títulos do site. [onOpenVortex] leva à aba Vortex (vem da `HomeShell`).
List<RailWidgetSpec> buildRailSpecs(AuthService auth, {VoidCallback? onOpenVortex}) => [
      RailWidgetSpec(
        id: 'weather',
        title: 'O clima hoje',
        builder: (_) => RailWeatherWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'trending',
        title: 'Em alta',
        builder: (_) => RailTrendingWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'news',
        title: 'Notícias',
        builder: (_) => RailNewsWidget(service: WidgetsService(auth.client), news: NewsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'vortex',
        title: 'Vortex',
        builder: (_) => RailVortexWidget(service: WidgetsService(auth.client), onOpenVortex: onOpenVortex),
      ),
      RailWidgetSpec(
        id: 'online',
        title: 'Quem está online',
        builder: (_) => RailOnlineWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'clock',
        title: 'Relógio mundial',
        builder: (_) => RailClockWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'calendar',
        title: 'Calendário',
        builder: (_) => RailCalendarWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'moon',
        title: 'Fase da Lua',
        builder: (_) => RailMoonWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'seasons',
        title: 'Estações',
        builder: (_) => RailSeasonsWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'quotes',
        title: 'Cotações',
        builder: (_) => RailQuotesWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'stats',
        title: 'Seu Driqy',
        builder: (_) => RailStatsWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'expiring',
        title: 'Acabando',
        builder: (_) => RailExpiringWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(
        id: 'phrase',
        title: 'Frase do dia',
        builder: (_) => RailPhraseWidget(service: WidgetsService(auth.client)),
      ),
      RailWidgetSpec(id: 'pomodoro', title: 'Foco', builder: (_) => const RailPomodoroWidget()),
      RailWidgetSpec(id: 'calc', title: 'Calculadora', builder: (_) => const RailCalcWidget()),
      RailWidgetSpec(id: 'breathe', title: 'Respirar', builder: (_) => const RailBreatheWidget()),
    ];

/// Widgets da "Minha área" como itens do seletor. A chave por id mantém o estado de cada um
/// (o conteúdo é buscado de novo só ao abrir o widget, como no site).
List<RailWidgetSpec> buildCustomSpecs(
  WidgetsService service,
  List<CustomWidget> customs, {
  void Function(String id, String title)? onRenamed,
}) =>
    [
      for (final c in customs)
        RailWidgetSpec(
          id: c.id,
          title: c.title,
          custom: true,
          builder: (_) => RailMineWidget(
            key: ValueKey('mine-${c.id}'),
            kind: c.kind,
            load: () => service.getCustom(c.widgetId),
            save: ({String? title, Map<String, dynamic>? data}) =>
                service.updateCustom(c.widgetId, title: title, data: data),
            onRenamed: onRenamed == null ? null : (t) => onRenamed(c.id, t),
          ),
        ),
    ];

/// Coluna direita da `HomeShell` em tela larga: largura fixa (320 + respiros), área segura,
/// rolagem sem barra visível (como `.rail`, que esconde a scrollbar) e o [RailPanel] ligado
/// ao login do usuário.
class DriqyRail extends StatelessWidget {
  final VoidCallback? onOpenVortex;

  /// Personalização (ordem, widgets removidos, sugestões). null = padrão.
  final RailPrefs? prefs;

  /// Salva as preferências feitas no modo editar (lápis do cartão de widgets).
  final Future<bool> Function(RailPrefs next)? onSavePrefs;

  /// "Minha área": widgets do usuário (`custom:N`), tipos, limite e ações (vêm do `RailPrefsController`).
  final List<CustomWidget> customs;
  final List<CustomKind> customKinds;
  final int customMax;
  final Future<String> Function(String kind)? onCreateCustom;
  final Future<bool> Function(String id)? onDeleteCustom;
  final void Function(String id, String title)? onRenameCustom;

  const DriqyRail({
    super.key,
    this.onOpenVortex,
    this.prefs,
    this.onSavePrefs,
    this.customs = const [],
    this.customKinds = kDefaultCustomKinds,
    this.customMax = 12,
    this.onCreateCustom,
    this.onDeleteCustom,
    this.onRenameCustom,
  });

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthService>();
    return SizedBox(
      width: kRailWidth + kBoxGap,
      child: SafeArea(
        left: false,
        child: ScrollConfiguration(
          behavior: ScrollConfiguration.of(context).copyWith(scrollbars: false),
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(0, kBoxGap, kBoxGap, kBoxGap),
            child: RailPanel(
              prefs: prefs,
              onSavePrefs: onSavePrefs,
              specs: [
                ...buildRailSpecs(auth, onOpenVortex: onOpenVortex),
                ...buildCustomSpecs(WidgetsService(auth.client), customs, onRenamed: onRenameCustom),
              ],
              customKinds: customKinds,
              customMax: customMax,
              onCreateCustom: onCreateCustom,
              onDeleteCustom: onDeleteCustom,
              loadAvailableIds: () => WidgetsService(auth.client).getWidgetIds(),
              suggestions: RailSuggestions(
                service: WidgetsService(auth.client),
                users: UserService(auth.client),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
