import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../theme/app_colors.dart';
import 'rail_common.dart';

/// Os 3 widgets do painel que rodam só no aparelho, sem rota no servidor (`client: true`):
/// Foco (pomodoro), Calculadora e Respirar. Mesmas regras do `rail-new.js` do site.

String _pad(int n) => n < 10 ? '0$n' : '$n';

TextStyle _muted([double size = 12]) => TextStyle(color: AppColors.textMuted, fontSize: size);

// ----------------------------------------------------------------------------- Foco (pomodoro)

/// Chave do estado salvo (a mesma do site: `driqy-rail-pomo`).
const String kPomoKey = 'driqy-rail-pomo';

class PomoMode {
  final String label;
  final int seconds;

  const PomoMode(this.label, this.seconds);
}

const Map<String, PomoMode> kPomoModes = {
  'focus': PomoMode('Foco', 25 * 60),
  'short': PomoMode('Pausa', 5 * 60),
  'long': PomoMode('Pausa longa', 15 * 60),
};

String pomoToday(DateTime now) => '${now.year}-${_pad(now.month)}-${_pad(now.day)}';

/// Estado do pomodoro, todo em valores simples (guardado como JSON). Sem relógio próprio: quem
/// chama passa "agora" em milissegundos, o que deixa a lógica testável.
class PomoState {
  final String mode; // focus | short | long
  final bool running;
  final int endAtMs; // quando acaba (só vale com running)
  final int left; // segundos que faltam (só vale parado)
  final String doneDate; // dia da contagem de focos concluídos
  final int doneN;

  const PomoState({
    required this.mode,
    required this.running,
    required this.endAtMs,
    required this.left,
    required this.doneDate,
    required this.doneN,
  });

  factory PomoState.fresh(String today) =>
      PomoState(mode: 'focus', running: false, endAtMs: 0, left: kPomoModes['focus']!.seconds, doneDate: today, doneN: 0);

  /// Lê o JSON salvo; qualquer coisa estranha volta ao começo. A contagem do dia zera em dia novo.
  factory PomoState.fromJson(Object? raw, String today) {
    if (raw is! Map) return PomoState.fresh(today);
    final mode = '${raw['mode']}';
    if (!kPomoModes.containsKey(mode)) return PomoState.fresh(today);
    final total = kPomoModes[mode]!.seconds;
    final left = raw['left'] is num ? (raw['left'] as num).toInt() : total;
    final done = raw['done'];
    final sameDay = done is Map && done['date'] == today;
    return PomoState(
      mode: mode,
      running: raw['running'] == true,
      endAtMs: raw['endAt'] is num ? (raw['endAt'] as num).toInt() : 0,
      left: left < 1 || left > total ? total : left,
      doneDate: today,
      doneN: sameDay && done['n'] is num ? (done['n'] as num).toInt() : 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'mode': mode,
        'running': running,
        'endAt': endAtMs,
        'left': left,
        'done': {'date': doneDate, 'n': doneN},
      };

  PomoState _copy({String? mode, bool? running, int? endAtMs, int? left, int? doneN}) => PomoState(
        mode: mode ?? this.mode,
        running: running ?? this.running,
        endAtMs: endAtMs ?? this.endAtMs,
        left: left ?? this.left,
        doneDate: doneDate,
        doneN: doneN ?? this.doneN,
      );

  int get total => kPomoModes[mode]!.seconds;

  int secondsLeft(int nowMs) => running ? ((endAtMs - nowMs) / 1000).round().clamp(0, total).toInt() : left;

  PomoState start(int nowMs) => _copy(running: true, endAtMs: nowMs + left * 1000);

  PomoState pause(int nowMs) {
    final s = ((endAtMs - nowMs) / 1000).round();
    return _copy(running: false, left: s < 1 ? 1 : (s > total ? total : s));
  }

  PomoState reset() => _copy(running: false, left: total);

  PomoState withMode(String m) => PomoState(
        mode: m,
        running: false,
        endAtMs: 0,
        left: kPomoModes[m]!.seconds,
        doneDate: doneDate,
        doneN: doneN,
      );

  /// Se o tempo acabou, vai para a próxima etapa (foco -> pausa, de 4 em 4 focos a pausa é longa;
  /// pausa -> foco) e fica parado. Se ainda não acabou, devolve o mesmo estado.
  PomoState advance(int nowMs) {
    if (!running || nowMs < endAtMs) return this;
    final n = mode == 'focus' ? doneN + 1 : doneN;
    final next = mode == 'focus' ? (n % 4 == 0 ? 'long' : 'short') : 'focus';
    return PomoState(
      mode: next,
      running: false,
      endAtMs: 0,
      left: kPomoModes[next]!.seconds,
      doneDate: doneDate,
      doneN: n,
    );
  }
}

class RailPomodoroWidget extends StatefulWidget {
  /// Relógio (milissegundos desde 1970) e o aviso sonoro; trocáveis para teste.
  final int Function()? nowMs;
  final VoidCallback? onFinished;

  const RailPomodoroWidget({super.key, this.nowMs, this.onFinished});

  @override
  State<RailPomodoroWidget> createState() => _RailPomodoroWidgetState();
}

class _RailPomodoroWidgetState extends State<RailPomodoroWidget> {
  PomoState? _s;
  Timer? _timer;

  int _now() => (widget.nowMs ?? () => DateTime.now().millisecondsSinceEpoch)();

  String get _today => pomoToday(DateTime.fromMillisecondsSinceEpoch(_now()));

  @override
  void initState() {
    super.initState();
    _restore();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _restore() async {
    Object? raw;
    try {
      final text = (await SharedPreferences.getInstance()).getString(kPomoKey);
      raw = text == null ? null : jsonDecode(text);
    } catch (_) {
      raw = null;
    }
    if (!mounted) return;
    final loaded = PomoState.fromJson(raw, _today);
    final late = loaded.running ? _now() - loaded.endAtMs : 0;
    final s = loaded.advance(_now());
    setState(() => _s = s);
    if (!identical(s, loaded)) {
      _save(s);
      if (late < 5000) _beep(); // acabou faz pouco: avisa; faz tempo: só mostra a etapa nova
    }
    _ensureTimer();
  }

  void _ensureTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _tick() {
    final s = _s;
    if (s == null || !mounted) return;
    if (!s.running) return;
    final next = s.advance(_now());
    setState(() => _s = next);
    if (!identical(next, s)) {
      _save(next);
      _beep();
    }
  }

  void _beep() {
    if (widget.onFinished != null) {
      widget.onFinished!();
      return;
    }
    SystemSound.play(SystemSoundType.alert);
    HapticFeedback.mediumImpact();
  }

  Future<void> _save(PomoState s) async {
    try {
      await (await SharedPreferences.getInstance()).setString(kPomoKey, jsonEncode(s.toJson()));
    } catch (_) {}
  }

  void _apply(PomoState s) {
    setState(() => _s = s);
    _save(s);
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (s == null) return const RailMessage(text: 'Carregando…');
    final now = _now();
    final sec = s.secondsLeft(now);
    final total = s.total;
    final goLabel = s.running ? 'Pausar' : (sec < total ? 'Continuar' : 'Iniciar');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 6,
          children: [
            for (final e in kPomoModes.entries)
              ChoiceChip(
                key: Key('pomo-mode-${e.key}'),
                label: Text(e.value.label),
                selected: s.mode == e.key,
                visualDensity: VisualDensity.compact,
                onSelected: (_) => _apply(s.withMode(e.key)),
              ),
          ],
        ),
        const SizedBox(height: 8),
        Center(
          child: Text(
            '${_pad(sec ~/ 60)}:${_pad(sec % 60)}',
            key: const Key('pomo-time'),
            style: TextStyle(color: AppColors.text, fontSize: 42, fontWeight: FontWeight.w800),
          ),
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: (1 - sec / total).clamp(0.0, 1.0).toDouble(),
            minHeight: 6,
            color: AppColors.amber,
            backgroundColor: AppColors.surface2,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FilledButton(
              key: const Key('pomo-go'),
              onPressed: () => _apply(s.running ? s.pause(now) : s.start(now)),
              child: Text(goLabel),
            ),
            const SizedBox(width: 8),
            TextButton(key: const Key('pomo-reset'), onPressed: () => _apply(s.reset()), child: const Text('Reiniciar')),
          ],
        ),
        Center(
          child: Text(
            s.doneN > 0 ? 'Hoje: ${s.doneN}${s.doneN == 1 ? ' foco concluído' : ' focos concluídos'}' : '25 min de foco, 5 de pausa.',
            key: const Key('pomo-count'),
            style: _muted(),
          ),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------------------- Calculadora

/// Máquina da calculadora (sem `eval`): 0,1 + 0,2 = 0,3 e 1 ÷ 0 = "Erro".
class CalcEngine {
  String cur = '0';
  double? acc;
  String? op;
  bool fresh = true;
  bool err = false;

  /// Número sem lixo de ponto flutuante; null se não for finito (divisão por zero etc.).
  static String? fmt(double n) {
    if (n.isNaN || n.isInfinite) return null;
    final d = double.parse(n.toStringAsPrecision(12));
    if (d == d.truncateToDouble() && d.abs() < 1e15) return d.toInt().toString();
    return d.toString();
  }

  String get display => err ? 'Erro' : cur.replaceAll('.', ',');

  String get history => acc != null && op != null ? '${fmt(acc!)!.replaceAll('.', ',')} $op' : '';

  void _compute() {
    final a = acc ?? 0;
    final b = double.tryParse(cur) ?? 0;
    final double r;
    switch (op) {
      case '+':
        r = a + b;
        break;
      case '−':
        r = a - b;
        break;
      case '×':
        r = a * b;
        break;
      default:
        r = b == 0 ? double.nan : a / b;
    }
    final f = fmt(r);
    if (f == null) {
      err = true;
      cur = '0';
      acc = null;
      op = null;
      fresh = true;
      return;
    }
    cur = f;
  }

  void _clearError() {
    if (err) {
      err = false;
      cur = '0';
      fresh = true;
    }
  }

  void digit(String d) {
    _clearError();
    if (fresh) {
      cur = d;
      fresh = false;
    } else if (cur.replaceAll(RegExp(r'[-.]'), '').length < 14) {
      cur = cur == '0' ? d : cur + d;
    }
  }

  void dot() {
    _clearError();
    if (fresh) {
      cur = '0.';
      fresh = false;
    } else if (!cur.contains('.')) {
      cur += '.';
    }
  }

  void setOp(String o) {
    if (err) return;
    if (op != null && !fresh) {
      _compute();
      if (err) return;
    }
    acc = double.tryParse(cur) ?? 0;
    op = o;
    fresh = true;
  }

  void equals() {
    if (err || op == null) return;
    _compute();
    acc = null;
    op = null;
    fresh = true;
  }

  void clear() {
    cur = '0';
    acc = null;
    op = null;
    fresh = true;
    err = false;
  }

  void back() {
    if (err) {
      clear();
      return;
    }
    if (fresh) return;
    cur = cur.length > 1 && !(cur.length == 2 && cur[0] == '-') ? cur.substring(0, cur.length - 1) : '0';
    if (cur == '0') fresh = true;
  }

  void percent() {
    if (err) return;
    cur = fmt((double.tryParse(cur) ?? 0) / 100) ?? '0';
    fresh = true;
  }

  void negate() {
    if (err || cur == '0') return;
    cur = cur[0] == '-' ? cur.substring(1) : '-$cur';
  }
}

class RailCalcWidget extends StatefulWidget {
  const RailCalcWidget({super.key});

  @override
  State<RailCalcWidget> createState() => _RailCalcWidgetState();
}

class _RailCalcWidgetState extends State<RailCalcWidget> {
  final CalcEngine _c = CalcEngine();
  final FocusNode _focus = FocusNode(debugLabel: 'rail-calc');

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  void _do(VoidCallback fn) => setState(fn);

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (e is! KeyDownEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    final ch = e.character ?? '';
    if (RegExp(r'^[0-9]$').hasMatch(ch)) {
      _do(() => _c.digit(ch));
    } else if (ch == ',' || ch == '.') {
      _do(_c.dot);
    } else if (ch == '+') {
      _do(() => _c.setOp('+'));
    } else if (ch == '-') {
      _do(() => _c.setOp('−'));
    } else if (ch == '*' || ch == 'x') {
      _do(() => _c.setOp('×'));
    } else if (ch == '/') {
      _do(() => _c.setOp('÷'));
    } else if (ch == '=' || k == LogicalKeyboardKey.enter || k == LogicalKeyboardKey.numpadEnter) {
      _do(_c.equals);
    } else if (k == LogicalKeyboardKey.backspace) {
      _do(_c.back);
    } else if (k == LogicalKeyboardKey.escape || k == LogicalKeyboardKey.delete) {
      _do(_c.clear);
    } else if (ch == '%') {
      _do(_c.percent);
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  Widget _key(String label, VoidCallback fn, {String kind = 'num'}) {
    final isOp = kind == 'op';
    final isEq = kind == 'eq';
    return Padding(
      padding: const EdgeInsets.all(2.5),
      child: SizedBox(
        height: 38,
        child: Material(
          color: isEq ? AppColors.amber : (isOp ? AppColors.surface2 : AppColors.surface2.withOpacity(kind == 'fn' ? 0.6 : 1)),
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            key: Key('calc-key-$label'),
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              _focus.requestFocus();
              _do(fn);
            },
            child: Center(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: isEq ? AppColors.onBrand : (isOp ? AppColors.amber : AppColors.text),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final rows = <List<Widget>>[
      [
        _key('C', _c.clear, kind: 'fn'),
        _key('⌫', _c.back, kind: 'fn'),
        _key('%', _c.percent, kind: 'fn'),
        _key('÷', () => _c.setOp('÷'), kind: 'op'),
      ],
      [
        _key('7', () => _c.digit('7')),
        _key('8', () => _c.digit('8')),
        _key('9', () => _c.digit('9')),
        _key('×', () => _c.setOp('×'), kind: 'op'),
      ],
      [
        _key('4', () => _c.digit('4')),
        _key('5', () => _c.digit('5')),
        _key('6', () => _c.digit('6')),
        _key('−', () => _c.setOp('−'), kind: 'op'),
      ],
      [
        _key('1', () => _c.digit('1')),
        _key('2', () => _c.digit('2')),
        _key('3', () => _c.digit('3')),
        _key('+', () => _c.setOp('+'), kind: 'op'),
      ],
      [
        _key('±', _c.negate, kind: 'fn'),
        _key('0', () => _c.digit('0')),
        _key(',', _c.dot, kind: 'fn'),
        _key('=', _c.equals, kind: 'eq'),
      ],
    ];
    return Focus(
      focusNode: _focus,
      onKeyEvent: _onKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(12)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(_c.history, key: const Key('calc-history'), style: _muted(12)),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    _c.display,
                    key: const Key('calc-display'),
                    style: TextStyle(color: AppColors.text, fontSize: 28, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          for (final r in rows) Row(children: [for (final k in r) Expanded(child: k)]),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------------- Respirar

class BreathePhase {
  final String label;
  final int ms;
  final double scale;

  const BreathePhase(this.label, this.ms, this.scale);
}

/// Inspire 4 s, segure 4 s, expire 6 s; a sessão dura 1 minuto.
const List<BreathePhase> kBreathePhases = [
  BreathePhase('Inspire', 4000, 1.0),
  BreathePhase('Segure', 4000, 1.0),
  BreathePhase('Expire', 6000, 0.55),
];
const Duration kBreatheSession = Duration(seconds: 60);
const double kBreatheRest = 0.55;

class RailBreatheWidget extends StatefulWidget {
  const RailBreatheWidget({super.key});

  @override
  State<RailBreatheWidget> createState() => _RailBreatheWidgetState();
}

class _RailBreatheWidgetState extends State<RailBreatheWidget> {
  Timer? _t;
  bool _running = false;
  String _label = 'Respirar';
  String _sub = 'Um minuto: inspire 4 s, segure 4 s, expire 6 s.';
  double _scale = kBreatheRest;
  Duration _dur = const Duration(milliseconds: 400);
  late DateTime _startedAt;
  int _cycles = 0;

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  bool get _reduce => MediaQuery.maybeOf(context)?.disableAnimations ?? false;

  void _start() {
    _startedAt = DateTime.now();
    _cycles = 0;
    setState(() {
      _running = true;
      _sub = 'Um minuto: inspire 4 s, segure 4 s, expire 6 s.';
      _dur = Duration.zero;
      _scale = kBreatheRest;
    });
    _step(0);
  }

  void _stop(String msg, {String? sub}) {
    _t?.cancel();
    setState(() {
      _running = false;
      _label = msg;
      if (sub != null) _sub = sub;
      _dur = _reduce ? Duration.zero : const Duration(milliseconds: 400);
      _scale = kBreatheRest;
    });
  }

  void _step(int i) {
    if (!_running || !mounted) return;
    if (i == 0 && DateTime.now().difference(_startedAt) >= kBreatheSession) {
      _stop('Pronto. Respire normalmente.', sub: '$_cycles ${_cycles == 1 ? 'ciclo' : 'ciclos'}.');
      return;
    }
    final p = kBreathePhases[i];
    setState(() {
      _label = p.label;
      _dur = _reduce ? Duration.zero : Duration(milliseconds: p.ms);
      _scale = p.scale;
    });
    _t = Timer(Duration(milliseconds: p.ms), () {
      if (i == kBreathePhases.length - 1) _cycles++;
      _step((i + 1) % kBreathePhases.length);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Center(
          child: Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
            child: Center(
              child: AnimatedScale(
                scale: _scale,
                duration: _dur,
                curve: Curves.easeInOut,
                child: Container(
                  key: const Key('breathe-circle'),
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.amber.withOpacity(0.35)),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Center(
          child: Text(_label,
              key: const Key('breathe-label'),
              style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.w700)),
        ),
        const SizedBox(height: 6),
        Center(
          child: FilledButton(
            key: const Key('breathe-go'),
            onPressed: () => _running ? _stop('Parado.') : _start(),
            child: Text(_running ? 'Parar' : 'Começar'),
          ),
        ),
        const SizedBox(height: 4),
        Center(child: Text(_sub, key: const Key('breathe-sub'), textAlign: TextAlign.center, style: _muted())),
      ],
    );
  }
}
