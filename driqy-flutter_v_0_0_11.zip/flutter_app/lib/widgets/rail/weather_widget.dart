import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import '../wide_layout.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../models/rail_widgets.dart';
import '../../screens/edit_profile_screen.dart';
import '../../services/widgets_service.dart';
import '../../theme/app_colors.dart';
import '../place_field.dart';

/// Ícone do clima. O site desenha SVGs; aqui são ícones do Material nas mesmas cores
/// (sol âmbar, nuvem cinza, chuva azul, raio âmbar), com combinações para "sol com nuvem".
class WeatherIcon extends StatelessWidget {
  final String kind;
  final double size;

  const WeatherIcon({super.key, required this.kind, this.size = 52});

  static const _sun = Color(0xFFF2A93B);
  static const _moon = Color(0xFFC9C3D8);
  static const _cloud = Color(0xFFB8B2C6);
  static const _stormCloud = Color(0xFF8A849B);
  static const _rain = Color(0xFF6AA9E9);
  static const _snow = Color(0xFF9CC4E8);

  Widget _icon(IconData data, Color color, double s) => Icon(data, color: color, size: s);

  Widget _combo(Widget back, Widget front) => SizedBox(
        width: size,
        height: size,
        child: Stack(
          children: [
            Align(alignment: Alignment.topLeft, child: back),
            Align(alignment: Alignment.bottomRight, child: front),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    switch (kind) {
      case 'sun':
        return _icon(Icons.wb_sunny_rounded, _sun, size);
      case 'moon':
        return _icon(Icons.nightlight_round, _moon, size);
      case 'sun-cloud':
        return _combo(_icon(Icons.wb_sunny_rounded, _sun, size * 0.62), _icon(Icons.cloud, _cloud, size * 0.82));
      case 'moon-cloud':
        return _combo(_icon(Icons.nightlight_round, _moon, size * 0.6), _icon(Icons.cloud, _cloud, size * 0.82));
      case 'fog':
        return _icon(Icons.foggy, _cloud, size);
      case 'drizzle':
        return _icon(Icons.grain, _rain, size);
      case 'rain':
        return _icon(Icons.water_drop, _rain, size);
      case 'snow':
        return _icon(Icons.ac_unit, _snow, size);
      case 'storm':
        return _icon(Icons.thunderstorm, _stormCloud, size);
      case 'cloud':
      default:
        return _icon(Icons.cloud, _cloud, size);
    }
  }
}

/// Widget "O clima hoje" do painel direito. Lê `/api/v1/widgets/weather` (cidade do perfil ou a
/// região escolhida em "Alterar região", guardada no aparelho).
/// Estados: carregando; ok; `no_location` e `not_found` (botão "Editar perfil");
/// `unavailable` ("Tentar de novo"); `disabled`. Atualiza a cada [refreshEvery] (15 min, como o
/// site) e pausa com o app em segundo plano.
class RailWeatherWidget extends StatefulWidget {
  final WidgetsService service;

  /// Abre a edição do perfil. null = abre a `EditProfileScreen`. Ao voltar, o clima é buscado de novo.
  final Future<void> Function()? onEditProfile;
  final Duration refreshEvery;

  const RailWeatherWidget({
    super.key,
    required this.service,
    this.onEditProfile,
    this.refreshEvery = const Duration(minutes: 15),
  });

  @override
  State<RailWeatherWidget> createState() => _RailWeatherWidgetState();
}

class _RailWeatherWidgetState extends State<RailWeatherWidget> with WidgetsBindingObserver {
  WeatherResult? _result;
  bool _loading = true;
  bool _foreground = true;
  int _request = 0;
  Timer? _timer;

  /// Região escolhida só para o widget (não muda o perfil); guardada neste aparelho.
  PlaceSuggestion? _region;
  static const _kRegion = 'weather_region';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init();
    _timer = Timer.periodic(widget.refreshEvery, (_) {
      if (_foreground && mounted) _load(silent: true);
    });
  }

  Future<void> _init() async {
    _region = await _readRegion();
    if (mounted) _load();
  }

  Future<PlaceSuggestion?> _readRegion() async {
    try {
      final raw = (await SharedPreferences.getInstance()).getString(_kRegion);
      if (raw == null) return null;
      return PlaceSuggestion.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> _saveRegion(PlaceSuggestion? r) async {
    _region = r;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (r == null) {
        await prefs.remove(_kRegion);
      } else {
        await prefs.setString(_kRegion, jsonEncode({
          'name': r.name,
          'admin1': r.admin1,
          'country': r.country,
          'label': r.label,
          'latitude': r.latitude,
          'longitude': r.longitude,
        }));
      }
    } catch (_) {}
    if (mounted) _load();
  }

  Future<void> _changeRegion() async {
    final controller = TextEditingController();
    final choice = await showModalBottomSheet<PlaceSuggestion>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Alterar região do clima',
                style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('Vale só para este widget; sua cidade do perfil não muda.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
            const SizedBox(height: 12),
            PlaceField(
              controller: controller,
              service: widget.service,
              autofocus: true,
              hintText: 'Buscar cidade, estado ou país…',
              onSelected: (p) => Navigator.of(ctx).pop(p),
            ),
          ],
        ),
      ),
    );
    controller.dispose();
    if (choice != null) await _saveRegion(choice);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
  }

  /// [silent]: atualização automática — mantém o clima atual na tela enquanto busca e, se a
  /// busca falhar, não troca um clima bom por uma mensagem de erro.
  Future<void> _load({bool silent = false}) async {
    final mine = ++_request;
    // Primeira busca (initState): o estado inicial já é "carregando". Nas seguintes (tentar de
    // novo, voltar da edição do perfil) limpa o resultado antigo para aparecer "Carregando…".
    if (!silent && _result != null) {
      setState(() {
        _result = null;
        _loading = true;
      });
    }
    final r = await widget.service.getWeather(region: _region);
    if (!mounted || mine != _request) return; // resposta atrasada: outra busca já começou
    if (silent && !r.ok && (_result?.ok ?? false)) return;
    setState(() {
      _result = r;
      _loading = false;
    });
  }

  Future<void> _editProfile() async {
    if (widget.onEditProfile != null) {
      await widget.onEditProfile!();
    } else {
      await shellNavigatorOf(context).push(MaterialPageRoute<void>(builder: (_) => const EditProfileScreen()));
    }
    if (mounted) _load(); // a cidade pode ter mudado
  }

  @override
  Widget build(BuildContext context) {
    final r = _result;
    if (_loading && r == null) {
      return const _WeatherMessage(text: 'Carregando o clima…');
    }
    if (r == null) return const SizedBox.shrink();
    if (r.reason == 'disabled') return const _WeatherMessage(text: 'O clima está desativado.');
    final Widget body;
    if (r.ok) {
      body = _WeatherCard(data: r);
    } else {
      switch (r.reason) {
        case 'no_location':
          body = _WeatherMessage(
            text: 'Escolha sua cidade no perfil (com as sugestões) para ver o clima de onde você está, ou escolha uma região aqui.',
            actionLabel: 'Editar perfil',
            onAction: _editProfile,
          );
          break;
        case 'not_found':
          body = _WeatherMessage(
            text: 'Não encontrei a cidade “${r.location}”. Escolha uma sugestão no perfil ou escolha uma região aqui.',
            actionLabel: 'Editar perfil',
            onAction: _editProfile,
          );
          break;
        default:
          body = _WeatherMessage(
            text: 'Não consegui buscar o clima agora.',
            actionLabel: 'Tentar de novo',
            onAction: () => _load(),
          );
      }
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        body,
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: _changeRegion,
          icon: const Icon(Icons.place_outlined, size: 16),
          label: Text(_region != null ? 'Região: ${_region!.name} · alterar' : 'Alterar região'),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.text,
            side: BorderSide(color: AppColors.border),
            minimumSize: Size.zero,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            textStyle: const TextStyle(fontSize: 13),
          ),
        ),
      ],
    );
  }
}

class _WeatherMessage extends StatelessWidget {
  final String text;
  final String? actionLabel;
  final VoidCallback? onAction;

  const _WeatherMessage({required this.text, this.actionLabel, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(text, style: TextStyle(color: AppColors.textMuted, fontSize: 13.5, height: 1.3)),
        if (actionLabel != null) ...[
          const SizedBox(height: 10),
          OutlinedButton(
            onPressed: onAction,
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.text,
              side: BorderSide(color: AppColors.border),
              minimumSize: Size.zero,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              textStyle: const TextStyle(fontSize: 13),
            ),
            child: Text(actionLabel!),
          ),
        ],
      ],
    );
  }
}

class _WeatherCard extends StatelessWidget {
  final WeatherResult data;

  const _WeatherCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final facts = <MapEntry<String, String>>[
      if (data.tempMax != null) MapEntry('Máx.', '${data.tempMax}°'),
      if (data.tempMin != null) MapEntry('Mín.', '${data.tempMin}°'),
      if (data.feelsLike != null) MapEntry('Sensação', '${data.feelsLike}°'),
      if (data.rainChance != null) MapEntry('Chuva', '${data.rainChance}%'),
      if (data.humidity != null) MapEntry('Umidade', '${data.humidity}%'),
      if (data.windKmh != null) MapEntry('Vento', '${data.windKmh} km/h'),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            WeatherIcon(kind: data.icon),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data.temperature == null ? '–' : '${data.temperature}°C',
                    style: TextStyle(color: AppColors.text, fontSize: 30, fontWeight: FontWeight.w700, height: 1.1),
                  ),
                  Text(
                    data.condition,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: AppColors.textMuted, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Text(data.location, style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
        if (facts.isNotEmpty) ...[
          const SizedBox(height: 10),
          Divider(height: 1, color: AppColors.border),
          const SizedBox(height: 10),
          for (var i = 0; i < facts.length; i += 2)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  Expanded(child: _Fact(label: facts[i].key, value: facts[i].value)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: i + 1 < facts.length
                        ? _Fact(label: facts[i + 1].key, value: facts[i + 1].value)
                        : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
        ],
      ],
    );
  }
}

class _Fact extends StatelessWidget {
  final String label;
  final String value;

  const _Fact({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
        const SizedBox(width: 6),
        Text(value, style: TextStyle(color: AppColors.text, fontSize: 13, fontWeight: FontWeight.w700)),
      ],
    );
  }
}
