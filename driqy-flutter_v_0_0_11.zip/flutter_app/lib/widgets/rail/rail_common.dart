import 'package:flutter/material.dart';

import '../../config.dart';
import '../../theme/app_colors.dart';

/// Mensagem do painel, com botão opcional (ex.: "Tentar de novo"). Igual ao `.wx-msg` do site.
class RailMessage extends StatelessWidget {
  final String text;
  final String? actionLabel;
  final VoidCallback? onAction;

  const RailMessage({super.key, required this.text, this.actionLabel, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(text, style: TextStyle(color: AppColors.textMuted, fontSize: 13.5, height: 1.3)),
        if (actionLabel != null) ...[
          const SizedBox(height: 10),
          OutlinedButton(
            onPressed: onAction,
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.text,
              side: BorderSide(color: AppColors.border),
              minimumSize: Size.zero,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              textStyle: const TextStyle(fontSize: 13),
            ),
            child: Text(actionLabel!),
          ),
        ],
      ],
    );
  }
}

/// Avatar redondo: foto ou a inicial do usuário.
class RailAvatar extends StatelessWidget {
  final String username;
  final String? avatarUrl;
  final double size;

  const RailAvatar({super.key, required this.username, this.avatarUrl, this.size = 36});

  @override
  Widget build(BuildContext context) {
    final initial = username.isEmpty ? '?' : username.substring(0, 1).toUpperCase();
    return CircleAvatar(
      radius: size / 2,
      backgroundColor: AppColors.surface2,
      backgroundImage: avatarUrl == null ? null : NetworkImage(resolveMediaUrl(avatarUrl!)),
      onBackgroundImageError: avatarUrl == null ? null : (_, __) {},
      child: avatarUrl == null
          ? Text(initial, style: TextStyle(color: AppColors.text, fontSize: size * 0.4, fontWeight: FontWeight.w700))
          : null,
    );
  }
}

/// Busca algo, mostra "Carregando…", o conteúdo ou "Não consegui carregar agora." com
/// "Tentar de novo". Uma resposta atrasada (de uma busca antiga) é ignorada.
class RailLoader<T> extends StatefulWidget {
  final Future<T> Function() load;
  final Widget Function(BuildContext context, T data) builder;

  const RailLoader({super.key, required this.load, required this.builder});

  @override
  State<RailLoader<T>> createState() => _RailLoaderState<T>();
}

class _RailLoaderState<T> extends State<RailLoader<T>> {
  T? _data;
  bool _failed = false;
  bool _loading = true;
  int _request = 0;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    final mine = ++_request;
    if (!_loading) {
      setState(() {
        _loading = true;
        _failed = false;
      });
    }
    try {
      final d = await widget.load();
      if (!mounted || mine != _request) return;
      setState(() {
        _data = d;
        _loading = false;
      });
    } catch (_) {
      if (!mounted || mine != _request) return;
      setState(() {
        _failed = true;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const RailMessage(text: 'Carregando…');
    if (_failed) {
      return RailMessage(text: 'Não consegui carregar agora.', actionLabel: 'Tentar de novo', onAction: _run);
    }
    return widget.builder(context, _data as T);
  }
}
