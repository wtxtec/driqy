import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/rail_widgets.dart';
import '../../services/api_exception.dart';
import '../../theme/app_colors.dart';
import 'rail_common.dart';

/// Busca o widget próprio (com o conteúdo).
typedef MineLoad = Future<CustomWidget> Function();

/// Salva título e/ou conteúdo e devolve o que o servidor guardou (já normalizado).
typedef MineSave = Future<CustomWidget> Function({String? title, Map<String, dynamic>? data});

enum _MineStatus { idle, saving, saved, error }

/// Limites iguais aos do servidor (`widgets_custom.py`); o servidor revalida tudo.
const int kMineMaxTitle = 40;
const int kMineMaxNote = 2000;
const int kMineMaxItems = 50;
const int kMineMaxItemText = 120;
const int kMineMaxLinks = 12;
const int kMineCounterLimit = 999999;

/// Um widget da "Minha área" dentro do painel: nota, tarefas, atalhos, contagem ou contador.
/// Igual ao `rail-mine.js` do site: abre buscando o conteúdo, salva sozinho (nota ao parar de
/// digitar; o resto na hora), mostra "Salvando…/Salvo" e tem "Renomear" no rodapé.
///
/// Os salvamentos andam em fila (um por vez) e a resposta do servidor só substitui o que está na
/// tela quando não há edição mais nova. Se o salvamento falha, o que foi digitado fica na tela
/// com o aviso (a próxima edição manda tudo de novo).
class RailMineWidget extends StatefulWidget {
  final String kind;
  final MineLoad load;
  final MineSave save;

  /// Chamado com o título novo depois de "Renomear" salvar (para o seletor mostrar o nome).
  final ValueChanged<String>? onRenamed;

  /// Relógio da contagem regressiva (para teste). Padrão: agora.
  final DateTime Function()? now;

  const RailMineWidget({super.key, required this.kind, required this.load, required this.save, this.onRenamed, this.now});

  @override
  State<RailMineWidget> createState() => _RailMineWidgetState();
}

class _RailMineWidgetState extends State<RailMineWidget> {
  CustomWidget? _w;
  bool _loading = true;
  bool _failed = false;
  _MineStatus _status = _MineStatus.idle;
  String? _error;

  int _seq = 0;
  int _queued = 0;
  Future<void> _chain = Future<void>.value();

  // texto/campos que salvam depois de um tempo parado (nota, rótulo da contagem)
  Timer? _timer;
  Map<String, dynamic>? _debounced;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _timer?.cancel();
    final p = _debounced;
    _debounced = null;
    if (p != null) {
      // o que ainda não foi salvo não se perde só porque o painel trocou de widget
      widget.save(data: p).then((_) {}, onError: (Object _) {});
    }
    super.dispose();
  }

  void _set(VoidCallback fn) {
    if (mounted) setState(fn);
  }

  Future<void> _load() async {
    _set(() {
      _loading = true;
      _failed = false;
    });
    try {
      final w = await widget.load();
      _set(() {
        _w = w;
        _loading = false;
      });
    } catch (_) {
      _set(() {
        _failed = true;
        _loading = false;
      });
    }
  }

  /// Guarda [data] já (mostra na tela na hora se [optimistic]) e devolve a mensagem de erro, ou null.
  Future<String?> _commit(Map<String, dynamic> data, {bool optimistic = true}) {
    _timer?.cancel();
    _debounced = null;
    final mine = ++_seq;
    _set(() {
      if (optimistic && _w != null) _w = _w!.copyWith(data: data);
      _status = _MineStatus.saving;
      _error = null;
      _queued++;
    });
    final done = Completer<String?>();
    _chain = _chain.then((_) async {
      String? err;
      try {
        final saved = await widget.save(data: data);
        if (mine == _seq) _set(() => _w = saved);
      } catch (e) {
        err = e is ApiException ? e.message : 'Não foi possível salvar agora.';
      }
      _set(() {
        _queued--;
        if (err != null) {
          _status = _MineStatus.error;
          _error = err;
        } else if (_queued == 0 && _status != _MineStatus.error) {
          _status = _MineStatus.saved;
        }
      });
      done.complete(err);
    });
    return done.future;
  }

  /// Salva [data] depois de 800 ms sem novas edições (e também ao sair do campo: [flush]).
  void _commitLater(Map<String, dynamic> data) {
    _debounced = data;
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 800), flush);
    _set(() {
      _status = _MineStatus.saving;
      _error = null;
    });
  }

  void flush() {
    final p = _debounced;
    if (p == null) return;
    _commit(p, optimistic: true);
  }

  Future<void> _rename() async {
    final w = _w;
    if (w == null) return;
    final messenger = ScaffoldMessenger.maybeOf(context);
    final next = await showDialog<String>(context: context, builder: (_) => _RenameDialog(initial: w.title));
    if (next == null || next == w.title) return;
    try {
      final saved = await widget.save(title: next);
      _set(() => _w = _w?.copyWith(title: saved.title));
      widget.onRenamed?.call(saved.title);
    } catch (e) {
      messenger?.showSnackBar(
        SnackBar(content: Text(e is ApiException ? e.message : 'Não foi possível renomear agora.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const RailMessage(text: 'Carregando…');
    final w = _w;
    if (_failed || w == null) {
      return RailMessage(text: 'Não consegui carregar agora.', actionLabel: 'Tentar de novo', onAction: _load);
    }
    final Widget body;
    switch (w.kind) {
      case 'checklist':
        body = _ChecklistBody(items: _items(w.data), onChange: (items) => _commit({'items': items}));
        break;
      case 'links':
        body = _LinksBody(
          links: _links(w.data),
          onCommit: (links) => _commit({'links': links}, optimistic: false),
        );
        break;
      case 'countdown':
        body = _CountdownBody(
          label: '${w.data['label'] ?? ''}',
          date: '${w.data['date'] ?? ''}',
          now: widget.now ?? DateTime.now,
          onChange: (label, date) => _commit({'label': label, 'date': date}),
        );
        break;
      case 'counter':
        body = _CounterBody(data: w.data, onChange: (d) => _commit(d));
        break;
      default:
        body = _NoteBody(
          initial: '${w.data['text'] ?? ''}',
          onChanged: (t) => _commitLater({'text': t}),
          onBlur: flush,
        );
    }
    final statusText = _status == _MineStatus.saving
        ? 'Salvando…'
        : _status == _MineStatus.saved
            ? 'Salvo'
            : _status == _MineStatus.error
                ? (_error ?? 'Não foi possível salvar agora.')
                : '';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        body,
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: Text(
                statusText,
                key: const Key('mine-status'),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: _status == _MineStatus.error ? AppColors.danger : AppColors.textMuted,
                  fontSize: 12,
                ),
              ),
            ),
            TextButton(
              key: const Key('mine-rename'),
              onPressed: _rename,
              style: TextButton.styleFrom(
                foregroundColor: AppColors.textMuted,
                minimumSize: Size.zero,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                textStyle: const TextStyle(fontSize: 12.5),
              ),
              child: const Text('Renomear'),
            ),
          ],
        ),
      ],
    );
  }
}

// ----------------------------------------------------------------------------- leitura do `data`

List<Map<String, dynamic>> _items(Map<String, dynamic> data) => [
      for (final e in (data['items'] as List<dynamic>? ?? const []))
        if (e is Map)
          {'id': '${e['id'] ?? ''}', 'text': '${e['text'] ?? ''}', 'done': e['done'] == true},
    ];

List<Map<String, dynamic>> _links(Map<String, dynamic> data) => [
      for (final e in (data['links'] as List<dynamic>? ?? const []))
        if (e is Map) {'title': '${e['title'] ?? ''}', 'url': '${e['url'] ?? ''}'},
    ];

int _asInt(dynamic v, int fallback) => v is num ? v.round() : int.tryParse('${v ?? ''}') ?? fallback;

int _clampInt(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

InputDecoration _fieldDecoration(String hint) => InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: AppColors.textMuted, fontSize: 13.5),
      isDense: true,
      filled: true,
      fillColor: AppColors.surface2,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      counterText: '',
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
    );

TextStyle get _fieldStyle => TextStyle(color: AppColors.text, fontSize: 14);

// ------------------------------------------------------------------------------------------ nota

class _NoteBody extends StatefulWidget {
  final String initial;
  final ValueChanged<String> onChanged;
  final VoidCallback onBlur;

  const _NoteBody({required this.initial, required this.onChanged, required this.onBlur});

  @override
  State<_NoteBody> createState() => _NoteBodyState();
}

class _NoteBodyState extends State<_NoteBody> {
  late final TextEditingController _c = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (has) {
        if (!has) widget.onBlur();
      },
      child: TextField(
        key: const Key('mine-note'),
        controller: _c,
        minLines: 4,
        maxLines: 10,
        maxLength: kMineMaxNote,
        maxLengthEnforcement: MaxLengthEnforcement.enforced,
        keyboardType: TextInputType.multiline,
        style: _fieldStyle,
        decoration: _fieldDecoration('Escreva aqui…'),
        onChanged: widget.onChanged,
      ),
    );
  }
}

// ---------------------------------------------------------------------------------------- tarefas

class _ChecklistBody extends StatefulWidget {
  final List<Map<String, dynamic>> items;
  final void Function(List<Map<String, dynamic>> items) onChange;

  const _ChecklistBody({required this.items, required this.onChange});

  @override
  State<_ChecklistBody> createState() => _ChecklistBodyState();
}

class _ChecklistBodyState extends State<_ChecklistBody> {
  final TextEditingController _c = TextEditingController();
  int _n = 0;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  String _newId() => 'l${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${_n++}';

  void _add() {
    final text = _c.text.trim();
    if (text.isEmpty || widget.items.length >= kMineMaxItems) return;
    _c.clear();
    widget.onChange([
      ...widget.items,
      {'id': _newId(), 'text': text, 'done': false},
    ]);
  }

  void _toggle(int i) {
    final list = [for (final e in widget.items) {...e}];
    list[i]['done'] = list[i]['done'] != true;
    widget.onChange(list);
  }

  void _remove(int i) => widget.onChange([
        for (var k = 0; k < widget.items.length; k++)
          if (k != i) widget.items[k],
      ]);

  void _clearDone() => widget.onChange([
        for (final e in widget.items)
          if (e['done'] != true) e,
      ]);

  @override
  Widget build(BuildContext context) {
    final items = widget.items;
    final done = items.where((e) => e['done'] == true).length;
    final full = items.length >= kMineMaxItems;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (items.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text('Nada por aqui ainda.', style: TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
          ),
        for (var i = 0; i < items.length; i++)
          Row(
            children: [
              SizedBox(
                width: 34,
                height: 34,
                child: Checkbox(
                  key: Key('mine-check-${items[i]['id']}'),
                  value: items[i]['done'] == true,
                  visualDensity: VisualDensity.compact,
                  activeColor: AppColors.amber,
                  onChanged: (_) => _toggle(i),
                ),
              ),
              Expanded(
                child: Text(
                  '${items[i]['text']}',
                  style: TextStyle(
                    color: items[i]['done'] == true ? AppColors.textMuted : AppColors.text,
                    fontSize: 14,
                    decoration: items[i]['done'] == true ? TextDecoration.lineThrough : null,
                  ),
                ),
              ),
              IconButton(
                key: Key('mine-del-${items[i]['id']}'),
                icon: const Icon(Icons.close, size: 16),
                tooltip: 'Remover',
                color: AppColors.textMuted,
                visualDensity: VisualDensity.compact,
                constraints: const BoxConstraints.tightFor(width: 30, height: 30),
                padding: EdgeInsets.zero,
                onPressed: () => _remove(i),
              ),
            ],
          ),
        const SizedBox(height: 6),
        TextField(
          key: const Key('mine-item-input'),
          controller: _c,
          enabled: !full,
          inputFormatters: [LengthLimitingTextInputFormatter(kMineMaxItemText)],
          textInputAction: TextInputAction.done,
          style: _fieldStyle,
          decoration: _fieldDecoration(full ? 'Limite de $kMineMaxItems itens' : 'Nova tarefa…').copyWith(
            suffixIcon: IconButton(
              key: const Key('mine-item-add'),
              icon: const Icon(Icons.add, size: 18),
              tooltip: 'Adicionar',
              color: AppColors.textMuted,
              onPressed: full ? null : _add,
            ),
          ),
          onSubmitted: (_) => _add(),
        ),
        if (items.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(
              children: [
                Text('$done/${items.length}', key: const Key('mine-progress'), style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                const Spacer(),
                if (done > 0)
                  TextButton(
                    key: const Key('mine-clear-done'),
                    onPressed: _clearDone,
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.textMuted,
                      minimumSize: Size.zero,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      textStyle: const TextStyle(fontSize: 12.5),
                    ),
                    child: const Text('Limpar feitas'),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------------------- atalhos

class _LinksBody extends StatefulWidget {
  final List<Map<String, dynamic>> links;

  /// Salva a lista nova e devolve o erro do servidor (ex.: "Link inválido."), ou null.
  final Future<String?> Function(List<Map<String, dynamic>> links) onCommit;

  const _LinksBody({required this.links, required this.onCommit});

  @override
  State<_LinksBody> createState() => _LinksBodyState();
}

class _LinksBodyState extends State<_LinksBody> {
  final TextEditingController _title = TextEditingController();
  final TextEditingController _url = TextEditingController();
  String? _formError;
  bool _busy = false;

  @override
  void dispose() {
    _title.dispose();
    _url.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final url = _url.text.trim();
    if (url.isEmpty || _busy || widget.links.length >= kMineMaxLinks) return;
    setState(() {
      _busy = true;
      _formError = null;
    });
    final err = await widget.onCommit([
      ...widget.links,
      {'title': _title.text.trim(), 'url': url},
    ]);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _formError = err;
      if (err == null) {
        _title.clear();
        _url.clear();
      }
    });
  }

  Future<void> _remove(int i) async {
    await widget.onCommit([
      for (var k = 0; k < widget.links.length; k++)
        if (k != i) widget.links[k],
    ]);
  }

  Future<void> _open(String url) async {
    final messenger = ScaffoldMessenger.maybeOf(context);
    try {
      final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (!ok) messenger?.showSnackBar(const SnackBar(content: Text('Não consegui abrir o link.')));
    } catch (_) {
      messenger?.showSnackBar(const SnackBar(content: Text('Não consegui abrir o link.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final links = widget.links;
    final full = links.length >= kMineMaxLinks;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (links.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text('Nenhum atalho ainda.', style: TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
          ),
        for (var i = 0; i < links.length; i++)
          Row(
            children: [
              Icon(Icons.link, size: 16, color: AppColors.textMuted),
              const SizedBox(width: 8),
              Expanded(
                child: InkWell(
                  key: Key('mine-link-$i'),
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => _open('${links[i]['url']}'),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      '${links[i]['title']}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
              IconButton(
                key: Key('mine-link-del-$i'),
                icon: const Icon(Icons.close, size: 16),
                tooltip: 'Remover atalho',
                color: AppColors.textMuted,
                visualDensity: VisualDensity.compact,
                constraints: const BoxConstraints.tightFor(width: 30, height: 30),
                padding: EdgeInsets.zero,
                onPressed: () => _remove(i),
              ),
            ],
          ),
        const SizedBox(height: 6),
        TextField(
          key: const Key('mine-link-title'),
          controller: _title,
          enabled: !full,
          inputFormatters: [LengthLimitingTextInputFormatter(kMineMaxTitle)],
          style: _fieldStyle,
          decoration: _fieldDecoration(full ? 'Limite de $kMineMaxLinks atalhos' : 'Nome (opcional)'),
        ),
        const SizedBox(height: 6),
        TextField(
          key: const Key('mine-link-url'),
          controller: _url,
          enabled: !full,
          keyboardType: TextInputType.url,
          textInputAction: TextInputAction.done,
          style: _fieldStyle,
          decoration: _fieldDecoration('endereco.com').copyWith(
            suffixIcon: IconButton(
              key: const Key('mine-link-add'),
              icon: const Icon(Icons.add, size: 18),
              tooltip: 'Adicionar atalho',
              color: AppColors.textMuted,
              onPressed: full || _busy ? null : _add,
            ),
          ),
          onSubmitted: (_) => _add(),
        ),
        if (_formError != null)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(_formError!, key: const Key('mine-link-error'), style: TextStyle(color: AppColors.danger, fontSize: 12.5)),
          ),
      ],
    );
  }
}

// -------------------------------------------------------------------------------------- contagem

String _isoDate(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// Dias de [today] até [iso] (AAAA-MM-DD): positivo = falta, negativo = já passou. null se a data não vale.
int? daysUntil(String iso, DateTime today) {
  final m = RegExp(r'^(\d{4})-(\d{2})-(\d{2})$').firstMatch(iso);
  if (m == null) return null;
  final y = int.parse(m.group(1)!);
  final mo = int.parse(m.group(2)!);
  final d = int.parse(m.group(3)!);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  // em UTC para o horário de verão não gerar 6,96 dias
  final target = DateTime.utc(y, mo, d);
  if (target.month != mo) return null; // 31/02 viraria março
  final base = DateTime.utc(today.year, today.month, today.day);
  return target.difference(base).inDays;
}

class _CountdownBody extends StatefulWidget {
  final String label;
  final String date;
  final DateTime Function() now;
  final void Function(String label, String date) onChange;

  const _CountdownBody({required this.label, required this.date, required this.now, required this.onChange});

  @override
  State<_CountdownBody> createState() => _CountdownBodyState();
}

class _CountdownBodyState extends State<_CountdownBody> {
  late final TextEditingController _label = TextEditingController(text: widget.label);

  @override
  void dispose() {
    _label.dispose();
    super.dispose();
  }

  void _saveLabel() {
    final t = _label.text.trim();
    if (t != widget.label) widget.onChange(t, widget.date);
  }

  Future<void> _pick() async {
    final today = widget.now();
    final current = daysUntil(widget.date, today) == null ? null : DateTime.tryParse(widget.date);
    final picked = await showDatePicker(
      context: context,
      initialDate: current ?? DateTime(today.year, today.month, today.day),
      firstDate: DateTime(1900),
      lastDate: DateTime(2100, 12, 31),
    );
    if (picked == null) return;
    widget.onChange(_label.text.trim(), _isoDate(picked));
  }

  @override
  Widget build(BuildContext context) {
    final n = widget.date.isEmpty ? null : daysUntil(widget.date, widget.now());
    final String big;
    final String small;
    if (n == null) {
      big = '—';
      small = widget.date.isEmpty ? 'Escolha uma data.' : 'Data inválida.';
    } else if (n == 0) {
      big = 'Hoje';
      small = 'é o dia!';
    } else if (n > 0) {
      big = '$n';
      small = n == 1 ? 'dia para' : 'dias para';
    } else {
      big = '${-n}';
      small = n == -1 ? 'dia desde' : 'dias desde';
    }
    final label = widget.label.isEmpty ? 'a data' : widget.label;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(big, key: const Key('mine-count-big'), style: TextStyle(color: AppColors.text, fontSize: 38, fontWeight: FontWeight.w800)),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                n == null || n == 0 ? small : '$small $label',
                key: const Key('mine-count-text'),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: AppColors.textMuted, fontSize: 14),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Focus(
          onFocusChange: (has) {
            if (!has) _saveLabel();
          },
          child: TextField(
            key: const Key('mine-count-label'),
            controller: _label,
            inputFormatters: [LengthLimitingTextInputFormatter(kMineMaxTitle)],
            textInputAction: TextInputAction.done,
            style: _fieldStyle,
            decoration: _fieldDecoration('Para quê? (ex.: Viagem)'),
            onSubmitted: (_) => _saveLabel(),
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            OutlinedButton.icon(
              key: const Key('mine-pick-date'),
              onPressed: _pick,
              icon: const Icon(Icons.event, size: 16),
              label: Text(widget.date.isEmpty ? 'Escolher data' : widget.date),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.text,
                side: BorderSide(color: AppColors.border),
                minimumSize: Size.zero,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                textStyle: const TextStyle(fontSize: 13),
              ),
            ),
            if (widget.date.isNotEmpty)
              IconButton(
                key: const Key('mine-clear-date'),
                icon: const Icon(Icons.close, size: 16),
                tooltip: 'Tirar a data',
                color: AppColors.textMuted,
                onPressed: () => widget.onChange(_label.text.trim(), ''),
              ),
          ],
        ),
      ],
    );
  }
}

// -------------------------------------------------------------------------------------- contador

class _CounterBody extends StatefulWidget {
  final Map<String, dynamic> data;
  final void Function(Map<String, dynamic> data) onChange;

  const _CounterBody({required this.data, required this.onChange});

  @override
  State<_CounterBody> createState() => _CounterBodyState();
}

class _CounterBodyState extends State<_CounterBody> {
  bool _config = false;
  late final TextEditingController _step = TextEditingController();
  late final TextEditingController _goal = TextEditingController();
  late final TextEditingController _unit = TextEditingController();

  int get _value => _asInt(widget.data['value'], 0);
  int get _stepValue => _clampInt(_asInt(widget.data['step'], 1), 1, 1000);
  int? get _goalValue {
    final g = widget.data['goal'];
    if (g == null || '$g'.isEmpty) return null;
    final n = _asInt(g, 0);
    return n >= 1 ? n : null;
  }

  String get _unitValue => '${widget.data['unit'] ?? ''}';

  @override
  void dispose() {
    _step.dispose();
    _goal.dispose();
    _unit.dispose();
    super.dispose();
  }

  Map<String, dynamic> _with({int? value, int? step, Object? goal = _keep, String? unit}) => {
        'value': _clampInt(value ?? _value, -kMineCounterLimit, kMineCounterLimit),
        'step': step ?? _stepValue,
        'goal': identical(goal, _keep) ? _goalValue : goal,
        'unit': unit ?? _unitValue,
      };

  static const Object _keep = Object();

  void _bump(int sign) => widget.onChange(_with(value: _value + sign * _stepValue));

  void _openConfig() {
    _step.text = '$_stepValue';
    _goal.text = _goalValue?.toString() ?? '';
    _unit.text = _unitValue;
    setState(() => _config = true);
  }

  void _applyConfig() {
    final step = _clampInt(_asInt(_step.text, _stepValue), 1, 1000);
    final goalText = _goal.text.trim();
    final int? goal = goalText.isEmpty ? null : _clampInt(_asInt(goalText, 0), 1, kMineCounterLimit);
    final unit = _unit.text.trim();
    setState(() => _config = false);
    widget.onChange(_with(step: step, goal: goal, unit: unit.length > 12 ? unit.substring(0, 12) : unit));
  }

  Widget _round(Key key, String label, VoidCallback onTap) => SizedBox(
        width: 54,
        height: 40,
        child: OutlinedButton(
          key: key,
          onPressed: onTap,
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.text,
            side: BorderSide(color: AppColors.border),
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
          ),
          child: Text(label),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final goal = _goalValue;
    final double? progress = goal == null ? null : (_value / goal).clamp(0.0, 1.0).toDouble();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text('$_value', key: const Key('mine-counter-value'), style: TextStyle(color: AppColors.text, fontSize: 38, fontWeight: FontWeight.w800)),
            if (_unitValue.isNotEmpty) ...[
              const SizedBox(width: 8),
              Text(_unitValue, style: TextStyle(color: AppColors.textMuted, fontSize: 14)),
            ],
            const Spacer(),
            if (goal != null)
              Text('meta $goal', key: const Key('mine-counter-goal'), style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
          ],
        ),
        if (progress != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                key: const Key('mine-counter-bar'),
                value: progress,
                minHeight: 6,
                color: AppColors.amber,
                backgroundColor: AppColors.surface2,
              ),
            ),
          ),
        const SizedBox(height: 10),
        Row(
          children: [
            _round(const Key('mine-dec'), '−$_stepValue', () => _bump(-1)),
            const SizedBox(width: 8),
            _round(const Key('mine-inc'), '+$_stepValue', () => _bump(1)),
            const Spacer(),
            TextButton(
              key: const Key('mine-reset'),
              onPressed: _value == 0 ? null : () => widget.onChange(_with(value: 0)),
              child: const Text('Zerar'),
            ),
            TextButton(
              key: const Key('mine-config'),
              onPressed: _config ? () => setState(() => _config = false) : _openConfig,
              child: Text(_config ? 'Fechar' : 'Ajustar'),
            ),
          ],
        ),
        if (_config) ...[
          const SizedBox(height: 4),
          Row(
            children: [
              Expanded(
                child: TextField(
                  key: const Key('mine-cfg-step'),
                  controller: _step,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
                  style: _fieldStyle,
                  decoration: _fieldDecoration('Passo'),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: TextField(
                  key: const Key('mine-cfg-goal'),
                  controller: _goal,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
                  style: _fieldStyle,
                  decoration: _fieldDecoration('Meta'),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: TextField(
                  key: const Key('mine-cfg-unit'),
                  controller: _unit,
                  inputFormatters: [LengthLimitingTextInputFormatter(12)],
                  style: _fieldStyle,
                  decoration: _fieldDecoration('Unidade'),
                ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton(key: const Key('mine-cfg-ok'), onPressed: _applyConfig, child: const Text('OK')),
          ),
        ],
      ],
    );
  }
}

// ---------------------------------------------------------------------------------------- renomear

class _RenameDialog extends StatefulWidget {
  final String initial;

  const _RenameDialog({required this.initial});

  @override
  State<_RenameDialog> createState() => _RenameDialogState();
}

class _RenameDialogState extends State<_RenameDialog> {
  late final TextEditingController _c = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.surface,
      title: const Text('Renomear'),
      content: TextField(
        key: const Key('mine-rename-input'),
        controller: _c,
        autofocus: true,
        inputFormatters: [LengthLimitingTextInputFormatter(kMineMaxTitle)],
        decoration: const InputDecoration(hintText: 'Nome do widget'),
        onSubmitted: (v) => Navigator.of(context).pop(v.trim()),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancelar')),
        FilledButton(
          key: const Key('mine-rename-ok'),
          onPressed: () => Navigator.of(context).pop(_c.text.trim()),
          child: const Text('Salvar'),
        ),
      ],
    );
  }
}
