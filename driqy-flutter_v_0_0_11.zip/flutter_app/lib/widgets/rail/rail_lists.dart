import 'package:flutter/material.dart';
import '../wide_layout.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../config.dart';
import '../../models/rail_widgets.dart';
import '../../screens/post_detail_screen.dart';
import '../../screens/profile_screen.dart';
import '../../screens/vortex_detail_screen.dart';
import '../../services/news_service.dart';
import '../../services/widgets_service.dart';
import '../../theme/app_colors.dart';
import 'rail_common.dart';

void _openProfile(BuildContext context, String username) {
  if (username.isEmpty) return;
  shellNavigatorOf(context).push(MaterialPageRoute<void>(builder: (_) => ProfileScreen(username: username)));
}

/// Linha clicável dos widgets (`.rail-row`).
class _RailRow extends StatelessWidget {
  final Widget? leading;
  final List<Widget> body;
  final VoidCallback onTap;

  const _RailRow({this.leading, required this.body, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (leading != null) ...[leading!, const SizedBox(width: 10)],
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: body)),
          ],
        ),
      ),
    );
  }
}

/// "Em alta": posts com mais reação nos últimos 7 dias. Toque abre o post.
class RailTrendingWidget extends StatelessWidget {
  final WidgetsService service;

  const RailTrendingWidget({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return RailLoader<List<TrendingPost>>(
      load: service.getTrending,
      builder: (context, posts) {
        if (posts.isEmpty) {
          return const RailMessage(text: 'Ainda não há posts em alta. Curta e comente para movimentar!');
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (final p in posts)
              _RailRow(
                leading: RailAvatar(username: p.author.username, avatarUrl: p.author.avatarUrl, size: 30),
                onTap: () => shellNavigatorOf(context)
                    .push(MaterialPageRoute<void>(builder: (_) => PostDetailScreen(postId: p.id))),
                body: [
                  Text('@${p.author.username}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.text, fontSize: 13.5, fontWeight: FontWeight.w700)),
                  if (p.snippet.isNotEmpty)
                    Text(p.snippet,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: AppColors.text, fontSize: 13, height: 1.25)),
                  Text('♥ ${p.likes}  ·  💬 ${p.comments}',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                ],
              ),
          ],
        );
      },
    );
  }
}

/// Chave (em `SharedPreferences`) com os ids das manchetes dispensadas neste aparelho.
const String kNewsDismissedKey = 'driqy.news.dismissed';

/// Quantas manchetes o widget mostra de uma vez.
const int kNewsShown = 4;

/// "Notícias": manchetes recomendadas. Toque registra o clique (`NewsService.openArticle`) e
/// abre a fonte no navegador do aparelho. O "×" dispensa a manchete (guardado só neste aparelho,
/// as 60 mais recentes) e o servidor é consultado de novo para repor uma; "Mostrar as dispensadas"
/// limpa a lista.
class RailNewsWidget extends StatefulWidget {
  final WidgetsService service;
  final NewsService news;

  /// Para os testes: troca o abrir de verdade.
  final Future<void> Function(NewsHeadline article)? onOpen;

  const RailNewsWidget({super.key, required this.service, required this.news, this.onOpen});

  @override
  State<RailNewsWidget> createState() => _RailNewsWidgetState();
}

class _RailNewsWidgetState extends State<RailNewsWidget> {
  List<NewsHeadline> _all = [];
  List<int> _dismissed = [];
  bool _loading = true;
  bool _failed = false;
  int _request = 0;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<List<int>> _readDismissed() async {
    try {
      final p = await SharedPreferences.getInstance();
      return (p.getStringList(kNewsDismissedKey) ?? const <String>[]).map(int.tryParse).whereType<int>().toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _saveDismissed() async {
    try {
      final p = await SharedPreferences.getInstance();
      final keep = _dismissed.length > 60 ? _dismissed.sublist(_dismissed.length - 60) : _dismissed;
      await p.setStringList(kNewsDismissedKey, keep.map((e) => e.toString()).toList());
    } catch (_) {/* sem storage: vale só até fechar o app */}
  }

  /// Busca as manchetes. [silent] = não volta para "Carregando…" (usado ao repor uma dispensada).
  Future<void> _run({bool silent = false}) async {
    final mine = ++_request;
    if (!silent && !_loading) {
      // "Tentar de novo": volta para "Carregando…" (na abertura _loading já é true)
      setState(() {
        _loading = true;
        _failed = false;
      });
    }
    try {
      if (!silent) {
        final saved = await _readDismissed();
        if (!mounted || mine != _request) return;
        _dismissed = saved;
      }
      final limit = (kNewsShown + _dismissed.length).clamp(kNewsShown, 12).toInt();
      final list = await widget.service.getNews(limit: limit);
      if (!mounted || mine != _request) return;
      setState(() {
        _all = list;
        _loading = false;
        _failed = false;
      });
    } catch (_) {
      if (!mounted || mine != _request) return;
      if (silent) return; // sem reposição: fica com o que já está na tela
      setState(() {
        _failed = true;
        _loading = false;
      });
    }
  }

  Future<void> _dismiss(NewsHeadline a) async {
    setState(() {
      if (!_dismissed.contains(a.id)) _dismissed = [..._dismissed, a.id];
    });
    await _saveDismissed();
    if (mounted) _run(silent: true);
  }

  Future<void> _restore() async {
    setState(() => _dismissed = []);
    await _saveDismissed();
    if (mounted) _run(silent: true);
  }

  Future<void> _open(BuildContext context, NewsHeadline a) async {
    if (widget.onOpen != null) return widget.onOpen!(a);
    final messenger = ScaffoldMessenger.maybeOf(context);
    try {
      final url = await widget.news.openArticle(a.id);
      final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (!ok) messenger?.showSnackBar(const SnackBar(content: Text('Não consegui abrir a notícia.')));
    } catch (_) {
      messenger?.showSnackBar(const SnackBar(content: Text('Não consegui abrir a notícia.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const RailMessage(text: 'Carregando…');
    if (_failed) {
      return RailMessage(text: 'Não consegui carregar agora.', actionLabel: 'Tentar de novo', onAction: _run);
    }
    final articles = _all.where((a) => !_dismissed.contains(a.id)).take(kNewsShown).toList();
    final restore = _dismissed.isEmpty
        ? null
        : Align(
            alignment: Alignment.centerLeft,
            child: TextButton(
              key: const Key('news-restore'),
              onPressed: _restore,
              style: TextButton.styleFrom(
                foregroundColor: AppColors.amber,
                padding: const EdgeInsets.symmetric(horizontal: 2),
                minimumSize: const Size(0, 28),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                textStyle: const TextStyle(fontSize: 12.5),
              ),
              child: Text('Mostrar as dispensadas (${_dismissed.length})'),
            ),
          );
    if (articles.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          RailMessage(text: _dismissed.isEmpty ? 'Sem notícias por enquanto.' : 'Você dispensou as manchetes de agora.'),
          if (restore != null) restore,
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final a in articles)
          Row(
            key: ValueKey('news-${a.id}'),
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _RailRow(
                  onTap: () => _open(context, a),
                  leading: a.imageUrl == null
                      ? null
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            resolveMediaUrl(a.imageUrl!),
                            width: 56,
                            height: 56,
                            fit: BoxFit.cover,
                            // imagem que não carrega some, como no site (img.remove())
                            errorBuilder: (_, __, ___) => const SizedBox(width: 0, height: 0),
                          ),
                        ),
                  body: [
                    Text(a.title,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: AppColors.text, fontSize: 13, height: 1.25)),
                    if (a.source.isNotEmpty)
                      Text(a.source, style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  ],
                ),
              ),
              IconButton(
                key: Key('news-dismiss-${a.id}'),
                tooltip: 'Dispensar esta manchete',
                icon: Icon(Icons.close, size: 16, color: AppColors.textMuted),
                visualDensity: VisualDensity.compact,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                onPressed: () => _dismiss(a),
              ),
            ],
          ),
        if (restore != null) restore,
      ],
    );
  }
}

/// "Vortex": grade 3x2 com as peças mais novas. Toque numa peça abre o detalhe; "Abrir o
/// Vortex" vai para a aba (via [onOpenVortex], que vem da `HomeShell`).
class RailVortexWidget extends StatelessWidget {
  final WidgetsService service;
  final VoidCallback? onOpenVortex;

  const RailVortexWidget({super.key, required this.service, this.onOpenVortex});

  @override
  Widget build(BuildContext context) {
    return RailLoader<List<VortexPreviewItem>>(
      load: service.getVortex,
      builder: (context, items) {
        if (items.isEmpty) return const RailMessage(text: 'O Vortex ainda não tem peças novas.');
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              mainAxisSpacing: 6,
              crossAxisSpacing: 6,
              children: [
                for (final it in items.take(6))
                  Tooltip(
                    message: it.title.isEmpty ? 'Vortex' : it.title,
                    child: InkWell(
                      onTap: () => shellNavigatorOf(context)
                          .push(MaterialPageRoute<void>(builder: (_) => VortexDetailScreen(itemId: it.id))),
                      borderRadius: BorderRadius.circular(10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          it.thumbUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => ColoredBox(color: AppColors.surface2),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            if (onOpenVortex != null) ...[
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  onPressed: onOpenVortex,
                  style: TextButton.styleFrom(
                    foregroundColor: AppColors.amber,
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text('Abrir o Vortex'),
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}

/// "Quem está online": quantidade + avatares. Respeita `hidden` (quem esconde o próprio
/// "online" também não vê os outros).
class RailOnlineWidget extends StatelessWidget {
  final WidgetsService service;

  const RailOnlineWidget({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return RailLoader<OnlineResult>(
      load: service.getOnline,
      builder: (context, d) {
        if (d.hidden) {
          return const RailMessage(
            text: 'Você escondeu o seu “online”, então também não vê quem está online. '
                'Dá para mudar isso nas configurações de privacidade do chat.',
          );
        }
        final n = d.count;
        final extra = n - d.users.length;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              n == 0 ? 'Ninguém online agora.' : '$n ${n == 1 ? 'pessoa online agora' : 'pessoas online agora'}',
              style: TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w600),
            ),
            if (d.users.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final u in d.users)
                    Tooltip(
                      message: '@${u.username}',
                      child: InkResponse(
                        onTap: () => _openProfile(context, u.username),
                        radius: 22,
                        child: RailAvatar(username: u.username, avatarUrl: u.avatarUrl, size: 36),
                      ),
                    ),
                ],
              ),
            ],
            if (n > 0 && extra > 0) ...[
              const SizedBox(height: 8),
              Text('+$extra pessoas', style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
            ],
          ],
        );
      },
    );
  }
}
