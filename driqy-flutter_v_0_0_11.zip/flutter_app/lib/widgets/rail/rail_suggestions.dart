import 'dart:async';

import 'package:flutter/material.dart';
import '../wide_layout.dart';

import '../../models/rail_widgets.dart';
import '../../screens/profile_screen.dart';
import '../../services/user_service.dart';
import '../../services/widgets_service.dart';
import '../../theme/app_colors.dart';
import 'rail_common.dart';

/// Tempo em que o "Desfazer" fica disponível depois de seguir (igual ao site).
const Duration kSuggestUndoWindow = Duration(seconds: 6);

/// Conteúdo do cartão "Sugestões para você": [count] pessoas com o motivo e o botão Seguir.
/// Ao seguir, a linha mostra "Seguindo" + "Desfazer" por [kSuggestUndoWindow]; se ninguém desfizer,
/// a linha some e entra outra (`limit=1` + `exclude` com todos os já mostrados), como no site.
/// Se o seguir (ou o desfazer) falha, a linha fica e aparece um aviso.
class RailSuggestions extends StatefulWidget {
  final WidgetsService service;
  final UserService users;
  final int count;

  const RailSuggestions({super.key, required this.service, required this.users, this.count = 4});

  @override
  State<RailSuggestions> createState() => _RailSuggestionsState();
}

class _RailSuggestionsState extends State<RailSuggestions> {
  List<SuggestedUser> _items = [];
  final Set<String> _shown = {}; // todos que já apareceram (não voltam como reposição)
  final Set<String> _busy = {};
  final Map<String, Timer> _undo = {}; // seguidos há pouco: ainda dá para desfazer
  bool _loading = true;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final t in _undo.values) {
      t.cancel();
    }
    _undo.clear();
    super.dispose();
  }

  Future<void> _load() async {
    for (final t in _undo.values) {
      t.cancel();
    }
    _undo.clear();
    setState(() {
      _loading = true;
      _failed = false;
    });
    try {
      final list = await widget.service.getSuggestions(limit: widget.count);
      if (!mounted) return;
      setState(() {
        _items = list;
        _shown
          ..clear()
          ..addAll(list.map((s) => s.user.username));
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _failed = true;
        _loading = false;
      });
    }
  }

  Future<void> _follow(SuggestedUser s) async {
    final name = s.user.username;
    if (_busy.contains(name)) return;
    setState(() => _busy.add(name));
    final messenger = ScaffoldMessenger.maybeOf(context);
    try {
      await widget.users.follow(name);
    } catch (_) {
      if (!mounted) return;
      setState(() => _busy.remove(name));
      messenger?.showSnackBar(const SnackBar(content: Text('Não consegui seguir agora. Tente de novo.')));
      return;
    }
    if (!mounted) return;
    setState(() => _busy.remove(name));
    _startUndoWindow(name);
  }

  void _startUndoWindow(String name) {
    _undo[name]?.cancel();
    setState(() {
      _undo[name] = Timer(kSuggestUndoWindow, () => _leave(name));
    });
  }

  /// Fim da janela do Desfazer: tira a linha e repõe uma pessoa nova, sem repetir ninguém que já apareceu.
  Future<void> _leave(String name) async {
    if (!mounted) return;
    setState(() {
      _undo.remove(name);
      _items = _items.where((x) => x.user.username != name).toList();
    });
    try {
      final more = await widget.service.getSuggestions(limit: 1, exclude: _shown.toList());
      if (!mounted) return;
      final fresh = more.where((m) => _shown.add(m.user.username)).take(1).toList();
      if (fresh.isNotEmpty) setState(() => _items = [..._items, ...fresh]);
    } catch (_) {/* sem reposição: a lista só fica menor */}
  }

  Future<void> _undoFollow(SuggestedUser s) async {
    final name = s.user.username;
    if (_busy.contains(name)) return;
    _undo[name]?.cancel(); // enquanto o pedido roda, a linha não pode ser trocada
    setState(() => _busy.add(name));
    final messenger = ScaffoldMessenger.maybeOf(context);
    try {
      await widget.users.unfollow(name);
    } catch (_) {
      if (!mounted) return;
      setState(() => _busy.remove(name));
      messenger?.showSnackBar(const SnackBar(content: Text('Não consegui desfazer agora. Tente de novo.')));
      _startUndoWindow(name); // continua seguindo: reabre a janela
      return;
    }
    if (!mounted) return;
    setState(() {
      _busy.remove(name);
      _undo.remove(name); // volta a "Seguir" e a linha fica
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const RailMessage(text: 'Carregando…');
    if (_failed) {
      return RailMessage(text: 'Não consegui carregar agora.', actionLabel: 'Tentar de novo', onAction: _load);
    }
    if (_items.isEmpty) return const RailMessage(text: 'Sem sugestões por enquanto.');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final s in _items)
          Padding(
            key: ValueKey('suggest-${s.user.username}'),
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => shellNavigatorOf(context).push(
                        MaterialPageRoute<void>(builder: (_) => ProfileScreen(username: s.user.username))),
                    borderRadius: BorderRadius.circular(12),
                    child: Row(
                      children: [
                        RailAvatar(username: s.user.username, avatarUrl: s.user.avatarUrl, size: 36),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(s.user.displayName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: AppColors.text, fontSize: 13.5, fontWeight: FontWeight.w700)),
                              Text('@${s.user.username}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                              if (s.reason.isNotEmpty)
                                Text(s.reason,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(color: AppColors.textMuted, fontSize: 11.5, height: 1.2)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                if (_undo.containsKey(s.user.username)) ...[
                  Text('Seguindo', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                  TextButton(
                    key: Key('suggest-undo-${s.user.username}'),
                    onPressed: _busy.contains(s.user.username) ? null : () => _undoFollow(s),
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.amber,
                      minimumSize: const Size(0, 30),
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    child: const Text('Desfazer'),
                  ),
                ] else
                  OutlinedButton(
                    key: Key('suggest-follow-${s.user.username}'),
                    onPressed: _busy.contains(s.user.username) ? null : () => _follow(s),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.amber,
                      side: BorderSide(color: AppColors.amber),
                      minimumSize: const Size(0, 30),
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    child: _busy.contains(s.user.username)
                        ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('Seguir'),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
