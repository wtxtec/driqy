import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';

/// Abas de Mensagens (fase 8: cada uma é uma tela; `PingNav` troca entre elas).
enum PingTab { chats, contacts, calls }

/// Barra inferior flutuante em pílula de Mensagens: Chats, Contatos, Chamadas e
/// Menu (abre o menu lateral). Igual ao `.ping-tabbar` do site. Use em `Scaffold.bottomNavigationBar`: o botão
/// flutuante já sobe acima dela sozinho.
class PingTabBar extends StatelessWidget {
  /// Total de mensagens não lidas (selo na aba Chats; 0 esconde).
  final int unread;

  /// Fase 8: aba marcada (padrão: Chats).
  final PingTab current;

  /// Fase 8: toque em Chats (na lista de conversas não faz nada).
  final VoidCallback? onChats;
  final VoidCallback onContacts;
  final VoidCallback onCalls;

  /// Abre o menu lateral (privacidade, perfil, atalhos).
  final VoidCallback onMenu;

  const PingTabBar({
    super.key,
    this.unread = 0,
    this.current = PingTab.chats,
    this.onChats,
    required this.onContacts,
    required this.onCalls,
    required this.onMenu,
  });

  @override
  Widget build(BuildContext context) {
    final ping = PingColors.of(context);
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        child: Center(
          heightFactor: 1,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Material(
              color: ping.panel,
              elevation: 8,
              shadowColor: Colors.black,
              borderRadius: BorderRadius.circular(999),
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Row(
                  children: [
                    _Tab(
                      icon: Icons.chat_bubble_outline,
                      label: 'Chats',
                      selected: current == PingTab.chats,
                      badge: unread,
                      onTap: onChats,
                    ),
                    _Tab(
                      icon: Icons.person_outline,
                      label: 'Contatos',
                      selected: current == PingTab.contacts,
                      onTap: onContacts,
                    ),
                    _Tab(
                      icon: Icons.call_outlined,
                      label: 'Chamadas',
                      selected: current == PingTab.calls,
                      onTap: onCalls,
                    ),
                    _Tab(
                      icon: Icons.menu,
                      label: 'Menu',
                      onTap: onMenu,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final int badge;
  final VoidCallback? onTap;

  const _Tab({
    required this.icon,
    required this.label,
    this.selected = false,
    this.badge = 0,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final ping = PingColors.of(context);
    final color = selected ? AppColors.amber : AppColors.text;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        // fase 10: um único rótulo (com as não lidas) em vez de ícone + texto + selo separados
        label: badge > 0 ? '$label, ${badge > 99 ? 'mais de 99' : badge} não lidas' : label,
        excludeSemantics: true,
        onTap: onTap,
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 2),
            decoration: BoxDecoration(
              color: selected ? Color.alphaBlend(AppColors.amber.withOpacity(0.16), ping.panel) : Colors.transparent,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Badge(
                  isLabelVisible: badge > 0,
                  label: Text(badge > 99 ? '99+' : '$badge'),
                  backgroundColor: AppColors.rose,
                  child: Icon(icon, size: 22, color: color),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
