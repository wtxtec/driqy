import 'package:flutter/material.dart';

/// Botão redondo "voltar ao topo": aparece depois de rolar [showAfter] pixels e leva a lista ao
/// começo com uma animação curta. Use em `Scaffold.floatingActionButton` (Vortex e Notícias).
class ScrollToTopButton extends StatefulWidget {
  final ScrollController controller;
  final double showAfter;

  const ScrollToTopButton({super.key, required this.controller, this.showAfter = 600});

  @override
  State<ScrollToTopButton> createState() => _ScrollToTopButtonState();
}

class _ScrollToTopButtonState extends State<ScrollToTopButton> {
  bool _visible = false;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onScroll);
  }

  @override
  void didUpdateWidget(covariant ScrollToTopButton old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller.removeListener(_onScroll);
      widget.controller.addListener(_onScroll);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onScroll);
    super.dispose();
  }

  void _onScroll() {
    final c = widget.controller;
    final show = c.hasClients && c.position.pixels > widget.showAfter;
    if (show != _visible) setState(() => _visible = show);
  }

  void _toTop() {
    final c = widget.controller;
    if (!c.hasClients) return;
    final reduce = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (reduce) {
      c.jumpTo(0);
    } else {
      c.animateTo(0, duration: const Duration(milliseconds: 450), curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: _visible ? 1 : 0,
      duration: const Duration(milliseconds: 160),
      child: IgnorePointer(
        ignoring: !_visible,
        child: FloatingActionButton.small(
          heroTag: null,
          tooltip: 'Voltar ao topo',
          onPressed: _toTop,
          child: const Icon(Icons.keyboard_arrow_up),
        ),
      ),
    );
  }
}
