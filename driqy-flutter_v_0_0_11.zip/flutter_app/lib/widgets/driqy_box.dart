import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import 'wide_layout.dart';

/// Caixa arredondada flutuante do layout largo: igual à `.sidebar` e ao `.rail-card` do site
/// (raio 22, borda, sombra suave). É um `Material` (e não só um `Container`) para que o realce
/// dos `ListTile`/`InkWell` de dentro apareça por cima do fundo da caixa.
class DriqyBox extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;

  const DriqyBox({super.key, required this.child, this.padding});

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(kBoxRadius);
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: const [
          BoxShadow(color: Color(0x2E000000), blurRadius: 24, offset: Offset(0, 6)),
        ],
      ),
      child: Material(
        color: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: radius,
          side: BorderSide(color: AppColors.border),
        ),
        clipBehavior: Clip.antiAlias,
        child: padding == null ? child : Padding(padding: padding!, child: child),
      ),
    );
  }
}
