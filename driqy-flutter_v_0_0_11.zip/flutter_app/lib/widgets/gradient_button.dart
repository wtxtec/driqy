import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Botão em formato de pílula com o gradiente âmbar→rosa da marca,
/// espelhando a classe `.btn` do `style.css`. Usado nas chamadas para
/// ação mais importantes (entrar, criar conta, publicar).
class GradientButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final double height;
  final double fontSize;
  final EdgeInsetsGeometry padding;

  const GradientButton({
    super.key,
    required this.onPressed,
    required this.child,
    this.height = 48,
    this.fontSize = 15,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    final disabled = onPressed == null;
    return Opacity(
      opacity: disabled ? 0.6 : 1,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(height),
        child: Ink(
          height: height,
          decoration: BoxDecoration(
            gradient: AppGradients.brand,
            borderRadius: BorderRadius.all(Radius.circular(999)),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(height),
            onTap: onPressed,
            child: Padding(
              padding: padding,
              child: Center(
              child: DefaultTextStyle.merge(
                style: TextStyle(
                  color: AppColors.onBrand,
                  fontWeight: FontWeight.w600,
                  fontSize: fontSize,
                ),
                child: IconTheme.merge(
                  data: IconThemeData(color: AppColors.onBrand),
                  child: child,
                ),
              ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
