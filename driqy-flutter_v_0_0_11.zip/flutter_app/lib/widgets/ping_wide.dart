import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/ping_theme.dart';

/// Largura mínima (dp) para o Ping virar master-detail (lista à esquerda, conversa à
/// direita). Mesmo corte do site (`@media (min-width: 900px)`).
const double kPingWideBreakpoint = 900;

/// Nome da rota de conversa no painel direito (o argumento é o @usuário). Serve para o
/// [PingDetailObserver] saber qual linha da lista marcar.
const String kPingThreadRoute = 'ping_thread';

/// Avisa as telas do painel direito que estão em modo largo (sem barra "Ping"/pílula
/// duplicadas, transições em fade). Fora do modo largo `PingWide.of` é false.
class PingWide extends InheritedWidget {
  const PingWide({super.key, required super.child});

  static bool of(BuildContext context) => context.getInheritedWidgetOfExactType<PingWide>() != null;

  @override
  bool updateShouldNotify(PingWide oldWidget) => false;
}

/// Transição do painel direito: fade curto (o slide do celular não faz sentido ao lado da lista).
PageRoute<T> pingFadeRoute<T>(Widget page, {String? name, Object? args}) {
  return PageRouteBuilder<T>(
    settings: RouteSettings(name: name, arguments: args),
    transitionDuration: const Duration(milliseconds: 160),
    reverseTransitionDuration: const Duration(milliseconds: 120),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (context, animation, __, child) => MediaQuery.of(context).disableAnimations
        ? child // fase 10: sem animação quando o sistema pede movimento reduzido
        : FadeTransition(opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut), child: child),
  );
}

/// Rota para Contatos/Configurações: fade no modo largo, Material normal no celular.
PageRoute<T> pingRoute<T>(BuildContext context, Widget page) =>
    PingWide.of(context) ? pingFadeRoute<T>(page) : MaterialPageRoute<T>(builder: (_) => page);

/// Diz qual conversa está aberta no painel direito (null = nenhuma) a cada mudança de rota.
class PingDetailObserver extends NavigatorObserver {
  final ValueChanged<String?> onActive;

  PingDetailObserver(this.onActive);

  String? _user(Route<dynamic>? r) =>
      r?.settings.name == kPingThreadRoute ? r!.settings.arguments as String? : null;

  // fora do frame atual: o Navigator pode estar no meio de um build/transição
  void _emit(Route<dynamic>? top) {
    final user = _user(top);
    WidgetsBinding.instance.addPostFrameCallback((_) => onActive(user));
  }

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) => _emit(route);

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) => _emit(previousRoute);

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) => _emit(newRoute);
}

/// Estado vazio do painel direito (igual ao "Selecione uma conversa" do site).
class PingEmptyDetail extends StatelessWidget {
  const PingEmptyDetail({super.key});

  @override
  Widget build(BuildContext context) {
    final c = PingColors.of(context);
    return PingBackground(
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(gradient: AppGradients.brand, shape: BoxShape.circle),
              child: Icon(Icons.chat_bubble_outline, size: 32, color: c.onAccent),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(color: c.panel, borderRadius: BorderRadius.circular(999)),
              child: Text(
                'Selecione uma conversa para começar',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
