import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import 'brand_title.dart';

/// Conteúdo do menu lateral (mesmos links, na mesma ordem, da `.sidebar-nav` do site:
/// Feed, Vortex, Notícias, Mensagens, Notificações, Meu perfil, Sair). É usado nos dois
/// lugares: dentro do `Drawer` (celular) e dentro da caixa fixa (tela larga).
///
/// [selectedTab] usa o índice das abas da `HomeShell` (0 Feed, 1 Vortex, 2 Notificações).
/// [onClose] só existe no Drawer (botão ✕ do `.sidebar-head`); na caixa fixa fica null.
class HomeMenu extends StatelessWidget {
  final int selectedTab;
  final ValueChanged<int> onSelectTab;
  final VoidCallback onNews;
  final VoidCallback onMessages;
  final VoidCallback onLogout;

  /// null = sem "Meu perfil" (usuário ainda não carregado).
  final VoidCallback? onProfile;
  final VoidCallback? onClose;

  /// "Configurações" (hoje só em tela larga, onde existe o painel direito: lá fica o
  /// "Personalizar painel"). null = sem o item.
  final VoidCallback? onSettings;

  /// "Widgets": tela com o painel de widgets (Clima, Lua, Estações...). Só aparece onde a coluna da
  /// direita não cabe (celular). null = sem o item.
  final VoidCallback? onWidgets;

  /// Marca do cabeçalho. Parâmetro para os testes não precisarem baixar a fonte da marca.
  final Widget brand;

  const HomeMenu({
    super.key,
    required this.selectedTab,
    required this.onSelectTab,
    required this.onNews,
    required this.onMessages,
    required this.onLogout,
    this.onProfile,
    this.onClose,
    this.onSettings,
    this.onWidgets,
    this.brand = const BrandTitle(fontSize: 22),
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Cabeçalho igual ao `.sidebar-head` do site: marca (+ botão ✕ no Drawer).
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 14, 14),
          child: Row(
            children: [
              Expanded(child: Align(alignment: Alignment.centerLeft, child: brand)),
              if (onClose != null)
                InkWell(
                  onTap: onClose,
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Icon(Icons.close, size: 18, color: AppColors.textMuted),
                  ),
                ),
            ],
          ),
        ),
        Divider(height: 1, color: AppColors.border),
        Flexible(
          child: ScrollConfiguration(
            // sem barra de scroll (a lista continua rolando)
            behavior: ScrollConfiguration.of(context).copyWith(scrollbars: false),
            child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.symmetric(vertical: 8),
            children: [
              HomeMenuItem(label: 'Feed', selected: selectedTab == 0, onTap: () => onSelectTab(0)),
              HomeMenuItem(label: 'Vortex', selected: selectedTab == 1, onTap: () => onSelectTab(1)),
              HomeMenuItem(label: 'Notícias', onTap: onNews),
              HomeMenuItem(label: 'Mensagens', onTap: onMessages),
              HomeMenuItem(
                label: 'Notificações',
                selected: selectedTab == 2,
                onTap: () => onSelectTab(2),
              ),
              if (onWidgets != null) HomeMenuItem(label: 'Widgets', onTap: onWidgets!),
              if (onProfile != null) HomeMenuItem(label: 'Meu perfil', onTap: onProfile!),
              if (onSettings != null) HomeMenuItem(label: 'Configurações', onTap: onSettings!),
              HomeMenuItem(label: 'Sair', onTap: onLogout),
            ],
            ),
          ),
        ),
      ],
    );
  }
}

/// Um item do menu lateral, igual às `<a>` da `.sidebar-nav` do site (só texto, sem ícone;
/// o ativo fica destacado).
class HomeMenuItem extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const HomeMenuItem({
    super.key,
    required this.label,
    required this.onTap,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        label,
        style: TextStyle(
          fontSize: 16,
          color: selected ? AppColors.text : AppColors.textMuted,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
        ),
      ),
      selected: selected,
      selectedTileColor: AppColors.surface2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      onTap: onTap,
    );
  }
}
