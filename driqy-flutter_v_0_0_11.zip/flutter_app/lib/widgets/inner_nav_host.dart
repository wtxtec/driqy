import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'wide_layout.dart';

/// Conta quantas telas estão empilhadas por cima da tela inicial deste `Navigator`
/// (0 = só a tela inicial). Cobre `push`, `pop`, `pushAndRemoveUntil` e `popUntil`.
class InnerDepthObserver extends NavigatorObserver {
  final ValueChanged<int> onDepth;
  int _depth = 0;

  InnerDepthObserver(this.onDepth);

  int get depth => _depth;

  void _set(int d) {
    _depth = d < 0 ? 0 : d;
    onDepth(_depth);
  }

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    // a primeira rota (tela inicial) não tem rota anterior e não conta
    if (previousRoute != null) _set(_depth + 1);
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (previousRoute != null) _set(_depth - 1);
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (previousRoute != null) _set(_depth - 1);
  }
}

/// Miolo da `HomeShell` em tela larga (menu em caixa). Tem um `Navigator` PRÓPRIO: as telas que o
/// miolo abre (Perfil, Notícias, Post, Busca, Widgets...) são empilhadas aqui dentro, então a caixa
/// do menu (e o painel direito) continuam na tela, como no site. Abaixo de 901 dp esta classe não é
/// usada: o celular continua com as telas empilhadas por cima de tudo.
///
/// - [homeBuilder] desenha a tela inicial (as abas). Precisa se atualizar sozinho (ex.:
///   `ValueListenableBuilder`): o `Navigator` não reconstrói a rota quando este widget reconstrói.
/// - Largura: com telas empilhadas o miolo é limitado a [kContentMaxWidth] (como `.content` do site).
///   Sem nada empilhado, [homeFullWidth] true (aba Vortex) usa a largura toda.
/// - Botão voltar do sistema: fecha primeiro a tela empilhada deste `Navigator`; só quando não há
///   nenhuma o gesto segue para o `Navigator` raiz.
/// - `HeroControllerScope.none`: o `HeroController` do `MaterialApp` já pertence ao `Navigator` raiz
///   e não pode ser dividido com outro.
class InnerNavHost extends StatefulWidget {
  final GlobalKey<NavigatorState> navigatorKey;
  final WidgetBuilder homeBuilder;
  final bool homeFullWidth;

  /// Avisado quando muda a quantidade de telas empilhadas (0 = só a tela inicial). A `HomeShell` usa
  /// para mostrar o painel direito só na Home, sem nenhuma tela por cima.
  final ValueChanged<int>? onDepthChanged;

  const InnerNavHost({
    super.key,
    required this.navigatorKey,
    required this.homeBuilder,
    this.homeFullWidth = false,
    this.onDepthChanged,
  });

  @override
  State<InnerNavHost> createState() => _InnerNavHostState();
}

class _InnerNavHostState extends State<InnerNavHost> {
  late final InnerDepthObserver _observer = InnerDepthObserver(_onDepth);
  int _depth = 0;
  int _target = 0;

  void _onDepth(int d) {
    _target = d;
    // O observer é chamado no meio de uma transição/build do Navigator: fora do frame atual.
    if (SchedulerBinding.instance.schedulerPhase == SchedulerPhase.persistentCallbacks) {
      SchedulerBinding.instance.addPostFrameCallback((_) => _apply());
    } else {
      _apply();
    }
  }

  void _apply() {
    if (!mounted || _depth == _target) return;
    setState(() => _depth = _target);
    widget.onDepthChanged?.call(_depth);
  }

  Future<bool> _onWillPop() async {
    final nav = widget.navigatorKey.currentState;
    if (nav != null && _depth > 0 && nav.canPop()) {
      await nav.maybePop();
      return false; // consumido pela tela empilhada
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final fullWidth = _depth == 0 && widget.homeFullWidth;
    return WillPopScope(
      onWillPop: _onWillPop,
      child: ContentColumn(
        enabled: !fullWidth,
        child: HeroControllerScope.none(
          child: Navigator(
            key: widget.navigatorKey,
            observers: [_observer],
            onGenerateRoute: (settings) => MaterialPageRoute<void>(
              settings: settings,
              builder: widget.homeBuilder,
            ),
          ),
        ),
      ),
    );
  }
}
