import 'package:flutter/material.dart';

import '../config.dart';
import '../theme/app_colors.dart';

/// Foto do grupo (ou inicial do nome sobre o gradiente da marca).
class GroupAvatar extends StatelessWidget {
  final String name;
  final String? url;
  final double radius;

  const GroupAvatar({super.key, required this.name, this.url, this.radius = 26});

  @override
  Widget build(BuildContext context) {
    if (url != null) {
      return CircleAvatar(radius: radius, backgroundColor: AppColors.surface2, backgroundImage: NetworkImage(resolveMediaUrl(url!)));
    }
    return Container(
      width: radius * 2,
      height: radius * 2,
      alignment: Alignment.center,
      decoration: BoxDecoration(shape: BoxShape.circle, gradient: AppGradients.brand),
      child: Text(
        name.isNotEmpty ? name[0].toUpperCase() : '?',
        style: TextStyle(color: AppColors.onBrand, fontWeight: FontWeight.w700, fontSize: radius * 0.85),
      ),
    );
  }
}
