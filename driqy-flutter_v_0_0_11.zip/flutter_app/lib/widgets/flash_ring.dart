import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/flash.dart';
import '../screens/flash_viewer_screen.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/flash_service.dart';
import '../theme/app_colors.dart';

/// Anel colorido (gradiente âmbar→rosa da rede) em volta de um avatar quando a pessoa
/// tem um Flash ativo. Cinza quando o espectador já viu tudo. Sem Flash, devolve [child].
class FlashRing extends StatelessWidget {
  final Widget child;
  final bool hasFlash;
  final bool unseen;
  final double thickness;
  final double gap;

  const FlashRing({
    super.key,
    required this.child,
    required this.hasFlash,
    this.unseen = true,
    this.thickness = 2.5,
    this.gap = 2,
  });

  @override
  Widget build(BuildContext context) {
    if (!hasFlash) return child;
    return Container(
      padding: EdgeInsets.all(thickness),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: unseen ? AppGradients.brand : null,
        color: unseen ? null : AppColors.border,
      ),
      child: Container(
        padding: EdgeInsets.all(gap),
        decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.bg),
        child: child,
      ),
    );
  }
}

/// Abre o visualizador de Flash de [username] (e, ao fechar, chama [onClosed]).
Future<void> openFlash(BuildContext context, List<String> usernames,
    {int startIndex = 0, VoidCallback? onClosed}) async {
  // raiz: o visualizador cobre a janela toda (em tela larga o miolo tem um Navigator próprio)
  await Navigator.of(context, rootNavigator: true).push(
    PageRouteBuilder<void>(
      opaque: true,
      transitionDuration: const Duration(milliseconds: 180),
      pageBuilder: (_, __, ___) => FlashViewerScreen(usernames: usernames, startIndex: startIndex),
      transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
    ),
  );
  onClosed?.call();
}

/// Escolhe uma foto, pede a legenda e publica o Flash (vive 24h). Devolve true se publicou.
Future<bool> publishFlash(BuildContext context) async {
  final service = FlashService(context.read<AuthService>().client);
  final messenger = ScaffoldMessenger.of(context);
  final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 92, maxWidth: 1600);
  if (picked == null || !context.mounted) return false;
  final file = File(picked.path);
  final captionCtrl = TextEditingController();
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
    builder: (ctx) {
      bool sending = false;
      return StatefulBuilder(builder: (ctx, setState) {
        return Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 360),
                  child: Image.file(file, fit: BoxFit.contain),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: captionCtrl,
                maxLength: 200,
                decoration: const InputDecoration(hintText: 'Legenda (opcional)'),
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: sending ? null : () => Navigator.pop(ctx, false),
                      child: const Text('Cancelar'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: sending
                          ? null
                          : () async {
                              setState(() => sending = true);
                              try {
                                await service.publish(file, caption: captionCtrl.text.trim());
                                if (ctx.mounted) Navigator.pop(ctx, true);
                              } on ApiException catch (e) {
                                messenger.showSnackBar(SnackBar(content: Text(e.message)));
                                setState(() => sending = false);
                              } catch (_) {
                                messenger.showSnackBar(
                                    const SnackBar(content: Text('Não foi possível publicar o Flash.')));
                                setState(() => sending = false);
                              }
                            },
                      child: Text(sending ? 'Enviando…' : 'Publicar Flash (24h)'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      });
    },
  );
  captionCtrl.dispose();
  return ok == true;
}

/// Bandeja horizontal do topo do feed: "Seu Flash" + quem eu sigo com Flash ativo.
class FlashTrayBar extends StatefulWidget {
  const FlashTrayBar({super.key});

  @override
  State<FlashTrayBar> createState() => FlashTrayBarState();
}

class FlashTrayBarState extends State<FlashTrayBar> {
  late final FlashService _service;
  FlashTray? _tray;

  @override
  void initState() {
    super.initState();
    _service = FlashService(context.read<AuthService>().client);
    reload();
  }

  Future<void> reload() async {
    try {
      final t = await _service.tray();
      if (mounted) setState(() => _tray = t);
    } catch (_) {
      // sem bandeja (rede/versão antiga do servidor): simplesmente não mostra
    }
  }

  Widget _bubble({
    required FlashOwner user,
    required String label,
    required bool hasFlash,
    required bool unseen,
    required VoidCallback onTap,
    bool showAdd = false,
    VoidCallback? onAdd,
  }) {
    final avatar = CircleAvatar(
      radius: 28,
      backgroundColor: AppColors.surface2,
      backgroundImage: user.avatarUrl != null ? NetworkImage(resolveMediaUrl(user.avatarUrl!)) : null,
      child: user.avatarUrl == null ? Text(user.displayName[0].toUpperCase()) : null,
    );
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 74,
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                FlashRing(hasFlash: hasFlash, unseen: unseen, child: avatar),
                if (showAdd)
                  Positioned(
                    right: -2,
                    bottom: -2,
                    child: GestureDetector(
                      onTap: onAdd,
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          color: AppColors.amber,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.bg, width: 2),
                        ),
                        child: Icon(Icons.add, size: 15, color: AppColors.onBrand),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 11.5, color: AppColors.textMuted)),
          ],
        ),
      ),
    );
  }

  Future<void> _add() async {
    if (await publishFlash(context)) reload();
  }

  @override
  Widget build(BuildContext context) {
    final t = _tray;
    if (t == null) return const SizedBox.shrink();
    // sem Flash de ninguém (nem meu): a bandeja some; aparece quando alguém publicar
    if (t.myCount == 0 && t.items.isEmpty) return const SizedBox.shrink();
    final queue = t.items.map((e) => e.user.username).toList();
    return SizedBox(
      height: 98,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
        children: [
          _bubble(
            user: t.me,
            label: 'Seu Flash',
            hasFlash: t.myCount > 0,
            unseen: false,
            showAdd: true,
            onAdd: _add,
            onTap: () => t.myCount > 0
                ? openFlash(context, [t.me.username], onClosed: reload)
                : _add(),
          ),
          for (var i = 0; i < t.items.length; i++)
            _bubble(
              user: t.items[i].user,
              label: t.items[i].user.displayName,
              hasFlash: true,
              unseen: t.items[i].unseen,
              onTap: () => openFlash(context, queue, startIndex: i, onClosed: reload),
            ),
        ],
      ),
    );
  }
}
