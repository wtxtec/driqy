import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../services/api_exception.dart';
import '../services/auth_service.dart';
import '../services/post_service.dart';
import '../theme/app_colors.dart';
import '../screens/profile_screen.dart';
import '../theme/app_spacing.dart';
import 'gradient_button.dart';

/// Mesmas opções de duração de templates/create_post.html / config.py
/// DURATION_PRESETS, em minutos.
const List<(int, String)> kDurationPresets = [
  (1, '1 minuto'),
  (5, '5 minutos'),
  (30, '30 minutos'),
  (60, '1 hora'),
  (360, '6 horas'),
  (1440, '1 dia'),
  (4320, '3 dias'),
  (10080, '1 semana'),
  (43200, '1 mês'),
  (129600, '3 meses'),
  (259200, '6 meses'),
  (525600, '1 ano'),
];

/// Caixa de "O que está acontecendo?" direto no topo do feed — igual ao
/// composer do site (`templates/feed.html`), em vez de abrir uma tela
/// separada. Ao publicar com sucesso, chama [onPosted].
class InlinePostComposer extends StatefulWidget {
  final VoidCallback onPosted;

  const InlinePostComposer({super.key, required this.onPosted});

  @override
  State<InlinePostComposer> createState() => _InlinePostComposerState();
}

class _InlinePostComposerState extends State<InlinePostComposer> {
  final _textController = TextEditingController();
  final List<XFile> _pickedFiles = [];
  int _durationMinutes = 0; // 0 = sem expiração (padrão); > 0 = post temporário
  bool _posting = false;
  String? _error;

  late PostService _postService;

  @override
  void initState() {
    super.initState();
    _postService = PostService(context.read<AuthService>().client);
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  bool get _isVideoSelection =>
      _pickedFiles.isNotEmpty && (_pickedFiles.first.mimeType?.startsWith('video/') ?? false);

  Future<void> _pickMedia() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.image_outlined, color: AppColors.text),
              title: Text('Fotos', style: TextStyle(color: AppColors.text)),
              onTap: () => Navigator.pop(ctx, 'photo'),
            ),
            ListTile(
              leading: Icon(Icons.videocam_outlined, color: AppColors.text),
              title: Text('Vídeo', style: TextStyle(color: AppColors.text)),
              onTap: () => Navigator.pop(ctx, 'video'),
            ),
          ],
        ),
      ),
    );
    if (choice == 'photo') {
      try {
        final files = await ImagePicker().pickMultiImage(limit: 10);
        if (files.isNotEmpty) {
          setState(() {
            _pickedFiles
              ..clear()
              ..addAll(files);
          });
        }
      } catch (_) {
        _showSnack('Não foi possível abrir a galeria.');
      }
    } else if (choice == 'video') {
      try {
        final file = await ImagePicker().pickVideo(source: ImageSource.gallery);
        if (file != null) {
          setState(() {
            _pickedFiles
              ..clear()
              ..add(file);
          });
        }
      } catch (_) {
        _showSnack('Não foi possível abrir a galeria.');
      }
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _removeFile(XFile file) => setState(() => _pickedFiles.remove(file));

  /// Mesmo agrupamento do painel do site (`_composer.html`).
  static String _groupOf(int minutes) {
    if (minutes <= 360) return 'Minutos e horas';
    if (minutes <= 10080) return 'Dias e semanas';
    return 'Meses e anos';
  }

  /// Folha (bottom sheet) igual à do site no mobile: alça, título, botão
  /// fechar, grupos com rótulo em caixa alta e opções em 2 colunas.
  Future<void> _pickDuration() async {
    final maxHeight = MediaQuery.of(context).size.height * 0.75;
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      barrierColor: const Color(0x8008060A),
      constraints: BoxConstraints(maxHeight: maxHeight),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) {
        final groups = <String, List<(int, String)>>{};
        for (final preset in kDurationPresets) {
          groups.putIfAbsent(_groupOf(preset.$1), () => []).add(preset);
        }
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(top: 10, bottom: 2),
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Tornar este post temporário? (opcional)',
                        style: TextStyle(
                            color: AppColors.text, fontWeight: FontWeight.w600, fontSize: 15.2),
                      ),
                    ),
                    InkWell(
                      onTap: () => Navigator.pop(ctx),
                      customBorder: const CircleBorder(),
                      child: Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Icon(Icons.close, size: 16, color: AppColors.textMuted),
                      ),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(14, 6, 14, 18),
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      // `flex: 1 1 calc(50% - 10px)` com gap de 10px.
                      final optWidth = (constraints.maxWidth - 10) / 2;
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _DurationOption(
                            width: optWidth,
                            label: 'Sem expiração',
                            selected: _durationMinutes == 0,
                            onTap: () => Navigator.pop(ctx, 0),
                          ),
                          const SizedBox(height: 18),
                          for (final entry in groups.entries) ...[
                            // (sem expiração é a primeira opção, acima dos grupos)
                            if (entry.key != groups.keys.first) const SizedBox(height: 18),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(2, 0, 2, 8),
                              child: Text(
                                entry.key.toUpperCase(),
                                style: TextStyle(
                                  fontSize: 10.9,
                                  letterSpacing: 0.76,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ),
                            Wrap(
                              spacing: 10,
                              runSpacing: 10,
                              children: [
                                for (final preset in entry.value)
                                  _DurationOption(
                                    width: optWidth,
                                    label: preset.$2,
                                    selected: preset.$1 == _durationMinutes,
                                    onTap: () => Navigator.pop(ctx, preset.$1),
                                  ),
                              ],
                            ),
                          ],
                        ],
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
    if (selected != null) setState(() => _durationMinutes = selected);
  }

  /// Mesmo modal "Confirmar publicação" do site (`publish-confirm.js`).
  Future<bool> _confirmPublish() async {
    final result = await showDialog<bool>(
      context: context,
      barrierColor: const Color(0xD908060A),
      builder: (ctx) => Dialog(
        backgroundColor: AppColors.surface,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: AppColors.border),
        ),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Confirmar publicação',
                        style: TextStyle(
                            color: AppColors.text, fontSize: 17.6, fontWeight: FontWeight.w600),
                      ),
                    ),
                    InkWell(
                      onTap: () => Navigator.pop(ctx, false),
                      customBorder: const CircleBorder(),
                      child: Container(
                        width: 26,
                        height: 26,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: AppColors.surface2),
                        child: Icon(Icons.close, size: 12, color: AppColors.textMuted),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'Esse post vai ficar visível por $_durationLabel e depois some sozinho '
                  '(você também pode excluí-lo antes, quando quiser). Confirma a publicação?',
                  style: TextStyle(
                      color: AppColors.textMuted, fontSize: 14.7, height: 1.5),
                ),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: const Text('Cancelar', style: TextStyle(fontSize: 14)),
                    ),
                    const SizedBox(width: 10),
                    GradientButton(
                      height: 38,
                      fontSize: 15.2,
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Publicar'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    return result ?? false;
  }

  Future<void> _submit() async {
    final text = _textController.text.trim();
    if (_pickedFiles.isEmpty && text.isEmpty) {
      setState(() => _error = 'Escreva algo ou selecione uma foto/vídeo para publicar.');
      return;
    }
    FocusScope.of(context).unfocus();
    // só posts temporários passam pela confirmação de tempo
    if (_durationMinutes > 0 && !await _confirmPublish()) return;
    if (!mounted) return;
    setState(() {
      _posting = true;
      _error = null;
    });
    try {
      if (_pickedFiles.isEmpty) {
        await _postService.createTextPost(textContent: text, durationMinutes: _durationMinutes);
      } else {
        final postType = _isVideoSelection ? 'video' : 'photo';
        await _postService.createMediaPost(
          postType: postType,
          textContent: text,
          durationMinutes: _durationMinutes,
          files: _pickedFiles.map((f) => File(f.path)).toList(),
        );
      }
      _textController.clear();
      setState(() => _pickedFiles.clear());
      widget.onPosted();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'Não foi possível publicar agora.');
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  String get _durationLabel =>
      kDurationPresets.firstWhere((p) => p.$1 == _durationMinutes, orElse: () => kDurationPresets[5]).$2;

  static const double _avatarSize = 38; // `.composer-avatar` (mobile)

  Widget _buildAvatar() {
    final user = context.read<AuthService>().currentUser;
    final avatarUrl = user?.avatarUrl;
    final avatar = Container(
      width: _avatarSize,
      height: _avatarSize,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: avatarUrl == null
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.accentFromKey(user?.accentColor), AppColors.rose],
              )
            : null,
        image: avatarUrl != null
            ? DecorationImage(image: NetworkImage(resolveMediaUrl(avatarUrl)), fit: BoxFit.cover)
            : null,
      ),
      alignment: Alignment.center,
      child: avatarUrl == null
          ? Text(
              (user?.username.isNotEmpty ?? false) ? user!.username[0].toUpperCase() : '?',
              style: TextStyle(
                  color: AppColors.onBrand, fontWeight: FontWeight.w700, fontSize: 16),
            )
          : null,
    );
    if (user == null) return avatar;
    // tocar na própria foto leva ao próprio perfil
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => ProfileScreen(username: user.username)),
      ),
      child: avatar,
    );
  }

  @override
  Widget build(BuildContext context) {
    final len = _textController.text.length;
    return Container(
      margin: const EdgeInsets.all(AppSpacing.gap),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), // `.composer-card` (mobile)
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildAvatar(),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // `#composer-text`: sem fundo/borda, 16px, line-height 1.4, padding 9px 0.
                // Sem caixa: o tema global pinta todo TextField com fundo e
                // borda, então aqui o tema é zerado (e o decoration é
                // `collapsed`) pra ficar igual ao `#composer-text` do site.
                Theme(
                  data: Theme.of(context).copyWith(
                    inputDecorationTheme: const InputDecorationTheme(
                      filled: false,
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      focusedErrorBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    child: TextField(
                      controller: _textController,
                      minLines: 1,
                      maxLines: null,
                      maxLength: 1000,
                      onChanged: (_) => setState(() => _error = null),
                      cursorColor: AppColors.amber,
                      style: TextStyle(color: AppColors.text, fontSize: 16, height: 1.4),
                      decoration: InputDecoration.collapsed(
                        hintText: 'O que está acontecendo?',
                        hintStyle:
                            TextStyle(color: AppColors.textMuted, fontSize: 16, height: 1.4),
                        border: InputBorder.none,
                      ),
                      buildCounter: (_,
                              {required currentLength, required isFocused, maxLength}) =>
                          null,
                    ),
                  ),
                ),
                if (_pickedFiles.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  SizedBox(
                    height: 80,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _pickedFiles.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, index) {
                        final file = _pickedFiles[index];
                        final isVideo = file.mimeType?.startsWith('video/') ?? false;
                        return Stack(
                          children: [
                            Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: AppColors.border),
                                color: AppColors.surface2,
                                image: isVideo
                                    ? null
                                    : DecorationImage(
                                        image: FileImage(File(file.path)), fit: BoxFit.cover),
                              ),
                              child: isVideo
                                  ? const Center(child: Icon(Icons.play_circle_fill, size: 28))
                                  : null,
                            ),
                            Positioned(
                              top: 2,
                              right: 2,
                              child: GestureDetector(
                                onTap: () => _removeFile(file),
                                child: const CircleAvatar(
                                  radius: 9,
                                  backgroundColor: Colors.black54,
                                  child: Icon(Icons.close, size: 12, color: Colors.white),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
                const SizedBox(height: 6),
                // `.composer-toolbar`: chip de duração à esquerda; contador, "+" e
                // "Postar" à direita, com 8px de gap.
                Row(
                  children: [
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: _pickDuration,
                          borderRadius: BorderRadius.circular(999),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.access_time_filled,
                                    size: 14, color: AppColors.amber),
                                const SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    _durationMinutes == 0 ? 'Sem expiração' : 'Some em $_durationLabel',
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: AppColors.amber, fontSize: 12.5),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Icon(Icons.keyboard_arrow_down,
                                    size: 14,
                                    color: AppColors.amber.withValues(alpha: 0.65)),
                              ],
                            ),
                          ),
                        ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (len > 800) ...[
                      Text(
                        '${1000 - len}',
                        style: TextStyle(
                          fontSize: 12,
                          color: len >= 1000 ? AppColors.danger : AppColors.textMuted,
                        ),
                      ),
                      const SizedBox(width: 8),
                    ],
                    // `.composer-attach-btn`: círculo 34px, borda, "+" âmbar.
                    Material(
                      color: Colors.transparent,
                      shape: CircleBorder(side: BorderSide(color: AppColors.border)),
                      child: InkWell(
                        onTap: _pickMedia,
                        customBorder: const CircleBorder(),
                        child: SizedBox(
                          width: 34,
                          height: 34,
                          child: Icon(Icons.add, size: 18, color: AppColors.amber),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // `.btn.composer-post-btn`: padding 8x20, fonte 0.9rem. Sempre
                    // aceso (só apaga enquanto está publicando).
                    GradientButton(
                      height: 34,
                      fontSize: 14.4,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      onPressed: _posting ? null : _submit,
                      child: _posting
                          ? SizedBox(
                              height: 16,
                              width: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: AppColors.onBrand),
                            )
                          : const Text('Postar'),
                    ),
                  ],
                ),
                if (_error != null) ...[
                  const SizedBox(height: 8),
                  Text(_error!, style: TextStyle(color: AppColors.danger, fontSize: 13)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Opção do painel de duração (`.composer-duration-opt`): pílula com borda;
/// selecionada fica rosa com fundo translúcido e um check à direita.
class _DurationOption extends StatelessWidget {
  final double width;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _DurationOption({
    required this.width,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.rose : AppColors.textMuted;
    return SizedBox(
      width: width,
      child: Material(
        color: selected ? AppColors.rose.withValues(alpha: 0.1) : Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: selected ? AppColors.rose : AppColors.border),
        ),
        child: InkWell(
          onTap: onTap,
          customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(label,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: color, fontSize: 14.7)),
                ),
                Opacity(
                  opacity: selected ? 1 : 0,
                  child: Icon(Icons.check, size: 15, color: color),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
