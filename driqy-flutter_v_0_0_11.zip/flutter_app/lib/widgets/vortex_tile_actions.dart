import 'package:flutter/material.dart';

import '../models/picture_tile.dart';
import '../services/pictures_service.dart';
import '../theme/vortex_theme.dart';

/// O que a pessoa pode fazer com uma peça direto na grade (segurar o dedo).
enum VortexTileAction { open, less }

/// Peças que a pessoa curtiu / escondeu nesta tela. Mora no `State` da tela e
/// vale só até ela fechar: o servidor guarda o sinal de verdade (`/vortex/interact`).
class VortexTileReactions {
  final Set<String> liked = {};
  final Set<String> hidden = {};
}

/// Folha de baixo com Abrir / Menos disso (o Curtir fica dentro da imagem, na tela do item) (estilo Pinterest: segurar
/// a peça). Devolve a escolha, ou null se a pessoa só fechou.
Future<VortexTileAction?> showVortexTileActions(
  BuildContext context,
  PictureTile tile, {
  bool liked = false,
}) {
  final c = VortexColors.of(context);
  final name = tile.title.isNotEmpty
      ? tile.title
      : (tile.profile?.displayName ?? (tile.author != null ? '@${tile.author!.username}' : ''));

  return showModalBottomSheet<VortexTileAction>(
    context: context,
    backgroundColor: Theme.of(context).colorScheme.surface,
    showDragHandle: true,
    builder: (sheetContext) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (name.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(
                name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: c.textMuted, fontSize: 13),
              ),
            ),
          ListTile(
            leading: const Icon(Icons.open_in_full),
            title: const Text('Abrir'),
            onTap: () => Navigator.of(sheetContext).pop(VortexTileAction.open),
          ),
          ListTile(
            leading: const Icon(Icons.thumb_down_alt_outlined),
            title: const Text('Menos disso'),
            subtitle: const Text('Esconder e mostrar menos coisas assim'),
            onTap: () => Navigator.of(sheetContext).pop(VortexTileAction.less),
          ),
        ],
      ),
    ),
  );
}

/// Abre a folha de ações da peça e faz o que a pessoa escolher:
/// - **Abrir** → [onOpen];
/// - **Curtir** → sinal `like` no servidor + coração na peça;
/// - **Menos disso** → sinal `less` no servidor + a peça some da grade (o
///   servidor também nunca mais a devolve) + aviso com **Desfazer** (manda
///   `undo_less`: a peça volta na hora e deixa de ser rejeitada).
///
/// [onChanged] deve fazer `setState` na tela (as peças curtidas/escondidas
/// ficam em [reactions]).
Future<void> reactToTile({
  required BuildContext context,
  required PicturesService service,
  required PictureTile tile,
  required VortexTileReactions reactions,
  required VoidCallback onChanged,
  required VoidCallback onOpen,
}) async {
  final action = await showVortexTileActions(
    context,
    tile,
    liked: reactions.liked.contains(tile.key),
  );
  if (action == null || !context.mounted) return;

  final messenger = ScaffoldMessenger.of(context);
  switch (action) {
    case VortexTileAction.open:
      onOpen();
      break;
    case VortexTileAction.less:
      service.trackInteraction(postId: tile.postId, itemId: tile.itemId, kind: 'less');
      reactions.hidden.add(tile.key);
      reactions.liked.remove(tile.key);
      onChanged();
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(
          content: const Text('Ok, vamos mostrar menos disso.'),
          duration: const Duration(seconds: 6),
          action: SnackBarAction(
            label: 'Desfazer',
            onPressed: () {
              // O servidor apaga o sinal negativo e tira a peça das rejeitadas.
              service.trackInteraction(
                  postId: tile.postId, itemId: tile.itemId, kind: 'undo_less');
              reactions.hidden.remove(tile.key);
              onChanged();
            },
          ),
        ));
      break;
  }
}

/// Coração pequeno no canto da peça curtida.
class VortexLikedBadge extends StatelessWidget {
  const VortexLikedBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
      child: const Icon(Icons.favorite, size: 14, color: Color(0xFFE85D75)),
    );
  }
}
