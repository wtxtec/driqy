import 'dart:async';

import 'package:flutter/material.dart';

import '../models/rail_widgets.dart';
import '../services/widgets_service.dart';
import '../theme/app_colors.dart';

/// Campo de cidade com sugestões (cidade, estado e país) enquanto a pessoa digita.
/// As sugestões vêm de `GET /api/v1/places/search`; escolher uma chama [onSelected]. Digitar à mão
/// chama [onTyped] (quem usa descarta as coordenadas escolhidas antes).
class PlaceField extends StatefulWidget {
  final TextEditingController controller;
  final WidgetsService service;
  final ValueChanged<PlaceSuggestion> onSelected;
  final VoidCallback? onTyped;
  final String hintText;
  final int maxLength;
  final bool autofocus;
  final Duration debounce;

  const PlaceField({
    super.key,
    required this.controller,
    required this.service,
    required this.onSelected,
    this.onTyped,
    this.hintText = 'Comece a digitar sua cidade…',
    this.maxLength = 80,
    this.autofocus = false,
    this.debounce = const Duration(milliseconds: 300),
  });

  @override
  State<PlaceField> createState() => _PlaceFieldState();
}

class _PlaceFieldState extends State<PlaceField> {
  Timer? _timer;
  int _seq = 0;
  List<PlaceSuggestion> _items = const [];
  bool _searched = false;
  String _query = '';

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _onChanged(String text) {
    widget.onTyped?.call();
    _timer?.cancel();
    final q = text.trim();
    if (q.length < 2) {
      _seq++;
      setState(() {
        _items = const [];
        _searched = false;
      });
      return;
    }
    _timer = Timer(widget.debounce, () async {
      final mine = ++_seq;
      final res = await widget.service.searchPlaces(q);
      if (!mounted || mine != _seq) return; // resposta velha
      setState(() {
        _items = res;
        _searched = true;
        _query = q;
      });
    });
  }

  void _pick(PlaceSuggestion p) {
    _seq++;
    _timer?.cancel();
    widget.controller.text = p.label.length > widget.maxLength ? p.label.substring(0, widget.maxLength) : p.label;
    widget.controller.selection = TextSelection.collapsed(offset: widget.controller.text.length);
    setState(() {
      _items = const [];
      _searched = false;
    });
    FocusScope.of(context).unfocus();
    widget.onSelected(p);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: widget.controller,
          maxLength: widget.maxLength,
          autofocus: widget.autofocus,
          onChanged: _onChanged,
          decoration: InputDecoration(
            counterText: '',
            hintText: widget.hintText,
            prefixIcon: const Icon(Icons.place_outlined, size: 20),
          ),
        ),
        if (_searched)
          Container(
            margin: const EdgeInsets.only(top: 6),
            constraints: const BoxConstraints(maxHeight: 240),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: _items.isEmpty
                ? Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text('Nenhuma cidade encontrada para “$_query”.',
                        style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    itemCount: _items.length,
                    itemBuilder: (_, i) {
                      final p = _items[i];
                      return InkWell(
                        onTap: () => _pick(p),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.name, style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w600)),
                              if (p.subtitle.isNotEmpty)
                                Text(p.subtitle, style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
      ],
    );
  }
}
