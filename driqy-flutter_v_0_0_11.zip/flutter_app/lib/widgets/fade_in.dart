import 'package:flutter/material.dart';

/// Faz o filho surgir com um leve fade + slide de baixo pra cima,
/// reproduzindo a animação `post-arrive` do CSS (usada quando um post ou
/// notificação novo aparece na lista).
class FadeSlideIn extends StatelessWidget {
  final Widget child;
  final Duration duration;

  const FadeSlideIn({super.key, required this.child, this.duration = const Duration(milliseconds: 380)});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: duration,
      curve: Curves.easeOut,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(offset: Offset(0, (1 - value) * 14), child: child),
        );
      },
      child: child,
    );
  }
}
