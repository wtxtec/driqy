import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import 'config.dart';
import 'package:provider/provider.dart';

import 'screens/home_shell.dart';
import 'screens/login_screen.dart';
import 'screens/group_thread_screen.dart';
import 'screens/message_thread_screen.dart';
import 'screens/messages_inbox_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/post_detail_screen.dart';
import 'screens/profile_screen.dart';
import 'services/auth_service.dart';
import 'services/call_manager.dart';
import 'services/push_notification_service.dart';
import 'theme/app_theme.dart';
import 'theme/vortex_theme.dart';

/// Usado pra navegar a partir do toque numa notificação, mesmo sem um
/// BuildContext de tela à mão (ex: app foi aberto do zero pelo toque).
final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await loadApiBaseUrl(); // endereço do servidor salvo no aparelho
  await VortexThemeController.instance.load(); // tema do Vortex (claro/escuro) salvo no aparelho
  await Firebase.initializeApp();

  // Precisa ser registrado ANTES do runApp: é o que garante que uma
  // mensagem chegando com o app minimizado ou totalmente fechado seja
  // processada (e, no caso do payload ter bloco "notification", exibida
  // pelo próprio Android/iOS com som).
  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  runApp(
    ChangeNotifierProvider(
      create: (_) => AuthService(),
      child: const DriqyApp(),
    ),
  );
}

class DriqyApp extends StatelessWidget {
  const DriqyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = VortexThemeController.instance;
    return AnimatedBuilder(
      animation: theme,
      builder: (context, _) => MaterialApp(
        title: 'driqy',
        navigatorKey: navigatorKey,
        debugShowCheckedModeBanner: false,
        // Identidade Driqy nos dois temas (mesmos tokens do site: gradiente
        // âmbar→rosa, fontes Baloo 2 / Fraunces / Inter). A escolha fica salva.
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: theme.isLight ? ThemeMode.light : ThemeMode.dark,
        // `AppColors` não é herdado pela árvore: ao trocar o tema, refaz todas as telas
        // já abertas (sem perder o estado delas).
        builder: (context, child) => _RebuildOnTheme(child: child ?? const SizedBox.shrink()),
        home: const AuthGate(),
      ),
    );
  }
}

/// Marca todos os widgets abaixo para reconstruir quando o tema muda, para que as cores
/// lidas de `AppColors` nas telas abertas (e nas rotas empilhadas) sejam atualizadas.
class _RebuildOnTheme extends StatefulWidget {
  final Widget child;
  const _RebuildOnTheme({required this.child});

  @override
  State<_RebuildOnTheme> createState() => _RebuildOnThemeState();
}

class _RebuildOnThemeState extends State<_RebuildOnTheme> {
  @override
  void initState() {
    super.initState();
    VortexThemeController.instance.addListener(_onTheme);
  }

  @override
  void dispose() {
    VortexThemeController.instance.removeListener(_onTheme);
    super.dispose();
  }

  void _onTheme() {
    // depois do frame em que o MaterialApp recebeu o tema novo
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      void rebuild(Element el) {
        el.markNeedsBuild();
        el.visitChildren(rebuild);
      }

      (context as Element).visitChildren(rebuild);
    });
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

/// Trata o toque numa notificação (push chegou, usuário tocou) e decide
/// pra qual tela navegar, usando o `data` que o backend deve mandar
/// junto do payload (ex: {"type": "message", "username": "fulano"}).
void _handleNotificationTap(Map<String, dynamic> data) {
  final nav = navigatorKey.currentState;
  if (nav == null) return;
  final type = data['type'] as String?;
  final username = data['username'] as String?;
  final postId = int.tryParse('${data['post_id'] ?? ''}');
  final kind = data['kind'] as String?;
  switch (type) {
    case 'call':
      // Fase 12: tocou na notificação de chamada -> mostra a tela de chamada (se ainda tocando).
      // Fase 14: botões Atender/Recusar da notificação de tela cheia chegam em `_action`.
      PushNotificationService.instance.cancelIncomingCall();
      CallManager.instance.handleNotificationAction(
        data['_action'] as String?,
        int.tryParse('${data['call_id'] ?? ''}'),
      );
      break;
    case 'call_missed':
      if (username != null) {
        nav.push(MaterialPageRoute(builder: (_) => MessageThreadScreen(username: username)));
      }
      break;
    case 'message':
      if (username != null) {
        nav.push(MaterialPageRoute(builder: (_) => MessageThreadScreen(username: username)));
      } else {
        nav.push(MaterialPageRoute(builder: (_) => const MessagesInboxScreen()));
      }
      break;
    case 'group_message':
      // Mensagens parte 4: toque na notificação de grupo abre a conversa do grupo.
      final gid = int.tryParse('${data['group_id'] ?? ''}');
      if (gid != null) {
        nav.push(MaterialPageRoute(builder: (_) => GroupThreadScreen(groupId: gid)));
      } else {
        nav.push(MaterialPageRoute(builder: (_) => const MessagesInboxScreen()));
      }
      break;
    default:
      // Nova seguida abre o perfil de quem seguiu; curtida/comentário abre
      // o post; sem dados suficientes, cai na lista de notificações.
      if (kind == 'follow' && username != null) {
        nav.push(MaterialPageRoute(builder: (_) => ProfileScreen(username: username)));
      } else if (postId != null) {
        nav.push(MaterialPageRoute(builder: (_) => PostDetailScreen(postId: postId)));
      } else {
        nav.push(MaterialPageRoute(builder: (_) => const NotificationsScreen()));
      }
  }
}

/// Decide qual tela mostrar de acordo com o estado de login: enquanto
/// checa o token salvo mostra um splash simples; depois alterna
/// automaticamente entre LoginScreen e FeedScreen conforme o usuário
/// entra ou sai (logout), sem precisar navegar manualmente.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  AuthStatus? _previousStatus;

  @override
  void initState() {
    super.initState();
    PushNotificationService.instance.onNotificationTap = _handleNotificationTap;
    PushNotificationService.instance.onCallPush = CallManager.instance.onCallPush;
    PushNotificationService.instance.init();
    context.read<AuthService>().tryAutoLogin();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final status = auth.status;

    // Assim que o login é confirmado (autologin ou login manual), manda
    // o token do FCM pro backend salvar contra esse usuário. Só dispara
    // uma vez por transição unauthenticated/unknown -> authenticated.
    if (status == AuthStatus.authenticated && _previousStatus != AuthStatus.authenticated) {
      PushNotificationService.instance.registerDeviceToken(auth.client);
      // Fase 12: chamadas de voz em qualquer tela (stream de eventos + WebRTC).
      CallManager.instance.attach(auth.client, navigatorKey);
    } else if (status == AuthStatus.unauthenticated && _previousStatus == AuthStatus.authenticated) {
      CallManager.instance.detach();
    }
    _previousStatus = status;

    switch (status) {
      case AuthStatus.unknown:
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      case AuthStatus.authenticated:
        return const HomeShell();
      case AuthStatus.unauthenticated:
        return const LoginScreen();
    }
  }
}
