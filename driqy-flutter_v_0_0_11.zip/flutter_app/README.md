# driqy_flutter

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Learn Flutter](https://docs.flutter.dev/get-started/learn-flutter)
- [Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Flutter learning resources](https://docs.flutter.dev/reference/learning-resources)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


## Chat
O chat (texto, emojis, reações, fotos/GIF, vídeo, áudio, documentos, chamadas de voz e vídeo) foi feito em 15 fases; veja `PROGRESSO_CHAT.md` para o que existe e o que falta.
Depois de baixar o projeto rode `flutter pub get`, `flutter analyze` e `flutter test`. **O código do chat nunca foi compilado pela IA que o escreveu**: espere pequenos ajustes de build.
Dependências nativas do chat: `emoji_picker_flutter`, `record`, `just_audio`, `flutter_webrtc`, `file_picker`, `path_provider`, `open_filex`.
