package com.wtxtec.driqy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
