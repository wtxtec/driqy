"""
Disparo de push notifications (FCM) pro app Flutter.

Fica isolado num módulo próprio (em vez de dentro de models.py) porque
precisa do pacote `firebase-admin`, que é opcional: se ele não estiver
instalado, ou se a chave de serviço do Firebase ainda não tiver sido
configurada, o site inteiro continua funcionando normalmente — só o
push é pulado (com um aviso no log, uma vez só). Ninguém deveria
conseguir derrubar o backend inteiro (likes, comentários, mensagens)
só porque uma etapa opcional de push não está pronta ainda.
"""
import os
import time
from datetime import timedelta

from extensions import db

_warned = False
_app = None
_init_attempted = False


def _get_firebase_app():
    """Inicializa o Firebase Admin SDK de forma preguiçosa (só na
    primeira vez que alguém tenta mandar um push) e devolve o app, ou
    None se não tiver como (pacote ausente ou chave não configurada)."""
    global _app, _init_attempted, _warned

    if _init_attempted:
        return _app
    _init_attempted = True

    key_path = os.environ.get(
        "FIREBASE_SERVICE_ACCOUNT",
        os.path.join(os.path.dirname(__file__), "instance", "firebase-service-account.json"),
    )
    if not os.path.exists(key_path):
        if not _warned:
            print(
                f"[push] Aviso: chave de serviço do Firebase não encontrada em "
                f"'{key_path}'. Pushes ficam desativados até você gerar essa chave "
                f"no Firebase Console (veja BACKEND_FCM_FLASK.md) e definir o "
                f"caminho dela na variável de ambiente FIREBASE_SERVICE_ACCOUNT, "
                f"ou colocar o arquivo nesse caminho padrão."
            )
            _warned = True
        return None

    try:
        import firebase_admin
        from firebase_admin import credentials
    except ImportError:
        if not _warned:
            print(
                "[push] Aviso: pacote 'firebase-admin' não está instalado "
                "(pip install firebase-admin). Pushes ficam desativados."
            )
            _warned = True
        return None

    try:
        cred = credentials.Certificate(key_path)
        _app = firebase_admin.initialize_app(cred)
    except Exception as exc:  # chave inválida, projeto errado, etc.
        if not _warned:
            print(f"[push] Aviso: falha ao inicializar o Firebase Admin SDK: {exc}")
            _warned = True
        return None

    return _app


def send_push_to_user(user_id, title, body, data=None, count=None):
    """
    Manda um push pra todos os aparelhos logados do usuário `user_id`.
    Nunca levanta exceção pro chamador — se o Firebase não estiver
    configurado, ou a chamada à API do FCM falhar por qualquer motivo,
    isso é só logado, porque quem chama essa função está no meio de
    salvar uma curtida/comentário/mensagem e essa ação não deve
    quebrar por causa do push.
    """
    app = _get_firebase_app()
    if app is None:
        return

    # Import local: só precisamos do modelo quando formos usar o banco,
    # e assim evitamos qualquer chance de import circular com models.py.
    from models import DeviceToken

    tokens = [d.token for d in DeviceToken.query.filter_by(user_id=user_id).all()]
    if not tokens:
        return

    from firebase_admin import messaging

    data = {k: str(v) for k, v in (data or {}).items()}

    # Dois canais no app Flutter, cada um com seu som (ver
    # PushNotificationService): mensagens x todo o resto. No Android 8+ o
    # som vem do canal; o nome do arquivo em `sound` vale pros Androids
    # mais antigos e pro iOS.
    is_message = data.get("type") in ("message", "group_message")
    is_call = data.get("type") == "call"  # Fase 11: chamada entrando (toca forte, expira rápido)
    channel_id = "driqy_calls" if is_call else ("driqy_messages" if is_message else "driqy_activity")
    sound_name = "driqy_message" if (is_message or is_call) else "driqy_notification"
    # Mensagens da mesma pessoa se substituem na bandeja (uma por conversa)
    # em vez de empilhar uma notificação por mensagem.
    tag = f"msg-{data.get('username')}" if is_message and data.get("username") else None
    if data.get("type") == "group_message" and data.get("group_id"):
        tag = f"group-{data.get('group_id')}"

    if is_call:
        # Fase 14: chamada vai como DATA-ONLY no Android (sem bloco `notification`), para o app
        # acordar em segundo plano e desenhar a notificação de tela cheia (full-screen intent)
        # com Atender/Recusar. No iOS o alerta continua no `aps` (abaixo).
        data["title"] = title or ""
        data["body"] = body or ""

    message = messaging.MulticastMessage(
        notification=None if is_call else messaging.Notification(title=title, body=body),
        data=data,
        tokens=tokens,
        android=messaging.AndroidConfig(
            priority="high",
            ttl=timedelta(seconds=45) if is_call else None,  # chamada velha não deve tocar depois
            notification=None if is_call else messaging.AndroidNotification(
                channel_id=channel_id,
                sound=sound_name,
                icon="ic_stat_driqy",
                color="#F2A93B",
                tag=tag,
                notification_count=int(count) if count else None,
            ),
        ),
        apns=messaging.APNSConfig(
            headers=({"apns-priority": "10", "apns-expiration": str(int(time.time()) + 45)} if is_call else None),
            payload=messaging.APNSPayload(aps=messaging.Aps(
                alert=messaging.ApsAlert(title=title, body=body) if is_call else None,
                sound=f"{sound_name}.wav",
                # agrupa por conversa na central de notificações do iOS
                thread_id=(tag or None),
            )),
        ),
    )

    try:
        response = messaging.send_each_for_multicast(message, app=app)
    except Exception as exc:
        print(f"[push] Falha ao enviar para user_id={user_id}: {exc}")
        return

    # Tokens que falharam (app desinstalado, token expirado etc.) são
    # removidos, pra parar de tentar mandar pra eles de novo.
    dead_tokens = [
        tokens[idx] for idx, result in enumerate(response.responses) if not result.success
    ]
    if dead_tokens:
        DeviceToken.query.filter(DeviceToken.token.in_(dead_tokens)).delete(synchronize_session=False)
        db.session.commit()
