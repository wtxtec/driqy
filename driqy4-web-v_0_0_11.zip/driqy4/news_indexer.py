"""
Indexador de notícias: varre os feeds RSS cadastrados em NewsSource,
descobre artigos novos, classifica cada um (news_classifier) e grava em
NewsArticle. Roda periodicamente via APScheduler (ver start no app.py),
no mesmo esquema já usado para expirar posts (scheduler.py).
"""
import hashlib
import html as _html
import json
import re
from datetime import datetime, timedelta
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

import feedparser
import requests
from flask import current_app, has_app_context

from models import NewsArticle, NewsSource, utcnow
from news_classifier import classify, classify_article

_TAG_RE = re.compile(r"<[^>]+>")
# regex do <img> inteiro (não só o src) — precisamos do width/height do
# atributo (se houver) pra filtrar ícone pequeno que passaria batido só
# olhando o nome do arquivo
_IMG_TAG_RE = re.compile(r"<img\b[^>]*>", re.IGNORECASE)
_IMG_SRC_RE = re.compile(r"(?:src|data-src|data-lazy-src)\s*=\s*[\"']([^\"']+)[\"']", re.IGNORECASE)
_IMG_WIDTH_RE = re.compile(r'\bwidth\s*=\s*["\']?(\d+)', re.IGNORECASE)
_IMG_HEIGHT_RE = re.compile(r'\bheight\s*=\s*["\']?(\d+)', re.IGNORECASE)
# aceita og:image, og:image:url/:secure_url e twitter:image(:src) — algumas
# páginas só publicam a variante :secure_url, sem a tag "og:image" simples
_OG_IMAGE_RE = re.compile(
    r'<meta[^>]+(?:property|name)=["\']'
    r'(?:og:image(?::url|:secure_url)?|twitter:image(?::src)?)'
    r'["\'][^>]+content=["\']([^"\']+)["\']',
    re.IGNORECASE,
)
_LINK_IMAGE_SRC_RE = re.compile(
    r'<link[^>]+rel=["\']image_src["\'][^>]+href=["\']([^"\']+)["\']', re.IGNORECASE,
)
# quase todo veículo brasileiro grande (G1, Folha, UOL, CNN Brasil, R7...)
# publica um bloco JSON-LD (schema.org NewsArticle/Article) na página, com
# a imagem de capa em "image" — cobre casos em que a página não tem
# og:image mas tem esse bloco (ou o inverso, quando o og:image aponta pra
# um recorte genérico e o JSON-LD tem a foto real)
_JSON_LD_RE = re.compile(
    r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
    re.IGNORECASE | re.DOTALL,
)
# imagens genéricas demais pra valer a pena mostrar no card (ícones, spacers,
# pixels de rastreamento, logos de comentário/anúncio que às vezes vêm no <img>
# mais próximo do topo do resumo em HTML)
_BAD_IMAGE_HINTS = (
    "spacer", "blank.gif", "pixel", "1x1", "doubleclick", "feedburner",
    "gravatar", "avatar-default", "logo-", "-logo", "/logos/", "icon-",
    "-icon", "/icons/", "sprite",
    # imagens-padrão que veículos usam quando a matéria não tem foto
    # (mostrariam o mesmo logo/placeholder em vários cards)
    "placeholder", "no-image", "noimage", "sem-imagem", "default-image",
    "image-default", "og-default", "share-default", "default_og", "fallback-image",
)
# abaixo disso é ícone/thumbnail pequeno demais pro card (fica esticado e
# borrado) — só filtra quando o próprio HTML já informa a dimensão; imagem
# sem width/height no atributo passa (não dá pra saber sem baixar)
_MIN_IMAGE_DIMENSION = 150
_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 Driqy-NewsBot/1.0"
)
# várias fontes publicam a MESMA matéria (texto de agência, ex.: Agência
# Brasil) com título idêntico — sem isso, ela aparece duplicada no feed
# só porque a URL de cada veículo é diferente (o dedup por url_hash não
# pega esse caso). Compara só título exato dentro de uma janela recente
# pra não custar caro nem confundir matérias antigas que resumem o mesmo
# tema com o mesmo título por coincidência.
_TITLE_DEDUP_WINDOW_HOURS = 48
# veículos republicam "Resultado da Mega-Sena/Quina/..." todo dia — é ruído
# num feed de notícias (mesmo assunto, sem nada de novo), então filtramos
# esse tipo de matéria fora do indexador em vez de só reclassificar.
_LOTTERY_TITLE_RE = re.compile(
    r"\b(mega-?sena|quina|lotof[aá]cil|lotomania|dupla[\s-]sena|timemania|"
    r"dia de sorte|super sete|loteria federal|\+?\s?milion[aá]ria)\b",
    re.IGNORECASE,
)


def _is_lottery_result(title, summary=""):
    """True se o título/resumo é claramente resultado de loteria."""
    return bool(_LOTTERY_TITLE_RE.search(title or "") or _LOTTERY_TITLE_RE.search(summary or ""))


def _duplicate_title_exists(title):
    """True se já existe artigo com o MESMO título indexado nas últimas
    _TITLE_DEDUP_WINDOW_HOURS horas (outra fonte publicando a mesma
    matéria de agência)."""
    title = (title or "").strip()
    if not title:
        return False
    cutoff = utcnow() - timedelta(hours=_TITLE_DEDUP_WINDOW_HOURS)
    return (
        NewsArticle.query
        .filter(NewsArticle.title == title, NewsArticle.indexed_at >= cutoff)
        .first()
        is not None
    )
# fetch de fallback (buscar og:image na página original) é a etapa mais
# lenta do indexador — limitamos por rodada de fonte pra não travar o
# scheduler numa fonte com muitos artigos novos de uma vez, mas o limite
# precisa ser alto o bastante pra não deixar muitos cards sem imagem
_MAX_FALLBACK_FETCHES_PER_SOURCE = 40
_FALLBACK_FETCH_TIMEOUT = 6
# quanto do HTML lemos procurando og:image/twitter:image — a tag normalmente
# fica no <head>, mas algumas páginas têm um <head> grande (scripts, CSS
# inline etc.), então lemos alguns chunks em vez de só o primeiro
_FALLBACK_FETCH_MAX_BYTES = 300_000


def _hash_url(url):
    return hashlib.sha256(url.encode("utf-8")).hexdigest()


def _strip_html(raw):
    """Feeds costumam trazer o resumo com tags HTML (<p>, <img>, etc.) —
    tiramos tudo, já que só mostramos texto puro no card."""
    if not raw:
        return ""
    text = _TAG_RE.sub(" ", raw)
    # alguns feeds (UOL) entregam entidades duplamente escapadas: "Ita&uacute;",
    # "est&aacute;". Desescapa até estabilizar (máx. 3 vezes) e limpa o nbsp.
    for _ in range(3):
        new = _html.unescape(text)
        if new == text:
            break
        text = new
    text = text.replace("\xa0", " ")
    return re.sub(r"\s+", " ", text).strip()


def _parse_published(entry):
    for key in ("published_parsed", "updated_parsed"):
        value = getattr(entry, key, None)
        if value:
            try:
                return datetime(*value[:6])
            except (TypeError, ValueError):
                continue
    return None


def _looks_like_bad_image(url):
    low = url.lower()
    return any(hint in low for hint in _BAD_IMAGE_HINTS)


def _img_tag_too_small(tag):
    """True só quando o próprio <img> declara width/height pequeno demais
    (ex.: ícone de 24x24 embutido no resumo). Sem atributo de tamanho,
    deixa passar — não vale a pena baixar a imagem só pra medir."""
    w = _IMG_WIDTH_RE.search(tag)
    h = _IMG_HEIGHT_RE.search(tag)
    try:
        if w and int(w.group(1)) < _MIN_IMAGE_DIMENSION:
            return True
        if h and int(h.group(1)) < _MIN_IMAGE_DIMENSION:
            return True
    except ValueError:
        pass
    return False


def _first_img_in_html(html, base_url):
    """Procura o primeiro <img> "de verdade" dentro de um trecho HTML
    (resumo ou conteúdo completo do feed), ignorando ícones/pixels óbvios
    e imagens pequenas demais (quando o próprio HTML já informa o tamanho)."""
    if not html:
        return None
    for tag_match in _IMG_TAG_RE.finditer(html):
        tag = tag_match.group(0)
        src_match = _IMG_SRC_RE.search(tag)
        if not src_match:
            continue
        src = src_match.group(1).strip()
        if not src or _looks_like_bad_image(src) or _img_tag_too_small(tag):
            continue
        return urljoin(base_url, src)
    return None


def _best_media_item(items):
    """Entre várias variantes de mídia (media:content costuma trazer o
    mesmo artigo em vários tamanhos), escolhe a de maior largura — sem
    isso a gente às vezes pegava sem querer a miniatura em vez da foto
    principal, e o card ficava com imagem borrada/pixelizada."""
    best_url, best_width = None, -1
    for item in items:
        url = (item.get("url") or "").strip()
        if not url or _looks_like_bad_image(url):
            continue
        try:
            width = int(item.get("width") or 0)
        except (TypeError, ValueError):
            width = 0
        if width > best_width:
            best_url, best_width = url, width
    return best_url


def _extract_image_from_feed(entry, base_url):
    """Tenta achar a imagem de capa usando só o que já veio no feed —
    sem nenhuma requisição extra. Cobre os formatos mais comuns:
    media:content/thumbnail (Media RSS), <enclosure>, e <img> embutido no
    resumo ou no conteúdo completo (content:encoded), que é como boa parte
    dos feeds brasileiros (Folha, UOL, CNN Brasil, etc.) realmente manda a
    imagem, mesmo sem tag de mídia dedicada."""
    media = getattr(entry, "media_content", None) or []
    best = _best_media_item(media)
    if best:
        return urljoin(base_url, best)

    thumbs = getattr(entry, "media_thumbnail", None) or []
    best = _best_media_item(thumbs)
    if best:
        return urljoin(base_url, best)

    for link in getattr(entry, "links", []) or []:
        if link.get("rel") == "enclosure" and str(link.get("type", "")).startswith("image"):
            url = (link.get("href") or "").strip()
            if url:
                return urljoin(base_url, url)

    # content:encoded (conteúdo completo) costuma trazer a imagem de capa
    # como primeiro <img> do corpo, mesmo quando o resumo não traz nenhuma
    for content_item in getattr(entry, "content", None) or []:
        img = _first_img_in_html(content_item.get("value"), base_url)
        if img:
            return img

    # por fim, tenta o resumo/descrição em HTML (antes de ser limpo)
    img = _first_img_in_html(getattr(entry, "summary", None), base_url)
    if img:
        return img

    return None


def _image_from_json_ld_value(value):
    """O campo "image" do JSON-LD schema.org varia de formato entre
    veículos: string única, lista de strings, objeto ImageObject (com
    "url"), ou lista de objetos. Normaliza pra pegar a primeira URL válida."""
    if isinstance(value, str):
        return value.strip() or None
    if isinstance(value, dict):
        return _image_from_json_ld_value(value.get("url"))
    if isinstance(value, list):
        for item in value:
            found = _image_from_json_ld_value(item)
            if found:
                return found
    return None


def _find_image_in_json_ld_node(node):
    """Percorre um nó JSON-LD (pode ser dict, ou lista de nós, ou um
    "@graph" com vários nós dentro) procurando o primeiro "image" válido."""
    if isinstance(node, list):
        for item in node:
            found = _find_image_in_json_ld_node(item)
            if found:
                return found
        return None
    if not isinstance(node, dict):
        return None
    if "image" in node:
        found = _image_from_json_ld_value(node["image"])
        if found:
            return found
    if "@graph" in node:
        return _find_image_in_json_ld_node(node["@graph"])
    return None


def _extract_json_ld_image(html, base_url):
    for match in _JSON_LD_RE.finditer(html):
        raw = match.group(1).strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            continue
        img = _find_image_in_json_ld_node(data)
        if img and not _looks_like_bad_image(img):
            return urljoin(base_url, img)
    return None


def _fetch_og_image(url):
    """Último recurso: baixa a página da matéria e lê a meta tag
    og:image/twitter:image. Só roda pra artigos novos que não trouxeram
    nenhuma imagem no próprio feed. Lê em pedaços até achar a tag ou até
    um limite de bytes, em vez de olhar só o primeiro chunk — páginas com
    <head> grande (scripts/CSS inline antes das meta tags) faziam a busca
    antiga falhar e o card cair no fallback de cor sólida sem imagem."""
    try:
        resp = requests.get(
            url,
            headers={"User-Agent": _USER_AGENT},
            timeout=_FALLBACK_FETCH_TIMEOUT,
            stream=True,
        )
        resp.raise_for_status()
        html_bytes = b""
        for chunk in resp.iter_content(chunk_size=65536):
            html_bytes += chunk
            if len(html_bytes) >= _FALLBACK_FETCH_MAX_BYTES or b"</head>" in html_bytes:
                break
        html = html_bytes.decode(resp.encoding or "utf-8", errors="ignore")
        match = _OG_IMAGE_RE.search(html)
        if match:
            img = match.group(1).strip()
            if img and not _looks_like_bad_image(img):
                return urljoin(url, img)
        # sem og:image/twitter:image: tenta o bloco JSON-LD
        # (schema.org NewsArticle/Article), que quase toda página de
        # notícia brasileira grande publica com a foto de capa
        img = _extract_json_ld_image(html, url)
        if img:
            return img
        # ainda nada: algumas páginas só declaram <link rel="image_src">
        # (formato mais antigo, ainda usado por alguns veículos)
        match = _LINK_IMAGE_SRC_RE.search(html)
        if match:
            img = match.group(1).strip()
            if img and not _looks_like_bad_image(img):
                return urljoin(url, img)
        # por fim, tenta o primeiro <img> "de verdade" do corpo da página
        img = _first_img_in_html(html, url)
        if img:
            return img
    except Exception:
        return None
    finally:
        try:
            resp.close()
        except Exception:
            pass
    return None


# ---------------------------------------------------------------------------
# Qualidade da imagem de capa
# ---------------------------------------------------------------------------
# O card de notícia no desktop passa de 450px de largura (telas retina pedem
# o dobro), então uma miniatura de 150-300px fica visivelmente borrada. Duas
# frentes: (1) tentar "promover" a URL da miniatura pra versão grande quando
# o padrão da URL deixa isso seguro; (2) quando o feed só traz miniatura,
# trocar pela og:image da matéria (que costuma ter 1200px).
_WP_SIZE_SUFFIX_RE = re.compile(r"-\d{2,4}x\d{2,4}(?=\.(?:jpe?g|png|webp)(?:$|\?))", re.IGNORECASE)
_SMALL_PATH_HINTS = ("/thumb/", "/thumbs/", "/thumbnail/", "/small/", "/mini/", "/150x", "/100x", "/200x", "/300x")
# CDNs com URL assinada (qualquer mudança invalida o link) — nunca reescrever
_SIGNED_CDN_HINTS = ("glbimg.com",)
_TARGET_IMAGE_WIDTH = 1200
_WIDTH_PARAMS = ("w", "width")
_HEIGHT_PARAMS = ("h", "height")


def _upgrade_image_url(url):
    """Devolve uma versão maior da mesma imagem quando o padrão da URL deixa
    isso seguro (sufixo -300x200 do WordPress, parâmetros w=/width= de CDN
    de redimensionamento). Em qualquer dúvida devolve a URL original."""
    if not url:
        return url
    low = url.lower()
    if any(hint in low for hint in _SIGNED_CDN_HINTS):
        return url
    try:
        parts = urlsplit(url)
    except ValueError:
        return url
    path = _WP_SIZE_SUFFIX_RE.sub("", parts.path)
    query = parts.query
    if query:
        pairs = parse_qsl(query, keep_blank_values=True)
        keys = {k.lower(): i for i, (k, _v) in enumerate(pairs)}
        for wk in _WIDTH_PARAMS:
            if wk in keys:
                idx = keys[wk]
                try:
                    old_w = int(pairs[idx][1])
                except ValueError:
                    break
                if 0 < old_w < _TARGET_IMAGE_WIDTH:
                    pairs[idx] = (pairs[idx][0], str(_TARGET_IMAGE_WIDTH))
                    # mantém a proporção se a URL também fixa a altura
                    for hk in _HEIGHT_PARAMS:
                        if hk in keys:
                            hidx = keys[hk]
                            try:
                                old_h = int(pairs[hidx][1])
                                pairs[hidx] = (
                                    pairs[hidx][0],
                                    str(max(1, round(old_h * _TARGET_IMAGE_WIDTH / old_w))),
                                )
                            except ValueError:
                                pass
                break
        query = urlencode(pairs)
    return urlunsplit((parts.scheme, parts.netloc, path, query, parts.fragment))


def _url_width_hint(url):
    """Largura (px) que a própria URL declara (?w=300, -300x200.jpg,
    /300x200/), ou None se não der pra saber."""
    try:
        parts = urlsplit(url)
    except ValueError:
        return None
    for k, v in parse_qsl(parts.query, keep_blank_values=True):
        if k.lower() in _WIDTH_PARAMS:
            try:
                return int(v)
            except ValueError:
                return None
    m = re.search(r"-(\d{2,4})x\d{2,4}\.(?:jpe?g|png|webp)$", parts.path, re.IGNORECASE)
    if m:
        return int(m.group(1))
    m = re.search(r"/(\d{2,4})x\d{2,4}/", parts.path)
    if m:
        return int(m.group(1))
    return None


def _feed_declared_width(entry):
    """Maior largura declarada pelo feed (media:content/thumbnail), ou 0."""
    best = 0
    for attr in ("media_content", "media_thumbnail"):
        for item in getattr(entry, attr, None) or []:
            try:
                best = max(best, int(item.get("width") or 0))
            except (TypeError, ValueError):
                continue
    return best


def _image_is_weak(entry, image_url, min_width):
    """True se a imagem tirada do feed provavelmente é miniatura (pequena
    demais pro card) — aí vale gastar uma requisição pra buscar a og:image."""
    if not image_url:
        return True
    low = image_url.lower()
    if any(h in low for h in _SMALL_PATH_HINTS):
        return True
    declared = _feed_declared_width(entry)
    if 0 < declared < min_width:
        return True
    hint = _url_width_hint(image_url)
    if hint is not None and hint < min_width:
        return True
    # só havia media:thumbnail (sem media:content): quase sempre miniatura
    if not (getattr(entry, "media_content", None) or []) and (getattr(entry, "media_thumbnail", None) or []):
        return True
    return False


def _trust_prior(source_name, cfg):
    """False para portais generalistas cujo feed "de categoria" traz de tudo."""
    prefixes = tuple(cfg.get("NEWS_STRICT_PRIOR_PREFIXES", ()))
    return not (prefixes and (source_name or "").startswith(prefixes))


def seed_default_sources(app, db):
    """Cria as fontes RSS padrão (config.NEWS_DEFAULT_SOURCES) na primeira
    vez que o app sobe. Não faz nada se a fonte (pela URL) já existir —
    seguro rodar toda vez que o app inicia."""
    for name, feed_url, default_category in app.config.get("NEWS_DEFAULT_SOURCES", []):
        exists = NewsSource.query.filter_by(feed_url=feed_url).first()
        if exists:
            continue
        db.session.add(NewsSource(
            name=name, feed_url=feed_url, default_category=default_category, active=True,
        ))
    db.session.commit()


def index_source(db, source, keywords_by_category):
    """Busca um feed e grava os artigos novos. Retorna quantos foram adicionados."""
    # feedparser.parse(url) não tem timeout: um feed lento prendia a rodada
    # toda. Baixamos com requests (timeout) e só parseamos o conteúdo.
    try:
        feed_resp = requests.get(
            source.feed_url, headers={"User-Agent": _USER_AGENT}, timeout=12,
        )
        feed_resp.raise_for_status()
        parsed = feedparser.parse(feed_resp.content)
    except Exception:
        parsed = feedparser.parse(b"")
    cfg = getattr(current_app, "config", {}) if has_app_context() else {}
    mixed_sources = cfg.get("NEWS_MIXED_SOURCE_CATEGORIES", {})
    min_good_width = cfg.get("NEWS_MIN_GOOD_IMAGE_WIDTH", 600)
    new_count = 0
    fallback_fetches_left = _MAX_FALLBACK_FETCHES_PER_SOURCE
    # IMPORTANTE (causa do "database is locked"): nada é gravado enquanto
    # buscamos imagens na rede. Os NewsArticle ficam nesta lista e só vão
    # pra sessão no FIM, numa transação curta. Antes, cada db.session.add
    # ficava pendente e a próxima consulta de deduplicação (autoflush)
    # abria a transação de escrita, que só fechava no commit final — depois
    # de até 40 downloads de 6s. Nesse tempo o site inteiro (inclusive o
    # UPDATE de last_seen_at de toda requisição) esperava e estourava.
    pending = []
    tags_by_hash = {}
    seen_hashes = set()
    seen_titles = set()

    for entry in parsed.entries[:100]:
        url = getattr(entry, "link", None)
        title = _strip_html(getattr(entry, "title", "") or "")
        if not url or not title:
            continue

        url_hash = _hash_url(url)
        if url_hash in seen_hashes:
            continue
        if NewsArticle.query.filter_by(url_hash=url_hash).first():
            continue

        summary = _strip_html(getattr(entry, "summary", ""))
        if _is_lottery_result(title, summary):
            continue
        if title in seen_titles or _duplicate_title_exists(title):
            continue

        # v2: a categoria sai de VÁRIAS evidências (texto, seção da URL, tags do
        # próprio feed) e o palpite da fonte (default_category) é só um prior —
        # ver news_classifier.classify_article. Fontes mistas (G1 Ciência e
        # Saúde...) continuam limitando a evidência de TEXTO às categorias extras.
        extras = mixed_sources.get(source.name)
        tags = []
        for tg in (getattr(entry, "tags", None) or [])[:8]:
            term = tg.get("term") if hasattr(tg, "get") else getattr(tg, "term", None)
            if term:
                tags.append(str(term))
        info = classify_article(
            title, summary, keywords_by_category, url=url, tags=tags,
            prior=source.default_category, allowed=set(extras) if extras else None,
            default_category=source.default_category or "geral",
            trust_prior=_trust_prior(source.name, cfg),
        )
        category = info.category
        tags_by_hash[url_hash] = {"tags": tags}

        image_url = _extract_image_from_feed(entry, url)
        weak = _image_is_weak(entry, image_url, min_good_width)
        if image_url:
            image_url = _upgrade_image_url(image_url)
        if weak and fallback_fetches_left > 0:
            # sem imagem, ou só miniatura: a og:image da matéria costuma
            # ter ~1200px. Se a página não tiver, mantém a miniatura.
            fallback_fetches_left -= 1
            og_image = _fetch_og_image(url)
            if og_image:
                image_url = og_image

        seen_hashes.add(url_hash)
        seen_titles.add(title)
        pending.append(NewsArticle(
            source_id=source.id,
            title=title[:300],
            summary=summary[:500],
            url=url[:700],
            url_hash=url_hash,
            image_url=image_url[:700] if image_url else None,
            category=category,
            published_at=_parse_published(entry) or utcnow(),
        ))
        new_count += 1

    # só agora (sem rede pela frente) grava tudo de uma vez
    db.session.add_all(pending)
    source.last_indexed_at = utcnow()
    db.session.commit()
    # banco temporário: ficha de cada notícia nova (falha aqui não derruba a indexação)
    if pending and has_app_context():
        try:
            import news_bank
            news_bank.add_articles(current_app._get_current_object(), pending, tags_by_hash)
            db.session.commit()
        except Exception as exc:
            db.session.rollback()
            current_app.logger.warning(f"[news_indexer] banco de notícias: {exc}")
    return new_count


_MAX_IMAGE_RETRY_ATTEMPTS = 3
_MAX_IMAGE_RETRIES_PER_RUN = 40


def retry_missing_images(app, db):
    """Tenta de novo buscar og:image/JSON-LD pros artigos que ficaram sem
    imagem na indexação inicial (feed sem mídia embutida E og:image indisponível
    no momento — CDN lenta, matéria ainda sem foto publicada, etc.).

    Roda a cada ciclo do scheduler (junto com index_all_sources), então
    sem precisar do usuário rodar fix_missing_news_images.py manualmente.
    Cada artigo só é tentado até _MAX_IMAGE_RETRY_ATTEMPTS vezes — depois
    disso a página de origem provavelmente não tem imagem nenhuma, e
    insistir só gastaria requisição à toa a cada ciclo pra sempre."""
    candidates = (
        NewsArticle.query
        .filter(
            (NewsArticle.image_url.is_(None)) | (NewsArticle.image_url == ""),
            NewsArticle.image_fetch_attempts < _MAX_IMAGE_RETRY_ATTEMPTS,
        )
        .order_by(NewsArticle.indexed_at.desc())
        .limit(_MAX_IMAGE_RETRIES_PER_RUN)
        .all()
    )
    # rede primeiro (sem tocar no banco), escrita depois, de uma vez
    results = []
    for article in candidates:
        results.append((article, _fetch_og_image(article.url)))
    found = 0
    for article, image_url in results:
        article.image_fetch_attempts += 1
        if image_url:
            article.image_url = image_url[:700]
            found += 1
    if candidates:
        db.session.commit()
        app.logger.info(
            f"[news_indexer] retry de imagem: {found}/{len(candidates)} conseguida(s)."
        )


def _purge_old_articles(app, db):
    max_age_days = app.config.get("NEWS_MAX_AGE_DAYS", 14)
    cutoff = utcnow() - timedelta(days=max_age_days)
    NewsArticle.query.filter(NewsArticle.indexed_at < cutoff).delete()
    db.session.commit()
    _prune_image_cache(app, max_age_days + 2)


def _prune_image_cache(app, max_age_days):
    """Apaga do cache em disco (instance/news_img_cache) as imagens de
    notícias que já saíram do feed — sem isso a pasta só crescia, e agora
    que cada imagem tem também variantes redimensionadas cresceria mais."""
    import os
    import time
    cache_dir = os.path.join(app.instance_path, "news_img_cache")
    if not os.path.isdir(cache_dir):
        return
    limit = time.time() - max_age_days * 86400
    for name in os.listdir(cache_dir):
        path = os.path.join(cache_dir, name)
        try:
            if os.path.getmtime(path) < limit:
                os.remove(path)
        except OSError:
            continue


def index_all_sources(app, db):
    """Ponto de entrada chamado pelo scheduler: indexa todas as fontes
    ativas e depois limpa notícias antigas. Uma fonte com erro (feed fora
    do ar, formato inválido etc.) não derruba as outras."""
    with app.app_context():
        keywords_by_category = app.config["NEWS_CATEGORY_KEYWORDS"]
        total = 0
        for source in NewsSource.query.filter_by(active=True).all():
            # guarda o nome ANTES de tentar indexar: se der erro no meio da
            # transação (ex.: "database is locked"), o objeto "source" fica
            # com atributos expirados, e ler source.name de novo no except
            # dispara uma NOVA query — que falha com PendingRollbackError
            # porque a sessão ainda não foi limpa, mascarando o erro real.
            source_name = source.name
            try:
                total += index_source(db, source, keywords_by_category)
            except Exception as exc:
                db.session.rollback()
                app.logger.warning(f"[news_indexer] falha ao indexar '{source_name}': {exc}")
        if total:
            app.logger.info(f"[news_indexer] {total} notícia(s) nova(s) indexada(s).")
        try:
            retry_missing_images(app, db)
        except Exception as exc:
            db.session.rollback()
            app.logger.warning(f"[news_indexer] falha no retry de imagens: {exc}")
        _purge_old_articles(app, db)
        try:  # banco temporário: apaga o que passou de 3 dias e recompleta fichas que faltem
            import news_bank
            res = news_bank.maintain(app)
            if res["removed"] or res["created"]:
                app.logger.info(f"[news_bank] {res}")
        except Exception as exc:
            db.session.rollback()
            app.logger.warning(f"[news_bank] falha na manutenção: {exc}")
