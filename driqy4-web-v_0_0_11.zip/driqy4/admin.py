import os
from datetime import datetime, timedelta
from functools import wraps

from flask import (
    Blueprint, render_template, redirect, url_for, flash, request,
    current_app, abort, jsonify
)
from flask_login import login_required, current_user

from extensions import db
from models import User, Post, Follow, Notification, utcnow, log_admin_action, AdminActionLog
from uploads import delete_upload

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return wrapper


def staff_required(f):
    """Permite acesso a administradores e também a moderadores."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_staff:
            abort(403)
        return f(*args, **kwargs)
    return wrapper


@admin_bp.route("/")
@login_required
@admin_required
def dashboard():
    from datetime import timedelta
    from models import Comment
    now = utcnow()
    week_ago = now - timedelta(days=7)

    posts_by_type = dict(
        db.session.query(Post.post_type, db.func.count(Post.id))
        .group_by(Post.post_type).all()
    )

    stats = {
        "total_users": User.query.count(),
        "banned_users": User.query.filter_by(is_banned=True).count(),
        "admins": User.query.filter_by(is_admin=True).count(),
        "moderators": User.query.filter_by(is_moderator=True).count(),
        "verified_users": User.query.filter_by(is_verified=True).count(),
        "new_users_7d": User.query.filter(User.created_at >= week_ago).count(),
        "active_posts": Post.query.filter(Post.expires_at > now).count(),
        "expired_posts": Post.query.filter(Post.expires_at <= now).count(),
        "posts_7d": Post.query.filter(Post.created_at >= week_ago).count(),
        "total_follows": Follow.query.count(),
        "total_likes": db.session.query(db.func.coalesce(db.func.sum(User.total_likes_received), 0)).scalar(),
        "total_comments": Comment.query.count(),
        "posts_text": posts_by_type.get("text", 0),
        "posts_photo": posts_by_type.get("photo", 0),
        "posts_video": posts_by_type.get("video", 0),
        "posts_gif": posts_by_type.get("gif", 0),
    }
    latest_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    latest_posts = Post.query.order_by(Post.created_at.desc()).limit(5).all()
    top_ranked = sorted(
        User.query.filter_by(is_banned=False).all(),
        key=lambda u: u.ranking_score, reverse=True
    )[:5]

    return render_template(
        "admin/dashboard.html", stats=stats,
        latest_users=latest_users, latest_posts=latest_posts, top_ranked=top_ranked,
    )


@admin_bp.route("/usuarios")
@login_required
@staff_required
def users():
    q = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)
    query = User.query
    if q:
        query = query.filter(
            (User.username.ilike(f"%{q}%")) | (User.email.ilike(f"%{q}%"))
        )
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    return render_template("admin/users.html", pagination=pagination, q=q)


@admin_bp.route("/usuarios/<int:user_id>/banir", methods=["POST"])
@login_required
@staff_required
def ban_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Você não pode banir a si mesmo.", "danger")
        return redirect(url_for("admin.users"))
    if (user.is_admin or user.is_moderator) and not current_user.is_admin:
        flash("Apenas administradores podem banir outros membros da equipe.", "danger")
        return redirect(url_for("admin.users"))
    user.is_banned = True
    log_admin_action(current_user, "banir_usuario", f"@{user.username}")
    db.session.commit()
    flash(f"Usuário @{user.username} foi banido.", "warning")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/desbanir", methods=["POST"])
@login_required
@staff_required
def unban_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_banned = False
    log_admin_action(current_user, "desbanir_usuario", f"@{user.username}")
    db.session.commit()
    flash(f"Usuário @{user.username} foi desbanido.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/tornar-admin", methods=["POST"])
@login_required
@admin_required
def make_admin(user_id):
    user = User.query.get_or_404(user_id)
    user.is_admin = True
    log_admin_action(current_user, "tornar_admin", f"@{user.username}")
    db.session.commit()
    flash(f"@{user.username} agora é administrador.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/remover-admin", methods=["POST"])
@login_required
@admin_required
def remove_admin(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Você não pode remover seu próprio acesso de administrador.", "danger")
        return redirect(url_for("admin.users"))
    user.is_admin = False
    log_admin_action(current_user, "remover_admin", f"@{user.username}")
    db.session.commit()
    flash(f"Privilégios de administrador removidos de @{user.username}.", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/tornar-moderador", methods=["POST"])
@login_required
@admin_required
def make_moderator(user_id):
    user = User.query.get_or_404(user_id)
    if user.is_admin:
        flash(f"@{user.username} já é administrador.", "info")
        return redirect(url_for("admin.users"))
    user.is_moderator = True
    log_admin_action(current_user, "tornar_moderador", f"@{user.username}")
    db.session.commit()
    flash(f"@{user.username} agora é moderador(a).", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/remover-moderador", methods=["POST"])
@login_required
@admin_required
def remove_moderator(user_id):
    user = User.query.get_or_404(user_id)
    user.is_moderator = False
    log_admin_action(current_user, "remover_moderador", f"@{user.username}")
    db.session.commit()
    flash(f"Privilégios de moderador removidos de @{user.username}.", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/verificar", methods=["POST"])
@login_required
@admin_required
def verify_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_verified = True
    log_admin_action(current_user, "verificar_usuario", f"@{user.username}")
    db.session.commit()
    flash(f"@{user.username} agora é uma conta verificada.", "success")
    return redirect(request.referrer or url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/remover-verificacao", methods=["POST"])
@login_required
@admin_required
def unverify_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_verified = False
    log_admin_action(current_user, "remover_verificacao", f"@{user.username}")
    db.session.commit()
    flash(f"Selo de verificação removido de @{user.username}.", "info")
    return redirect(request.referrer or url_for("admin.users"))


@admin_bp.route("/usuarios/<int:user_id>/excluir", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Você não pode excluir sua própria conta por aqui.", "danger")
        return redirect(url_for("admin.users"))

    username_for_log = user.username

    # remove arquivos de mídia dos posts do usuário
    for post in user.posts:
        _delete_media_file(post)

    Follow.query.filter(
        (Follow.follower_id == user.id) | (Follow.followed_id == user.id)
    ).delete()

    # notificações onde este usuário curtiu/comentou/seguiu alguém também
    # precisam ser removidas — só as em que ele é o *destinatário* são
    # apagadas automaticamente pelo cascade do relacionamento "recipient"
    Notification.query.filter_by(actor_id=user.id).delete()

    db.session.delete(user)
    log_admin_action(current_user, "excluir_usuario", f"@{username_for_log}")
    db.session.commit()
    flash(f"Conta @{username_for_log} excluída permanentemente.", "warning")
    return redirect(url_for("admin.users"))


@admin_bp.route("/posts")
@login_required
@staff_required
def posts():
    page = request.args.get("page", 1, type=int)
    pagination = Post.query.order_by(Post.created_at.desc()).paginate(
        page=page, per_page=25, error_out=False
    )
    return render_template("admin/posts.html", pagination=pagination)


@admin_bp.route("/posts/<int:post_id>/excluir", methods=["POST"])
@login_required
@staff_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    author_label = f"@{post.author.username}"
    _delete_media_file(post)
    db.session.delete(post)
    log_admin_action(current_user, "excluir_post", f"post #{post_id} de {author_label}")
    db.session.commit()
    flash("Post removido pela moderação.", "warning")
    return redirect(request.referrer or url_for("admin.posts"))


@admin_bp.route("/comentarios/<int:comment_id>/excluir", methods=["POST"])
@login_required
@staff_required
def delete_comment(comment_id):
    from models import Comment
    comment = Comment.query.get_or_404(comment_id)
    author_label = f"@{comment.author.username}"
    for reply in list(comment.replies):
        db.session.delete(reply)
    db.session.delete(comment)
    log_admin_action(current_user, "excluir_comentario", f"comentário #{comment_id} de {author_label}")
    db.session.commit()
    flash("Comentário removido pela moderação.", "warning")
    return redirect(request.referrer or url_for("admin.posts"))


def _delete_media_file(post):
    for fname in post.all_media_filenames():
        delete_upload(fname)


@admin_bp.route("/atividade")
@login_required
@staff_required
def activity():
    """Histórico de ações de moderação/administração (quem fez o quê e quando)."""
    page = request.args.get("page", 1, type=int)
    pagination = AdminActionLog.query.order_by(AdminActionLog.created_at.desc()).paginate(
        page=page, per_page=40, error_out=False
    )
    return render_template("admin/activity.html", pagination=pagination)


# ---------------------------------------------------------------------------
# Vortex: crawler (fontes, execução manual e moderação dos itens)
# ---------------------------------------------------------------------------

@admin_bp.route("/vortex")
@login_required
@admin_required
def vortex_admin():
    from models import VortexCrawlSource, VortexItem, VortexProfile
    sources = VortexCrawlSource.query.order_by(VortexCrawlSource.id).all()
    profiles = VortexProfile.query.order_by(VortexProfile.id).all()
    counts = dict(
        db.session.query(VortexItem.media_type, db.func.count(VortexItem.id))
        .filter(VortexItem.is_active.is_(True)).group_by(VortexItem.media_type).all()
    )
    hidden = VortexItem.query.filter(VortexItem.is_active.is_(False)).count()
    return render_template(
        "admin/vortex.html", sources=sources, profiles=profiles, counts=counts, hidden=hidden,
        categories=current_app.config["VORTEX_CATEGORIES"],
        kinds=["commons", "openverse", "nasa", "met", "artic", "pexels", "pixabay", "unsplash",
               "giphy", "rss", "page"],
        engine=_vortex_engine_stats(),
    )


def _vortex_engine_stats():
    """Estatísticas do motor: do próprio processo se ele roda aqui; senão o
    instantâneo que o processo dono do motor grava a cada 2 s (None = parado)."""
    import vortex_control
    from vortex_crawler import get_engine
    engine = get_engine()
    saved = vortex_control.read_stats_file()
    if engine is not None and engine.running():
        snap = engine.stats()
        snap["series"] = (saved or {}).get("series", [])
        return snap
    return saved


def _vortex_totals():
    """Contagens baratas pro painel em tempo real (uma consulta agrupada)."""
    from models import VortexItem
    rows = (db.session.query(VortexItem.media_type, VortexItem.is_active, db.func.count(VortexItem.id))
            .group_by(VortexItem.media_type, VortexItem.is_active).all())
    out = {"photos": 0, "gifs": 0, "videos": 0, "active": 0, "hidden": 0}
    for media_type, is_active, n in rows:
        if is_active:
            out["active"] += n
            key = {"photo": "photos", "gif": "gifs", "video": "videos"}.get(media_type)
            if key:
                out[key] += n
        else:
            out["hidden"] += n
    out["total"] = out["active"] + out["hidden"]
    return out


def _vortex_recent(limit=8):
    from models import VortexItem
    rows = VortexItem.query.filter(VortexItem.is_active.is_(True)).order_by(VortexItem.id.desc()).limit(limit).all()
    return [{
        "id": i.id, "title": i.title or "", "media_type": i.media_type, "category": i.category,
        "site": i.source_name or "", "thumb": i.thumb_url or i.media_url,
        "at": i.created_at.isoformat() + "Z" if i.created_at else None,
    } for i in rows]


@admin_bp.route("/vortex/status")
@login_required
@admin_required
def vortex_status():
    """JSON em tempo real: motor (itens/min, fila, fontes rodando), controle
    (pausa/velocidade), totais, últimos itens e exclusão em andamento."""
    import vortex_control
    from models import VortexCrawlSource
    engine = _vortex_engine_stats()
    running = []
    if engine and engine.get("inflight_ids"):
        rows = VortexCrawlSource.query.filter(VortexCrawlSource.id.in_(engine["inflight_ids"][:12])).all()
        running = [r.name for r in rows]
    totals = _vortex_totals()
    return jsonify(
        engine=engine,
        control=vortex_control.read_control(current_app._get_current_object(), ttl=0),
        speed_levels=list(vortex_control.SPEED_LEVELS),
        totals=totals,
        total_items=totals["total"],
        recent=_vortex_recent(),
        running_sources=running,
        purge=vortex_control.read_purge_job(),
    )


@admin_bp.route("/vortex/saude")
@login_required
@admin_required
def vortex_health_page():
    """Saúde do Vortex: fila de indexação, recomendação (sinais, \"menos disso\", repetição)
    e cobertura de conceitos, com avisos. Só leitura."""
    import vortex_health
    return render_template("admin/vortex_health.html",
                           h=vortex_health.health(current_app._get_current_object()))


@admin_bp.route("/vortex/saude.json")
@login_required
@admin_required
def vortex_health_json():
    import vortex_health
    return jsonify(vortex_health.health(current_app._get_current_object()))


@admin_bp.route("/vortex/conteudo")
@login_required
@admin_required
def vortex_content():
    """Central do Vortex: controle do motor, tempo real, o que foi indexado e
    exclusão em massa por categoria/fonte/site/perfil/tipo."""
    import vortex_control
    app = current_app._get_current_object()
    return render_template(
        "admin/vortex_content.html",
        ov=vortex_control.overview(app, ttl=0),
        control=vortex_control.read_control(app, ttl=0),
        speed_levels=vortex_control.SPEED_LEVELS,
        categories=current_app.config["VORTEX_CATEGORIES"],
        purge=vortex_control.read_purge_job(),
    )


@admin_bp.route("/vortex/controle", methods=["POST"])
@login_required
@admin_required
def vortex_control_set():
    """Pausa/retoma a indexação de conteúdo novo ou muda a velocidade."""
    import vortex_control
    action = request.form.get("acao", "")
    wants_json = request.headers.get("X-Requested-With") == "fetch"
    try:
        if action == "pausar":
            vortex_control.set_paused(True)
            note = "Indexação pausada."
        elif action == "retomar":
            vortex_control.set_paused(False)
            note = "Indexação retomada."
        elif action == "velocidade":
            speed = vortex_control.set_speed(float(request.form.get("valor", "")))
            note = f"Velocidade da indexação: {speed:g}x."
        else:
            raise ValueError("ação desconhecida")
    except ValueError:
        if wants_json:
            return jsonify(ok=False, error="pedido inválido"), 400
        abort(400)
    log_admin_action(current_user, "vortex_controle", note.rstrip("."))
    db.session.commit()
    control = vortex_control.read_control(current_app._get_current_object(), ttl=0)
    if wants_json:
        return jsonify(ok=True, message=note, control=control)
    flash(note, "success")
    return redirect(url_for("admin.vortex_content"))


@admin_bp.route("/vortex/conteudo/previa")
@login_required
@admin_required
def vortex_purge_preview():
    """Quantos itens uma exclusão com estes filtros apagaria."""
    import vortex_control
    filters = vortex_control.filters_from_args(request.args)
    try:
        count = vortex_control.count_items(filters)
    except ValueError as exc:
        return jsonify(ok=False, error=str(exc)), 400
    return jsonify(ok=True, count=count,
                   label=vortex_control.describe_filters(filters, dict(current_app.config["VORTEX_CATEGORIES"])))


@admin_bp.route("/vortex/conteudo/apagar", methods=["POST"])
@login_required
@admin_required
def vortex_purge():
    """Apaga em massa (de verdade, não só oculta). Exige digitar APAGAR."""
    import vortex_control
    wants_json = request.headers.get("X-Requested-With") == "fetch"

    def reply(ok, message, code=200):
        if wants_json:
            return jsonify(ok=ok, message=message), (code if not ok else 200)
        flash(message, "success" if ok else "danger")
        return redirect(url_for("admin.vortex_content"))

    if request.form.get("confirmar", "").strip().upper() != "APAGAR":
        return reply(False, "Digite APAGAR para confirmar a exclusão.", 400)
    filters = vortex_control.filters_from_args(request.form)
    try:
        count = vortex_control.count_items(filters)
    except ValueError as exc:
        return reply(False, f"Filtro inválido: {exc}.", 400)
    if count == 0:
        return reply(False, "Nenhum item casa com esses filtros.", 404)
    label = vortex_control.describe_filters(filters, dict(current_app.config["VORTEX_CATEGORIES"]))
    started = vortex_control.start_purge(
        current_app._get_current_object(), filters,
        tombstone=request.form.get("lapide") == "1",
        disable_sources=request.form.get("desligar_fontes") == "1",
        block_site=request.form.get("bloquear_site") == "1",
        label=label,
    )
    if not started:
        return reply(False, "Já existe uma exclusão em andamento. Espere terminar.", 409)
    log_admin_action(current_user, "vortex_apagar", f"{count} itens ({label})")
    db.session.commit()
    return reply(True, f"Apagando {count} itens em segundo plano ({label}).")


@admin_bp.route("/vortex/conteudo/lapides/limpar", methods=["POST"])
@login_required
@admin_required
def vortex_tombstones_clear():
    """Permite que URLs apagadas voltem a ser indexadas (todas, ou só de uma
    categoria/site)."""
    import vortex_control
    from models import VortexTombstone
    query = VortexTombstone.query
    category = (request.form.get("categoria") or "").strip()
    site = (request.form.get("site") or "").strip().lower()
    if category:
        query = query.filter(VortexTombstone.category == category)
    if site:
        query = query.filter(VortexTombstone.source_name == site)
    removed = query.delete(synchronize_session=False)
    db.session.commit()
    vortex_control.bump_purge_seq()
    vortex_control.clear_overview_cache()
    log_admin_action(current_user, "vortex_lapides", f"liberou {removed} URLs apagadas")
    db.session.commit()
    flash(f"{removed} URLs apagadas voltam a poder ser indexadas.", "success")
    return redirect(url_for("admin.vortex_content"))


@admin_bp.route("/vortex/descoberta")
@login_required
@admin_required
def vortex_discovery():
    """Sites que o motor descobriu, sementes e bloqueio de domínios."""
    from models import VortexCrawlSource, VortexDomain, VortexFrontier
    status = request.args.get("status") or None
    query = VortexDomain.query
    if status:
        query = query.filter(VortexDomain.status == status)
    domains = query.order_by(VortexDomain.items_added.desc(), VortexDomain.id).limit(200).all()
    by_status = dict(db.session.query(VortexDomain.status, db.func.count(VortexDomain.id))
                     .group_by(VortexDomain.status).all())
    return render_template(
        "admin/vortex_discovery.html", domains=domains, by_status=by_status, status=status,
        frontier_pending=VortexFrontier.query.filter_by(status="pending").count(),
        auto_feeds=VortexCrawlSource.query.filter_by(origin="auto").count(),
        engine=_vortex_engine_stats(),
        seeds=current_app.config.get("VORTEX_DISCOVERY_SEEDS", []),
    )


@admin_bp.route("/vortex/descoberta/sementes", methods=["POST"])
@login_required
@admin_required
def vortex_add_seeds():
    from vortex_discovery import add_seeds
    urls = [u.strip() for u in (request.form.get("urls") or "").splitlines() if u.strip()]
    added = add_seeds(db, current_app.config, urls[:500])
    log_admin_action(current_user, "vortex_sementes", f"{added} URL(s) novas")
    db.session.commit()
    flash(f"{added} URL(s) nova(s) entraram na fila de descoberta.", "success")
    return redirect(url_for("admin.vortex_discovery"))


@admin_bp.route("/vortex/descoberta/dominio", methods=["POST"])
@login_required
@admin_required
def vortex_domain_action():
    from vortex_discovery import block_domain
    host = (request.form.get("host") or "").strip().lower()
    block = request.form.get("action") == "bloquear"
    if not host:
        abort(400)
    block_domain(db, host, blocked=block)
    log_admin_action(current_user, "vortex_dominio", f"{'bloqueou' if block else 'liberou'} {host}")
    db.session.commit()
    flash(f"{host}: {'bloqueado (itens ocultados)' if block else 'liberado'}.", "success")
    return redirect(url_for("admin.vortex_discovery"))


@admin_bp.route("/vortex/rodar", methods=["POST"])
@login_required
@admin_required
def vortex_run():
    import vortex_control
    from vortex_crawler import run_in_background
    source_id = request.form.get("source_id", type=int)
    if vortex_control.read_control(current_app._get_current_object(), ttl=0)["paused"]:
        flash("A indexação está pausada. Retome em Vortex (conteúdo) para rodar as fontes.", "warning")
        return redirect(url_for("admin.vortex_admin"))
    run_in_background(current_app._get_current_object(), db, only_source_id=source_id)
    log_admin_action(current_user, "vortex_rodar", f"fonte #{source_id}" if source_id else "todas as fontes")
    db.session.commit()
    flash("Crawler iniciado em segundo plano. Atualize a página em alguns instantes.", "success")
    return redirect(url_for("admin.vortex_admin"))


@admin_bp.route("/vortex/fontes/<int:source_id>/alternar", methods=["POST"])
@login_required
@admin_required
def vortex_toggle_source(source_id):
    from models import VortexCrawlSource
    source = VortexCrawlSource.query.get_or_404(source_id)
    source.enabled = not source.enabled
    log_admin_action(current_user, "vortex_fonte", f"{'ativou' if source.enabled else 'desativou'} {source.name}")
    db.session.commit()
    return redirect(url_for("admin.vortex_admin"))


@admin_bp.route("/vortex/fontes/nova", methods=["POST"])
@login_required
@admin_required
def vortex_add_source():
    from models import VortexCrawlSource, VortexProfile
    name = (request.form.get("name") or "").strip()[:120]
    kind = request.form.get("kind", "")
    query = (request.form.get("query") or "").strip()[:500]
    media = request.form.get("media", "photo")
    category = request.form.get("category") or None
    profile = db.session.get(VortexProfile, request.form.get("profile_id", type=int) or 0)
    valid_categories = {slug for slug, _ in current_app.config["VORTEX_CATEGORIES"]}
    if (not name or not query or profile is None or media not in ("photo", "gif", "video")
            or kind not in ("commons", "openverse", "pexels", "pixabay", "giphy", "rss", "page")
            or (category and category not in valid_categories)):
        flash("Preencha nome, tipo, termo/URL, perfil e mídia corretamente.", "danger")
        return redirect(url_for("admin.vortex_admin"))
    if VortexCrawlSource.query.filter_by(kind=kind, term=query, media=media).first():
        flash("Já existe uma fonte igual.", "warning")
        return redirect(url_for("admin.vortex_admin"))
    db.session.add(VortexCrawlSource(
        name=name, kind=kind, term=query, media=media, category=category, profile_id=profile.id,
    ))
    log_admin_action(current_user, "vortex_fonte", f"criou {name}")
    db.session.commit()
    flash("Fonte criada.", "success")
    return redirect(url_for("admin.vortex_admin"))


@admin_bp.route("/vortex/itens")
@login_required
@staff_required
def vortex_items():
    from models import VortexItem
    page = request.args.get("page", 1, type=int)
    import vortex_quality
    motivo = (request.args.get("motivo") or "").strip()
    show_hidden = request.args.get("ocultos") == "1" or bool(motivo)
    query = VortexItem.query.filter(VortexItem.is_active.is_(not show_hidden))
    if motivo == "auto":      # tudo que o filtro automático barrou
        query = query.filter(VortexItem.junk_reason.isnot(None), VortexItem.junk_reason != "manual_ok")
    elif motivo in vortex_quality.REASONS:
        query = query.filter(VortexItem.junk_reason == motivo)
    if request.args.get("categoria"):
        query = query.filter(VortexItem.category == request.args["categoria"])
    if request.args.get("tipo") in ("photo", "gif", "video"):
        query = query.filter(VortexItem.media_type == request.args["tipo"])
    if request.args.get("fonte", type=int):
        query = query.filter(VortexItem.source_id == request.args.get("fonte", type=int))
    if request.args.get("site"):
        query = query.filter(VortexItem.source_name == request.args["site"].strip().lower())
    if request.args.get("q"):
        query = query.filter(VortexItem.title.ilike(f"%{request.args['q'].strip()}%"))
    import vortex_concepts
    conceito = (request.args.get("conceito") or "").strip().lower()
    if conceito == "nenhum":      # analisado, mas nada no texto casou com o vocabulário
        query = query.filter(VortexItem.concept_version.isnot(None), VortexItem.concepts == "")
    elif conceito in vortex_concepts.TAXONOMY:   # o conceito OU qualquer filho (carro inclui esportivo)
        query = query.filter(VortexItem.concept_tags.like(f"% {conceito} %"))
    else:
        conceito = ""
    pagination = query.order_by(VortexItem.id.desc()).paginate(page=page, per_page=36, error_out=False)
    url_args = {k: v for k, v in (("categoria", request.args.get("categoria")), ("tipo", request.args.get("tipo")),
                                  ("conceito", conceito or None),
                                  ("fonte", request.args.get("fonte")), ("site", request.args.get("site")),
                                  ("q", request.args.get("q")), ("motivo", motivo or None),
                                  ("ocultos", "1" if show_hidden else None)) if v}
    return render_template(
        "admin/vortex_items.html", pagination=pagination, show_hidden=show_hidden, url_args=url_args,
        categories=current_app.config["VORTEX_CATEGORIES"], motivo=motivo,
        reasons=vortex_quality.REASONS, conceito=conceito,
        concept_label=vortex_concepts.label_of,
        concept_choices=sorted(((cid, c.label) for cid, c in vortex_concepts.TAXONOMY.items()),
                               key=lambda x: x[1].lower()),
    )


@admin_bp.route("/vortex/qualidade/limpar", methods=["POST"])
@login_required
@admin_required
def vortex_quality_clean():
    """Roda agora, sem rede: filtro de TEXTO (QR/logo/banner pelo nome) e
    agrupamento de repetidas. A análise dos pixels dos itens antigos roda
    sozinha em segundo plano (motor) ou com `python vortex_quality.py --rescan`."""
    import vortex_quality
    from vortex_search import clear_stats_cache
    app = current_app._get_current_object()
    texto = vortex_quality.text_sweep(app, db)
    rep = vortex_quality.dedupe_existing(app, db)
    clear_stats_cache(app)
    log_admin_action(current_user, "vortex_qualidade",
                     f"limpeza: {texto} por nome, {rep['duplicate']} duplicadas, {rep['repeated']} repetidas")
    db.session.commit()
    flash(f"Barrados: {texto} pelo nome, {rep['duplicate']} duplicadas e {rep['repeated']} "
          f"que se repetiam demais.", "success")
    return redirect(url_for("admin.vortex_items", motivo="auto"))


@admin_bp.route("/vortex/itens/<int:item_id>/apagar", methods=["POST"])
@login_required
@admin_required
def vortex_item_delete(item_id):
    """Apaga um item de vez (e impede que volte a ser indexado)."""
    import vortex_control
    if vortex_control.delete_item(current_app._get_current_object(), item_id):
        log_admin_action(current_user, "vortex_item", f"apagou item #{item_id}")
        db.session.commit()
        flash(f"Item #{item_id} apagado.", "success")
    return redirect(request.referrer or url_for("admin.vortex_items"))


@admin_bp.route("/vortex/itens/<int:item_id>/ocultar", methods=["POST"])
@login_required
@staff_required
def vortex_item_toggle(item_id):
    from models import VortexItem
    import vortex_quality
    item = VortexItem.query.get_or_404(item_id)
    if not item.is_active and item.junk_reason and item.junk_reason != "manual_ok":
        vortex_quality.restore(item)   # o filtro automático não barra de novo
    else:
        item.is_active = not item.is_active
    log_admin_action(current_user, "vortex_item", f"{'restaurou' if item.is_active else 'ocultou'} item #{item.id}")
    db.session.commit()
    return redirect(request.referrer or url_for("admin.vortex_items"))
