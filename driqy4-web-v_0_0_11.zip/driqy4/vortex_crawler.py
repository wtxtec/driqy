"""
Crawler do Vortex: indexa fotos, GIFs e vídeos da internet e grava em
VortexItem, cada um ligado a um VortexProfile (o "perfil que publicou").

Os itens NÃO são posts — só o Vortex os consulta (ver /api/v1/vortex).

Motor contínuo (IngestEngine)
-----------------------------
Antes: uma rodada a cada 30 min, uma fonte por vez, 20 itens por fonte, termos
fixos — e a indexação "parava" (~500 itens) quando as buscas iniciais
esgotavam ou quando uma API cortava a paginação e o crawler voltava à página 1
só pra reencontrar duplicatas.

Agora o motor roda o tempo todo e tem três estágios que trabalham em paralelo:

  despachante  escolhe as fontes "vencidas" (next_run_at) e as entrega a N
               threads (VORTEX_WORKERS); cada fonte se reagenda sozinha:
               rendendo => volta em segundos; esgotada => próximo termo;
               erro => backoff exponencial; 429 => respeita Retry-After.
  workers      chamam a API da fonte, filtram, e baixam miniaturas em outro
               pool (VORTEX_DOWNLOAD_WORKERS) pra calcular o dHash; cada item
               pronto vai pra fila no mesmo instante.
  gravador     UMA thread dona do banco: grava em lotes de
               VORTEX_BATCH_SIZE itens ou a cada VORTEX_FLUSH_SECONDS (o que
               vier primeiro) — nada fica mais de ~2 s só na memória.

Fontes (cada uma com `kind` que escolhe um adaptador):

  commons    API do Wikimedia Commons (fotos, GIFs, vídeos livres)
  openverse  API do Openverse (fotos e GIFs com licença aberta)
  nasa       NASA Image and Video Library (sem chave)
  met        The Met, domínio público/CC0 (sem chave)
  artic      Art Institute of Chicago, domínio público (sem chave)
  pexels     API do Pexels (precisa PEXELS_API_KEY)
  pixabay    API do Pixabay (precisa PIXABAY_API_KEY)
  unsplash   API do Unsplash (precisa UNSPLASH_ACCESS_KEY)
  giphy      API do GIPHY (precisa GIPHY_API_KEY)
  rss        feed com media:content / enclosure (term = URL do feed)
  page       página pública, lê og:image / og:video (term = URL)

Cada adaptador devolve "candidatos" (dicts com media_url, thumb_url, título,
tags, licença...). Validamos, deduplicamos (url_hash e dHash), classificamos a
categoria e gravamos. Guardamos só a URL (hotlink) + atribuição; o arquivo
continua no site de origem.

Boas maneiras: User-Agent próprio, timeout, intervalo mínimo por host
(VORTEX_HOST_INTERVALS), Retry-After, e `robots.txt` respeitado nas fontes
`rss`/`page` (as APIs oficiais não passam por robots).

Uso manual:   python vortex_crawler.py --once      (uma rodada de cada fonte)
              python vortex_crawler.py --daemon    (só o motor, sem o site)
Automático:   app.py chama start_engine() ao subir.
"""
import hashlib
import logging
import os
import queue
import random
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import timedelta
from html import unescape
from types import SimpleNamespace
from urllib import robotparser
from urllib.parse import urljoin, urlparse

import requests
from requests.adapters import HTTPAdapter
from sqlalchemy.exc import IntegrityError, OperationalError

from models import VortexCrawlSource, VortexItem, VortexProfile, VortexTombstone, utcnow
from news_classifier import classify
import vortex_control
import vortex_quality
import vortex_understand
import vortex_vision
from vortex_net import UnsafeHost, check_url
from vortex_phash import DUPLICATE_DISTANCE, dhash_from_bytes, image_size_from_bytes

log = logging.getLogger("vortex_crawler")

_popcount = int.bit_count if hasattr(int, "bit_count") else (lambda x: bin(x).count("1"))

_TAG_RE = re.compile(r"<[^>]+>")
_WORD_RE = re.compile(r"[a-zà-úA-ZÀ-Ú0-9]{3,}", re.UNICODE)
_PHOTO_MIMES = {"image/jpeg", "image/jpg", "image/png", "image/webp"}
_VIDEO_MIMES = {"video/mp4", "video/webm"}
# nomes de arquivo que são ícone/pixel/logo e não conteúdo
_BAD_URL_HINTS = (
    "spacer", "blank.gif", "pixel", "1x1", "doubleclick", "gravatar", "avatar-default",
    "logo-", "-logo", "/logos/", "icon-", "-icon", "/icons/", "sprite", "favicon",
)
# termos que tiram o item na entrada (as fontes já filtram, isto é só um
# segundo cinto; o admin também pode desativar itens um a um)
_BLOCKED_TERMS = {
    "nude", "naked", "nsfw", "porn", "erotic", "erotica", "sex", "sexual", "fetish",
    "genitals", "topless", "gore", "corpse", "nudity", "pelado", "pelada", "pornografia",
}
_STOPWORDS = {
    "the", "and", "for", "with", "from", "this", "that", "file", "jpg", "jpeg", "png",
    "gif", "webm", "mp4", "webp", "img", "dsc", "image", "photo", "foto", "uma", "dos",
    "das", "que", "com", "por", "para", "são", "sao", "não", "nao",
}

_RUN_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# utilidades
# ---------------------------------------------------------------------------

class HostLimiter:
    """Intervalo mínimo entre requisições ao mesmo host (todas as threads
    compartilham). `penalize` empurra o host pra frente (usado no 429)."""

    def __init__(self, intervals=None, default=0.0):
        self._lock = threading.Lock()
        self._next = {}
        self._intervals = dict(intervals or {})
        self._default = default
        # >1 deixa tudo mais lento (modo lento do admin); nunca fica < 1:
        # acelerar não pode furar o limite que o site/API impõe
        self.scale = 1.0

    def wait(self, url):
        host = urlparse(url).netloc.lower()
        interval = self._intervals.get(host, self._default) * self.scale
        if interval <= 0:
            return
        with self._lock:
            now = time.monotonic()
            slot = max(now, self._next.get(host, 0.0))
            self._next[host] = slot + interval
        if slot > now:
            time.sleep(slot - now)

    def penalize(self, url, seconds):
        host = urlparse(url).netloc.lower()
        with self._lock:
            self._next[host] = max(self._next.get(host, 0.0), time.monotonic() + seconds)


class ThrottledSession(requests.Session):
    """`requests.Session` que passa pelo HostLimiter antes de cada requisição
    e converte 429 em espera do host inteiro."""

    def __init__(self, limiter=None, allow_private=False):
        super().__init__()
        self.limiter = limiter
        self.allow_private = allow_private
        adapter = HTTPAdapter(pool_connections=32, pool_maxsize=32)
        self.mount("https://", adapter)
        self.mount("http://", adapter)

    def send(self, request, **kwargs):
        # roda em TODA requisição enviada, inclusive nos redirecionamentos
        check_url(request.url, allow_private=self.allow_private)
        return super().send(request, **kwargs)

    def request(self, method, url, **kwargs):
        if self.limiter is not None:
            self.limiter.wait(url)
        resp = super().request(method, url, **kwargs)
        if resp.status_code == 429 and self.limiter is not None:
            self.limiter.penalize(url, _retry_after(resp))
        return resp


def make_http(cfg, limiter=None):
    """Sessão `requests` com o User-Agent do bot."""
    session = ThrottledSession(limiter, allow_private=bool(cfg.get("VORTEX_ALLOW_PRIVATE_HOSTS")))
    session.headers.update({"User-Agent": cfg["VORTEX_USER_AGENT"]})
    return session


def _strip_html(raw):
    if not raw:
        return ""
    return re.sub(r"\s+", " ", unescape(_TAG_RE.sub(" ", raw))).strip()


def _hash_url(url):
    return hashlib.sha256(url.encode("utf-8")).hexdigest()


def _tokens(text):
    out = []
    for w in _WORD_RE.findall((text or "").lower()):
        if w not in _STOPWORDS and not w.isdigit():
            out.append(w)
    return out


def _clean_tags(raw_tags, *extra_texts, limit=15):
    """Lista de tags únicas, minúsculas, curtas. `raw_tags` pode ter frases
    (ex. categorias do Commons) — mantidas inteiras se curtas — e as demais
    fontes de texto contribuem com palavras soltas."""
    seen, tags = set(), []

    def add(tag):
        tag = re.sub(r"\s+", " ", (tag or "").strip().lower())
        if 2 < len(tag) <= 30 and tag not in seen and tag not in _STOPWORDS and "," not in tag:
            seen.add(tag)
            tags.append(tag)

    for t in raw_tags or []:
        add(t)
    for text in extra_texts:
        for w in _tokens(text):
            add(w)
    return tags[:limit]


def _is_blocked(*texts):
    words = set()
    for t in texts:
        words.update(w.lower() for w in re.findall(r"[a-zA-Zà-úÀ-Ú]+", t or ""))
    return bool(words & _BLOCKED_TERMS)


def _looks_like_bad_url(url):
    low = url.lower()
    return any(h in low for h in _BAD_URL_HINTS)


def _safe_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


# robots.txt (rss/page e descoberta) -----------------------------------------
_ROBOTS_CACHE = {}          # base -> (parser, instante)
_ROBOTS_TTL = 24 * 3600


def _robots_parser(http, base, timeout=6):
    """RobotFileParser do host, em cache por 24 h. 4xx = sem robots
    (permitido); 5xx/401/403/erro de rede = não arrisca (bloqueado)."""
    entry = _ROBOTS_CACHE.get(base)
    if entry is not None and time.time() - entry[1] < _ROBOTS_TTL:
        return entry[0]
    parser = robotparser.RobotFileParser()
    try:
        resp = http.get(f"{base}/robots.txt", timeout=timeout)
        if resp.status_code in (401, 403) or resp.status_code >= 500:
            parser.disallow_all = True
        elif resp.status_code >= 400:
            parser.allow_all = True
        else:
            parser.parse(resp.text[:500_000].splitlines())
    except Exception:
        parser.disallow_all = True
    if len(_ROBOTS_CACHE) > 5000:
        for key in sorted(_ROBOTS_CACHE, key=lambda k: _ROBOTS_CACHE[k][1])[:1000]:
            _ROBOTS_CACHE.pop(key, None)
    _ROBOTS_CACHE[base] = (parser, time.time())
    return parser


def robots_allows(http, url, user_agent, timeout=6):
    """True se o robots.txt do host permite buscar `url`."""
    parts = urlparse(url)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        return False
    parser = _robots_parser(http, f"{parts.scheme}://{parts.netloc}", timeout)
    return parser.can_fetch(user_agent, url)


def robots_extras(http, url, user_agent):
    """(Crawl-delay em segundos ou None, [URLs de sitemap]) do host de `url`."""
    parts = urlparse(url)
    parser = _robots_parser(http, f"{parts.scheme}://{parts.netloc}")
    try:
        delay = parser.crawl_delay(user_agent)
    except Exception:
        delay = None
    try:
        maps = list(parser.site_maps() or [])
    except Exception:
        maps = []
    return delay, maps


def _probe(http, url, timeout):
    """Confere (sem baixar o arquivo todo) tipo e tamanho de uma mídia.
    Devolve (content_type, total_bytes|None) ou None se inacessível."""
    try:
        resp = http.get(url, stream=True, timeout=timeout, headers={"Range": "bytes=0-1023"})
        try:
            if resp.status_code not in (200, 206):
                return None
            ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            total = None
            crange = resp.headers.get("Content-Range", "")
            if "/" in crange:
                total = _safe_int(crange.rsplit("/", 1)[1])
            if total is None:
                total = _safe_int(resp.headers.get("Content-Length"))
            return ctype, total
        finally:
            resp.close()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# adaptadores — cada um devolve (lista_de_candidatos, tem_mais_paginas)
# candidato: dict com media_type, media_url, thumb_url, width, height,
# duration, title, description, tags(list), source_url, license, attribution
# ---------------------------------------------------------------------------

class SourceUnavailable(Exception):
    """Fonte desligada (ex.: falta a chave da API) — não é erro de verdade."""


class RateLimited(Exception):
    """A API respondeu 429; tente de novo depois de `retry_after` segundos."""

    def __init__(self, retry_after=60):
        super().__init__(f"limite da API (429), aguardando {int(retry_after)}s")
        self.retry_after = retry_after


def _retry_after(resp, default=60):
    try:
        value = int(float((getattr(resp, "headers", None) or {}).get("Retry-After", default)))
    except (TypeError, ValueError):
        value = default
    return max(5, min(value, 3600))


def _api_get(http, cfg, url, **kwargs):
    kwargs.setdefault("timeout", cfg["VORTEX_REQUEST_TIMEOUT"])
    resp = http.get(url, **kwargs)
    if resp.status_code == 429:
        raise RateLimited(_retry_after(resp))
    resp.raise_for_status()
    return resp.json()


def fetch_commons(http, cfg, source, page):
    per_page = 30
    q = (source.term or "").strip()
    if source.media == "video":
        search = f"{q} filetype:video"
    elif source.media == "gif":
        search = f'incategory:"Animated GIF files" {q}'
    else:
        search = f"{q} filetype:bitmap"
    data = _api_get(http, cfg, "https://commons.wikimedia.org/w/api.php", params={
        "action": "query", "format": "json", "formatversion": "2",
        "generator": "search", "gsrnamespace": "6", "gsrsearch": search.strip(),
        "gsrlimit": per_page, "gsroffset": (page - 1) * per_page,
        "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata", "iiurlwidth": 600,
        "iiextmetadatafilter": "ImageDescription|Artist|LicenseShortName|Categories|ObjectName",
    })
    pages = (data.get("query") or {}).get("pages") or []
    if isinstance(pages, dict):  # formatversion antigo
        pages = list(pages.values())
    pages = sorted(pages, key=lambda p: p.get("index", 0))
    out = []
    for p in pages:
        info = (p.get("imageinfo") or [None])[0]
        if not info:
            continue
        mime = (info.get("mime") or "").lower()
        if source.media == "video" and mime not in _VIDEO_MIMES:
            continue
        if source.media == "gif" and mime != "image/gif":
            continue
        if source.media == "photo" and mime not in _PHOTO_MIMES:
            continue
        meta = info.get("extmetadata") or {}

        def mv(key):
            return _strip_html((meta.get(key) or {}).get("value", ""))

        title = mv("ObjectName") or re.sub(
            r"\.[A-Za-z0-9]{2,4}$", "",
            (p.get("title") or "").replace("File:", "").replace("_", " "),
        )
        cats = [c.replace("_", " ") for c in mv("Categories").split("|") if c][:12]
        out.append({
            "media_type": source.media,
            "media_url": info.get("url"),
            "thumb_url": info.get("thumburl") or None,
            "width": info.get("width"), "height": info.get("height"),
            "duration": _safe_int(info.get("duration")),
            "size_bytes": _safe_int(info.get("size")),
            "title": title, "description": mv("ImageDescription"),
            "tags": cats,
            "source_url": info.get("descriptionurl"),
            "license": mv("LicenseShortName") or None,
            "attribution": mv("Artist") or None,
        })
    return out, "continue" in data


_OV_TOKEN = {"value": None, "exp": 0.0}
_OV_LOCK = threading.Lock()


def _openverse_headers(http, cfg):
    """Token OAuth do Openverse (cota bem maior que a anônima). Sem
    OPENVERSE_CLIENT_ID/SECRET, devolve {} e o motor segue anônimo."""
    cid, secret = cfg.get("OPENVERSE_CLIENT_ID"), cfg.get("OPENVERSE_CLIENT_SECRET")
    if not (cid and secret):
        return {}
    with _OV_LOCK:
        if not _OV_TOKEN["value"] or _OV_TOKEN["exp"] < time.time() + 60:
            resp = http.post(
                "https://api.openverse.org/v1/auth_token/token/",
                data={"grant_type": "client_credentials", "client_id": cid, "client_secret": secret},
                timeout=cfg["VORTEX_REQUEST_TIMEOUT"],
            )
            resp.raise_for_status()
            body = resp.json()
            _OV_TOKEN["value"] = body.get("access_token")
            _OV_TOKEN["exp"] = time.time() + int(body.get("expires_in") or 3600)
        token = _OV_TOKEN["value"]
    return {"Authorization": f"Bearer {token}"} if token else {}


def fetch_openverse(http, cfg, source, page):
    params = {"q": source.term, "page": page, "page_size": 20}
    params["extension"] = "gif" if source.media == "gif" else "jpg,jpeg,png,webp"
    data = _api_get(http, cfg, "https://api.openverse.org/v1/images/", params=params,
                    headers=_openverse_headers(http, cfg) or None)
    out = []
    for r in data.get("results") or []:
        if r.get("mature"):
            continue
        lic = " ".join(x for x in (r.get("license"), r.get("license_version")) if x).upper()
        out.append({
            "media_type": "gif" if source.media == "gif" else "photo",
            "media_url": r.get("url"),
            "thumb_url": r.get("thumbnail") or None,
            "width": r.get("width"), "height": r.get("height"),
            "title": r.get("title") or "",
            "description": "",
            "tags": [t.get("name") for t in (r.get("tags") or []) if t.get("name")][:12],
            "source_url": r.get("foreign_landing_url"),
            "license": lic or None,
            "attribution": r.get("creator") or None,
        })
    return out, bool(out)


def fetch_pexels(http, cfg, source, page):
    key = cfg.get("PEXELS_API_KEY")
    if not key:
        raise SourceUnavailable("sem PEXELS_API_KEY")
    headers = {"Authorization": key}
    out = []
    if source.media == "video":
        data = _api_get(http, cfg, "https://api.pexels.com/videos/search", headers=headers,
                        params={"query": source.term, "per_page": 15, "page": page})
        for v in data.get("videos") or []:
            files = [f for f in (v.get("video_files") or [])
                     if f.get("file_type") == "video/mp4" and f.get("link")]
            if not files:
                continue
            # menor arquivo com pelo menos 480 px de largura (leve pro celular);
            # se nenhum chega a isso, o maior disponível
            wide = [f for f in files if (f.get("width") or 0) >= 480]
            f = min(wide, key=lambda f: f["width"]) if wide else max(files, key=lambda f: f.get("width") or 0)
            out.append({
                "media_type": "video", "media_url": f["link"], "thumb_url": v.get("image"),
                "width": f.get("width") or v.get("width"), "height": f.get("height") or v.get("height"),
                "duration": _safe_int(v.get("duration")),
                "title": "", "description": "",
                "tags": [], "source_url": v.get("url"),
                "license": "Pexels License", "attribution": (v.get("user") or {}).get("name"),
                "text_hint": (v.get("url") or "").rstrip("/").rsplit("/", 1)[-1].replace("-", " "),
            })
        return out, bool(data.get("next_page"))
    data = _api_get(http, cfg, "https://api.pexels.com/v1/search", headers=headers,
                    params={"query": source.term, "per_page": 20, "page": page})
    for p in data.get("photos") or []:
        src = p.get("src") or {}
        out.append({
            "media_type": "photo", "media_url": src.get("large2x") or src.get("original"),
            "thumb_url": src.get("large") or src.get("medium"),
            "width": p.get("width"), "height": p.get("height"),
            "title": p.get("alt") or "", "description": "", "tags": [],
            "source_url": p.get("url"),
            "license": "Pexels License", "attribution": p.get("photographer"),
        })
    return out, bool(data.get("next_page"))


def fetch_pixabay(http, cfg, source, page):
    key = cfg.get("PIXABAY_API_KEY")
    if not key:
        raise SourceUnavailable("sem PIXABAY_API_KEY")
    params = {"key": key, "q": source.term, "per_page": 20, "page": page, "safesearch": "true"}
    out = []
    if source.media == "video":
        data = _api_get(http, cfg, "https://pixabay.com/api/videos/", params=params)
        for h in data.get("hits") or []:
            vids = h.get("videos") or {}
            v = vids.get("medium") or vids.get("small") or vids.get("large") or {}
            if not v.get("url"):
                continue
            thumb = v.get("thumbnail") or (
                f"https://i.vimeocdn.com/video/{h['picture_id']}_640x360.jpg" if h.get("picture_id") else None
            )
            out.append({
                "media_type": "video", "media_url": v["url"], "thumb_url": thumb,
                "width": v.get("width"), "height": v.get("height"),
                "duration": _safe_int(h.get("duration")),
                "title": "", "description": "",
                "tags": [t.strip() for t in (h.get("tags") or "").split(",")],
                "source_url": h.get("pageURL"), "license": "Pixabay License",
                "attribution": h.get("user"),
            })
        return out, bool(data.get("hits"))
    params["image_type"] = "photo"
    data = _api_get(http, cfg, "https://pixabay.com/api/", params=params)
    for h in data.get("hits") or []:
        out.append({
            "media_type": "photo", "media_url": h.get("largeImageURL") or h.get("webformatURL"),
            "thumb_url": h.get("webformatURL"),
            "width": h.get("imageWidth"), "height": h.get("imageHeight"),
            "title": "", "description": "",
            "tags": [t.strip() for t in (h.get("tags") or "").split(",")],
            "source_url": h.get("pageURL"), "license": "Pixabay License",
            "attribution": h.get("user"),
        })
    return out, bool(data.get("hits"))


def fetch_giphy(http, cfg, source, page):
    key = cfg.get("GIPHY_API_KEY")
    if not key:
        raise SourceUnavailable("sem GIPHY_API_KEY")
    limit = 20
    data = _api_get(http, cfg, "https://api.giphy.com/v1/gifs/search", params={
        "api_key": key, "q": source.term, "limit": limit,
        "offset": (page - 1) * limit, "rating": "g",
    })
    out = []
    for g in data.get("data") or []:
        imgs = g.get("images") or {}
        orig = imgs.get("original") or {}
        pick = orig
        if (_safe_int(orig.get("size")) or 0) > cfg["VORTEX_MAX_GIF_BYTES"]:
            pick = imgs.get("downsized") or imgs.get("fixed_width") or orig
        if not pick.get("url"):
            continue
        out.append({
            "media_type": "gif", "media_url": pick["url"],
            "thumb_url": (imgs.get("fixed_width_still") or {}).get("url"),
            "width": _safe_int(pick.get("width")), "height": _safe_int(pick.get("height")),
            "size_bytes": _safe_int(pick.get("size")),
            "title": g.get("title") or "", "description": "", "tags": [],
            "source_url": g.get("url"), "license": "GIPHY",
            "attribution": g.get("username") or ((g.get("user") or {}).get("display_name")),
        })
    pagination = data.get("pagination") or {}
    total = pagination.get("total_count") or 0
    return out, (page * limit) < total


def fetch_unsplash(http, cfg, source, page):
    key = cfg.get("UNSPLASH_ACCESS_KEY")
    if not key:
        raise SourceUnavailable("sem UNSPLASH_ACCESS_KEY")
    data = _api_get(http, cfg, "https://api.unsplash.com/search/photos",
                    headers={"Authorization": f"Client-ID {key}", "Accept-Version": "v1"},
                    params={"query": source.term, "page": page, "per_page": 30,
                            "content_filter": "high"})
    out = []
    for p in data.get("results") or []:
        urls = p.get("urls") or {}
        tags = [t.get("title") for t in (p.get("tags") or []) if t.get("title")]
        out.append({
            "media_type": "photo", "media_url": urls.get("regular") or urls.get("full"),
            "thumb_url": urls.get("small"),
            "width": p.get("width"), "height": p.get("height"),
            "title": p.get("alt_description") or p.get("description") or "",
            "description": "", "tags": tags[:12],
            "source_url": (p.get("links") or {}).get("html"),
            "license": "Unsplash License",
            "attribution": (p.get("user") or {}).get("name"),
        })
    return out, page < (data.get("total_pages") or 0)


def fetch_nasa(http, cfg, source, page):
    """NASA Image and Video Library (domínio público na maioria). Só fotos."""
    if source.media != "photo":
        return [], False
    data = _api_get(http, cfg, "https://images-api.nasa.gov/search", params={
        "q": source.term, "media_type": "image", "page": page, "page_size": 50})
    col = data.get("collection") or {}
    out = []
    for it in col.get("items") or []:
        meta = (it.get("data") or [{}])[0]
        preview = next((l.get("href") for l in (it.get("links") or [])
                        if l.get("rel") == "preview" and l.get("href")), None)
        if not preview or "~thumb." not in preview:
            continue
        out.append({
            "media_type": "photo",
            # variante média (não existe pra todos): confirmamos com _probe
            "media_url": preview.replace("~thumb.", "~medium."), "thumb_url": None,
            "title": meta.get("title") or "", "description": _strip_html(meta.get("description"))[:600],
            "tags": list(meta.get("keywords") or [])[:12],
            "source_url": f"https://images.nasa.gov/details/{meta.get('nasa_id')}" if meta.get("nasa_id") else None,
            "license": "NASA (uso público)", "attribution": meta.get("photographer") or meta.get("center") or "NASA",
            "needs_probe": True,
        })
    has_more = any(l.get("rel") == "next" for l in (col.get("links") or []))
    return out, has_more


_MET_IDS = {}  # (termo) -> (instante, [ids]); a busca devolve todos os ids de uma vez
_MET_PAGE = 15


def fetch_met(http, cfg, source, page):
    """The Met (Open Access, CC0): 1 busca (em cache) + 1 requisição por obra."""
    if source.media != "photo":
        return [], False
    base = "https://collectionapi.metmuseum.org/public/collection/v1"
    cached = _MET_IDS.get(source.term)
    if cached is None or time.time() - cached[0] > 3600:
        data = _api_get(http, cfg, f"{base}/search", params={
            "q": source.term, "hasImages": "true", "isPublicDomain": "true"})
        cached = (time.time(), list(data.get("objectIDs") or []))
        _MET_IDS[source.term] = cached
    ids = cached[1][(page - 1) * _MET_PAGE: page * _MET_PAGE]
    out = []
    for oid in ids:
        try:
            o = _api_get(http, cfg, f"{base}/objects/{oid}")
        except RateLimited:
            raise
        except Exception:
            continue
        img = o.get("primaryImage") or ""
        if not o.get("isPublicDomain") or not img.lower().endswith((".jpg", ".jpeg", ".png")):
            continue
        tags = [t.get("term") for t in (o.get("tags") or []) if t.get("term")]
        tags += [x for x in (o.get("objectName"), o.get("classification"), o.get("culture"),
                             o.get("department")) if x]
        out.append({
            "media_type": "photo", "media_url": img,
            "thumb_url": o.get("primaryImageSmall") or None,
            "title": o.get("title") or "", "description": "", "tags": tags[:12],
            "source_url": o.get("objectURL"), "license": "CC0 (domínio público)",
            "attribution": o.get("artistDisplayName") or "The Metropolitan Museum of Art",
        })
    return out, page * _MET_PAGE < len(cached[1])


def fetch_artic(http, cfg, source, page):
    """Art Institute of Chicago (domínio público; imagens via IIIF)."""
    if source.media != "photo":
        return [], False
    data = _api_get(http, cfg, "https://api.artic.edu/api/v1/artworks/search", params={
        "q": source.term, "page": page, "limit": 30,
        "query[term][is_public_domain]": "true",
        "fields": "id,title,image_id,thumbnail,artist_title,classification_titles,"
                  "style_titles,subject_titles,term_titles",
    })
    iiif = ((data.get("config") or {}).get("iiif_url")) or "https://www.artic.edu/iiif/2"
    out = []
    for a in data.get("data") or []:
        image_id = a.get("image_id")
        if not image_id:
            continue
        thumb = a.get("thumbnail") or {}
        tags = []
        for key in ("subject_titles", "style_titles", "classification_titles", "term_titles"):
            tags += [t for t in (a.get(key) or []) if t]
        out.append({
            "media_type": "photo",
            "media_url": f"{iiif}/{image_id}/full/843,/0/default.jpg",
            "thumb_url": f"{iiif}/{image_id}/full/400,/0/default.jpg",
            "width": thumb.get("width"), "height": thumb.get("height"),
            "title": a.get("title") or "", "description": "", "tags": tags[:12],
            "source_url": f"https://www.artic.edu/artworks/{a.get('id')}",
            "license": "CC0 (domínio público)",
            "attribution": a.get("artist_title") or "Art Institute of Chicago",
        })
    total_pages = ((data.get("pagination") or {}).get("total_pages")) or 0
    return out, page < total_pages


_RSS_IMG_RE = re.compile(r"<img\b[^>]*>", re.IGNORECASE)
_RSS_SRC_RE = re.compile(r"""\bsrc\s*=\s*["']([^"']+)["']""", re.IGNORECASE)
_RSS_W_RE = re.compile(r"""\bwidth\s*=\s*["']?(\d+)""", re.IGNORECASE)
_RSS_H_RE = re.compile(r"""\bheight\s*=\s*["']?(\d+)""", re.IGNORECASE)


def fetch_rss(http, cfg, source, page):
    """Feed com mídia embutida. Só a 1ª página existe (feeds não paginam)."""
    import feedparser

    if page > 1:
        return [], False
    if not robots_allows(http, source.term, cfg["VORTEX_USER_AGENT"]):
        raise SourceUnavailable("bloqueado pelo robots.txt")
    resp = http.get(source.term, timeout=cfg["VORTEX_REQUEST_TIMEOUT"])
    if resp.status_code == 429:
        raise RateLimited(_retry_after(resp))
    resp.raise_for_status()
    parsed = feedparser.parse(resp.content)
    host = urlparse(source.term).netloc
    out = []
    for entry in parsed.entries[:60]:
        urls = []
        for m in getattr(entry, "media_content", []) or []:
            urls.append((m.get("url"), (m.get("medium") or m.get("type") or "")))
        for enc in getattr(entry, "enclosures", []) or []:
            urls.append((enc.get("href") or enc.get("url"), enc.get("type") or ""))
        for m in getattr(entry, "media_thumbnail", []) or []:
            urls.append((m.get("url"), "image"))
        base = getattr(entry, "link", None) or source.term
        if not urls and source.media == "photo":
            # feeds de blog (WordPress etc.) trazem a imagem só no HTML do item
            html = " ".join(c.get("value", "") for c in (getattr(entry, "content", None) or []))
            html += " " + (getattr(entry, "summary", "") or "")
            for tag in _RSS_IMG_RE.findall(html)[:3]:
                m = _RSS_SRC_RE.search(tag)
                if not m:
                    continue
                wm, hm = _RSS_W_RE.search(tag), _RSS_H_RE.search(tag)
                if (wm and int(wm.group(1)) < 200) or (hm and int(hm.group(1)) < 200):
                    continue
                urls.append((unescape(m.group(1)), "image"))
        for url, kind in urls:
            if not url:
                continue
            kind = kind.lower()
            is_video = kind.startswith("video")
            if (source.media == "video") != is_video:
                continue
            if source.media == "gif" and not url.lower().split("?")[0].endswith(".gif"):
                continue
            out.append({
                "media_type": source.media, "media_url": urljoin(base, url), "thumb_url": None,
                "width": None, "height": None,
                "title": _strip_html(getattr(entry, "title", "")),
                "description": _strip_html(getattr(entry, "summary", ""))[:600],
                "tags": [t.get("term") for t in (getattr(entry, "tags", []) or []) if t.get("term")],
                "source_url": base, "license": None, "attribution": host,
                "needs_probe": True,
            })
            break
    return out, False


_OG_META_RE = re.compile(
    r'<meta[^>]+(?:property|name)=["\'](og:image(?::secure_url|:url)?|twitter:image(?::src)?|'
    r'og:video(?::secure_url|:url)?)["\'][^>]+content=["\']([^"\']+)["\']', re.IGNORECASE,
)
_OG_TITLE_RE = re.compile(
    r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)["\']', re.IGNORECASE,
)


def fetch_page(http, cfg, source, page):
    """Página pública: pega og:image / og:video. Só a 1ª página."""
    if page > 1:
        return [], False
    if not robots_allows(http, source.term, cfg["VORTEX_USER_AGENT"]):
        raise SourceUnavailable("bloqueado pelo robots.txt")
    resp = http.get(source.term, timeout=cfg["VORTEX_REQUEST_TIMEOUT"])
    resp.raise_for_status()
    html = resp.text[:400_000]
    title_m = _OG_TITLE_RE.search(html)
    title = unescape(title_m.group(1)) if title_m else ""
    out = []
    for prop, url in _OG_META_RE.findall(html):
        is_video = prop.lower().startswith("og:video")
        if (source.media == "video") != is_video:
            continue
        out.append({
            "media_type": source.media, "media_url": urljoin(source.term, unescape(url)),
            "thumb_url": None, "title": title, "description": "", "tags": [],
            "source_url": source.term, "license": None,
            "attribution": urlparse(source.term).netloc, "needs_probe": True,
        })
    return out, False


ADAPTERS = {
    "commons": fetch_commons,
    "openverse": fetch_openverse,
    "pexels": fetch_pexels,
    "pixabay": fetch_pixabay,
    "unsplash": fetch_unsplash,
    "nasa": fetch_nasa,
    "met": fetch_met,
    "artic": fetch_artic,
    "giphy": fetch_giphy,
    "rss": fetch_rss,
    "page": fetch_page,
}

# páginas além disso costumam piorar/acabar — volta pro começo
_MAX_PAGE = 40


# ---------------------------------------------------------------------------
# termos que se renovam (é o que impede a indexação de "acabar")
# ---------------------------------------------------------------------------

_ROTATING_KINDS = {"commons", "openverse", "pexels", "pixabay", "unsplash", "giphy",
                   "nasa", "met", "artic"}
_NO_PAGING_KINDS = {"rss", "page"}


def _pool_for(cfg, category):
    pools = cfg.get("VORTEX_EXPAND_TERMS") or {}
    return pools.get(category) or pools.get("geral") or []


def effective_term(cfg, kind, base_term, category, rotation):
    """Termo realmente buscado: o da fonte (rotation 0) ou, depois que ele
    esgotou, o N-ésimo da lista de expansão da categoria."""
    if not rotation or kind not in _ROTATING_KINDS:
        return base_term
    pool = _pool_for(cfg, category)
    if not pool:
        return base_term
    return pool[(rotation - 1) % len(pool)]


def make_snapshot(cfg, row):
    """Cópia simples da fonte (sem ORM) pra usar nas threads de rede."""
    profile = row.profile
    return SimpleNamespace(
        id=row.id, name=row.name, kind=row.kind, base_term=row.term, media=row.media,
        category=row.category, profile_id=row.profile_id,
        rotation=row.rotation or 0, next_page=row.next_page or 1,
        term=effective_term(cfg, row.kind, row.term, row.category, row.rotation or 0),
        source_name=(urlparse(row.term).netloc.lower().removeprefix("www.")
                     if getattr(row, "origin", "manual") == "auto" and row.kind in _NO_PAGING_KINDS
                     else ((profile.source_site or profile.display_name) if profile else row.name))[:120],
    )


def _new_result(snap):
    return SimpleNamespace(source_id=snap.id, page=snap.next_page, term=snap.term, n=0,
                           has_more=False, added=0, error=None, unavailable=False,
                           retry_after=None)


def _fail(res, exc):
    if isinstance(exc, SourceUnavailable):
        res.unavailable, res.error = True, f"pulada: {exc}"
    elif isinstance(exc, RateLimited):
        res.retry_after, res.error = exc.retry_after, str(exc)
    else:
        res.error = f"erro: {str(exc)[:250]}"


def _fetch(http, cfg, snap):
    adapter = ADAPTERS.get(snap.kind)
    if adapter is None:
        raise SourceUnavailable(f"tipo desconhecido: {snap.kind}")
    return adapter(http, cfg, snap, snap.next_page)


def _jitter(seconds):
    return seconds * (1.0 + random.random() * 0.2)


def _rotate(cfg, row):
    """Esgotou o termo: vai pro próximo da lista (página 1). Devolve a espera."""
    row.next_page, row.empty_streak = 1, 0
    pool = _pool_for(cfg, row.category)
    if row.kind not in _ROTATING_KINDS or not pool:
        return cfg["VORTEX_IDLE_DELAY"]       # nada novo pra tentar: espera
    row.rotation = (row.rotation or 0) + 1
    if row.rotation > 3 * len(pool):          # 3 voltas na lista toda sem fôlego
        row.rotation = 0
        return cfg["VORTEX_IDLE_DELAY"] * 4
    return cfg["VORTEX_ROTATE_DELAY"]


def apply_source_result(cfg, row, res):
    """Atualiza a fonte com o resultado da rodada e decide quando volta."""
    now = utcnow()
    row.last_run_at = now
    row.items_added = (row.items_added or 0) + res.added
    if res.unavailable:
        row.last_status = res.error
        row.next_run_at = now + timedelta(seconds=cfg["VORTEX_UNAVAILABLE_DELAY"])
        return
    if res.retry_after:
        row.fail_count = (row.fail_count or 0) + 1
        row.last_status = res.error
        row.next_run_at = now + timedelta(seconds=_jitter(res.retry_after))
        return
    if res.error:
        row.fail_count = (row.fail_count or 0) + 1
        row.last_status = res.error
        if (row.next_page or 1) > 1:
            # erro em página funda (ex.: limite de paginação da API): em vez
            # de voltar à página 1 do MESMO termo (só duplicatas), troca de termo
            if row.kind in _ROTATING_KINDS:
                _rotate(cfg, row)
            else:
                row.next_page = 1
        delay = min(30 * 2 ** min(row.fail_count, 7), cfg["VORTEX_MAX_BACKOFF"])
        row.next_run_at = now + timedelta(seconds=_jitter(delay))
        return

    row.fail_count = 0
    row.empty_streak = 0 if res.added else (row.empty_streak or 0) + 1
    row.last_status = f"ok: {res.added} novo(s) de {res.n} (pág. {res.page}, termo “{res.term[:60]}”)"
    if row.kind in _NO_PAGING_KINDS:
        row.next_page = 1
        delay = cfg["VORTEX_IDLE_DELAY"]
    elif (not res.n or not res.has_more or res.page >= _MAX_PAGE
          or row.empty_streak >= cfg["VORTEX_EMPTY_STREAK_ROTATE"]):
        delay = _rotate(cfg, row)
    else:
        row.next_page = res.page + 1
        delay = cfg["VORTEX_SOURCE_MIN_DELAY"]
    row.next_run_at = now + timedelta(seconds=_jitter(delay))


# ---------------------------------------------------------------------------
# validação e enriquecimento de candidatos
# ---------------------------------------------------------------------------

def _download_head(http, url, timeout, max_bytes=3_000_000):
    """Baixa até `max_bytes` de uma imagem (pra calcular o dHash)."""
    try:
        resp = http.get(url, stream=True, timeout=timeout)
        try:
            if resp.status_code != 200:
                return None
            ctype = (resp.headers.get("Content-Type") or "").lower()
            if not ctype.startswith("image/"):
                return None
            buf = bytearray()
            for chunk in resp.iter_content(65536):
                buf.extend(chunk)
                if len(buf) > max_bytes:
                    return None
            return bytes(buf)
        finally:
            resp.close()
    except Exception:
        return None


def Image_open_rgb(data):
    """Imagem PIL RGB (miniatura) pro CLIP."""
    from io import BytesIO
    img = vortex_vision.Image.open(BytesIO(data))
    try:
        img.seek(0)
    except Exception:
        pass
    return img.convert("RGB")


class PhashSet:
    """dHashes já conhecidos (inteiros). `claim` é atômico: diz se o hash é
    novo (e já o registra) ou quase-duplicata de algum existente."""

    def __init__(self, values=()):
        self._lock = threading.Lock()
        self._vals = list(values)

    def __len__(self):
        return len(self._vals)

    def claim(self, phash_hex, max_distance=DUPLICATE_DISTANCE):
        try:
            value = int(phash_hex, 16)
        except (TypeError, ValueError):
            return True
        with self._lock:
            for known in self._vals:
                if _popcount(value ^ known) <= max_distance:
                    return False
            self._vals.append(value)
            return True


def prefilter(cfg, candidates):
    """Filtros baratos (sem rede): URL, tamanho declarado, termos bloqueados."""
    min_dim = cfg["VORTEX_MIN_DIMENSION"]
    prepared = []
    for c in candidates:
        url = (c.get("media_url") or "").strip()
        if not url.startswith(("http://", "https://")) or len(url) > 900:
            continue
        if _looks_like_bad_url(url):
            continue
        thumb = (c.get("thumb_url") or "").strip() or None
        if thumb and (not thumb.startswith(("http://", "https://")) or len(thumb) > 900):
            thumb = None
        c["media_url"], c["thumb_url"] = url, thumb
        w, h = _safe_int(c.get("width")), _safe_int(c.get("height"))
        if w and h:
            if min(w, h) < min_dim or max(w, h) / max(1, min(w, h)) > 4:
                continue
        if c["media_type"] == "gif" and (c.get("size_bytes") or 0) > cfg["VORTEX_MAX_GIF_BYTES"]:
            continue
        title = _strip_html(c.get("title"))[:300]
        desc = _strip_html(c.get("description"))[:600]
        if _is_blocked(title, desc, " ".join(c.get("tags") or []), c.get("text_hint", "")):
            continue
        # QR code, logo, banner, placeholder... pelo nome/título (sem rede)
        if cfg.get("VORTEX_QUALITY_ENABLED", True) and vortex_quality.check_text(
                url, title, " ".join(c.get("tags") or []), c.get("source_url") or ""):
            continue
        c["title"], c["description"] = title, desc
        prepared.append(c)
    return prepared


def enrich(cfg, http, snap, c, claim_phash):
    """Estágio de rede de UM candidato: confere tipo/tamanho (rss/page),
    baixa a miniatura, calcula o dHash, descarta quase-duplicatas e monta o
    dict pronto pra virar VortexItem. Devolve None se for descartado."""
    timeout = cfg["VORTEX_REQUEST_TIMEOUT"]
    min_dim = cfg["VORTEX_MIN_DIMENSION"]
    valid_categories = {slug for slug, _ in cfg["VORTEX_CATEGORIES"]}
    w, h = _safe_int(c.get("width")), _safe_int(c.get("height"))

    # rss/page/nasa não informam tipo/tamanho: confere com uma requisição leve
    if c.get("needs_probe"):
        probe = _probe(http, c["media_url"], timeout)
        if not probe:
            return None
        ctype, total = probe
        if c["media_type"] == "video" and ctype not in _VIDEO_MIMES:
            return None
        if c["media_type"] == "gif" and ctype != "image/gif":
            return None
        if c["media_type"] == "photo" and ctype not in _PHOTO_MIMES:
            return None
        if total is not None and total < 5_000 and c["media_type"] != "video":
            return None
        if c["media_type"] == "gif" and total and total > cfg["VORTEX_MAX_GIF_BYTES"]:
            return None

    phash, vis, data = None, None, None
    thumb_max = cfg.get("VORTEX_THUMB_MAX_BYTES", 3_000_000)
    if c["media_type"] in ("photo", "gif") and (c.get("thumb_url") or c["media_type"] == "photo"):
        data = _download_head(http, c.get("thumb_url") or c["media_url"], timeout, max_bytes=thumb_max)
        if data:
            phash = dhash_from_bytes(data)
            if (not w or not h) and c["media_type"] == "photo" and not c.get("thumb_url"):
                size = image_size_from_bytes(data)
                if size:
                    w, h = size
    quality_checked = False
    if data and cfg.get("VORTEX_QUALITY_ENABLED", True) and c["media_type"] in ("photo", "gif"):
        # QR code, logo/arte chapada, recorte transparente, imagem em branco
        reason, _m = vortex_quality.inspect_bytes(data, c["media_type"])
        if reason:
            return None
        quality_checked = True
    if phash and not claim_phash(phash, cfg.get("VORTEX_DEDUPE_DISTANCE", DUPLICATE_DISTANCE)):
        return None  # quase-duplicata de algo que já temos
    if w and h and min(w, h) < min_dim:
        return None
    if cfg.get("VORTEX_VISION_ENABLED", True):
        # assinatura de aparência com os mesmos bytes (vídeo: usa o pôster)
        if data is None and c["media_type"] == "video" and c.get("thumb_url"):
            data = _download_head(http, c["thumb_url"], timeout, max_bytes=thumb_max)
        vis = vortex_vision.describe_image(data) if data else None
        if (data and c["media_type"] == "video" and cfg.get("VORTEX_QUALITY_ENABLED", True)):
            # capa do vídeo que é QR code / tela em branco
            reason, _m = vortex_quality.inspect_bytes(data, "video")
            if reason:
                return None
            quality_checked = True

    category = snap.category if snap.category in valid_categories else None
    text_for_tags = f"{c['title']} {c.get('text_hint', '')}"
    tags = _clean_tags(c.get("tags"), text_for_tags)
    if not category:
        category, _ = classify(
            f"{c['title']} {' '.join(tags)}", c["description"], cfg["VORTEX_CATEGORY_KEYWORDS"],
            default_category="outros",
        )
        if category not in valid_categories:
            category = "outros"

    # compreensão de conteúdo (título/tags -> conceitos); "outros" vira a categoria do domínio
    # quando o texto aponta um com confiança. Só texto: sem rede, ~0,1 ms.
    understood = {}
    if cfg.get("VORTEX_CONCEPTS_ENABLED", True):
        try:
            understood, u = vortex_understand.build_fields(
                c["title"], ",".join(tags), c["description"], "", category)
            better = vortex_understand.suggest_category(
                u, category, valid_categories,
                cfg.get("VORTEX_CONCEPTS_RECLASSIFY_MIN_CONFIDENCE",
                        vortex_understand.RECLASSIFY_MIN_CONFIDENCE))
            if better:
                category = better
        except Exception:
            log.exception("[vortex] falha ao entender o conteúdo de um item novo")
            understood = {}

    return dict(
        profile_id=snap.profile_id, source_id=snap.id,
        media_type=c["media_type"], media_url=c["media_url"], thumb_url=c.get("thumb_url"),
        width=w, height=h, duration_seconds=c.get("duration"),
        title=c["title"], description=c["description"],
        tags=",".join(tags)[:500], category=category,
        source_url=(c.get("source_url") or None) and c["source_url"][:900],
        source_name=snap.source_name,
        license=(c.get("license") or None) and c["license"][:120],
        attribution=(c.get("attribution") or None) and c["attribution"][:300],
        phash=phash, url_hash=_hash_url(c["media_url"]), last_checked_at=utcnow(),
        vfeat=vis["hex"] if vis else None,
        visual_tags=(",".join(vis["tags"]) or None) if vis else None,
        vision_version=vortex_vision.VISION_VERSION if vis else None,
        quality_version=vortex_quality.QUALITY_VERSION if quality_checked else None,
        **understood,
    )


# ---------------------------------------------------------------------------
# rodada única e síncrona de UMA fonte (admin/testes; usa o http recebido)
# ---------------------------------------------------------------------------

def _new_state(app):
    recent = (
        VortexItem.query.with_entities(VortexItem.phash)
        .filter(VortexItem.phash.isnot(None)).order_by(VortexItem.id.desc()).limit(4000).all()
    )
    values = []
    for (ph,) in recent:
        try:
            values.append(int(ph, 16))
        except (TypeError, ValueError):
            continue
    return {"phashes": PhashSet(values)}


def crawl_source(app, db, source, http=None, state=None):
    """Rastreia UMA fonte (uma página de resultados), em série. Devolve itens
    novos. Nunca levanta: erros viram `last_status` da fonte. O motor
    contínuo (IngestEngine) faz o mesmo em paralelo."""
    cfg = app.config
    http = http or make_http(cfg)
    state = state or _new_state(app)
    snap = make_snapshot(cfg, source)
    res = _new_result(snap)
    try:
        candidates, has_more = _fetch(http, cfg, snap)
        res.n, res.has_more = len(candidates), has_more
        hashes = {}
        for c in prefilter(cfg, candidates):
            hashes.setdefault(_hash_url(c["media_url"]), c)
        existing = set()
        if hashes:
            existing = {row[0] for row in db.session.query(VortexItem.url_hash)
                        .filter(VortexItem.url_hash.in_(list(hashes))).all()}
        records = []
        for url_hash, c in hashes.items():
            if len(records) >= cfg["VORTEX_MAX_ITEMS_PER_SOURCE_RUN"]:
                break
            if url_hash in existing:
                continue
            rec = enrich(cfg, http, snap, c, state["phashes"].claim)
            if rec:
                records.append(rec)
        db.session.add_all([VortexItem(**r) for r in records])
        db.session.commit()
        res.added = len(records)
    except Exception as exc:
        db.session.rollback()
        _fail(res, exc)
        if not isinstance(exc, (SourceUnavailable, RateLimited)):
            app.logger.warning(f"[vortex_crawler] '{snap.name}': {exc}")
    row = db.session.get(VortexCrawlSource, snap.id)
    apply_source_result(cfg, row, res)
    db.session.commit()
    return res.added


def prune_old_items(app, db):
    cap = app.config.get("VORTEX_MAX_ITEMS", 60000)
    total = VortexItem.query.count()
    if total <= cap:
        return
    cutoff = (
        VortexItem.query.with_entities(VortexItem.id).order_by(VortexItem.id.desc())
        .offset(cap).limit(1).scalar()
    )
    if cutoff:
        VortexItem.query.filter(VortexItem.id <= cutoff).delete(synchronize_session=False)
        db.session.commit()


# ---------------------------------------------------------------------------
# o motor contínuo
# ---------------------------------------------------------------------------

_STOP = object()


class IngestEngine:
    """Indexação contínua: despachante -> workers (rede) -> gravador (banco).
    Veja a docstring do módulo."""

    def __init__(self, app, db):
        self.app, self.db, self.cfg = app, db, app.config
        self.q = queue.Queue(maxsize=2000)          # contrapressão sobre os workers
        self.wake = threading.Event()
        self._stop = threading.Event()
        self._cond = threading.Condition()
        self._inflight = set()                      # ids de fontes em andamento
        self._pending = 0
        self._known = set()                         # url_hash já vistos (memória)
        self._inflight_hashes = set()
        self._phashes = PhashSet()
        self._limiter = HostLimiter(self.cfg.get("VORTEX_HOST_INTERVALS"))
        self._tl = threading.local()
        self._src_pool = self._dl_pool = None
        self._writer = self._dispatcher = None
        self._inserted = {}                         # só o gravador mexe
        self._recent = []                           # (monotonic, n) dos últimos lotes
        self._vis_pool = self._vision = None
        self._q_pool = self._quality = None
        self.quality_done = self.quality_barred = self.quality_dups = 0
        self._quality_pending = None
        self._concepts = None
        self.concepts_done = self.concepts_with = self.concepts_reclassified = 0
        self._concepts_pending = None
        self._discovery = None
        self._clip = None
        self._ctl_seq = None                        # purge_seq já aplicado (None = ainda não lido)
        self._heartbeat = None
        self.vision_done = self.vision_failed = 0
        self._vision_pending = None
        self.started_at = None
        self.total_saved = 0
        self.last_flush_at = None
        self._running = False

    # -- ciclo de vida -----------------------------------------------------
    def _load_known(self):
        """(Re)carrega URLs e dHashes conhecidos: itens indexados + lápides
        (URLs que o admin apagou e não devem voltar)."""
        with self.app.app_context():
            rows = self.db.session.query(VortexItem.url_hash, VortexItem.phash).all()
            tomb = [h for (h,) in self.db.session.query(VortexTombstone.url_hash).all()]
        known, values = set(tomb), []
        for url_hash, ph in rows:
            known.add(url_hash)
            if ph:
                try:
                    values.append(int(ph, 16))
                except ValueError:
                    pass
        with self._cond:
            self._known = known
        self._phashes = PhashSet(values)

    def _boot(self):
        self._load_known()
        # os pools aceitam até MAX_SPEED x o configurado; quem limita a
        # concorrência real é o controle de velocidade (_effective_workers)
        self._src_pool = ThreadPoolExecutor(
            max_workers=max(1, int(self.cfg["VORTEX_WORKERS"] * vortex_control.MAX_SPEED)),
            thread_name_prefix="vortex-src")
        self._dl_pool = ThreadPoolExecutor(
            max_workers=max(1, self.cfg["VORTEX_DOWNLOAD_WORKERS"]), thread_name_prefix="vortex-dl")
        self._writer = threading.Thread(target=self._writer_loop, name="vortex-writer", daemon=True)
        self._writer.start()
        self.started_at = time.time()
        self._running = True

    def _start_vision(self):
        if not self.cfg.get("VORTEX_VISION_ENABLED", True) or vortex_vision.Image is None:
            return
        self._vis_pool = ThreadPoolExecutor(
            max_workers=max(1, self.cfg["VORTEX_VISION_WORKERS"]), thread_name_prefix="vortex-vis")
        self._vision = threading.Thread(target=self._vision_loop, name="vortex-vision", daemon=True)
        self._vision.start()

    def _start_quality(self):
        if (not self.cfg.get("VORTEX_QUALITY_ENABLED", True) or vortex_quality.Image is None
                or vortex_quality.np is None):
            return
        self._q_pool = ThreadPoolExecutor(
            max_workers=max(1, self.cfg.get("VORTEX_QUALITY_WORKERS", 4)),
            thread_name_prefix="vortex-qual")
        self._quality = threading.Thread(target=self._quality_loop, name="vortex-quality", daemon=True)
        self._quality.start()

    def _start_concepts(self):
        if not self.cfg.get("VORTEX_CONCEPTS_ENABLED", True):
            return
        self._concepts = threading.Thread(target=self._concepts_loop, name="vortex-concepts", daemon=True)
        self._concepts.start()

    def _start_discovery(self, initial_delay):
        if not self.cfg.get("VORTEX_DISCOVERY_ENABLED", True):
            return
        from vortex_discovery import DiscoveryCrawler
        self._discovery = DiscoveryCrawler(self)
        self._discovery.start(initial_delay)

    def start(self, initial_delay=0):
        """Liga o motor (não bloqueia)."""
        self._boot()
        self._start_vision()
        self._start_quality()
        self._start_concepts()
        self._start_discovery(initial_delay)
        self._dispatcher = threading.Thread(
            target=self._dispatch_loop, args=(initial_delay,), name="vortex-dispatch", daemon=True)
        self._dispatcher.start()
        self._heartbeat = threading.Thread(target=self._heartbeat_loop, name="vortex-heartbeat", daemon=True)
        self._heartbeat.start()
        log.info("[vortex] motor de indexação ligado (%d fontes em paralelo, %d downloads, %d itens conhecidos)",
                 self.cfg["VORTEX_WORKERS"], self.cfg["VORTEX_DOWNLOAD_WORKERS"], len(self._known))
        return self

    def running(self):
        return self._running and not self._stop.is_set()

    def stop(self, timeout=60):
        """Para o despachante, espera as fontes em andamento e grava o que
        sobrou na fila."""
        self._stop.set()
        self.wake.set()
        if self._dispatcher:
            self._dispatcher.join(5)
        if self._vision:
            self._vision.join(10)
        if self._quality:
            self._quality.join(10)
        if self._concepts:
            self._concepts.join(10)
        if self._discovery:
            self._discovery.stop()
        deadline = time.monotonic() + timeout
        with self._cond:
            while self._pending > 0 and time.monotonic() < deadline:
                self._cond.wait(0.5)
        self.q.put(_STOP)
        if self._writer:
            self._writer.join(max(1, deadline - time.monotonic()))
        for pool in (self._src_pool, self._dl_pool, self._vis_pool):
            if pool:
                pool.shutdown(wait=False, cancel_futures=True)
        self._running = False

    def run_once(self, only_source_id=None):
        """Uma rodada de cada fonte ativa (ignora next_run_at), em paralelo.
        Bloqueia até acabar e devolve quantos itens novos entraram."""
        self._boot()
        with self.app.app_context():
            query = VortexCrawlSource.query
            query = (query.filter_by(id=only_source_id) if only_source_id
                     else query.filter_by(enabled=True))
            snaps = [make_snapshot(self.cfg, r) for r in query.order_by(VortexCrawlSource.id).all()]
        for snap in snaps:
            self._submit(snap)
        with self._cond:
            while self._pending > 0:
                self._cond.wait(0.5)
        self.stop()
        return self.total_saved

    def wake_now(self, only_source_id=None):
        """Torna as fontes elegíveis agora (botão "Rodar agora" do admin)."""
        with self.app.app_context():
            query = VortexCrawlSource.query
            query = (query.filter_by(id=only_source_id) if only_source_id
                     else query.filter_by(enabled=True))
            query.update({"next_run_at": utcnow()}, synchronize_session=False)
            self.db.session.commit()
        self.wake.set()

    def stats(self):
        now = time.monotonic()
        recent = [(t, n) for t, n in self._recent if now - t <= 60]
        ctl = self.control()
        with self._cond:
            inflight, pending = len(self._inflight), self._pending
            inflight_ids = sorted(self._inflight)
        return {
            "running": self.running(),
            "paused": ctl["paused"], "speed": ctl["speed"],
            "workers": self._effective_workers(ctl), "inflight_ids": inflight_ids,
            "uptime_seconds": int(time.time() - self.started_at) if self.started_at else 0,
            "sources_in_flight": inflight, "pending": pending,
            "queue_size": self.q.qsize(),
            "saved_since_start": self.total_saved,
            "saved_last_minute": sum(n for _t, n in recent),
            "last_flush_seconds_ago": (int(time.time() - self.last_flush_at)
                                       if self.last_flush_at else None),
            "known_urls": len(self._known), "known_phashes": len(self._phashes),
            "vision_running": bool(self._vision and self._vision.is_alive()),
            "vision_done": self.vision_done, "vision_failed": self.vision_failed,
            "vision_pending": self._vision_pending, "clip_enabled": self._clip is not None,
            "quality_running": bool(self._quality and self._quality.is_alive()),
            "quality_done": self.quality_done, "quality_barred": self.quality_barred,
            "quality_dups": self.quality_dups, "quality_pending": self._quality_pending,
            "concepts_running": bool(self._concepts and self._concepts.is_alive()),
            "concepts_done": self.concepts_done, "concepts_with": self.concepts_with,
            "concepts_reclassified": self.concepts_reclassified, "concepts_pending": self._concepts_pending,
            "discovery": self._discovery.stats() if self._discovery else None,
        }

    # -- controle do admin (pausa / velocidade; ver vortex_control.py) -----
    def control(self):
        """{paused, speed, purge_seq} (cache de ~2 s; vale entre processos)."""
        return vortex_control.read_control(self.app)

    def _effective_workers(self, ctl=None):
        speed = (ctl or self.control())["speed"]
        return max(1, min(round(self.cfg["VORTEX_WORKERS"] * speed),
                          int(self.cfg["VORTEX_WORKERS"] * vortex_control.MAX_SPEED)))

    def _apply_control(self):
        """Aplica o que o admin mudou: espaçamento por host e recarga das
        listas em memória depois de uma exclusão em massa."""
        ctl = self.control()
        slow = max(1.0, 1.0 / ctl["speed"])
        self._limiter.scale = slow
        if self._discovery is not None:
            self._discovery.limiter.scale = slow
        if self._ctl_seq is None:
            self._ctl_seq = ctl["purge_seq"]
        elif ctl["purge_seq"] != self._ctl_seq:
            self._ctl_seq = ctl["purge_seq"]
            self._load_known()
            log.info("[vortex] listas conhecidas recarregadas (exclusão feita pelo admin)")
        return ctl

    def _scale_next_run(self, row, res):
        """Ajusta a volta da fonte à velocidade escolhida: pausas encurtam
        (rápido) ou esticam (lento). Espera de erro/429/fonte indisponível
        nunca é encurtada: é o site mandando esperar."""
        speed = self.control()["speed"]
        if speed == 1.0 or row.next_run_at is None:
            return
        if speed > 1.0 and (res.error or res.unavailable or res.retry_after):
            return
        now = utcnow()
        wait = (row.next_run_at - now).total_seconds()
        if wait > 0:
            row.next_run_at = now + timedelta(seconds=wait / speed)

    def _heartbeat_loop(self):
        """A cada 2 s grava um instantâneo (arquivo) pro admin ver em tempo
        real, mesmo caindo em outro processo; a cada 10 s soma um ponto na
        série de itens gravados (últimos 30 min)."""
        series, last_total, next_point = [], self.total_saved, 0.0
        while not self._stop.wait(2.0):
            try:
                now = time.time()
                if now >= next_point:
                    series.append([int(now), self.total_saved - last_total])
                    series, last_total, next_point = series[-180:], self.total_saved, now + 10
                snap = self.stats()
                snap.update(ts=now, pid=os.getpid(), series=series)
                vortex_control.write_stats_file(snap)
            except Exception:
                log.debug("[vortex] falha ao gravar o instantâneo do motor", exc_info=True)

    # -- despachante -------------------------------------------------------
    def _dispatch_loop(self, initial_delay):
        if initial_delay and self._stop.wait(initial_delay):
            return
        while not self._stop.is_set():
            try:
                ctl = self._apply_control()
                if not ctl["paused"]:
                    self._dispatch_once(ctl)
            except Exception:
                log.exception("[vortex] falha no despachante")
            self.wake.wait(1.0)
            self.wake.clear()

    def _dispatch_once(self, ctl=None):
        with self._cond:
            free = self._effective_workers(ctl) - len(self._inflight)
            busy = set(self._inflight)
        if free <= 0:
            return
        with self.app.app_context():
            query = VortexCrawlSource.query.filter(
                VortexCrawlSource.enabled.is_(True),
                self.db.or_(VortexCrawlSource.next_run_at.is_(None),
                            VortexCrawlSource.next_run_at <= utcnow()),
            )
            if busy:
                query = query.filter(~VortexCrawlSource.id.in_(busy))
            rows = (query.order_by(VortexCrawlSource.next_run_at.asc().nullsfirst(),
                                   VortexCrawlSource.id).limit(free).all())
            snaps = [make_snapshot(self.cfg, r) for r in rows]
        for snap in snaps:
            self._submit(snap)

    def _submit(self, snap):
        with self._cond:
            if snap.id in self._inflight:
                return
            self._inflight.add(snap.id)
            self._pending += 1
        self._src_pool.submit(self._run_source, snap)

    def _release(self, source_id):
        with self._cond:
            self._inflight.discard(source_id)
            self._pending -= 1
            self._cond.notify_all()
        self.wake.set()

    # -- workers (só rede; nunca tocam no banco) ---------------------------
    def _http(self):
        session = getattr(self._tl, "http", None)
        if session is None:
            session = self._tl.http = make_http(self.cfg, self._limiter)
        return session

    def _claim_url(self, url_hash):
        with self._cond:
            if url_hash in self._known or url_hash in self._inflight_hashes:
                return False
            self._inflight_hashes.add(url_hash)
            return True

    def _enrich_one(self, snap, c):
        url_hash = c["_hash"]
        try:
            return enrich(self.cfg, self._http(), snap, c, self._phashes.claim)
        except Exception as exc:
            log.debug("[vortex] candidato descartado (%s): %s", c.get("media_url"), exc)
            return None
        finally:
            with self._cond:
                self._inflight_hashes.discard(url_hash)
                self._known.add(url_hash)

    def _process_candidates(self, snap, candidates):
        """Filtra, deduplica, enriquece (downloads em paralelo) e põe na fila
        do gravador. Usado pelas fontes e pela descoberta. Devolve quantos
        itens foram enfileirados."""
        todo = []
        for c in prefilter(self.cfg, candidates):
            url_hash = _hash_url(c["media_url"])
            if self._claim_url(url_hash):
                c["_hash"] = url_hash
                todo.append(c)
        todo = todo[: self.cfg["VORTEX_MAX_ITEMS_PER_SOURCE_RUN"]]
        futures = [self._dl_pool.submit(self._enrich_one, snap, c) for c in todo]
        queued = 0
        for fut in as_completed(futures):
            rec = fut.result()
            if rec:   # cada item pronto vai pra fila na hora (salvamento constante)
                self.q.put(("item", rec))
                queued += 1
        return queued

    def _run_source(self, snap):
        res = _new_result(snap)
        try:
            http = self._http()
            candidates, has_more = _fetch(http, self.cfg, snap)
            res.n, res.has_more = len(candidates), has_more
            self._process_candidates(snap, candidates)
        except Exception as exc:
            _fail(res, exc)
            if not isinstance(exc, (SourceUnavailable, RateLimited)):
                log.warning("[vortex] fonte '%s': %s", snap.name, exc)
        finally:
            self.q.put(("done", res))

    # -- análise visual em segundo plano -----------------------------------
    def _vision_loop(self):
        """Preenche a assinatura de aparência dos itens que ainda não têm
        (todos os que já existiam) e, com CLIP ligado, o embedding e os
        conceitos. Roda sem parar enquanto houver pendências."""
        try:
            self._clip = vortex_vision.build_clip(self.cfg)
        except Exception:
            log.exception("[vortex] falha ao iniciar o CLIP")
        idle = self.cfg["VORTEX_VISION_IDLE_SECONDS"]
        while not self._stop.is_set():
            try:
                done = self._vision_cycle(self.cfg["VORTEX_VISION_BATCH"])
            except Exception:
                log.exception("[vortex] falha na análise visual")
                done = 0
            if not done:
                self._stop.wait(idle)

    def _vision_cycle(self, batch_size):
        clip = self._clip
        with self.app.app_context():
            pending = VortexItem.vfeat.is_(None)
            if clip is not None:
                pending = self.db.or_(pending, self.db.and_(
                    VortexItem.vfeat != "", VortexItem.clip_vec.is_(None)))
            rows = (
                self.db.session.query(
                    VortexItem.id, VortexItem.media_type, VortexItem.media_url, VortexItem.thumb_url,
                    VortexItem.category, VortexItem.tags, VortexItem.vfeat, VortexItem.visual_tags,
                    VortexItem.clip_vec, VortexItem.title, VortexItem.description)
                .filter(VortexItem.is_active.is_(True), pending)
                .order_by(VortexItem.id.desc()).limit(batch_size).all()
            )
            self._vision_pending = (
                self.db.session.query(self.db.func.count(VortexItem.id))
                .filter(VortexItem.is_active.is_(True), VortexItem.vfeat.is_(None)).scalar())
        if not rows:
            return 0
        results = list(self._vis_pool.map(lambda r: self._vision_fetch(r, clip is not None), rows))

        # CLIP em lote (uma thread só: o modelo não é thread-safe)
        with_img = [(r, res) for r, res in zip(rows, results) if res.get("_img") is not None]
        if clip is not None and with_img:
            try:
                vecs = clip.encode_images([res["_img"] for _r, res in with_img])
                for (r, res), vec in zip(with_img, vecs):
                    self._apply_clip(r, res, vec, clip)
            except Exception:
                log.exception("[vortex] falha no CLIP; lote segue só com a aparência")
                for _r, res in with_img:
                    res.setdefault("clip_vec", "")
        mappings = []
        for res in results:
            res.pop("_img", None)
            mappings.append(res)
            if res.get("vfeat") == "":
                self.vision_failed += 1
            else:
                self.vision_done += 1
        self._save_vision(mappings)
        return len(rows)

    def _vision_fetch(self, row, want_clip):
        """Baixa a miniatura e calcula a assinatura (thread de rede)."""
        out = {"id": row.id}
        try:
            url = row.thumb_url or (row.media_url if row.media_type == "photo" else None)
            data = (_download_head(self._http(), url, self.cfg["VORTEX_REQUEST_TIMEOUT"],
                                   max_bytes=self.cfg.get("VORTEX_THUMB_MAX_BYTES", 1_500_000))
                    if url else None)
            desc = vortex_vision.describe_image(data) if data else None
            if desc is None:
                # sem miniatura legível: marca pra não tentar de novo pra sempre
                # (sem apagar uma assinatura que o item já tenha)
                if row.vfeat is None:
                    out.update(vfeat="", vision_version=-1)
                if want_clip and row.clip_vec is None:
                    out["clip_vec"] = ""
                return out
            if row.vfeat is None:
                out.update(vfeat=desc["hex"], visual_tags=",".join(desc["tags"]) or None,
                           vision_version=vortex_vision.VISION_VERSION)
            if want_clip and row.clip_vec is None and row.vfeat != "":
                out["_img"] = Image_open_rgb(data)
        except Exception:
            if row.vfeat is None:
                out.update(vfeat="", vision_version=-1)
        return out

    def _apply_clip(self, row, res, vec, clip):
        """Guarda o embedding e transforma conceitos reconhecidos em tags
        (visual_tags sempre; tags/categoria só com confiança alta)."""
        res["clip_vec"] = vortex_vision.clip_pack(vec)
        found = clip.concepts_for(vec, top=3)
        min_p = self.cfg["VORTEX_CLIP_MIN_PROB"]
        strong_p = self.cfg["VORTEX_CLIP_TAG_MIN_PROB"]
        labels = [pt for pt, _cat, p in found if p >= min_p]
        base_visual = [t for t in (res.get("visual_tags") or row.visual_tags or "").split(",") if t]
        merged = labels + [t for t in base_visual if t not in labels]
        if merged:
            res["visual_tags"] = ",".join(merged)[:300]
        strong = [(pt, cat) for pt, cat, p in found if p >= strong_p]
        if strong:
            tags = [t for t in (row.tags or "").split(",") if t]
            for pt, _cat in strong:
                if pt not in tags and len(",".join(tags + [pt])) <= 500:
                    tags.append(pt)
            res["tags"] = ",".join(tags)
            if row.category == "outros" and strong[0][1] != "outros":
                res["category"] = strong[0][1]
        self._refresh_concepts(row, res)

    def _refresh_concepts(self, row, res):
        """A imagem acabou de ganhar rótulos do CLIP: recalcula os conceitos com eles (o título
        pode ser só "IMG_2031"). `res` é o que vai ser gravado; só soma campos a ele."""
        if not self.cfg.get("VORTEX_CONCEPTS_ENABLED", True):
            return
        try:
            category = res.get("category", row.category)
            fields, u = vortex_understand.build_fields(
                getattr(row, "title", ""), res.get("tags", row.tags), getattr(row, "description", ""),
                res.get("visual_tags", row.visual_tags), category)
            res.update(fields)
            better = vortex_understand.suggest_category(
                u, category, {slug for slug, _ in self.cfg["VORTEX_CATEGORIES"]},
                self.cfg.get("VORTEX_CONCEPTS_RECLASSIFY_MIN_CONFIDENCE",
                             vortex_understand.RECLASSIFY_MIN_CONFIDENCE))
            if better:
                res["category"] = better
        except Exception:
            log.exception("[vortex] falha ao recalcular conceitos depois do CLIP")

    def _save_vision(self, mappings):
        with self.app.app_context():
            session = self.db.session
            for attempt in range(5):
                try:
                    session.bulk_update_mappings(VortexItem, mappings)
                    session.commit()
                    break
                except OperationalError:
                    session.rollback()
                    time.sleep(0.5 * (attempt + 1))
                except Exception:
                    session.rollback()
                    log.exception("[vortex] falha ao salvar a análise visual")
                    break
        try:
            from vortex_search import clear_stats_cache
            clear_stats_cache(self.app)
        except Exception:
            pass

    # -- controle de qualidade em segundo plano -----------------------------
    def _quality_loop(self):
        """Passa o filtro de lixo (QR code, logo, chapada, repetida) nos itens
        que já estavam gravados antes dele existir e, de tempos em tempos,
        agrupa quase-duplicatas. Itens novos já entram analisados (enrich)."""
        idle = self.cfg.get("VORTEX_QUALITY_IDLE_SECONDS", 45)
        last_dedupe = 0.0
        swept = False
        while not self._stop.is_set():
            done = 0
            try:
                if not swept:
                    swept = True
                    with self.app.app_context():
                        n = vortex_quality.text_sweep(self.app, self.db)
                    self.quality_barred += n
                done = self._quality_cycle(self.cfg.get("VORTEX_QUALITY_BATCH", 40))
                if not done and time.monotonic() - last_dedupe > 1800:
                    last_dedupe = time.monotonic()
                    with self.app.app_context():
                        out = vortex_quality.dedupe_existing(self.app, self.db)
                    self.quality_dups += out["duplicate"] + out["repeated"]
                    if out["duplicate"] or out["repeated"]:
                        self._after_quality_change()
            except Exception:
                log.exception("[vortex] falha no controle de qualidade")
                self.db.session.rollback()
                done = 0
            if not done:
                self._stop.wait(idle)

    def _quality_cycle(self, batch_size):
        with self.app.app_context():
            rows = (
                self.db.session.query(VortexItem.id, VortexItem.media_type, VortexItem.thumb_url,
                                      VortexItem.media_url)
                .filter(VortexItem.is_active.is_(True),
                        self.db.or_(VortexItem.quality_version.is_(None),
                                    VortexItem.quality_version < vortex_quality.QUALITY_VERSION))
                .order_by(VortexItem.id.desc()).limit(batch_size).all()
            )
            self._quality_pending = vortex_quality.pending_count(self.db)
        if not rows:
            return 0
        timeout = self.cfg["VORTEX_REQUEST_TIMEOUT"]
        max_bytes = self.cfg.get("VORTEX_THUMB_MAX_BYTES", 1_500_000)

        def one(row):
            return vortex_quality.scan_rows(
                [row], lambda u: _download_head(self._http(), u, timeout, max_bytes=max_bytes))

        results = {}
        for part in self._q_pool.map(one, rows):
            results.update(part)
        if not results:      # nada baixou (rede/host fora): não gira em falso
            return 0
        barred = 0
        with self.app.app_context():
            for attempt in range(5):
                try:
                    barred = vortex_quality.apply_scan(self.db, results)
                    break
                except OperationalError:
                    self.db.session.rollback()
                    time.sleep(0.5 * (attempt + 1))
                except Exception:
                    self.db.session.rollback()
                    log.exception("[vortex] falha ao salvar o controle de qualidade")
                    break
        self.quality_done += len(results)
        self.quality_barred += barred
        if barred:
            self._after_quality_change()
        return len(results)

    # -- compreensão de conteúdo em segundo plano ----------------------------
    def _concepts_loop(self):
        """Entende (título/tags/CLIP -> conceitos) os itens que já estavam gravados antes da
        Parte 3B e os que ficaram com versão antiga do vocabulário. Só texto: sem rede, em lotes
        grandes, e não é afetado por pausa/velocidade (é CPU local, não busca nada na internet)."""
        idle = self.cfg.get("VORTEX_CONCEPTS_IDLE_SECONDS", 60)
        batch = self.cfg.get("VORTEX_CONCEPTS_BATCH", 500)
        valid = {slug for slug, _ in self.cfg["VORTEX_CATEGORIES"]}
        min_conf = self.cfg.get("VORTEX_CONCEPTS_RECLASSIFY_MIN_CONFIDENCE",
                                vortex_understand.RECLASSIFY_MIN_CONFIDENCE)
        state, last_count = {}, 0.0
        while not self._stop.is_set():
            done = 0
            try:
                out = vortex_understand.process_batch(
                    self.app, self.db, batch, valid, min_conf, state,
                    clip_enabled=self._clip is not None)
                done = out["done"]
                self.concepts_done += done
                self.concepts_with += out["with_concept"]
                self.concepts_reclassified += out["reclassified"]
                if out["reclassified"]:
                    self._after_quality_change()
                if not done or time.monotonic() - last_count > 30:
                    last_count = time.monotonic()
                    with self.app.app_context():
                        self._concepts_pending = vortex_understand.pending_count(
                            self.db, with_old=not state.get("old_done"))
            except Exception:
                log.exception("[vortex] falha ao entender o conteúdo do acervo")
                try:
                    self.db.session.rollback()
                except Exception:
                    pass
                done = 0
            self._stop.wait(0.2 if done else idle)

    def _after_quality_change(self):
        try:
            from vortex_search import clear_stats_cache
            clear_stats_cache(self.app)
        except Exception:
            pass

    # -- gravador (única thread que escreve) -------------------------------
    def _writer_loop(self):
        batch, started = [], 0.0
        size, every = self.cfg["VORTEX_BATCH_SIZE"], self.cfg["VORTEX_FLUSH_SECONDS"]
        prune_every = self.cfg.get("VORTEX_PRUNE_EVERY_SECONDS", 1800)
        last_prune = time.monotonic()
        while True:
            wait = every if not batch else max(0.05, every - (time.monotonic() - started))
            try:
                msg = self.q.get(timeout=wait)
            except queue.Empty:
                msg = None
            if msg is _STOP:
                self._flush(batch)
                return
            if msg is not None:
                if msg[0] == "item":
                    if not batch:
                        started = time.monotonic()
                    batch.append(msg[1])
                else:  # "done": grava o que falta ANTES de contar os itens da fonte
                    self._flush(batch)
                    batch = []
                    self._apply_done(msg[1])
            if batch and (len(batch) >= size or time.monotonic() - started >= every):
                self._flush(batch)
                batch = []
            if time.monotonic() - last_prune >= prune_every:
                last_prune = time.monotonic()
                try:
                    with self.app.app_context():
                        prune_old_items(self.app, self.db)
                except Exception:
                    self.db.session.rollback()
                    log.exception("[vortex] falha ao podar")

    def _flush(self, batch):
        if not batch:
            return
        saved = self._insert_batch(batch)
        for rec in batch:
            if rec["url_hash"] not in saved:
                with self._cond:
                    self._known.discard(rec["url_hash"])   # pode tentar de novo depois
            else:
                self._inserted[rec["source_id"]] = self._inserted.get(rec["source_id"], 0) + 1
        if saved:
            now = time.monotonic()
            self.total_saved += len(saved)
            self.last_flush_at = time.time()
            self._recent = [(t, n) for t, n in self._recent if now - t <= 120] + [(now, len(saved))]
            try:
                from vortex_search import clear_stats_cache
                clear_stats_cache(self.app)
            except Exception:
                pass

    def _insert_batch(self, batch):
        """Grava o lote num commit só; se algo colidir (url_hash único), cai
        pro item-a-item. Devolve o conjunto de url_hash gravados."""
        with self.app.app_context():
            session = self.db.session
            for attempt in range(5):
                try:
                    session.add_all([VortexItem(**r) for r in batch])
                    session.commit()
                    return {r["url_hash"] for r in batch}
                except IntegrityError:
                    session.rollback()
                    saved = set()
                    for rec in batch:
                        try:
                            with session.begin_nested():
                                session.add(VortexItem(**rec))
                            saved.add(rec["url_hash"])
                        except IntegrityError:
                            pass   # o savepoint já foi desfeito; esse item já existe
                    session.commit()
                    return saved
                except OperationalError:   # banco ocupado: espera e tenta de novo
                    session.rollback()
                    time.sleep(0.5 * (attempt + 1))
                except Exception:
                    session.rollback()
                    log.exception("[vortex] falha ao gravar lote de %d itens", len(batch))
                    return set()
            log.error("[vortex] banco ocupado: lote de %d itens descartado (será reindexado)", len(batch))
            return set()

    def _apply_done(self, res):
        res.added = self._inserted.pop(res.source_id, 0)
        try:
            with self.app.app_context():
                session = self.db.session
                for attempt in range(4):
                    try:
                        row = session.get(VortexCrawlSource, res.source_id)
                        if row is not None:
                            apply_source_result(self.cfg, row, res)
                            self._scale_next_run(row, res)
                            session.commit()
                        break
                    except OperationalError:
                        session.rollback()
                        time.sleep(0.5 * (attempt + 1))
        except Exception:
            log.exception("[vortex] falha ao atualizar a fonte #%s", res.source_id)
        finally:
            self._release(res.source_id)


# ---------------------------------------------------------------------------
# ponto de entrada: singleton por processo (e por máquina, via arquivo de trava)
# ---------------------------------------------------------------------------

_ENGINE = None
_ENGINE_GUARD = threading.Lock()
_RUN_LOCK = threading.Lock()
_LOCK_HANDLE = None


def _acquire_process_lock():
    """Só um processo por máquina roda o motor contínuo (ex.: vários workers
    do gunicorn). Devolve False se outro já tem a trava."""
    global _LOCK_HANDLE
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "instance", "vortex_ingest.lock")
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        handle = open(path, "a+")
        try:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except ImportError:  # Windows
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        _LOCK_HANDLE = handle
        return True
    except OSError:
        return False


def get_engine():
    return _ENGINE


def start_engine(app, db, initial_delay=0):
    """Liga o motor contínuo uma única vez. Chamado pelo app.py."""
    global _ENGINE
    with _ENGINE_GUARD:
        if _ENGINE is not None and _ENGINE.running():
            return _ENGINE
        if not _acquire_process_lock():
            app.logger.info("[vortex] outro processo já roda o motor de indexação; este não inicia.")
            return None
        _ENGINE = IngestEngine(app, db).start(initial_delay)
        import atexit
        atexit.register(lambda: _ENGINE and _ENGINE.running() and _ENGINE.stop(timeout=15))
        return _ENGINE


def crawl_all_sources(app, db, only_source_id=None, pause=1.0):
    """Rodada manual (admin / linha de comando). Com o motor contínuo ligado,
    só acorda as fontes (devolve 0: o resultado aparece conforme grava). Sem
    ele, roda uma rodada completa em paralelo e devolve os itens novos."""
    engine = _ENGINE
    if vortex_control.read_control(app, ttl=0)["paused"]:
        return 0      # pausado pelo admin (também vale pra rodadas manuais)
    if engine is not None and engine.running():
        engine.wake_now(only_source_id)
        return 0
    if not _RUN_LOCK.acquire(blocking=False):
        return 0  # já tem uma rodada em andamento
    try:
        return IngestEngine(app, db).run_once(only_source_id)
    finally:
        _RUN_LOCK.release()


def run_in_background(app, db, only_source_id=None):
    """Dispara uma rodada numa thread (usado pelo botão 'Rodar agora')."""
    thread = threading.Thread(
        target=lambda: crawl_all_sources(app, db, only_source_id=only_source_id),
        daemon=True,
    )
    thread.start()
    return thread


def seed_vortex_defaults(app, db):
    """Cria perfis e fontes padrão (config). Idempotente."""
    cfg = app.config
    profiles = {}
    for handle, name, bio, site in cfg.get("VORTEX_DEFAULT_PROFILES", []):
        p = VortexProfile.query.filter_by(handle=handle).first()
        if p is None:
            p = VortexProfile(handle=handle, display_name=name, bio=bio, source_site=site)
            db.session.add(p)
        profiles[handle] = p
    db.session.flush()
    for name, kind, handle, category, query, extra in cfg.get("VORTEX_DEFAULT_SOURCES", []):
        media = extra.get("media", "photo")
        exists = VortexCrawlSource.query.filter_by(kind=kind, term=query, media=media).first()
        if exists:
            continue
        db.session.add(VortexCrawlSource(
            name=name, kind=kind, profile_id=profiles[handle].id,
            category=category, term=query, media=media, enabled=True,
        ))
    db.session.commit()


if __name__ == "__main__":  # python vortex_crawler.py --once | --daemon
    import sys
    os.environ["VORTEX_CRAWLER_ENABLED"] = "0"   # o create_app não sobe um 2º motor
    from app import create_app
    from extensions import db as _db

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    _app = create_app()
    with _app.app_context():
        seed_vortex_defaults(_app, _db)
    if "--daemon" in sys.argv:
        engine = IngestEngine(_app, _db).start(0)
        try:
            while True:
                time.sleep(10)
                print(engine.stats(), flush=True)
        except KeyboardInterrupt:
            engine.stop()
            sys.exit(0)
    n = crawl_all_sources(_app, _db)
    print(f"{n} item(ns) novo(s).")
    sys.exit(0)
