"""
Mensagens — parte 3: grupos (backend). Só texto por enquanto; mídia em grupo fica para depois.

Rotas (aceitam token Bearer do app OU a sessão do site com X-Requested-With: fetch), todas em /api/v1:
    POST   /groups                              cria  {name, description?, members: [@usernames]}
    GET    /groups[?arquivadas=1]               meus grupos (fixados primeiro, depois a atividade mais recente)
    GET    /groups/<id>                         detalhes + membros
    PUT    /groups/<id>                         {name?, description?}                (admin)
    DELETE /groups/<id>                         apaga o grupo                        (dono)
    POST   /groups/<id>/avatar | DELETE         foto do grupo (multipart `file`)     (admin)
    POST   /groups/<id>/members                 {usernames: [...]}                   (admin)
    DELETE /groups/<id>/members/<username>      remove (dono remove qualquer um; admin só membro)
    PUT    /groups/<id>/members/<username>      {role: admin|member}                 (dono)
    POST   /groups/<id>/leave                   sair (se era o dono, passa para o admin/membro mais antigo)
    GET    /groups/<id>/messages                ?before=<id>&limit=50  |  ?after=<id>
    POST   /groups/<id>/messages                {content, reply_to_id?, client_id?}  (idempotente por client_id)
    PUT    /groups/<id>/messages/<mid>          edita o texto (autor, dentro da janela)
    DELETE /groups/<id>/messages/<mid>          apaga para todos (autor na janela, ou admin)
    POST   /groups/<id>/read                    {up_to_id?} marca como lido
    PUT    /groups/<id>/prefs                   {pinned?, muted?, archived?}
    POST   /groups/<id>/typing                  {state: typing|stop}

Tempo real: evento SSE `group` (no mesmo /messages/stream) com `group_id` e `kind`:
message | update | members | info | prefs | read | removed | typing. Sem corpo: o cliente rebusca pela API.
Quem entra depois NÃO vê o histórico anterior (`ChatGroupMember.start_after_id`).
"""
from datetime import timedelta

from flask import current_app, jsonify, request

from api import api_bp, chat_login_required, current_api_user, _upload_url
from chat_events import hub
from extensions import db
from models import ChatGroup, ChatGroupMember, ChatGroupMessage, User, utcnow
from uploads import delete_upload, save_upload

ROLES = ("owner", "admin", "member")


# ---------------------------------------------------------------------------
# Auxiliares
# ---------------------------------------------------------------------------

def _err(msg, code=400):
    return jsonify({"error": msg}), code


def _iso(dt):
    return dt.isoformat() + "Z" if dt else None


def _is_admin(member):
    return member.role in ("owner", "admin")


def _get(group_id, user):
    """(grupo, meu vínculo) ou (None, None) se o grupo não existe OU eu não faço parte (404 igual nos dois)."""
    member = ChatGroupMember.query.filter_by(group_id=group_id, user_id=user.id).first()
    if member is None:
        return None, None
    return db.session.get(ChatGroup, group_id), member


def _not_found():
    return _err("Grupo não encontrado.", 404)


def _user_min(u):
    return {
        "id": u.id, "username": u.username, "display_name": u.display_label,
        "avatar_url": _upload_url(u.avatar_filename),
    }


def _latest_id(group_id):
    row = db.session.query(db.func.max(ChatGroupMessage.id)).filter(ChatGroupMessage.group_id == group_id).scalar()
    return row or 0


def _visible(group_id, member):
    return ChatGroupMessage.query.filter(ChatGroupMessage.group_id == group_id, ChatGroupMessage.id > member.start_after_id)


def unread_count(member):
    floor = max(member.last_read_id or 0, member.start_after_id or 0)
    return ChatGroupMessage.query.filter(
        ChatGroupMessage.group_id == member.group_id, ChatGroupMessage.id > floor,
        ChatGroupMessage.sender_id != member.user_id, ChatGroupMessage.kind == "text",
        ChatGroupMessage.deleted_at.is_(None),
    ).count()


def message_preview(m, with_sender=True):
    if m.deleted_at:
        return "Mensagem apagada"
    if m.kind == "system":
        return m.content
    text = (m.content or "")[:80]
    return f"{m.sender.display_label}: {text}" if with_sender and m.sender else text


def serialize_message(m, viewer):
    deleted = m.deleted_at is not None
    reply = None
    if m.reply_to_id:
        ref = db.session.get(ChatGroupMessage, m.reply_to_id)
        if ref is not None:
            reply = {
                "id": ref.id, "sender_id": ref.sender_id,
                "sender_name": ref.sender.display_label if ref.sender else "",
                "preview": message_preview(ref, with_sender=False),
                "deleted": ref.deleted_at is not None,
            }
    return {
        "id": m.id, "group_id": m.group_id, "kind": m.kind,
        "sender": _user_min(m.sender) if m.sender else None,
        "content": "" if deleted else m.content,
        "reply_to": reply, "client_id": m.client_id,
        "created_at": _iso(m.created_at), "edited_at": _iso(m.edited_at),
        "edited": m.edited_at is not None, "deleted": deleted,
        "mine": m.sender_id == viewer.id,
    }


def serialize_group(group, member, with_members=False):
    last = _visible(group.id, member).order_by(ChatGroupMessage.id.desc()).first()
    data = {
        "id": group.id, "name": group.name, "description": group.description or "",
        "avatar_url": _upload_url(group.avatar_filename),
        "member_count": group.members.count(), "created_at": _iso(group.created_at),
        "my_role": member.role,
        "prefs": {"pinned": member.pinned_at is not None, "muted": bool(member.muted), "archived": bool(member.archived)},
        "unread": unread_count(member),
        "last_message": serialize_message(last, member.user) if last else None,
        "last_preview": message_preview(last) if last else "",
        "last_activity": _iso(last.created_at if last else group.created_at),
    }
    if with_members:
        rows = group.members.order_by(ChatGroupMember.joined_at.asc(), ChatGroupMember.id.asc()).all()
        data["members"] = [
            {**_user_min(r.user), "role": r.role, "joined_at": _iso(r.joined_at)} for r in rows
        ]
    return data


def notify_group(group_id, kind, only=None, exclude=None, **extra):
    """Avisa os membros (SSE `group`). `only`: lista de user_ids; `exclude`: user_id a pular."""
    ids = only if only is not None else [r.user_id for r in ChatGroupMember.query.filter_by(group_id=group_id)]
    for uid in ids:
        if uid != exclude:
            hub.publish(uid, "group", {"group_id": group_id, "kind": kind, **extra})


def _system(group, actor, text):
    m = ChatGroupMessage(group_id=group.id, sender_id=actor.id, kind="system", content=text[:2000])
    db.session.add(m)
    db.session.flush()
    return m


def _push_group_message(group, msg, sender):
    from push import send_push_to_user
    text = (msg.content or "")[:140]
    for r in ChatGroupMember.query.filter(ChatGroupMember.group_id == group.id, ChatGroupMember.user_id != sender.id):
        if r.muted:
            continue
        try:
            n = unread_count(r)
            send_push_to_user(
                r.user_id, title=group.name if n < 2 else f"{group.name} ({n} mensagens)",
                body=f"{sender.display_label}: {text}",
                data={"type": "group_message", "group_id": group.id, "unread_count": n}, count=n,
            )
        except Exception:  # push nunca derruba o envio
            current_app.logger.exception("push de grupo falhou")


def _find_users(usernames):
    """(usuários, erro): ignora repetidos; recusa nome inexistente ou banido."""
    found, seen = [], set()
    for raw in usernames or []:
        name = str(raw or "").strip().lstrip("@")
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        u = User.query.filter(db.func.lower(User.username) == name.lower()).first()
        if u is None or u.is_banned:
            return None, f"Usuário @{name} não encontrado."
        found.append(u)
    return found, None


def _max_members():
    return int(current_app.config.get("GROUP_MAX_MEMBERS", 200))


# ---------------------------------------------------------------------------
# Grupo: criar, listar, detalhes, editar, apagar, foto
# ---------------------------------------------------------------------------

@api_bp.route("/groups", methods=["POST"])
@chat_login_required
def group_create():
    user = current_api_user()
    data = request.get_json(silent=True) or {}
    name = str(data.get("name") or "").strip()
    if not name:
        return _err("Dê um nome ao grupo.")
    if len(name) > 60:
        return _err("O nome do grupo pode ter até 60 caracteres.")
    description = str(data.get("description") or "").strip()
    if len(description) > 200:
        return _err("A descrição pode ter até 200 caracteres.")
    users, error = _find_users(data.get("members"))
    if error:
        return _err(error, 404)
    users = [u for u in users if u.id != user.id]
    if not users:
        return _err("Escolha pelo menos uma pessoa para o grupo.")
    if len(users) + 1 > _max_members():
        return _err(f"O grupo pode ter até {_max_members()} pessoas.")

    group = ChatGroup(name=name, description=description, created_by_id=user.id)
    db.session.add(group)
    db.session.flush()
    db.session.add(ChatGroupMember(group_id=group.id, user_id=user.id, role="owner"))
    for u in users:
        db.session.add(ChatGroupMember(group_id=group.id, user_id=u.id, role="member"))
    _system(group, user, f"{user.display_label} criou o grupo “{name}”")
    db.session.commit()
    notify_group(group.id, "members")
    member = ChatGroupMember.query.filter_by(group_id=group.id, user_id=user.id).first()
    return jsonify({"group": serialize_group(group, member, with_members=True)}), 201


@api_bp.route("/groups", methods=["GET"])
@chat_login_required
def group_list():
    user = current_api_user()
    archived = request.args.get("arquivadas") in ("1", "true")
    rows = ChatGroupMember.query.filter_by(user_id=user.id, archived=archived).all()
    out = [serialize_group(r.group, r) for r in rows]
    out.sort(key=lambda g: g["last_activity"] or "", reverse=True)
    # fixados primeiro (o mais recentemente fixado no topo, igual às conversas)
    pins = {r.group_id: r.pinned_at for r in rows if r.pinned_at}
    out.sort(key=lambda g: pins.get(g["id"]).timestamp() if g["id"] in pins else 0, reverse=True)
    archived_count = ChatGroupMember.query.filter_by(user_id=user.id, archived=True).count()
    return jsonify({"groups": out, "archived_count": archived_count})


@api_bp.route("/groups/<int:group_id>", methods=["GET"])
@chat_login_required
def group_detail(group_id):
    group, me = _get(group_id, current_api_user())
    if group is None:
        return _not_found()
    return jsonify({"group": serialize_group(group, me, with_members=True)})


@api_bp.route("/groups/<int:group_id>", methods=["PUT"])
@chat_login_required
def group_update(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    if not _is_admin(me):
        return _err("Só administradores podem mudar o grupo.", 403)
    data = request.get_json(silent=True) or {}
    changed = False
    if "name" in data:
        name = str(data.get("name") or "").strip()
        if not name:
            return _err("Dê um nome ao grupo.")
        if len(name) > 60:
            return _err("O nome do grupo pode ter até 60 caracteres.")
        if name != group.name:
            group.name = name
            _system(group, user, f"{user.display_label} mudou o nome do grupo para “{name}”")
            changed = True
    if "description" in data:
        description = str(data.get("description") or "").strip()
        if len(description) > 200:
            return _err("A descrição pode ter até 200 caracteres.")
        if description != (group.description or ""):
            group.description = description
            changed = True
    db.session.commit()
    if changed:
        notify_group(group.id, "info")
    return jsonify({"group": serialize_group(group, me, with_members=True)})


@api_bp.route("/groups/<int:group_id>", methods=["DELETE"])
@chat_login_required
def group_delete(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    if me.role != "owner":
        return _err("Só o dono pode apagar o grupo.", 403)
    ids = [r.user_id for r in ChatGroupMember.query.filter_by(group_id=group.id)]
    avatar = group.avatar_filename
    ChatGroupMessage.query.filter_by(group_id=group.id).update({"reply_to_id": None})
    db.session.flush()
    db.session.delete(group)
    db.session.commit()
    delete_upload(avatar)
    notify_group(group_id, "removed", only=ids)
    return jsonify({"deleted": True})


@api_bp.route("/groups/<int:group_id>/avatar", methods=["POST", "DELETE"])
@chat_login_required
def group_avatar(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    if not _is_admin(me):
        return _err("Só administradores podem mudar a foto.", 403)
    old = group.avatar_filename
    if request.method == "DELETE":
        if not old:
            return jsonify({"group": serialize_group(group, me)})
        group.avatar_filename = None
        text = f"{user.display_label} removeu a foto do grupo"
    else:
        upload = request.files.get("file")
        if not (upload and upload.filename):
            return _err("Envie a imagem no campo `file`.")
        ext = upload.filename.rsplit(".", 1)[-1].lower() if "." in upload.filename else ""
        if ext not in current_app.config["ALLOWED_IMAGE_EXT"]:
            return _err("Formato de imagem não permitido.")
        group.avatar_filename = save_upload(upload, "avatar", ext, "group")
        text = f"{user.display_label} mudou a foto do grupo"
    _system(group, user, text)
    db.session.commit()
    delete_upload(old)
    notify_group(group.id, "info")
    return jsonify({"group": serialize_group(group, me)})


# ---------------------------------------------------------------------------
# Membros
# ---------------------------------------------------------------------------

@api_bp.route("/groups/<int:group_id>/members", methods=["POST"])
@chat_login_required
def group_add_members(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    if not _is_admin(me):
        return _err("Só administradores podem adicionar pessoas.", 403)
    users, error = _find_users((request.get_json(silent=True) or {}).get("usernames"))
    if error:
        return _err(error, 404)
    present = {r.user_id for r in ChatGroupMember.query.filter_by(group_id=group.id)}
    new = [u for u in users if u.id not in present]
    if not new:
        return _err("Essas pessoas já estão no grupo." if users else "Escolha pelo menos uma pessoa.")
    if len(present) + len(new) > _max_members():
        return _err(f"O grupo pode ter até {_max_members()} pessoas.")
    latest = _latest_id(group.id)
    for u in new:
        db.session.add(ChatGroupMember(group_id=group.id, user_id=u.id, role="member", start_after_id=latest, last_read_id=latest))
    sysmsg = _system(group, user, f"{user.display_label} adicionou " + ", ".join(u.display_label for u in new))
    # quem acabou de entrar vê a mensagem de entrada (mas não o histórico antes dela)
    for r in ChatGroupMember.query.filter(ChatGroupMember.group_id == group.id, ChatGroupMember.user_id.in_([u.id for u in new])):
        r.start_after_id = sysmsg.id - 1
        r.last_read_id = sysmsg.id
    db.session.commit()
    notify_group(group.id, "members")
    return jsonify({"group": serialize_group(group, me, with_members=True)})


@api_bp.route("/groups/<int:group_id>/members/<username>", methods=["DELETE"])
@chat_login_required
def group_remove_member(group_id, username):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    target = User.query.filter(db.func.lower(User.username) == username.lower()).first()
    row = ChatGroupMember.query.filter_by(group_id=group.id, user_id=target.id).first() if target else None
    if row is None:
        return _err("Essa pessoa não está no grupo.", 404)
    if target.id == user.id:
        return _err("Para sair do grupo use /leave.")
    if not _is_admin(me):
        return _err("Só administradores podem remover pessoas.", 403)
    if row.role == "owner" or (row.role == "admin" and me.role != "owner"):
        return _err("Você não pode remover essa pessoa.", 403)
    db.session.delete(row)
    _system(group, user, f"{user.display_label} removeu {target.display_label}")
    db.session.commit()
    notify_group(group.id, "removed", only=[target.id])
    notify_group(group.id, "members")
    return jsonify({"group": serialize_group(group, me, with_members=True)})


@api_bp.route("/groups/<int:group_id>/members/<username>", methods=["PUT"])
@chat_login_required
def group_set_role(group_id, username):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    if me.role != "owner":
        return _err("Só o dono pode mudar administradores.", 403)
    role = (request.get_json(silent=True) or {}).get("role")
    if role not in ("admin", "member"):
        return _err("Informe role: admin ou member.")
    target = User.query.filter(db.func.lower(User.username) == username.lower()).first()
    row = ChatGroupMember.query.filter_by(group_id=group.id, user_id=target.id).first() if target else None
    if row is None:
        return _err("Essa pessoa não está no grupo.", 404)
    if row.role == "owner":
        return _err("O dono não pode mudar o próprio papel.", 403)
    if row.role != role:
        row.role = role
        _system(group, user, f"{user.display_label} tornou {target.display_label} " + ("administrador" if role == "admin" else "membro"))
        db.session.commit()
        notify_group(group.id, "members")
    return jsonify({"group": serialize_group(group, me, with_members=True)})


@api_bp.route("/groups/<int:group_id>/leave", methods=["POST"])
@chat_login_required
def group_leave(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    others = ChatGroupMember.query.filter(
        ChatGroupMember.group_id == group.id, ChatGroupMember.user_id != user.id,
    ).order_by(ChatGroupMember.joined_at.asc(), ChatGroupMember.id.asc()).all()
    if not others:  # último a sair: o grupo some
        avatar = group.avatar_filename
        ChatGroupMessage.query.filter_by(group_id=group.id).update({"reply_to_id": None})
        db.session.flush()
        db.session.delete(group)
        db.session.commit()
        delete_upload(avatar)
        return jsonify({"left": True, "deleted": True})
    if me.role == "owner":  # passa o grupo: admin mais antigo, senão o membro mais antigo
        heir = next((r for r in others if r.role == "admin"), others[0])
        heir.role = "owner"
    db.session.delete(me)
    _system(group, user, f"{user.display_label} saiu do grupo")
    db.session.commit()
    notify_group(group.id, "removed", only=[user.id])
    notify_group(group.id, "members")
    return jsonify({"left": True, "deleted": False})


# ---------------------------------------------------------------------------
# Mensagens
# ---------------------------------------------------------------------------

@api_bp.route("/groups/<int:group_id>/messages", methods=["GET"])
@chat_login_required
def group_messages(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    try:
        limit = min(max(int(request.args.get("limit", 50)), 1), 200)
        before = int(request.args["before"]) if request.args.get("before") else None
        after = int(request.args["after"]) if request.args.get("after") else None
    except ValueError:
        return _err("Parâmetros inválidos.")
    q = _visible(group.id, me)
    if after is not None:
        rows = q.filter(ChatGroupMessage.id > after).order_by(ChatGroupMessage.id.asc()).limit(limit + 1).all()
        has_more = len(rows) > limit
        rows = rows[:limit]
    else:
        if before is not None:
            q = q.filter(ChatGroupMessage.id < before)
        rows = q.order_by(ChatGroupMessage.id.desc()).limit(limit + 1).all()
        has_more = len(rows) > limit
        rows = list(reversed(rows[:limit]))
    return jsonify({"messages": [serialize_message(m, user) for m in rows], "has_more": has_more})


@api_bp.route("/groups/<int:group_id>/messages", methods=["POST"])
@chat_login_required
def group_send(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    data = request.get_json(silent=True) or {}
    content = str(data.get("content") or "").strip()
    if not content:
        return _err("Escreva uma mensagem.")
    if len(content) > 2000:
        return _err("A mensagem pode ter até 2000 caracteres.")
    client_id = str(data.get("client_id") or "").strip()[:40] or None
    if client_id:
        dup = ChatGroupMessage.query.filter_by(group_id=group.id, sender_id=user.id, client_id=client_id).first()
        if dup is not None:
            return jsonify({"message": serialize_message(dup, user)})
    reply_to = None
    if data.get("reply_to_id") not in (None, ""):
        try:
            reply_to = db.session.get(ChatGroupMessage, int(data["reply_to_id"]))
        except (TypeError, ValueError):
            reply_to = None
        if reply_to is None or reply_to.group_id != group.id or reply_to.id <= me.start_after_id:
            return _err("A mensagem respondida não existe.")
    msg = ChatGroupMessage(group_id=group.id, sender_id=user.id, content=content, client_id=client_id,
                           reply_to_id=reply_to.id if reply_to else None)
    db.session.add(msg)
    db.session.flush()
    me.last_read_id = max(me.last_read_id or 0, msg.id)  # o que eu mando já está lido para mim
    # mensagem nova desarquiva o grupo para os outros (igual às conversas)
    for r in ChatGroupMember.query.filter(ChatGroupMember.group_id == group.id, ChatGroupMember.user_id != user.id,
                                          ChatGroupMember.archived.is_(True)):
        r.archived = False
    db.session.commit()
    notify_group(group.id, "message", id=msg.id)
    _push_group_message(group, msg, user)
    return jsonify({"message": serialize_message(msg, user)})


def _own_text_message(group, user, mid):
    m = db.session.get(ChatGroupMessage, mid)
    if m is None or m.group_id != group.id:
        return None
    return m


@api_bp.route("/groups/<int:group_id>/messages/<int:mid>", methods=["PUT"])
@chat_login_required
def group_edit_message(group_id, mid):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    m = _own_text_message(group, user, mid)
    if m is None or m.id <= me.start_after_id:
        return _err("Mensagem não encontrada.", 404)
    if m.sender_id != user.id or m.kind != "text" or m.deleted_at:
        return _err("Você só pode editar as suas mensagens de texto.", 403)
    window = current_app.config.get("CHAT_EDIT_WINDOW_SECONDS", 24 * 3600)
    if utcnow() - m.created_at > timedelta(seconds=window):
        return _err("O prazo para editar acabou.", 403)
    content = str((request.get_json(silent=True) or {}).get("content") or "").strip()
    if not content or len(content) > 2000:
        return _err("Escreva uma mensagem de até 2000 caracteres.")
    if content != m.content:
        m.content = content
        m.edited_at = utcnow()
        db.session.commit()
        notify_group(group.id, "update", sub="edit", id=m.id)
    return jsonify({"message": serialize_message(m, user)})


@api_bp.route("/groups/<int:group_id>/messages/<int:mid>", methods=["DELETE"])
@chat_login_required
def group_delete_message(group_id, mid):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    m = _own_text_message(group, user, mid)
    if m is None or m.id <= me.start_after_id:
        return _err("Mensagem não encontrada.", 404)
    if m.kind != "text":
        return _err("Mensagens do sistema não podem ser apagadas.", 403)
    own = m.sender_id == user.id
    if not (own or _is_admin(me)):
        return _err("Só o autor ou um administrador pode apagar.", 403)
    window = current_app.config.get("CHAT_DELETE_WINDOW_SECONDS", 48 * 3600)
    if own and not _is_admin(me) and utcnow() - m.created_at > timedelta(seconds=window):
        return _err("O prazo para apagar para todos acabou.", 403)
    if not m.deleted_at:
        m.deleted_at = utcnow()
        m.content = ""
        db.session.commit()
        notify_group(group.id, "update", sub="delete", id=m.id)
    return jsonify({"message": serialize_message(m, user)})


# ---------------------------------------------------------------------------
# Leitura, preferências, digitando
# ---------------------------------------------------------------------------

@api_bp.route("/groups/<int:group_id>/read", methods=["POST"])
@chat_login_required
def group_read(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    up_to = (request.get_json(silent=True) or {}).get("up_to_id")
    try:
        up_to = int(up_to) if up_to not in (None, "") else _latest_id(group.id)
    except (TypeError, ValueError):
        return _err("up_to_id inválido.")
    if up_to > (me.last_read_id or 0):
        me.last_read_id = min(up_to, _latest_id(group.id))
        db.session.commit()
        notify_group(group.id, "read", only=[user.id])  # minhas outras abas/aparelhos
    return jsonify({"unread": unread_count(me), "last_read_id": me.last_read_id})


@api_bp.route("/groups/<int:group_id>/prefs", methods=["PUT"])
@chat_login_required
def group_prefs(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    data = request.get_json(silent=True) or {}
    for key in ("pinned", "muted", "archived"):
        if key in data and not isinstance(data[key], bool):
            return _err(f"{key} deve ser true ou false.")
    if "muted" in data:
        me.muted = data["muted"]
    if "archived" in data:
        me.archived = data["archived"]
        if me.archived:
            me.pinned_at = None
    if "pinned" in data:
        if data["pinned"]:
            if me.pinned_at is None:
                limit = current_app.config.get("CHAT_MAX_PINNED", 3)
                n = ChatGroupMember.query.filter(
                    ChatGroupMember.user_id == user.id, ChatGroupMember.pinned_at.isnot(None),
                    ChatGroupMember.group_id != group.id,
                ).count()
                if n >= limit:
                    db.session.rollback()
                    return _err(f"Você pode fixar até {limit} grupos.")
                me.pinned_at = utcnow()
            me.archived = False
        else:
            me.pinned_at = None
    db.session.commit()
    notify_group(group.id, "prefs", only=[user.id])
    return jsonify({"prefs": serialize_group(group, me)["prefs"]})


@api_bp.route("/groups/<int:group_id>/typing", methods=["POST"])
@chat_login_required
def group_typing(group_id):
    user = current_api_user()
    group, me = _get(group_id, user)
    if group is None:
        return _not_found()
    state = (request.get_json(silent=True) or {}).get("state", "typing")
    if state not in ("typing", "stop"):
        return _err("state deve ser typing ou stop.")
    if state == "stop" or hub.typing_allowed(user.id, -group.id):
        notify_group(group.id, "typing", exclude=user.id, state=state, username=user.username)
    return jsonify({"ok": True})
