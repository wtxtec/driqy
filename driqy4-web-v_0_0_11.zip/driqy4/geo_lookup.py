"""
Localização é só um texto livre digitado pelo usuário no perfil (ex:
"Rio de Janeiro, BR", "Guarapari - ES"), sem coordenadas. Pro mapa de
"quem está online agora" do painel admin, tentamos casar esse texto com uma
lista de capitais/cidades grandes conhecidas — é só uma aproximação (o
pino cai no centro da cidade, não no endereço real de ninguém), suficiente
pra dar uma visão geral de onde a rede está concentrada sem precisar de
serviço de geocodificação externo nem guardar coordenada exata de ninguém.
"""
import re
import unicodedata

# (nomes possíveis pra bater no texto, latitude, longitude, rótulo de exibição)
_KNOWN_PLACES = [
    (["guarapari"], -20.6672, -40.4986, "Guarapari, ES"),
    (["vitoria", "vitoria es"], -20.3155, -40.3128, "Vitória, ES"),
    (["vila velha"], -20.3297, -40.2925, "Vila Velha, ES"),
    (["serra es", "serra, es"], -20.1289, -40.3078, "Serra, ES"),
    (["cariacica"], -20.2634, -40.4165, "Cariacica, ES"),
    (["sao paulo", "sp"], -23.5505, -46.6333, "São Paulo, SP"),
    (["rio de janeiro", "rj"], -22.9068, -43.1729, "Rio de Janeiro, RJ"),
    (["belo horizonte", "bh"], -19.9167, -43.9345, "Belo Horizonte, MG"),
    (["brasilia", "df"], -15.7939, -47.8828, "Brasília, DF"),
    (["salvador", "ba"], -12.9777, -38.5016, "Salvador, BA"),
    (["fortaleza", "ce"], -3.7172, -38.5433, "Fortaleza, CE"),
    (["recife", "pe"], -8.0476, -34.8770, "Recife, PE"),
    (["curitiba", "pr"], -25.4284, -49.2733, "Curitiba, PR"),
    (["porto alegre", "rs"], -30.0346, -51.2177, "Porto Alegre, RS"),
    (["manaus", "am"], -3.1190, -60.0217, "Manaus, AM"),
    (["belem", "pa"], -1.4558, -48.4902, "Belém, PA"),
    (["goiania", "go"], -16.6869, -49.2648, "Goiânia, GO"),
    (["campinas"], -22.9099, -47.0626, "Campinas, SP"),
    (["florianopolis", "sc"], -27.5954, -48.5480, "Florianópolis, SC"),
    (["natal", "rn"], -5.7945, -35.2110, "Natal, RN"),
    (["joao pessoa", "pb"], -7.1195, -34.8450, "João Pessoa, PB"),
    (["maceio", "al"], -9.6498, -35.7089, "Maceió, AL"),
    (["aracaju", "se"], -10.9472, -37.0731, "Aracaju, SE"),
    (["cuiaba", "mt"], -15.6014, -56.0979, "Cuiabá, MT"),
    (["campo grande", "ms"], -20.4697, -54.6201, "Campo Grande, MS"),
    (["teresina", "pi"], -5.0892, -42.8019, "Teresina, PI"),
    (["sao luis", "ma"], -2.5307, -44.3068, "São Luís, MA"),
    (["macapa", "ap"], 0.0389, -51.0664, "Macapá, AP"),
    (["boa vista", "rr"], 2.8235, -60.6758, "Boa Vista, RR"),
    (["porto velho", "ro"], -8.7619, -63.9039, "Porto Velho, RO"),
    (["rio branco", "ac"], -9.9754, -67.8249, "Rio Branco, AC"),
    (["palmas", "to"], -10.1689, -48.3317, "Palmas, TO"),
    (["lisboa", "portugal", "pt"], 38.7223, -9.1393, "Lisboa, Portugal"),
    (["porto, portugal"], 41.1579, -8.6291, "Porto, Portugal"),
    (["nova york", "new york", "nyc"], 40.7128, -74.0060, "Nova York, EUA"),
    (["miami"], 25.7617, -80.1918, "Miami, EUA"),
    (["londres", "london"], 51.5072, -0.1276, "Londres, Reino Unido"),
]


def _normalize(text):
    text = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode()
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def resolve(location_text):
    """
    Tenta casar o texto de localização com uma cidade conhecida.
    Retorna (lat, lng, rótulo) ou None se não reconhecer nada.
    """
    if not location_text:
        return None
    norm = f" {_normalize(location_text)} "
    for aliases, lat, lng, label in _KNOWN_PLACES:
        for alias in aliases:
            if f" {alias} " in norm or norm.strip() == alias:
                return lat, lng, label
    return None
