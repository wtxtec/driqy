"""Saúde do Vortex para o painel admin (Parte 8): fila de indexação + recomendação.

Só LÊ o banco (nunca altera nada). Tudo numa função, `health(app, cfg)`, que devolve um
dicionário simples (serve para a página e para o JSON). `alerts` traz avisos em português
quando algo foge do normal; os limites estão nas constantes abaixo.

Métricas da recomendação (janela de 24 h e 7 dias):
- sinais por tipo (open/like/less/dwell/search) e pessoas ativas;
- taxa de "menos disso" = less / (open + like + less): muito alta = a grade está errando o gosto;
- livro de vistos: linhas, quantas já foram vistas, rejeitadas e a taxa de REPETIÇÃO
  (linhas entregues mais de uma vez / linhas entregues) — alta = o usuário está vendo repetido;
- cobertura de conceitos (quanto do acervo o sistema "entende").
"""
from datetime import timedelta

from sqlalchemy import func

# limites dos avisos (ajuste aqui)
LESS_RATE_WARN = 0.15        # >15 % de "menos disso" entre os sinais de gosto
REPEAT_RATE_WARN = 0.25      # >25 % das peças entregues já tinham sido entregues antes
CONCEPT_COVERAGE_WARN = 80.0  # % do acervo entendido
QUEUE_ETA_WARN_HOURS = 72    # fila que levaria mais de 3 dias para esvaziar no ritmo atual
MIN_SIGNALS_FOR_RATES = 20   # abaixo disso as taxas não dizem nada


def _since(hours):
    from models import utcnow
    return utcnow() - timedelta(hours=hours)


def queue_health(app, db, cfg):
    import vortex_queue as vq
    from models import VortexFrontier
    stats = vq.queue_stats(app, db, cfg)
    with app.app_context():
        q = db.session.query(func.count(VortexFrontier.id))
        done_24h = q.filter(VortexFrontier.status == "done", VortexFrontier.done_at >= _since(24)).scalar() or 0
        failed = db.session.query(func.count(VortexFrontier.id)).filter(VortexFrontier.status == "failed").scalar() or 0
    rate_per_hour = done_24h / 24.0
    eta = round(stats["pending"] / rate_per_hour, 1) if rate_per_hour > 0 else None
    stats.update(done_24h=done_24h, failed=failed, rate_per_hour=round(rate_per_hour, 1), eta_hours=eta,
                 fill_percent=round(100.0 * stats["pending"] / stats["cap"], 1) if stats["cap"] else 0.0)
    return stats


def reco_health(app, db):
    from models import VortexInteraction as I, VortexSeen as S
    out = {}
    with app.app_context():
        for label, hours in (("h24", 24), ("d7", 24 * 7)):
            since = _since(hours)
            rows = (db.session.query(I.kind, func.count(I.id)).filter(I.created_at >= since)
                    .group_by(I.kind).all())
            kinds = {k: n for k, n in rows}
            users = (db.session.query(func.count(func.distinct(I.user_id)))
                     .filter(I.created_at >= since).scalar() or 0)
            taste = sum(kinds.get(k, 0) for k in ("open", "like", "less"))
            out[label] = {
                "kinds": kinds, "users": users, "signals": sum(kinds.values()),
                "less_rate": round(kinds.get("less", 0) / taste, 3) if taste else None,
                "like_rate": round(kinds.get("like", 0) / taste, 3) if taste else None,
            }
        total = db.session.query(func.count(S.id)).scalar() or 0
        served = db.session.query(func.count(S.id)).filter(S.served_count > 0).scalar() or 0
        reserved = db.session.query(func.count(S.id)).filter(S.served_count > 1).scalar() or 0
        viewed = db.session.query(func.count(S.id)).filter(S.viewed_count > 0).scalar() or 0
        rejected = db.session.query(func.count(S.id)).filter(S.rejected.is_(True)).scalar() or 0
        users = db.session.query(func.count(func.distinct(S.user_id))).scalar() or 0
    out["seen"] = {
        "rows": total, "users": users, "served": served, "viewed": viewed, "rejected": rejected,
        "repeat_rate": round(reserved / served, 3) if served else None,
    }
    return out


def health(app, cfg=None):
    from extensions import db
    import vortex_understand
    cfg = cfg if cfg is not None else app.config
    queue = queue_health(app, db, cfg)
    reco = reco_health(app, db)
    try:
        concepts = vortex_understand.coverage(app, ttl=30.0, top=8, samples=0)
    except Exception:
        concepts = None
    alerts = []
    if queue["level"] == "full":
        alerts.append("A fila de indexação está CHEIA: nenhum link novo entra até ela andar.")
    elif queue["level"] == "tight":
        alerts.append("A fila de indexação está apertada (só entram links rasos).")
    if queue["eta_hours"] is not None and queue["eta_hours"] > QUEUE_ETA_WARN_HOURS:
        alerts.append(f"No ritmo atual a fila levaria {queue['eta_hours']:.0f} h para esvaziar.")
    if queue["pending"] and queue["rate_per_hour"] == 0:
        alerts.append("Há páginas na fila, mas nenhuma foi visitada nas últimas 24 h (motor parado ou pausado?).")
    d24 = reco["h24"]
    if d24["signals"] >= MIN_SIGNALS_FOR_RATES and d24["less_rate"] is not None and d24["less_rate"] > LESS_RATE_WARN:
        alerts.append(f"{d24['less_rate'] * 100:.0f}% dos sinais de 24 h são \"menos disso\": a grade pode estar errando o gosto.")
    rr = reco["seen"]["repeat_rate"]
    if reco["seen"]["served"] >= 200 and rr is not None and rr > REPEAT_RATE_WARN:
        alerts.append(f"{rr * 100:.0f}% das peças entregues já tinham sido entregues antes (repetição alta).")
    if concepts and concepts["total"] and concepts["percent"] < CONCEPT_COVERAGE_WARN:
        alerts.append(f"Só {concepts['percent']}% do acervo foi entendido (conceitos); rode `python vortex_concepts.py --reprocess`.")
    return {"queue": queue, "reco": reco, "concepts": concepts, "alerts": alerts}
