# TURN (coturn) para chamadas de voz/vídeo

Chamadas WebRTC tentam ligar os aparelhos **direto** (STUN). Em ~10–20 % das redes (4G/CGNAT, firewalls
corporativos) isso falha e a chamada "conecta" sem áudio. O **TURN** retransmite a mídia e resolve.
STUN público (padrão em `config.py`) serve só para testes.

## Instalar (Ubuntu/Debian)
```
sudo apt install coturn
sudo sed -i 's/#TURNSERVER_ENABLED=1/TURNSERVER_ENABLED=1/' /etc/default/coturn
```

## `/etc/turnserver.conf` (mínimo)
```
listening-port=3478
tls-listening-port=5349
fingerprint
use-auth-secret
static-auth-secret=TROQUE_POR_UM_SEGREDO_LONGO
realm=turn.seudominio.com
total-quota=100
no-multicast-peers
no-cli
# TLS (opcional, recomendado): certificados do Let's Encrypt
# cert=/etc/letsencrypt/live/turn.seudominio.com/fullchain.pem
# pkey=/etc/letsencrypt/live/turn.seudominio.com/privkey.pem
# faixa de portas de mídia (abrir no firewall: UDP 49152-65535)
min-port=49152
max-port=65535
```
Abra no firewall: **3478 (UDP/TCP)**, **5349 (TCP)** e **UDP 49152–65535**.

## Ligar no Driqy (variáveis de ambiente)
```
CALL_TURN_URLS="turn:turn.seudominio.com:3478?transport=udp,turn:turn.seudominio.com:3478?transport=tcp,turns:turn.seudominio.com:5349?transport=tcp"
CALL_TURN_SECRET="o mesmo valor de static-auth-secret"
# opcional: CALL_STUN_URLS="stun:turn.seudominio.com:3478"
```
O servidor entrega credenciais **temporárias por usuário** (6 h) em `GET /api/v1/calls/config`;
nada fixo vai para o app. (Alternativa simples: `CALL_TURN_USERNAME` + `CALL_TURN_CREDENTIAL` com `user=` no coturn.)

## Testar
- `GET /api/v1/calls/config` deve mostrar `turn_configured: true`.
- Site de teste: https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/ — cole a URL `turn:`,
  usuário e senha (de `ice_servers`) e confira candidatos do tipo **relay**.
