# Calendário que funciona no mundo todo (em 4 partes)

## Parte 1 (feita): números trocados + "hoje" no fuso do usuário
- **Números errados no print** (… 5, 7, 8 … 30, 6): não era a data. O destaque de hoje e os feriados estavam nas casas
  certas (9, 15 e 20); só os textos vinham deslocados, com o "6" indo parar no fim. É o padrão de um tradutor automático
  do navegador embaralhando as casas. Correção: `translate="no"` + `notranslate` no painel (`_rail.html`) e na grade do calendário
  (`rail-new.js`). Se ainda aparecer, clique no ícone de tradução da barra de endereço e escolha "mostrar original".
- **"Hoje" por fuso**: antes era sempre Brasília. Agora `GET /widgets/calendar` aceita `tz` (nome IANA; o site manda
  `Intl.DateTimeFormat().resolvedOptions().timeZone`) ou `tz_offset` (minutos; o app manda o do aparelho). Inválido ou ausente = Brasília.

## Parte 2 (feita): feriados por país
`holidays_world.py` (sem rede): BR, PT, US, GB (Inglaterra), ES, FR, DE, IT, AR, MX, CA, JP e AU. Móveis saem da Páscoa,
de "n-ésima segunda-feira do mês" ou da fórmula dos equinócios (Japão). Só feriados **nacionais**: estaduais, municipais e
dia compensado quando cai no fim de semana não entram.
País: escolha do usuário (seletor "Feriados:" no calendário, guardado no navegador) > país do fuso (`tz`) > Brasil.
Fuso sem tabela (ex.: África) cai no Brasil e o seletor deixa trocar. `GET /widgets/calendar` aceita `country=XX` e devolve
`country`, `country_name`, `country_chosen` e `countries`. O app Flutter ainda não mostra o seletor (parte 4).

## Parte 3 (feita): horários, nomes e semana por região
- **Fuso do usuário nos horários**: `GET /widgets/moon` e `/widgets/seasons` aceitam `tz` (nome IANA, o site manda o do
  navegador) ou `tz_offset` (minutos, para o app). Nascer/pôr da Lua, "próximo evento", hora do máximo dos eclipses, datas
  dos marcos da Lua e início/fim das estações saem no fuso dele; sem `tz`, continua Brasília. Resposta nova: `tz_label`
  ("Brasília", "GMT-5", "GMT+5:30"), que o site mostra ao lado dos horários ("seu horário (GMT+9)").
- **Avisos de estação na hora local**: `User.tz_name` (coluna nova, criada sozinha) guarda o último fuso IANA que o site
  mandou aos widgets. `season_alerts.run_season_alerts` agrupa por fuso: o aviso só sai a partir das 8h LOCAIS e a contagem
  "3 dias antes / hoje" usa a data local. A chave anti-repetição continua sendo a data da virada em Brasília + tipo (igual
  para todos e igual à já gravada no banco). Sem fuso guardado (app, usuário que nunca abriu o painel): Brasília.
- **Nomes e semana**: `GET /widgets/calendar` agora devolve `lang`, `week_start` (0 = domingo, 1 = segunda), `weekdays`
  (iniciais já na ordem da grade) e `first_offset` (casas em branco antes do dia 1 nessa ordem); `month_name` vem no idioma da
  região (pt, en, es, fr, de, it, ja). `first_weekday` (0 = domingo) continua para clientes antigos. Semana na segunda:
  GB, ES, FR, DE, IT, AR; domingo: BR, PT, US, MX, CA, JP, AU. A região é a do seletor "Feriados:" (ou do fuso).
- **Limite conhecido:** os NOMES DOS FERIADOS continuam em português (ex.: "Ação de Graças" num calendário em inglês).

## Parte 4: app Flutter, testes e fechamento
Levar partes 2 e 3 ao app. 4a (calendário: país, nomes e semana) FEITA; 4b (Lua/Estações com `tz_offset` e `tz_label`) FEITA. Calendário global concluído (falta só compilar/testar no seu ambiente).
