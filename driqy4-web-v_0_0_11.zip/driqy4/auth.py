import re
import secrets

from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, session
from flask_login import login_user, logout_user, login_required, current_user

from extensions import db, oauth
from models import User

auth_bp = Blueprint("auth", __name__)

# Fase 15: nomes que colidem com rotas fixas do chat (/messages/privacy, /messages/stream,
# /mensagens/chamadas, /mensagens/api, Ping fase 8: /mensagens/contatos e /mensagens/configuracoes).
# Contas antigas com esses nomes continuam valendo.
RESERVED_USERNAMES = {"privacy", "stream", "chamadas", "api", "contatos", "configuracoes", "grupo", "grupos"}


class _UsernameRe:
    """Igual a `re.compile(...).match`, mas recusa nomes reservados."""

    def __init__(self, pattern):
        self._re = re.compile(pattern)

    def match(self, value):
        m = self._re.match(value or "")
        if m is not None and (value or "").lower() in RESERVED_USERNAMES:
            return None
        return m


USERNAME_RE = _UsernameRe(r"^[a-zA-Z0-9_]{3,20}$")


def _unique_username_from(base):
    """Gera um nome de usuário válido e livre a partir do e-mail/nome do
    Google, adicionando sufixos numéricos se já estiver em uso."""
    base = re.sub(r"[^a-zA-Z0-9_]", "", base) or "usuario"
    base = base[:20]
    if len(base) < 3:
        base = (base + "usuario")[:20]

    candidate = base
    suffix = 0
    while (candidate.lower() in RESERVED_USERNAMES
           or User.query.filter_by(username=candidate).first() is not None):
        suffix += 1
        suffix_str = str(suffix)
        candidate = f"{base[:20 - len(suffix_str)]}{suffix_str}"
    return candidate


@auth_bp.route("/registrar", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        errors = []
        if not USERNAME_RE.match(username):
            errors.append(
                "Nome de usuário deve ter 3-20 caracteres: letras, números ou _."
            )
        if not email or "@" not in email:
            errors.append("E-mail inválido.")
        if len(password) < 6:
            errors.append("A senha deve ter pelo menos 6 caracteres.")
        if password != password2:
            errors.append("As senhas não coincidem.")
        if User.query.filter_by(username=username).first():
            errors.append("Esse nome de usuário já está em uso.")
        if User.query.filter_by(email=email).first():
            errors.append("Esse e-mail já está cadastrado.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("register.html", username=username, email=email)

        user = User(username=username, email=email)
        user.set_password(password)

        # o primeiro usuário cadastrado no sistema vira admin automaticamente
        if User.query.count() == 0:
            user.is_admin = True

        db.session.add(user)
        db.session.commit()

        flash("Conta criada com sucesso! Faça login.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))

    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip().lower()
        password = request.form.get("password", "")

        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier)
        ).first()

        if user is None or not user.check_password(password):
            flash("Usuário/e-mail ou senha incorretos.", "danger")
            return render_template("login.html")

        if user.is_banned:
            flash("Esta conta foi banida. Contate um administrador.", "danger")
            return render_template("login.html")

        session.permanent = True
        login_user(user, remember=True)
        flash(f"Bem-vindo(a) de volta, {user.username}!", "success")
        next_page = request.args.get("next")
        return redirect(next_page or url_for("main.feed"))

    return render_template("login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Você saiu da sua conta.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/login/google")
def login_google():
    if not current_app.config.get("GOOGLE_LOGIN_ENABLED"):
        flash("Login com Google não está disponível no momento.", "danger")
        return redirect(url_for("auth.login"))

    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))

    redirect_uri = url_for("auth.google_callback", _external=True)
    return oauth.google.authorize_redirect(redirect_uri)


@auth_bp.route("/login/google/callback")
def google_callback():
    if not current_app.config.get("GOOGLE_LOGIN_ENABLED"):
        return redirect(url_for("auth.login"))

    try:
        token = oauth.google.authorize_access_token()
        userinfo = token.get("userinfo") or oauth.google.userinfo(token=token)
    except Exception:
        flash("Não foi possível concluir o login com o Google. Tente novamente.", "danger")
        return redirect(url_for("auth.login"))

    google_id = userinfo.get("sub")
    email = (userinfo.get("email") or "").strip().lower()
    email_verified = userinfo.get("email_verified", False)

    if not google_id or not email or not email_verified:
        flash("Não foi possível confirmar sua conta Google (e-mail não verificado).", "danger")
        return redirect(url_for("auth.login"))

    # 1) já existe alguém com esse google_id? só entra.
    user = User.query.filter_by(google_id=google_id).first()

    # 2) primeira vez, mas já existe uma conta com esse e-mail (criada com
    #    usuário/senha) — vincula o Google a essa conta em vez de duplicar.
    if user is None:
        user = User.query.filter_by(email=email).first()
        if user is not None:
            user.google_id = google_id

    # 3) ninguém com esse e-mail ainda — cria uma conta nova.
    if user is None:
        base_username = email.split("@")[0]
        username = _unique_username_from(base_username)
        display_name = (userinfo.get("name") or "").strip()[:50]

        user = User(
            username=username,
            email=email,
            google_id=google_id,
            display_name=display_name,
        )
        user.set_unusable_password()

        if User.query.count() == 0:
            user.is_admin = True

        db.session.add(user)

    if user.is_banned:
        flash("Esta conta foi banida. Contate um administrador.", "danger")
        return redirect(url_for("auth.login"))

    db.session.commit()
    session.permanent = True
    login_user(user, remember=True)
    flash(f"Bem-vindo(a), {user.username}!", "success")
    return redirect(url_for("main.feed"))


@auth_bp.route("/esqueci-senha", methods=["GET", "POST"])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = User.query.filter_by(email=email).first() if email else None

        if user is not None:
            from mailer import send_password_reset_email

            token = user.generate_reset_token(
                current_app.config["PASSWORD_RESET_EXPIRES_MINUTES"]
            )
            db.session.commit()

            reset_url = url_for("auth.reset_password", token=token, _external=True)
            send_password_reset_email(user, reset_url)

        # Mensagem igual não importa se o e-mail existe ou não — evita que
        # alguém use este formulário pra descobrir quais e-mails estão
        # cadastrados no site.
        flash(
            "Se esse e-mail estiver cadastrado, enviamos um link de redefinição de senha para ele.",
            "success",
        )
        return redirect(url_for("auth.login"))

    return render_template("forgot_password.html")


@auth_bp.route("/redefinir-senha/<token>", methods=["GET", "POST"])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))

    user = User.query.filter_by(reset_token=token).first()
    if user is None or not user.verify_reset_token(token):
        flash("Este link de redefinição de senha é inválido ou já expirou. Peça um novo.", "danger")
        return redirect(url_for("auth.forgot_password"))

    if request.method == "POST":
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        errors = []
        if len(password) < 6:
            errors.append("A senha deve ter pelo menos 6 caracteres.")
        if password != password2:
            errors.append("As senhas não coincidem.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("reset_password.html", token=token)

        user.set_password(password)
        user.clear_reset_token()
        db.session.commit()

        flash("Senha redefinida com sucesso! Faça login com a nova senha.", "success")
        return redirect(url_for("auth.login"))

    return render_template("reset_password.html", token=token)
