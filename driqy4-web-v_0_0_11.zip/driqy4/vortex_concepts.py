"""
Compreensão de conteúdo do Vortex — taxonomia de CONCEITOS (Parte 3A).

Problema que isto resolve: o "mais como este" e o gosto do usuário só enxergavam
categoria + tags soltas. Quem clicava num carro recebia gente dançando e balões,
porque nada dizia que "carro" é um veículo de rodas, parente de moto, caminhão
e bicicleta, e que nada tem a ver com dança ou festa.

Este módulo é PURO (sem banco, sem rede, sem Flask): só texto -> conceitos. A
Parte 3B grava o resultado no banco e reprocessa o acervo; a Parte 4 usa
`relation`/`similarity` nos relacionados; a Parte 5 usa os conceitos no perfil.

Ideias
------
* Taxonomia em árvore (domínio > família > conceito > especialização):

      veiculo                        <- domínio (raiz)
        veiculo_rodas                <- família ("coisas com rodas")
          carro  moto  caminhao  bicicleta  onibus  trator
          carro > carro_esportivo, carro_antigo, carro_corrida
        aeronave   embarcacao   veiculo_trilho
      pessoas > festa > balao   (balão de festa NÃO é veículo)

* `extract(...)` lê título, tags, descrição e os conceitos do CLIP
  (`visual_tags`) e devolve até 6 conceitos com peso 0..1. Casamento por
  palavra inteira (sem acento, singular/plural), o termo MAIS LONGO ganha
  ("campo de futebol" é futebol, não "campo"). Termo ambíguo divide o peso.
* `relation(a, b)` mede o parentesco de dois conceitos (1.0 igual; 0.8 pai/filho;
  0.65 irmãos; 0.5 primos; 0.25 mesmo domínio; 0 domínios diferentes, salvo
  ligações explícitas em `LINKS`, p.ex. bicicleta<->ciclismo).
* `similarity(a, b)` compara dois CONJUNTOS de conceitos (peças inteiras).

Testar à mão:  python vortex_concepts.py "red sports car on a road"
"""
import re
import sys
import unicodedata
from collections import defaultdict, namedtuple

# v2 (Parte 3B): texto corroborado em vez de somado, cenário amortecido quando há assunto,
# tags de aparência (cor/luz) ignoradas. Nada tinha sido gravado com a v1.
CONCEPTS_VERSION = 2

# ---------------------------------------------------------------------------
# taxonomia: (id, rótulo pt, pai, termos pt+en separados por vírgula)
# Termos no singular; plural é gerado sozinho (+s, +es, ies, ões, ns, is).
# Formas irregulares/gerúndio entram à mão.
# ---------------------------------------------------------------------------
_RAW = [
    # ====================================================== VEÍCULOS
    ("veiculo", "Veículos", None, "veiculo,vehicle,transporte,transport"),
    ("veiculo_rodas", "Veículos de rodas", "veiculo", "veiculo de rodas,wheeled vehicle,automotivo,automotive"),
    ("carro", "Carro", "veiculo_rodas",
     "carro,car,automovel,automobile,sedan,hatchback,suv,coupe,carro popular,pickup,picape,camioneta,minivan,limousine,limusine,jipe,jeep,taxi,auto"),
    ("carro_esportivo", "Carro esportivo", "carro",
     "carro esportivo,sports car,supercar,super carro,esportivo,ferrari,lamborghini,porsche,mustang,camaro,conversivel,convertible,roadster,muscle car"),
    ("carro_antigo", "Carro antigo", "carro",
     "carro antigo,classic car,vintage car,antique car,carro classico,carro de colecao,fusca,beetle,hot rod,oldtimer,model t"),
    ("carro_corrida", "Carro de corrida", "carro",
     "carro de corrida,race car,racing car,formula 1,formula one,f1,kart,rally,rali,nascar,indy,stock car,drag racing,grand prix"),
    ("moto", "Moto", "veiculo_rodas",
     "moto,motocicleta,motorcycle,motorbike,scooter,lambreta,vespa,harley,harley davidson,motoqueiro,biker,motocross,quadriciclo,lambreta"),
    ("caminhao", "Caminhão", "veiculo_rodas",
     "caminhao,truck,lorry,carreta,semi truck,tir,betoneira,cacamba,dump truck,fire truck,caminhao de bombeiro,garbage truck,food truck"),
    ("bicicleta", "Bicicleta", "veiculo_rodas",
     "bicicleta,bike,bicycle,bici,mountain bike,mtb,bmx,bike eletrica,e bike,ciclista,cyclist,fixie,triciclo,tricycle"),
    ("onibus", "Ônibus", "veiculo_rodas", "onibus,bus,onibus escolar,microonibus,coach bus,school bus,double decker,van,kombi,micro onibus"),
    ("trator", "Trator e máquinas", "veiculo_rodas",
     "trator,tractor,colheitadeira,combine harvester,escavadeira,excavator,bulldozer,retroescavadeira,guindaste,crane truck,empilhadeira,forklift,maquina agricola"),
    ("aeronave", "Aeronaves", "veiculo", "aeronave,aircraft"),
    ("aviao", "Avião", "aeronave",
     "aviao,airplane,aeroplane,plane,jato,jet,airliner,boeing,airbus,biplano,biplane,aviao de caca,fighter jet,planador,glider,avioneta"),
    ("helicoptero", "Helicóptero", "aeronave", "helicoptero,helicopter,chopper"),
    ("balao_ar_quente", "Balão de ar quente", "aeronave",
     "balao de ar quente,hot air balloon,balonismo,ballooning,dirigivel,zeppelin,airship,blimp"),
    ("embarcacao", "Embarcações", "veiculo", "embarcacao,watercraft"),
    ("barco", "Barco", "embarcacao",
     "barco,boat,lancha,speedboat,jet ski,jetski,canoa,canoe,caiaque,kayak,bote,rowboat,pesqueiro,fishing boat,rebocador,tugboat,balsa,ferry,ferryboat,gondola,barcos"),
    ("navio", "Navio", "embarcacao",
     "navio,ship,cruzeiro,cruise ship,transatlantico,cargueiro,cargo ship,navio de guerra,warship,porta avioes,submarino,submarine,petroleiro,tanker"),
    ("veleiro", "Veleiro", "embarcacao", "veleiro,sailboat,sailing boat,yacht,iate,catamara,catamaran,vela,sailing,regata,regatta,windsurf"),
    ("veiculo_trilho", "Veículos sobre trilhos", "veiculo", "veiculo sobre trilhos,rail vehicle,ferroviario,railway,railroad"),
    ("trem", "Trem", "veiculo_trilho",
     "trem,train,locomotiva,locomotive,metro,subway,underground,tube,bonde,tram,streetcar,trem bala,bullet train,vagao,metrô,monotrilho,monorail,maria fumaca,steam train"),

    # ====================================================== NATUREZA
    ("natureza", "Natureza", None, "natureza,nature,paisagem,landscape,scenery,outdoor,outdoors,wilderness,natural"),
    ("paisagem_agua", "Paisagens de água", "natureza", "paisagem de agua,water landscape"),
    ("cachoeira", "Cachoeira", "paisagem_agua", "cachoeira,waterfall,cascata,cascade,queda d agua,salto,rapids,corredeira"),
    ("praia", "Praia", "paisagem_agua", "praia,beach,costa,coast,coastline,litoral,seaside,areia,sand,duna do mar,shore,orla,beachfront"),
    ("mar", "Mar e ondas", "paisagem_agua",
     "mar,sea,oceano,ocean,onda,wave,ondas do mar,ocean wave,maresia,surf break,tide,mare,underwater,submarino,debaixo d agua"),
    ("lago", "Lago", "paisagem_agua", "lago,lake,lagoa,lagoon,pond,represa,reservoir,fjord,fiorde,bay,baia"),
    ("rio", "Rio", "paisagem_agua", "rio,river,riacho,stream,creek,igarape,canal,delta,nascente,spring"),
    ("ilha_tropical", "Ilha tropical", "paisagem_agua",
     "ilha tropical,tropical island,ilha,island,atol,atoll,paraiso tropical,tropical paradise,palmeira,palm tree,coqueiro,coconut tree,tropical beach"),
    ("paisagem_terra", "Paisagens de terra", "natureza", "paisagem de terra,land landscape"),
    ("montanha", "Montanha", "paisagem_terra",
     "montanha,mountain,serra,morro,pico,peak,cordilheira,mountain range,alpes,alps,himalaia,himalaya,colina,hill,planalto,plateau,monte,valley,vale"),
    ("floresta", "Floresta", "paisagem_terra",
     "floresta,forest,mata,woods,woodland,selva,jungle,rainforest,amazonia,amazon rainforest,bosque,trilha na mata,forest path"),
    ("deserto", "Deserto", "paisagem_terra", "deserto,desert,dunas,dunes,sahara,savana,savanna,arido,arid,badlands"),
    ("campo", "Campo e pasto", "paisagem_terra",
     "campo,field,pasto,pasture,meadow,prado,grass field,gramado natural,plantacao,plantation,lavoura,farmland,farm field,trigal,wheat field,rural"),
    ("vulcao", "Vulcão", "paisagem_terra", "vulcao,volcano,lava,erupcao,eruption,cratera,crater,volcanic"),
    ("caverna", "Caverna", "paisagem_terra", "caverna,cave,gruta,grotto,cavern,estalactite,stalactite"),
    ("canion", "Cânion", "paisagem_terra", "canion,canyon,desfiladeiro,gorge,penhasco,cliff,falesia,rochedo,rock formation,garganta"),
    ("neve_gelo", "Neve e gelo", "paisagem_terra",
     "neve,snow,paisagem com neve,snowy landscape,snowy,inverno nevado,gelo,ice,geleira,glacier,iceberg,tundra,nevasca,blizzard,frozen,congelado,winter landscape,snowfall"),
    ("ceu_clima", "Céu e clima", "natureza", "ceu e clima,sky and weather"),
    ("por_do_sol", "Pôr do sol", "ceu_clima",
     "por do sol,sunset,nascer do sol,sunrise,amanhecer,dawn,entardecer,dusk,golden hour,hora dourada,crepusculo,twilight,aurora,aurora boreal,northern lights"),
    ("nuvem", "Nuvens e tempo", "ceu_clima",
     "nuvem,cloud,clouds in the sky,ceu,sky,tempestade,storm,raio,lightning,chuva,rain,neblina,fog,mist,nevoeiro,tornado,furacao,hurricane,trovoada,thunderstorm"),
    ("arco_iris", "Arco-íris", "ceu_clima", "arco iris,rainbow"),
    ("flora", "Plantas", "natureza", "flora,planta,plant,vegetacao,vegetation,botanica,botanical"),
    ("flor", "Flores", "flora",
     "flor,flower,flores,rosa,rose,tulipa,tulip,girassol,sunflower,orquidea,orchid,lirio,lily,margarida,daisy,jardim,garden,bouquet,buque,floral,blossom,cerejeira,cherry blossom,lavanda,lavender,petala,petal,margaridas"),
    ("arvore", "Árvores", "flora",
     "arvore,tree,carvalho,oak,pinheiro,pine,bambu,bamboo,cacto,cactus,folha,leaf,folhagem,foliage,galho,branch,musgo,moss,samambaia,fern,bonsai,suculenta,succulent"),
    ("outono", "Outono", "flora", "outono,autumn,fall foliage,folhas secas,autumn leaves,autumn trees,otonal"),

    # ====================================================== ANIMAIS
    ("animais", "Animais", None, "animal,animals,wildlife,fauna,bicho,pet,creature,zoologico,zoo"),
    ("animal_pet", "Pets", "animais", "animal de estimacao,pets,domestic animal"),
    ("cachorro", "Cachorro", "animal_pet",
     "cachorro,dog,cao,caes,cachorrinho,puppy,filhote de cachorro,labrador,golden retriever,poodle,bulldog,husky,pastor alemao,german shepherd,vira lata,beagle,dachshund,salsicha,chihuahua,pug,collie,doberman,shih tzu,corgi,spaniel,canino,canine"),
    ("gato", "Gato", "animal_pet",
     "gato,cat,gatinho,kitten,felino,feline,siames,siamese,persa,persian cat,maine coon,tabby,gata,kitty,gato preto,black cat"),
    ("coelho", "Coelho", "animal_pet", "coelho,rabbit,bunny,lebre,hare,hamster,porquinho da india,guinea pig,chinchila,chinchilla,furao,ferret"),
    ("animal_fazenda", "Animais de fazenda", "animais", "animal de fazenda,farm animal,livestock,gado,fazenda,farm"),
    ("cavalo", "Cavalo", "animal_fazenda", "cavalo,horse,egua,mare,potro,foal,pony,pônei,garanhao,stallion,equino,equine,cavalaria,jumento,donkey,burro,mula,mule,zebra"),
    ("vaca", "Vaca e boi", "animal_fazenda", "vaca,cow,boi,ox,bovino,cattle,bezerro,calf,touro,bull,bufalo,buffalo,yak"),
    ("ovelha", "Ovelha e cabra", "animal_fazenda", "ovelha,sheep,cordeiro,lamb,carneiro,ram,cabra,goat,bode,lhama,llama,alpaca,porco,pig,leitao,piglet,galinha,hen,chicken,galo,rooster,pato,duck,ganso,goose,peru,turkey"),
    ("animal_selvagem", "Animais selvagens", "animais", "animal selvagem,wild animal,mamifero,mammal,safari"),
    ("leao", "Leão e felinos", "animal_selvagem", "leao,lion,tigre,tiger,leopardo,leopard,onca,jaguar,puma,cougar,guepardo,cheetah,pantera,panther,lince,lynx,leoa,lioness,felinos selvagens,big cat"),
    ("urso", "Urso", "animal_selvagem", "urso,bear,panda,urso polar,polar bear,grizzly,urso pardo,brown bear,koala"),
    ("lobo", "Lobo e raposa", "animal_selvagem", "lobo,wolf,raposa,fox,coiote,coyote,chacal,jackal,hiena,hyena,lobo guara,maned wolf"),
    ("elefante", "Elefante e grandes", "animal_selvagem", "elefante,elephant,rinoceronte,rhino,rhinoceros,hipopotamo,hippo,girafa,giraffe,camelo,camel,bisao,bison,alce,moose,elk,veado,deer,cervo,reindeer,rena,canguru,kangaroo,gorila,gorilla"),
    ("macaco", "Macaco", "animal_selvagem", "macaco,monkey,chimpanze,chimpanzee,orangotango,orangutan,babuino,baboon,mico,lemure,lemur,primata,primate,sagui,marmoset,bugio,gibbon"),
    ("ave", "Aves", "animais", "ave,bird,birds,passaro,pássaros,bird watching,ornitologia"),
    ("passaro", "Pássaro", "ave",
     "passaro,songbird,pardal,sparrow,beija flor,hummingbird,tucano,toucan,arara,macaw,andorinha,swallow,pomba,dove,pigeon,gaivota,seagull,aguia,eagle,falcao,falcon,gavião,hawk,cisne,swan,flamingo,pavao,peacock,pelicano,pelican,garca,heron,cardeal,cardinal,canario,canary,bem te vi,passarinho"),
    ("coruja", "Coruja", "ave", "coruja,owl,mocho,corujao,great horned owl"),
    ("papagaio", "Papagaio", "ave", "papagaio,parrot,periquito,parakeet,calopsita,cockatiel,cacatua,cockatoo,agapornis,lovebird"),
    ("pinguim", "Pinguim", "ave", "pinguim,penguin,pinguins"),
    ("animal_aquatico", "Vida aquática", "animais", "vida aquatica,aquatic life,marine life,vida marinha,aquario,aquarium"),
    ("peixe", "Peixe", "animal_aquatico",
     "peixe,fish,tubarao,shark,salmao,salmon,atum,tuna,carpa,carp,koi,peixe palhaco,clownfish,peixinho,goldfish,betta,arraia,stingray,manta,raia,enguia,eel,cavalo marinho,seahorse,pesca,fishing,cardume,school of fish,coral,recife,reef,coral reef,anemona,polvo,octopus,lula,squid,agua viva,jellyfish,caranguejo,crab,lagosta,lobster,camarao,shrimp,estrela do mar,starfish"),
    ("golfinho", "Golfinho e baleia", "animal_aquatico", "golfinho,dolphin,baleia,whale,orca,killer whale,foca,seal,leao marinho,sea lion,morsa,walrus,manati,manatee,boto"),
    ("tartaruga", "Tartaruga", "animal_aquatico", "tartaruga,turtle,tartaruga marinha,sea turtle,cagado,tortoise,jabuti,cagado"),
    ("animal_pequeno", "Insetos e répteis", "animais", "inseto e reptil,insects and reptiles"),
    ("borboleta", "Borboleta", "animal_pequeno", "borboleta,butterfly,mariposa,moth,libelula,dragonfly,joaninha,ladybug,ladybird,monarca,monarch"),
    ("inseto", "Inseto", "animal_pequeno", "inseto,insect,abelha,bee,vespa wasp,formiga,ant,besouro,beetle,aranha,spider,mosca,fly,mosquito,gafanhoto,grasshopper,grilo,cricket,escorpiao,scorpion,lagarta,caterpillar,centopeia,centipede,louva a deus,mantis,bug"),
    ("cobra", "Cobra e lagarto", "animal_pequeno", "cobra,snake,serpente,serpent,jiboia,boa,piton,python,naja,cobra cobra,lagarto,lizard,iguana,camaleao,chameleon,jacare,alligator,crocodilo,crocodile,sapo,frog,perereca,tree frog,salamandra,salamander,gecko,lagartixa,dragao de komodo,komodo"),

    # ====================================================== LUGARES / VIAGENS
    ("lugares", "Lugares e viagens", None, "lugar,place,viagem,travel,turismo,tourism,destino,destination,tourist,turista,trip,viajar,vacation,ferias,landmark"),
    ("cidade", "Cidade e rua", "lugares",
     "cidade,city,horizonte da cidade,skyline,city skyline,urbano,urban,centro da cidade,downtown,rua,street,rua historica,historic street,avenida,avenue,viela,alley,calcada,sidewalk,praca,square,plaza,cityscape,metropole,metropolis,vila,village,town,cidade antiga,old town,bairro,neighborhood,night city,rio de janeiro,sao paulo,porto alegre,nova york,new york,paris,londres,london,toquio,tokyo,veneza,venice,roma,rome"),
    ("mercado", "Mercado e feira", "lugares",
     "mercado,market,mercado de rua,street market,feira,fair,bazar,bazaar,souk,loja,shop,store,vitrine,storefront,shopping,mall,supermercado,supermarket,barraca,stall,vendedor,vendor"),
    ("estrada", "Estrada e caminho", "lugares",
     "estrada,road,rodovia,highway,freeway,autoestrada,motorway,caminho,path,trilha,trail,rua deserta,empty road,road trip,viagem de carro,asfalto,asphalt,cruzamento,crossroads,tunel,tunnel,pedagio,toll"),
    ("porto", "Porto e aeroporto", "lugares",
     "porto,port,harbor,harbour,porto com barcos,porto de pesca,docas,dock,marina,cais,pier,quay,aeroporto,airport,terminal,estacao de trem,train station,railway station,rodoviaria,bus station,heliponto,helipad"),

    # ====================================================== ARQUITETURA
    ("arquitetura", "Arquitetura", None, "arquitetura,architecture,construcao,construction,arquitetonico,architectural,estrutura,structure"),
    ("edificio", "Edifícios", "arquitetura", "edificio,edificacao"),
    ("predio", "Prédio e arranha-céu", "edificio",
     "predio,building,buildings,arranha ceu,skyscraper,torre comercial,office tower,edificio alto,high rise,highrise,apartamento,apartment,condominio,condominium,fachada,facade,vidro e aco,glass building,sede,headquarters,hotel,hospital,escola,school building,universidade,university,fabrica,factory,armazem,warehouse"),
    ("casa", "Casa", "edificio",
     "casa,house,casa moderna,modern house,home,residencia,residence,chale,cabin,cottage,mansao,mansion,villa,bangalo,bungalow,sitio,casa de campo,farmhouse,celeiro,barn,cabana,hut,casa de praia,beach house,lar,fachada de casa,telhado,roof"),
    ("castelo", "Castelo e fortaleza", "edificio",
     "castelo,castle,fortaleza,fortress,forte,fort,palacio,palace,muralha,rampart,city wall,cidadela,citadel,medieval,medieval castle,torre de castelo,chateau"),
    ("arq_religiosa", "Arquitetura religiosa", "arquitetura", "arquitetura religiosa,religious architecture"),
    ("igreja", "Igreja e catedral", "arq_religiosa",
     "igreja,church,catedral,cathedral,interior de igreja,church interior,capela,chapel,basilica,mosteiro,monastery,abadia,abbey,convento,convent,vitral da igreja,altar,campanario,bell tower,nave"),
    ("templo", "Templo e mesquita", "arq_religiosa",
     "templo,temple,mesquita,mosque,sinagoga,synagogue,pagode,pagoda,templo budista,buddhist temple,xinto,shinto,santuario,shrine,minarete,minaret,stupa,templo hindu,hindu temple,cupula,dome,domo"),
    ("arq_estrutura", "Estruturas e monumentos", "arquitetura", "estrutura e monumento,structures and monuments"),
    ("ponte", "Ponte", "arq_estrutura", "ponte,bridge,viaduto,viaduct,ponte pensil,suspension bridge,passarela,footbridge,aqueduto,aqueduct,ponte de pedra,stone bridge"),
    ("torre", "Torre e farol", "arq_estrutura", "torre,tower,farol,lighthouse,torre eiffel,eiffel tower,obelisco,obelisk,minarete alto,watchtower,torre de relogio,clock tower,antena,radio tower"),
    ("monumento", "Monumento e estátua", "arq_estrutura",
     "monumento,monument,estatua,statue,memorial,marco historico,landmark monument,arco do triunfo,arc de triomphe,cristo redentor,christ the redeemer,estatua da liberdade,statue of liberty,pirâmide,piramide,pyramid,coliseu,colosseum,partenon,parthenon,taj mahal,machu picchu,muralha da china,great wall,fonte,fountain,chafariz,coluna,column"),
    ("ruinas", "Ruínas", "arq_estrutura", "ruinas,ruins,ruina,ruin,sitio arqueologico,archaeological site,arqueologia,archaeology,antigo,ancient,escavacao,excavation,vestigios,abandonado,abandoned,decadente"),
    ("escada", "Escada", "arq_estrutura", "escada,stairs,staircase,stairway,escadaria,steps,escada em espiral,spiral staircase,degraus,degrau,corrimao,handrail,elevador,elevator,rampa,ramp"),
    ("interior", "Interiores e decoração", "arquitetura",
     "interior,interiors,sala decorada,decorated room,sala de estar,living room,decoracao,decor,interior design,design de interiores,cozinha,kitchen,quarto,bedroom,banheiro,bathroom,escritorio,office,movel,furniture,sofa,couch,mesa,table,cadeira,chair,biblioteca,library,lustre,chandelier,lareira,fireplace,varanda,balcony,jardim interno,atrio,lobby"),

    # ====================================================== ARTE
    ("arte", "Arte e design", None, "arte,art,artistico,artistic,artwork,obra de arte,design,galeria,gallery,museu,museum,exposicao,exhibition,artista,artist"),
    ("pintura", "Pintura", "arte", "pintura,painting,pintura a oleo,oil painting,aquarela,watercolor,tela,canvas,acrilica,acrylic,quadro,retrato pintado,painted portrait,paisagem pintada,impressionismo,impressionism,renascimento,renaissance,barroco,baroque,pintor,painter,mona lisa,van gogh,monet,picasso,pincel,brush,tinta,paint"),
    ("escultura", "Escultura", "arte", "escultura,sculpture,escultor,sculptor,busto,bust,estatueta,figurine,entalhe,carving,marmore,marble sculpture,bronze,relevo,bas relief,instalacao,installation"),
    ("desenho", "Desenho", "arte", "desenho,drawing,sketch,esboco,rascunho,croqui,lapis,pencil,carvao,charcoal,nanquim,ink drawing,caligrafia,calligraphy,tracado,line art,doodle,rabisco,mangá,manga,quadrinhos,comics,historia em quadrinhos,comic book"),
    ("grafite", "Grafite e arte de rua", "arte", "grafite,graffiti,street art,arte de rua,mural,muralismo,pichacao,spray paint,stencil,tag urbana,wall art,arte urbana,urban art"),
    ("arte_abstrata", "Arte abstrata", "arte", "arte abstrata,abstract art,abstrato,abstract,geometrico,geometric,surrealismo,surrealism,cubismo,cubism,minimalismo,minimalism,expressionismo,expressionism,psicodelico,psychedelic,fractal,mandala,padrao,pattern,textura,texture,arte digital,digital art,generative art"),
    ("ceramica", "Cerâmica e artesanato", "arte", "ceramica,ceramic,ceramics,porcelana,porcelain,vaso,vase,argila,clay,barro,pottery,olaria,artesanato,handicraft,craft,crochê,croche,tricô,tricot,knitting,bordado,embroidery,tecelagem,weaving,origami,macrame,cestaria,basketry,trabalho manual,handmade"),
    ("vitral", "Vitral e mosaico", "arte", "vitral,stained glass,mosaico,mosaic,azulejo,tile,azulejos,tiles,painel de vidro,glass art,caleidoscopio,kaleidoscope"),
    ("ilustracao", "Ilustração", "arte", "ilustracao,illustration,ilustrado,illustrated,vetor,vector,arte vetorial,vector art,infografico,infographic,icone,icon,arte conceitual,concept art,fan art,fanart,character design,aquarela digital,flat design,cartoon art,desenho animado art,storybook"),
    ("cartaz", "Cartaz e tipografia", "arte", "cartaz,poster,cartazes,flyer,panfleto,anuncio,advertisement,tipografia,typography,lettering,fonte tipografica,font,logotipo,logotype,capa de livro,book cover,capa de album,album cover,propaganda,propaganda antiga,vintage ad,brochure"),
    ("fotografia_arte", "Fotografia artística", "arte", "fotografia,photography,fotografo,photographer,preto e branco,black and white,monochrome,longa exposicao,long exposure,macro,macrofotografia,macro photography,fine art photography,fotografia de rua,street photography,bokeh,silhueta,silhouette,minimalist photography,double exposure,dupla exposicao"),

    # ====================================================== COMIDA
    ("comida", "Comida", None, "comida,food,culinaria,cuisine,gastronomia,gastronomy,refeicao,meal,prato,dish,receita,recipe,cozinhar,cooking,chef,restaurante,restaurant,lanche,snack,delicious,delicioso,gourmet,foodie,mesa posta,table setting"),
    ("prato_salgado", "Pratos salgados", "comida", "prato salgado,savory dish"),
    ("pizza", "Pizza", "prato_salgado", "pizza,pizzaria,pizzeria,calzone,focaccia,pizza napolitana,margherita"),
    ("hamburguer", "Hambúrguer e fast food", "prato_salgado", "hamburguer,hamburger,burger,cheeseburger,hot dog,cachorro quente,sanduiche,sandwich,fast food,batata frita,french fries,fries,nuggets,tacos,taco,burrito,kebab,wrap,coxinha,pastel,salgado,empada,esfiha,quesadilla,nachos,pao de queijo,hot dogs"),
    ("sushi", "Sushi e culinária oriental", "prato_salgado", "sushi,sashimi,temaki,niguiri,nigiri,maki,ramen,lamen,tempura,yakisoba,gyoza,dim sum,comida japonesa,japanese food,comida chinesa,chinese food,pad thai,curry,caril,comida tailandesa,thai food,bibimbap,kimchi,pho,wok,onigiri,miojo"),
    ("salada", "Salada", "prato_salgado", "salada,salad,alface,lettuce,tomate,tomato,pepino,cucumber,rucula,arugula,folhas verdes,leafy greens,caesar,vegetariano,vegetarian,vegano,vegan,bowl,poke,legume cru,healthy food,comida saudavel,fit food,saudavel,low carb,superfood"),
    ("massa", "Massa", "prato_salgado", "massa,pasta,macarrao,spaghetti,espaguete,lasanha,lasagna,nhoque,gnocchi,penne,fettuccine,carbonara,bolonhesa,bolognese,ravioli,risoto,risotto,talharim,noodles,macarronada,molho de tomate,tomato sauce,pesto"),
    ("churrasco", "Churrasco e carnes", "prato_salgado", "churrasco,barbecue,bbq,grelhado,grilled,grill,carne,meat,steak,bife,picanha,costela,ribs,linguica,sausage,salsicha,frango assado,roast chicken,assado,roast,espeto,skewer,fogueira culinaria,fumeiro,smoked,bacon,presunto,ham,churrasqueira,feijoada,estrogonofe,stroganoff,strogonoff"),
    ("frutos_do_mar", "Frutos do mar", "prato_salgado", "frutos do mar,seafood,camarao cozido,cooked shrimp,lagosta cozida,ostra,oyster,mexilhao,mussel,marisco,clam,peixe assado,grilled fish,moqueca,bacalhau,cod,paella,paelha,ceviche,peixe frito,fish and chips,caranguejo cozido,siri,lula frita,calamari,sardinha,sardine"),
    ("sopa", "Sopa e caldos", "prato_salgado", "sopa,soup,caldo,broth,ensopado,stew,sopa de legumes,vegetable soup,canja,creme de abobora,pumpkin soup,caldo verde,goulash,chili,cozido,minestrone,sopa quente,hot soup"),
    ("doce", "Doces e sobremesas", "comida", "doce,sweet,doces,sweets,confeitaria,confectionery,sobremesa doce"),
    ("bolo", "Bolo", "doce", "bolo,cake,cupcake,bolo de aniversario,birthday cake,torta,pie,tarte,tart,cheesecake,brownie,muffin,donut,rosquinha,doughnut,waffle,panqueca,pancake,crepe,cookie,biscoito,biscuit,macaron,eclair,croissant doce,pao de mel,bolo de chocolate,chocolate cake,bolo de cenoura,carrot cake,confeito,cake pop,bolo decorado"),
    ("sobremesa", "Sobremesa", "doce", "sobremesa,dessert,pudim,pudding,flan,mousse,brigadeiro,beijinho,docinho,gelatina,jelly,creme brulee,tiramisu,panna cotta,paçoca,pacoca,doce de leite,dulce de leche,cocada,quindim,churros,churro,romeu e julieta,goiabada,sweet treat,pavê,pave,petit gateau,profiterole,trufa,truffle"),
    ("sorvete", "Sorvete", "doce", "sorvete,ice cream,gelato,sorveteria,picole,popsicle,milk shake,milkshake,sundae,casquinha,cone,acai,açai,frozen yogurt,iogurte gelado,sorbet,sorbete,paleta mexicana,helado"),
    ("chocolate", "Chocolate", "doce", "chocolate,cacau,cocoa,cacao,bombom,praline,pralines,barra de chocolate,chocolate bar,chocolate quente,hot chocolate,nutella,candy,bala,doce de festa,jujuba,gummy,pirulito,lollipop,algodao doce,cotton candy,caramelo,caramel,marshmallow,chiclete,chewing gum"),
    ("bebida", "Bebidas", "comida", "bebida,drink,beverage,coquetel,cocktail,drinks,suco,juice,smoothie,vitamina,refrigerante,soda,limonada,lemonade,cerveja,beer,vinho,wine,champanhe,champagne,whisky,whiskey,drinque,mocktail,agua com gas,sparkling water,cha gelado,iced tea,energetico,energy drink,chopp,draft beer,caipirinha"),
    ("cafe", "Café e chá", "bebida", "cafe,coffee,cafezinho,espresso,cappuccino,capuccino,latte,latte art,cafeteria,coffee shop,graos de cafe,coffee beans,xicara de cafe,coffee cup,mocha,macchiato,cha,tea,cha verde,green tea,matcha,chai,bule,teapot,infusao,infusion,tea time,cha da tarde,afternoon tea,coador,french press"),
    ("fruta_legume", "Frutas e legumes", "comida", "fruta e legume,fruit and vegetable"),
    ("frutas", "Frutas", "fruta_legume", "fruta,fruit,frutas,maca,apple,banana,morango,strawberry,uva,grape,melancia,watermelon,abacaxi,pineapple,manga fruta,mango,limao,lemon,lime,oranges,tangerina,tangerine,mexerica,pera,pear,pessego,peach,cereja,cherry,mirtilo,blueberry,framboesa,raspberry,amora,blackberry,kiwi,mamao,papaya,coco,coconut,abacate,avocado,goiaba,guava,maracuja,passion fruit,figo,fig,romã,pomegranate,laranjas,fruit basket,cesta de frutas,fruta tropical,tropical fruit,ameixa,plum,damasco,apricot,jabuticaba,caju,cashew fruit,pitaya,dragon fruit,carambola,star fruit,lichia,lychee"),
    ("legumes", "Legumes e verduras", "fruta_legume", "legume,vegetable,vegetables,verdura,cenoura,carrot,batata,potato,cebola,onion,alho,garlic,abobora,pumpkin,brocolis,broccoli,couve,kale,couve flor,cauliflower,milho,corn,pimentao,bell pepper,pimenta,chili pepper,berinjela,eggplant,abobrinha,zucchini,beterraba,beet,espinafre,spinach,ervilha,peas,feijao,beans,lentilha,lentil,grao de bico,chickpea,cogumelo,mushroom,champignon,rabanete,radish,mandioca,cassava,inhame,yam,quiabo,okra,horta,vegetable garden,hortalica,ervas,herbs,manjericao,basil,salsinha,parsley,coentro,cilantro,hortela,mint,alecrim,rosemary,tempero,seasoning,especiaria,spice,spices,temperos"),
    ("padaria", "Pão e café da manhã", "comida", "pao,bread,padaria,bakery,baguete,baguette,pao frances,french bread,pao de forma,sliced bread,torrada,toast,cafe da manha,breakfast,brunch,ovo,egg,ovos,eggs,omelete,omelette,mingau,porridge,aveia,oatmeal,granola,cereal,iogurte,yogurt,manteiga,butter,geleia,jam,mel,honey,queijo,cheese,tabua de frios,cheese board,charcuterie,fondue,leite,milk,pao integral,whole bread,panificadora,massa de pao,dough,sourdough,fermentacao natural,rosca,bagel,pretzel"),

    # ====================================================== TECNOLOGIA
    ("tecnologia", "Tecnologia", None, "tecnologia,technology,tech,eletronico,electronic,electronics,digital,gadget,inovacao,innovation,software,hardware,programacao,programming,codigo,code,internet,rede,network,inteligencia artificial,artificial intelligence,ai,machine learning,dados,data,nuvem de dados,cloud computing,ciber,cyber,startup,futurista,futuristic"),
    ("dispositivo", "Dispositivos", "tecnologia", "dispositivo,device"),
    ("computador", "Computador e notebook", "dispositivo", "computador,computer,pc,desktop,notebook,laptop,macbook,monitor,tela de computador,computer screen,teclado,keyboard,mouse de computador,computer mouse,setup,workstation,gamer pc,all in one,tablet,ipad,workspace,home office,mesa de trabalho,desk setup,imac,chromebook,impressora,printer,scanner,webcam"),
    ("celular", "Celular", "dispositivo", "celular,smartphone,phone,telefone,mobile phone,cell phone,iphone,android,aparelho celular,telefone celular,mobile,smartwatch,relogio inteligente,apple watch,wearable,vestivel,telefone antigo,old phone,orelhao,payphone,tela de celular,phone screen,app,aplicativo"),
    ("camera", "Câmera e foto", "dispositivo", "camera,camera fotografica,dslr,mirrorless,lente,lens,tripe,tripod,gopro,action camera,filmadora,camcorder,camera de video,video camera,polaroid,camera instantanea,instant camera,camera antiga,vintage camera,flash,projetor,projector,cinema,filme,film,clapperboard,claquete,cinegrafista,cameraman,fotografando,taking photo"),
    ("fones", "Fones e áudio", "dispositivo", "fones de ouvido,headphones,fone de ouvido,earphones,earbuds,airpods,headset,caixa de som,speaker,alto falante,loudspeaker,microfone,microphone,mic,vinil,vinyl,toca discos,turntable,radio,rádio,amplificador,amplifier,mesa de som,mixer,mixing console,home theater,soundbar,estudio de gravacao,recording studio,podcast"),
    ("maquina_autonoma", "Robôs e drones", "tecnologia", "robo e drone,robots and drones"),
    ("robo", "Robô", "maquina_autonoma", "robo,robot,robos,robots,android humanoide,humanoid,ciborgue,cyborg,automacao,automation,braco robotico,robotic arm,robotica,robotics,androide,mecha,exoesqueleto,exoskeleton,assistente virtual,chatbot,inteligencia artificial robo,bot,ai robot,rover,mars rover,robo aspirador,robot vacuum,automato,automaton"),
    ("drone", "Drone", "maquina_autonoma", "drone,drones,quadricoptero,quadcopter,veiculo aereo nao tripulado,uav,multirotor,fpv,drone dji,dji,dronie,vista de drone,drone view,aerial view,visao aerea,aerial photography,fotografia aerea,topo visto de cima,from above,top view"),
    ("infra_tech", "Infraestrutura e circuitos", "tecnologia", "infraestrutura tecnologica,tech infrastructure"),
    ("circuito", "Placa de circuito", "infra_tech", "circuito,circuit,placa de circuito,circuit board,pcb,chip,microchip,processador,processor,cpu,gpu,placa de video,graphics card,memoria ram,ram,semicondutor,semiconductor,transistor,eletronica,electronics board,arduino,raspberry pi,solda,soldering,componente eletronico,electronic component,motherboard,placa mae,resistor,capacitor,fiacao,wiring,cabo,cable,fibra otica,fiber optic,conector,connector"),
    ("servidor", "Servidores e redes", "infra_tech", "servidor,server,sala de servidores,server room,data center,datacenter,rack,rede de dados,network cables,switch de rede,network switch,roteador,router,wifi,wi fi,antena de celular,cell tower,nuvem computacional,cloud server,hospedagem,hosting,banco de dados,database,blockchain,criptomoeda,cryptocurrency,bitcoin,mineracao de bitcoin,mining rig,cybersecurity,seguranca digital,hacker,hacking,codigo na tela,code on screen,terminal,linha de comando,command line"),
    ("satelite", "Satélite", "infra_tech", "satelite,satellite,antena parabolica,satellite dish,gps,painel solar,solar panel,energia solar,solar energy,turbina eolica,wind turbine,energia eolica,wind energy,usina,power plant,usina nuclear,nuclear plant,linha de transmissao,power line,poste de luz,utility pole,bateria,battery,carregador,charger,energia renovavel,renewable energy,hidreletrica,hydroelectric,reator,reactor,gerador,generator,radar"),

    # ====================================================== ESPORTES
    ("esportes", "Esportes", None, "esporte,sport,sports,atleta,athlete,atletismo,athletics,competicao,competition,campeonato,championship,olimpiadas,olympics,olympic games,torneio,tournament,treino,workout,training,academia,gym,fitness,musculacao,weightlifting,crossfit,yoga,pilates,maratona,marathon,medalha,medal,podio,podium,jogador,player,time,team,esportista"),
    ("esporte_bola", "Esportes de bola", "esportes", "esporte de bola,ball sport"),
    ("futebol", "Futebol", "esporte_bola", "futebol,soccer,football match,gol,goal,campo de futebol,football field,soccer field,chuteira,cleats,bola de futebol,soccer ball,torcida,fans,penalti,penalty kick,copa do mundo,world cup,futsal,futebol de salao,libertadores,champions league,brasileirao,premier league,la liga,messi,cristiano ronaldo,neymar,pele,maradona,escanteio,corner kick,atacante,striker,goleiro,goalkeeper,partida de futebol,football game,football team,time de futebol,soccer team,soccer player,jogador de futebol"),
    ("basquete", "Basquete", "esporte_bola", "basquete,basketball,cesta,basket,nba,quadra de basquete,basketball court,enterrada,slam dunk,bola de basquete,basketball hoop,aro,hoop,street basketball,wnba,arremesso,jump shot,jogador de basquete,basketball player"),
    ("volei", "Vôlei", "esporte_bola", "volei,volleyball,voleibol,volei de praia,beach volleyball,rede de volei,volleyball net,saque,serve,cortada,spike,libero,bola de volei,volleyball ball,handebol,handball,rugby,futebol americano,american football,nfl,touchdown,beisebol,baseball,mlb,softbol,softball,hoquei,hockey,ice hockey,hoquei no gelo,golfe,golf,tacos de golfe,golf course,campo de golfe,polo,polo aquatico,water polo,criquete,cricket sport,badminton,peteca"),
    ("tenis", "Tênis", "esporte_bola", "tenis esporte,tennis,tenis de mesa,table tennis,ping pong,raquete,racket,racquet,quadra de tenis,tennis court,wimbledon,roland garros,grand slam,saque de tenis,tennis serve,bolinha de tenis,tennis ball,padel,squash,tenista,tennis player,us open,australian open,djokovic,nadal,federer,serena williams,guga,tennis match"),
    ("esporte_agua", "Esportes aquáticos", "esportes", "esporte aquatico,water sport"),
    ("surfe", "Surfe", "esporte_agua", "surfe,surf,surfista,surfer,prancha de surfe,surfboard,onda gigante,big wave,tubo,barrel,bodyboard,stand up paddle,sup,remo,rowing,wakeboard,kitesurf,kitesurfing,skimboard,surf trip,longboard surf,windsurfe,esporte de onda,wave riding,pipeline,teahupoo,nazare,maresias,saquarema,fernando de noronha surf,paddle surf,canoagem,canoeing,rafting,bote de borracha,whitewater"),
    ("natacao", "Natação", "esporte_agua", "natacao,swimming,nado,swim,nadador,swimmer,piscina,swimming pool,pool,mergulho,diving,scuba diving,snorkel,snorkeling,mergulhador,diver,nado sincronizado,synchronized swimming,saltos ornamentais,platform diving,trampolim,springboard,maiô,swimsuit,touca,swim cap,oculos de natacao,goggles,raia de natacao,swim lane,crawl,borboleta nado,butterfly stroke,medley,triatlo aquatico,aquathlon,hidroginastica,aqua aerobics,mergulho livre,freediving,apneia,spearfishing"),
    ("esporte_radical", "Esportes radicais", "esportes", "esporte radical,extreme sport,aventura,adventure,radical"),
    ("skate", "Skate", "esporte_radical", "skate,skateboard,skatista,skater,skate park,pista de skate,manobra,trick,kickflip,ollie,half pipe,halfpipe,longboard,patins,roller skates,inline skates,patinacao,roller skating,patinete,scooter de rua,bmx freestyle,parkour,freerun,breakdance de rua,snowboard,snowboarding,wingsuit,paraquedismo,skydiving,parapente,paragliding,bungee jump,bungee jumping,base jumping,slackline,tirolesa,zip line,trilha radical,downhill,motocross radical"),
    ("esqui", "Esqui", "esporte_radical", "esqui,ski,skiing,esquiador,skier,pista de esqui,ski slope,estacao de esqui,ski resort,esqui alpino,alpine skiing,esqui cross country,cross country skiing,trenó,sled,sledding,luge,bobsled,bobsleigh,patinacao no gelo,ice skating,patinador,ice skater,curling,biatlo,biathlon,salto de esqui,ski jumping,trilha na neve,snowshoe,esqui aquatico,water ski,esqui nautico,monoski,telesqui,ski lift,teleferico de esqui,chalet de esqui,apres ski"),
    ("escalada", "Escalada", "esporte_radical", "escalada,climbing,rock climbing,escalador,climber,alpinismo,mountaineering,alpinista,mountaineer,montanhismo,via ferrata,boulder,bouldering,parede de escalada,climbing wall,corda de escalada,climbing rope,mosquetao,carabiner,capacete de escalada,escalar,climb,trekking,hiking,caminhada na montanha,mountain hiking,trilha de montanha,mountain trail,camping,acampamento,tenda,tent,mochila,backpack,mochileiro,backpacker,expedição,expedition,everest,monte everest,kilimanjaro,aconcagua,pico da neblina"),
    ("atletismo", "Atletismo e corrida", "esportes", "atletismo e corrida,athletics and running"),
    ("corrida", "Corrida", "atletismo", "corrida,running,corredor,runner,maratona de rua,road race,sprint,100 metros,100 meters,pista de atletismo,running track,velocista,sprinter,meia maratona,half marathon,corrida de rua,street run,jogging,cooper,trote,tenis de corrida,running shoes,corrida de obstaculos,hurdles,salto em altura,high jump,salto com vara,pole vault,arremesso de peso,shot put,lancamento de dardo,javelin,revezamento,relay race,triatlo,triathlon,ultramaratona,ultramarathon,trail running,corrida de montanha,cross country running,corrida noturna,night run,linha de chegada,finish line,largada,starting line,cronometro,stopwatch"),
    ("ciclismo", "Ciclismo", "atletismo", "ciclismo,cycling,tour de france,pedalar,pedaling,pedal,peloton,volta ciclistica,cycling race,ciclismo de estrada,road cycling,ciclismo de montanha,mountain biking,velodromo,velodrome,ciclismo de pista,track cycling,cicloturismo,bike touring,ciclovia,bike lane,cycle path,capacete de ciclismo,cycling helmet,spinning,bicicleta ergometrica,exercise bike,contrarrelogio,time trial,giro d italia,vuelta"),
    ("ginastica", "Ginástica", "atletismo", "ginastica,gymnastics,ginasta,gymnast,ginastica artistica,artistic gymnastics,ginastica ritmica,rhythmic gymnastics,barras assimetricas,uneven bars,trave,balance beam,argolas,rings,cavalo com alcas,pommel horse,solo,floor exercise,salto sobre o cavalo,vault,trampolim acrobatico,trampoline,acrobacia,acrobatics,acrobata,acrobat,contorcionista,contortionist,alongamento,stretching,flexibilidade,flexibility,parada de maos,handstand,estrela,cartwheel,mortal,flip,backflip,ginastica aerobica,aerobics,zumba,step aerobics,dança aerobica"),
    ("combate", "Lutas", "esportes", "luta,fight,lutas,combat sport,artes marciais,martial arts"),
    ("boxe", "Boxe", "combate", "boxe,boxing,boxeador,boxer,luvas de boxe,boxing gloves,ringue,boxing ring,nocaute,knockout,ko,mma,ufc,jiu jitsu,jiu-jitsu,judo,judô,karate,karatê,taekwondo,muay thai,kickboxing,capoeira,luta livre,wrestling,wrestler,lutador,fighter,sumo,esgrima,fencing,kung fu,aikido,krav maga,arte marcial,faixa preta,black belt,kimono,quimono,dojo,tatame,octagono,octagon,combate,saco de pancada,punching bag,sparring,treino de luta,fight training,campeao de boxe,boxing champion"),
    ("estadio", "Estádio e arena", "esportes", "estadio,stadium,arena,ginasio,gymnasium,maracana,camp nou,wembley,old trafford,estadio olimpico,olympic stadium,arquibancada,stands,bleachers,gramado,pitch,turf,quadra,court,quadra esportiva,sports court,pista,track,autodromo,racetrack,circuito de corrida,race circuit,velodromo estadio,hipodromo,racecourse,ginasio de esportes,sports hall,complexo esportivo,sports complex,campo esportivo,sports field,tribuna,grandstand,vestiario,locker room,placar,scoreboard,holofotes do estadio,stadium lights,estadio lotado,packed stadium,estadio vazio,empty stadium,arena de shows,concert arena"),
    ("automobilismo", "Automobilismo", "esportes", "automobilismo,motorsport,motor sport,formula 1 corrida,f1 race,grande premio,gp,corrida de carros,car racing,piloto,driver,pit stop,box de corrida,pit lane,pole position,podio de formula 1,motogp,superbike,speedway,drift,drifting,corrida de moto,motorcycle racing,rally dakar,dakar,kart racing,corrida de kart,stock car brasil,endurance,24 horas de le mans,le mans,indianapolis 500,monaco gp,silverstone,interlagos,suzuka,monza,spa francorchamps"),

    # ====================================================== MODA
    ("moda", "Moda e beleza", None, "moda,fashion,estilo,style,look,outfit,tendencia,trend,passarela,runway,desfile,fashion show,estilista,fashion designer,grife,brand fashion,elegante,elegant,streetwear,vintage fashion,roupa vintage,haute couture,alta costura,editorial de moda,fashion editorial,lookbook,vitrine de moda,fashion week,semana de moda,boutique,brechó,brecho,thrift,second hand,secondhand,moda sustentavel,sustainable fashion"),
    ("roupa", "Roupas", "moda", "roupa,clothes,clothing,vestuario,wardrobe,apparel"),
    ("vestido", "Vestido", "roupa", "vestido,dress,gown,vestido de festa,evening gown,vestido de noiva,wedding dress,saia,skirt,blusa,blouse,camisa,shirt,camiseta,t shirt,tshirt,jaqueta,jacket,casaco,coat,sobretudo,overcoat,terno,suit,blazer,gravata,tie,necktie,calca,pants,trousers,jeans,shorts,bermuda,moletom,hoodie,sweatshirt,suéter,sueter,sweater,cardigan,biquini,bikini,sunga,swim trunks,lingerie,pijama,pajamas,uniforme,uniform,macacao,jumpsuit,colete,vest,agasalho,tracksuit,legging,leggings,roupa de academia,gym wear,roupa de inverno,winter clothes,roupa de verão,summer clothes,echarpe,scarf,cachecol,luvas,gloves,meia,sock,socks"),
    ("traje_tipico", "Traje típico", "roupa", "traje tipico,traditional dress,traditional clothing,trajes tipicos,folk costume,quimono tradicional,kimono,hanbok,sari,kilt,poncho,sombrero,dirndl,fantasia,costume,cosplay,carnaval,carnival costume,fantasia de carnaval,roupa tradicional,tribal clothing,vestimenta indigena,indigenous clothing,cocar,headdress,kaftan,abaya,hijab,turbante,turban,cheongsam,qipao,ao dai,lederhosen,traje de gala,formal wear,smoking,tuxedo,traje de baile,ball gown,vestimenta regional,regional costume,baiana,roupa de capoeira,gaucho,traje gaucho,bombacha,vaqueiro,cowboy outfit,chapeu de cowboy,cowboy hat,bota de cowboy,cowboy boots,fantasia de halloween,halloween costume,roupa medieval,medieval clothing,armadura,armor,traje de samurai,samurai armor,traje de viking,viking costume,roupa de epoca,period costume,vestuario de epoca,historical clothing"),
    ("modelo_moda", "Modelo de moda", "roupa", "modelo de moda,fashion model,modelo,model fashion,ensaio de moda,fashion shoot,sessao de fotos de moda,fashion photoshoot,pose de modelo,model pose,supermodelo,supermodel,manequim,mannequin,top model,desfile de moda,fashion runway,catwalk,passarela de moda,editorial,magazine cover,capa de revista,revista de moda,fashion magazine,vogue,elle,harpers bazaar,estilo de rua,street style,influencer,influenciadora,fashionista,blogueira,blogger,look do dia,outfit of the day,ootd,moda masculina,menswear,moda feminina,womenswear,moda infantil,kids fashion,plus size,moda plus size,moda praia,beachwear,moda fitness,activewear,moda casual,casual wear,moda executiva,business attire,moda festa,party wear,moda noiva,bridal fashion"),
    ("acessorio", "Acessórios", "moda", "acessorio,accessory,accessories,acessorios de moda,fashion accessories"),
    ("sapato", "Sapatos", "acessorio", "sapato,shoe,sapatos,shoes,tenis calcado,sneaker,sneakers,salto alto,high heels,heels,sandalia,sandal,bota,boot,chinelo,flip flop,sapatilha,ballet flat,mocassim,loafer,scarpin,pump,rasteirinha,slide,calcado,footwear,tamanco,clog,oxford,sapato social,dress shoe,tenis esportivo,athletic shoe,all star,converse,nike,adidas,air jordan,puma shoe,vans,crocs,havaianas,botina,ankle boot,coturno,combat boot,bota de chuva,rain boot,galocha,wellington,pantufa,slipper,sapateiro,cobbler,loja de sapatos,shoe store,cadarco,shoelace,sola,sole,palmilha,insole"),
    ("joia", "Joias", "acessorio", "joia,jewelry,jewellery,joias,jewel,anel,ring,colar,necklace,pulseira,bracelet,brinco,earring,alianca,wedding ring,relogio,watch,wristwatch,diamante,diamond,ouro,gold,prata,silver,perola,pearl,esmeralda,emerald,rubi,ruby,safira,sapphire,gema,gemstone,pedra preciosa,precious stone,pingente,pendant,corrente,chain,tiara,coroa,crown,joalheria,jewelry store,bijuteria,costume jewelry,broche,brooch,piercing,tornozeleira,anklet,cordao,cord,medalha de ouro,gold medal,amuleto,amulet,talisma,talisman,relicario,locket,camafeu,cameo,anel de noivado,engagement ring"),
    ("bolsa", "Bolsas e malas", "acessorio", "bolsa,bag,handbag,mochila escolar,school bag,carteira,wallet,clutch,pochete,fanny pack,bolsa de grife,designer bag,louis vuitton,gucci,chanel,hermes,prada,mala,suitcase,luggage,mala de viagem,travel bag,maleta,briefcase,valise,bagagem,baggage,sacola,tote bag,shopping bag,sacola de compras,bolsa de praia,beach bag,bolsa de palha,straw bag,necessaire,toiletry bag,estojo,pencil case,porta cartoes,card holder,porta moedas,coin purse,bolsa transversal,crossbody bag,bolsa tiracolo,shoulder bag,bolsa de couro,leather bag,couro,leather,cinto,belt,fivela,buckle,mochila de viagem,travel backpack,bolsa termica,cooler bag,bolsa maternidade,diaper bag,bolsa esportiva,gym bag,bolsa de mao,hand bag"),
    ("chapeu", "Chapéus e óculos", "acessorio", "chapeu,hat,bone,cap,baseball cap,gorro,beanie,boina,beret,fedora,panama,chapeu de palha,straw hat,chapeu de praia,sun hat,viseira,visor,touca,bonnet,capacete,helmet,turbante moda,fashion turban,lenço,bandana,headscarf,tiara de cabelo,headband,presilha,hair clip,laco,bow,xuxinha,scrunchie,oculos,glasses,oculos de sol,sunglasses,armacao,frames,lentes de contato,contact lenses,oculos de grau,eyeglasses,monoculo,monocle,oculos escuros,shades,aviador,aviator,wayfarer,oculos redondo,round glasses,oculos gatinho,cat eye glasses,oculos esportivo,sports glasses"),
    ("beleza", "Beleza e cabelo", "moda", "beleza,beauty,cosmeticos,cosmetics,skincare,cuidados com a pele,pele,skin,hidratante,moisturizer,perfume,fragrance,esmalte,nail polish,manicure,unhas,nails,nail art,pedicure,spa,massagem,massage,salao de beleza,beauty salon,barbearia,barbershop,barba,beard,bigode,mustache,tatuagem,tattoo,tatuador,tattoo artist,body art,piercing de corpo,body piercing,depilacao,waxing,estetica,aesthetics,tratamento facial,facial treatment,mascara facial,face mask,protetor solar,sunscreen,bronzeado,tan,bronzeamento,tanning,antes e depois,before and after,transformacao,makeover,maquiador,makeup artist,tutorial de maquiagem,makeup tutorial"),
    ("maquiagem", "Maquiagem", "beleza", "maquiagem,makeup,make up,batom,lipstick,sombra,eyeshadow,rimel,mascara de cilios,mascara,delineador,eyeliner,base,foundation,po compacto,powder,blush,iluminador,highlighter,corretivo,concealer,gloss,brilho labial,lip gloss,paleta de sombras,eyeshadow palette,pincel de maquiagem,makeup brush,esponja,beauty blender,cilios postiços,false lashes,sobrancelha,eyebrow,design de sobrancelha,brow design,contorno,contour,make de festa,party makeup,make natural,natural makeup,make artistica,artistic makeup,make de noiva,bridal makeup,make colorida,colorful makeup,glitter,brilho,cosmetico,cosmetic,paleta,palette,kit de maquiagem,makeup kit,demaquilante,makeup remover,primer,fixador,setting spray"),
    ("cabelo", "Cabelo e penteado", "beleza", "cabelo,hair,penteado,hairstyle,corte de cabelo,haircut,cabeleireiro,hairdresser,hair stylist,trança,braid,coque,bun,rabo de cavalo,ponytail,cabelo cacheado,curly hair,cabelo liso,straight hair,cabelo crespo,coily hair,cabelo black power,afro,cabelo loiro,blonde hair,cabelo ruivo,red hair,cabelo preto,black hair,cabelo castanho,brown hair,cabelo colorido,colorful hair,cabelo rosa,pink hair,cabelo azul,blue hair,mechas,highlights,luzes,tintura,hair dye,coloracao,hair coloring,progressiva,keratin treatment,escova,blow dry,chapinha,flat iron,babyliss,curling iron,secador,hair dryer,laquê,hairspray,gel de cabelo,hair gel,shampoo,condicionador,conditioner,mascara capilar,hair mask,tratamento capilar,hair treatment,peruca,wig,aplique,hair extension,megahair,careca,bald,cabelo curto,short hair,cabelo longo,long hair,franja,bangs,fringe,undercut,moicano,mohawk,topete,pompadour,dreadlocks,dread,tranças nago,cornrows,box braids,tranças box"),

    # ====================================================== PESSOAS
    ("pessoas", "Pessoas", None, "pessoa,person,pessoas,people,humano,human,gente,individuo,individual,social,sociedade,society,comunidade,community,cultura,culture,tradicao,tradition,religiao,religion,estilo de vida,lifestyle,rotina,routine,cotidiano,everyday life,dia a dia,daily life,vida real,real life,historia de vida,life story,documental,documentary"),
    ("retrato", "Retrato", "pessoas", "retrato,portrait,rosto,face,selfie,autorretrato,self portrait,close up,closeup,olhar,gaze,sorriso,smile,expressao,expression,emocao,emotion,olhos,eyes,headshot,foto de perfil,profile picture,perfil,profile,homem,man,mulher,woman,garoto,boy,garota,girl,jovem,young,idoso,elderly,velho,old man,velha,old woman,avo,grandmother,avô,grandfather,adulto,adult,adolescente,teenager,teen,pessoa idosa,senior,pessoa jovem,young person,barbudo,bearded man,ruiva,redhead,loira,blonde woman,morena,brunette,rapaz,lad,moça,lass,senhor,gentleman,senhora,lady,cavalheiro,sir,dama,dame,figura humana,human figure,silhueta humana,human silhouette,perfil de rosto,face profile,lagrima,tear,choro,crying,riso,laughter,gargalhada,laughing,sorrindo,smiling,pensativo,pensive,serio,serious,feliz,happy,triste,sad,surpreso,surprised,bravo,angry,assustado,scared,emocionado,excited,cansado,tired,sonolento,sleepy,apaixonado,in love"),
    ("grupo", "Grupos e multidão", "pessoas", "grupo de pessoas,group of people,grupo,group,multidao,crowd,aglomeracao,gathering,manifestacao,protest,passeata,march,protesto,demonstration,comicio,rally political,plateia,audience,publico,spectators,espectadores,torcedores,supporters,fila,queue,line of people,multidao na rua,street crowd,pessoas na rua,people on street,passantes,passersby,pedestres,pedestrians,turistas,tourists,populacao,population,povo,folk,comunidade local,local community,equipe,crew,time de trabalho,work team,colegas,colleagues,amigos,friends,amigas,girlfriends,turma,gang,bando,band of people,galera,squad,parceiros,partners,casal,couple,namorados,sweethearts,noivos,fiances,namoro,dating,romance,beijo,kiss,abraço,abraco,hug,mãos dadas,mao dada,holding hands,apaixonados,lovers,familia,family,pais e filhos,parents and children,mae,mother,pai,father,filho,son,filha,daughter,irmaos,siblings,irmao,brother,irma,sister,avos e netos,grandparents and grandchildren,reuniao de familia,family reunion,familia feliz,happy family,retrato de familia,family portrait,foto de familia,family photo,tios,uncles and aunts,primos,cousins,sobrinhos,nephews and nieces,casamento civil,civil wedding"),
    ("crianca", "Crianças", "pessoas", "crianca,child,criancas,children,kid,kids,bebe,baby,bebes,babies,recem nascido,newborn,infantil,infant,menino,little boy,menina,little girl,garotinho,garotinha,pequeno,toddler,primeira infancia,early childhood,criancas brincando,children playing,brincadeira,play,brincar,brinquedos infantis,children toys,parquinho,playground,balanço,swing,escorregador,slide playground,gangorra,seesaw,pula pula,bounce house,amarelinha,hopscotch,pique esconde,hide and seek,pipa,kite,papagaio de papel,bolinha de gude,marbles,pião,spinning top,ioio,yo yo,boneca,doll,carrinho de brinquedo,toy car,bola de crianca,kids ball,casinha de boneca,dollhouse,lego,blocos de montar,building blocks,massinha,play dough,desenho de crianca,kids drawing,escola infantil,kindergarten,creche,daycare,sala de aula,classroom,aluno,student,professor,teacher,escolar,school,uniforme escolar,school uniform,volta as aulas,back to school,recreio,playtime,formatura infantil,children graduation,festa infantil,kids party,aniversario infantil,kids birthday,crianca sorrindo,smiling child,crianca chorando,crying child,bebe dormindo,sleeping baby,bebe engatinhando,crawling baby,primeiros passos,first steps,gravidez,pregnancy,gestante,pregnant woman,barriga,baby bump,ultrassom,ultrasound,cha de bebe,baby shower,cha revelacao,gender reveal,enxoval,layette,berço,crib,carrinho de bebe,stroller,mamadeira,baby bottle,fralda,diaper,chupeta,pacifier,amamentacao,breastfeeding,adolescencia,adolescence"),
    ("atividade", "Atividades", "pessoas", "atividade,activity"),
    ("danca", "Dança", "atividade", "danca,dance,dancing,dancando,dançando,dancarino,dancer,dancarina,dançarino,dancarinos,dancers,coreografia,choreography,ballet,balé,bale,bailarina,ballerina,balé clássico,classical ballet,hip hop dance,street dance,danca de rua,break,breakdance,breaking,b boy,b girl,salsa,samba,forro,forró,tango,valsa,waltz,flamenco,zumba danca,danca do ventre,belly dance,pole dance,danca contemporanea,contemporary dance,jazz dance,sapateado,tap dance,quadrilha,square dance,danca folclorica,folk dance,danca tipica,traditional dance,carnaval danca,carnival dance,passista,samba dancer,mestre sala,porta bandeira,baile,ball dance,baile funk,funk dance,pagode,axe,axé,frevo,maracatu,capoeira roda,bumba meu boi,ciranda,coco,jongo,catira,vanera,gauchesca,danca gaucha,dança de salão,ballroom dance,danca de salao,ballroom,gafieira,bolero dance,rumba,cha cha cha,mambo,merengue,bachata,kizomba,lambada,twist,disco dance,discoteca,disco,danca no palco,dancing on stage,performance de danca,dance performance,show de danca,dance show,festival de danca,dance festival,aula de danca,dance class,estudio de danca,dance studio,academia de danca,dance academy,trupe de danca,dance troupe,companhia de danca,dance company,grupo de danca,dance group,flash mob,tiktok dance,danca tiktok,desafio de danca,dance challenge,viral dance,danca viral,moves,passos de danca,dance moves,balada,club dancing,pista de danca,dance floor,dj,festival de musica dancando,rave,festa eletronica,edm,musica eletronica,electronic music,balada eletronica,night club,boate,nightclub,festa dancando,party dancing,pessoas dançando,people dancing,casal dançando,couple dancing,crianças dançando,kids dancing,dancing people"),
    ("musico", "Música e músicos", "atividade", "musico,musician,musica,music,banda,band,cantor,singer,cantora,vocalist,cantando,singing,show,concert,concerto,festival de musica,music festival,palco,stage,microfone no palco,stage microphone,guitarra,guitar,violao,acoustic guitar,baixo,bass guitar,bateria,drums,drummer,baterista,teclado musical,keyboard instrument,piano,pianista,pianist,violino,violin,violinista,violinist,violoncelo,cello,flauta,flute,saxofone,saxophone,trompete,trumpet,trombone,clarinete,clarinet,harpa,harp,acordeon,accordion,sanfona,gaita,harmonica,gaita de fole,bagpipes,ukulele,cavaquinho,banjo,bandolim,mandolin,sitar,tambor,drum,percussao,percussion,pandeiro,tambourine,atabaque,conga,bongo,djembe,xilofone,xylophone,triangulo,triangle,orquestra,orchestra,maestro,conductor,coral,choir,coro,chorus,opera,ópera,musical,teatro musical,musical theatre,rock,rock band,banda de rock,metal,heavy metal,punk,pop,pop star,rap,rapper,hip hop,mc,trap,funk,sertanejo,sertanejo dupla,mpb,bossa nova,samba musica,pagode musica,forro musica,reggae,jazz,jazz band,blues,country,country music,folk music,classica,classical music,erudita,gospel,musica gospel,louvor,worship,rave musica,eletronica musica,dj set,dj,vinil dj,turntablist,sound system,show ao vivo,live show,ao vivo,live,ensaio,rehearsal,estudio de musica,music studio,gravacao,recording,compositor,composer,letra de musica,lyrics,partitura,sheet music,notas musicais,musical notes,clave de sol,treble clef,instrumento musical,musical instrument,aula de musica,music lesson,escola de musica,music school,roda de samba,samba circle,roda de choro,choro,seresta,serenata,serenade,trio eletrico,carnaval musica,bloco de carnaval,carnival block,bateria de escola de samba,samba school drums,festival de jazz,jazz festival,rock in rio,coachella,glastonbury,lollapalooza,tomorrowland,woodstock,show de rock,rock concert,show de pop,pop concert,show sertanejo,sertanejo show,turne,tour,fa clube,fan club,fas,fans,autografo,autograph,camarim,backstage,ingresso,ticket,fila do show,concert queue,plateia do show,concert audience,mao pro alto,hands up,celular no show,phone in concert,isqueiro no show,lighter in concert,luzes do show,concert lights,fumaca do palco,stage smoke,confete,confetti,fogos no palco,stage fireworks,pirotecnia,pyrotechnics"),
    ("trabalhador", "Trabalho e profissões", "atividade", "trabalhador,worker,trabalho,work,profissao,profession,profissional,professional,emprego,job,ocupacao,occupation,operario,laborer,construcao civil,construction work,pedreiro,bricklayer,mason,carpinteiro,carpenter,marceneiro,joiner,eletricista,electrician,encanador,plumber,mecanico,mechanic,soldador,welder,pintor de parede,house painter,jardineiro,gardener,agricultor,farmer,fazendeiro,rancher,pescador,fisherman,minerador,miner,metalurgico,metalworker,padeiro,baker,cozinheiro,cook,confeiteiro,pastry chef,garcom,waiter,garconete,waitress,barista,bartender,atendente,attendant,caixa,cashier,vendedor de loja,salesperson,comerciante,merchant,feirante,market vendor,ambulante,street vendor,motorista,driver professional,taxista,taxi driver,caminhoneiro,truck driver,piloto de aviao,airline pilot,comissario,flight attendant,marinheiro,sailor,capitao,captain,soldado,soldier,militar,military,policial,police officer,bombeiro,firefighter,guarda,guard,seguranca,security guard,medico,doctor,enfermeira,nurse,dentista,dentist,cirurgiao,surgeon,paciente,patient,hospital trabalho,hospital work,professor trabalho,teacher work,advogado,lawyer,juiz,judge,engenheiro,engineer,arquiteto,architect,cientista,scientist,pesquisador,researcher,programador,programmer,desenvolvedor,developer,designer,designer profissional,jornalista,journalist,reporter,fotografo profissional,professional photographer,escritor,writer,autor,author,artista profissional,professional artist,ator,actor,atriz,actress,diretor,director,produtor,producer,empresario,businessman,empresaria,businesswoman,executivo,executive,ceo,gerente,manager,funcionario,employee,estagiario,intern,reuniao de trabalho,business meeting,escritorio de trabalho,office work,home office trabalho,remote work,trabalho remoto,coworking,startup trabalho,fabrica trabalho,factory work,linha de producao,assembly line,industria,industry,obra,building site,canteiro de obras,construction site,andaime,scaffolding,capacete de seguranca,hard hat,uniforme de trabalho,work uniform,ferramenta,tool,ferramentas,tools,martelo,hammer,chave de fenda,screwdriver,serra,saw,furadeira,drill,alicate,pliers,oficina,workshop,garagem de trabalho,garage workshop,mao de obra,labor,sindicato,union,greve,strike,desemprego,unemployment,aposentadoria,retirement,aposentado,retiree,salario,salary,pagamento,payment,dia do trabalho,labor day"),
    ("festa", "Festas e eventos", "pessoas", "festa,party,festas,parties,evento,event,celebracao,celebration,comemoracao,comemorar,celebrate,festividade,festivity,festival,festival popular,folia,revelry,confraternizacao,get together,reuniao social,social gathering,happy hour,churrasco de amigos,friends bbq,festa de rua,street party,carnaval,carnival,bloco,festa junina,june festival,sao joao,saint john festival,quadrilha junina,festa de sao joao,festa do peao,rodeo,rodeio,festa da uva,grape festival,oktoberfest,festa de natal,christmas party,natal,christmas,arvore de natal,christmas tree,papai noel,santa claus,presépio,presepio,nativity,ano novo,new year,reveillon,new years eve,fogos de artificio,fireworks,pascoa,easter,coelho da pascoa,easter bunny,ovo de pascoa,easter egg,halloween,dia das bruxas,bruxa,witch,abobora de halloween,jack o lantern,dia dos namorados,valentines day,dia das maes,mothers day,dia dos pais,fathers day,dia das criancas,childrens day,aniversario,birthday,parabens,congratulations,feliz aniversario,happy birthday,velinhas,candles,bolo de velas,cake candles,sopro das velas,blowing candles,surpresa,surprise,presente,gift,present,embrulho,gift wrapping,pacote de presente,gift box,laco de presente,gift ribbon,cartao,card,cartao de aniversario,birthday card,convite,invitation,convidados,guests,anfitriao,host,decoracao de festa,party decoration,mesa de festa,party table,lembrancinha,party favor,fantasia de festa,party costume,chapeu de festa,party hat,apito de festa,party horn,serpentina,streamer,confete de festa,party confetti,pinhata,pinata,pegar o buque,bouquet toss,brinde,toast,brindando,cheering,taça,wine glass,champanhe festa,party champagne,dj de festa,party dj,musica de festa,party music,pista de dança de festa,party dance floor,casamento,wedding,noiva,bride,noivo,groom,madrinha,bridesmaid,padrinho,groomsman,altar de casamento,wedding altar,cerimonia,ceremony,cerimonia de casamento,wedding ceremony,festa de casamento,wedding party,recepção de casamento,wedding reception,bolo de casamento,wedding cake,aliança de casamento,wedding band,lua de mel,honeymoon,vestido de noiva festa,bridal gown,buque de noiva,bridal bouquet,veu de noiva,veil,casamento na praia,beach wedding,casamento no campo,country wedding,casamento civil festa,civil ceremony,bodas,anniversary,bodas de ouro,golden anniversary,formatura,graduation,beca,gown graduation,capelo,graduation cap,diploma,formando,graduate,baile de formatura,prom,baile de debutantes,debutante ball,quinceanera,festa de 15 anos,sweet sixteen,cha de panela,bridal shower,despedida de solteiro,bachelor party,despedida de solteira,bachelorette party,cha de bebe festa,baby shower party,cha de casa nova,housewarming,inauguracao,inauguration,grand opening,lancamento,launch,coquetel de lancamento,launch party,gala,baile de gala,gala ball,tapete vermelho,red carpet,premiere,estreia,premio,award,cerimonia de premiacao,award ceremony,oscar,grammy,emmy,cannes,festival de cinema,film festival,desfile de carnaval,carnival parade,escola de samba,samba school,sambodromo,sambadrome,carro alegorico,float,parada,parade,parada do orgulho,pride parade,orgulho lgbt,lgbt pride,bandeira arco iris,rainbow flag,parada militar,military parade,desfile civico,civic parade,sete de setembro,independence day,dia da independencia,4 de julho,fourth of july,thanksgiving,acao de gracas,dia de graças,festa de colheita,harvest festival,festa da primavera,spring festival,ano novo chines,chinese new year,lanterna,lantern,festival das lanternas,lantern festival,diwali,holi,festival das cores,festival of colors,carnaval de veneza,venice carnival,mascara de carnaval,carnival mask,mardi gras,dia dos mortos,day of the dead,la catrina,calavera,dia de muertos,festa de iemanja,iemanja festival,reveillon na praia,new year beach,fogueira,bonfire,fogueira de sao joao,saint john bonfire,balao,balloon,balloons,baloes,bexiga,balao de festa,party balloon,balao de gas,helium balloon,balao de aniversario,birthday balloon,arco de baloes,balloon arch,baloes coloridos,colorful balloons,balao metalizado,foil balloon,balao de gas helio,gas balloon,soltar baloes,balloon release,balao inflado,inflated balloon,baloes no ceu,balloons in sky,baloes flutuando,floating balloons,balao vermelho,red balloon,balao de coracao,heart balloon,balao de estrela,star balloon,balao de numero,number balloon,balao personalizado,custom balloon,decoracao de baloes,balloon decoration,baloes de festa,party balloons,festival de baloes,balloon festival"),
    ("balao", "Balões de festa", "festa",
     "balao,balloon,balloons,bexiga,balao de festa,party balloon,balao de gas,helium balloon,balao de aniversario,birthday balloon,arco de baloes,balloon arch,balao metalizado,foil balloon,soltar baloes,balloon release,balao inflado,inflated balloon,balao vermelho,red balloon,balao de coracao,heart balloon,decoracao de baloes,balloon decoration,festival de baloes"),
    ("casamento", "Casamento", "festa",
     "casamento,wedding,noiva,bride,noivo,groom,madrinha,bridesmaid,padrinho,groomsman,altar de casamento,wedding altar,cerimonia de casamento,wedding ceremony,festa de casamento,wedding party,bolo de casamento,wedding cake,lua de mel,honeymoon,buque de noiva,bridal bouquet,veu de noiva,veil,casamento na praia,beach wedding,alianca de casamento,wedding band,bodas"),
    # ====================================================== HUMOR
    ("humor", "Humor e memes", None, "humor,comedia,comedy,piada,joke,engracado,funny,hilario,hilarious,rir,laugh,lol,comico,comic,zoeira,fail,epic fail,pegadinha,prank,trollagem,troll,sarcasmo,sarcasm,ironia,irony,satira,satire,parodia,parody,stand up,stand up comedy,comediante,comedian,palhaco,clown,circo,circus,mágico,mago,magician,truque de magia,magic trick,ilusionismo,illusionism,reacao,reaction,reaction gif,gif de reacao,gif engracado,funny gif,video engracado,funny video,viral,viralizou,went viral,trend,tendencia da internet,internet trend,desafio,challenge,challenge viral,viral challenge,tiktok,reels,shorts,videos curtos,short videos,vine,compilacao,compilation,melhores momentos,best moments,bloopers,erros de gravacao,outtakes,bastidores engracados,funny behind the scenes,dublagem engracada,funny dubbing,legenda engracada,funny caption,tirinha,comic strip,charge,political cartoon,caricatura,caricature,cartum,cartoon strip,humor negro,dark humor,humor inteligente,witty humor,humor britanico,british humor,humor americano,american humor,humor brasileiro,brazilian humor,memes brasileiros,brazilian memes,meme de gato,cat meme,meme de cachorro,dog meme,meme classico,classic meme,meme atual,current meme,meme de politica,political meme,meme de futebol,football meme,meme de filme,movie meme,meme de serie,series meme,meme de anime,anime meme,meme de game,gaming meme,meme de escola,school meme,meme de trabalho,work meme,meme de segunda feira,monday meme,meme de sexta feira,friday meme,meme de domingo,sunday meme,meme de natal,christmas meme,meme de ano novo,new year meme,meme de carnaval,carnival meme,meme de verao,summer meme,meme de inverno,winter meme,meme de fim de semana,weekend meme,meme de feriado,holiday meme,meme de ferias,vacation meme,meme de volta as aulas,back to school meme"),
    ("meme", "Meme", "humor", "meme,memes,imagem engracada,funny image,macro de imagem,image macro,template de meme,meme template,meme format,formato de meme,rage comic,rage face,troll face,pepe,doge,grumpy cat,distracted boyfriend,drake meme,woman yelling at cat,this is fine,success kid,bad luck brian,scumbag steve,good guy greg,advice animal,first world problems,y u no,one does not simply,ancient aliens,futurama fry,not sure if,philosoraptor,condescending wonka,confession bear,insanity wolf,overly attached girlfriend,hide the pain harold,roll safe,surprised pikachu,galaxy brain,expanding brain,stonks,wojak,chad,virgin vs chad,gigachad,npc,bernie sitting,mocking spongebob,spongebob meme,patrick meme,squidward meme,shrek meme,minions meme,simpsons meme,rick and morty meme,family guy meme,south park meme,star wars meme,marvel meme,dc meme,harry potter meme,lord of the rings meme,game of thrones meme,breaking bad meme,office meme,friends meme,stranger things meme,squid game meme,money heist meme,la casa de papel meme,anime meme jp,naruto meme,dragon ball meme,one piece meme,pokemon meme,mario meme,zelda meme,sonic meme,minecraft meme,fortnite meme,among us meme,roblox meme,cs go meme,league of legends meme,valorant meme,gta meme,fifa meme,pes meme,free fire meme,pubg meme,fall guys meme,genshin meme"),
    ("personagem_desenho", "Personagem de desenho", "humor", "personagem de desenho,cartoon character,desenho animado,cartoon,animacao,animation,animated,animado,personagem animado,animated character,mascote,mascot,boneco,puppet,fantoche,marionete,marionette,cartoon network,disney personagem,disney character,pixar personagem,pixar character,looney tunes,pernalonga,bugs bunny,patolino,daffy duck,tom e jerry,tom and jerry,pica pau,woody woodpecker,pink panther,pantera cor de rosa,scooby doo,snoopy,charlie brown,garfield,mickey,mickey mouse,minnie,donald,pato donald,pateta,goofy,pluto,tweety,piu piu,frajola,sylvester,speedy gonzales,coiote e papa leguas,wile e coyote,road runner,popeye,betty boop,felix o gato,felix the cat,mutley,muttley,flintstones,os flintstones,jetsons,os jetsons,yogi bear,zé colmeia,hanna barbera,smurfs,smurf,os smurfs,pequeno principe cartoon,little prince cartoon,tintin,asterix,obelix,lucky luke,spirou,gaston,mafalda,calvin e haroes,calvin and hobbes,turma da monica,monica,cebolinha,cascao,magali,chico bento,horacio,penadinho,turma do pererê,saci perere,sitio do picapau amarelo,emilia,narizinho,pedrinho,visconde,cuca,tia anastacia,dona benta"),
    ("careta", "Caretas e expressões", "humor", "careta,funny face,make a face,fazendo careta,pulling a face,cara engracada,silly face,expressao engracada,funny expression,boca torta,crooked mouth,lingua para fora,tongue out,olhos vesgos,cross eyed,vesgo,squint,bochechas infladas,puffed cheeks,piscadinha,wink,piscar,blink,mostrando a lingua,sticking tongue out,cara de espanto,shocked face,cara de nojo,disgusted face,cara de bravo,angry face,cara de choro,crying face,cara de sono,sleepy face,cara de tedio,bored face,cara de pensativo,thinking face,cara de preocupado,worried face,cara de culpado,guilty face,cara de inocente,innocent face,cara de safado,naughty face,cara de paisagem,blank stare,cara de pau,poker face,cara feia,ugly face,cara de bunda,silly grimace,micagem,mugging,bobeira,silliness,palhacada,clowning around,gracinha,cute antics,fofura,cuteness,fofo,cute,adoravel,adorable,engracadinho,cutie,bebe fazendo careta,baby making face,cachorro fazendo careta,dog making face,gato fazendo careta,cat making face"),

    # ====================================================== GAMES
    ("games", "Games", None, "game,games,jogo,jogos,gaming,gamer,videogame,video game,jogador de videogame,esports,e sports,streamer,streaming de jogos,game streaming,twitch,e sport,jogatina,gameplay,jogabilidade,fase,level,boss,chefao,personagem de jogo,game character,mundo aberto,open world,rpg,mmorpg,fps,jogo de tiro,shooter,jogo de corrida,racing game,jogo de luta,fighting game,jogo de estrategia,strategy game,jogo de aventura,adventure game,jogo de plataforma,platformer,jogo de puzzle,puzzle game,jogo indie,indie game,jogo mobile,mobile game,jogo retro,retro game,jogo classico,classic game,arcade,fliperama,maquina de arcade,arcade machine,atari,nes,super nintendo,snes,mega drive,sega,playstation,ps5,ps4,xbox,nintendo switch,switch,game boy,gameboy,tamagotchi,pac man,tetris,space invaders,donkey kong,super mario,zelda game,pokemon game,minecraft game,fortnite,league of legends,valorant,counter strike,cs go,dota,overwatch,apex legends,call of duty,gta,grand theft auto,fifa game,the sims,sims,animal crossing,among us game,roblox game,free fire game,pubg game,genshin impact,elden ring,dark souls,witcher,cyberpunk 2077,red dead redemption,god of war,last of us,uncharted,assassins creed,far cry,resident evil,silent hill,final fantasy,dragon quest,kingdom hearts,metal gear,street fighter,mortal kombat,tekken,smash bros,mario kart,splatoon,kirby,metroid,fire emblem,star fox,f zero,pikmin,earthbound,chrono trigger"),
    ("videogame", "Videogame e consoles", "games", "captura de jogo,game screenshot,screenshot de jogo,captura de tela de jogo,print de jogo,gameplay screenshot,controle de videogame,game controller,controller,joystick,gamepad,controle,console,console de videogame,video game console,playstation controle,ps controller,xbox controle,xbox controller,nintendo controle,nintendo controller,mouse gamer,gaming mouse,teclado gamer,gaming keyboard,headset gamer,gaming headset,cadeira gamer,gaming chair,setup gamer,gaming setup,pc gamer,gaming pc,notebook gamer,gaming laptop,monitor gamer,gaming monitor,placa de video gamer,gaming gpu,sala de jogos,game room,lan house,cyber cafe,torneio de games,gaming tournament,campeonato de games,gaming championship,arena de esports,esports arena,jogador profissional,pro gamer,time de esports,esports team,streamer de games,game streamer,live de games,game live stream,narrador de games,game commentator,cosplay de games,game cosplay,convencao de games,gaming convention,gamescom,e3,bgs,brasil game show,comic con,cca,realidade virtual,virtual reality,vr,oculos vr,vr headset,oculus,quest,realidade aumentada,augmented reality,ar,metaverso,metaverse,jogo em vr,vr game,simulador,simulator,simulador de voo,flight simulator,simulador de corrida,racing simulator,simulador de fazenda,farm simulator,volante gamer,gaming wheel,pedais,pedals,cockpit,cockpit de simulador,sim rig,rig,arcade stick,fight stick,joystick arcade"),
    ("jogo_tabuleiro", "Jogos de tabuleiro e cartas", "games", "tabuleiro de xadrez,chess board,xadrez,chess,peca de xadrez,chess piece,rei,king,rainha,queen,bispo,bishop,cavalo de xadrez,knight,torre de xadrez,rook,peao,pawn,xeque mate,checkmate,partida de xadrez,chess game,enxadrista,chess player,jogo de tabuleiro,board game,tabuleiro,board,damas,checkers,gamao,backgammon,go,jogo de go,ludo,banco imobiliario,monopoly,war,jogo war,detetive,clue,cluedo,scrabble,palavras cruzadas,crossword,catan,carcassonne,ticket to ride,dominion,pandemic,risk,jogo da vida,game of life,uno,cartas de baralho,playing cards,baralho,deck of cards,deck,carta,card,naipe,suit,ouros,diamonds,copas,hearts,paus,clubs,espadas,spades,as,ace,coringa,joker,truco,poker,poquer,blackjack,vinte e um,twenty one,buraco,canastra,bridge card game,solitaire,paciencia,paciência,magic the gathering,mtg,pokemon tcg,yugioh,yu gi oh,tcg,card game,jogo de cartas,rpg de mesa,tabletop rpg,dungeons and dragons,dnd,d&d,dados,dice,dado,d20,rpg dice,mestre de jogo,game master,dungeon master,miniaturas,miniatures,warhammer,wargame,jogo de guerra,war game,quebra cabeca,jigsaw puzzle,puzzle,peca de quebra cabeca,puzzle piece,cubo magico,rubiks cube,rubik,jogo de memoria,memory game,domino,dominó,mahjong,bingo,loteria,lottery,roleta,roulette,cassino,casino,caca niquel,slot machine,fichas,chips,mesa de poker,poker table,mesa de jogo,game table,noite de jogos,game night,ludoteca,board game cafe,cafe de jogos,jogos de mesa,tabletop games,jogos de salao,parlor games,jogo de adivinhacao,guessing game,charada,riddle,quiz,trivia,jogo de perguntas,question game,jogo de palavras,word game,caca palavras,word search,sudoku,jogo de logica,logic game,jogo de raciocinio,brain game,jogo de estrategia de tabuleiro,strategy board game,jogo cooperativo,cooperative game,jogo familiar,family game,jogo infantil,kids game,jogo educativo,educational game,jogo de festa,party game,jogo de beber,drinking game,jogo de verdade ou desafio,truth or dare,jogo da garrafa,spin the bottle,pique bandeira,capture the flag,esconde esconde,hide and seek game,jogo da forca,hangman,batalha naval,battleship,jogo da velha,tic tac toe,quatro em linha,connect four,pega varetas,pick up sticks,jenga,torre de blocos,block tower,twister,jogo twister,operando,operation game,cara a cara,guess who,imagem e acao,pictionary,mimica,charades,tabu,taboo,cranium,jogo cranium"),
    ("pixel_art", "Pixel art", "games", "pixel art,pixelart,pixel,pixelado,pixelated,8 bit,8bit,16 bit,16bit,sprite art,sprite sheet,arte em pixel,pixel character,personagem pixel,pixel landscape,paisagem pixel,pixel animation,animacao pixel,retro pixel,pixel retro,estilo retro,retro style,estilo 8 bits,8 bits style,voxel,voxel art,low poly,lowpoly,estilo pixelado,pixelated style,arte pixelada,pixelated art,tile map,tilemap,tileset,mapa de tiles,pixel game,jogo pixel,jogo de pixels,pixel icons,icones pixel,emoji pixel,pixel emoji,pixel logo,logo pixel,pixel text,texto pixel,pixel font,fonte pixel,bitmap font,fonte bitmap,pixel face,rosto pixel,pixel portrait,retrato pixel,pixel food,comida pixel,pixel animal,animal pixel,pixel city,cidade pixel,pixel space,espaco pixel,pixel sky,ceu pixel,pixel water,agua pixel,pixel fire,fogo pixel,pixel explosion,explosao pixel,pixel heart,coracao pixel,pixel star,estrela pixel,pixel sword,espada pixel,pixel shield,escudo pixel,pixel potion,pocao pixel,pixel chest,bau pixel,pixel key,chave pixel,pixel coin,moeda pixel,pixel gem,gema pixel,pixel crystal,cristal pixel"),
    ("brinquedo", "Brinquedos", "games", "brinquedo,toy,toys,brinquedos,action figure,boneco de acao,colecionavel,collectible,figure,figura,funko,funko pop,lego brinquedo,lego toy,blocos de montar brinquedo,building blocks toy,carrinho hot wheels,hot wheels,matchbox,miniatura de carro,toy car miniature,trem de brinquedo,toy train,aviaozinho,toy plane,barquinho de brinquedo,toy boat,robo de brinquedo,toy robot,boneca barbie,barbie,bonecas,dolls,urso de pelucia,teddy bear,pelucia,plush,bicho de pelucia,stuffed animal,boneco de pano,rag doll,casa de boneca,doll house,ursinho,teddy,massinha de modelar,modeling clay,play doh,slime,fidget spinner,fidget toy,cubo de rubik brinquedo,rubik toy,pop it,bolha de sabao,soap bubbles,bubble wand,bolha,bubble,piao de brinquedo,toy top,ioio de brinquedo,toy yoyo,pipa de brinquedo,toy kite,aviaozinho de papel,paper airplane,barquinho de papel,paper boat,origami brinquedo,toy origami,dobradura,paper folding,boneco de neve,snowman,boneco de madeira,wooden toy,cavalinho de pau,hobby horse,cavalo de balanco,rocking horse,triciclo brinquedo,toy tricycle,patinete de crianca,kids scooter,bicicleta infantil,kids bike,skate infantil,kids skate,bola de brinquedo,toy ball,bambole,hula hoop,corda de pular,jump rope,pula corda,skipping rope,pe de lata,tin can stilts,perna de pau,stilts,carrinho de rolima,soapbox cart,carrinho de pedal,pedal car,carro de controle remoto,rc car,remote control car,aviao de controle remoto,rc plane,helicoptero de controle remoto,rc helicopter,barco de controle remoto,rc boat,drone de brinquedo,toy drone,trem eletrico,model train,ferromodelismo,model railroad,maquete,scale model,modelismo,modeling hobby,miniaturismo,miniature,diorama,diorama de miniaturas,miniature diorama,casinha em miniatura,miniature house,mobilia em miniatura,miniature furniture,comida em miniatura,miniature food,cozinha em miniatura,miniature kitchen,loja em miniatura,miniature shop,cidade em miniatura,miniature city,paisagem em miniatura,miniature landscape,jardim em miniatura,miniature garden,fada,fairy,jardim de fadas,fairy garden,casa de fada,fairy house,duende,elf,gnomo,gnome,anao de jardim,garden gnome,sereia,mermaid,unicornio,unicorn,dragao,dragon,fenix,phoenix,pegasus,pégaso,centauro,centaur,minotauro,minotaur,grifo,griffin,quimera,chimera,hidra,hydra,kraken,leviata,leviathan,golem,troll criatura,troll creature,orc,goblin,ogro,ogre,gigante,giant,mago de fantasia,fantasy wizard,bruxo,wizard,feiticeiro,sorcerer,elfo,elf fantasy,anao,dwarf,hobbit,halfling,paladino,paladin,guerreiro,warrior,arqueiro,archer,ladino,rogue,clerigo,cleric,bardo,bard,druida,druid,monge,monk,barbaro,barbarian,necromante,necromancer,invocador,summoner,alquimista,alchemist,cavaleiro,knight fantasy,rei de fantasia,fantasy king,rainha de fantasia,fantasy queen,princesa,princess,principe,prince,vilao,villain,heroi,hero,heroina,heroine,super heroi,superhero,super vilao,supervillain,anti heroi,anti hero,mascarado,masked,encapuzado,hooded,misterioso,mysterious,sombrio,dark,gotico,gothic,macabro,macabre,sinistro,sinister,assombrado,haunted,fantasma,ghost,espirito,spirit,alma,soul,assombracao,haunting,zumbi,zombie,vampiro,vampire,lobisomem,werewolf,monstro,monster,alienigena,alien,ET,extraterrestre,extraterrestrial,ovni,ufo,disco voador,flying saucer,nave espacial,spaceship,espaçonave,spacecraft"),

    # ====================================================== CIÊNCIA E ESPAÇO
    ("ciencia", "Ciência e espaço", None, "ciencia,science,cientifico,scientific,pesquisa,research,experimento,experiment,descoberta,discovery,teoria,theory,formula,equacao,equation,matematica,mathematics,math,fisica,physics,quimica,chemistry,biologia,biology,geologia,geology,astronomia,astronomy,medicina,medicine,saude,health,tecnologia cientifica,scientific technology,inovacao cientifica,scientific innovation,educacao,education,estudo,study,aprendizado,learning,conhecimento,knowledge,sabedoria,wisdom,genio,genius,inteligencia,intelligence,cerebro,brain,mente,mind,pensamento,thought,ideia,idea,lampada,light bulb,eureka,curiosidade,curiosity,fato curioso,fun fact,voce sabia,did you know,infografico cientifico,scientific infographic,diagrama,diagram,grafico,chart,grafico de barras,bar chart,grafico de linha,line chart,grafico de pizza,pie chart,tabela,table,estatistica,statistics,dados cientificos,scientific data,pesquisa cientifica,scientific research,artigo cientifico,scientific paper,tese,thesis,dissertacao,dissertation,laboratorio de pesquisa,research lab,universidade pesquisa,university research"),
    ("espaco", "Espaço e astronomia", "ciencia", "espaco,space,universo,universe,cosmos,cosmo,astronomia espacial,space astronomy,sistema solar,solar system,via lactea,milky way,estrelas,stars,estrela,star,constelacao,constellation,ceu estrelado,starry sky,ceu noturno,night sky,noite estrelada,starry night,cometa,comet,asteroide,asteroid,meteoro,meteor,meteorito,meteorite,chuva de meteoros,meteor shower,eclipse,eclipse solar,solar eclipse,eclipse lunar,lunar eclipse,buraco negro,black hole,supernova,pulsar,quasar,anã branca,white dwarf,gigante vermelha,red giant,aglomerado de estrelas,star cluster,materia escura,dark matter,energia escura,dark energy,big bang,expansao do universo,universe expansion,multiverso,multiverse,viagem espacial,space travel,exploracao espacial,space exploration,missao espacial,space mission,programa espacial,space program,nasa,esa,spacex,roscosmos,agencia espacial,space agency,cosmonauta,cosmonaut,taikonauta,taikonaut,voo espacial,spaceflight,orbita,orbit,gravidade zero,zero gravity,microgravidade,microgravity,caminhada espacial,spacewalk,traje espacial,spacesuit,capsula espacial,space capsule,modulo lunar,lunar module,sonda espacial,space probe,voyager,hubble,james webb,jwst,telescopio espacial,space telescope"),
    ("galaxia", "Galáxia", "espaco", "galaxia,galaxy,galaxias,galaxies,andromeda,galaxia espiral,spiral galaxy,galaxia elíptica,elliptical galaxy,nuvem de magalhaes,magellanic cloud,aglomerado de galaxias,galaxy cluster,campo profundo,deep field,hubble deep field,imagem do hubble,hubble image,imagem do webb,webb image,imagem astronomica,astronomical image,astrofotografia,astrophotography,fotografia astronomica,astronomical photography,ceu profundo,deep sky,objeto de ceu profundo,deep sky object"),
    ("nebulosa", "Nebulosa", "espaco", "nebulosa,nebula,nebulosas,nebulae,nebulosa de orion,orion nebula,nebulosa do caranguejo,crab nebula,nebulosa planetaria,planetary nebula,nebulosa de emissao,emission nebula,nebulosa escura,dark nebula,pilares da criacao,pillars of creation,nebulosa da aguia,eagle nebula,nebulosa do anel,ring nebula,nebulosa da helice,helix nebula,nuvem molecular,molecular cloud,regiao de formacao estelar,star forming region,berçario estelar,stellar nursery,gas cosmico,cosmic gas,poeira cosmica,cosmic dust,nuvem cosmica,cosmic cloud,cores do espaco,space colors,espaco colorido,colorful space,fundo espacial,space background,wallpaper espacial,space wallpaper,papel de parede espacial,space wallpaper pt"),
    ("planeta", "Planeta", "espaco", "planeta,planet,planetas,planets,terra planeta,planet earth,marte,mars,venus,venus planet,mercurio planeta,mercury planet,jupiter,saturno,saturn,aneis de saturno,saturn rings,urano,uranus,netuno,neptune,plutao,pluto,planeta anao,dwarf planet,exoplaneta,exoplanet,planeta rochoso,rocky planet,gigante gasoso,gas giant,gigante de gelo,ice giant,lua de jupiter,jupiter moon,europa,ganimedes,ganymede,calisto,callisto,io,titan,titã,encelado,enceladus,triton,tritao,fobos,phobos,deimos,mancha vermelha,great red spot,superficie de marte,mars surface,rover em marte,mars rover,curiosity,perseverance,opportunity,spirit rover,sojourner,viking,mariner,pioneer,galileo,cassini,juno,new horizons,messenger,magellan,venera,luna,lunokhod,chang e,change,chandrayaan,mangalyaan,hope,tianwen,zhurong,planeta vermelho,red planet,planeta azul,blue planet,planeta gasoso,gaseous planet,planeta com aneis,ringed planet,sistema planetario,planetary system,orbita planetaria,planetary orbit,alinhamento planetario,planetary alignment,transito de venus,venus transit,transito de mercurio,mercury transit,conjuncao,conjunction,oposicao,opposition,planeta visto da terra,planet seen from earth,planeta no ceu,planet in sky,planeta no telescopio,planet in telescope,planeta fotografado,photographed planet,imagem de planeta,planet image,planeta em alta resolucao,high resolution planet,planeta em 3d,3d planet,modelo de planeta,planet model,globo,globe,globo terrestre,earth globe,mapa mundi,world map,atlas,mapa,map,mapa antigo,old map,mapa de navegacao,navigation map,mapa do tesouro,treasure map,bussola,compass,sextante,sextant,astrolabio,astrolabe,cartografia,cartography,cartografo,cartographer,geografia,geography,geografo,geographer,planisferio,planisphere,projecao de mercator,mercator projection,latitude,longitude,meridiano,meridian,equador,equator,tropico,tropic,polo norte,north pole,polo sul,south pole,hemisferio,hemisphere,continente,continent,oceano no mapa,ocean on map,pais,country,fronteira,border,bandeira,flag,bandeiras do mundo,world flags,capitais,capitals,mapa politico,political map,mapa fisico,physical map,mapa topografico,topographic map,relevo no mapa,relief map,satelite de mapa,satellite map,google maps,google earth,vista de satelite,satellite view,terra vista do espaco,earth from space,terra vista da lua,earth from moon,nascer da terra,earthrise,blue marble,pale blue dot,pálido ponto azul,pálido ponto azul pt"),
    ("lua", "Lua", "espaco", "lua,moon,luar,moonlight,lua cheia,full moon,lua nova,new moon,lua crescente,crescent moon,lua minguante,waning moon,quarto crescente,first quarter,quarto minguante,last quarter,superlua,supermoon,lua de sangue,blood moon,lua azul,blue moon,lua de morango,strawberry moon,lua da colheita,harvest moon,lua do caçador,hunters moon,lua do lobo,wolf moon,lua de neve,snow moon,lua de minhoca,worm moon,lua rosa,pink moon,lua de flores,flower moon,lua de trovao,thunder moon,lua de esturjao,sturgeon moon,lua de castor,beaver moon,lua fria,cold moon,superficie lunar,lunar surface,cratera lunar,lunar crater,mar lunar,lunar sea,mare lunar,lunar mare,lado escuro da lua,dark side of the moon,lado oculto da lua,far side of the moon,pouso na lua,moon landing,apollo,apollo 11,neil armstrong,buzz aldrin,michael collins,pegada na lua,moon footprint,bandeira na lua,flag on moon,modulo lunar apollo,apollo lunar module,rover lunar,lunar rover,base lunar,moon base,colonia lunar,lunar colony,artemis,programa artemis,artemis program,missao artemis,artemis mission,gateway lunar,lunar gateway,foguete sls,sls rocket,orion,capsula orion,orion capsule"),
    ("astronauta", "Astronauta", "espaco", "astronauta,astronaut,astronautas,astronauts,cosmonauta russo,russian cosmonaut,traje de astronauta,astronaut suit,capacete de astronauta,astronaut helmet,astronauta flutuando,floating astronaut,astronauta na lua,astronaut on moon,astronauta em marte,astronaut on mars,astronauta no espaço,astronaut in space,astronauta na iss,astronaut on iss,astronauta fazendo caminhada espacial,astronaut spacewalk,astronauta reparando,astronaut repairing,astronauta com bandeira,astronaut with flag,selfie de astronauta,astronaut selfie,tripulacao,crew,tripulante,crew member,comandante,commander,piloto espacial,space pilot,especialista de missao,mission specialist,engenheiro de voo,flight engineer,treinamento de astronauta,astronaut training,piscina de treinamento,training pool,centrifuga,centrifuge,simulador de gravidade zero,zero gravity simulator,voo parabolico,parabolic flight,cometa do vomito,vomit comet,primeiro astronauta,first astronaut,yuri gagarin,gagarin,valentina tereshkova,tereshkova,alan shepard,shepard,john glenn,glenn,sally ride,ride,marcos pontes,pontes,astronauta brasileiro,brazilian astronaut,turismo espacial,space tourism,turista espacial,space tourist,voo suborbital,suborbital flight,blue origin,virgin galactic,inspiration4,axiom,crew dragon,dragon,starliner,soyuz,soyuz capsule,shenzhou,tiangong,estacao tiangong,tiangong station"),
    ("foguete", "Foguete e lançamento", "espaco", "foguete,rocket,foguetes,rockets,lancamento de foguete,rocket launch,lancamento espacial,space launch,decolagem de foguete,rocket takeoff,plataforma de lancamento,launch pad,centro de lancamento,launch center,cabo canaveral,cape canaveral,kennedy space center,centro espacial kennedy,baikonur,kourou,alcantara,centro de lancamento de alcantara,base de lancamento,launch base,contagem regressiva,countdown,ignicao,ignition,propulsao,propulsion,empuxo,thrust,motor de foguete,rocket engine,combustivel de foguete,rocket fuel,estagio,stage,estagio de foguete,rocket stage,booster,propulsor,propellant,falcon 9,falcon heavy,starship,super heavy,saturn v,saturno v,space shuttle,onibus espacial,ônibus espacial,atlantis,discovery,columbia,challenger,endeavour,buran,ariane,ariane 5,ariane 6,vega,atlas,delta,delta iv,vulcan,new glenn,new shepard,electron,rocket lab,neutron,antares,cygnus,long march,longa marcha,chang zheng,gslv,pslv,h2a,h3,epsilon,soyuz foguete,soyuz rocket,proton,angara,zenit,energia,n1,r7,v2,v 2,redstone,jupiter c,vanguard,juno 1,titan,titan ii,gemini,mercury,mercury redstone,mercury atlas,project mercury,project gemini,project apollo,apollo program,programa apollo,saturn ib,saturno ib,little joe,aerobee,sounding rocket,foguete de sondagem,foguete de garrafa pet,water rocket,modelismo de foguete,model rocket,foguetemodelismo,rocketry,amador de foguetes,rocket amateur,lancamento amador,amateur launch,fogos de foguete,rocket fireworks,fumaca de foguete,rocket smoke,rastro de foguete,rocket trail,chama do foguete,rocket flame,foguete no ceu,rocket in sky,foguete ao amanhecer,rocket at dawn,foguete ao entardecer,rocket at dusk,foguete a noite,rocket at night,lancamento noturno,night launch,lancamento diurno,day launch,lancamento ao vivo,live launch,transmissao de lancamento,launch broadcast,torcida de lancamento,launch crowd,publico de lancamento,launch audience,espectadores de lancamento,launch spectators,fotografo de lancamento,launch photographer,cameras de lancamento,launch cameras,imagem de lancamento,launch image,foto de lancamento,launch photo,video de lancamento,launch video,gif de lancamento,launch gif,timelapse de lancamento,launch timelapse,sobreposicao de lancamento,launch overlay,longa exposicao de lancamento,launch long exposure,rastro luminoso,light trail,estrela cadente de foguete,rocket shooting star,efeito medusa,jellyfish effect,nuvem de foguete,rocket cloud,pluma de foguete,rocket plume,pluma,plume,exaustao,exhaust,gases de exaustao,exhaust gases,onda de choque,shock wave,diamantes de mach,mach diamonds,disco de mach,mach disk,som de foguete,rocket sound,estrondo,rumble,barulho de foguete,rocket noise,vibracao,vibration,tremor,tremor of launch,terremoto de lancamento,launch quake"),
    ("estacao_espacial", "Estação espacial", "espaco", "estacao espacial,space station,iss,estacao espacial internacional,international space station,mir,skylab,salyut,tiangong estacao,tiangong space station,estacao orbital,orbital station,laboratorio orbital,orbital laboratory,modulo espacial,space module,painel solar da iss,iss solar panel,braco robotico da iss,iss robotic arm,canadarm,cupola,cupola da iss,iss cupola,janela da iss,iss window,vista da iss,view from iss,terra vista da iss,earth from iss,aurora vista da iss,aurora from iss,tempestade vista da iss,storm from iss,cidade a noite vista da iss,city at night from iss,fotos da iss,iss photos,videos da iss,iss videos,transmissao da iss,iss broadcast,iss ao vivo,iss live,hdev,earth viewing,earth viewing iss,iss tracker,rastreador da iss,iss passando,iss passing,iss no ceu,iss in sky,iss transito,iss transit,iss sobre a lua,iss over moon,iss sobre o sol,iss over sun,passagem da iss,iss pass,iss visivel,iss visible,quando ver a iss,when to see iss,gateway estacao,gateway station,estacao lunar,lunar station,estacao de marte,mars station,habitat espacial,space habitat,colonia espacial,space colony,cilindro de oneill,oneill cylinder,roda espacial,space wheel,estacao rotativa,rotating station,gravidade artificial,artificial gravity,elevador espacial,space elevator,anel orbital,orbital ring,hotel espacial,space hotel,voyager station,von braun station,estacao von braun,gateway foundation,orbital assembly,assembleia orbital"),
    ("telescopio", "Telescópio e observatório", "espaco", "telescopio,telescope,telescopios,telescopes,observatorio,observatory,observatorio astronomico,astronomical observatory,cupula do observatorio,observatory dome,telescopio refletor,reflector telescope,telescopio refrator,refractor telescope,telescopio newtoniano,newtonian telescope,telescopio dobsoniano,dobsonian telescope,telescopio amador,amateur telescope,astronomo amador,amateur astronomer,astronomo,astronomer,observacao do ceu,sky observation,observar estrelas,stargazing,observacao de estrelas,star watching,noite de observacao,observation night,festa de estrelas,star party,clube de astronomia,astronomy club,planetario,planetarium,sessao de planetario,planetarium show,museu de astronomia,astronomy museum,centro de ciencias,science center,museu de ciencias,science museum,feira de ciencias,science fair,olimpiada de astronomia,astronomy olympiad,observatorio nacional,national observatory,observatorio de greenwich,greenwich observatory,observatorio de paris,paris observatory,observatorio de lick,lick observatory,observatorio de yerkes,yerkes observatory,observatorio de mauna kea,mauna kea observatory,observatorio de la silla,la silla observatory,observatorio de paranal,paranal observatory,observatorio de atacama,atacama observatory,alma,very large telescope,vlt,telescopio extremamente grande,extremely large telescope,elt,telescopio gigante de magalhaes,giant magellan telescope,gmt,telescopio de trinta metros,thirty meter telescope,tmt,telescopio keck,keck telescope,telescopio subaru,subaru telescope,telescopio gemini,gemini telescope,telescopio hale,hale telescope,telescopio hooker,hooker telescope,telescopio de arecibo,arecibo telescope,radiotelescopio,radio telescope,antena de radiotelescopio,radio telescope dish,parabolica de radiotelescopio,radio telescope parabolic,array de radiotelescopios,radio telescope array,vla,very large array,ska,square kilometre array,fast,telescopio chines,chinese telescope,telescopio de cinco centos metros,five hundred meter telescope,telescopio espacial hubble,hubble space telescope,telescopio espacial james webb,james webb space telescope,telescopio espacial spitzer,spitzer space telescope,telescopio espacial chandra,chandra space telescope,telescopio espacial kepler,kepler space telescope,telescopio espacial tess,tess space telescope,telescopio espacial gaia,gaia space telescope,telescopio espacial planck,planck space telescope,telescopio espacial herschel,herschel space telescope,telescopio espacial euclid,euclid space telescope,telescopio espacial roman,roman space telescope,telescopio espacial xrism,xrism space telescope,telescopio espacial fermi,fermi space telescope,telescopio espacial swift,swift space telescope"),
    ("biologia", "Biologia e microscopia", "ciencia", "biologia,biology,microscopia,microscopy,microscopio,microscope,celula,cell,celulas,cells,bacteria,bactéria,virus,vírus,micro organismo,microorganism,microbio,microbe,microbiologia,microbiology,tecido,tissue,organismo,organism,organelas,organelles,nucleo celular,cell nucleus,mitocondria,mitochondria,cromossomo,chromosome,gene,genes,genetica,genetics,dna,adn,dna helice,dna helix,dupla helice,double helix,sequenciamento,sequencing,genoma,genome,crispr,clonagem,cloning,celulas tronco,stem cells,proteina,protein,enzima,enzyme,molecula,molecule,atomo,atom,quimica organica,organic chemistry,bioquimica,biochemistry,biotecnologia,biotechnology,bioengenharia,bioengineering,evolucao,evolution,darwin,selecao natural,natural selection,ecologia,ecology,ecossistema,ecosystem,biodiversidade,biodiversity,cadeia alimentar,food chain,habitat,especie,species,extincao,extinction,fossil,fossil record,fossilizado,fossilized,paleontologia,paleontology,paleontologo,paleontologist,dinossauro,dinosaur,esqueleto de dinossauro,dinosaur skeleton,t rex,tiranossauro,tyrannosaurus,velociraptor,triceratops,estegossauro,stegosaurus,braquiossauro,brachiosaurus,mamute,mammoth,mastodonte,mastodon,tigre dente de sabre,sabertooth,preguiça gigante,giant sloth,megalodon,trilobita,trilobite,amonite,ammonite,ambar,amber,inseto em ambar,insect in amber,pegada fossil,fossil footprint,ovo de dinossauro,dinosaur egg,escavacao paleontologica,paleontological dig,museu de historia natural,natural history museum,osso,bone,ossos,bones,cranio,skull,caveira,skull and bones,esqueleto,skeleton,anatomia,anatomy,orgao,organ,coracao anatomia,heart anatomy,cerebro anatomia,brain anatomy,pulmao,lung,figado,liver,rim,kidney,estomago,stomach,intestino,intestine,musculo,muscle,sangue,blood,celula sanguinea,blood cell,vaso sanguineo,blood vessel,neuronio,neuron,sinapse,synapse,sistema nervoso,nervous system,sistema imunologico,immune system,sistema digestivo,digestive system,sistema respiratorio,respiratory system,sistema circulatorio,circulatory system,raio x,x ray,tomografia,tomography,ressonancia magnetica,mri,ultrassonografia,ultrasonography,ecografia,echography,exame de sangue,blood test,teste de dna,dna test,teste genetico,genetic test,medicina genomica,genomic medicine"),
    ("laboratorio", "Laboratório", "ciencia", "laboratorio,laboratory,lab,laboratorio de quimica,chemistry lab,laboratorio de biologia,biology lab,laboratorio de fisica,physics lab,laboratorio de pesquisa,research laboratory,laboratorio clinico,clinical laboratory,laboratorio farmaceutico,pharmaceutical laboratory,tubo de ensaio,test tube,becker,beaker,erlenmeyer,pipeta,pipette,proveta,graduated cylinder,balao de laboratorio,laboratory flask,placa de petri,petri dish,bico de bunsen,bunsen burner,capela de exaustao,fume hood,jaleco,lab coat,luvas de laboratorio,lab gloves,oculos de protecao,safety goggles,mascara de laboratorio,lab mask,avental,apron,quimico,chemist,farmaceutico,pharmacist,biologo,biologist,fisico,physicist,matematico,mathematician,geologo,geologist,astrofisico,astrophysicist,astronomo cientista,astronomer scientist,engenheiro cientifico,scientific engineer,tecnico de laboratorio,lab technician,assistente de laboratorio,lab assistant,estagiario de laboratorio,lab intern,pesquisador de laboratorio,lab researcher,doutorando,phd student,mestrando,masters student,pos doutorando,postdoc,orientador,advisor,professor pesquisador,research professor,cientista louco,mad scientist,cientista maluco,crazy scientist,experimento quimico,chemical experiment,reacao quimica,chemical reaction,explosao quimica,chemical explosion,fumaca quimica,chemical smoke,liquido colorido,colored liquid,liquido fervendo,boiling liquid,liquido borbulhando,bubbling liquid,cristal,crystal,cristais,crystals,cristalizacao,crystallization,cristal de quartzo,quartz crystal,ametista,amethyst,geodo,geode,mineral,minerals,rocha,rock,pedra,stone,meteorito de laboratorio,laboratory meteorite,amostra,sample,amostras,samples,analise,analysis,teste,test,resultado,result,dados de laboratorio,lab data,caderno de laboratorio,lab notebook,prancheta,clipboard,relatorio de laboratorio,lab report,tabela periodica,periodic table,elementos quimicos,chemical elements,hidrogenio,hydrogen,oxigenio,oxygen,carbono,carbon,nitrogenio,nitrogen,ferro,iron,cobre,copper,zinco,zinc,aluminio,aluminum,magnesio,magnesium,calcio,calcium,sodio,sodium,potassio,potassium,cloro,chlorine,enxofre,sulfur,fosforo,phosphorus,helio,helium,neonio,neon,argonio,argon,uranio,uranium,plutonio,plutonium,radio,radium,polonio,polonium,mercurio,mercury element,chumbo,lead,estanho,tin,niquel,nickel,cromo,chromium,titanio,titanium,tungstenio,tungsten,platina,platinum,paladio,palladium,litio,lithium,boro,boron,silicio,silicon,germanio,germanium,arsenio,arsenic,selenio,selenium,bromo,bromine,iodo,iodine,xenonio,xenon,kriptonio,krypton,radonio,radon,francio,francium,cesio,cesium,rubidio,rubidium,estroncio,strontium,bario,barium,lantanio,lanthanum,cerio,cerium,neodimio,neodymium,disprosio,dysprosium,itrio,yttrium,escandio,scandium,zirconio,zirconium,niobio,niobium,molibdenio,molybdenum,tecnecio,technetium,rutenio,ruthenium,rodio,rhodium,prata elemento,silver element,cadmio,cadmium,indio,indium,antimonio,antimony,telurio,tellurium,hafnio,hafnium,tantalo,tantalum,renio,rhenium,osmio,osmium,iridio,iridium,ouro elemento,gold element,talio,thallium,bismuto,bismuth,astato,astatine,actinio,actinium,torio,thorium,protactinio,protactinium,neptunio,neptunium,americio,americium,curio,curium,berquelio,berkelium,californio,californium,einstenio,einsteinium,fermio,fermium,mendelevio,mendelevium,nobelio,nobelium,laurêncio,lawrencium"),
]

# ligações explícitas entre conceitos de domínios diferentes (score 0..1)
LINKS = [
    ("bicicleta", "ciclismo", 0.7), ("carro_corrida", "automobilismo", 0.7),
    ("moto", "automobilismo", 0.45), ("carro_esportivo", "automobilismo", 0.45),
    ("futebol", "estadio", 0.6), ("basquete", "estadio", 0.5), ("volei", "estadio", 0.5),
    ("surfe", "praia", 0.5), ("surfe", "mar", 0.5), ("natacao", "mar", 0.3),
    ("barco", "porto", 0.6), ("navio", "porto", 0.6), ("veleiro", "mar", 0.5), ("barco", "mar", 0.4),
    ("aviao", "porto", 0.5), ("trem", "porto", 0.4),
    ("foguete", "aviao", 0.3), ("foguete", "satelite", 0.5), ("drone", "aviao", 0.5),
    ("drone", "helicoptero", 0.5), ("satelite", "espaco", 0.4),
    ("videogame", "computador", 0.4), ("carro", "estrada", 0.55), ("moto", "estrada", 0.45),
    ("caminhao", "estrada", 0.45), ("bicicleta", "estrada", 0.35), ("onibus", "estrada", 0.4),
    ("escalada", "montanha", 0.6), ("esqui", "neve_gelo", 0.6), ("skate", "cidade", 0.3),
    ("cachorro", "gato", 0.2), ("flor", "borboleta", 0.3), ("macaco", "floresta", 0.35),
    ("peixe", "mar", 0.45), ("golfinho", "mar", 0.45), ("tartaruga", "praia", 0.3),
    ("pinguim", "neve_gelo", 0.4), ("urso", "floresta", 0.35), ("lobo", "floresta", 0.3),
    ("cafe", "padaria", 0.4),
    ("danca", "musico", 0.45),
    ("camera", "fotografia_arte", 0.5), ("modelo_moda", "retrato", 0.4),
    ("tenis", "sapato", 0.2),
    ("planeta", "espaco", 0.6), ("lua", "por_do_sol", 0.2),
]

# O CLIP devolve rótulos em português soltos; alguns são ambíguos fora de contexto.
# Resolvemos pelo rótulo exato (sem acento) em vez de pelo texto livre.
VISUAL_LABEL_OVERRIDES = {
    "balao": "balao_ar_quente",          # rótulo do CLIP em "viagens" = balão de ar quente
    "ponte": "ponte", "torre": "torre", "porto com barcos": "porto",
    "campo": "campo", "rio": "rio", "lua": "lua", "outono": "outono",
    "tenis": "tenis", "retrato": "retrato", "casal": "grupo", "familia": "grupo", "multidao": "grupo",
    "criancas brincando": "crianca", "dancarinos": "danca", "trabalhador": "trabalhador",
    "casamento": "casamento", "musico": "musico", "modelo de moda": "modelo_moda",
    "meme": "meme", "personagem de desenho": "personagem_desenho", "careta": "careta",
    "captura de jogo": "videogame", "controle de videogame": "videogame",
    "tabuleiro de xadrez": "jogo_tabuleiro", "jogo de tabuleiro": "jogo_tabuleiro",
    "cartas de baralho": "jogo_tabuleiro", "pixel art": "pixel_art", "brinquedo": "brinquedo",
}

CATEGORY_ROOT = {
    "natureza": "natureza", "animais": "animais", "viagens": "lugares",
    "arquitetura": "arquitetura", "arte": "arte", "comida": "comida",
    "tecnologia": "tecnologia", "esportes": "esportes", "carros": "veiculo",
    "moda": "moda", "pessoas": "pessoas", "humor": "humor", "games": "games",
    "ciencia": "ciencia",
}

# palavras comuns demais (ou de outro sentido) pra valer como pista de conceito
BLOCKED_TERMS = frozenset("""
ace ago age air all and any app art bar bat big box boy bug can cap car_ cat_ cut day den dip
dog_ end eye far fit fix fun gap get god gun guy hat_ hit hot ice_ ink job joy key kid_ lab_ law
leg let lie lot low mad man_ map_ may mix new nip not now nut odd off old_ one out own pan pay
pen pet_ pie_ pin pit pop pot put raw red_ rid row run sad sea_ set sir sit sky_ son sun_ tag tap
tax the tie_ tip top toy_ try two use van_ war_ way wet win wow yes yet you zoo_
""".replace("_", "").split()) - {"car", "cat", "dog", "hat", "ice", "kid", "lab", "map", "old",
                                 "pet", "pie", "red", "sea", "sky", "sun", "toy", "van", "war",
                                 "tie", "bar", "man", "art", "pen", "bat", "bug", "zoo", "fit",
                                 "fun", "gun", "key", "pop", "sea", "ink", "job", "age", "app"}

# termos removidos de TODOS os conceitos (ambíguos demais ou de outro sentido)
DROP_TERMS = frozenset("""
pele mare mars ram rock coral pais country countries suit table stage delta atlas titan dragon
streamer trend toast touca roma serra passarela dados chips beetle alma choro damas
fases fontes pontes kimono radio salsicha rings pets pedais commit curiosity discovery crew
terminal tourists turistas cards card diamonds ouros skies suits shorts mechas fans bones bone
bonecas dolls miniatures pluto vans titan estrela sample samples sampling
""".split())

# (termo, conceito) removidos só daquele conceito
DROP_PAIRS = frozenset({
    ("bateria", "satelite"), ("pele", "futebol"), ("mare", "cavalo"), ("coral", "musico"),
    ("estrela", "ginastica"), ("pagode", "templo"), ("carnaval", "traje_tipico"),
    ("passarela", "ponte"), ("dados", "tecnologia"), ("rock", "laboratorio"),
    ("coco", "danca"), ("submarino", "mar"), ("mars rover", "robo"),
})

# peso de cada fonte de texto
SOURCE_WEIGHT = {"title": 1.0, "visual": 1.0, "tags": 0.8, "description": 0.45}
MAX_CONCEPTS = 6
# `tags` e `description` do crawler são DERIVADOS do título (as mesmas palavras de novo): contar
# título + tags como evidências independentes dobrava o peso de quem aparece nos dois. Então a
# melhor fonte de texto vale inteira e as outras só "confirmam" (25 % cada). O CLIP (visual) é
# evidência independente e soma inteiro.
TEXT_CORROBORATION = 0.25
# Cenário (onde a foto foi tirada) pesa menos que o assunto (o que ela mostra): "red sports car on
# a road" é um carro, não uma estrada. Só amortece se existir algum assunto; sozinho, cenário vale cheio.
SETTINGS = frozenset("""
estrada cidade mercado porto praia mar lago rio montanha floresta deserto campo caverna
neve_gelo por_do_sol nuvem arco_iris interior
""".split())
SETTING_DAMP = 0.7
# tags de APARÊNCIA que o vortex_vision gera (cores, luz, contraste): descrevem a imagem, não o
# assunto. "rosa" (cor) NÃO é flor. Nunca viram conceito.
APPEARANCE_LABELS = frozenset("""
preto e branco|tons neutros|colorido|escuro|claro|vermelho|laranja|amarelo|verde|turquesa|ciano|
azul|roxo|rosa|tons quentes|tons frios|minimalista|detalhado|alto contraste
""".replace("\n", "").split("|"))
TERMS_PER_CONCEPT = 150      # cauda longa de termos além disso é ignorada
MIN_REL_WEIGHT = 0.2          # descarta conceito com < 20 % do peso do primeiro

Concept = namedtuple("Concept", "id label parent depth root")
Understanding = namedtuple("Understanding", "concepts domain families confidence source")


# ---------------------------------------------------------------------------
# normalização
# ---------------------------------------------------------------------------
_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def normalize(text):
    """minúsculas, sem acento, só letras/números separados por espaço."""
    if not text:
        return ""
    s = unicodedata.normalize("NFD", str(text).lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return _NON_ALNUM.sub(" ", s).strip()


def _variants(term):
    """Formas do termo: singular + plurais regulares (en e pt)."""
    out = {term}
    parts = term.split(" ")
    last = parts[-1]
    head = " ".join(parts[:-1])
    forms = {last, last + "s"}
    if last[-1] in "sxzhr":
        forms.add(last + "es")
    if last.endswith("y") and len(last) > 2:
        forms.add(last[:-1] + "ies")
    if last.endswith("ao") and len(last) > 3:
        forms.update({last[:-2] + "oes", last[:-2] + "aes"})
    if last.endswith("l") and len(last) > 3:
        forms.add(last[:-1] + "is")
    if last.endswith("m") and len(last) > 3:
        forms.add(last[:-1] + "ns")
    if last.endswith("f") and len(last) > 3:
        forms.add(last[:-1] + "ves")
    for f in forms:
        out.add((head + " " + f).strip())
    return out


# ---------------------------------------------------------------------------
# construção da taxonomia
# ---------------------------------------------------------------------------
TAXONOMY = {}          # id -> Concept
_CHILDREN = defaultdict(list)
_TERMS = {}            # termo normalizado -> [ids]
_MAX_NGRAM = 1


def _build():
    global _MAX_NGRAM
    depth = {}
    for cid, label, parent, _terms in _RAW:
        if cid in TAXONOMY:
            raise ValueError("conceito duplicado: %s" % cid)
        if parent is not None and parent not in depth:
            raise ValueError("pai desconhecido (%s antes de %s)" % (parent, cid))
        d = 0 if parent is None else depth[parent] + 1
        depth[cid] = d
        root = cid if parent is None else TAXONOMY[parent].root
        TAXONOMY[cid] = Concept(cid, label, parent, d, root)
        if parent:
            _CHILDREN[parent].append(cid)
    for cid, _label, _parent, terms in _RAW:
        n_added = 0
        for raw in terms.split(","):
            t = normalize(raw)
            if len(t) < 3 or t in BLOCKED_TERMS or t in DROP_TERMS or t.count(" ") >= 4:
                continue
            if (t, cid) in DROP_PAIRS:
                continue
            n_added += 1
            if n_added > TERMS_PER_CONCEPT:
                break
            for v in _variants(t):
                ids = _TERMS.setdefault(v, [])
                if cid not in ids:
                    ids.append(cid)
                _MAX_NGRAM = max(_MAX_NGRAM, v.count(" ") + 1)
    # Termo ambíguo mantém todos os conceitos (o peso é dividido), EXCETO quando um
    # é ancestral do outro: aí vale só o mais específico ("casamento" é casamento,
    # não "festa" em geral).
    def _anc(x):
        out = set()
        while TAXONOMY[x].parent:
            x = TAXONOMY[x].parent
            out.add(x)
        return out

    for term, ids in _TERMS.items():
        if len(ids) > 1:
            keep = [c for c in ids if not any(o != c and c in _anc(o) for o in ids)]
            _TERMS[term] = keep or ids


_build()
_MAX_NGRAM = min(_MAX_NGRAM, 6)


def concept(cid):
    return TAXONOMY.get(cid)


def label_of(cid):
    c = TAXONOMY.get(cid)
    return c.label if c else cid


def ancestors(cid, include_self=False):
    """Do pai mais próximo até a raiz."""
    out = []
    c = TAXONOMY.get(cid)
    if c is None:
        return out
    if include_self:
        out.append(cid)
    while c.parent:
        out.append(c.parent)
        c = TAXONOMY[c.parent]
    return out


def root_of(cid):
    c = TAXONOMY.get(cid)
    return c.root if c else None


def family_of(cid):
    """Ancestral de profundidade 1 (a "família"); raiz e filhos diretos da raiz
    devolvem a si mesmos (a raiz) ou o próprio nó."""
    c = TAXONOMY.get(cid)
    if c is None:
        return None
    if c.depth <= 1:
        return c.id
    for a in ancestors(cid, include_self=True):
        if TAXONOMY[a].depth == 1:
            return a
    return c.root


def children(cid):
    return list(_CHILDREN.get(cid, ()))


def descendants(cid):
    out, stack = [], list(_CHILDREN.get(cid, ()))
    while stack:
        n = stack.pop()
        out.append(n)
        stack.extend(_CHILDREN.get(n, ()))
    return out


_LINK = {}
for _a, _b, _s in LINKS:
    if _a not in TAXONOMY or _b not in TAXONOMY:
        raise ValueError("LINK com conceito desconhecido: %s/%s" % (_a, _b))
    _LINK[(_a, _b)] = _LINK[(_b, _a)] = _s


def relation(a, b):
    """Parentesco 0..1 entre dois conceitos."""
    if a not in TAXONOMY or b not in TAXONOMY:
        return 0.0
    if a == b:
        return 1.0
    anc_a = ancestors(a, include_self=True)
    anc_b = ancestors(b, include_self=True)
    if b in anc_a or a in anc_b:             # um é ancestral do outro
        dist = abs(TAXONOMY[a].depth - TAXONOMY[b].depth)
        return {1: 0.8, 2: 0.7}.get(dist, 0.6)
    set_b = set(anc_b)
    lca = next((x for x in anc_a if x in set_b), None)
    best = _LINK.get((a, b), 0.0)
    if lca is None:                          # domínios diferentes
        return best
    if TAXONOMY[lca].depth == 0:             # só o domínio em comum
        return max(best, 0.25)
    da = TAXONOMY[a].depth - TAXONOMY[lca].depth
    db = TAXONOMY[b].depth - TAXONOMY[lca].depth
    if da == 1 and db == 1:
        score = 0.65
    elif da + db == 3:
        score = 0.5
    else:
        score = 0.4
    return max(best, score)


def related_concepts(cid, min_score=0.45):
    """Conceitos parecidos com `cid` (ordem decrescente), pra expandir buscas."""
    if cid not in TAXONOMY:
        return []
    out = []
    for other in TAXONOMY:
        if other == cid:
            continue
        s = relation(cid, other)
        if s >= min_score:
            out.append((other, s))
    out.sort(key=lambda x: (-x[1], x[0]))
    return out


# ---------------------------------------------------------------------------
# extração
# ---------------------------------------------------------------------------

_APPEARANCE = frozenset(normalize(x) for x in APPEARANCE_LABELS)


def _match_text(text):
    """Lista de (ids, nº de ocorrências) achados no texto (maior termo ganha)."""
    toks = normalize(text).split()
    found = defaultdict(float)
    i, n = 0, len(toks)
    while i < n:
        hit = None
        for size in range(min(_MAX_NGRAM, n - i), 0, -1):
            cand = " ".join(toks[i:i + size])
            ids = _TERMS.get(cand)
            if ids:
                hit = (size, ids)
                break
        if hit:
            size, ids = hit
            share = 1.0 / len(ids)
            for cid in ids:
                found[cid] += share
            i += size
        else:
            i += 1
    return found


def _source_scores(text, weight):
    scores = {}
    for cid, cnt in _match_text(text).items():
        # 1ª ocorrência vale tudo; repetições valem 30 % (com teto)
        mult = min(1.0 + 0.3 * max(cnt - 1.0, 0.0), 1.6) if cnt >= 1.0 else cnt
        scores[cid] = weight * mult
    return scores


def _specificity_cap(total):
    """Conceito geral nunca ganha do específico que apareceu junto
    ("birthday party" não passa "balão de festa"; "carros esportivos" -> esportivo)."""
    for cid in list(total):
        below = [total[d] for d in descendants(cid) if d in total]
        if below:
            total[cid] = min(total[cid], 0.6 * max(below))
    return total


def extract(title="", tags="", description="", visual_tags="", category=None):
    """Entende o item: devolve `Understanding`.

    concepts   [(id, peso 0..1)] do mais forte ao mais fraco (até 6)
    domain     raiz do conceito principal (ou a da categoria, se nada casou)
    families   famílias dos conceitos (profundidade 1), sem repetir
    confidence 0..1 — quanta evidência de texto existiu (0.15 = só a categoria)
    source     "text" | "category" | "none"
    """
    if isinstance(tags, (list, tuple)):
        tags = ",".join(str(t) for t in tags)
    by_source = defaultdict(list)           # conceito -> pontuações de cada fonte de TEXTO
    for text, key in ((title, "title"), (tags, "tags"), (description, "description")):
        if text:
            for cid, s in _source_scores(text, SOURCE_WEIGHT[key]).items():
                by_source[cid].append(s)
    total = defaultdict(float)
    for cid, parts in by_source.items():
        parts.sort(reverse=True)
        total[cid] = parts[0] + TEXT_CORROBORATION * sum(parts[1:])
    for raw in str(visual_tags or "").split(","):
        label = normalize(raw)
        if not label or label in _APPEARANCE:
            continue
        forced = VISUAL_LABEL_OVERRIDES.get(label)
        if forced:
            total[forced] += SOURCE_WEIGHT["visual"]
        else:
            for cid, s in _source_scores(label, SOURCE_WEIGHT["visual"]).items():
                total[cid] += s

    if total:
        _specificity_cap(total)
        if any(c not in SETTINGS and TAXONOMY[c].depth > 0 for c in total):
            for c in total:
                if c in SETTINGS:
                    total[c] *= SETTING_DAMP
        ranked = sorted(total.items(), key=lambda x: (-x[1], x[0]))
        top = ranked[0][1]
        picked = [(c, w / top) for c, w in ranked if w / top >= MIN_REL_WEIGHT][:MAX_CONCEPTS]
        # um conceito geral (raiz) só fica se for o único; senão o específico basta
        specific = [(c, w) for c, w in picked if TAXONOMY[c].depth > 0]
        if specific:
            picked = specific
        concepts = [(c, round(w, 2)) for c, w in picked]
        fams = []
        for c, _w in concepts:
            f = family_of(c)
            if f and f not in fams:
                fams.append(f)
        conf = round(min(1.0, 0.35 + 0.65 * min(top, 1.6) / 1.6), 2)
        return Understanding(concepts, TAXONOMY[concepts[0][0]].root, fams, conf, "text")

    root = CATEGORY_ROOT.get(category or "")
    if root:
        return Understanding([], root, [], 0.15, "category")
    return Understanding([], None, [], 0.0, "none")


# ---------------------------------------------------------------------------
# comparação de itens
# ---------------------------------------------------------------------------

def _pairs(x):
    if isinstance(x, Understanding):
        return list(x.concepts)
    return list(x or [])


def similarity(a, b):
    """Parecença 0..1 entre dois conjuntos de conceitos (Understanding ou lista).

    Média simétrica: para cada conceito de A, o melhor parentesco com algum de
    B (ponderado pelos pesos); idem de B para A. Domínios diferentes -> 0.
    """
    pa, pb = _pairs(a), _pairs(b)
    if not pa or not pb:
        return 0.0

    def one_way(x, y):
        num = den = 0.0
        for cx, wx in x:
            best = max(relation(cx, cy) * wy for cy, wy in y)
            num += wx * best
            den += wx
        return num / den if den else 0.0

    return round((one_way(pa, pb) + one_way(pb, pa)) / 2.0, 4)


# ---------------------------------------------------------------------------
# gravação / leitura (a Parte 3B guarda estas strings no banco)
# ---------------------------------------------------------------------------

def encode(u):
    """"carro:1.0,estrada:0.55" (cabe em 120 caracteres: 6 conceitos)."""
    return ",".join("%s:%s" % (c, ("%.2f" % w).rstrip("0").rstrip(".") or "0") for c, w in u.concepts)


def decode(text):
    out = []
    for part in str(text or "").split(","):
        if ":" not in part:
            continue
        c, _, w = part.partition(":")
        c = c.strip()
        if c in TAXONOMY:
            try:
                out.append((c, max(0.0, min(1.0, float(w)))))
            except ValueError:
                continue
    return out


def concept_tags(u):
    """Texto com os conceitos E seus ancestrais, separados por espaço e
    cercados de espaços (" carro veiculo_rodas veiculo "), pra achar por LIKE/
    FTS "todo item que é veículo de rodas" sem juntar tabelas."""
    seen = []
    for c, _w in (u.concepts if isinstance(u, Understanding) else u):
        for x in ancestors(c, include_self=True):
            if x not in seen:
                seen.append(x)
    if not seen and isinstance(u, Understanding) and u.domain:
        seen = [u.domain]
    return (" " + " ".join(seen) + " ") if seen else ""


def describe(u):
    if not u.concepts:
        return "(sem conceito claro; domínio: %s)" % (label_of(u.domain) if u.domain else "—")
    return ", ".join("%s %.0f%%" % (label_of(c), w * 100) for c, w in u.concepts)


def find_concepts(text, limit=4):
    """Conceitos citados num texto livre (consulta de busca)."""
    scores = _specificity_cap(_source_scores(text, 1.0))
    ranked = sorted(scores.items(), key=lambda x: (-x[1], x[0]))
    specific = [c for c, _ in ranked if TAXONOMY[c].depth > 0] or [c for c, _ in ranked]
    return specific[:limit]


def stats():
    return {"concepts": len(TAXONOMY), "terms": len(_TERMS),
            "roots": sum(1 for c in TAXONOMY.values() if c.depth == 0)}


def main(argv):
    if len(argv) < 2:
        print("uso: python vortex_concepts.py \"texto\" [texto2]   |   --stats   |   "
              "--reprocess [--force] [--limit N]   |   --report")
        return 0
    if argv[1] == "--stats":
        print(stats())
        return 0
    if argv[1] in ("--reprocess", "--report", "--force", "--limit"):
        # liga no banco (Parte 3B): analisa o acervo / mostra cobertura e o que falta no vocabulário
        from vortex_understand import cli
        return cli(argv[1:])
    us = []
    for t in argv[1:]:
        u = extract(title=t)
        us.append(u)
        print("%r -> %s | domínio=%s famílias=%s conf=%s" % (
            t, describe(u), u.domain, u.families, u.confidence))
    if len(us) == 2:
        print("similaridade:", similarity(us[0], us[1]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
