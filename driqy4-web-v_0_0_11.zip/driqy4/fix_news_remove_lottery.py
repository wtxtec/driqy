"""
Script de correção única: remove do banco as notícias de "resultado da
Mega-Sena/Quina/Lotofácil/..." que já tinham sido indexadas antes do
filtro existir em news_indexer.py.

Sem esse script, o filtro novo só vale pra notícias futuras — as que já
foram indexadas antes continuam aparecendo no feed até expirarem
sozinhas por NEWS_MAX_AGE_DAYS.

Como rodar (na raiz do projeto, com o venv ativado):
    python fix_news_remove_lottery.py
"""
from app import create_app
from extensions import db
from models import NewsArticle
from news_indexer import _is_lottery_result


def main():
    app = create_app()
    with app.app_context():
        removed = 0
        for article in NewsArticle.query.all():
            if _is_lottery_result(article.title, article.summary or ""):
                db.session.delete(article)
                removed += 1
        db.session.commit()
        print(f"Removida(s) {removed} notícia(s) de resultado de loteria.")


if __name__ == "__main__":
    main()
