import os
from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler

from models import utcnow
from uploads import delete_upload


def purge_expired_posts(app, db, Post):
    """Apaga do banco (e do disco) todos os posts cujo tempo de vida acabou."""
    with app.app_context():
        now = utcnow()
        expired = Post.query.filter(Post.expires_at <= now).all()
        if not expired:
            return
        for post in expired:
            for fname in post.all_media_filenames():
                delete_upload(fname)
            db.session.delete(post)
        db.session.commit()
        app.logger.info(f"[scheduler] {len(expired)} post(s) expirado(s) removido(s).")


def start_scheduler(app, db, Post):
    scheduler = BackgroundScheduler(daemon=True)
    interval = app.config.get("CLEANUP_INTERVAL_SECONDS", 20)
    scheduler.add_job(
        func=lambda: purge_expired_posts(app, db, Post),
        trigger="interval",
        seconds=interval,
        id="purge_expired_posts",
        replace_existing=True,
    )
    scheduler.add_job(
        func=lambda: purge_expired_flashes(app),
        trigger="interval", seconds=app.config.get("FLASH_PURGE_SECONDS", 60),
        id="purge_expired_flashes", replace_existing=True,
    )
    if app.config.get("CHAT_ORPHAN_CLEANUP_ENABLED"):
        from chat_cleanup import cleanup_orphan_chat_media
        scheduler.add_job(
            func=lambda: cleanup_orphan_chat_media(app, apply=True),
            trigger="interval", hours=24, id="cleanup_chat_orphans", replace_existing=True,
        )
    # visualização única: apaga do disco o que foi aberto e não fechado, e o que ninguém abriu
    scheduler.add_job(
        func=lambda: purge_stale_view_once(app),
        trigger="interval", minutes=30, id="purge_stale_view_once", replace_existing=True,
    )
    # banco de notícias temporário: apaga fichas com mais de 3 dias (não depende da rede)
    scheduler.add_job(
        func=lambda: purge_news_bank(app),
        trigger="interval", minutes=app.config.get("NEWS_BANK_PURGE_MINUTES", 60),
        id="purge_news_bank", replace_existing=True,
    )
    # avisos de virada de estação (3 dias antes e no dia); de hora em hora para recuperar o que a
    # indisponibilidade do servidor tiver perdido. Só envia a partir das 8h (Brasília) e uma vez por usuário.
    scheduler.add_job(
        func=lambda: _season_alerts(app),
        trigger="interval", minutes=60, id="season_alerts", replace_existing=True,
        next_run_time=datetime.now(),
    )
    scheduler.start()
    return scheduler


def _season_alerts(app):
    try:
        from season_alerts import run_season_alerts
        run_season_alerts(app)
    except Exception as exc:  # noqa: BLE001
        app.logger.warning(f"[estações] job falhou: {exc}")


def purge_expired_flashes(app):
    """Apaga do banco e do disco os Flashes com mais de 24h."""
    from extensions import db
    from models import Flash
    with app.app_context():
        try:
            n = 0
            for fl in Flash.query.filter(Flash.expires_at <= utcnow()).limit(500).all():
                delete_upload(fl.filename)
                db.session.delete(fl)
                n += 1
            if n:
                db.session.commit()
                app.logger.info(f"[scheduler] {n} flash(es) expirado(s) removido(s).")
            return n
        except Exception as exc:
            db.session.rollback()
            app.logger.warning(f"[flash] limpeza falhou: {exc}")


def purge_news_bank(app):
    import news_bank
    with app.app_context():
        try:
            return news_bank.maintain(app)
        except Exception as exc:
            from extensions import db
            db.session.rollback()
            app.logger.warning(f"[news_bank] manutenção agendada falhou: {exc}")


def purge_stale_view_once(app):
    """Remove a mídia de mensagens de visualização única vencidas (ver api.py::consume_view_once)."""
    from datetime import timedelta
    from models import Message, utcnow
    import api as api_mod
    with app.app_context():
        now = utcnow()
        win = timedelta(seconds=app.config.get("CHAT_VIEW_ONCE_WINDOW_SECONDS", 600))
        ttl = timedelta(seconds=app.config.get("CHAT_VIEW_ONCE_TTL_SECONDS", 14 * 86400))
        rows = Message.query.filter(Message.view_once.is_(True), Message.media_path.isnot(None)).limit(500).all()
        n = 0
        for m in rows:
            opened = m.view_once_opened_at
            if (opened is not None and now - opened > win) or (opened is None and m.created_at and now - m.created_at > ttl):
                api_mod.consume_view_once(m)
                n += 1
        if n:
            from extensions import db
            db.session.commit()
        return n
