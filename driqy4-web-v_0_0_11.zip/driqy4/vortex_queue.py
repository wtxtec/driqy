"""
Fila de indexação PROGRESSIVA do Vortex (a "fronteira" de URLs a visitar).

Problema
--------
A fronteira (`vortex_frontier`) aceitava até 500 mil URLs pendentes e cada página
visitada empurrava até 150 links para dentro dela. Uma fila nunca esvazia se entra
mais do que sai: passou de 200 mil páginas esperando, a maioria de poucos sites
gigantes, e nada nela era "o próximo passo útil".

Regras novas (todas em constantes `VORTEX_FRONTIER_*` no config.py)
-------------------------------------------------------------------
  teto global      a fila pendente nunca passa de `VORTEX_DISCOVERY_MAX_FRONTIER`.
  nível da fila    "open" (< 60 %), "tight" (60–100 %), "full" (>= 100 %):
                   aberta aceita tudo dentro do orçamento; apertada só aceita
                   links rasos e em menor número; cheia não aceita nenhum link
                   novo (a fila só anda).
  orçamento/página cada página visitada pode colocar poucos links na fila
                   (mesmo site: `SAME_HOST_PER_PAGE`; sitemap: `SITEMAP_PER_PAGE`;
                   outros sites: `OTHER_PER_PAGE`, no máximo UM link por site).
  orçamento/site   cada site tem no máximo `PER_HOST_MAX` páginas esperando. Site
                   gigante não monopoliza a fila.
  sem repetir      página visitada fica `done` por `DONE_KEEP_DAYS` dias (a URL
                   não volta enquanto a linha existir); pendente velha demais
                   (`PENDING_MAX_DAYS`) é descartada em vez de apodrecer.
  esvaziar o       `trim_step` apaga o excesso em LOTES (nada de DELETE gigante
  passivo          travando o SQLite): primeiro o que passa do orçamento de cada
                   site (sobram as páginas mais rasas e mais antigas), depois o que
                   passa do teto global (saem as mais profundas e mais novas).
                   O laço da descoberta chama isso a cada poucos segundos, então
                   200 mil viram o teto em minutos, sem parar a indexação.

A escolha da próxima página é feita por `vortex_discovery.DiscoveryCrawler._pick`
(round-robin entre sites, o menos recentemente visitado primeiro, uma página por
site por vez). Aqui ficam só as políticas, para serem testadas sem rede.
"""
import hashlib
import logging
import time
from datetime import timedelta
from urllib.parse import urlparse

from sqlalchemy import func
from sqlalchemy.exc import OperationalError

from models import VortexFrontier, utcnow

log = logging.getLogger("vortex_queue")

# valores padrão (o config.py os repete; assim testes com dict puro também funcionam)
DEFAULTS = {
    "VORTEX_DISCOVERY_MAX_FRONTIER": 20000,
    "VORTEX_FRONTIER_PER_HOST_MAX": 40,
    "VORTEX_FRONTIER_SAME_HOST_PER_PAGE": 10,
    "VORTEX_FRONTIER_SITEMAP_PER_PAGE": 40,
    "VORTEX_FRONTIER_OTHER_PER_PAGE": 16,
    "VORTEX_FRONTIER_TIGHT_RATIO": 0.6,
    "VORTEX_FRONTIER_TIGHT_FACTOR": 0.4,      # no nível "tight" os limites por página encolhem
    "VORTEX_FRONTIER_TIGHT_MAX_DEPTH": 1,     # no nível "tight" só entram links rasos
    "VORTEX_FRONTIER_TRIM_BATCH": 3000,
    "VORTEX_FRONTIER_TRIM_BUSY_SECONDS": 15,
    "VORTEX_FRONTIER_TRIM_IDLE_SECONDS": 300,
    "VORTEX_FRONTIER_PENDING_MAX_DAYS": 7,
    "VORTEX_FRONTIER_DONE_KEEP_DAYS": 30,
    "VORTEX_FRONTIER_PRUNE_BATCH": 5000,
}
_CHUNK = 400          # ids por DELETE (o SQLite limita variáveis por consulta)


def opt(cfg, name):
    value = cfg.get(name)
    return DEFAULTS[name] if value is None else value


# ---------------------------------------------------------------------------
# Nível da fila e orçamento por página (funções puras)
# ---------------------------------------------------------------------------

def level_for(pending, cfg):
    """"open" | "tight" | "full" para `pending` páginas esperando."""
    cap = max(1, int(opt(cfg, "VORTEX_DISCOVERY_MAX_FRONTIER")))
    if pending >= cap:
        return "full"
    if pending >= cap * float(opt(cfg, "VORTEX_FRONTIER_TIGHT_RATIO")):
        return "tight"
    return "open"


def _spread_key(url):
    """Ordem estável e sem viés de posição: links rasos primeiro, o resto
    espalhado por hash (a página não entrega só o menu do topo)."""
    path = urlparse(url).path.strip("/")
    depth = path.count("/") + 1 if path else 0
    return (0 if path.endswith(".xml") else 1, depth, hashlib.md5(url.encode("utf-8")).hexdigest())


def _host_of(url):
    """Mesma chave de domínio de vortex_discovery.host_key (host + porta, sem www.)."""
    netloc = urlparse(url).netloc.lower()
    return netloc[4:] if netloc.startswith("www.") else netloc


def shape_entries(cfg, host, entries, level, from_sitemap=False):
    """Aplica o orçamento da página aos links que ela achou.

    `entries`: lista de (url, depth). Devolve `(mesmo_site, outros_sites)`, cada
    uma uma lista de (url, depth) já cortada. Nível "full" devolve tudo vazio.
    """
    if level == "full":
        return [], []
    tight = level == "tight"
    factor = float(opt(cfg, "VORTEX_FRONTIER_TIGHT_FACTOR")) if tight else 1.0
    max_depth = opt(cfg, "VORTEX_FRONTIER_TIGHT_MAX_DEPTH") if tight else None
    same_cap = opt(cfg, "VORTEX_FRONTIER_SITEMAP_PER_PAGE" if from_sitemap
                   else "VORTEX_FRONTIER_SAME_HOST_PER_PAGE")
    same_cap = max(1, int(same_cap * factor))
    other_cap = max(1, int(opt(cfg, "VORTEX_FRONTIER_OTHER_PER_PAGE") * factor))

    same, other, seen = [], {}, set()
    for url, depth in entries:
        if url in seen:
            continue
        seen.add(url)
        if max_depth is not None and depth > max_depth:
            continue
        h = _host_of(url)
        if h == host:
            same.append((url, depth))
        elif h and h not in other:        # UM link por site de fora (diversidade)
            other[h] = (url, depth)
    same.sort(key=lambda e: (e[1], _spread_key(e[0])))
    other_list = sorted(other.values(), key=lambda e: _spread_key(e[0]))
    return same[:same_cap], other_list[:other_cap]


def limit_per_host(db, cfg, allowed):
    """`allowed`: {url: depth} prestes a entrar. Corta o que passaria do
    orçamento de páginas esperando por site (considera o que já está na fila)."""
    if not allowed:
        return allowed
    per_host = int(opt(cfg, "VORTEX_FRONTIER_PER_HOST_MAX"))
    by_host = {}
    for url, depth in allowed.items():
        by_host.setdefault(_host_of(url), []).append((url, depth))
    pending = {h: n for h, n in (
        db.session.query(VortexFrontier.host, func.count(VortexFrontier.id))
        .filter(VortexFrontier.status == "pending", VortexFrontier.host.in_(list(by_host)))
        .group_by(VortexFrontier.host).all())}
    kept = {}
    for host, rows in by_host.items():
        room = per_host - pending.get(host, 0)
        if room <= 0:
            continue
        rows.sort(key=lambda e: (e[1], _spread_key(e[0])))
        for url, depth in rows[:room]:
            kept[url] = depth
    return kept


# ---------------------------------------------------------------------------
# Esvaziar o passivo (em lotes) e podar o antigo
# ---------------------------------------------------------------------------

def _delete_ids(db, ids):
    """Apaga por id em pedaços pequenos; devolve quantas linhas saíram."""
    removed = 0
    for i in range(0, len(ids), _CHUNK):
        part = ids[i:i + _CHUNK]
        removed += (VortexFrontier.query.filter(VortexFrontier.id.in_(part))
                    .delete(synchronize_session=False))
        db.session.commit()
        time.sleep(0.02)                 # deixa o gravador do motor respirar
    return removed


def pending_count(db):
    return VortexFrontier.query.filter_by(status="pending").count()


def trim_step(app, db, cfg, batch=None):
    """Um passo do esvaziamento. Devolve
    `{"deleted", "per_host", "global", "stale", "pending", "level"}`.

    1. páginas esperando há mais que `PENDING_MAX_DAYS` saem;
    2. cada site mantém no máximo `PER_HOST_MAX` (ficam as mais rasas/antigas);
    3. se ainda passa do teto global, saem as mais profundas e mais novas.
    Faz no máximo `batch` exclusões por chamada — chame de novo até `deleted` = 0.
    """
    batch = int(batch or opt(cfg, "VORTEX_FRONTIER_TRIM_BATCH"))
    out = {"deleted": 0, "per_host": 0, "global": 0, "stale": 0, "pending": 0, "level": "open"}
    try:
        with app.app_context():
            budget = batch
            cutoff = utcnow() - timedelta(days=opt(cfg, "VORTEX_FRONTIER_PENDING_MAX_DAYS"))
            ids = [r[0] for r in db.session.query(VortexFrontier.id).filter(
                VortexFrontier.status == "pending", VortexFrontier.created_at < cutoff)
                .limit(budget).all()]
            if ids:
                out["stale"] = _delete_ids(db, ids)
                budget -= out["stale"]

            per_host = int(opt(cfg, "VORTEX_FRONTIER_PER_HOST_MAX"))
            if budget > 0:
                fat = (db.session.query(VortexFrontier.host, func.count(VortexFrontier.id))
                       .filter(VortexFrontier.status == "pending")
                       .group_by(VortexFrontier.host)
                       .having(func.count(VortexFrontier.id) > per_host)
                       .order_by(func.count(VortexFrontier.id).desc()).limit(40).all())
                for host, _n in fat:
                    if budget <= 0:
                        break
                    ids = [r[0] for r in db.session.query(VortexFrontier.id).filter(
                        VortexFrontier.host == host, VortexFrontier.status == "pending")
                        .order_by(VortexFrontier.depth.asc(), VortexFrontier.id.asc())
                        .offset(per_host).limit(budget).all()]
                    removed = _delete_ids(db, ids)
                    out["per_host"] += removed
                    budget -= removed

            total = pending_count(db)
            cap = int(opt(cfg, "VORTEX_DISCOVERY_MAX_FRONTIER"))
            if budget > 0 and total > cap:
                ids = [r[0] for r in db.session.query(VortexFrontier.id).filter(
                    VortexFrontier.status == "pending")
                    .order_by(VortexFrontier.depth.desc(), VortexFrontier.id.desc())
                    .limit(min(budget, total - cap)).all()]
                out["global"] = _delete_ids(db, ids)

            out["deleted"] = out["stale"] + out["per_host"] + out["global"]
            out["pending"] = pending_count(db)
            out["level"] = level_for(out["pending"], cfg)
    except OperationalError:
        db.session.rollback()          # banco ocupado: tenta no próximo passo
    except Exception:
        db.session.rollback()
        log.exception("[vortex] fila: falha ao esvaziar a fronteira")
    return out


def prune_finished(app, db, cfg):
    """Apaga, em lotes, as páginas já visitadas/falhas mais antigas que
    `DONE_KEEP_DAYS` (enquanto existem, a URL não volta pra fila)."""
    batch = int(opt(cfg, "VORTEX_FRONTIER_PRUNE_BATCH"))
    cutoff = utcnow() - timedelta(days=opt(cfg, "VORTEX_FRONTIER_DONE_KEEP_DAYS"))
    removed = 0
    try:
        with app.app_context():
            while True:
                ids = [r[0] for r in db.session.query(VortexFrontier.id).filter(
                    VortexFrontier.status.in_(("done", "failed")),
                    VortexFrontier.done_at < cutoff).limit(batch).all()]
                if not ids:
                    break
                removed += _delete_ids(db, ids)
                if len(ids) < batch:
                    break
    except Exception:
        db.session.rollback()
        log.exception("[vortex] fila: falha ao podar páginas visitadas")
    return removed


def queue_stats(app, db, cfg):
    """Retrato da fila para o painel: total, nível, maiores sites, profundidade."""
    with app.app_context():
        pending = pending_count(db)
        top = (db.session.query(VortexFrontier.host, func.count(VortexFrontier.id))
               .filter(VortexFrontier.status == "pending").group_by(VortexFrontier.host)
               .order_by(func.count(VortexFrontier.id).desc()).limit(10).all())
        hosts = (db.session.query(func.count(func.distinct(VortexFrontier.host)))
                 .filter(VortexFrontier.status == "pending").scalar() or 0)
        by_depth = (db.session.query(VortexFrontier.depth, func.count(VortexFrontier.id))
                    .filter(VortexFrontier.status == "pending").group_by(VortexFrontier.depth).all())
    return {
        "pending": pending,
        "cap": int(opt(cfg, "VORTEX_DISCOVERY_MAX_FRONTIER")),
        "level": level_for(pending, cfg),
        "hosts_waiting": hosts,
        "per_host_max": int(opt(cfg, "VORTEX_FRONTIER_PER_HOST_MAX")),
        "top_hosts": [{"host": h, "pending": n} for h, n in top],
        "by_depth": {int(d): n for d, n in by_depth},
    }


def _main():  # pragma: no cover
    import argparse
    from app import create_app
    from extensions import db
    ap = argparse.ArgumentParser(description="Fila de indexação do Vortex")
    ap.add_argument("--status", action="store_true", help="mostra o retrato da fila")
    ap.add_argument("--trim", action="store_true", help="esvazia o excesso até o orçamento")
    args = ap.parse_args()
    app = create_app()
    if args.trim:
        total = 0
        while True:
            out = trim_step(app, db, app.config)
            total += out["deleted"]
            print(f"  apagadas {total}; esperando {out['pending']} ({out['level']})", end="\r")
            if not out["deleted"]:
                break
        print(f"\nfila esvaziada: {total} páginas removidas")
        print("podadas visitadas antigas:", prune_finished(app, db, app.config))
    if args.status or not args.trim:
        print(queue_stats(app, db, app.config))


if __name__ == "__main__":  # pragma: no cover
    _main()
