# Crawler do Vortex

Indexa fotos, GIFs e vídeos da internet e mostra dentro do Vortex como se
fossem publicados por um **perfil** (ex.: @commons). Os itens ficam na tabela
`vortex_items` — **não são posts**, então nunca aparecem no feed, no perfil
dos usuários, no ranking nem nas notificações.

## Fontes
| kind | O que é | Precisa de chave? |
|---|---|---|
| `commons` | Wikimedia Commons (fotos, GIFs, vídeos livres) | não |
| `openverse` | Openverse (fotos e GIFs com licença aberta) | não — mas veja `OPENVERSE_CLIENT_ID/SECRET` abaixo |
| `nasa` | NASA Image and Video Library (fotos) | não |
| `met` | The Met, Open Access (CC0) | não |
| `artic` | Art Institute of Chicago, domínio público | não |
| `pexels` | fotos e vídeos | `PEXELS_API_KEY` |
| `pixabay` | fotos e vídeos | `PIXABAY_API_KEY` |
| `unsplash` | fotos | `UNSPLASH_ACCESS_KEY` |
| `giphy` | GIFs | `GIPHY_API_KEY` |
| `rss` | feed com `media:content`/enclosure (termo = URL) | não (respeita robots.txt) |
| `page` | página pública, lê `og:image`/`og:video` (termo = URL) | não (respeita robots.txt) |

Fontes padrão: `Config.VORTEX_DEFAULT_SOURCES` (criadas na 1ª subida; as novas
entram sozinhas nas subidas seguintes). Fontes com chave ausente ficam
"puladas" e só são tentadas de novo após 6 h — ao colocar a chave, use o botão
"Rodar" da fonte no admin pra acordá-la na hora.
Pelo admin (`/admin/vortex`, só admin) dá pra ligar/desligar, rodar uma fonte,
criar fontes novas e ver o painel do motor (itens no último minuto, fila,
próxima rodada de cada fonte). `/admin/vortex/status` devolve o mesmo em JSON.
`/admin/vortex/itens` (staff) oculta/restaura itens.

## Como a indexação roda (motor contínuo)
Antes: uma rodada a cada 30 min, uma fonte por vez, 20 itens por fonte, termos
fixos. Quando as buscas iniciais esgotavam (ou o Openverse anônimo cortava a
paginação e o crawler voltava à página 1 só pra achar duplicatas), parava.

Agora o `IngestEngine` (em `vortex_crawler.py`) roda o tempo todo:
- **despachante**: escolhe as fontes com `next_run_at` vencido e as entrega a
  `VORTEX_WORKERS` threads (8). Cada fonte se reagenda sozinha: rendendo =>
  volta em ~2 s e avança a página; esgotada/erro em página funda/3 páginas só
  com duplicatas => **troca de termo** (lista `VORTEX_EXPAND_TERMS` da categoria,
  ~30 termos por categoria, 3 voltas na lista antes de descansar 1 h); erro =>
  backoff exponencial (até `VORTEX_MAX_BACKOFF`); HTTP 429 => espera o `Retry-After`.
- **workers**: chamam a API, filtram e baixam as miniaturas em paralelo
  (`VORTEX_DOWNLOAD_WORKERS`, 16) pra calcular o dHash. Cada item pronto vai pra
  fila na hora. Intervalo mínimo por host em `VORTEX_HOST_INTERVALS` (as APIs com
  chave têm cota baixa no plano grátis).
- **gravador**: uma única thread escreve no banco, em lotes de
  `VORTEX_BATCH_SIZE` (25) itens ou a cada `VORTEX_FLUSH_SECONDS` (2 s). O estado
  de cada fonte (página, termo de expansão, erros) fica no banco: reiniciar o app
  continua de onde parou, sem reindexar o que já existe.
- Só um processo por máquina roda o motor (arquivo `instance/vortex_ingest.lock`),
  então vários workers do gunicorn não duplicam o trabalho.

Variáveis de ambiente úteis: `VORTEX_CRAWLER_ENABLED=0` (desliga),
`VORTEX_WORKERS`, `VORTEX_DOWNLOAD_WORKERS`, `OPENVERSE_CLIENT_ID` +
`OPENVERSE_CLIENT_SECRET` (app grátis em api.openverse.org: a cota anônima é
baixa e é uma das causas de "parar"), `PEXELS_API_KEY`, `PIXABAY_API_KEY`,
`UNSPLASH_ACCESS_KEY`, `GIPHY_API_KEY`.

## Descoberta de fontes: "fontes infinitas" (`vortex_discovery.py`)
A lista de fontes deixou de ser o limite. O motor vasculha a web sozinho:

1. **Sementes**: `Config.VORTEX_DISCOVERY_SEEDS`, os feeds das fontes de notícias
   e o que o admin cadastrar em `/admin/vortex/descoberta` (sites, feeds ou sitemaps).
2. **Fronteira persistente** (`vortex_frontier`): URLs a visitar; reiniciar o app
   não perde a fila e páginas já visitadas não são rebuscadas.
3. **Cada página visitada** rende:
   - imagens e vídeos (og:image, `<img>` com lazy-load/srcset, `<video>`) -> mesmo
     pipeline das outras fontes (filtros, dHash, assinatura visual, gravação em lote).
     O `alt` da imagem vira o título: é o texto que descreve aquela imagem;
   - feeds (`<link rel="alternate">`) -> viram fontes `rss` **automáticas** (origem
     "auto", relidas pelo motor, imagens extraídas até do HTML dos itens);
   - links do mesmo site -> fronteira (profundidade+1, máx. 4);
   - links para outros sites -> **domínios novos** (profundidade 0).
4. **Sitemaps**: o `Sitemap:` do robots.txt entra na fila e as tags `<image:loc>`
   viram candidatos direto.

**Diversidade**: a escolha da próxima página é round-robin entre domínios (cada
site tem seu intervalo, o `Crawl-delay` do robots.txt ou 2 s, e no máximo 60
páginas/hora). Cada site tem teto de itens (`VORTEX_DISCOVERY_MAX_ITEMS_PER_DOMAIN`,
3000): ao atingir, vira `capped` e abre espaço pros outros. Sites com 8 erros
seguidos viram `dead`.

**Regras de conduta**: robots.txt, `<meta robots noindex/noimageindex/nofollow>` e
`X-Robots-Tag` respeitados; páginas adultas (RTA / `meta rating`) e URLs com termos
bloqueados saem; denylist (`VORTEX_DOMAIN_DENYLIST`) e bloqueio manual no admin
(esconde os itens do site e desliga os feeds dele; "Liberar" desfaz).

**Segurança (SSRF)**: como o motor segue links de qualquer site, ele **só acessa
hosts públicos** (nada de 127.0.0.1, rede interna ou metadata de nuvem, nem via
redirecionamento, nem em portas incomuns). `VORTEX_ALLOW_PRIVATE_HOSTS=1` só para
laboratório. Resta a janela de DNS rebinding (o `requests` resolve de novo ao
conectar): para isolamento forte, rode o crawler num container/rede sem rota para a
rede interna.

**Atenção a direitos autorais e moderação** (decisão sua, não técnica): páginas
arbitrárias raramente declaram licença; guardamos só a URL (hotlink), o site de
origem e a página de origem, e `license` só quando a página declara
`rel="license"`. Ter a URL indexada não dá direito de uso. Para só indexar o que
declara licença aberta: `VORTEX_DISCOVERY_ONLY_LICENSED=1`. O filtro de conteúdo
adulto (RTA, meta rating, termos) reduz mas **não elimina** o risco: acompanhe os
sites novos em `/admin/vortex/descoberta` e bloqueie o que não servir.

Variáveis: `VORTEX_DISCOVERY_ENABLED=0` (desliga), `VORTEX_DISCOVERY_WORKERS`,
`VORTEX_DISCOVERY_ONLY_LICENSED`, e as demais em `config.py` (`VORTEX_DISCOVERY_*`).

## Sugestões pelo conteúdo da imagem (`vortex_vision.py`)
Antes, "Mais como este" só enxergava o TEXTO que a fonte escreveu (tags,
título, categoria, perfil). Agora a imagem pesa mais que o texto:

| Sinal | O que captura | Custo |
|---|---|---|
| Embedding CLIP (opcional) | **o que a imagem representa** (cachoeira ≈ cachoeira, mesmo com legendas diferentes) | modelo de ~600 MB |
| Assinatura de aparência (sempre) | cores, luz, layout da cena, textura (vetor de 69 números tirado de uma miniatura 64x64) | ~5 ms/imagem, só Pillow |
| dHash | quase-duplicatas | já existia |
| tags/título/categoria da fonte | texto | peso menor (0,6x; 0,3x se a imagem contradiz o texto) |

- Item novo ganha a assinatura na hora; os itens que já existiam (e o CLIP, se
  ligado) são preenchidos em segundo plano pela thread `vortex-vision`, sem
  parar a indexação. Progresso no painel `/admin/vortex` (`vision_pending`).
  Item cuja miniatura não abre fica com `vfeat = ''` (não tenta de novo); pra
  reprocessar: `UPDATE vortex_items SET vfeat = NULL WHERE vfeat = ''`.
- `visual_tags` (no detalhe da API): "azul", "escuro", "tons frios",
  "minimalista"... descrevem **a aparência**, não o conteúdo — uma parede azul
  e um céu azul ficam parecidos. Só o CLIP diz "cachoeira".
- Ligar o CLIP: `pip install sentence-transformers` e
  `VORTEX_CLIP_MODEL=clip-ViT-B-32`. O CLIP escolhe, entre os ~160 conceitos de
  `Config.VORTEX_VISUAL_CONCEPTS`, os que combinam com a imagem: entram em
  `visual_tags` (confiança ≥ 0,20), nas `tags` e, se estava em "outros", na
  categoria (confiança ≥ 0,35). Fora do vocabulário ele escolhe o conceito
  "menos errado" — por isso os limiares; acrescente conceitos à vontade.
  **Esse caminho foi testado só com um codificador de mentira**; teste o modelo
  real em algumas dezenas de imagens antes de confiar nas tags geradas.
- Requer `numpy` (índice em memória: ~11 ms por consulta com 60 mil itens
  usando a aparência; ~80 ms com CLIP). Sem numpy, cai nos sinais de texto/dHash.
- Desligar tudo: `VORTEX_VISION_ENABLED=0`.

## Controle pelo admin (`/admin/vortex/conteudo`, só web)
Pausar/retomar a indexação, velocidade (0,25x–4x), painel em tempo real, o que
foi indexado (por categoria/fonte/site/perfil) e exclusão em massa com lápide.
Detalhes e limites: `PROGRESSO_VORTEX.md` → Parte 5. Estado em `vortex_control`
(banco) + `instance/vortex_engine_stats.json` (motor, a cada 2 s) +
`instance/vortex_purge_job.json` (exclusão em andamento). Acelerar não encurta
intervalo por host, `Crawl-delay`, páginas/hora nem backoff/`Retry-After`.

## Rodar
- Automático: o `app.py` liga o motor ao subir (1º disparo ~20 s depois).
- Manual: `python vortex_crawler.py --once` (uma rodada de cada fonte, em
  paralelo), `python vortex_crawler.py --daemon` (só o motor, sem o site; imprime
  as estatísticas a cada 10 s) ou o botão "Rodar agora" no admin.

## Regras
- Só guarda URL (hotlink) + licença + atribuição + link da página original.
- Descarta: < 200 px, proporção > 4:1, nome com cara de ícone/logo, GIF > 8 MB,
  termos bloqueados (nudez/gore), vídeo que não seja mp4/webm, duplicata exata
  (sha256 da URL) e quase-duplicata (dHash, distância ≤ 4).
- Todo item novo tem o dHash calculado (antes só os 40 primeiros por rodada).
- Poda: acima de `VORTEX_MAX_ITEMS` (60 000) apaga os mais antigos (a cada 30 min).
- Categoria: a da fonte; se vazia, classificador por palavras-chave
  (`VORTEX_CATEGORY_KEYWORDS`), padrão `outros`.

## API (Bearer, prefixo `/api/v1`)
- `GET /vortex?category=&type=photo|gif|video&cursor=` — grade mista (≈30 %
  posts de usuários + itens do crawler). `category` ⇒ só crawler.
  `cursor` é opaco (ex. `p120|c4500`). Cada peça tem `source: user|crawler`.
- `GET /vortex/item/<id>` — detalhe (tags, licença, atribuição, link original).
- `GET /vortex/profile/<handle>` — perfil-robô + contagens + itens paginados.
- `GET /vortex/search?q=&category=&type=&cursor=` — busca (FTS5; LIKE se o
  SQLite não tiver FTS5). `q` >= 2 letras. Devolve `tiles`, `total`,
  `total_capped`, `has_next`, `next_cursor` (`o30`), `mode`, `relaxed`.
- `GET /vortex/item/<id>/related?cursor=` — "mais como este". O detalhe
  (`/vortex/item/<id>`) já traz a 1ª página em `related` (`?related=0` desliga).
- `GET /vortex/stats` — `{total, photos, gifs, videos, crawler_items,
  user_posts, profiles, by_category[]}` (cache de 60 s).
- `GET /vortex/categories[?category=][&all=1]` — categorias com contagem por
  tipo + bloco `types` pros chips de tipo.
- `GET /pictures` — inalterado (só posts de usuários; apps antigos).

## Busca e similares (`vortex_search.py`)
- Índice FTS5 `vortex_items_fts` criado/reindexado sozinho na subida do app;
  gatilhos mantêm em dia (inclusive na poda). À mão: `python vortex_search.py
  --reindex`. Sem FTS5 a busca cai pra LIKE automaticamente.
- Ranking: bm25 + recência. Similares: tags (Jaccard) + dHash (Hamming <= 12) +
  título + categoria; quase-duplicatas (<= 4) omitidas.
- Config (`config.py`): `VORTEX_SEARCH_MAX_RESULTS` (400),
  `VORTEX_RELATED_MAX_RESULTS` (150), `VORTEX_RELATED_CANDIDATES` (300),
  `VORTEX_STATS_TTL_SECONDS` (60), `VORTEX_PHASH_RECHECK_SECONDS` (20).

## Site web
`/pictures` (grade + busca + chips + contadores; `?q=` `?categoria=` `?tipo=`)
e `/pictures/item/<id>` (detalhe + "Mais como este"). Itens do crawler só
aparecem aqui — nunca no feed.

## Testes
`pip install pytest && python -m pytest tests -q` (HTTP simulado, sem rede).
