# Driqy — rede social com posts temporários

Base funcional de uma rede social em Python (Flask) onde o autor **pode, opcionalmente,
tornar um post temporário**, escolhendo uma duração entre 1 minuto e 1 ano. Posts sem
duração ficam no ar até o autor excluí-los. Posts temporários somem sozinhos quando o
tempo acaba (banco de dados e arquivo de mídia são apagados automaticamente). Em ambos os
casos, **o autor pode excluir o próprio post quando quiser**.

## Funcionalidades

- **Cadastro e login** de usuários (senha com hash, sessão via Flask-Login).
- **Perfis com personalização**: nome de exibição, bio, localização, foto de avatar,
  **@ editável** (troca de nome de usuário com validação de unicidade) e uma **cor de
  marca** (escolhida entre 12 opções) que aparece no nome, no avatar padrão e na borda
  esquerda de todos os posts do usuário — tudo editável em `/perfil/editar`.
- **Contas verificadas**: administradores podem conceder/remover um selo de verificação
  (✓), exibido ao lado do nome em posts, comentários, perfil, ranking e painel admin.
- **Temas visuais**: alternância entre 4 temas (Escuro, Claro, Crepúsculo, Oceano),
  salva no navegador do usuário (localStorage), sem necessidade de login.
- **Interface responsiva**: menu hambúrguer em telas pequenas, tabelas com rolagem
  horizontal, alvos de toque ampliados e layout adaptado para celulares e tablets.
- **Sistema de @ nicknames**: qualquer `@usuario` escrito em posts, comentários ou bio
  vira automaticamente um link clicável para o perfil da pessoa (só quando o usuário existe).
- **Seguir / deixar de seguir** outros perfis.
- **Curtidas**: qualquer usuário logado pode curtir/descurtir um post ativo.
- **Comentários**: comentários curtos em posts ativos, com suporte a @menções;
  eles desaparecem junto com o post quando ele expira.
- **Ranking**: página `/ranking` que classifica os usuários por uma pontuação
  combinando curtidas recebidas, comentários recebidos e número de seguidores.
  Essa pontuação é **permanente** — não zera quando os posts expiram, funcionando
  como um histórico de reputação na rede.
- **Posts com tipo**: texto, foto, vídeo ou GIF, cada um com sua própria duração (1 min a 1 ano).
- **Feed global** com os posts mais recentes que ainda não expiraram.
- **Contagem regressiva visual** (anel + texto) em cada post, atualizada em tempo real no navegador.
- **Expiração automática de verdade**: um job em background (APScheduler) roda periodicamente
  e apaga do banco (e do disco) qualquer post cujo tempo tenha acabado — não depende do
  usuário estar com a página aberta. Comentários e curtidas do post são removidos junto.
- **Painel de administração** (`/admin`):
  - Visão geral com estatísticas ampliadas: usuários totais, novos em 7 dias, contas
    verificadas, admins, banidos, posts ativos/expirados, posts publicados em 7 dias,
    curtidas e comentários totais, posts por tipo (texto/foto/vídeo/GIF) e top ranking.
  - Gestão de contas: banir/desbanir, **verificar/remover selo**, promover/remover
    admin, excluir conta.
  - Moderação de posts e de comentários individuais.
  - Acesso restrito a usuários com `is_admin = True` (o primeiro usuário cadastrado
    no sistema vira admin automaticamente).

## Como rodar

```bash
# 1. crie um ambiente virtual (recomendado)
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. instale as dependências
pip install -r requirements.txt

# 3. rode o servidor
python app.py
```

Acesse http://localhost:5000 no navegador. O banco de dados SQLite é criado
automaticamente em `instance/driqy.db` na primeira execução.

> O **primeiro usuário que você cadastrar** vira administrador automaticamente e
> passa a ver o link "Admin" no menu. Os próximos cadastros são usuários comuns.

> **Já tinha um banco de dados de uma versão anterior deste projeto?** Esta versão
> adicionou colunas novas (personalização de perfil, contadores de ranking) e tabelas
> novas (curtidas, comentários). O SQLite não cria colunas em tabelas já existentes
> sozinho, então apague `instance/driqy.db` antes de rodar `python app.py` de novo
> — um banco novo e vazio será criado automaticamente com a estrutura atualizada.

### Login com Google (opcional)

O botão "Entrar com Google" só aparece se você configurar credenciais OAuth. Passo a passo:

1. Acesse https://console.cloud.google.com/apis/credentials e crie um **ID do
   cliente OAuth** do tipo **Aplicativo da Web**.
2. Em **"Origens JavaScript autorizadas"**, adicione a URL do seu site (ex.:
   `http://localhost:5000` em desenvolvimento).
3. Em **"URIs de redirecionamento autorizados"**, adicione:
   `http://localhost:5000/login/google/callback` (troque pelo domínio real em produção).
4. Copie o **Client ID** e o **Client Secret** gerados e defina como variáveis de
   ambiente antes de rodar o app:

```bash
# Windows (cmd)
set GOOGLE_CLIENT_ID=seu-client-id.apps.googleusercontent.com
set GOOGLE_CLIENT_SECRET=seu-client-secret

# Linux/macOS
export GOOGLE_CLIENT_ID=seu-client-id.apps.googleusercontent.com
export GOOGLE_CLIENT_SECRET=seu-client-secret
```

Sem essas variáveis definidas, o site funciona normalmente — só o botão do Google
fica escondido nas telas de login e cadastro.

Se a pessoa já tinha uma conta cadastrada com o mesmo e-mail (usuário/senha), o
login com Google **vincula automaticamente** à conta existente em vez de criar uma
duplicada. Contas criadas direto pelo Google recebem uma senha aleatória interna
(a pessoa pode definir uma senha de verdade depois, pela tela "Esqueci minha senha").

## Estrutura do projeto

```
driqy/
├── app.py              # application factory, registra blueprints, filtros e inicia o scheduler
├── config.py            # configurações (durações, extensões aceitas, cores, pesos do ranking)
├── extensions.py        # instâncias do SQLAlchemy, Flask-Login e cliente OAuth (Google)
├── models.py             # User, Post, Follow, Like, Comment
├── mentions.py            # conversão de @usuario em links de perfil
├── auth.py               # cadastro, login, logout
├── main.py               # feed, posts, perfil, seguir, likes, comentários, ranking
├── admin.py               # painel administrativo
├── scheduler.py            # job em background que apaga posts expirados
├── templates/               # HTML (Jinja2)
│   └── admin/
├── static/
│   ├── css/style.css
│   ├── js/countdown.js       # contagem regressiva + toggle de comentários
│   ├── js/ui.js               # troca de tema + menu mobile
│   └── uploads/                # arquivos de mídia e avatares enviados pelos usuários
└── requirements.txt
```

## Detalhes de implementação importantes

- **Duração do post**: campo `duration_minutes` em `Post`, validado no backend entre
  `MIN_DURATION_MINUTES` (1) e `MAX_DURATION_MINUTES` (525600 = 1 ano), definidos em `config.py`.
  `expires_at` é calculado automaticamente na criação do post.
- **Por que o usuário não consegue apagar**: propositalmente **não existe rota** de exclusão
  de post para usuários comuns — apenas o job automático (`scheduler.py`) e o admin
  (`admin.delete_post`, usado para moderação) podem remover um post.
- **Limpeza automática**: `scheduler.py` usa `APScheduler` com um job de intervalo
  (`CLEANUP_INTERVAL_SECONDS`, padrão 20s) que varre `Post.expires_at <= agora`,
  apaga o arquivo de mídia do disco e remove a linha do banco.
- **Contagem regressiva**: cada card de post carrega `data-expires` e `data-duration`
  em atributos HTML; `countdown.js` atualiza um anel SVG e um rótulo de tempo a cada
  segundo, e remove o card da tela com uma animação quando chega a zero — mesmo que
  o scheduler ainda não tenha rodado nesse exato segundo.

## Próximos passos sugeridos (não incluídos nesta base)

- Upload de avatar de perfil.
- Curtidas/comentários (que também poderiam expirar).
- Notificações em tempo real (WebSocket) em vez de polling.
- Paginação "infinita" no feed com JavaScript.
- Deploy com um servidor WSGI de produção (gunicorn/uwsgi) atrás de Nginx.


## Chat (mensagens diretas)
Chat estilo WhatsApp/Telegram, feito em 15 fases (histórico e pendências em `PROGRESSO_CHAT.md`).
- **Recursos**: texto, emojis e reações, fotos/GIF, vídeo, áudio, documentos (PDF, Office, TXT, CSV, ZIP…), responder, editar, encaminhar, apagar (para mim/para todos), buscar,
  tempo real (SSE), "digitando…", entregue/lido, online/visto por último, fixar/silenciar/arquivar, chamadas de voz e vídeo (WebRTC) e histórico de chamadas.
- **Mídia é privada**: fica em `instance/uploads/chat/` e só sai por `/api/v1/messages/media/<id>` (participantes). Documentos sempre baixam como anexo. **Não há criptografia ponta a ponta.**
- **Chamadas** precisam de HTTPS (ou `localhost`) e, em redes 4G/CGNAT, de um servidor TURN: veja `COTURN.md`.
- **Servidor**: um processo com threads (`python app.py`/`run_forever.bat`). Vários workers exigem Redis para o tempo real (ver `PROGRESSO_CHAT.md`, Fase 9).
- **Limpeza de mídia órfã**: `python cleanup_chat_media.py` lista; `python cleanup_chat_media.py --apply` apaga. Job diário opcional: `CHAT_ORPHAN_CLEANUP_ENABLED=1`.
- **Testes**: `pip install -r requirements.txt pytest && python -m pytest tests -q`.

## Notícias — fase 16 (lista em 3 colunas, imagens, recomendação, categorias)

- **Layout**: `/noticias` agora é uma lista de cards iguais (4:3) — 3 colunas no
  desktop (≥1100px), 2 no tablet, 1 no celular. Mosaico antigo desligado.
- **Imagens**: o proxy `/noticias/<id>/imagem?w=480|800|1200` entrega WebP
  redimensionado (nunca amplia); o indexador troca miniaturas pela `og:image`
  e promove URLs `-300x200`/`?w=300`; URLs que quebram se corrigem sozinhas.
- **Recomendação** (`news_recommender.py`): pool por categoria, afinidade por
  assunto (termos dos títulos clicados), cobertura multi-veículo, lidas descem
  (não somem), repetições do mesmo fato descem, sem-imagem desce.
- **Categorias**: ~55 fontes (todas as categorias com várias fontes), feeds
  mistos (`NEWS_MIXED_SOURCE_CATEGORIES`), classificador com peso de título.
- **Depois de subir**: rode uma vez `python fix_news_categories.py` (recategoriza
  e promove imagens do que já está no banco). Fontes novas entram sozinhas no
  próximo start; feed que não responder só gera um aviso no log.
- `NEWS_ALLOW_NO_IMAGE = False` em `config.py` volta a esconder notícia sem capa.
