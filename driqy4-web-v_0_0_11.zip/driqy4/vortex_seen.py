"""
Livro de vistos do Vortex — "o que eu já vi não volta".

Problema que resolve: a grade só se lembrava do que a pessoa ABRIU (36 h) e da
sessão em memória (30 min). Quem rolava, saía e voltava recebia de novo as
mesmas peças, porque o ranking é determinístico em cima do mesmo acervo.

Agora o servidor lembra, POR USUÁRIO e no banco (sobrevive a reinício), de dois
níveis de "visto":

* servido (`served`)  — a peça foi entregue numa página da grade. Pode nem ter
  chegado à tela (o app pré-carrega), então a memória é curta: SERVED_BLOCK_HOURS.
* visto (`viewed`)    — o app/site confirmou que a peça ficou visível na tela
  (POST /vortex/seen), ou a pessoa abriu / curtiu a peça. Memória longa:
  VIEWED_BLOCK_DAYS.
* rejeitado (`rejected`) — "menos disso". Memória ainda mais longa
  (REJECTED_BLOCK_DAYS) e vale também para imagens QUASE IGUAIS (dHash).

Depois do bloqueio a peça não volta de uma vez: ela reentra com uma nota
reduzida que sobe aos poucos (SOFT_RAMP_DAYS), então reencontrar algo muito
antigo é possível, mas nunca no topo.

Se o acervo acabou para aquela pessoa (tudo bloqueado), a grade NÃO fica vazia:
recicla as peças vistas há mais tempo (ver `vortex_taste._recycle`).

Chaves: 'c<id>' = item do crawler, 'p<id>' = post de usuário.
"""
import re
from collections import defaultdict
from datetime import timedelta

from extensions import db
from models import VortexItem, VortexSeen, utcnow

SERVED_BLOCK_HOURS = 36.0
VIEWED_BLOCK_DAYS = 30.0
REJECTED_BLOCK_DAYS = 120.0
SOFT_RAMP_DAYS = 30.0        # depois do bloqueio: nota x0,3 -> x1,0 nesse prazo
SOFT_FLOOR = 0.3
MAX_LOAD = 8000              # linhas mais recentes carregadas por ranqueamento
MAX_KEYS_PER_CALL = 200
PRUNE_AFTER_DAYS = 150
NEAR_DUP_DISTANCE = 6        # Hamming (dHash 64 bits) pra contar como "a mesma imagem"

_key_re = re.compile(r"^[cp]\d{1,12}$")


def valid_key(key):
    return isinstance(key, str) and bool(_key_re.match(key))


def clean_keys(keys, limit=MAX_KEYS_PER_CALL):
    out, seen = [], set()
    for k in keys or []:
        if valid_key(k) and k not in seen:
            seen.add(k)
            out.append(k)
            if len(out) >= limit:
                break
    return out


# ===========================================================================
# gravação
# ===========================================================================

def _upsert(user_id, keys, viewed, rejected=False, now=None):
    """Grava/atualiza as linhas do livro. Devolve quantas peças foram tocadas.
    Nunca levanta: o livro é um auxílio, não pode derrubar a requisição."""
    keys = clean_keys(keys)
    if not keys or not user_id:
        return 0
    now = now or utcnow()
    try:
        existing = {
            r.key: r for r in VortexSeen.query.filter(
                VortexSeen.user_id == user_id, VortexSeen.key.in_(keys)).all()
        }
        for k in keys:
            row = existing.get(k)
            if row is None:
                row = VortexSeen(user_id=user_id, key=k, served_count=0, viewed_count=0,
                                 first_seen_at=now)
                db.session.add(row)
            if viewed:
                row.viewed_count = (row.viewed_count or 0) + 1
                row.last_viewed_at = now
                if row.last_served_at is None:
                    row.last_served_at = now
                    row.served_count = max(1, row.served_count or 0)
            else:
                row.served_count = (row.served_count or 0) + 1
                row.last_served_at = now
            if rejected:
                row.rejected = True
        db.session.commit()
        return len(keys)
    except Exception:
        db.session.rollback()
        return 0


def mark_served(user_id, keys, now=None):
    """O servidor entregou estas peças numa página da grade."""
    return _upsert(user_id, keys, viewed=False, now=now)


def mark_viewed(user_id, keys, rejected=False, now=None):
    """A pessoa viu (ficou visível), abriu, curtiu ou rejeitou estas peças."""
    return _upsert(user_id, keys, viewed=True, rejected=rejected, now=now)


def clear_rejected(user_id, keys):
    """Desfaz o \"menos disso\": a peça deixa de ser rejeitada (continua como vista, com o
    bloqueio normal de vista). Devolve quantas linhas mudaram. Nunca levanta."""
    keys = clean_keys(keys)
    if not keys or not user_id:
        return 0
    try:
        n = (VortexSeen.query.filter(VortexSeen.user_id == user_id, VortexSeen.key.in_(keys),
                                     VortexSeen.rejected.is_(True))
             .update({VortexSeen.rejected: False}, synchronize_session=False))
        db.session.commit()
        return n or 0
    except Exception:
        db.session.rollback()
        return 0


def key_for(item=None, post=None):
    if item is not None:
        return f"c{item.id}"
    if post is not None:
        return f"p{post.id}"
    return None


def prune(days=PRUNE_AFTER_DAYS):
    try:
        cut = utcnow() - timedelta(days=days)
        VortexSeen.query.filter(
            db.func.coalesce(VortexSeen.last_viewed_at, VortexSeen.last_served_at,
                             VortexSeen.first_seen_at) < cut
        ).delete(synchronize_session=False)
        db.session.commit()
    except Exception:
        db.session.rollback()


# ===========================================================================
# leitura / política
# ===========================================================================

class Ledger:
    """Foto do livro de um usuário, já com as regras de bloqueio aplicadas."""

    def __init__(self, rows=(), now=None):
        self.now = now or utcnow()
        self.rows = {r.key: r for r in rows}

    def __len__(self):
        return len(self.rows)

    def blocked_until(self, key):
        r = self.rows.get(key)
        if r is None:
            return None
        until = None

        def bump(t, delta):
            nonlocal until
            if t is not None:
                cand = t + delta
                until = cand if until is None or cand > until else until

        if r.rejected:
            bump(r.last_viewed_at or r.last_served_at, timedelta(days=REJECTED_BLOCK_DAYS))
        if (r.viewed_count or 0) > 0:
            bump(r.last_viewed_at, timedelta(days=VIEWED_BLOCK_DAYS))
        bump(r.last_served_at, timedelta(hours=SERVED_BLOCK_HOURS))
        return until

    def is_blocked(self, key):
        until = self.blocked_until(key)
        return until is not None and until > self.now

    def factor(self, key):
        """1.0 = nunca visto / esquecido; 0.0 = bloqueado; entre os dois = voltando."""
        until = self.blocked_until(key)
        if until is None:
            return 1.0
        if until > self.now:
            return 0.0
        ramp = (self.now - until).total_seconds() / 86400.0 / SOFT_RAMP_DAYS
        return SOFT_FLOOR + (1.0 - SOFT_FLOOR) * min(1.0, max(0.0, ramp))

    def blocked_keys(self):
        return {k for k in self.rows if self.is_blocked(k)}

    def blocked_item_ids(self):
        return {int(k[1:]) for k in self.blocked_keys() if k[0] == "c"}

    def soft_factors(self):
        """{chave: fator} só das peças que já saíram do bloqueio mas ainda pesam menos."""
        out = {}
        for k in self.rows:
            f = self.factor(k)
            if 0.0 < f < 1.0:
                out[k] = f
        return out

    def viewed_item_ids(self, rejected_only=False):
        """Itens do crawler que a pessoa viu de verdade (ainda dentro do bloqueio)."""
        ids = []
        for k, r in self.rows.items():
            if k[0] != "c" or not self.is_blocked(k):
                continue
            if rejected_only:
                if r.rejected:
                    ids.append(int(k[1:]))
            elif (r.viewed_count or 0) > 0 or r.rejected:
                ids.append(int(k[1:]))
        return ids

    def oldest_blocked(self, kind, limit):
        """Chaves ('c'/'p') bloqueadas, as vistas há MAIS tempo primeiro — usadas
        só quando o acervo novo acabou (reciclagem)."""
        def last(r):
            return r.last_viewed_at or r.last_served_at or r.first_seen_at
        rows = [r for k, r in self.rows.items() if k[0] == kind]
        rows.sort(key=last)
        return [r.key for r in rows[:limit]]


def load(user_id, now=None):
    """Carrega o livro do usuário (as MAX_LOAD linhas mais recentes)."""
    now = now or utcnow()
    if not user_id:
        return Ledger((), now)
    try:
        rows = (
            VortexSeen.query.filter(VortexSeen.user_id == user_id)
            .order_by(db.func.coalesce(VortexSeen.last_viewed_at, VortexSeen.last_served_at,
                                       VortexSeen.first_seen_at).desc())
            .limit(MAX_LOAD).all()
        )
    except Exception:
        db.session.rollback()
        rows = []
    return Ledger(rows, now)


# ===========================================================================
# imagens quase iguais às que a pessoa já viu
# ===========================================================================

def _popcount(x):
    return bin(x).count("1")


class NearIndex:
    """Índice de dHash por faixas (8 faixas de 8 bits): com distância <= 7,
    pelo menos uma faixa é idêntica (princípio da casa dos pombos), então só
    comparamos candidatos que dividem alguma faixa — nada de N x M."""

    def __init__(self, hashes=()):
        self.buckets = defaultdict(list)
        self.size = 0
        for h in hashes:
            self.add(h)

    @staticmethod
    def _bands(h):
        return [(i, (h >> (8 * i)) & 0xFF) for i in range(8)]

    def add(self, h):
        if h is None:
            return
        self.size += 1
        for band in self._bands(h):
            self.buckets[band].append(h)

    def near(self, h, distance=NEAR_DUP_DISTANCE):
        if h is None or not self.size:
            return False
        for band in self._bands(h):
            for other in self.buckets.get(band, ()):
                if _popcount(h ^ other) <= distance:
                    return True
        return False


def seen_phash_index(ledger, limit=3000):
    """Índice dos dHash das peças que a pessoa viu/abriu/rejeitou (dentro do
    bloqueio). Quem for quase igual a alguma delas não entra na grade."""
    ids = ledger.viewed_item_ids()[:limit]
    idx = NearIndex()
    if not ids:
        return idx
    try:
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            for (ph,) in (db.session.query(VortexItem.phash)
                          .filter(VortexItem.id.in_(chunk), VortexItem.phash.isnot(None)).all()):
                try:
                    idx.add(int(ph, 16))
                except (TypeError, ValueError):
                    continue
    except Exception:
        db.session.rollback()
    return idx
