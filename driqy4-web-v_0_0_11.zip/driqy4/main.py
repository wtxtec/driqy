import os
import random
import uuid
from datetime import datetime

from flask import (
    Blueprint, render_template, redirect, url_for, flash, request,
    current_app, abort, jsonify
)
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

from extensions import db
from models import User, Post, PostMedia, Follow, Like, Comment, Notification, VortexItem, create_notification, utcnow, to_brasilia
from auth import USERNAME_RE
from uploads import save_upload, delete_upload
import vortex_search as vsearch
import vortex_seen as vseen
import vortex_taste as vtaste

main_bp = Blueprint("main", __name__)


def detect_source_client():
    """
    Descobre, a partir do User-Agent da requisição, se quem publicou usou um
    iPhone/iPad, um aparelho Android ou um navegador "comum" (desktop).
    Usado só pra exibir o selo "Post via iPhone/Android", como no Twitter/X
    — não afeta nada funcional.
    """
    ua = (request.user_agent.string or "").lower()
    if "iphone" in ua or "ipad" in ua or "ipod" in ua:
        return "iphone"
    if "android" in ua:
        return "android"
    return "web"


def allowed_file(filename, post_type):
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    cfg = current_app.config
    if post_type == "photo":
        return ext in cfg["ALLOWED_IMAGE_EXT"]
    if post_type == "gif":
        return ext in cfg["ALLOWED_GIF_EXT"]
    if post_type == "video":
        return ext in cfg["ALLOWED_VIDEO_EXT"]
    return False


def detect_media_type(file):
    """
    Descobre o tipo de mídia (photo/gif/video/audio) de um arquivo enviado,
    olhando a extensão (e, quando necessário, o mimetype). Usado ao publicar
    posts com várias fotos/vídeos/áudios juntos, onde cada arquivo pode ser
    de um tipo diferente.
    Retorna None se a extensão não for permitida.

    Aceita tanto um objeto de upload (FileStorage, com .filename e
    .mimetype) quanto uma string com o nome do arquivo, por compatibilidade.
    """
    filename = getattr(file, "filename", file)
    mimetype = (getattr(file, "mimetype", "") or "").lower()
    if not filename or "." not in filename:
        return None
    ext = filename.rsplit(".", 1)[1].lower()
    cfg = current_app.config

    # extensões como .webm e .ogg são usadas tanto por vídeo quanto por
    # áudio gravado no navegador — o mimetype enviado pelo navegador é o
    # jeito confiável de diferenciar os dois nesse caso.
    if mimetype.startswith("audio/") and ext in cfg["ALLOWED_AUDIO_EXT"]:
        return "audio"
    if ext in cfg["ALLOWED_IMAGE_EXT"]:
        return "photo"
    if ext in cfg["ALLOWED_GIF_EXT"]:
        return "gif"
    if ext in cfg["ALLOWED_VIDEO_EXT"]:
        return "video"
    if ext in cfg["ALLOWED_AUDIO_EXT"]:
        return "audio"
    return None


@main_bp.route("/")
def feed():
    """Feed global: mostra tudo que ainda não expirou, mais recente primeiro."""
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login"))

    posts, has_next, next_cursor = _feed_posts_page()
    return render_template(
        "feed.html", posts=posts, has_next=has_next, next_cursor=next_cursor,
        presets=current_app.config["DURATION_PRESETS"],
        min_minutes=current_app.config["MIN_DURATION_MINUTES"],
        max_minutes=current_app.config["MAX_DURATION_MINUTES"],
    )


def _feed_posts_page(cursor_id=None):
    """
    Uma leva de posts do feed global. Paginação por CURSOR (id do último
    post já mostrado), igual ao Vortex (ver docstring de
    _vortex_tiles_page): como posts expiram e saem da consulta a qualquer
    momento, paginar por número de página faria a rolagem infinita repetir
    ou pular post conforme itens fossem expirando entre uma leva e outra.
    Ancorado no id, a próxima leva sempre continua de onde a anterior
    parou.
    """
    query = Post.query.filter(Post.expires_at > utcnow())
    if cursor_id:
        query = query.filter(Post.id < cursor_id)

    per_page = current_app.config["POSTS_PER_PAGE"]
    posts = query.order_by(Post.id.desc()).limit(per_page + 1).all()
    has_next = len(posts) > per_page
    posts = posts[:per_page]
    next_cursor = posts[-1].id if (posts and has_next) else None
    return posts, has_next, next_cursor


@main_bp.route("/api/feed/mais")
def feed_more():
    """Próxima leva de posts do feed global, usada pela rolagem infinita."""
    if not current_user.is_authenticated:
        abort(401)

    cursor_id = request.args.get("cursor", type=int)
    posts, has_next, next_cursor = _feed_posts_page(cursor_id)

    html = [render_template("_post_card_fragment.html", post=p) for p in posts]
    return jsonify({
        "posts": html,
        "has_next": has_next,
        "next_cursor": next_cursor,
    })


_VORTEX_TYPES = ("photo", "gif", "video")


def _vortex_user_tiles(post_cursor, limit, media_type):
    """Peças de posts de usuários ainda no ar (uma por post, pela primeira
    mídia visual do tipo pedido). Devolve (peças, tem_mais, último_post_id)."""
    types = (media_type,) if media_type else _VORTEX_TYPES
    has_visual_media = Post.id.in_(
        db.session.query(PostMedia.post_id).filter(PostMedia.media_type.in_(types))
    )
    query = Post.query.filter(Post.expires_at > utcnow()).filter(
        db.or_(Post.post_type.in_(types), has_visual_media)
    )
    if post_cursor:
        query = query.filter(Post.id < post_cursor)
    posts = query.order_by(Post.id.desc()).limit(limit + 1).all()
    has_more = len(posts) > limit
    posts = posts[:limit]
    tiles = []
    for post in posts:
        # carrosséis contribuem só com a primeira mídia (as demais só
        # aparecem abrindo o post)
        media = next((m for m in post.display_media if m["media_type"] in types), None)
        if media is not None:
            tiles.append({"kind": "user", "post": post, "media": media, "key": f"{post.id}-0"})
    return tiles, has_more, (posts[-1].id if posts else None)


def _vortex_tiles_page(cursor=None, category=None, media_type=None, q=None):
    """
    Uma leva de peças do Vortex. Devolve (peças, tem_próxima, próximo_cursor, info).

    Sem busca: itens do crawler e posts de usuários competem pela MESMA nota de
    gosto do usuário (vortex_taste), igual à API (`/api/v1/vortex`) — sem cota
    nem prioridade pra posts de usuários. Com `category`, só itens do crawler (posts de
    usuários não têm categoria). Com `q`: só itens do crawler, na ordem de
    relevância (sem embaralhar).

    A paginação é por CURSOR, nunca por número de página: posts expiram e saem
    da consulta, então OFFSET repetiria/pularia peças. O cursor da grade é
    composto ("p<último post>|c<último item>"); o da busca é um deslocamento
    ("o30") na lista ranqueada.
    """
    app = current_app._get_current_object()
    if q:
        offset = vsearch.parse_offset_cursor(cursor)
        res = vsearch.search_items(app, q, category=category, media_type=media_type, offset=offset)
        if offset == 0 and res["total"] and current_user.is_authenticated:
            vtaste.record(current_user.id, "search", query=q)
        tiles = [{"kind": "crawler", "item": i, "key": f"c{i.id}"} for i in res["items"]]
        return tiles, res["has_next"], res["next_cursor"], {
            "total": res["total"], "capped": res["capped"], "relaxed": res["relaxed"],
        }

    if cursor and vtaste.parse_cursor(cursor) is None:
        return _vortex_tiles_page_chronological(app, cursor, category, media_type)

    page = vtaste.ranked_page(
        app, current_user.id, cursor=cursor, category=category,
        media_type=media_type, include_users=True,
    )
    objs = vtaste.load_objects(page["keys"])
    tiles = []
    for key in page["keys"]:
        obj = objs.get(key)
        if obj is None:
            continue
        if key.startswith("c"):
            tiles.append({"kind": "crawler", "item": obj, "key": key})
        else:
            types = (media_type,) if media_type else _VORTEX_TYPES
            media = next((m for m in obj.display_media if m["media_type"] in types), None)
            if media is not None:
                tiles.append({"kind": "user", "post": obj, "media": media, "key": f"{obj.id}-0"})
    return tiles, page["has_next"], page["next_cursor"], {
        "total": None, "capped": False, "relaxed": False,
    }


def _vortex_tiles_page_chronological(app, cursor, category, media_type):
    """Caminho ANTIGO (cursor `p..|c..`): só pra rolagens já em andamento."""
    post_cursor, item_cursor = vsearch.parse_grid_cursor(cursor)
    page_size = vsearch.page_size(app)

    user_tiles, user_has_more, last_post = [], False, None
    if not category:
        user_limit = max(1, round(page_size * 0.3))
        user_tiles, user_has_more, last_post = _vortex_user_tiles(post_cursor, user_limit, media_type)

    item_limit = max(1, page_size - len(user_tiles))
    query = vsearch.item_query(category, media_type)
    if item_cursor:
        query = query.filter(VortexItem.id < item_cursor)
    items = query.order_by(VortexItem.id.desc()).limit(item_limit + 1).all()
    item_has_more = len(items) > item_limit
    items = items[:item_limit]

    tiles = user_tiles + [{"kind": "crawler", "item": i, "key": f"c{i.id}"} for i in items]
    random.shuffle(tiles)

    has_next = user_has_more or item_has_more
    next_post = last_post if last_post is not None else post_cursor
    next_item = items[-1].id if items else item_cursor
    next_cursor = vsearch.format_grid_cursor(next_post, next_item) if has_next else None
    return tiles, has_next, next_cursor, {"total": None, "capped": False, "relaxed": False}


def _vortex_filters_from_request():
    """Lê ?q= ?categoria= ?tipo= da URL (valores inválidos são ignorados)."""
    q = (request.args.get("q") or "").strip()[:80]
    if not vsearch.tokenize_query(q):
        q = ""
    valid = {slug for slug, _ in current_app.config["VORTEX_CATEGORIES"]}
    category = (request.args.get("categoria") or "").strip()
    category = category if category in valid else None
    media_type = (request.args.get("tipo") or "").strip()
    media_type = media_type if media_type in _VORTEX_TYPES else None
    return q, category, media_type


@main_bp.route("/pictures")
def pictures():
    """
    Vortex: grade estilo Pinterest com as fotos/GIFs/vídeos publicados pelos
    usuários E os itens indexados pelo crawler (publicados por "perfis" do
    Vortex). Os itens do crawler só existem aqui — nunca vão pro feed.

    Tem busca (?q=), chips de categoria (?categoria=) e de tipo (?tipo=) e o
    contador de conteúdo. A grade rola infinitamente (vortex.js busca as
    próximas levas em /api/pictures/mais conforme o usuário desce a tela).
    """
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login"))

    app = current_app._get_current_object()
    q, category, media_type = _vortex_filters_from_request()
    tiles, has_next, next_cursor, info = _vortex_tiles_page(None, category, media_type, q)

    stats = vsearch.vortex_stats(app)
    cats = vsearch.vortex_categories(app, category=category)
    categories = vsearch.vortex_categories(app)["categories"]
    return render_template(
        "pictures.html",
        tiles=tiles, has_next=has_next, next_cursor=next_cursor,
        q=q, category=category, media_type=media_type, info=info,
        stats=stats, type_counts=cats["types"], categories=categories,
        category_label=dict(app.config["VORTEX_CATEGORIES"]).get(category),
        fmt=vsearch.format_count,
        wellbeing=vtaste.wellbeing(current_user.id, app=app),
    )


@main_bp.route("/api/pictures/mais")
def pictures_more():
    """Próxima leva de peças do Vortex, usada pela rolagem infinita."""
    if not current_user.is_authenticated:
        abort(401)

    q, category, media_type = _vortex_filters_from_request()
    tiles, has_next, next_cursor, _info = _vortex_tiles_page(
        request.args.get("cursor"), category, media_type, q
    )
    html = [render_template("_picture_tile.html", tile=t) for t in tiles]
    return jsonify({"tiles": html, "has_next": has_next, "next_cursor": next_cursor,
                    "wellbeing": vtaste.wellbeing(current_user.id, app=current_app)})


@main_bp.route("/api/pictures/seen", methods=["POST"])
def pictures_seen():
    """Peças que ficaram visíveis na grade web (vortex.js manda em lote com
    sendBeacon) — entram no livro de vistos e não voltam (vortex_seen.py)."""
    if not current_user.is_authenticated:
        abort(401)
    data = request.get_json(silent=True) or {}
    keys = data.get("keys")
    if not isinstance(keys, list):
        return jsonify({"error": "keys inválido"}), 400
    return jsonify({"ok": True, "recorded": vseen.mark_viewed(current_user.id, keys)})


@main_bp.route("/api/pictures/interact", methods=["POST"])
def pictures_interact():
    """Sinal de gosto vindo da grade web (vortex.js usa sendBeacon): clique num
    post de usuário, tempo no detalhe, curtida, "menos disso". Abrir o detalhe
    de uma peça do crawler já é registrado pela própria página."""
    if not current_user.is_authenticated:
        abort(401)
    data = request.get_json(silent=True) or {}
    kind = (data.get("kind") or "open").strip()
    undo = kind == "undo_less"     # desfaz o "menos disso"
    if (kind not in vtaste.VALID_KINDS and not undo) or kind == "search":
        return jsonify({"error": "kind inválido"}), 400
    item_id, post_id = data.get("item_id"), data.get("post_id")
    if isinstance(item_id, int):
        item = VortexItem.query.get(item_id)
        if item is None:
            return jsonify({"error": "Peça não encontrada"}), 404
        recorded = (vtaste.undo_less(current_user.id, item=item) if undo
                    else vtaste.record(current_user.id, kind, item=item))
    elif isinstance(post_id, int):
        post = Post.query.get(post_id)
        if post is None:
            return jsonify({"error": "Post não encontrado"}), 404
        recorded = (vtaste.undo_less(current_user.id, post=post) if undo
                    else vtaste.record(current_user.id, kind, post=post))
    else:
        return jsonify({"error": "Informe item_id ou post_id"}), 400
    return jsonify({"ok": True, "recorded": bool(recorded)})


def _visible_vortex_item_or_404(item_id):
    item = VortexItem.query.get_or_404(item_id)
    if not item.is_active or not item.profile.is_active:
        abort(404)
    return item


@main_bp.route("/pictures/item/<int:item_id>")
def pictures_item(item_id):
    """Detalhe de uma peça do crawler: mídia grande, crédito/licença, link da
    página original e a grade \"Mais como este\" (rolagem infinita; tocar numa
    sugestão abre o detalhe dela — o botão Voltar do navegador desfaz)."""
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login"))

    app = current_app._get_current_object()
    item = _visible_vortex_item_or_404(item_id)
    # abrir o detalhe É o clique: alimenta o gosto do usuário
    vtaste.record(current_user.id, "open", item=item)
    related = vsearch.related_items(app, item)
    tiles = [{"kind": "crawler", "item": i, "key": f"c{i.id}"} for i in related["items"]]

    def safe_url(url):
        return url if (url or "").lower().startswith(("http://", "https://")) else None

    return render_template(
        "vortex_item.html",
        item=item,
        tiles=tiles, has_next=related["has_next"], next_cursor=related["next_cursor"],
        source_url=safe_url(item.source_url),
        category_label=dict(app.config["VORTEX_CATEGORIES"]).get(item.category, item.category),
    )


@main_bp.route("/api/pictures/item/<int:item_id>/mais")
def pictures_item_more(item_id):
    """Próxima leva de \"Mais como este\" (rolagem infinita da página de detalhe)."""
    if not current_user.is_authenticated:
        abort(401)
    item = _visible_vortex_item_or_404(item_id)
    related = vsearch.related_items(
        current_app._get_current_object(), item,
        offset=vsearch.parse_offset_cursor(request.args.get("cursor")),
    )
    tiles = [{"kind": "crawler", "item": i, "key": f"c{i.id}"} for i in related["items"]]
    html = [render_template("_picture_tile.html", tile=t) for t in tiles]
    return jsonify({"tiles": html, "has_next": related["has_next"], "next_cursor": related["next_cursor"]})


@main_bp.route("/api/feed/novos")
def feed_new_posts():
    """
    Usado pelo feed para inserir posts novos sozinho, sem precisar recarregar
    a página. Retorna só posts publicados depois de `since_id` e que ainda
    não expiraram, já prontos em HTML (mesmo card usado no resto do site).
    """
    since_id = request.args.get("since_id", 0, type=int)
    posts = (
        Post.query.filter(Post.expires_at > utcnow(), Post.id > since_id)
        .order_by(Post.created_at.asc())
        .limit(20)
        .all()
    )
    html = [render_template("_post_card_fragment.html", post=p) for p in posts]
    last_id = max([p.id for p in posts], default=since_id)
    return jsonify({"posts": html, "last_id": last_id})




@main_bp.route("/post/<int:post_id>")
def post_detail(post_id):
    """Link único de um post — usado para compartilhar diretamente."""
    post = Post.query.get_or_404(post_id)
    if post.is_expired:
        abort(404)
    post.views_count += 1
    db.session.commit()
    return render_template("post_detail.html", post=post)


@main_bp.route("/post/<int:post_id>/visualizar", methods=["POST"])
def register_post_view(post_id):
    """
    Registra uma "visualização" (impressão) de um post no feed.
    Uma única visualização por post por sessão de navegador, pra não inflar
    o contador toda vez que o card volta a aparecer na tela.
    """
    from flask import session

    post = Post.query.get_or_404(post_id)
    if post.is_expired:
        return jsonify({"views_count": post.views_count})

    seen = session.get("viewed_posts", [])
    if post_id not in seen:
        post.views_count += 1
        db.session.commit()
        seen.append(post_id)
        session["viewed_posts"] = seen[-500:]  # limita o tamanho guardado na sessão

    return jsonify({"views_count": post.views_count})


@main_bp.route("/post/novo", methods=["GET", "POST"])
@login_required
def create_post():
    cfg = current_app.config

    if request.method == "POST":
        post_type = request.form.get("post_type")
        text_content = (request.form.get("text_content") or "").strip()
        duration_minutes = request.form.get("duration_minutes", type=int)
        max_items = cfg.get("MAX_MEDIA_ITEMS", 10)

        if post_type not in ("text", "photo", "video", "gif", "audio", "media"):
            flash("Tipo de post inválido.", "danger")
            return redirect(url_for("main.create_post"))

        # duração é opcional: vazio/0 = post permanente (sem expiração)
        if not duration_minutes:
            duration_minutes = None

        if duration_minutes is not None and not (
            cfg["MIN_DURATION_MINUTES"] <= duration_minutes <= cfg["MAX_DURATION_MINUTES"]
        ):
            flash(
                f"A duração deve estar entre {cfg['MIN_DURATION_MINUTES']} minuto "
                f"e {cfg['MAX_DURATION_MINUTES']} minutos (1 ano).", "danger"
            )
            return redirect(url_for("main.create_post"))

        if post_type == "text":
            if not text_content:
                flash("Escreva algo para publicar um post de texto.", "danger")
                return redirect(url_for("main.create_post"))
            saved_media = []
        else:
            # aceita o campo novo (múltiplos arquivos) e, por compatibilidade,
            # o campo antigo de um único arquivo
            files = [f for f in request.files.getlist("media_files") if f and f.filename]
            if not files:
                legacy_file = request.files.get("media_file")
                if legacy_file and legacy_file.filename:
                    files = [legacy_file]

            if not files:
                flash("Selecione ao menos um arquivo para enviar.", "danger")
                return redirect(url_for("main.create_post"))

            if len(files) > max_items:
                flash(f"Você pode enviar no máximo {max_items} fotos/vídeos por post.", "danger")
                return redirect(url_for("main.create_post"))

            saved_media = []
            for file in files:
                media_type = detect_media_type(file)
                if media_type is None:
                    flash(f"Formato de arquivo não permitido: {file.filename}", "danger")
                    return redirect(url_for("main.create_post"))

                ext = secure_filename(file.filename).rsplit(".", 1)[1].lower()
                fname = save_upload(file, "post", ext)
                saved_media.append((fname, media_type))

        # o campo legado `post_type` do Post continua guardando um resumo do
        # conteúdo (usado por telas antigas de admin): o tipo único quando só
        # há um tipo de arquivo, ou "media" quando fotos e vídeos vêm juntos.
        if saved_media:
            types_present = {t for _, t in saved_media}
            stored_post_type = types_present.pop() if len(types_present) == 1 else "media"
        else:
            stored_post_type = "text"

        post = Post(
            user_id=current_user.id,
            post_type=stored_post_type,
            text_content=text_content or None,
            media_filename=saved_media[0][0] if saved_media else None,
            duration_minutes=duration_minutes,
            source_client=detect_source_client(),
        )
        db.session.add(post)
        db.session.flush()  # garante post.id antes de criar as linhas de mídia

        for position, (fname, media_type) in enumerate(saved_media):
            db.session.add(PostMedia(
                post_id=post.id, filename=fname, media_type=media_type, position=position,
            ))

        db.session.commit()

        if post.is_temporary:
            flash("Post publicado! Ele vai expirar automaticamente no tempo escolhido.", "success")
        else:
            flash("Post publicado!", "success")
        return redirect(url_for("main.feed"))

    return render_template("create_post.html", presets=cfg["DURATION_PRESETS"],
                            min_minutes=cfg["MIN_DURATION_MINUTES"],
                            max_minutes=cfg["MAX_DURATION_MINUTES"])


@main_bp.route("/u/<username>")
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    page = request.args.get("page", 1, type=int)
    pagination = (
        user.posts.filter(Post.expires_at > utcnow())
        .order_by(Post.created_at.desc())
        .paginate(page=page, per_page=current_app.config["POSTS_PER_PAGE"], error_out=False)
    )
    is_following = (
        current_user.is_authenticated and current_user.is_following(user)
    )
    return render_template(
        "profile.html", profile_user=user, posts=pagination.items,
        pagination=pagination, is_following=is_following,
        presets=current_app.config["DURATION_PRESETS"],
        min_minutes=current_app.config["MIN_DURATION_MINUTES"],
        max_minutes=current_app.config["MAX_DURATION_MINUTES"],
    )


@main_bp.route("/u/<username>/seguir", methods=["POST"])
@login_required
def follow(username):
    user = User.query.filter_by(username=username).first_or_404()
    followed_now = current_user.follow(user)
    if followed_now:
        create_notification(recipient=user, actor=current_user, kind=Notification.KIND_FOLLOW)
        db.session.commit()
        flash(f"Você agora segue @{user.username}.", "success")

    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({
            "following": True,
            "followers_count": user.followers_count,
        })

    return redirect(request.referrer or url_for("main.profile", username=username))


@main_bp.route("/u/<username>/deixar-de-seguir", methods=["POST"])
@login_required
def unfollow(username):
    user = User.query.filter_by(username=username).first_or_404()
    if current_user.unfollow(user):
        db.session.commit()
        flash(f"Você deixou de seguir @{user.username}.", "info")

    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({
            "following": False,
            "followers_count": user.followers_count,
        })

    return redirect(request.referrer or url_for("main.profile", username=username))


@main_bp.route("/u/<username>/seguidores")
def followers(username):
    """Lista de quem segue este usuário."""
    user = User.query.filter_by(username=username).first_or_404()
    page = request.args.get("page", 1, type=int)
    pagination = (
        User.query.join(Follow, Follow.follower_id == User.id)
        .filter(Follow.followed_id == user.id)
        .order_by(Follow.created_at.desc())
        .paginate(page=page, per_page=current_app.config["USERS_PER_PAGE"], error_out=False)
    )
    following_ids = set()
    if current_user.is_authenticated:
        following_ids = {
            f.followed_id for f in Follow.query.filter_by(follower_id=current_user.id).all()
        }
    return render_template(
        "user_list.html", profile_user=user, users=pagination.items, pagination=pagination,
        following_ids=following_ids, list_kind="seguidores",
        page_title=f"Seguidores de @{user.username}",
        endpoint="main.followers",
    )


@main_bp.route("/u/<username>/seguindo")
def following(username):
    """Lista de quem este usuário segue."""
    user = User.query.filter_by(username=username).first_or_404()
    page = request.args.get("page", 1, type=int)
    pagination = (
        User.query.join(Follow, Follow.followed_id == User.id)
        .filter(Follow.follower_id == user.id)
        .order_by(Follow.created_at.desc())
        .paginate(page=page, per_page=current_app.config["USERS_PER_PAGE"], error_out=False)
    )
    following_ids = set()
    if current_user.is_authenticated:
        following_ids = {
            f.followed_id for f in Follow.query.filter_by(follower_id=current_user.id).all()
        }
    return render_template(
        "user_list.html", profile_user=user, users=pagination.items, pagination=pagination,
        following_ids=following_ids, list_kind="seguindo",
        page_title=f"Quem @{user.username} segue",
        endpoint="main.following",
    )


@main_bp.route("/widgets")
@login_required
def widgets_page():
    """Painel de widgets em página própria (no celular o painel da direita não existe)."""
    return render_template("widgets_page.html")


@main_bp.route("/notificacoes")
@login_required
def notifications():
    page = request.args.get("page", 1, type=int)
    pagination = (
        Notification.query.filter_by(recipient_id=current_user.id)
        .join(User, Notification.actor_id == User.id)
        .order_by(Notification.created_at.desc())
        .paginate(page=page, per_page=current_app.config["NOTIFICATIONS_PER_PAGE"], error_out=False)
    )

    # marca como lidas todas as que aparecem nesta visita
    unread_ids = [n.id for n in pagination.items if not n.is_read]
    if unread_ids:
        Notification.query.filter(Notification.id.in_(unread_ids)).update(
            {"is_read": True}, synchronize_session=False
        )
        db.session.commit()

    return render_template("notifications.html", pagination=pagination, notifs=pagination.items)


@main_bp.route("/api/notificacoes/nao-lidas")
@login_required
def notifications_unread_count():
    """Usado pelo sino no topo para atualizar o contador periodicamente."""
    return jsonify({"unread": current_user.unread_notifications_count})


@main_bp.route("/api/notificacoes/recentes")
@login_required
def notifications_recent():
    """
    Usado pelo painel suspenso do sino e pela própria página de notificações
    para atualizar a lista sem precisar recarregar a página. Se `since_id`
    for informado, retorna só o que é mais novo que ele (usado no polling
    em tempo real); caso contrário retorna as mais recentes.
    """
    since_id = request.args.get("since_id", 0, type=int)
    query = Notification.query.filter_by(recipient_id=current_user.id).join(
        User, Notification.actor_id == User.id
    )
    if since_id:
        query = query.filter(Notification.id > since_id)
    notifs = query.order_by(Notification.created_at.desc()).limit(20).all()

    def serialize(n):
        target_url = url_for("main.profile", username=n.actor.username)
        if n.kind == Notification.KIND_SEASON:
            target_url = url_for("main.feed")
        elif n.kind != Notification.KIND_FOLLOW and n.post:
            target_url = url_for("main.post_detail", post_id=n.post.id)
            if n.kind in (Notification.KIND_COMMENT, Notification.KIND_REPLY) and n.comment:
                target_url += f"#comment-{n.comment.id}"
        return {
            "id": n.id,
            "kind": n.kind,
            "verb": n.verb,
            "actor_name": n.actor.display_label,
            "actor_username": n.actor.username,
            "actor_avatar": (
                url_for("serve_upload", filename=n.actor.avatar_filename)
                if n.actor.avatar_filename else None
            ),
            "actor_initial": n.actor.username[0].upper(),
            "actor_accent": current_app.jinja_env.filters["accent_hex"](n.actor.accent_color),
            "snippet": (n.comment.content[:80] if n.kind in (Notification.KIND_COMMENT, Notification.KIND_REPLY) and n.comment else None),
            "is_read": n.is_read,
            "created_at": to_brasilia(n.created_at).strftime("%d/%m/%Y %H:%M"),
            "target_url": target_url,
        }

    return jsonify({"notifications": [serialize(n) for n in notifs], "unread": current_user.unread_notifications_count})


@main_bp.route("/buscar")
def search():
    """Página de resultados de busca por usuários (por username, nome de exibição ou bio)."""
    q = (request.args.get("q") or "").strip()
    users = []
    if q:
        like = f"%{q}%"
        users = (
            User.query.filter(
                User.is_banned.is_(False),
                db.or_(User.username.ilike(like), User.display_name.ilike(like), User.bio.ilike(like)),
            )
            .order_by(User.username.asc())
            .limit(50)
            .all()
        )
    return render_template("search_results.html", q=q, users=users)


@main_bp.route("/api/buscar")
def search_quick():
    """Busca rápida usada no dropdown da barra de pesquisa no topo."""
    q = (request.args.get("q") or "").strip()
    results = []
    if q:
        like = f"%{q}%"
        users = (
            User.query.filter(
                User.is_banned.is_(False),
                db.or_(User.username.ilike(like), User.display_name.ilike(like)),
            )
            .order_by(User.username.asc())
            .limit(6)
            .all()
        )
        results = [{
            "username": u.username,
            "display_name": u.display_label,
            "avatar": url_for("serve_upload", filename=u.avatar_filename) if u.avatar_filename else None,
            "initial": u.username[0].upper(),
            "accent": current_app.jinja_env.filters["accent_hex"](u.accent_color),
            "profile_url": url_for("main.profile", username=u.username),
            "is_verified": u.is_verified,
            "badge_kind": u.badge_kind,
        } for u in users]
    return jsonify({"users": results})



def _replace_user_image(user, field_name, upload, prefix):
    """
    Salva uma nova imagem (avatar ou capa) enviada pela pessoa, apaga o
    arquivo antigo do disco e devolve o novo nome de arquivo.
    O corte/enquadramento (zoom e posição) já é aplicado no navegador antes
    do envio, então aqui só cuidamos de salvar e limpar o antigo.
    Retorna "invalid" se o formato não for permitido, ou None em caso de
    sucesso (ou se nenhum arquivo novo tiver sido enviado).
    """
    if not (upload and upload.filename):
        return None
    if not allowed_file(upload.filename, "photo"):
        return "invalid"

    cfg = current_app.config
    old_filename = getattr(user, field_name)
    ext = secure_filename(upload.filename).rsplit(".", 1)[1].lower()
    new_filename = save_upload(upload, "cover" if prefix == "cover" else "avatar", ext, prefix)
    setattr(user, field_name, new_filename)

    delete_upload(old_filename)
    return None




@main_bp.route("/perfil/editar", methods=["GET", "POST"])
@login_required
def edit_profile():
    cfg = current_app.config
    valid_accents = {key for key, _ in cfg["ACCENT_COLORS"]}

    if request.method == "POST":
        new_username = request.form.get("username", "").strip()
        display_name = request.form.get("display_name", "").strip()[:50]
        bio = request.form.get("bio", "").strip()[:280]
        location = request.form.get("location", "").strip()[:80]
        accent_color = request.form.get("accent_color", cfg["DEFAULT_ACCENT"])

        if accent_color not in valid_accents:
            accent_color = cfg["DEFAULT_ACCENT"]

        if new_username and new_username != current_user.username:
            if not USERNAME_RE.match(new_username):
                flash("Nome de usuário deve ter 3-20 caracteres: letras, números ou _.", "danger")
                return redirect(url_for("main.edit_profile"))
            existing = User.query.filter(
                User.username.ilike(new_username), User.id != current_user.id
            ).first()
            if existing:
                flash("Esse @ já está em uso por outra conta.", "danger")
                return redirect(url_for("main.edit_profile"))
            current_user.username = new_username

        current_user.display_name = display_name
        current_user.bio = bio
        from widgets_weather import apply_profile_location
        apply_profile_location(current_user, location, request.form.get("location_lat"),
                               request.form.get("location_lng"))
        current_user.accent_color = accent_color

        def _remove_image(field_name, remove_flag):
            if request.form.get(remove_flag) != "1":
                return
            old_filename = getattr(current_user, field_name)
            if not old_filename:
                return
            delete_upload(old_filename)
            setattr(current_user, field_name, None)

        if _replace_user_image(current_user, "avatar_filename", request.files.get("avatar_file"), "avatar") == "invalid":
            return redirect(url_for("main.edit_profile"))
        if _replace_user_image(current_user, "cover_filename", request.files.get("cover_file"), "cover") == "invalid":
            return redirect(url_for("main.edit_profile"))

        # remoção só se nenhuma imagem nova tiver sido enviada para o mesmo campo
        if not (request.files.get("avatar_file") and request.files.get("avatar_file").filename):
            _remove_image("avatar_filename", "remove_avatar")
        if not (request.files.get("cover_file") and request.files.get("cover_file").filename):
            _remove_image("cover_filename", "remove_cover")

        db.session.commit()
        flash("Perfil atualizado com sucesso!", "success")
        return redirect(url_for("main.profile", username=current_user.username))

    return render_template("edit_profile.html", accent_colors=cfg["ACCENT_COLORS"])



@main_bp.route("/post/<int:post_id>/excluir", methods=["POST"])
@login_required
def delete_own_post(post_id):
    """O autor pode apagar o próprio post quando quiser (permanente ou temporário)."""
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        abort(403)

    for fname in post.all_media_filenames():
        delete_upload(fname)
    db.session.delete(post)
    db.session.commit()

    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({"ok": True})

    flash("Post excluído.", "success")
    referrer = request.referrer or ""
    # se o clique veio da página do próprio post, ela não existe mais
    if f"/post/{post_id}" in referrer or not referrer:
        return redirect(url_for("main.feed"))
    return redirect(referrer)


@main_bp.route("/post/<int:post_id>/curtir", methods=["POST"])
@login_required
def like_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.is_expired:
        abort(404)

    existing = Like.query.filter_by(user_id=current_user.id, post_id=post.id).first()
    if existing:
        db.session.delete(existing)
        post.author.total_likes_received = max(0, post.author.total_likes_received - 1)
    else:
        db.session.add(Like(user_id=current_user.id, post_id=post.id))
        post.author.total_likes_received += 1
        create_notification(recipient=post.author, actor=current_user, kind=Notification.KIND_LIKE, post=post)

    db.session.commit()

    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({"liked": existing is None, "likes_count": post.likes_count})

    return redirect(request.referrer or url_for("main.feed"))


@main_bp.route("/post/<int:post_id>/comentar", methods=["POST"])
@login_required
def comment_post(post_id):
    post = Post.query.get_or_404(post_id)
    is_ajax = request.headers.get("X-Requested-With") == "fetch"
    if post.is_expired:
        abort(404)

    content = (request.form.get("content") or "").strip()
    max_len = current_app.config["MAX_COMMENT_LENGTH"]

    parent = None
    parent_id = request.form.get("parent_id", type=int)
    if parent_id:
        parent = Comment.query.filter_by(id=parent_id, post_id=post.id).first()
        if parent is None:
            if is_ajax:
                return jsonify({"ok": False, "error": "Esse comentário não existe mais."}), 400
            flash("Esse comentário não existe mais.", "danger")
            return redirect(request.referrer or url_for("main.feed"))

    error = None
    if not content:
        error = "Escreva algo para comentar."
    elif len(content) > max_len:
        error = f"O comentário pode ter no máximo {max_len} caracteres."

    if error:
        if is_ajax:
            return jsonify({"ok": False, "error": error}), 400
        flash(error, "danger")
        anchor = f"#comment-{parent.id}" if parent else f"#comments-{post.id}"
        return redirect((request.referrer or url_for("main.post_detail", post_id=post.id)).split("#")[0] + anchor)

    comment = Comment(post_id=post.id, user_id=current_user.id, content=content,
                       parent_id=parent.id if parent else None)
    db.session.add(comment)
    post.author.total_comments_received += 1
    db.session.flush()  # garante comment.id antes de referenciar na notificação
    if parent is not None:
        create_notification(recipient=parent.author, actor=current_user, kind=Notification.KIND_REPLY,
                             post=post, comment=comment)
    else:
        create_notification(recipient=post.author, actor=current_user, kind=Notification.KIND_COMMENT,
                             post=post, comment=comment)
    db.session.commit()

    if is_ajax:
        comment_html = render_template("_comment_fragment.html", comment=comment, post=post)
        return jsonify({
            "ok": True,
            "html": comment_html,
            "comment_id": comment.id,
            "parent_id": parent.id if parent else None,
            "comments_count": post.comments_count,
        })

    anchor = f"#comment-{parent.id}" if parent else f"#comments-{post.id}"
    return redirect((request.referrer or url_for("main.post_detail", post_id=post.id)).split("#")[0] + anchor)


@main_bp.route("/api/post/<int:post_id>/status")
def post_status(post_id):
    """Usado pelo front-end para confirmar se o post ainda está ativo."""
    post = Post.query.get_or_404(post_id)
    return jsonify({
        "expired": post.is_expired,
        "seconds_remaining": post.seconds_remaining,
    })


@main_bp.route("/api/feed/stats")
def feed_stats():
    """
    Devolve, para uma lista de posts, os números que mudam com o tempo
    (curtidas, comentários, visualizações) — usado pelo front-end pra manter
    o feed atualizado em tempo real sem precisar recarregar a página.
    """
    ids_param = request.args.get("ids", "")
    try:
        ids = [int(x) for x in ids_param.split(",") if x.strip().isdigit()]
    except ValueError:
        ids = []
    ids = ids[:60]  # limite de segurança por requisição

    if not ids:
        return jsonify({"posts": {}})

    posts = Post.query.filter(Post.id.in_(ids)).all()
    liked_ids = set()
    if current_user.is_authenticated and posts:
        liked_ids = {
            like.post_id for like in Like.query.filter(
                Like.user_id == current_user.id, Like.post_id.in_(ids)
            ).all()
        }

    data = {
        str(p.id): {
            "likes_count": p.likes_count,
            "comments_count": p.comments_count,
            "views_count": p.views_count,
            "liked": p.id in liked_ids,
            "expired": p.is_expired,
        }
        for p in posts
    }
    return jsonify({"posts": data})
