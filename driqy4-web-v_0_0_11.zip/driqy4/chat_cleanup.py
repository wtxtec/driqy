"""Fase 15 — limpeza de mídia de chat órfã.

Órfã = arquivo em UPLOAD_FOLDER/chat/** que nenhuma mensagem referencia (upload que falhou no
meio, mensagem apagada por script, banco restaurado etc.). Miniaturas `<arquivo>.thumb` valem
enquanto o vídeo dono delas valer. Só mexe em `chat/` e só em arquivos mais velhos que
`min_age_seconds` (não corre contra um upload em andamento).

Uso: `python cleanup_chat_media.py` (só lista) · `python cleanup_chat_media.py --apply` (apaga).
"""
import os
import time


def find_orphans(upload_folder, referenced, min_age_seconds=6 * 3600, now=None):
    """Devolve [(caminho_relativo, bytes)] dos órfãos. `referenced` = set de `media_path`."""
    now = time.time() if now is None else now
    root = os.path.join(upload_folder, "chat")
    out = []
    if not os.path.isdir(root):
        return out
    for dirpath, _dirs, files in os.walk(root):
        for fname in files:
            full = os.path.join(dirpath, fname)
            rel = os.path.relpath(full, upload_folder).replace(os.sep, "/")
            owner = rel[: -len(".thumb")] if rel.endswith(".thumb") else rel
            if owner in referenced:
                continue
            try:
                st = os.stat(full)
            except OSError:
                continue
            if now - st.st_mtime < min_age_seconds:
                continue
            out.append((rel, st.st_size))
    return sorted(out)


def cleanup_orphan_chat_media(app, apply=False, min_age_seconds=None):
    """Roda dentro (ou fora) de um app context. Devolve {'found', 'bytes', 'deleted'}."""
    from models import Message

    min_age = app.config.get("CHAT_ORPHAN_MIN_AGE_SECONDS", 6 * 3600) if min_age_seconds is None else min_age_seconds
    with app.app_context():
        referenced = {
            row[0] for row in Message.query.with_entities(Message.media_path)
            .filter(Message.media_path.isnot(None)).all()
        }
        orphans = find_orphans(app.config["UPLOAD_FOLDER"], referenced, min_age)
        deleted = 0
        if apply:
            root = os.path.realpath(app.config["UPLOAD_FOLDER"])
            for rel, _size in orphans:
                full = os.path.realpath(os.path.join(root, *rel.split("/")))
                if not full.startswith(os.path.join(root, "chat") + os.sep):
                    continue
                try:
                    os.remove(full)
                    deleted += 1
                except OSError:
                    pass
            # remove pastas vazias (chat/AAAA/MM)
            for dirpath, _dirs, _files in os.walk(os.path.join(root, "chat"), topdown=False):
                if dirpath != os.path.join(root, "chat") and not os.listdir(dirpath):
                    try:
                        os.rmdir(dirpath)
                    except OSError:
                        pass
        total = sum(size for _rel, size in orphans)
        app.logger.info("[chat_cleanup] %d órfão(s), %d bytes, %d apagado(s).", len(orphans), total, deleted)
        return {"found": len(orphans), "bytes": total, "deleted": deleted}
