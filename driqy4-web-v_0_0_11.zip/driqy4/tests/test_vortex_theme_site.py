"""Parte 7: o fundo do Vortex no site segue o tema (escuro = preto, claro = claro)."""
import pathlib

CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")


def _block():
    i = CSS.index("Vortex — visual Pinterest")
    return CSS[i:i + 900]


def test_vortex_does_not_force_black_in_light_theme():
    b = _block()
    assert "body.pictures-page { background: var(--bg); }" in b
    # o preto só vale sob o tema escuro
    assert '[data-theme="dark"] body.pictures-page' in b
    assert "\nbody.pictures-page {\n  background: #000;" not in b


def test_vortex_tile_background_uses_theme_token():
    assert "overflow: hidden; background: var(--surface-2);" in CSS


def test_service_worker_bumped():
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 57  # versão do cache do SW só pode subir
