"""Ping — fase 7: barra inferior flutuante em pílula (celular)."""
import pathlib

import pytest


@pytest.fixture()
def site(app):
    from extensions import db as _db
    from models import Message, User
    with app.app_context():
        ids = {}
        for name in ("ana", "beto"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            ids[name] = u.id
        _db.session.add(Message(sender_id=ids["beto"], recipient_id=ids["ana"], content="oi"))
        _db.session.commit()
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(ids["ana"])
    return c


def test_tabbar_on_every_ping_page_with_four_destinations(site):
    for url in ("/mensagens/", "/mensagens/beto"):
        html = site.get(url).get_data(as_text=True)
        assert 'id="ping-tabbar"' in html, url
        for label in ("Chats", "Contatos", "Chamadas", "Menu"):
            assert f'ping-tab-label">{label}<' in html, (url, label)
        assert 'href="/mensagens/contatos"' in html and 'href="/mensagens/chamadas"' in html
        assert 'id="ping-tab-menu"' in html and 'href="/mensagens/configuracoes"' not in html
        assert 'id="chat-badge-pingtab"' in html


def test_fragment_has_no_tabbar(site):
    frag = site.get("/mensagens/beto", headers={"X-Ping-Fragment": "1"}).get_data(as_text=True)
    assert "ping-tabbar" not in frag


def test_tabbar_hidden_in_conversation_and_desktop_by_css():
    css = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
    assert ".ping-tabbar { display: none; }" in css                       # desktop: nunca
    assert "body.ping-view-list .ping-tabbar" in css                      # celular: só na lista
    assert "body.ping-view-main .ping-tabbar" not in css


def test_still_no_driqy_chrome(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    assert "bottom-nav" not in html and 'id="chat-badge-bottomnav"' not in html


def test_chat_js_updates_tab_badge_and_sw_bumped():
    assert "chat-badge-pingtab" in pathlib.Path("static/js/chat.js").read_text(encoding="utf-8")
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 57  # versão do cache do SW só pode subir
