"""Ping — fase 5b: composer nas cores do Driqy + estado vazio com logo."""
import pathlib
import pytest

CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
BLOCK = CSS.split("fase 5b: composer + estado vazio")[1].split("Ping — fase 6b")[0]


@pytest.fixture()
def site(app):
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User(username="ana", email="ana@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
        uid = u.id
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(uid)
    return c


def test_composer_css_scoped_and_tokenized():
    for tok in ("--ping-panel", "--ping-gradient", "--ping-pattern", "--ping-on-accent"):
        assert tok in BLOCK, tok
    rules = [l for l in BLOCK.splitlines() if l.rstrip().endswith("{") and not l.startswith(" ")]
    assert all(r.startswith((".ping-mode", ".ping-empty")) for r in rules)


def test_empty_state_has_logo_and_text(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    assert "ping-empty-logo" in html and "Selecione uma conversa" in html


def test_composer_ids_untouched(site):
    # o JS do chat depende destes ids; a 5b só mexe em CSS
    html = (pathlib.Path("templates/_ping_thread_main.html")).read_text(encoding="utf-8")
    for i in ("cw-form", "cw-input", "cw-send", "cw-mic", "cw-emoji-btn", "cw-attach-btn"):
        assert f'id="{i}"' in html, i
