"""Descoberta de fontes: parser, segurança (SSRF) e um mini-internet local
com vários sites que o motor precisa encontrar sozinho."""
import hashlib
import io
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest
from PIL import Image
from sqlalchemy import text

import vortex_crawler as vc
import vortex_discovery as vd
import vortex_net
from models import (
    NewsSource, VortexCrawlSource, VortexDomain, VortexFrontier, VortexItem, VortexProfile,
)

CFG = {"VORTEX_URL_BLOCK_TERMS": ("sex", "login", "porn"), "VORTEX_DOMAIN_DENYLIST": {"facebook.com"},
       "VORTEX_DISCOVERY_MAX_IMAGES_PER_PAGE": 12, "VORTEX_DISCOVERY_MAX_LINKS_PER_PAGE": 150}


# ------------------------------------------------------------------ URLs
def test_normalize_url_and_host_key():
    assert vd.normalize_url("/a/b?utm_source=x&id=3&fbclid=z#frag", "https://WWW.Exemplo.com/x") == \
        "https://www.exemplo.com/a/b?id=3"
    assert vd.normalize_url("https://exemplo.com:443/") == "https://exemplo.com/"
    assert vd.normalize_url("https://exemplo.com:8080/p") == "https://exemplo.com:8080/p"
    assert vd.normalize_url("javascript:alert(1)") is None and vd.normalize_url("mailto:a@b.c") is None
    assert vd.host_key("https://www.exemplo.com/x") == "exemplo.com"


def test_should_follow_filters():
    assert vd.should_follow("https://a.com/galeria/ferias", CFG)
    assert not vd.should_follow("https://a.com/arquivo.pdf", CFG)
    assert not vd.should_follow("https://a.com/foto.jpg", CFG)           # imagem direta não é página
    assert not vd.should_follow("https://m.facebook.com/x", CFG)         # denylist por sufixo
    assert not vd.should_follow("https://a.com/user/login", CFG)
    assert not vd.should_follow("https://a.com/sex-tape", CFG)
    assert vd.should_follow("https://a.com/essex-county-photos", CFG)    # token inteiro, não substring


# --------------------------------------------------------------- parser
HTML = """<html><head><title>Fallback</title>
<meta property="og:title" content="Cachoeira do Sul">
<meta property="og:description" content="Fotos da cachoeira">
<meta property="og:image" content="/hero.jpg"><meta property="og:image:width" content="1200">
<meta property="og:image:height" content="800">
<meta name="keywords" content="cachoeira, natureza">
<link rel="license" href="https://creativecommons.org/licenses/by/4.0/">
<link rel="alternate" type="application/rss+xml" href="/feed.xml">
</head><body>
<img src="/pequena.jpg" width="50" height="50" alt="ícone pequeno demais">
<img data-src="/lazy.jpg" src="/placeholder.gif" alt="Cachoeira vista de cima">
<img src="/a.jpg" srcset="/a-400.jpg 400w, /a-1600.jpg 1600w, /a-800.jpg 800w" alt="curta">
<img src="data:image/gif;base64,AAAA"><img src="/logo.svg"><img src="/x/icon-menu.png">
<video src="/v.mp4" poster="/v.jpg"></video>
<a href="/p/1?utm_campaign=z">um</a> <a href="/p/1">um de novo</a> <a href="/doc.pdf">pdf</a>
<a href="https://outro.org/galeria">fora</a> <a href="/conta/login">login</a>
</body></html>"""


def test_parse_page_extracts_media_feeds_links_license():
    info = vd.parse_page(HTML, "https://site.com/g/", CFG, ("icon-",))
    urls = {m["media_url"]: m for m in info.media}
    assert "https://site.com/hero.jpg" in urls and urls["https://site.com/hero.jpg"]["width"] == 1200
    assert "https://site.com/lazy.jpg" in urls                       # data-src vence o placeholder
    assert "https://site.com/a-1600.jpg" in urls                     # maior do srcset
    assert "https://site.com/v.mp4" in urls and urls["https://site.com/v.mp4"]["media_type"] == "video"
    assert not any(k.endswith(("pequena.jpg", "logo.svg", "icon-menu.png")) or k.startswith("data:") for k in urls)
    assert urls["https://site.com/lazy.jpg"]["title"] == "Cachoeira vista de cima"   # alt descritivo
    assert urls["https://site.com/a-1600.jpg"]["title"] == "Cachoeira do Sul"        # alt curto: usa o título
    assert info.license.startswith("https://creativecommons.org")
    assert urls["https://site.com/hero.jpg"]["license"] == info.license
    assert info.feeds == ["https://site.com/feed.xml"]
    assert set(info.links) == {"https://site.com/p/1", "https://outro.org/galeria"}
    assert info.tags[:2] == ["cachoeira", "natureza"]
    assert not info.noindex and not info.adult


def test_parse_page_robots_and_adult_flags():
    base = "<html><head>{}</head><body><img src='/a.jpg' width='800' height='600'></body></html>"
    assert vd.parse_page(base.format('<meta name="robots" content="noindex, nofollow">'), "https://s.com/", CFG).noindex
    assert vd.parse_page(base.format('<meta name="robots" content="noimageindex">'), "https://s.com/", CFG).noimageindex
    assert vd.parse_page(base.format('<meta name="rating" content="RTA-5042-1996-1400-1577-RTA">'), "https://s.com/", CFG).adult
    assert vd.parse_page(base.format('<meta name="rating" content="adult">'), "https://s.com/", CFG).adult


def test_parse_sitemap_images_pages_and_index():
    xml = """<urlset xmlns:image="x"><url><loc>https://s.com/galeria</loc>
      <image:image><image:loc>https://s.com/i/1.jpg</image:loc><image:title><![CDATA[Praia ao entardecer]]></image:title></image:image>
      <image:image><image:loc>https://s.com/i/logo-x.png</image:loc></image:image></url>
      <url><loc>https://s.com/doc.pdf</loc></url><url><loc>https://s.com/p2</loc></url></urlset>"""
    pages, subs, images = vd.parse_sitemap(xml, "https://s.com/sitemap.xml", CFG, ("logo-",))
    assert pages == ["https://s.com/galeria", "https://s.com/p2"] and not subs
    assert [i["media_url"] for i in images] == ["https://s.com/i/1.jpg"]
    assert images[0]["title"] == "Praia ao entardecer" and images[0]["source_url"] == "https://s.com/galeria"
    idx = "<sitemapindex><sitemap><loc>https://s.com/s1.xml</loc></sitemap></sitemapindex>"
    assert vd.parse_sitemap(idx, "https://s.com/", CFG)[1] == ["https://s.com/s1.xml"]


# ------------------------------------------------------------ segurança
def test_ssrf_guard_blocks_private_and_odd_ports():
    for url in ("http://127.0.0.1/", "http://169.254.169.254/latest/meta-data", "http://10.1.2.3/",
                "http://[::1]/", "http://localhost/", "ftp://exemplo.com/", "http://8.8.8.8:22/"):
        with pytest.raises(vortex_net.UnsafeHost):
            vortex_net.check_url(url)
    vortex_net.check_url("https://8.8.8.8/")
    vortex_net.check_url("http://127.0.0.1:9/", allow_private=True)      # só no modo laboratório


def test_session_blocks_private_hosts_even_through_requests():
    import requests
    session = vc.make_http({"VORTEX_USER_AGENT": "t", "VORTEX_ALLOW_PRIVATE_HOSTS": False})
    with pytest.raises(vortex_net.UnsafeHost):
        session.get("http://127.0.0.1:9/x", timeout=1)
    with pytest.raises(vortex_net.UnsafeHost):
        vd.safe_fetch(session, "http://169.254.169.254/", {"VORTEX_ALLOW_PRIVATE_HOSTS": False})


# ------------------------------------------------------- mini-internet
def _noise_png(seed):
    rnd = random.Random(seed)
    small = Image.new("L", (9, 8))
    small.putdata([rnd.randrange(256) for _ in range(72)])
    buf = io.BytesIO()
    big = small.resize((320, 320), Image.Resampling.NEAREST)
    # ruído fraco: infla o arquivo acima do mínimo do crawler (5 KB) sem mudar o dHash
    big.putdata([min(255, max(0, v + rnd.randint(-2, 2))) for v in big.getdata()])
    big.save(buf, "PNG")
    return buf.getvalue()


class MiniWeb:
    """Vários 'sites' locais (cada porta é um host diferente)."""

    def __init__(self):
        self.hits, self.sites, self.servers, self.lock = [], {}, [], threading.Lock()

    def base(self, name):
        return f"http://127.0.0.1:{self.sites[name]}"

    def host(self, name):
        return f"127.0.0.1:{self.sites[name]}"

    def hits_for(self, name, path=None):
        return [h for h in self.hits if h[0] == name and (path is None or h[1] == path)]

    def close(self):
        for s in self.servers:
            s.shutdown()
            s.server_close()


def html(title, imgs=(), links=(), head=""):
    pics = "".join(f'<img src="/img/{n}.png" width="600" height="400" alt="Foto numero {n} de {title}">' for n in imgs)
    anchors = "".join(f'<a href="{l}">link</a>' for l in links)
    return ("text/html", f"<html><head><title>{title}</title>{head}</head><body>{pics}{anchors}</body></html>")


@pytest.fixture()
def web(app, db, monkeypatch):
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    mini = MiniWeb()
    # portas primeiro (as páginas referenciam {B}, {C}...), depois o conteúdo
    for name in ("A", "B", "C"):
        mini.sites[name] = 0
    ports = {}
    for name in ("A", "B", "C"):
        s = ThreadingHTTPServer(("127.0.0.1", 0), BaseHTTPRequestHandler)
        ports[name] = s.server_address[1]
        s.server_close()
    mini.sites.update(ports)
    pages_a = {
        "/": html("Site A", [1, 2], ["/p1", "/p2", "/private/x", "/noindex", "/adult", "{B}/", "/sem-saida.pdf"],
                  head='<link rel="alternate" type="application/rss+xml" href="/feed.xml">'),
        "/p1": html("Pagina 1 A", [3], ["/", "/p3", "{C}/"]),
        "/p2": html("Pagina 2 A", [4]),
        "/p3": html("Pagina 3 A", [5]),
        "/private/x": html("Privado", [90]),
        "/noindex": html("Oculta", [91], head='<meta name="robots" content="noindex">'),
        "/adult": html("Adulta", [92], head='<meta name="rating" content="RTA-5042-1996-1400-1577-RTA">'),
        "/feed.xml": ("application/rss+xml", """<?xml version="1.0"?><rss version="2.0"><channel><title>Blog A</title>
            <item><title>Post um</title><link>{base}/p1</link><description><![CDATA[<img src="{base}/img/60.png" width="600" height="400">]]></description></item>
            <item><title>Post dois</title><link>{base}/p2</link><description><![CDATA[<img src="{base}/img/61.png" width="600" height="400">]]></description></item>
            </channel></rss>"""),
        "/sitemap.xml": ("application/xml", """<urlset xmlns:image="x"><url><loc>{base}/galeria</loc>
            <image:image><image:loc>{base}/img/70.png</image:loc><image:title>Imagem do sitemap</image:title></image:image>
            </url></urlset>"""),
        "/galeria": html("Galeria", [6]),
    }
    pages_b = {"/": html("Site B", [10, 11], ["/b1", "{C}/"]), "/b1": html("B um", [12])}
    pages_c = {"/": html("Site C", [20, 21], [])}
    for name, pages, robots in (("A", pages_a, "User-agent: *\nDisallow: /private/\nSitemap: {base}/sitemap.xml\n"),
                                ("B", pages_b, ""), ("C", pages_c, "")):
        _serve(mini, name, pages, robots, ports[name])
    app.config.update(
        VORTEX_ALLOW_PRIVATE_HOSTS=True, VORTEX_DISCOVERY_ENABLED=True, VORTEX_VISION_ENABLED=False,
        VORTEX_DISCOVERY_PAGE_INTERVAL=0.0, VORTEX_DISCOVERY_WORKERS=4, VORTEX_HOST_INTERVALS={},
        VORTEX_DISCOVERY_SEEDS=[mini.base("A") + "/"], VORTEX_WORKERS=2, VORTEX_FLUSH_SECONDS=0.2,
        VORTEX_BATCH_SIZE=5, VORTEX_DOMAIN_DENYLIST=set(), VORTEX_SOURCE_MIN_DELAY=0.05,
        VORTEX_IDLE_DELAY=600,
    )
    vc._ROBOTS_CACHE.clear()
    NewsSource.query.delete()
    VortexCrawlSource.query.delete()
    db.session.commit()
    yield mini
    mini.close()


def _serve(mini, name, pages, robots, port):
    outer = mini

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            path = self.path.split("?")[0]
            with outer.lock:
                outer.hits.append((name, path))
            fmt = {"base": outer.base(name), "B": outer.base("B"), "C": outer.base("C"), "A": outer.base("A")}
            if path == "/robots.txt":
                body, ctype, code = (robots or "User-agent: *\nAllow: /\n").format(**fmt).encode(), "text/plain", 200
            elif path.startswith("/img/"):
                seed = int(hashlib.sha1((name + path).encode()).hexdigest()[:8], 16)
                body, ctype, code = _noise_png(seed), "image/png", 200
            elif path in pages:
                ctype, content = pages[path]
                body, code = content.replace("{base}", fmt["base"]).replace("{B}", fmt["B"]) \
                    .replace("{C}", fmt["C"]).replace("{A}", fmt["A"]).encode(), 200
            else:
                body, ctype, code = b"", "text/plain", 404
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(("127.0.0.1", port), H)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    mini.servers.append(server)


def _wait(predicate, timeout=40):
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if predicate():
            return True
        time.sleep(0.25)
    return False


def _scalar(db, sql):
    with db.engine.connect() as conn:
        return conn.execute(text(sql)).scalar()


def test_engine_discovers_new_sites_feeds_and_respects_the_rules(app, db, web):
    engine = vc.IngestEngine(app, db).start(0)
    try:
        assert _wait(lambda: _scalar(db, "SELECT COUNT(*) FROM vortex_items") >= 14
                     and _scalar(db, "SELECT COUNT(*) FROM vortex_crawl_sources WHERE origin='auto'") >= 1), \
            "descoberta não chegou ao esperado"
        time.sleep(1.0)
        stats = engine.stats()["discovery"]
    finally:
        engine.stop()
    db.session.expire_all()
    hosts = {d.host for d in VortexDomain.query.all()}
    assert {web.host("A"), web.host("B"), web.host("C")} <= hosts          # B e C só vieram por links
    assert VortexDomain.query.filter_by(host=web.host("B")).one().discovered_from == web.host("A")
    names = {i.source_name for i in VortexItem.query.all()}
    assert {web.host("A"), web.host("B"), web.host("C")} <= names           # itens de 3 sites diferentes
    # regras: robots.txt, noindex, página adulta e link pra PDF
    assert not web.hits_for("A", "/private/x") and not web.hits_for("A", "/sem-saida.pdf")
    urls = {i.media_url for i in VortexItem.query.all()}
    assert not any(f"/img/{n}.png" in u for n in (90, 91, 92) for u in urls if web.base("A") in u)
    assert web.hits_for("A", "/noindex")           # a página é visitada (links valem), mas nada é indexado
    # feed descoberto vira fonte automática e suas imagens (que só existem no HTML do item) entram
    feed = VortexCrawlSource.query.filter_by(origin="auto").first()
    assert feed.kind == "rss" and feed.term.endswith("/feed.xml") and feed.name.startswith("Auto")
    assert any(u.endswith("/img/60.png") for u in urls)
    # imagem declarada só no sitemap (<image:loc>)
    assert any(u.endswith("/img/70.png") for u in urls)
    # imagens vêm com a página de origem e o alt como título (o que a imagem mostra)
    sample = VortexItem.query.filter(VortexItem.media_url.like("%/img/3.png")).first()
    assert sample.source_url.endswith("/p1") and "Foto numero 3" in sample.title
    assert stats["pages_fetched"] >= 6 and stats["new_domains"] >= 2


def test_frontier_survives_restart_and_pages_are_not_refetched(app, db, web):
    engine = vc.IngestEngine(app, db).start(0)
    assert _wait(lambda: _scalar(db, "SELECT COUNT(*) FROM vortex_frontier WHERE status='done'") >= 3)
    engine.stop()
    done_before = _scalar(db, "SELECT COUNT(*) FROM vortex_frontier WHERE status='done'")
    hits_before = len(web.hits_for("A", "/p1")) + len(web.hits_for("A", "/"))
    engine2 = vc.IngestEngine(app, db).start(0)                   # reinício: sementes de novo, fila já existe
    try:
        assert _wait(lambda: _scalar(db, "SELECT COUNT(*) FROM vortex_frontier WHERE status='done'") > done_before)
    finally:
        engine2.stop()
    assert len(web.hits_for("A", "/")) <= 1 + (1 if hits_before else 0)   # "/" não é rebuscada
    assert _scalar(db, "SELECT COUNT(*) FROM vortex_frontier") == len(
        {r[0] for r in db.session.query(VortexFrontier.url).all()})        # sem URLs duplicadas


def test_block_domain_hides_items_and_stops_crawling(app, db, web):
    engine = vc.IngestEngine(app, db).start(0)
    try:
        assert _wait(lambda: _scalar(
            db, f"SELECT COUNT(*) FROM vortex_items WHERE source_name='{web.host('B')}'") >= 2)
        vd.block_domain(db, web.host("B"))
        db.session.expire_all()
        assert all(not i.is_active for i in VortexItem.query.filter_by(source_name=web.host("B")))
        assert VortexDomain.query.filter_by(host=web.host("B")).one().status == "blocked"
        assert VortexFrontier.query.filter_by(host=web.host("B"), status="pending").count() == 0
        assert vd.enqueue_urls(db, app.config, [(web.base("B") + "/novo", 1)]) == (0, 0)   # não volta
    finally:
        engine.stop()
    vd.block_domain(db, web.host("B"), blocked=False)
    assert all(i.is_active for i in VortexItem.query.filter_by(source_name=web.host("B")))


def test_round_robin_gives_small_sites_their_turn_and_caps_big_ones(app, db, web):
    # A tem 30 páginas; B e C poucas. Com teto de 6 itens por site, A "enche" e para.
    pages = {"/": html("Big", [100], [f"/n{i}" for i in range(30)])}
    pages.update({f"/n{i}": html(f"n{i}", [200 + i]) for i in range(30)})
    for srv in web.servers:
        srv.shutdown()
        srv.server_close()
    web.servers.clear()
    web.hits.clear()
    for name, pg in (("A", pages), ("B", {"/": html("B", [10], ["/b1"]), "/b1": html("b1", [11])}),
                     ("C", {"/": html("C", [20])})):
        _serve(web, name, pg, "", web.sites[name])
    app.config.update(VORTEX_DISCOVERY_MAX_ITEMS_PER_DOMAIN=6,
                      VORTEX_DISCOVERY_SEEDS=[web.base("A") + "/", web.base("B") + "/", web.base("C") + "/"])
    db.session.commit()
    engine = vc.IngestEngine(app, db).start(0)
    try:
        assert _wait(lambda: VortexDomain.query.filter_by(host=web.host("A")).first() is not None
                     and (db.session.expire_all() or True)
                     and VortexDomain.query.filter_by(host=web.host("A")).one().status == "capped"
                     and _scalar(db, f"SELECT COUNT(*) FROM vortex_items WHERE source_name='{web.host('B')}'") >= 2)
    finally:
        engine.stop()
    order = [h[0] for h in web.hits if h[1] in ("/", "/b1") or h[1].startswith("/n")]
    assert order.index("B") < 6 and order.index("C") < 8, f"B e C esperaram demais: {order[:12]}"
    assert len(web.hits_for("A")) < 30                                # A não foi varrido inteiro
    assert _scalar(db, f"SELECT COUNT(*) FROM vortex_items WHERE source_name='{web.host('C')}'") >= 1


def test_admin_pages_for_discovery(app, db, user_token):
    from models import User
    u = User.query.first()
    u.is_admin = True
    db.session.add(VortexDomain(host="exemplo.org", items_added=3))
    db.session.commit()
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(u.id)
        sess["_fresh"] = True
    page = client.get("/admin/vortex/descoberta")
    assert page.status_code == 200 and b"exemplo.org" in page.data
    resp = client.post("/admin/vortex/descoberta/sementes", data={"urls": "https://novo.example/galeria\nhttps://x.example/"},
                       follow_redirects=True)
    assert b"2 URL(s) nova(s)" in resp.data
    assert VortexFrontier.query.filter_by(host="novo.example").count() == 1
    client.post("/admin/vortex/descoberta/dominio", data={"host": "exemplo.org", "action": "bloquear"})
    assert VortexDomain.query.filter_by(host="exemplo.org").one().status == "blocked"
