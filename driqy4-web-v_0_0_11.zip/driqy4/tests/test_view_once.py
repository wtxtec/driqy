"""Visualização única (foto/vídeo/áudio) — abrir uma vez, apagar do disco, sem vazar."""
import io
import os
from datetime import timedelta

import pytest

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
MP4 = b"\x00\x00\x00\x20ftypisom" + b"\x00" * 64
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 200


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _send_once(c, h, to, data=PNG, name="a.png", mime="image/png", view_once="1", content=None):
    form = {"file": (io.BytesIO(data), name, mime)}
    if view_once is not None:
        form["view_once"] = view_once
    if content:
        form["content"] = content
    return c.post(f"/api/v1/messages/{to}", headers=h, content_type="multipart/form-data", data=form)


def _row(app, mid):
    from extensions import db as _db
    from models import Message
    with app.app_context():
        return _db.session.get(Message, mid)


def test_send_hides_media_and_caption(app, users):
    c = app.test_client()
    r = _send_once(c, users[0], "beto", content="legenda secreta")
    assert r.status_code == 200
    j = r.get_json()
    assert j["view_once"] is True and j["view_once_state"] == "unopened"
    assert j["media_url"] is None and j["caption"] is None and j["media_mime"] is None
    assert j["content"] == "📷 Foto"
    assert j["can_open_view_once"] is False  # remetente
    # o destinatário vê que pode abrir, mas continua sem URL na lista
    lst = c.get("/api/v1/messages/ana", headers=users[1]).get_json()["messages"][0]
    assert lst["can_open_view_once"] is True and lst["media_url"] is None


def test_only_media_kinds_and_needs_file(app, users):
    c = app.test_client()
    r = c.post("/api/v1/messages/beto", headers=users[0], json={"content": "oi", "view_once": "1"})
    assert r.status_code == 400
    r = _send_once(c, users[0], "beto", data=b"%PDF-1.4\n" + b"0" * 50, name="a.pdf", mime="application/pdf")
    assert r.status_code == 400


def test_open_once_then_gone(app, users):
    c = app.test_client()
    mid = _send_once(c, users[0], "beto").get_json()["id"]
    path = _row(app, mid).media_path
    # antes de abrir, nem o destinatário baixa a mídia
    assert c.get(f"/api/v1/messages/media/{mid}", headers=users[1]).status_code == 404
    # remetente não abre; terceiro não vê
    assert c.post(f"/api/v1/messages/{mid}/view-once", headers=users[0]).status_code == 403
    assert c.post(f"/api/v1/messages/{mid}/view-once", headers=users[2]).status_code == 404
    r = c.post(f"/api/v1/messages/{mid}/view-once", headers=users[1])
    assert r.status_code == 200
    url = r.get_json()["media_url"]
    assert c.get(url, headers=users[1]).status_code == 200
    assert c.get(url, headers=users[0]).status_code == 404       # remetente nunca baixa
    assert c.get(url + "?download=1", headers=users[1]).status_code == 404
    # segunda abertura: 410
    assert c.post(f"/api/v1/messages/{mid}/view-once", headers=users[1]).status_code == 410
    # fechar apaga do disco
    root = app.config["UPLOAD_FOLDER"]
    assert os.path.isfile(os.path.join(root, *path.split("/")))
    r = c.post(f"/api/v1/messages/{mid}/view-once/close", headers=users[1])
    assert r.status_code == 200
    assert r.get_json()["message"]["view_once_state"] == "opened"
    assert not os.path.isfile(os.path.join(root, *path.split("/")))
    assert c.get(url, headers=users[1]).status_code == 404
    # idempotente
    assert c.post(f"/api/v1/messages/{mid}/view-once/close", headers=users[1]).status_code == 200
    # a lista mostra "Aberta" para os dois
    for h, peer in ((users[0], "beto"), (users[1], "ana")):
        m = c.get(f"/api/v1/messages/{peer}", headers=h).get_json()["messages"][0]
        assert m["view_once_state"] == "opened" and m["can_open_view_once"] is False


def test_window_expires_media(app, users):
    from extensions import db as _db
    from models import Message, utcnow
    c = app.test_client()
    mid = _send_once(c, users[0], "beto", data=MP4, name="v.mp4", mime="video/mp4").get_json()["id"]
    url = c.post(f"/api/v1/messages/{mid}/view-once", headers=users[1]).get_json()["media_url"]
    with app.app_context():
        m = _db.session.get(Message, mid)
        m.view_once_opened_at = utcnow() - timedelta(hours=1)
        _db.session.commit()
    assert c.get(url, headers=users[1]).status_code == 410
    assert _row(app, mid).media_path is None


def test_unopened_expires_after_ttl(app, users):
    from extensions import db as _db
    from models import Message, utcnow
    c = app.test_client()
    mid = _send_once(c, users[0], "beto").get_json()["id"]
    with app.app_context():
        m = _db.session.get(Message, mid)
        m.created_at = utcnow() - timedelta(days=30)
        _db.session.commit()
    j = c.get("/api/v1/messages/ana", headers=users[1]).get_json()["messages"][0]
    assert j["view_once_state"] == "expired" and j["can_open_view_once"] is False
    assert c.post(f"/api/v1/messages/{mid}/view-once", headers=users[1]).status_code == 410
    assert _row(app, mid).media_path is None


def test_not_forwardable_nor_pinnable_and_no_thumb(app, users):
    c = app.test_client()
    form = {"file": (io.BytesIO(MP4), "v.mp4", "video/mp4"), "view_once": "1",
            "thumb": (io.BytesIO(JPEG), "t.jpg", "image/jpeg")}
    r = c.post("/api/v1/messages/beto", headers=users[0], content_type="multipart/form-data", data=form)
    mid = r.get_json()["id"]
    assert r.get_json()["media_thumb_url"] is None
    root = app.config["UPLOAD_FOLDER"]
    assert not any(f.endswith(".thumb") for _d, _s, fs in os.walk(root) for f in fs)
    # nem o destinatário nem o remetente encaminham
    for h in users[:2]:
        r = c.post(f"/api/v1/messages/{mid}/forward", headers=h, json={"usernames": ["caio"]})
        assert r.status_code == 400
    r = c.put("/api/v1/messages/beto/pin", headers=users[0], json={"message_id": mid})
    assert r.status_code == 400


def test_delete_for_all_removes_file(app, users):
    c = app.test_client()
    mid = _send_once(c, users[0], "beto").get_json()["id"]
    path = _row(app, mid).media_path
    assert c.delete(f"/api/v1/messages/{mid}?scope=all", headers=users[0]).status_code == 200
    assert not os.path.isfile(os.path.join(app.config["UPLOAD_FOLDER"], *path.split("/")))
    assert c.post(f"/api/v1/messages/{mid}/view-once", headers=users[1]).status_code == 404


def test_push_does_not_leak(app, users):
    import chat_extras as cx
    c = app.test_client()
    mid = _send_once(c, users[0], "beto", content="segredo").get_json()["id"]
    with app.app_context():
        assert cx.push_body(_row(app, mid)) == "🔒 Foto de visualização única"


def test_scheduler_purge(app, users):
    from extensions import db as _db
    from models import Message, utcnow
    from scheduler import purge_stale_view_once
    c = app.test_client()
    mid = _send_once(c, users[0], "beto").get_json()["id"]
    c.post(f"/api/v1/messages/{mid}/view-once", headers=users[1])
    with app.app_context():
        m = _db.session.get(Message, mid)
        m.view_once_opened_at = utcnow() - timedelta(hours=2)
        _db.session.commit()
    assert purge_stale_view_once(app) == 1
    assert _row(app, mid).media_path is None


# ---------------- site (HTML/JS/CSS) ----------------

def test_site_has_view_once_ui(app, users):
    from extensions import db as _db
    from models import User
    with app.app_context():
        ana = User.query.filter_by(username="ana").first().id
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(ana)
    html = c.get("/mensagens/beto").get_data(as_text=True)
    for needle in ('id="cw-once-btn"', 'id="cw-preview-once"', 'id="cw-preview-once-wrap"'):
        assert needle in html, needle
    js = open("static/js/chat-thread.js", encoding="utf-8").read()
    for needle in ("function viewOnceBlock", "function openViewOnce", "function closeViewOnce",
                   "/view-once/close", 'fd.append("view_once", "1")', "m.view_once_state"):
        assert needle in js, needle
    # visualização única nunca vai para fixar/encaminhar/copiar no menu
    assert "if (!m.view_once) act(\"➦  Encaminhar\"" in js
    css = open("static/css/style.css", encoding="utf-8").read()
    assert ".cw-once-ico" in css and ".cw-once-view" in css
