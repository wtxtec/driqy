"""Parte 3B: conceitos gravados no banco (colunas, item novo, acervo antigo, CLIP,
reclassificação de "outros", concorrência, painel admin e linha de comando)."""
import random
import threading
import time

import pytest
from sqlalchemy import text

from config import Config
import vortex_concepts as vcn
import vortex_crawler as vc
import vortex_understand as vu
import vortex_vision
from models import User, VortexItem, VortexProfile, utcnow
from test_vortex_crawler import FakeHttp, FakeResp, commons_payload, get_source
from test_vortex_quality import _thumb_router, noisy_photo, to_bytes

_n = [500000]


def mk(db, title="", tags="", description="", visual_tags="", category="outros", active=True,
       version=None, concepts=None, concept_tags=None, handle="commons"):
    """Item já gravado (como os do acervo antigo: sem conceitos, a não ser que se peça)."""
    _n[0] += 1
    prof = VortexProfile.query.filter_by(handle=handle).first()
    url = f"https://x.org/{_n[0]}/foto.jpg"
    item = VortexItem(
        profile_id=prof.id, media_type="photo", media_url=url, thumb_url=url + ".t.jpg",
        width=800, height=600, title=title, tags=tags, description=description,
        visual_tags=visual_tags or None, category=category, url_hash=vc._hash_url(url),
        is_active=active, created_at=utcnow(),
        concept_version=version, concepts=concepts, concept_tags=concept_tags,
    )
    db.session.add(item)
    db.session.commit()
    return item


def reload(db, item):
    db.session.refresh(item)
    return item


# ------------------------------------------------------------------ cálculo puro
def test_build_fields_encodes_version_and_fits_the_columns():
    fields, u = vu.build_fields("Red sports car on a road", "car,red,road", "", "", "carros")
    assert fields["concept_version"] == vcn.CONCEPTS_VERSION
    assert fields["concepts"].startswith("carro_esportivo:1")
    assert " carro_esportivo carro veiculo_rodas veiculo " in fields["concept_tags"]
    assert u.domain == "veiculo"
    assert len(fields["concepts"]) <= vu.CONCEPTS_COLUMN and len(fields["concept_tags"]) <= vu.TAGS_COLUMN
    assert vcn.decode(fields["concepts"])[0][0] == "carro_esportivo"


def test_every_possible_encoding_fits_in_the_columns():
    rnd = random.Random(7)
    ids = list(vcn.TAXONOMY)
    for _ in range(3000):
        u = vcn.Understanding([(c, rnd.random()) for c in rnd.sample(ids, 6)], None, [], 1.0, "text")
        assert len(vu._fit_concepts(vcn.encode(u))) <= vu.CONCEPTS_COLUMN
        assert len(vu.fit_tags(vcn.concept_tags(u))) <= vu.TAGS_COLUMN


def test_fit_tags_cuts_on_whole_ids_never_in_the_middle():
    text_ = " " + " ".join(f"conceito_numero_{i}" for i in range(40)) + " "
    cut = vu.fit_tags(text_, 100)
    assert len(cut) <= 100 and cut.startswith(" ") and cut.endswith(" ")
    assert all(tok in text_.split() for tok in cut.split())
    assert vu.fit_tags(" a b ", 100) == " a b " and vu.fit_tags(" " + "x" * 400 + " ", 100) == ""


def test_no_text_clue_keeps_only_the_domain_from_the_category():
    fields, u = vu.build_fields("IMG_2031", "", "", "", "carros")
    assert fields["concepts"] == "" and fields["concept_tags"] == " veiculo "
    assert u.source == "category"
    fields, u = vu.build_fields("IMG_2031", "", "", "", "outros")
    assert fields["concepts"] == "" and fields["concept_tags"] == "" and u.source == "none"
    assert fields["concept_version"] == vcn.CONCEPTS_VERSION        # "analisado, nada achado"


def test_appearance_tags_from_vision_never_become_concepts():
    # "rosa" (a cor) virava flor; "preto e branco" virava fotografia de arte
    for tag in sorted(vcn.APPEARANCE_LABELS):
        assert vcn.extract(visual_tags=tag).concepts == [], tag
    assert vcn.extract(visual_tags="rosa,claro,cachoeira").concepts[0][0] == "cachoeira"
    # mas a PALAVRA no título continua valendo ("rosa" a flor)
    assert vcn.extract(title="Rosa vermelha no jardim").concepts[0][0] == "flor"


def test_appearance_labels_cover_everything_the_vision_module_can_emit():
    rnd = random.Random(3)
    seen = set()
    for _ in range(4000):
        vec = bytes(rnd.choice((0, 0, 3, 20, 60, 120, 200, 255)) if rnd.random() < .5 else rnd.randrange(256)
                    for _ in range(vortex_vision.FEAT_DIM))
        seen.update(vortex_vision.tags_from_vec(vec))
    assert seen, "o gerador de vetores não produziu nenhuma tag"
    assert seen <= vcn.APPEARANCE_LABELS, seen - vcn.APPEARANCE_LABELS


def test_title_and_derived_tags_do_not_double_count_but_clip_does_add():
    # o crawler monta `tags` a partir do título: repetir a palavra não pode inflar o peso
    once = dict(vcn.extract(title="Red sports car on a road").concepts)
    twice = dict(vcn.extract(title="Red sports car on a road", tags="car,red,road").concepts)
    # tags que só repetem o título CONFIRMAM (+25 %), não dobram (antes: estrada 1,8 x carro 1,0)
    assert twice["carro_esportivo"] == 1.0 and twice["estrada"] < 0.9 and once["estrada"] < twice["estrada"]
    u = vcn.extract(title="Red sports car on a road", tags="car,red,road", category="carros")
    assert [c for c, _ in u.concepts][:2] == ["carro_esportivo", "estrada"] and u.domain == "veiculo"
    # o CLIP é evidência independente da imagem: soma de verdade
    base = dict(vcn.extract(title="paisagem", tags="paisagem").concepts)
    clip = dict(vcn.extract(title="cachoeira", visual_tags="cachoeira").concepts)
    assert clip["cachoeira"] == 1.0 and "cachoeira" not in base


def test_setting_alone_is_full_weight_but_yields_to_a_subject():
    assert vcn.extract(title="Praia de Copacabana").concepts[0] == ("praia", 1.0)
    u = vcn.extract(title="Casal na praia ao entardecer")
    assert u.concepts[0][0] != "praia" and u.domain == "pessoas"
    u = vcn.extract(title="Cachorro correndo na praia")
    assert u.concepts[0][0] in vcn.TAXONOMY and vcn.TAXONOMY[u.concepts[0][0]].root == "animais"


@pytest.mark.parametrize("title,expected", [
    ("Helicopter hovering over bay", "carros"), ("Ferrari at the paddock", "carros"),
    ("Violin recital", "pessoas"), ("Rotterdam harbour crane", "viagens"),
])
def test_suggest_category_follows_the_domain(title, expected):
    _f, u = vu.build_fields(title, "", "", "", "outros")
    assert vu.suggest_category(u, "outros", {s for s, _ in Config.VORTEX_CATEGORIES}) == expected


def test_suggest_category_never_touches_a_defined_category_or_weak_evidence():
    _f, u = vu.build_fields("Ferrari at the paddock", "", "", "", "natureza")
    assert vu.suggest_category(u, "natureza", None) is None            # a fonte/classificador já decidiu
    _f, u = vu.build_fields("", "", "ferrari", "", "outros")            # só descrição: confiança baixa
    assert u.confidence < vu.RECLASSIFY_MIN_CONFIDENCE and vu.suggest_category(u, "outros", None) is None
    _f, u = vu.build_fields("IMG_2031", "", "", "", "outros")
    assert vu.suggest_category(u, "outros", None) is None
    _f, u = vu.build_fields("Ferrari", "", "", "", "outros")
    assert vu.suggest_category(u, "outros", {"natureza"}) is None       # categoria não existe no Vortex


# ------------------------------------------------------------------ acervo antigo
def test_process_batch_fills_every_pending_item_and_is_idempotent(app, db):
    car = mk(db, "Ferrari at the paddock", category="carros")
    wave = mk(db, "Praia ao entardecer", category="natureza")
    junk = mk(db, "IMG_2031", category="outros")
    hidden = mk(db, "Ferrari barrada", active=False)
    valid = {s for s, _ in app.config["VORTEX_CATEGORIES"]}
    assert vu.pending_count(db) == 3
    out = vu.process_batch(app, db, 500, valid)
    assert out == {"done": 3, "with_concept": 2, "reclassified": 0}
    assert vu.process_batch(app, db, 500, valid)["done"] == 0 and vu.pending_count(db) == 0
    for it in (car, wave, junk):
        assert reload(db, it).concept_version == vcn.CONCEPTS_VERSION
    assert car.concepts.startswith("carro_esportivo:1") and " veiculo " in car.concept_tags
    assert car.concept_list[0][0] == "carro_esportivo"
    assert wave.concepts.split(":")[0] in vcn.TAXONOMY
    assert junk.concepts == "" and junk.concept_tags == ""
    assert reload(db, hidden).concept_version is None                    # inativo não entra na fila


def test_process_batch_uses_the_clip_labels_already_stored(app, db):
    it = mk(db, "IMG_2031", visual_tags="cachoeira,claro,verde", category="outros")
    vu.process_batch(app, db, 10, {s for s, _ in app.config["VORTEX_CATEGORIES"]})
    reload(db, it)
    assert it.concepts.startswith("cachoeira:1")
    assert it.category == "natureza"                                       # saiu de "outros"


def test_reclassification_only_moves_items_still_in_outros(app, db):
    a = mk(db, "Vespa parked on the street", category="outros")
    b = mk(db, "Vespa parked on the street", category="humor")            # categoria já decidida
    valid = {s for s, _ in app.config["VORTEX_CATEGORIES"]}
    out = vu.process_batch(app, db, 10, valid)
    assert out["reclassified"] == 1
    assert reload(db, a).category == "carros" and reload(db, b).category == "humor"


def test_reclassification_does_not_trample_a_category_set_meanwhile(app, db):
    it = mk(db, "Vespa parked on the street", category="outros")
    valid = {s for s, _ in app.config["VORTEX_CATEGORIES"]}
    rows = vu.fetch_pending(db, 10)
    mappings, reclass, _wc = vu.process_rows(rows, valid)
    assert reclass == {it.id: "carros"}
    db.session.execute(text("UPDATE vortex_items SET category = 'arte' WHERE id = :i"), {"i": it.id})
    db.session.commit()                                                      # o CLIP mudou antes de gravarmos
    assert vu.save(db, mappings, reclass) == 0
    assert reload(db, it).category == "arte" and it.concept_version == vcn.CONCEPTS_VERSION


def test_stale_calculation_never_overwrites_a_newer_clip_result(app, db):
    it = mk(db, "IMG_2031")
    rows = vu.fetch_pending(db, 10)
    mappings, reclass, _wc = vu.process_rows(rows, None)                   # cálculo "velho" (sem CLIP)
    it.concepts, it.concept_tags, it.concept_version = "cachoeira:1", " cachoeira paisagem_agua natureza ", vcn.CONCEPTS_VERSION
    db.session.commit()                                                      # o CLIP gravou no meio do caminho
    vu.save(db, mappings, reclass)
    assert reload(db, it).concepts == "cachoeira:1"
    vu.save(db, mappings, reclass, guard=False)                              # --force passa por cima
    assert reload(db, it).concepts == ""


def test_old_vocabulary_version_is_reprocessed(app, db, monkeypatch):
    it = mk(db, "Ferrari at the paddock", category="carros", version=1, concepts="balao:1",
            concept_tags=" balao festa pessoas ")
    done = mk(db, "Tractor", category="carros", version=vcn.CONCEPTS_VERSION, concepts="trator:1",
              concept_tags=" trator veiculo_rodas veiculo ")
    state = {}
    assert vu.pending_count(db, with_old=False) == 0 and vu.pending_count(db) == 1
    out = vu.process_batch(app, db, 10, None, state=state)
    assert out["done"] == 1 and reload(db, it).concepts.startswith("carro_esportivo")
    assert reload(db, done).concepts == "trator:1"                           # na versão atual: intocado
    assert vu.process_batch(app, db, 10, None, state=state)["done"] == 0
    assert state["old_done"] is True
    # o vocabulário mudou de novo: a mesma fila volta a andar
    monkeypatch.setattr(vcn, "CONCEPTS_VERSION", vcn.CONCEPTS_VERSION + 1)
    assert vu.pending_count(db) == 2
    assert vu.process_batch(app, db, 10, None, state={})["done"] == 2


def test_reprocess_all_with_limit_and_force(app, db):
    for i in range(7):
        mk(db, f"Ferrari number {i}", category="carros")
    out = vu.reprocess_all(app, db, limit=3, batch_size=2)
    assert out["processed"] == 3 and vu.pending_count(db) == 4
    out = vu.reprocess_all(app, db, batch_size=3)
    assert out["processed"] == 4 and vu.pending_count(db) == 0
    VortexItem.query.update({"concepts": "x:1"})                              # estraga de propósito
    db.session.commit()
    assert vu.reprocess_all(app, db)["processed"] == 0                        # já na versão: nada a fazer
    out = vu.reprocess_all(app, db, force=True, batch_size=3)
    assert out["processed"] == 7 and out["with_concept"] == 7
    assert all(i.concepts.startswith("carro_esportivo") for i in VortexItem.query.all())


def test_reprocessing_a_few_thousand_items_is_fast(app, db):
    prof = VortexProfile.query.filter_by(handle="commons").first()
    titles = ["Red sports car", "Mountain lake at dawn", "Chocolate cake", "Dog running", "IMG_2031"]
    db.session.add_all([
        VortexItem(profile_id=prof.id, media_type="photo", media_url=f"https://x.org/{i}.jpg",
                   url_hash=f"h{i:06d}", title=titles[i % 5], tags="", category="outros")
        for i in range(3000)])
    db.session.commit()
    t0 = time.monotonic()
    out = vu.reprocess_all(app, db, batch_size=500)
    assert out["processed"] == 3000 and time.monotonic() - t0 < 15


# ------------------------------------------------------------------ item novo e CLIP
def _crawl(app, db, entries, **cfg):
    for k, v in cfg.items():
        app.config[k] = v
    src = get_source(db, category=None, query="termo-sem-categoria")
    names = {e["name"]: to_bytes(noisy_photo(seed=40 + i)) for i, e in enumerate(entries)}
    http = FakeHttp({
        "https://commons.wikimedia.org/w/api.php": lambda u, k: FakeResp(
            200, json_data=commons_payload(entries, more=False)),
        "https://upload.wikimedia.org/thumb/": _thumb_router(names),
    })
    return vc.crawl_source(app, db, src, http=http)


def test_new_items_are_understood_on_insert_and_leave_outros(app, db):
    entries = [{"name": "ferrari.jpg", "title": "Ferrari at the paddock", "cats": "", "desc": ""},
               {"name": "p123.jpg", "title": "P123 sample", "cats": "", "desc": ""}]
    assert _crawl(app, db, entries) == 2
    by_name = {i.media_url.rsplit("/", 1)[-1]: i for i in VortexItem.query.all()}
    car, blank = by_name["ferrari.jpg"], by_name["p123.jpg"]
    assert car.concept_version == vcn.CONCEPTS_VERSION and car.concepts.startswith("carro_esportivo")
    assert car.category == "carros" and " veiculo " in car.concept_tags
    assert blank.concept_version == vcn.CONCEPTS_VERSION and blank.concepts == ""
    assert vu.pending_count(db) == 0                                         # nasce entendido: nada a reprocessar


def test_new_item_keeps_the_category_defined_by_the_source(app, db):
    src = get_source(db, category="humor", query="memes")
    names = {"ferrari.jpg": to_bytes(noisy_photo(seed=61))}
    http = FakeHttp({
        "https://commons.wikimedia.org/w/api.php": lambda u, k: FakeResp(
            200, json_data=commons_payload([{"name": "ferrari.jpg", "title": "Ferrari at the paddock",
                                              "cats": "", "desc": ""}], more=False)),
        "https://upload.wikimedia.org/thumb/": _thumb_router(names),
    })
    assert vc.crawl_source(app, db, src, http=http) == 1
    item = VortexItem.query.one()
    assert item.category == "humor" and item.concepts.startswith("carro_esportivo")


def test_concepts_can_be_turned_off(app, db):
    assert _crawl(app, db, [{"name": "ferrari.jpg", "title": "Ferrari at the paddock", "cats": "", "desc": ""}],
                  VORTEX_CONCEPTS_ENABLED=False) == 1
    item = VortexItem.query.one()
    assert item.concept_version is None and item.concepts is None and item.category == "outros"


def test_clip_labels_recompute_concepts_and_category(app, db):
    engine = vc.IngestEngine(app, db)
    row = type("Row", (), dict(title="IMG_2031", description="", tags="", visual_tags="escuro,rosa",
                               category="outros"))()
    res = {"visual_tags": "cachoeira,escuro,rosa"}
    engine._refresh_concepts(row, res)
    assert res["concepts"].startswith("cachoeira:1") and res["category"] == "natureza"
    assert res["concept_version"] == vcn.CONCEPTS_VERSION
    # sem CLIP ligado a configuração desliga o cálculo
    app.config["VORTEX_CONCEPTS_ENABLED"] = False
    res = {"visual_tags": "cachoeira"}
    engine._refresh_concepts(row, res)
    assert "concepts" not in res


def test_clip_save_goes_through_bulk_update_with_the_new_columns(app, db):
    it = mk(db, "IMG_2031", category="outros")
    engine = vc.IngestEngine(app, db)
    row = db.session.query(VortexItem.id, VortexItem.title, VortexItem.description, VortexItem.tags,
                           VortexItem.visual_tags, VortexItem.category).filter_by(id=it.id).one()
    res = {"id": it.id, "visual_tags": "cachoeira"}
    engine._refresh_concepts(row, res)
    engine._save_vision([res])
    reload(db, it)
    assert it.concepts.startswith("cachoeira") and it.category == "natureza" and it.visual_tags == "cachoeira"


def test_engine_loop_processes_the_backlog_and_reports_progress(app, db):
    for i in range(5):
        mk(db, f"Ferrari number {i}", category="carros")
    mk(db, "Vespa parked on the street", category="outros")
    app.config["VORTEX_CONCEPTS_IDLE_SECONDS"] = 1
    engine = vc.IngestEngine(app, db)
    th = threading.Thread(target=engine._concepts_loop, daemon=True)
    engine._concepts = th
    th.start()
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline and engine.concepts_done < 6:
        time.sleep(0.05)
    try:
        assert engine.concepts_done == 6 and engine.concepts_with == 6 and engine.concepts_reclassified == 1
        while time.monotonic() < deadline and engine._concepts_pending != 0:
            time.sleep(0.05)
        snap = engine.stats()
        assert snap["concepts_done"] == 6 and snap["concepts_pending"] == 0 and snap["concepts_running"]
        assert snap["concepts_reclassified"] == 1
    finally:
        engine._stop.set()
        th.join(10)
    assert not th.is_alive()
    assert VortexItem.query.filter(VortexItem.concept_version.is_(None)).count() == 0


def test_engine_loop_survives_a_failure_and_keeps_going(app, db, monkeypatch):
    mk(db, "Ferrari at the paddock", category="carros")
    calls = {"n": 0}
    real = vu.process_batch

    def flaky(*a, **kw):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("banco caiu")
        return real(*a, **kw)

    monkeypatch.setattr(vu, "process_batch", flaky)
    app.config["VORTEX_CONCEPTS_IDLE_SECONDS"] = 0.1
    engine = vc.IngestEngine(app, db)
    th = threading.Thread(target=engine._concepts_loop, daemon=True)
    th.start()
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline and engine.concepts_done < 1:
        time.sleep(0.05)
    engine._stop.set()
    th.join(10)
    assert engine.concepts_done == 1 and calls["n"] >= 2


# ------------------------------------------------------------------ cobertura / painel
def _seed_coverage(db):
    mk(db, "Ferrari at the paddock", category="carros", version=vcn.CONCEPTS_VERSION,
       concepts="carro_esportivo:1", concept_tags=" carro_esportivo carro veiculo_rodas veiculo ")
    mk(db, "Vespa parked", category="carros", version=vcn.CONCEPTS_VERSION, concepts="moto:1,estrada:0.5",
       concept_tags=" moto veiculo_rodas veiculo estrada lugares ")
    mk(db, "Violin recital", category="pessoas", version=vcn.CONCEPTS_VERSION, concepts="musico:1",
       concept_tags=" musico atividade pessoas ")
    for _ in range(3):
        mk(db, "Zorblax gadget", category="tecnologia", version=vcn.CONCEPTS_VERSION, concepts="",
           concept_tags=" tecnologia ")
    mk(db, "IMG_2031", category="outros", version=vcn.CONCEPTS_VERSION, concepts="", concept_tags="")
    mk(db, "Nova", category="outros")                                         # pendente
    mk(db, "Velha", category="carros", version=1, concepts="balao:1", concept_tags=" balao ")


def test_coverage_counts_and_distribution(app, db):
    _seed_coverage(db)
    cov = vu.coverage(app, ttl=0)
    assert (cov["total"], cov["understood"], cov["category_only"], cov["nothing"]) == (9, 3, 3, 1)
    assert cov["pending"] == 1 and cov["stale"] == 1 and cov["version"] == vcn.CONCEPTS_VERSION
    assert cov["percent"] == pytest.approx(33.3, abs=0.1)
    assert {c["id"]: c["count"] for c in cov["top_concepts"]} == {
        "carro_esportivo": 1, "moto": 1, "musico": 1, "balao": 1}
    assert {d["id"]: d["count"] for d in cov["domains"]}["veiculo"] == 2
    assert cov["concepts_distinct"] == 4
    assert [s["title"] for s in cov["without_samples"]][:1] == ["IMG_2031"]
    assert {"word": "zorblax", "count": 3} in cov["missing_words"]          # o que falta no vocabulário


def test_coverage_cache_and_overview_embed(app, db):
    import vortex_control
    first = vu.coverage(app, ttl=60)
    mk(db, "Ferrari", version=vcn.CONCEPTS_VERSION, concepts="carro:1", concept_tags=" carro ")
    assert vu.coverage(app, ttl=60) is first                                   # cache
    assert vu.coverage(app, ttl=0)["understood"] == 1
    assert vortex_control.overview(app, ttl=0)["concepts"]["understood"] == 1


@pytest.fixture()
def admin_client(app, db):
    user = User(username="chefe3b", email="chefe3b@example.com", is_admin=True)
    user.set_password("senha1234")
    db.session.add(user)
    db.session.commit()
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["_fresh"] = True
    return client


def test_admin_content_page_shows_concept_coverage(app, db, admin_client):
    _seed_coverage(db)
    page = admin_client.get("/admin/vortex/conteudo")
    html = page.get_data(as_text=True)
    assert page.status_code == 200 and "Compreensão do conteúdo" in html
    assert "zorblax" in html and "entendidos" in html and "t-concepts" in html


def test_admin_items_filter_by_concept_includes_descendants(app, db, admin_client):
    _seed_coverage(db)
    html = admin_client.get("/admin/vortex/itens?conceito=veiculo_rodas").get_data(as_text=True)
    assert "Ferrari at the paddock" in html and "Vespa parked" in html and "Violin recital" not in html
    html = admin_client.get("/admin/vortex/itens?conceito=carro").get_data(as_text=True)
    assert "Ferrari at the paddock" in html and "Vespa parked" not in html
    html = admin_client.get("/admin/vortex/itens?conceito=nenhum").get_data(as_text=True)
    assert "Zorblax gadget" in html and "Ferrari at the paddock" not in html and "Nova" not in html


def test_admin_items_ignores_an_invalid_concept_filter(app, db, admin_client):
    _seed_coverage(db)
    for bad in ("%", "' OR 1=1 --", "inexistente"):
        resp = admin_client.get("/admin/vortex/itens", query_string={"conceito": bad})
        html = resp.get_data(as_text=True)
        assert resp.status_code == 200 and "Ferrari at the paddock" in html and "Violin recital" in html


def test_admin_items_shows_the_main_concept_label(app, db, admin_client):
    _seed_coverage(db)
    html = admin_client.get("/admin/vortex/itens").get_data(as_text=True)
    assert "🧠 Carro esportivo" in html and "🧠 Moto +1" in html


# ------------------------------------------------------------------ esquema e CLI
def test_schema_upgrade_adds_the_columns_and_the_pending_index(app, db):
    with db.engine.begin() as conn:
        for idx in ("ix_vortex_items_concept_pending",):
            conn.execute(text(f"DROP INDEX IF EXISTS {idx}"))
        for col in ("concepts", "concept_tags", "concept_version"):
            conn.execute(text(f"ALTER TABLE vortex_items DROP COLUMN {col}"))
    from app import _ensure_schema_upgrades
    _ensure_schema_upgrades(db)
    _ensure_schema_upgrades(db)                                                # idempotente
    cols = {r[1] for r in db.session.execute(text("PRAGMA table_info(vortex_items)"))}
    assert {"concepts", "concept_tags", "concept_version"} <= cols
    idx = {r[1] for r in db.session.execute(text("PRAGMA index_list(vortex_items)"))}
    assert "ix_vortex_items_concept_pending" in idx


def test_cli_flags_reach_the_database_layer(monkeypatch):
    seen = {}
    monkeypatch.setattr(vu, "cli", lambda argv: seen.setdefault("argv", argv) and 0)
    assert vcn.main(["vortex_concepts.py", "--reprocess", "--limit", "5"]) == 0
    assert seen["argv"] == ["--reprocess", "--limit", "5"]
    seen.clear()
    assert vcn.main(["vortex_concepts.py", "--report"]) == 0 and seen["argv"] == ["--report"]


def test_cli_text_mode_still_works(capsys):
    assert vcn.main(["vortex_concepts.py", "red sports car", "motorcycle"]) == 0
    out = capsys.readouterr().out
    assert "similaridade" in out and "Carro" in out
