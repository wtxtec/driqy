"""Chat rico — Fase 1: modelo, migração, envio de mídia e mídia privada."""
import io

import pytest

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64


@pytest.fixture()
def two_users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append((u.id, {"Authorization": f"Bearer {tok.token}"}))
        return out


def _send_img(client, headers, to, name="a.png", data=PNG, **form):
    payload = {"file": (io.BytesIO(data), name), **form}
    return client.post(f"/api/v1/messages/{to}", headers=headers,
                       data=payload, content_type="multipart/form-data")


def test_text_message_still_works(app, two_users):
    c = app.test_client()
    r = c.post("/api/v1/messages/beto", headers=two_users[0][1], json={"content": "oi"})
    assert r.status_code == 200
    j = r.get_json()
    assert j["content"] == "oi" and j["msg_type"] == "text" and j["media_url"] is None
    assert j["mine"] is True and j["deleted"] is False


def test_empty_message_rejected(app, two_users):
    r = app.test_client().post("/api/v1/messages/beto", headers=two_users[0][1], json={"content": " "})
    assert r.status_code == 400


def test_image_upload_label_and_caption(app, two_users):
    c = app.test_client()
    j = _send_img(c, two_users[0][1], "beto", width="10", height="20").get_json()
    assert j["msg_type"] == "image" and j["content"] == "📷 Foto" and j["caption"] is None
    assert j["media_width"] == 10 and j["media_height"] == 20
    j2 = _send_img(c, two_users[0][1], "beto", content="olha").get_json()
    assert j2["caption"] == "olha" and j2["content"] == "olha"


def test_fake_image_rejected(app, two_users):
    r = _send_img(app.test_client(), two_users[0][1], "beto", data=b"nao sou png")
    assert r.status_code == 400


def test_disallowed_extension_rejected(app, two_users):
    r = _send_img(app.test_client(), two_users[0][1], "beto", name="x.exe", data=b"MZ")
    assert r.status_code == 400


def test_audio_and_video_types(app, two_users):
    c = app.test_client()
    a = c.post("/api/v1/messages/beto", headers=two_users[0][1], content_type="multipart/form-data",
               data={"file": (io.BytesIO(b"\x00\x00\x00\x20ftypM4A " + b"x" * 50), "v.m4a", "audio/mp4"), "duration_ms": "4200"}).get_json()
    assert a["msg_type"] == "audio" and a["media_duration_ms"] == 4200
    v = c.post("/api/v1/messages/beto", headers=two_users[0][1], content_type="multipart/form-data",
               data={"file": (io.BytesIO(b"\x00\x00\x00\x20ftypisom" + b"x" * 50), "v.mp4", "video/mp4")}).get_json()
    assert v["msg_type"] == "video"


def test_size_limit(app, two_users):
    app.config["CHAT_MAX_IMAGE_BYTES"] = 100
    r = _send_img(app.test_client(), two_users[0][1], "beto", data=PNG + b"0" * 200)
    assert r.status_code == 413


def test_media_is_private(app, two_users):
    c = app.test_client()
    j = _send_img(c, two_users[0][1], "beto").get_json()
    url = j["media_url"]
    assert url.startswith("/api/v1/messages/media/")
    assert c.get(url).status_code == 401                         # sem login
    assert c.get(url, headers=two_users[2][1]).status_code == 404  # terceiro
    ok = c.get(url, headers=two_users[1][1])                      # destinatário
    assert ok.status_code == 200 and ok.data == PNG
    assert c.get(url, headers=two_users[0][1]).status_code == 200  # remetente


def test_uploads_route_blocks_chat_folder(app, two_users):
    c = app.test_client()
    from models import Message
    with app.app_context():
        _send_img(c, two_users[0][1], "beto")
        path = Message.query.first().media_path
    assert path.startswith("chat/")
    assert c.get(f"/uploads/{path}").status_code == 404


def test_client_id_is_idempotent(app, two_users):
    c = app.test_client()
    h = two_users[0][1]
    a = c.post("/api/v1/messages/beto", headers=h, json={"content": "x", "client_id": "abc"}).get_json()
    b = c.post("/api/v1/messages/beto", headers=h, json={"content": "x", "client_id": "abc"}).get_json()
    assert a["id"] == b["id"]
    assert len(c.get("/api/v1/messages/beto", headers=h).get_json()["messages"]) == 1


def test_reply_validation(app, two_users):
    c = app.test_client()
    first = c.post("/api/v1/messages/beto", headers=two_users[0][1], json={"content": "a"}).get_json()
    ok = c.post("/api/v1/messages/ana", headers=two_users[1][1],
                json={"content": "b", "reply_to_id": first["id"]}).get_json()
    assert ok["reply_to"]["id"] == first["id"] and ok["reply_to"]["preview"] == "a"
    # terceiro não pode responder mensagem de conversa alheia
    bad = c.post("/api/v1/messages/ana", headers=two_users[2][1],
                 json={"content": "c", "reply_to_id": first["id"]})
    assert bad.status_code == 400


def test_read_sets_timestamps(app, two_users):
    c = app.test_client()
    c.post("/api/v1/messages/beto", headers=two_users[0][1], json={"content": "oi"})
    msgs = c.get("/api/v1/messages/ana", headers=two_users[1][1]).get_json()["messages"]
    assert msgs[0]["is_read"] is True
    again = c.get("/api/v1/messages/beto", headers=two_users[0][1]).get_json()["messages"][0]
    assert again["read_at"] and again["delivered_at"]


def test_schema_upgrade_adds_columns_to_old_table(tmp_path):
    """Banco antigo (tabela messages sem as colunas novas) é migrado no boot."""
    import sqlite3
    db_file = tmp_path / "old.db"
    con = sqlite3.connect(db_file)
    con.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, cover_filename VARCHAR(255), reset_token VARCHAR(64),"
                " reset_token_expires DATETIME, google_id VARCHAR(255), last_seen_at DATETIME)")
    con.execute("CREATE TABLE messages (id INTEGER PRIMARY KEY, sender_id INT, recipient_id INT,"
                " content VARCHAR(2000) NOT NULL, is_read BOOLEAN NOT NULL DEFAULT 0, created_at DATETIME)")
    con.execute("INSERT INTO messages (sender_id, recipient_id, content) VALUES (1, 2, 'antiga')")
    con.commit(); con.close()

    from flask import Flask
    from extensions import db as _db
    from app import _ensure_schema_upgrades
    a = Flask(__name__)
    a.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_file}"
    _db.init_app(a)
    with a.app_context():
        _ensure_schema_upgrades(_db)
        _ensure_schema_upgrades(_db)  # idempotente
        from sqlalchemy import inspect, text
        cols = {c["name"] for c in inspect(_db.engine).get_columns("messages")}
        assert {"msg_type", "media_path", "reply_to_id", "client_id", "deleted_at", "read_at"} <= cols
        row = _db.session.execute(text("SELECT msg_type, content FROM messages")).one()
        assert tuple(row) == ("text", "antiga")

