"""Parte 4: "mais como este" por conceito/família, co-cliques e corte de relevância."""
from datetime import timedelta

import pytest

import vortex_concepts as vcn
import vortex_search as vs
from models import User, VortexInteraction, utcnow
from test_vortex_search import get, ids_of, mk


def cmk(db, title, concept, tags="", category="outros", **kw):
    """Item já analisado: `concept` = (id, peso) ou None (sem pista)."""
    item = mk(db, title, tags=tags, category=category, **kw)
    if concept:
        u = vcn.Understanding([concept], None, [], 1.0, "text")
        item.concepts = vcn.encode(u)
        item.concept_tags = vcn.concept_tags(u)
        item.concept_version = vcn.CONCEPTS_VERSION
    else:
        item.concepts, item.concept_tags, item.concept_version = "", "", vcn.CONCEPTS_VERSION
    db.session.commit()
    return item


def related(client, headers, item):
    return ids_of(get(client, headers, f"/api/v1/vortex/item/{item.id}/related")[1])


def test_car_gets_wheeled_vehicles_never_dancing_or_balloons(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    car = cmk(db, "Red car", ("carro", 1.0), "vermelho", "carros")
    moto = cmk(db, "Old motorcycle", ("moto", 1.0), "", "carros")
    truck = cmk(db, "Big truck", ("caminhao", 1.0), "", "carros")
    car2 = cmk(db, "Another car", ("carro", 1.0), "", "carros")
    dance = cmk(db, "Dancing people", ("danca", 1.0), "vermelho", "carros")   # mesma tag e categoria
    balloon = cmk(db, "Party balloons", ("balao", 1.0), "vermelho", "carros")
    plane = cmk(db, "Airplane", ("aviao", 1.0), "", "carros")
    got = related(client, headers, car)
    assert car2.id in got and moto.id in got and truck.id in got
    assert dance.id not in got and balloon.id not in got and plane.id not in got
    assert got.index(car2.id) < got.index(moto.id)        # mesmo conceito vem antes do parente


def test_family_candidates_do_not_depend_on_tags_or_category(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    car = cmk(db, "Carro azul", ("carro", 1.0), "", "carros")
    bike = cmk(db, "Bicicleta urbana", ("bicicleta", 1.0), "", "esportes")   # sem tag/categoria em comum
    cmk(db, "Gato", ("gato", 1.0), "", "carros")
    assert bike.id in related(client, headers, car)


def test_unanalysed_items_need_the_minimum_score_and_do_not_fill(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    car = cmk(db, "Red car", ("carro", 1.0), "carro", "carros")
    raw_same_tags = mk(db, "Sem analise com tag", tags="carro", category="carros")   # nunca analisado
    raw_fill = mk(db, "Sem analise so categoria", tags="", category="carros")
    got = related(client, headers, car)
    assert raw_same_tags.id in got        # tag em comum + categoria passa do corte
    assert raw_fill.id not in got         # sem confirmação, não completa a lista


def test_item_without_concepts_behaves_as_before(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    base = mk(db, "Cachoeira", tags="cachoeira", category="natureza")
    fill = mk(db, "Outra coisa", tags="", category="natureza")
    assert fill.id in related(client, headers, base)


def test_coclicks_add_a_bonus_only_with_two_distinct_users(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    car = cmk(db, "Car", ("carro", 1.0), "", "carros")
    a = cmk(db, "Car A", ("carro", 1.0), "", "carros")
    b = cmk(db, "Car B", ("carro", 1.0), "", "carros")
    assert related(client, headers, car).index(b.id) < related(client, headers, car).index(a.id)  # desempate: id maior
    users = []
    for i in range(2):
        u = User(username=f"co{i}", email=f"co{i}@x.com")
        u.set_password("senha1234")
        db.session.add(u)
        users.append(u)
    db.session.commit()
    now = utcnow()
    one_user_only = [(users[0], car, now), (users[0], a, now + timedelta(minutes=5))]
    for u, it, when in one_user_only:
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0, item_id=it.id, created_at=when))
    db.session.commit()
    assert vs.coclick_counts(car.id) == {}                 # 1 pessoa só não conta
    for u in users:
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0, item_id=car.id, created_at=now))
        db.session.add(VortexInteraction(user_id=u.id, kind="like", weight=2.0, item_id=a.id,
                                         created_at=now + timedelta(minutes=3)))
    db.session.commit()
    assert vs.coclick_counts(car.id) == {a.id: 2}
    assert related(client, headers, car).index(a.id) < related(client, headers, car).index(b.id)


def test_coclick_ignores_far_apart_negative_and_self(app, db, user_token):
    car = cmk(db, "Car", ("carro", 1.0), "", "carros")
    other = cmk(db, "Other", ("carro", 1.0), "", "carros")
    now = utcnow()
    for i in range(3):
        u = User(username=f"far{i}", email=f"far{i}@x.com")
        u.set_password("senha1234")
        db.session.add(u)
        db.session.commit()
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0, item_id=car.id, created_at=now))
        db.session.add(VortexInteraction(user_id=u.id, kind="less", weight=-1.5, item_id=other.id, created_at=now))
        db.session.commit()
    assert vs.coclick_counts(car.id) == {}
