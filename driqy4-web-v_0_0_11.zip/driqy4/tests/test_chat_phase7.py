"""Chat rico — Fase 7: apagar (para mim / para todos), responder, janela de tempo."""
import io
import os
from datetime import timedelta

import pytest

MP4 = b"\x00\x00\x00\x20ftypisom" + b"\x00" * 64
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 200


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _text(c, h, to, text, **extra):
    r = c.post(f"/api/v1/messages/{to}", headers=h, json={"content": text, **extra})
    assert r.status_code == 200, r.get_data(as_text=True)
    return r.get_json()


def _video(c, h, to="beto"):
    r = c.post(f"/api/v1/messages/{to}", headers=h, content_type="multipart/form-data",
               data={"file": (io.BytesIO(MP4), "v.mp4", "video/mp4"),
                     "thumb": (io.BytesIO(JPEG), "t.jpg", "image/jpeg")})
    assert r.status_code == 200
    return r.get_json()


def _files(app, msg_id):
    from extensions import db as _db
    from models import Message
    with app.app_context():
        m = _db.session.get(Message, msg_id)
        root = app.config["UPLOAD_FOLDER"]
        return m.media_path, [os.path.isfile(os.path.join(root, *p.split("/")))
                              for p in (m.media_path, m.media_path + ".thumb")] if m.media_path else []


def _set_age(app, msg_id, hours):
    from extensions import db as _db
    from models import Message, utcnow
    with app.app_context():
        m = _db.session.get(Message, msg_id)
        m.created_at = utcnow() - timedelta(hours=hours)
        _db.session.commit()


# ---------- apagar para todos ----------
def test_delete_for_all_sender_only(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "segredo")
    assert m["can_delete_for_all"] is True
    assert c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[1]).status_code == 403
    assert c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[2]).status_code == 404
    r = c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[0])
    assert r.status_code == 200
    j = r.get_json()["message"]
    assert j["deleted"] is True and j["content"] == "" and j["can_delete_for_all"] is False
    # o destinatário também vê "apagada"
    thread = c.get("/api/v1/messages/ana", headers=users[1]).get_json()["messages"]
    assert thread[0]["deleted"] is True and thread[0]["content"] == ""
    # idempotente
    assert c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[0]).status_code == 200


def test_delete_for_all_window(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "velha")
    _set_age(app, m["id"], 49)
    again = c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"][0]
    assert again["can_delete_for_all"] is False
    r = c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[0])
    assert r.status_code == 403 and "48" in r.get_json()["error"]


def test_delete_for_all_removes_media_and_thumb(app, users):
    c = app.test_client()
    m = _video(c, users[0])
    path, exists = _files(app, m["id"])
    assert exists == [True, True]
    assert c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[0]).status_code == 200
    from extensions import db as _db
    from models import Message
    with app.app_context():
        row = _db.session.get(Message, m["id"])
        assert row.media_path is None and row.deleted_at is not None
        root = app.config["UPLOAD_FOLDER"]
        assert not os.path.isfile(os.path.join(root, *path.split("/")))
        assert not os.path.isfile(os.path.join(root, *(path + ".thumb").split("/")))
    assert c.get(m["media_url"], headers=users[1]).status_code == 404


def test_delete_for_all_clears_reactions(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "oi")
    assert c.put(f"/api/v1/messages/{m['id']}/reaction", headers=users[1], json={"emoji": "👍"}).status_code == 200
    c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[0])
    from models import MessageReaction
    with app.app_context():
        assert MessageReaction.query.count() == 0


# ---------- apagar para mim ----------
def test_delete_for_me_hides_only_for_me(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "oi beto")
    r = c.delete(f"/api/v1/messages/{m['id']}", headers=users[1])  # padrão = me
    assert r.status_code == 200 and r.get_json() == {"scope": "me", "id": m["id"]}
    assert c.get("/api/v1/messages/ana", headers=users[1]).get_json()["messages"] == []
    assert len(c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"]) == 1
    # idempotente
    assert c.delete(f"/api/v1/messages/{m['id']}?scope=me", headers=users[1]).status_code == 200
    # estranho não mexe
    assert c.delete(f"/api/v1/messages/{m['id']}", headers=users[2]).status_code == 404


def test_hidden_message_leaves_inbox_and_unread(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "nova")
    assert c.get("/api/v1/messages/unread-count", headers=users[1]).get_json()["unread"] == 1
    c.delete(f"/api/v1/messages/{m['id']}?scope=me", headers=users[1])
    assert c.get("/api/v1/messages/unread-count", headers=users[1]).get_json()["unread"] == 0
    assert c.get("/api/v1/messages", headers=users[1]).get_json()["conversations"] == []
    # para a ana a conversa continua
    assert len(c.get("/api/v1/messages", headers=users[0]).get_json()["conversations"]) == 1


def test_inbox_last_message_skips_hidden(app, users):
    c = app.test_client()
    _text(c, users[0], "beto", "primeira")
    m2 = _text(c, users[0], "beto", "segunda")
    c.delete(f"/api/v1/messages/{m2['id']}?scope=me", headers=users[1])
    conv = c.get("/api/v1/messages", headers=users[1]).get_json()["conversations"][0]
    assert conv["last_message"]["content"] == "primeira"


def test_both_hide_purges_media(app, users):
    c = app.test_client()
    m = _video(c, users[0])
    path, _ = _files(app, m["id"])
    c.delete(f"/api/v1/messages/{m['id']}?scope=me", headers=users[0])
    assert _files(app, m["id"])[1] == [True, True]  # ainda há quem veja
    c.delete(f"/api/v1/messages/{m['id']}?scope=me", headers=users[1])
    from extensions import db as _db
    from models import Message
    with app.app_context():
        assert _db.session.get(Message, m["id"]).media_path is None
        assert not os.path.isfile(os.path.join(app.config["UPLOAD_FOLDER"], *path.split("/")))


def test_bad_scope(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "x")
    assert c.delete(f"/api/v1/messages/{m['id']}?scope=xyz", headers=users[0]).status_code == 400
    assert c.delete("/api/v1/messages/99999", headers=users[0]).status_code == 404
    assert c.delete(f"/api/v1/messages/{m['id']}").status_code == 401


# ---------- responder ----------
def test_reply_roundtrip(app, users):
    c = app.test_client()
    orig = _text(c, users[0], "beto", "que horas?")
    rep = _text(c, users[1], "ana", "às 10", reply_to_id=orig["id"])
    assert rep["reply_to"]["id"] == orig["id"]
    assert rep["reply_to"]["preview"] == "que horas?"
    assert rep["reply_to"]["sender_id"] == orig["sender_id"]


def test_reply_to_stranger_message_rejected(app, users):
    c = app.test_client()
    other = _text(c, users[2], "ana", "oi ana")
    r = c.post("/api/v1/messages/beto", headers=users[0], json={"content": "x", "reply_to_id": other["id"]})
    assert r.status_code == 400


def test_reply_to_deleted_rejected_and_preview_updates(app, users):
    c = app.test_client()
    orig = _text(c, users[0], "beto", "vou apagar")
    rep = _text(c, users[1], "ana", "ok", reply_to_id=orig["id"])
    c.delete(f"/api/v1/messages/{orig['id']}?scope=all", headers=users[0])
    # a citação existente passa a mostrar "Mensagem apagada"
    msgs = c.get("/api/v1/messages/ana", headers=users[1]).get_json()["messages"]
    quoted = [m for m in msgs if m["id"] == rep["id"]][0]["reply_to"]
    assert quoted["preview"] == "Mensagem apagada"
    # e não dá para responder a ela
    r = c.post("/api/v1/messages/ana", headers=users[1], json={"content": "x", "reply_to_id": orig["id"]})
    assert r.status_code == 400


def test_reply_preview_hidden_for_viewer(app, users):
    c = app.test_client()
    orig = _text(c, users[0], "beto", "texto original")
    rep = _text(c, users[1], "ana", "resposta", reply_to_id=orig["id"])
    c.delete(f"/api/v1/messages/{orig['id']}?scope=me", headers=users[1])
    msgs = c.get("/api/v1/messages/ana", headers=users[1]).get_json()["messages"]
    assert msgs[0]["reply_to"]["preview"] == "Mensagem apagada"
    # para a ana a citação segue normal
    msgs = c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"]
    assert [m for m in msgs if m["id"] == rep["id"]][0]["reply_to"]["preview"] == "texto original"


def test_reply_with_media_multipart(app, users):
    c = app.test_client()
    orig = _text(c, users[0], "beto", "olha")
    r = c.post("/api/v1/messages/ana", headers=users[1], content_type="multipart/form-data",
               data={"file": (io.BytesIO(MP4), "v.mp4", "video/mp4"), "reply_to_id": str(orig["id"])})
    assert r.status_code == 200 and r.get_json()["reply_to"]["id"] == orig["id"]


def test_web_thread_page_has_reply_and_delete_ui(app, users):
    from models import User
    c = app.test_client()
    with app.app_context():
        uid = User.query.filter_by(username="ana").first().id
    with c.session_transaction() as sess:
        sess["_user_id"] = str(uid)
        sess["_fresh"] = True
    html = c.get("/mensagens/beto").get_data(as_text=True)
    assert 'id="cw-replybar"' in html and 'id="cw-delete"' in html
    assert 'data-partner-name=' in html


def test_web_session_can_delete(app, users):
    """A web usa sessão (cookie), não Bearer: o DELETE também precisa funcionar assim."""
    from models import User
    c = app.test_client()
    m = _text(c, users[0], "beto", "web")
    with app.app_context():
        uid = User.query.filter_by(username="ana").first().id
    with c.session_transaction() as sess:
        sess["_user_id"] = str(uid)
        sess["_fresh"] = True
    r = c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers={"X-Requested-With": "fetch"})
    assert r.status_code == 200 and r.get_json()["message"]["deleted"] is True
