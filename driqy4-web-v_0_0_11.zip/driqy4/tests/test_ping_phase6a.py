"""Ping — fase 6a: abrir conversa sem recarregar (fragmento + ciclo de vida do chat-thread.js)."""
import pathlib
import pytest


@pytest.fixture()
def site(app):
    from extensions import db as _db
    from models import Message, User
    with app.app_context():
        ids = {}
        for name in ("ana", "beto"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            ids[name] = u.id
        _db.session.add(Message(sender_id=ids["beto"], recipient_id=ids["ana"], content="oi ana"))
        _db.session.commit()
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(ids["ana"])
    c.ids = ids
    return c


def test_fragment_is_only_the_thread(site):
    r = site.get("/mensagens/beto", headers={"X-Ping-Fragment": "1"})
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    assert 'id="cw"' in html and 'data-partner="beto"' in html and 'id="cw-form"' in html
    for modal in ("cw-delete", "cw-forward", "cw-preview", "cw-toast"):
        assert f'id="{modal}"' in html, modal
    assert "<html" not in html and 'id="chat-inbox-list"' not in html and "ping-shell.js" not in html


def test_fragment_still_marks_as_read(site, app):
    site.get("/mensagens/beto", headers={"X-Ping-Fragment": "1"})
    from models import Message
    with app.app_context():
        m = Message.query.filter_by(content="oi ana").first()
        assert m.is_read


def test_full_page_unchanged(site):
    html = site.get("/mensagens/beto").get_data(as_text=True)
    assert 'id="cw"' in html and 'id="chat-inbox-list"' in html and "chat-thread.js" in html
    assert 'data-thread-script="/static/js/chat-thread.js' in html


def test_self_thread_redirects_even_for_fragment(site):
    r = site.get("/mensagens/ana", headers={"X-Ping-Fragment": "1"})
    assert r.status_code == 302


def test_thread_script_has_destroy_and_tracked_listeners():
    js = pathlib.Path("static/js/chat-thread.js").read_text(encoding="utf-8")
    assert "window.__pingThreadDestroy" in js
    assert 'document.addEventListener(' not in js.replace("listenOn(document", "")  # nenhum listener global solto
    shell = pathlib.Path("static/js/ping-shell.js").read_text(encoding="utf-8")
    assert "X-Ping-Fragment" in shell and "__pingThreadDestroy" in shell and "popstate" in shell
