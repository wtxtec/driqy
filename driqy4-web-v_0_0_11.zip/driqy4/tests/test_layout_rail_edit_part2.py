"""Minha área, Parte 2: modo 'Editar widgets' no cartão do painel (site)."""
import pathlib

import pytest

EDIT = pathlib.Path("static/js/rail-edit.js").read_text(encoding="utf-8")
RAIL = pathlib.Path("static/js/rail.js").read_text(encoding="utf-8")


def _login(app, name="ana"):
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User(username=name, email=f"{name}@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": name, "password": "senha1234"})
    return c


def test_assets_and_safety():
    for needle in ("X-Requested-With", "openEditor", "/widgets/prefs" if False else "__railPrefsUrl", "Concluir", "Restaurar", "Escape"):
        assert needle in EDIT
    assert "innerHTML" not in EDIT  # texto do servidor só por textContent
    assert "openEditor" in RAIL and "reapply" in RAIL and "renderEmpty" in RAIL
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 63  # versão do cache do SW só pode subir
    css = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
    for cls in (".rail-ed-row", ".rail-ed-btn", ".rail-ed-actions", ".rail-ed-tag"):
        assert cls in css


def test_page_has_pencil_and_script_order(app):
    c = _login(app)
    html = c.get("/").get_data(as_text=True)
    assert 'id="rail-widget-edit"' in html and 'aria-label="Editar widgets"' in html
    assert html.index("js/rail.js") < html.index("js/rail-edit.js") < html.index("js/rail-weather.js")


def test_card_still_rendered_when_every_widget_is_removed(app):
    """Sem nenhum widget ativo o cartão continua lá: é por ele que se adiciona de volta."""
    from api_widgets import WIDGETS
    c = _login(app)
    r = c.post("/api/v1/widgets/prefs", headers={"X-Requested-With": "fetch"},
               json={"disabled": [w["id"] for w in WIDGETS]})
    assert r.status_code == 200 and len(r.get_json()["prefs"]["disabled"]) == len(WIDGETS)
    html = c.get("/").get_data(as_text=True)
    assert 'id="rail-widgets"' in html and 'id="rail-widget-edit"' in html


def test_prefs_roundtrip_keeps_other_settings(app):
    """O editor manda rail_hidden/suggest/suggest_first como estavam; salvar a ordem não pode mexer neles."""
    c = _login(app)
    h = {"X-Requested-With": "fetch"}
    c.post("/api/v1/widgets/prefs", headers=h, json={"suggest": False, "suggest_first": True})
    p = c.get("/api/v1/widgets/prefs").get_json()["prefs"]
    r = c.post("/api/v1/widgets/prefs", headers=h, json={
        "rail_hidden": p["rail_hidden"], "suggest": p["suggest"], "suggest_first": p["suggest_first"],
        "order": ["news", "weather"], "disabled": ["weather"]}).get_json()["prefs"]
    assert r["order"][:2] == ["news", "weather"] and r["disabled"] == ["weather"]
    assert r["suggest"] is False and r["suggest_first"] is True
