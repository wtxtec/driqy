"""Peq-3: "Personalizar painel" lista os widgets próprios ("seu") e os 10 novos (site)."""
import pathlib
import re

J = pathlib.Path("static/js/rail-customize.js").read_text(encoding="utf-8")


def test_customize_marks_own_widgets_with_seu_tag():
    assert "w.custom" in J and "customIds" in J
    assert '"rail-ed-tag", "seu"' in J


def test_customize_list_comes_from_server_widgets_not_a_fixed_list(app):
    # o diálogo usa cfg.widgets (rail_context): prontos + próprios; ids novos entram sem mexer no JS
    from api_widgets import WIDGETS
    assert len(WIDGETS) == 16
    assert "cfg.widgets.forEach" in J and "state.order" in J


def test_rail_context_includes_custom_widget_with_flag(app):
    from api_widgets import rail_context
    from extensions import db as _db
    from models import User
    import widgets_custom
    with app.app_context():
        u = User(username="ana", email="ana@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
        widgets_custom.create(u, "note", "Minha nota", None)
        ctx = rail_context(u)
        ids = [w["id"] for w in ctx["widgets"]]
        assert len(ids) == 17 and ids[-1].startswith("custom:")
        assert ctx["widgets"][-1]["custom"] is True and ctx["widgets"][-1]["title"] == "Minha nota"
        assert ids[-1] in ctx["prefs"]["order"]


def test_no_innerhtml_with_server_text():
    uses = re.findall(r"innerHTML\s*=\s*([^;\n]{0,10})", J)
    assert all(u.strip().startswith('""') for u in uses), uses
