"""Chamadas — Fase 11: sinalização (offer/answer/ICE/estado), expiração, ocupado, config STUN/TURN."""
import base64
import hashlib
import hmac
from datetime import timedelta

import pytest

from chat_events import hub

SDP = "v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\n"


@pytest.fixture(autouse=True)
def _clean_hub():
    import api_calls
    hub.reset()
    api_calls.reset()
    yield
    hub.reset()
    api_calls.reset()


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _uid(app, name):
    from models import User
    with app.app_context():
        return User.query.filter_by(username=name).first().id


def _drain(q):
    out = []
    while not q.empty():
        out.append(q.get_nowait())
    return out


def _start(client, h, to="beto", media="voice", **extra):
    body = {"media": media, "offer": {"type": "offer", "sdp": SDP}, **extra}
    return client.post(f"/api/v1/calls/{to}", json=body, headers=h)


def _answer(client, h, cid):
    return client.post(f"/api/v1/calls/{cid}/answer", json={"answer": {"type": "answer", "sdp": SDP}}, headers=h)


def test_start_creates_ringing_and_notifies(app, users):
    ana, beto, _ = users
    c = app.test_client()
    qb = hub.subscribe(_uid(app, "beto"))
    r = _start(c, ana)
    assert r.status_code == 201
    j = r.get_json()
    assert j["state"] == "ringing" and j["direction"] == "outgoing" and j["media"] == "voice"
    ev = [e for e in _drain(qb) if e[0] == "call_incoming"]
    assert len(ev) == 1
    assert ev[0][1]["partner"] == "ana" and ev[0][1]["call_id"] == j["id"]
    assert ev[0][1]["offer"]["sdp"] == SDP


def test_start_validation(app, users):
    ana, _, _ = users
    c = app.test_client()
    assert _start(c, ana, to="ana").status_code == 400
    assert _start(c, ana, to="ninguem").status_code == 404
    assert _start(c, ana, media="hologram").status_code == 400
    assert c.post("/api/v1/calls/beto", json={"media": "voice"}, headers=ana).status_code == 400
    bad = c.post("/api/v1/calls/beto", json={"offer": {"type": "offer", "sdp": "lixo"}}, headers=ana)
    assert bad.status_code == 400
    big = c.post("/api/v1/calls/beto", json={"offer": {"type": "offer", "sdp": "v=0" + "a" * 20000}}, headers=ana)
    assert big.status_code == 413
    assert c.post("/api/v1/calls/beto", json={"offer": {"type": "answer", "sdp": SDP}}, headers=ana).status_code == 400


def test_requires_auth(app):
    c = app.test_client()
    assert c.post("/api/v1/calls/beto", json={}).status_code == 401
    assert c.get("/api/v1/calls/active").status_code == 401
    assert c.get("/api/v1/calls/config").status_code == 401


def test_client_id_is_idempotent(app, users):
    ana, _, _ = users
    c = app.test_client()
    a = _start(c, ana, client_id="x1")
    b = _start(c, ana, client_id="x1")
    assert a.status_code == 201 and b.status_code == 200
    assert a.get_json()["id"] == b.get_json()["id"]


def test_answer_flow(app, users):
    ana, beto, _ = users
    c = app.test_client()
    qa, qb = hub.subscribe(_uid(app, "ana")), hub.subscribe(_uid(app, "beto"))
    cid = _start(c, ana).get_json()["id"]
    _drain(qa), _drain(qb)
    r = _answer(c, beto, cid)
    assert r.status_code == 200 and r.get_json()["state"] == "accepted"
    ea = _drain(qa)
    sig = [e for e in ea if e[0] == "call_signal"]
    assert sig and sig[0][1]["kind"] == "answer" and sig[0][1]["answer"]["sdp"] == SDP
    assert any(e[0] == "call_state" and e[1]["state"] == "accepted" and e[1]["by"] == "beto" for e in ea)
    assert any(e[0] == "call_state" and e[1]["state"] == "accepted" for e in _drain(qb))
    # segunda vez: já não toca
    assert _answer(c, beto, cid).status_code == 409


def test_only_callee_answers_and_declines(app, users):
    ana, beto, caio = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    assert _answer(c, ana, cid).status_code == 403
    assert c.post(f"/api/v1/calls/{cid}/decline", headers=ana).status_code == 403
    assert _answer(c, caio, cid).status_code == 404       # estranho nem vê a chamada
    assert c.get(f"/api/v1/calls/{cid}", headers=caio).status_code == 404
    assert c.post(f"/api/v1/calls/{cid}/end", headers=caio).status_code == 404


def test_answer_validation(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    assert c.post(f"/api/v1/calls/{cid}/answer", json={}, headers=beto).status_code == 400
    assert c.post(f"/api/v1/calls/{cid}/answer", json={"answer": {"type": "offer", "sdp": SDP}}, headers=beto).status_code == 400


def test_decline(app, users):
    ana, beto, _ = users
    c = app.test_client()
    qa = hub.subscribe(_uid(app, "ana"))
    cid = _start(c, ana).get_json()["id"]
    _drain(qa)
    r = c.post(f"/api/v1/calls/{cid}/decline", headers=beto)
    assert r.status_code == 200 and r.get_json()["state"] == "declined"
    assert any(e[0] == "call_state" and e[1]["state"] == "declined" for e in _drain(qa))
    assert c.post(f"/api/v1/calls/{cid}/decline", headers=beto).get_json()["state"] == "declined"  # idempotente
    assert _answer(c, beto, cid).status_code == 409


def test_caller_cancels_ringing_is_missed(app, users, monkeypatch):
    ana, beto, _ = users
    c = app.test_client()
    pushed = []
    import push
    monkeypatch.setattr(push, "send_push_to_user", lambda *a, **k: pushed.append((a, k)))
    cid = _start(c, ana).get_json()["id"]
    pushed.clear()
    r = c.post(f"/api/v1/calls/{cid}/end", headers=ana)
    assert r.get_json()["state"] == "missed" and r.get_json()["end_reason"] == "canceled"
    assert pushed and pushed[0][1]["data"]["type"] == "call_missed"


def test_callee_end_while_ringing_is_decline(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    assert c.post(f"/api/v1/calls/{cid}/end", headers=beto).get_json()["state"] == "declined"


def test_hangup_after_accept_and_duration(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    _answer(c, beto, cid)
    from extensions import db as _db
    from models import Call
    with app.app_context():
        call = _db.session.get(Call, cid)
        call.answered_at = call.answered_at - timedelta(seconds=65)
        _db.session.commit()
    r = c.post(f"/api/v1/calls/{cid}/end", headers=beto).get_json()
    assert r["state"] == "ended" and r["end_reason"] == "hangup" and 64 <= r["duration_s"] <= 70
    again = c.post(f"/api/v1/calls/{cid}/end", headers=ana).get_json()  # idempotente
    assert again["state"] == "ended"
    with app.app_context():  # SDP não fica no banco
        call = _db.session.get(Call, cid)
        assert call.offer_sdp is None and call.answer_sdp is None


def test_busy_and_already_in_call(app, users):
    ana, beto, caio = users
    c = app.test_client()
    cid = _start(c, ana, to="beto").get_json()["id"]
    r = _start(c, caio, to="beto")                      # beto está tocando
    assert r.status_code == 409 and r.get_json()["code"] == "busy"
    r = _start(c, ana, to="caio")                       # ana já está ligando
    assert r.status_code == 409 and r.get_json()["code"] == "already_in_call"
    assert r.get_json()["call_id"] == cid
    hist = c.get("/api/v1/calls", headers=caio).get_json()["calls"]
    assert hist[0]["state"] == "busy"
    c.post(f"/api/v1/calls/{cid}/end", headers=ana)
    assert _start(c, caio, to="beto").status_code == 201  # liberou


def test_ringing_expires_lazily(app, users):
    ana, beto, _ = users
    c = app.test_client()
    qa = hub.subscribe(_uid(app, "ana"))
    cid = _start(c, ana).get_json()["id"]
    _drain(qa)
    from extensions import db as _db
    from models import Call
    with app.app_context():
        call = _db.session.get(Call, cid)
        call.created_at = call.created_at - timedelta(seconds=120)
        _db.session.commit()
    r = c.get(f"/api/v1/calls/{cid}", headers=beto).get_json()
    assert r["state"] == "missed" and r["end_reason"] == "timeout"
    assert any(e[0] == "call_state" and e[1]["state"] == "missed" for e in _drain(qa))
    assert _answer(c, beto, cid).status_code == 409


def test_stale_accepted_is_ended(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    _answer(c, beto, cid)
    from extensions import db as _db
    from models import Call
    with app.app_context():
        call = _db.session.get(Call, cid)
        call.heartbeat_at = call.heartbeat_at - timedelta(seconds=300)
        _db.session.commit()
    assert c.get("/api/v1/calls/active", headers=ana).get_json()["call"] is None
    assert c.get(f"/api/v1/calls/{cid}", headers=ana).get_json()["end_reason"] == "stale"
    assert _start(c, ana, to="caio").status_code == 201  # não ficou "ocupada"


def test_ping_keeps_alive(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    _answer(c, beto, cid)
    from extensions import db as _db
    from models import Call
    with app.app_context():
        call = _db.session.get(Call, cid)
        call.heartbeat_at = call.heartbeat_at - timedelta(seconds=60)
        _db.session.commit()
    assert c.post(f"/api/v1/calls/{cid}/ping", headers=ana).get_json()["state"] == "accepted"
    assert c.get(f"/api/v1/calls/{cid}", headers=ana).get_json()["state"] == "accepted"


def test_ice_relay_buffer_and_limits(app, users):
    ana, beto, _ = users
    c = app.test_client()
    qb = hub.subscribe(_uid(app, "beto"))
    cid = _start(c, ana).get_json()["id"]
    _drain(qb)
    cand = {"candidate": "candidate:1 1 udp 1 1.2.3.4 5 typ host", "sdpMid": "0", "sdpMLineIndex": 0}
    r = c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": cand}, headers=ana)
    assert r.get_json() == {"ok": True, "relayed": True}
    ev = [e for e in _drain(qb) if e[0] == "call_signal"]
    assert ev[0][1]["kind"] == "ice" and ev[0][1]["candidate"] == cand and ev[0][1]["partner"] == "ana"
    # quem conecta atrasado recupera os candidatos do outro lado pelo REST
    got = c.get(f"/api/v1/calls/{cid}", headers=beto).get_json()
    assert got["ice"] == [cand] and got["offer"]["sdp"] == SDP
    assert c.get(f"/api/v1/calls/{cid}", headers=ana).get_json()["ice"] == []
    # null = fim dos candidatos
    assert c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": None}, headers=ana).get_json()["relayed"] is False
    assert c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": "texto"}, headers=ana).status_code == 400
    assert c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": {"candidate": "x" * 3000}}, headers=ana).status_code == 413


def test_ice_rate_limit_and_closed(app, users):
    ana, beto, _ = users
    app.config["CALL_ICE_MAX_PER_CALL"] = 3
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    for _i in range(3):
        assert c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": {"candidate": "c"}}, headers=ana).status_code == 200
    assert c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": {"candidate": "c"}}, headers=ana).status_code == 429
    assert c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": {"candidate": "c"}}, headers=beto).status_code == 200
    c.post(f"/api/v1/calls/{cid}/end", headers=ana)
    assert c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": {"candidate": "c"}}, headers=beto).status_code == 409


def test_answer_visible_to_caller_after_accept(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    assert "answer" not in c.get(f"/api/v1/calls/{cid}", headers=ana).get_json()
    _answer(c, beto, cid)
    assert c.get(f"/api/v1/calls/{cid}", headers=ana).get_json()["answer"]["sdp"] == SDP
    assert "offer" not in c.get(f"/api/v1/calls/{cid}", headers=ana).get_json()


def test_active_and_history(app, users):
    ana, beto, _ = users
    c = app.test_client()
    assert c.get("/api/v1/calls/active", headers=beto).get_json()["call"] is None
    cid = _start(c, ana, media="video").get_json()["id"]
    a = c.get("/api/v1/calls/active", headers=beto).get_json()["call"]
    assert a["id"] == cid and a["direction"] == "incoming" and a["media"] == "video" and a["offer"]["sdp"] == SDP
    c.post(f"/api/v1/calls/{cid}/end", headers=ana)
    h = c.get("/api/v1/calls?limit=1", headers=beto).get_json()
    assert len(h["calls"]) == 1 and h["calls"][0]["id"] == cid and h["has_more"] is False
    assert c.get("/api/v1/calls", headers=_users_caio(users)).get_json()["calls"] == []


def _users_caio(users):
    return users[2]


def test_push_sent_on_incoming(app, users, monkeypatch):
    ana, _, _ = users
    c = app.test_client()
    pushed = []
    import push
    monkeypatch.setattr(push, "send_push_to_user", lambda *a, **k: pushed.append((a, k)))
    _start(c, ana, media="video")
    assert pushed
    k = pushed[0][1]
    assert k["data"]["type"] == "call" and k["data"]["media"] == "video" and "vídeo" in k["body"]


def test_muted_conversation_still_rings(app, users, monkeypatch):
    ana, beto, _ = users
    c = app.test_client()
    c.put("/api/v1/messages/ana/prefs", json={"muted": True}, headers=beto)
    pushed = []
    import push
    monkeypatch.setattr(push, "send_push_to_user", lambda *a, **k: pushed.append(k))
    assert _start(c, ana).status_code == 201
    assert pushed


def test_disabled_returns_503(app, users):
    ana, _, _ = users
    app.config["CALL_ENABLED"] = False
    c = app.test_client()
    assert _start(c, ana).status_code == 503
    assert c.get("/api/v1/calls/config", headers=ana).get_json()["enabled"] is False


def test_config_stun_only_and_turn_secret(app, users):
    ana, _, _ = users
    c = app.test_client()
    j = c.get("/api/v1/calls/config", headers=ana).get_json()
    assert j["turn_configured"] is False and j["ice_servers"][0]["urls"][0].startswith("stun:")
    app.config["CALL_TURN_URLS"] = ["turn:t.exemplo.com:3478?transport=udp"]
    app.config["CALL_TURN_SECRET"] = "segredo"
    j = c.get("/api/v1/calls/config", headers=ana).get_json()
    turn = j["ice_servers"][-1]
    exp, uid = turn["username"].split(":")
    assert int(uid) == _uid(app, "ana") and int(exp) > 0 and j["turn_configured"] is True
    want = base64.b64encode(hmac.new(b"segredo", turn["username"].encode(), hashlib.sha1).digest()).decode()
    assert turn["credential"] == want
    app.config["CALL_TURN_SECRET"] = ""
    app.config["CALL_TURN_USERNAME"], app.config["CALL_TURN_CREDENTIAL"] = "u", "p"
    turn = c.get("/api/v1/calls/config", headers=ana).get_json()["ice_servers"][-1]
    assert turn["username"] == "u" and turn["credential"] == "p"


def test_stranger_gets_no_call_events(app, users):
    ana, _, _ = users
    c = app.test_client()
    qc = hub.subscribe(_uid(app, "caio"))
    cid = _start(c, ana).get_json()["id"]
    c.post(f"/api/v1/calls/{cid}/ice", json={"candidate": {"candidate": "c"}}, headers=ana)
    _answer(c, users[1], cid)
    assert _drain(qc) == []


def test_session_cookie_needs_fetch_header(app):
    from extensions import db as _db
    from models import User
    with app.app_context():
        for n in ("ana", "beto"):
            u = User(username=n, email=f"{n}@e.com")
            u.set_password("senha1234")
            _db.session.add(u)
        _db.session.commit()
        uid = User.query.filter_by(username="ana").first().id
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(uid)
        s["_fresh"] = True
    body = {"media": "voice", "offer": {"type": "offer", "sdp": SDP}}
    assert c.post("/api/v1/calls/beto", json=body).status_code == 400
    assert c.post("/api/v1/calls/beto", json=body, headers={"X-Requested-With": "fetch"}).status_code == 201


def test_web_assets_and_events(app):
    c = app.test_client()
    js = c.get("/static/js/calls-api.js")
    assert js.status_code == 200 and b"driqyCalls" in js.data
    live = c.get("/static/js/chat-live.js").data
    for ev in (b"call_incoming", b"call_signal", b"call_state"):
        assert ev in live
    assert b"driqy-shell-v" in c.get("/static/sw.js").data
