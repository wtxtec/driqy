"""Vortex por GOSTO: sinais, perfil, ordenação, adaptação, paginação, API e web."""
from datetime import timedelta

import pytest

import vortex_crawler as vc
import vortex_taste as vt
from models import (
    ApiToken, Post, PostMedia, User, VortexInteraction, VortexItem, VortexProfile, utcnow,
)

_n = [0]


def mk_item(db, category, media="photo", tags="", profile="commons", title=None, age_days=0.0):
    _n[0] += 1
    prof = VortexProfile.query.filter_by(handle=profile).first()
    url = f"https://x.org/{_n[0]}/{category}.jpg"
    item = VortexItem(
        profile_id=prof.id, media_type=media, media_url=url, thumb_url=url + ".t.jpg",
        width=800, height=600, title=title or f"{category} {_n[0]}", tags=tags,
        category=category, url_hash=vc._hash_url(url),
        created_at=utcnow() - timedelta(days=age_days),
    )
    db.session.add(item)
    db.session.commit()
    return item


def mk_user(db, name):
    u = User(username=name, email=f"{name}@example.com")
    u.set_password("senha1234")
    db.session.add(u)
    db.session.commit()
    return u


def mk_post(db, user, media="photo"):
    _n[0] += 1
    p = Post(user_id=user.id, post_type=media, media_filename=f"f{_n[0]}.jpg",
             duration_minutes=0)
    db.session.add(p)
    db.session.commit()
    return p


def headers_for(db, user):
    tok = ApiToken.generate_for(user)
    db.session.commit()
    return {"Authorization": f"Bearer {tok.token}"}


@pytest.fixture(autouse=True)
def _clean(app):
    vt.clear_caches()
    yield
    vt.clear_caches()


def cat_share(app, db, user, n=30, first=None):
    """Fatia de cada categoria nas `n` primeiras peças do crawler."""
    keys = vt.ranked_page(app, user.id, page_size=n)["keys"][:n]
    objs = vt.load_objects(keys)
    cats = [objs[k].category for k in keys if k.startswith("c") and k in objs]
    return {c: cats.count(c) / max(len(cats), 1) for c in set(cats)}


# ------------------------------------------------------------------ sinais
def test_record_open_saves_a_copy_of_the_item_attributes(app, db):
    u = mk_user(db, "ana")
    it = mk_item(db, "natureza", tags="Cachoeira,Água")
    assert vt.record(u.id, "open", item=it) is True
    row = VortexInteraction.query.one()
    assert (row.category, row.media_type, row.item_id) == ("natureza", "photo", it.id)
    assert row.tags == "cachoeira,agua"       # minúscula e sem acento
    assert row.weight == vt.EVENT_WEIGHTS["open"]


def test_record_ignores_double_tap_and_invalid_kind(app, db):
    u = mk_user(db, "ana")
    it = mk_item(db, "natureza")
    assert vt.record(u.id, "open", item=it) is True
    assert vt.record(u.id, "open", item=it) is False       # repetido em seguida
    assert vt.record(u.id, "xpto", item=it) is False
    assert VortexInteraction.query.count() == 1


def test_search_becomes_tag_interest(app, db):
    u = mk_user(db, "ana")
    assert vt.record(u.id, "search", query="Cachoeira bonita") is True
    prof = vt.build_profile(u.id)
    assert "cachoeira" in prof.tag


def test_record_user_post(app, db):
    u, autor = mk_user(db, "ana"), mk_user(db, "bia")
    post = mk_post(db, autor, "video")
    assert vt.record(u.id, "open", post=post)
    row = VortexInteraction.query.one()
    assert (row.post_id, row.author_id, row.media_type) == (post.id, autor.id, "video")


# ------------------------------------------------------------------ perfil
def test_profile_is_empty_without_signals(app, db):
    u = mk_user(db, "ana")
    prof = vt.build_profile(u.id)
    assert prof.confidence == 0 and prof.category == {}


def test_recent_clicks_outweigh_old_ones(app, db):
    u = mk_user(db, "ana")
    old = utcnow() - timedelta(days=12)
    for _ in range(5):   # gostava de comida há 12 dias
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                         category="comida", media_type="photo", created_at=old))
    for _ in range(2):   # hoje clicou em esportes
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                         category="esportes", media_type="photo"))
    db.session.commit()
    prof = vt.build_profile(u.id)
    assert prof.category["esportes"] > prof.category["comida"]
    assert prof.top_categories[0] == "esportes"


def test_less_like_this_lowers_affinity(app, db):
    u = mk_user(db, "ana")
    for _ in range(3):
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                         category="humor", media_type="photo"))
    db.session.add(VortexInteraction(user_id=u.id, kind="less", weight=-9.0,
                                     category="humor", media_type="photo"))
    db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                     category="arte", media_type="photo"))
    db.session.commit()
    prof = vt.build_profile(u.id)
    assert "humor" not in prof.category
    assert prof.top_categories[0] == "arte"


def test_confidence_grows_with_signals(app, db):
    u = mk_user(db, "ana")
    it = mk_item(db, "natureza")
    vt.record(u.id, "open", item=it)
    low = vt.build_profile(u.id).confidence
    for _ in range(12):
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                         category="natureza", media_type="photo"))
    db.session.commit()
    assert vt.build_profile(u.id).confidence > low
    assert vt.build_profile(u.id).confidence == 1.0


# ------------------------------------------------------------------ ordenação
def seed_catalog(db):
    for _ in range(40):
        mk_item(db, "natureza", tags="paisagem,verde")
        mk_item(db, "comida", tags="prato,receita")
        mk_item(db, "esportes", tags="futebol,bola")


def like(db, user, category, times=6):
    for _ in range(times):
        db.session.add(VortexInteraction(user_id=user.id, kind="open", weight=1.0,
                                         category=category, media_type="photo",
                                         tags={"natureza": "paisagem,verde",
                                               "comida": "prato,receita",
                                               "esportes": "futebol,bola"}.get(category)))
    db.session.commit()


def test_feed_follows_taste_not_recency(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)          # os de esportes são os MAIS NOVOS (ids maiores)
    for _ in range(10):
        mk_item(db, "esportes", tags="futebol,bola")
    like(db, u, "natureza", 8)
    share = cat_share(app, db, u, n=30)
    assert share.get("natureza", 0) >= 0.55, share


def test_taste_shifts_when_user_changes_interest(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)
    like(db, u, "natureza", 8)
    assert cat_share(app, db, u, 30).get("natureza", 0) >= 0.5
    # agora passa a clicar em comida, várias vezes seguidas
    for _ in range(9):
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                         category="comida", media_type="photo",
                                         tags="prato,receita"))
    db.session.commit()
    vt.clear_caches()
    share = cat_share(app, db, u, 30)
    assert share.get("comida", 0) > share.get("natureza", 0), share


def test_user_posts_have_no_reserved_quota_or_priority(app, db):
    u, autor = mk_user(db, "ana"), mk_user(db, "bia")
    seed_catalog(db)
    for _ in range(12):
        mk_post(db, autor)            # posts novíssimos de uma conta qualquer
    like(db, u, "natureza", 10)
    keys = vt.ranked_page(app, u.id, page_size=30)["keys"]
    posts = [k for k in keys if k.startswith("p")]
    assert len(posts) <= 4, keys          # nada de 30 % fixo; só o acaso/exploração


def test_user_posts_still_appear_when_user_likes_that_author(app, db):
    u, autor = mk_user(db, "ana"), mk_user(db, "bia")
    seed_catalog(db)
    for _ in range(8):                      # posts que ela já abriu (ficam de fora por 36 h)
        seen = mk_post(db, autor)
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                         post_id=seen.id, author_id=autor.id, media_type="photo"))
    db.session.commit()
    fresh = mk_post(db, autor)              # post NOVO do mesmo autor
    for _ in range(8):
        mk_post(db, mk_user(db, f"outro{_n[0]}"))
    keys = vt.ranked_page(app, u.id, page_size=30)["keys"]
    assert f"p{fresh.id}" in keys[:10]


def test_cold_start_mixes_everything_without_error(app, db):
    u, autor = mk_user(db, "ana"), mk_user(db, "bia")
    seed_catalog(db)
    mk_post(db, autor)
    page = vt.ranked_page(app, u.id, page_size=30)
    assert len(page["keys"]) == 30 and page["has_next"]


def test_exploration_slots_bring_other_categories(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)
    like(db, u, "natureza", 12)
    keys = vt.ranked_page(app, u.id, page_size=30)["keys"]
    objs = vt.load_objects(keys)
    others = [objs[k].category for k in keys if objs[k].category != "natureza"]
    assert others, "tem que sobrar espaço pra descoberta"
    assert len(others) <= 12


def test_recently_opened_item_is_demoted(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)
    like(db, u, "natureza", 6)
    top = vt.ranked_page(app, u.id, page_size=5)["keys"]
    first = vt.load_objects(top[:1])[top[0]]
    vt.record(u.id, "open", item=first)
    vt.clear_caches()
    again = vt.ranked_page(app, u.id, page_size=30)["keys"]
    assert top[0] not in again[:5]


def test_category_filter_stays_in_category_and_has_no_user_posts(app, db):
    u, autor = mk_user(db, "ana"), mk_user(db, "bia")
    seed_catalog(db)
    mk_post(db, autor)
    keys = vt.ranked_page(app, u.id, category="comida", page_size=30)["keys"]
    objs = vt.load_objects(keys)
    assert keys and all(k.startswith("c") and objs[k].category == "comida" for k in keys)


def test_media_type_filter(app, db):
    u = mk_user(db, "ana")
    for _ in range(15):
        mk_item(db, "natureza", media="video")
        mk_item(db, "natureza", media="photo")
    keys = vt.ranked_page(app, u.id, media_type="video", page_size=30)["keys"]
    assert all(o.media_type == "video" for o in vt.load_objects(keys).values())


# ------------------------------------------------------------------ paginação
def test_pagination_never_repeats_and_walks_the_whole_list(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)
    like(db, u, "natureza", 6)
    seen, cursor = [], None
    for _ in range(40):
        page = vt.ranked_page(app, u.id, cursor=cursor, page_size=30)
        seen += page["keys"]
        cursor = page["next_cursor"]
        if not cursor:
            break
    assert len(seen) == len(set(seen)) > 60


def test_new_signal_midscroll_reorders_only_the_unseen_part(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)
    like(db, u, "natureza", 6)
    p1 = vt.ranked_page(app, u.id, page_size=30)
    # no meio da rolagem: abre e curte várias peças de esportes
    for _ in range(14):
        db.session.add(VortexInteraction(user_id=u.id, kind="like", weight=2.0,
                                         category="esportes", media_type="photo",
                                         tags="futebol,bola"))
    db.session.commit()
    p2 = vt.ranked_page(app, u.id, cursor=p1["next_cursor"], page_size=30)
    assert not set(p1["keys"]) & set(p2["keys"])          # nada repetido
    objs = vt.load_objects(p2["keys"])
    esportes = sum(1 for k in p2["keys"] if objs[k].category == "esportes")
    assert esportes >= 12                                  # a página 2 já reflete o novo gosto


def test_cursor_roundtrip_and_legacy_cursor_rejected():
    assert vt.parse_cursor(vt.format_cursor(123, 30)) == (123, 30)
    assert vt.parse_cursor("p12|c34") is None
    assert vt.parse_cursor("o30") is None
    assert vt.parse_cursor(None) is None


# ------------------------------------------------------------------ API
def test_api_vortex_personalizes_and_paginates(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)
    like(db, u, "natureza", 8)
    h = headers_for(db, u)
    c = app.test_client()
    r = c.get("/api/v1/vortex", headers=h)
    assert r.status_code == 200
    data = r.get_json()
    cats = [t["category"] for t in data["tiles"] if t["source"] == "crawler"]
    assert cats.count("natureza") / len(cats) >= 0.5
    assert data["has_next"] and data["next_cursor"].startswith("t")
    r2 = c.get(f"/api/v1/vortex?cursor={data['next_cursor']}", headers=h).get_json()
    assert not {t["key"] for t in data["tiles"]} & {t["key"] for t in r2["tiles"]}


def test_api_legacy_cursor_still_works(app, db):
    u = mk_user(db, "ana")
    seed_catalog(db)
    h = headers_for(db, u)
    r = app.test_client().get("/api/v1/vortex?cursor=p0|c999999", headers=h)
    assert r.status_code == 200 and r.get_json()["tiles"]


def test_api_item_detail_counts_as_a_click(app, db):
    u = mk_user(db, "ana")
    it = mk_item(db, "arte")
    h = headers_for(db, u)
    assert app.test_client().get(f"/api/v1/vortex/item/{it.id}", headers=h).status_code == 200
    row = VortexInteraction.query.one()
    assert (row.user_id, row.kind, row.category) == (u.id, "open", "arte")


def test_api_interact_validates_and_records(app, db):
    u, autor = mk_user(db, "ana"), mk_user(db, "bia")
    it, post = mk_item(db, "arte"), mk_post(db, autor)
    h = headers_for(db, u)
    c = app.test_client()
    assert c.post("/api/v1/vortex/interact", json={"kind": "like", "item_id": it.id},
                  headers=h).get_json()["recorded"] is True
    assert c.post("/api/v1/vortex/interact", json={"kind": "open", "post_id": post.id},
                  headers=h).get_json()["recorded"] is True
    assert c.post("/api/v1/vortex/interact", json={"kind": "bogus", "item_id": it.id},
                  headers=h).status_code == 400
    assert c.post("/api/v1/vortex/interact", json={"kind": "open"}, headers=h).status_code == 400
    assert c.post("/api/v1/vortex/interact", json={"kind": "open", "item_id": 99999},
                  headers=h).status_code == 404
    assert c.post("/api/v1/vortex/interact", json={"kind": "open", "item_id": it.id}).status_code == 401


def test_api_search_feeds_taste(app, db):
    u = mk_user(db, "ana")
    mk_item(db, "natureza", tags="cachoeira", title="Cachoeira azul")
    h = headers_for(db, u)
    app.test_client().get("/api/v1/vortex/search?q=cachoeira", headers=h)
    assert "cachoeira" in vt.build_profile(u.id).tag


def test_api_pictures_legacy_is_ranked_by_taste_with_int_cursor(app, db):
    u = mk_user(db, "ana")
    a, b = mk_user(db, "bia"), mk_user(db, "caio")
    for _ in range(4):                      # já abriu posts da Bia antes
        seen = mk_post(db, a)
        db.session.add(VortexInteraction(user_id=u.id, kind="open", weight=1.0,
                                         post_id=seen.id, author_id=a.id, media_type="photo"))
    db.session.commit()
    fav = [mk_post(db, a) for _ in range(3)]      # posts novos da Bia
    for _ in range(40):
        mk_post(db, b)                            # posts mais novos de outra pessoa
    h = headers_for(db, u)
    c = app.test_client()
    data = c.get("/api/v1/pictures", headers=h).get_json()
    got = [t["post_id"] for t in data["tiles"]]
    assert all(p.id in got for p in fav)          # autor que ela abre sobe
    assert set(data["tiles"][0]) >= {"key", "post_id", "media_url", "media_type", "author"}
    assert data["next_cursor"] is None or isinstance(data["next_cursor"], int)
    if data["next_cursor"]:
        more = c.get(f"/api/v1/pictures?cursor={data['next_cursor']}", headers=h).get_json()
        assert not set(got) & {t["post_id"] for t in more["tiles"]}


# ------------------------------------------------------------------ web
def web_login(client, db, username="webuser"):
    u = mk_user(db, username)
    with client.session_transaction() as sess:
        sess["_user_id"] = str(u.id)
        sess["_fresh"] = True
    return u


def test_web_grid_and_infinite_scroll_follow_taste(app, db):
    client = app.test_client()
    u = web_login(client, db)
    seed_catalog(db)
    like(db, u, "natureza", 8)
    html = client.get("/pictures").get_data(as_text=True)
    assert "picture-tile" in html
    more = client.get("/api/pictures/mais?cursor=" + vt.format_cursor(7, 30))
    assert more.status_code == 200 and more.get_json()["tiles"]


def test_web_detail_open_and_interact_endpoint(app, db):
    client = app.test_client()
    u = web_login(client, db)
    autor = mk_user(db, "bia")
    it, post = mk_item(db, "arte"), mk_post(db, autor)
    assert client.get(f"/pictures/item/{it.id}").status_code == 200
    assert VortexInteraction.query.filter_by(user_id=u.id, item_id=it.id, kind="open").count() == 1
    r = client.post("/api/pictures/interact", json={"kind": "open", "post_id": post.id})
    assert r.get_json() == {"ok": True, "recorded": True}
    assert client.post("/api/pictures/interact", json={"kind": "nada"}).status_code == 400


def test_web_interact_requires_login(app, db):
    assert app.test_client().post("/api/pictures/interact",
                                  json={"kind": "open", "post_id": 1}).status_code == 401
