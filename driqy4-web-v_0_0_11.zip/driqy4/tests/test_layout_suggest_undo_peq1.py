"""Peq-1: "Desfazer" no Seguir do cartão "Sugestões para você" (site)."""
import pathlib
import re

S = pathlib.Path("static/js/rail-suggest.js").read_text(encoding="utf-8")
CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")


def test_undo_button_and_window():
    assert 'rail-suggest-undo' in S and '"Desfazer"' in S
    assert re.search(r"UNDO_MS\s*=\s*\d{4,}", S)


def test_undo_uses_existing_unfollow_route_and_follow_js_state():
    assert "/deixar-de-seguir" in S
    # o estado do botão é o mesmo que follow.js usa
    assert 'data-following' in S and "is-following" in S


def test_replacement_waits_for_the_undo_window():
    # a linha não é mais trocada 1,1 s depois do clique: só quando a janela do Desfazer termina
    assert "1100" not in S
    assert "MutationObserver" in S and "scheduleLeave" in S


def test_undo_css_and_service_worker():
    assert ".rail-suggest-undo" in CSS and ".rail-suggest-undo[hidden]" in CSS
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 63  # versão do cache do SW só pode subir


def test_no_innerhtml_with_server_text():
    uses = re.findall(r"innerHTML\s*=\s*([^;\n]{0,10})", S)
    assert all(u.strip().startswith('""') for u in uses), uses
