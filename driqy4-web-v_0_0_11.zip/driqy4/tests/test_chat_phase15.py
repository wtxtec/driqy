"""Chat rico — Fase 15: documentos (msg_type=file), limpeza de órfãos, usernames reservados."""
import io
import os
import time

import pytest

PDF = b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\n" + b"x" * 80
ZIPLIKE = b"PK\x03\x04" + b"\x00" * 60
OLE = bytes.fromhex("D0CF11E0A1B11AE1") + b"\x00" * 60
HEIC = b"\x00\x00\x00\x18ftypheic" + b"\x00" * 60
MP4 = b"\x00\x00\x00\x20ftypisom" + b"\x00" * 64
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _send(c, h, to, name, data, mime="application/octet-stream", content=None, expect=200):
    form = {"file": (io.BytesIO(data), name, mime)}
    if content:
        form["content"] = content
    r = c.post(f"/api/v1/messages/{to}", headers=h, content_type="multipart/form-data", data=form)
    assert r.status_code == expect, r.get_data(as_text=True)
    return r.get_json()


def test_pdf_keeps_original_name_and_type(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "Relatório final — v2.pdf", PDF, "application/pdf")
    assert m["msg_type"] == "file" and m["media_mime"] == "application/pdf"
    assert m["media_name"] == "Relatório final — v2.pdf"
    assert m["media_size"] == len(PDF) and m["caption"] is None and m["content"] == "📎 Arquivo"
    m2 = _send(c, users[0], "beto", "a.pdf", PDF, content="segue")
    assert m2["caption"] == "segue"


def test_signature_is_checked_not_only_extension(app, users):
    c = app.test_client()
    _send(c, users[0], "beto", "falso.pdf", b"isso nao e pdf" * 10, expect=400)
    _send(c, users[0], "beto", "falso.docx", b"texto puro" * 10, expect=400)
    _send(c, users[0], "beto", "falso.xls", ZIPLIKE, expect=400)
    _send(c, users[0], "beto", "bin.txt", b"abc\x00def", expect=400)
    _send(c, users[0], "beto", "ok.docx", ZIPLIKE)
    _send(c, users[0], "beto", "ok.xls", OLE)
    _send(c, users[0], "beto", "ok.txt", "olá mundo".encode())
    _send(c, users[0], "beto", "ok.csv", b"a,b\n1,2\n")
    _send(c, users[0], "beto", "ok.rtf", b"{\\rtf1\\ansi hi}")
    _send(c, users[0], "beto", "ok.exe", PDF, expect=400)  # extensão fora da lista


def test_heic_is_accepted_as_file_but_fake_is_not(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "IMG_0001.HEIC", HEIC)
    assert m["msg_type"] == "file" and m["media_mime"] == "image/heic"
    _send(c, users[0], "beto", "fake.heic", MP4, expect=400)


def test_filename_is_sanitized_for_display(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "../../etc/passwd?.pdf", PDF)
    assert "/" not in m["media_name"] and "?" not in m["media_name"] and m["media_name"].endswith(".pdf")
    big = ("n" * 300) + ".pdf"
    m = _send(c, users[0], "beto", big, PDF)
    assert len(m["media_name"]) <= 120 and m["media_name"].endswith(".pdf")


def test_media_name_only_for_files(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "foto.png", PNG, "image/png")
    assert m["msg_type"] == "image" and m["media_name"] is None


def test_download_is_attachment_with_name_and_private(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "Orçamento 2026.pdf", PDF, "application/pdf")
    r = c.get(m["media_url"], headers=users[1])
    assert r.status_code == 200 and r.data == PDF
    cd = r.headers["Content-Disposition"]
    assert cd.startswith("attachment") and "Or%C3%A7amento" in cd
    assert r.headers["X-Content-Type-Options"] == "nosniff"
    assert c.get(m["media_url"], headers=users[2]).status_code == 404  # estranho
    img = _send(c, users[0], "beto", "f.png", PNG, "image/png")
    assert "attachment" not in c.get(img["media_url"], headers=users[1]).headers.get("Content-Disposition", "")
    assert c.get(img["media_url"] + "?download=1", headers=users[1]).headers["Content-Disposition"].startswith("attachment")


def test_site_session_can_download_file(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "x.pdf", PDF, "application/pdf")
    with app.app_context():
        from models import User
        bid = User.query.filter_by(username="beto").first().id
    site = app.test_client()
    with site.session_transaction() as s:
        s["_user_id"] = str(bid)
        s["_fresh"] = True
    r = site.get(m["media_url"])
    assert r.status_code == 200 and r.headers["Content-Disposition"].startswith("attachment")


def test_delete_for_all_removes_file_and_name(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "d.pdf", PDF)
    with app.app_context():
        from extensions import db as _db
        from models import Message
        path = os.path.join(app.config["UPLOAD_FOLDER"], *_db.session.get(Message, m["id"]).media_path.split("/"))
    assert os.path.isfile(path)
    r = c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=users[0])
    assert r.status_code == 200
    assert not os.path.isfile(path)
    with app.app_context():
        from extensions import db as _db
        from models import Message
        assert _db.session.get(Message, m["id"]).media_name is None


def test_forward_copies_file_name(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "Contrato.pdf", PDF)
    r = c.post(f"/api/v1/messages/{m['id']}/forward", headers=users[0], json={"usernames": ["caio"]})
    assert r.status_code == 200
    fm = r.get_json()["forwarded"][0]["message"]
    assert fm["media_name"] == "Contrato.pdf" and fm["forwarded"] is True


def test_search_finds_file_by_name(app, users):
    c = app.test_client()
    _send(c, users[0], "beto", "Relatório Anual.pdf", PDF)
    _send(c, users[0], "beto", "outro.pdf", PDF)
    r = c.get("/api/v1/messages/beto/search?q=relatorio", headers=users[0]).get_json()
    assert r["total"] == 1 and r["results"][0]["media_name"] == "Relatório Anual.pdf"
    assert c.get("/api/v1/messages/beto/search?q=arquivo", headers=users[0]).get_json()["total"] == 0


def test_inbox_preview_for_file_in_site(app, users):
    c = app.test_client()
    m = _send(c, users[0], "beto", "planilha_q3.pdf", PDF)
    assert m["content"] == "📎 Arquivo"
    with app.app_context():
        from models import User
        bid = User.query.filter_by(username="beto").first().id
    site = app.test_client()
    with site.session_transaction() as s:
        s["_user_id"] = str(bid)
        s["_fresh"] = True
    assert "planilha_q3.pdf" in site.get("/mensagens/").get_data(as_text=True)
    # a citação (resposta) e o push também usam o nome
    r = c.post("/api/v1/messages/beto", headers=users[0], json={"content": "ok", "reply_to_id": m["id"]}).get_json()
    assert r["reply_to"]["preview"] == "📎 planilha_q3.pdf"
    import chat_extras as cx
    from models import Message
    with app.app_context():
        from extensions import db as _db
        assert cx.push_body(_db.session.get(Message, m["id"])) == "📎 planilha_q3.pdf"


# ---------------- limpeza de órfãos ----------------

def test_orphan_cleanup_only_removes_unreferenced_old_files(app, users):
    from chat_cleanup import cleanup_orphan_chat_media
    c = app.test_client()
    m = _send(c, users[0], "beto", "keep.pdf", PDF)
    root = app.config["UPLOAD_FOLDER"]
    with app.app_context():
        from extensions import db as _db
        from models import Message
        kept = _db.session.get(Message, m["id"]).media_path
    d = os.path.join(root, "chat", "2020", "01")
    os.makedirs(d)
    old, young, thumb_ok, thumb_orphan = (os.path.join(d, n) for n in ("old.bin", "young.bin", "x.thumb", "y.thumb"))
    for p in (old, young, thumb_orphan):
        open(p, "wb").write(b"zz")
    long_ago = time.time() - 48 * 3600
    for p in (old, thumb_orphan):
        os.utime(p, (long_ago, long_ago))
    # miniatura de vídeo referenciado não pode ser apagada
    with app.app_context():
        from extensions import db as _db
        from models import Message
        vm = Message(sender_id=1, recipient_id=2, content="v", msg_type="video", media_path="chat/2020/01/x")
        _db.session.add(vm); _db.session.commit()
    open(thumb_ok, "wb").write(b"zz"); os.utime(thumb_ok, (long_ago, long_ago))

    r = cleanup_orphan_chat_media(app, apply=False)
    assert r["found"] == 2 and r["deleted"] == 0 and os.path.isfile(old)
    r = cleanup_orphan_chat_media(app, apply=True)
    assert r["deleted"] == 2
    assert not os.path.exists(old) and not os.path.exists(thumb_orphan)
    assert os.path.isfile(young) and os.path.isfile(thumb_ok)
    assert os.path.isfile(os.path.join(root, *kept.split("/")))


def test_cleanup_script_importable():
    import importlib
    assert importlib.import_module("cleanup_chat_media")


# ---------------- usernames reservados / rotas antigas / sw ----------------

@pytest.mark.parametrize("name", ["privacy", "Stream", "chamadas", "api"])
def test_reserved_usernames_are_refused_on_register(app, name):
    c = app.test_client()
    r = c.post("/api/v1/auth/register", json={"username": name, "email": f"{name}@x.com", "password": "senha1234"})
    assert r.status_code == 400
    r = c.post("/api/v1/auth/register", json={"username": "normal_1", "email": "n@x.com", "password": "senha1234"})
    assert r.status_code in (200, 201)


def test_old_site_routes_are_gone(app, users):
    c = app.test_client()
    assert c.post("/mensagens/beto/enviar", data={"content": "x"}).status_code in (404, 405)
    assert c.get("/mensagens/api/beto/novas").status_code == 404


def test_pages_have_file_ui_and_sw_v22(app, users):
    with app.app_context():
        from models import User
        aid = User.query.filter_by(username="ana").first().id
    site = app.test_client()
    with site.session_transaction() as s:
        s["_user_id"] = str(aid)
        s["_fresh"] = True
    html = site.get("/mensagens/beto").get_data(as_text=True)
    assert "chat-thread.js" in html
    js = site.get("/static/js/chat-thread.js").get_data(as_text=True)
    assert "fileBlock" in js and "application/pdf" in js
    assert "driqy-shell-v" in site.get("/static/sw.js").get_data(as_text=True)
