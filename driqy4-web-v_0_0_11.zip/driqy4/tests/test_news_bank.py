"""Banco de notícias temporário (3 dias) + classificador v2 + recomendador usando o banco."""
from datetime import timedelta

import pytest

from config import Config
from models import NewsArticle, NewsBankItem, NewsInteraction, NewsSource, User, utcnow
from news_classifier import category_from_url, classify, classify_article

K = Config.NEWS_CATEGORY_KEYWORDS


# ---------------------------------------------------------------- classificador

LABELED = [
    # (título, resumo, url, prior, esperado)
    ("Dólar fecha em alta e Ibovespa recua com cautela no exterior", "", "https://www.poder360.com.br/economia/x", "politica", "economia"),
    ("Lula sanciona lei e oposição critica no Congresso", "", "", None, "politica"),
    ("Santos vence o Palmeiras e assume a liderança do Brasileirão", "", "", None, "esportes"),
    ("Prefeitura de Santos abre vagas de emprego", "", "", None, "geral"),   # 'santos' sozinho não é esporte
    ("Justiça da Bahia condena empresário por fraude", "", "", None, "geral"),
    ("Pesquisadores descobrem nova espécie de dinossauro no Brasil", "", "", None, "ciencia"),
    ("Anvisa aprova vacina contra dengue para adultos", "", "", None, "saude"),
    ("Samsung lança novo smartphone com inteligência artificial", "", "", None, "tecnologia"),
    ("Série da Netflix estreia com elenco famoso e vira sucesso", "", "", None, "entretenimento"),
    ("Putin e Zelensky: guerra na Ucrânia entra em nova fase", "", "", None, "mundo"),
    ("Pesquisa eleitoral mostra empate técnico entre candidatos", "", "", None, "politica"),
    # fonte "geral" e matéria claramente de outra área: a URL decide
    ("Governo anuncia pacote", "", "https://g1.globo.com/economia/noticia/2026/x.ghtml", "geral", "economia"),
    ("Final emocionante", "", "https://ge.globo.com/futebol/x.ghtml", None, "esportes"),
    # prior especializado se mantém sem evidência contrária
    ("Nova atualização chega aos usuários", "", "", "tecnologia", "tecnologia"),
]


@pytest.mark.parametrize("title,summary,url,prior,expected", LABELED)
def test_classifier_v2_labeled_examples(title, summary, url, prior, expected):
    info = classify_article(title, summary, K, url=url, prior=prior,
                            default_category=prior or "geral")
    assert info.category == expected, (title, info)


def test_classifier_accents_and_plurals():
    assert classify("Eleicoes: candidatos fazem debate", "", K)[0] == "politica"       # sem acento
    assert classify("Cientista explica descoberta sobre fosseis", "", K)[0] == "ciencia"
    assert classify("Gols decidem a rodada do campeonato", "", K)[0] == "esportes"       # plural


def test_url_section_and_host():
    assert category_from_url("https://g1.globo.com/politica/noticia/x") == "politica"
    assert category_from_url("https://ge.globo.com/qualquer/x") == "esportes"
    assert category_from_url("https://example.com/blog/post") is None


def test_feed_tags_count_and_specialized_source_can_be_overridden():
    info = classify_article("Texto neutro sobre algo", "", K, tags=["Economia", "Brasil"], prior="geral")
    assert info.category == "economia"
    # fonte de política com matéria claramente de esporte (título + resumo fortes)
    info = classify_article("Flamengo vence o Palmeiras e é campeão do Brasileirão", "O técnico elogiou os jogadores",
                            K, prior="politica")
    assert info.category == "esportes"
    # mas uma pista fraca não derruba o prior
    info = classify_article("Presidente fala sobre o tema", "", K, prior="politica")
    assert info.category == "politica"


def test_secondary_categories_and_confidence():
    info = classify_article("Reforma tributária divide o governo e o Congresso", "Impostos e inflação no centro do debate",
                            K, default_category="geral")
    assert info.category in ("economia", "politica")
    assert len(info.secondary) >= 1 and 0 < info.confidence <= 1


# ---------------------------------------------------------------- banco

def _source(db, name="S", cat=None):
    s = NewsSource(name=name, feed_url=f"https://{name}.example/feed", default_category=cat)
    db.session.add(s)
    db.session.commit()
    return s


def _art(db, src, title, category="geral", hours_ago=1.0, indexed_hours_ago=None, n=[0], url=None, image="https://i/x.jpg"):
    n[0] += 1
    a = NewsArticle(
        source_id=src.id, title=title, summary="", url=url or f"https://x.example/{n[0]}",
        url_hash=f"b{n[0]:040d}", image_url=image, category=category,
        published_at=utcnow() - timedelta(hours=hours_ago),
        indexed_at=utcnow() - timedelta(hours=indexed_hours_ago if indexed_hours_ago is not None else hours_ago),
    )
    db.session.add(a)
    db.session.commit()
    return a


def test_bank_ttl_is_three_days_and_purge_deletes(app, db):
    import news_bank
    assert app.config["NEWS_BANK_TTL_DAYS"] == 3
    s = _source(db)
    fresh = _art(db, s, "Governo anuncia reforma ministerial", "politica", hours_ago=2)
    old = _art(db, s, "Notícia velha do mês passado sobre economia", "economia", hours_ago=100)
    news_bank.add_articles(app, [fresh, old])
    db.session.commit()
    assert NewsBankItem.query.count() == 1  # a de 100h (>72h) nem entra: já nasceria vencida
    item = NewsBankItem.query.first()
    assert item.expires_at - item.created_at <= timedelta(days=3, minutes=1)
    # vence com o tempo
    item.expires_at = utcnow() - timedelta(minutes=1)
    db.session.commit()
    assert news_bank.purge_expired(app) == 1
    assert NewsBankItem.query.count() == 0


def test_purge_removes_orphans_and_respects_cap(app, db):
    import news_bank
    s = _source(db)
    arts = [_art(db, s, f"Matéria distinta número {i} sobre assuntos variados {i*7}", "geral", hours_ago=1 + i * 0.01) for i in range(6)]
    news_bank.add_articles(app, arts)
    db.session.commit()
    NewsArticle.query.filter_by(id=arts[0].id).delete()   # notícia removida => ficha órfã
    db.session.commit()
    assert news_bank.purge_expired(app) == 1
    app.config["NEWS_BANK_MAX_ITEMS"] = 3
    news_bank.purge_expired(app)
    assert NewsBankItem.query.count() == 3


def test_backfill_recreates_cards_without_network(app, db):
    import news_bank
    s = _source(db)
    for i in range(5):
        _art(db, s, f"Notícia recente {i} sobre o mercado financeiro hoje {i}", "economia", hours_ago=i + 1)
    assert NewsBankItem.query.count() == 0
    assert news_bank.backfill(app) == 5
    assert news_bank.backfill(app) == 0      # idempotente
    assert news_bank.maintain(app)["size"] == 5


def test_same_story_from_other_outlets_shares_story_id(app, db):
    import news_bank
    a, b, c = (_source(db, n) for n in "ABC")
    x1 = _art(db, a, "Governo anuncia novo pacote de medidas para a economia brasileira")
    x2 = _art(db, b, "Governo anuncia pacote de medidas para economia brasileira hoje")
    y = _art(db, c, "Flamengo vence clássico carioca no Maracanã lotado")
    news_bank.add_articles(app, [x1])
    db.session.commit()
    news_bank.add_articles(app, [x2, y])
    db.session.commit()
    items = {i.article_id: i for i in NewsBankItem.query.all()}
    assert items[x1.id].story_id == items[x2.id].story_id != items[y.id].story_id


def test_extract_terms_normalized_and_proper_names_first():
    import news_bank
    terms = news_bank.extract_terms("Governo de Lula anuncia reformas tributárias", "O Congresso analisa as propostas")
    assert "lula" in terms[:2]
    assert "reforma" in terms and "tributaria" in terms     # singular, sem acento
    assert "governo" not in terms                            # stopword


def test_recommender_reads_from_bank_and_uses_precomputed_stories(app, db):
    import news_bank
    import news_recommender
    from news_recommender import recommended_articles
    app.config["NEWS_BANK_MIN_ITEMS"] = 3
    news_recommender._pool_cache._store.clear()
    srcs = [_source(db, f"S{i}") for i in range(4)]
    a1 = _art(db, srcs[0], "Governo anuncia novo pacote de medidas para a economia brasileira", "economia", hours_ago=1)
    a2 = _art(db, srcs[1], "Governo anuncia pacote de medidas para economia brasileira hoje", "economia", hours_ago=2)
    a3 = _art(db, srcs[2], "Flamengo vence clássico carioca no Maracanã lotado", "esportes", hours_ago=3)
    a4 = _art(db, srcs[3], "Cientistas descobrem exoplaneta habitável", "ciencia", hours_ago=4)
    news_bank.add_articles(app, [a1, a2, a3, a4])
    db.session.commit()
    pool = news_recommender._build_raw_pool(None)
    assert pool.get("from_bank") is True
    assert pool["coverage"][a1.id] == 2 and pool["coverage"][a3.id] == 1
    assert len(pool["duplicates"] & {a1.id, a2.id}) == 1
    # um artigo FORA do banco (vencido) não entra no pool
    NewsBankItem.query.filter_by(article_id=a4.id).update({"expires_at": utcnow() - timedelta(hours=1)})
    db.session.commit()
    news_recommender._pool_cache._store.clear()
    arts, _ = recommended_articles(None, limit=10)
    assert a4.id not in {a.id for a in arts}


def test_recommender_personalizes_with_bank_terms_and_secondary(app, db):
    import news_bank
    import news_recommender
    from news_recommender import recommended_articles
    app.config["NEWS_BANK_MIN_ITEMS"] = 3
    news_recommender._pool_cache._store.clear()
    s1, s2, s3, s4 = (_source(db, f"T{i}") for i in range(4))
    clicked = _art(db, s1, "Copa do Mundo: seleção brasileira divulga lista de convocados", "esportes", hours_ago=30)
    match = _art(db, s2, "Seleção brasileira treina para a Copa do Mundo", "esportes", hours_ago=5)
    other_sport = _art(db, s3, "Torneio de xadrez movimenta cidade", "esportes", hours_ago=5)
    filler = _art(db, s4, "Dólar fecha em queda", "economia", hours_ago=5)
    news_bank.add_articles(app, [clicked, match, other_sport, filler])
    db.session.commit()
    user = User(username="leitor2", email="l2@example.com")
    user.set_password("senha1234")
    db.session.add(user)
    db.session.commit()
    db.session.add(NewsInteraction(user_id=user.id, article_id=clicked.id, category="esportes", created_at=utcnow()))
    db.session.commit()
    from types import SimpleNamespace
    u = SimpleNamespace(id=user.id, is_authenticated=True, location="")
    scores = {}
    for _ in range(5):   # o jitter é pequeno: média de algumas rodadas
        news_recommender._pool_cache._store.clear()
        arts, _ = recommended_articles(u, limit=10)
        for pos, a in enumerate(arts):
            scores[a.id] = scores.get(a.id, 0) + pos
    assert scores[match.id] < scores[other_sport.id]   # mesmo assunto sobe, mesmo estando na mesma categoria


def test_indexer_stores_cards_and_uses_url_and_tags(app, db, monkeypatch):
    import feedparser
    import news_indexer
    xml = b"""<?xml version="1.0"?><rss version="2.0"><channel><title>t</title>
    <item><title>Governo anuncia pacote</title><link>https://g1.globo.com/economia/noticia/2026/a.ghtml</link>
      <description>resumo</description><category>Economia</category></item>
    <item><title>Texto neutro de blog</title><link>https://blog.example/post/1</link>
      <description>nada</description><category>Esportes</category></item></channel></rss>"""

    class R:
        content = xml
        def raise_for_status(self): pass

    monkeypatch.setattr(news_indexer.requests, "get", lambda *a, **k: R())
    monkeypatch.setattr(news_indexer, "_fetch_og_image", lambda u: None)
    s = _source(db, "Generica", None)
    n = news_indexer.index_source(db, s, app.config["NEWS_CATEGORY_KEYWORDS"])
    assert n == 2
    cats = {a.title: a.category for a in NewsArticle.query.all()}
    assert cats["Governo anuncia pacote"] == "economia"   # seção da URL + tag
    assert cats["Texto neutro de blog"] == "esportes"     # tag do feed
    assert NewsBankItem.query.count() == 2
