"""Chat rico — Fase 8: editar, encaminhar, buscar na conversa."""
import io
import os
from datetime import timedelta

import pytest

MP4 = b"\x00\x00\x00\x20ftypisom" + b"\x00" * 64
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 200
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio", "dani"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _text(c, h, to, text, **extra):
    r = c.post(f"/api/v1/messages/{to}", headers=h, json={"content": text, **extra})
    assert r.status_code == 200, r.get_data(as_text=True)
    return r.get_json()


def _media(c, h, to, name, data, mime, content=None, thumb=False):
    form = {"file": (io.BytesIO(data), name, mime)}
    if content:
        form["content"] = content
    if thumb:
        form["thumb"] = (io.BytesIO(JPEG), "t.jpg", "image/jpeg")
    r = c.post(f"/api/v1/messages/{to}", headers=h, content_type="multipart/form-data", data=form)
    assert r.status_code == 200, r.get_data(as_text=True)
    return r.get_json()


def _age(app, message_id, **delta):
    from extensions import db as _db
    from models import Message, utcnow
    with app.app_context():
        m = _db.session.get(Message, message_id)
        m.created_at = utcnow() - timedelta(**delta)
        _db.session.commit()


# ---------------- editar ----------------

def test_edit_text_sets_edited_at_and_updates_preview(app, users):
    c = app.test_client()
    ana, beto = users[0], users[1]
    m = _text(c, ana, "beto", "oi mundo")
    assert m["can_edit"] is True and m["edited_at"] is None
    r = c.patch(f"/api/v1/messages/{m['id']}", headers=ana, json={"content": "  olá mundo  "})
    assert r.status_code == 200
    j = r.get_json()
    assert j["content"] == "olá mundo" and j["edited_at"]
    # o outro lado vê editada
    thread = c.get("/api/v1/messages/ana", headers=beto).get_json()["messages"]
    assert thread[0]["content"] == "olá mundo" and thread[0]["edited_at"]
    assert thread[0]["can_edit"] is False  # não é o remetente


def test_edit_same_text_is_not_an_edit(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "igual")
    r = c.patch(f"/api/v1/messages/{m['id']}", headers=users[0], json={"content": "igual"})
    assert r.status_code == 200 and r.get_json()["edited_at"] is None


def test_edit_rules(app, users):
    c = app.test_client()
    ana, beto, caio = users[0], users[1], users[2]
    m = _text(c, ana, "beto", "texto")
    assert c.patch(f"/api/v1/messages/{m['id']}", headers=beto, json={"content": "x"}).status_code == 403
    assert c.patch(f"/api/v1/messages/{m['id']}", headers=caio, json={"content": "x"}).status_code == 404
    assert c.patch(f"/api/v1/messages/{m['id']}", headers=ana, json={"content": "   "}).status_code == 400
    assert c.patch("/api/v1/messages/99999", headers=ana, json={"content": "x"}).status_code == 404
    img = _media(c, ana, "beto", "a.png", PNG, "image/png", content="legenda")
    assert img["can_edit"] is False
    assert c.patch(f"/api/v1/messages/{img['id']}", headers=ana, json={"content": "x"}).status_code == 400


def test_edit_window_and_deleted(app, users):
    c = app.test_client()
    ana = users[0]
    m = _text(c, ana, "beto", "velha")
    _age(app, m["id"], hours=25)
    r = c.patch(f"/api/v1/messages/{m['id']}", headers=ana, json={"content": "nova"})
    assert r.status_code == 403
    thread = c.get("/api/v1/messages/beto", headers=ana).get_json()["messages"]
    assert thread[0]["can_edit"] is False
    m2 = _text(c, ana, "beto", "vai apagar")
    assert c.delete(f"/api/v1/messages/{m2['id']}?scope=all", headers=ana).status_code == 200
    assert c.patch(f"/api/v1/messages/{m2['id']}", headers=ana, json={"content": "x"}).status_code == 404


def test_edit_hidden_for_sender_is_404(app, users):
    c = app.test_client()
    ana = users[0]
    m = _text(c, ana, "beto", "escondida")
    assert c.delete(f"/api/v1/messages/{m['id']}?scope=me", headers=ana).status_code == 200
    assert c.patch(f"/api/v1/messages/{m['id']}", headers=ana, json={"content": "x"}).status_code == 404


def test_reply_preview_reflects_edit(app, users):
    c = app.test_client()
    ana, beto = users[0], users[1]
    m = _text(c, ana, "beto", "original")
    _text(c, beto, "ana", "respondi", reply_to_id=m["id"])
    c.patch(f"/api/v1/messages/{m['id']}", headers=ana, json={"content": "editado"})
    thread = c.get("/api/v1/messages/ana", headers=beto).get_json()["messages"]
    assert thread[1]["reply_to"]["preview"] == "editado"


# ---------------- encaminhar ----------------

def test_forward_text_to_many(app, users):
    c = app.test_client()
    ana = users[0]
    m = _text(c, users[1], "ana", "encaminha isso")
    r = c.post(f"/api/v1/messages/{m['id']}/forward", headers=ana, json={"usernames": ["caio", "dani", "caio"]})
    assert r.status_code == 200
    out = r.get_json()["forwarded"]
    assert [o["username"] for o in out] == ["caio", "dani"]
    assert all(o["message"]["forwarded"] and o["message"]["mine"] for o in out)
    assert all(o["message"]["content"] == "encaminha isso" for o in out)
    # aparece na conversa do destino
    t = c.get("/api/v1/messages/ana", headers=users[2]).get_json()["messages"]
    assert len(t) == 1 and t[0]["forwarded"] is True and t[0]["mine"] is False
    # original não ganha selo
    orig = c.get("/api/v1/messages/beto", headers=ana).get_json()["messages"][0]
    assert orig["forwarded"] is False


def test_forward_validation(app, users):
    c = app.test_client()
    ana = users[0]
    m = _text(c, ana, "beto", "x")
    url = f"/api/v1/messages/{m['id']}/forward"
    assert c.post(url, headers=ana, json={}).status_code == 400
    assert c.post(url, headers=ana, json={"usernames": []}).status_code == 400
    assert c.post(url, headers=ana, json={"usernames": ["ana"]}).status_code == 400
    assert c.post(url, headers=ana, json={"usernames": ["fantasma"]}).status_code == 404
    too_many = ["beto", "caio", "dani", "a1", "a2", "a3"]
    assert c.post(url, headers=ana, json={"usernames": too_many}).status_code == 400
    # destino inválido no meio: nada é criado
    assert c.post(url, headers=ana, json={"usernames": ["caio", "fantasma"]}).status_code == 404
    assert c.get("/api/v1/messages/ana", headers=users[2]).get_json()["messages"] == []
    # estranho não encaminha mensagem alheia
    assert c.post(url, headers=users[2], json={"usernames": ["dani"]}).status_code == 404


def test_forward_deleted_or_hidden_is_404(app, users):
    c = app.test_client()
    ana = users[0]
    m = _text(c, ana, "beto", "x")
    n = _text(c, ana, "beto", "y")
    c.delete(f"/api/v1/messages/{m['id']}?scope=all", headers=ana)
    c.delete(f"/api/v1/messages/{n['id']}?scope=me", headers=ana)
    for mid in (m["id"], n["id"]):
        assert c.post(f"/api/v1/messages/{mid}/forward", headers=ana, json={"usernames": ["caio"]}).status_code == 404


def test_forward_media_copies_file_and_survives_delete(app, users):
    c = app.test_client()
    ana = users[0]
    v = _media(c, users[1], "ana", "v.mp4", MP4, "video/mp4", content="olha", thumb=True)
    r = c.post(f"/api/v1/messages/{v['id']}/forward", headers=ana, json={"usernames": ["caio"]})
    assert r.status_code == 200
    fm = r.get_json()["forwarded"][0]["message"]
    assert fm["msg_type"] == "video" and fm["caption"] == "olha" and fm["forwarded"]
    assert fm["media_thumb_url"]
    # arquivo próprio do destino: serve para caio
    assert c.get(fm["media_url"], headers=users[2]).status_code == 200
    assert c.get(fm["media_thumb_url"], headers=users[2]).status_code == 200
    # apagar o original para todos não quebra o encaminhado
    assert c.delete(f"/api/v1/messages/{v['id']}?scope=all", headers=users[1]).status_code == 200
    assert c.get(fm["media_url"], headers=users[2]).status_code == 200
    # e o contrário: apagar o encaminhado não afeta outros
    from extensions import db as _db
    from models import Message
    with app.app_context():
        paths = {m.id: m.media_path for m in Message.query.all() if m.media_path}
    assert fm["id"] in paths


def test_forward_image_and_audio_keep_metadata(app, users):
    c = app.test_client()
    ana = users[0]
    img = _media(c, users[1], "ana", "a.png", PNG, "image/png")
    r = c.post(f"/api/v1/messages/{img['id']}/forward", headers=ana, json={"usernames": ["caio"]})
    fm = r.get_json()["forwarded"][0]["message"]
    assert fm["msg_type"] == "image" and fm["media_mime"] == "image/png"
    assert c.get(fm["media_url"], headers=users[2]).data.startswith(b"\x89PNG")


def test_forward_client_id_is_idempotent(app, users):
    c = app.test_client()
    ana = users[0]
    m = _text(c, ana, "beto", "uma vez")
    url = f"/api/v1/messages/{m['id']}/forward"
    a = c.post(url, headers=ana, json={"usernames": ["caio"], "client_id": "fw-1"}).get_json()
    b = c.post(url, headers=ana, json={"usernames": ["caio"], "client_id": "fw-1"}).get_json()
    assert a["forwarded"][0]["message"]["id"] == b["forwarded"][0]["message"]["id"]
    assert len(c.get("/api/v1/messages/ana", headers=users[2]).get_json()["messages"]) == 1


def test_forward_missing_file_gives_410(app, users):
    c = app.test_client()
    ana = users[0]
    img = _media(c, ana, "beto", "a.png", PNG, "image/png")
    from extensions import db as _db
    from models import Message
    with app.app_context():
        m = _db.session.get(Message, img["id"])
        os.remove(os.path.join(app.config["UPLOAD_FOLDER"], *m.media_path.split("/")))
    r = c.post(f"/api/v1/messages/{img['id']}/forward", headers=ana, json={"usernames": ["caio"]})
    assert r.status_code == 410
    assert c.get("/api/v1/messages/ana", headers=users[2]).get_json()["messages"] == []


# ---------------- buscar ----------------

def test_search_basic_accent_and_case_insensitive(app, users):
    c = app.test_client()
    ana, beto = users[0], users[1]
    _text(c, ana, "beto", "Reunião amanhã às 10h")
    _text(c, beto, "ana", "ok, combinado")
    _text(c, ana, "beto", "AÇÃO urgente")
    j = c.get("/api/v1/messages/beto/search?q=reuniao", headers=ana).get_json()
    assert j["total"] == 1 and j["results"][0]["content"] == "Reunião amanhã às 10h"
    j = c.get("/api/v1/messages/beto/search?q=acao", headers=ana).get_json()
    assert j["total"] == 1
    j = c.get("/api/v1/messages/ana/search?q=COMBINADO", headers=beto).get_json()
    assert j["total"] == 1 and j["results"][0]["mine"] is True


def test_search_orders_newest_first_and_paginates(app, users):
    c = app.test_client()
    ana = users[0]
    ids = [_text(c, ana, "beto", f"gato {i}")["id"] for i in range(5)]
    j = c.get("/api/v1/messages/beto/search?q=gato&limit=2", headers=ana).get_json()
    assert [m["id"] for m in j["results"]] == [ids[4], ids[3]]
    assert j["total"] == 5 and j["has_more"] is True
    j2 = c.get(f"/api/v1/messages/beto/search?q=gato&limit=2&before_id={ids[3]}", headers=ana).get_json()
    assert [m["id"] for m in j2["results"]] == [ids[2], ids[1]]
    j3 = c.get(f"/api/v1/messages/beto/search?q=gato&limit=5&before_id={ids[1]}", headers=ana).get_json()
    assert [m["id"] for m in j3["results"]] == [ids[0]] and j3["has_more"] is False


def test_search_captions_yes_labels_no(app, users):
    c = app.test_client()
    ana = users[0]
    _media(c, ana, "beto", "a.png", PNG, "image/png", content="praia linda")
    _media(c, ana, "beto", "b.png", PNG, "image/png")
    assert c.get("/api/v1/messages/beto/search?q=praia", headers=ana).get_json()["total"] == 1
    assert c.get("/api/v1/messages/beto/search?q=foto", headers=ana).get_json()["total"] == 0


def test_search_respects_deleted_and_hidden(app, users):
    c = app.test_client()
    ana, beto = users[0], users[1]
    a = _text(c, ana, "beto", "segredo um")
    b = _text(c, ana, "beto", "segredo dois")
    d = _text(c, ana, "beto", "segredo tres")
    c.delete(f"/api/v1/messages/{a['id']}?scope=all", headers=ana)
    c.delete(f"/api/v1/messages/{b['id']}?scope=me", headers=beto)
    assert c.get("/api/v1/messages/ana/search?q=segredo", headers=beto).get_json()["total"] == 1
    # ana escondeu nada além da apagada para todos: b e d continuam para ela
    assert c.get("/api/v1/messages/beto/search?q=segredo", headers=ana).get_json()["total"] == 2
    assert d["id"]


def test_search_validation_and_isolation(app, users):
    c = app.test_client()
    ana = users[0]
    _text(c, ana, "beto", "privado entre os dois")
    assert c.get("/api/v1/messages/beto/search?q=a", headers=ana).status_code == 400
    assert c.get("/api/v1/messages/beto/search", headers=ana).status_code == 400
    assert c.get("/api/v1/messages/ana/search?q=privado", headers=ana).status_code == 400  # a si mesma
    assert c.get("/api/v1/messages/fantasma/search?q=privado", headers=ana).status_code == 404
    # caio conversando com ana não enxerga a conversa ana↔beto
    assert c.get("/api/v1/messages/ana/search?q=privado", headers=users[2]).get_json()["total"] == 0
    assert c.get("/api/v1/messages/beto/search?q=privado").status_code in (401, 403)


def test_search_wildcards_are_literal(app, users):
    c = app.test_client()
    ana = users[0]
    _text(c, ana, "beto", "100% certo")
    _text(c, ana, "beto", "cem por cento")
    assert c.get("/api/v1/messages/beto/search?q=100%25", headers=ana).get_json()["total"] == 1
    assert c.get("/api/v1/messages/beto/search?q=%25%25", headers=ana).get_json()["total"] == 0


def test_forwarded_flag_migration_on_old_db(tmp_path):
    """Banco antigo sem a coluna `forwarded` ganha a coluna ao subir o app."""
    import sqlite3
    from config import Config
    path = tmp_path / "old.db"

    class Cfg(Config):
        TESTING = True
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{path}"
        UPLOAD_FOLDER = str(tmp_path / "up")
        WTF_CSRF_ENABLED = False

    from app import create_app
    create_app(Cfg)
    con = sqlite3.connect(path)
    con.execute("ALTER TABLE messages DROP COLUMN forwarded")
    con.commit(); con.close()
    create_app(Cfg)
    con = sqlite3.connect(path)
    cols = [r[1] for r in con.execute("PRAGMA table_info(messages)")]
    con.close()
    assert "forwarded" in cols
