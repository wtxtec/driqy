"""Minha área, Parte 3: site com os 10 widgets novos e os widgets próprios (rail-new.js, rail-mine.js)."""
import pathlib
import re

NEW = pathlib.Path("static/js/rail-new.js").read_text(encoding="utf-8")
MINE = pathlib.Path("static/js/rail-mine.js").read_text(encoding="utf-8")
EDIT = pathlib.Path("static/js/rail-edit.js").read_text(encoding="utf-8")
RAIL = pathlib.Path("static/js/rail.js").read_text(encoding="utf-8")


def _login(app, name="ana"):
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User(username=name, email=f"{name}@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": name, "password": "senha1234"})
    return c


def test_all_builtin_ids_have_a_renderer():
    """Todo id pronto do servidor precisa estar registrado em algum .js (senão nunca aparece no seletor)."""
    from api_widgets import WIDGETS
    sources = "".join(pathlib.Path(f"static/js/{n}.js").read_text(encoding="utf-8")
                      for n in ("rail-weather", "rail-widgets", "rail-new"))
    for w in WIDGETS:
        assert re.search(r'["\']%s["\']' % w["id"], sources), w["id"]


def test_no_unsafe_html_sinks():
    for name, src in (("new", NEW), ("mine", MINE), ("edit", EDIT)):
        assert not re.search(r"innerHTML\s*=\s*[^\"'\s]", src), name
        assert "insertAdjacentHTML" not in src and "document.write" not in src and "eval(" not in src, name
    assert "http" in MINE and "noopener noreferrer" in MINE  # links próprios só http(s), sem opener
    assert "X-Requested-With" in MINE


def test_rail_api_for_runtime_widgets():
    for fn in ("unregister:", "rename:", "showId:", "openEditor"):
        assert fn in RAIL
    for fn in ("DriqyMine.create", "DriqyMine.remove"):
        assert fn in EDIT
    assert "window.DriqyMine" in MINE and "create:" in MINE and "remove:" in MINE


def test_page_loads_scripts_and_exposes_custom_widgets(app):
    c = _login(app)
    h = {"X-Requested-With": "fetch"}
    wid = c.post("/api/v1/widgets/custom", headers=h, json={"kind": "note", "title": "Lembretes"}).get_json()["widget"]["id"]
    html = c.get("/").get_data(as_text=True)
    assert html.index("js/rail-widgets.js") < html.index("js/rail-new.js") < html.index("js/rail-mine.js") < html.index("js/rail-suggest.js")
    assert '"max_custom": 12' in html or '"max_custom":12' in html
    assert wid in html and "Lembretes" in html  # catálogo do cliente já inclui o widget próprio (sem `data`)
    assert '"data"' not in html.split("window.__railCfg =")[1].split(";</script>")[0]


def test_custom_note_roundtrip_via_api_as_site_does(app):
    """O site lê GET /custom/<n> ao abrir e salva com PUT {data}; renomear manda {title}."""
    c = _login(app)
    h = {"X-Requested-With": "fetch"}
    n = c.post("/api/v1/widgets/custom", headers=h, json={"kind": "counter"}).get_json()["widget"]["widget_id"]
    r = c.put(f"/api/v1/widgets/custom/{n}", headers=h, json={"data": {"value": 3, "step": 2, "goal": 10, "unit": "copos"}})
    assert r.get_json()["widget"]["data"] == {"value": 3, "step": 2, "goal": 10, "unit": "copos"}
    r = c.put(f"/api/v1/widgets/custom/{n}", headers=h, json={"title": "Água"})
    assert r.get_json()["widget"]["title"] == "Água" and r.get_json()["widget"]["data"]["value"] == 3
    assert c.get(f"/api/v1/widgets/custom/{n}").get_json()["widget"]["title"] == "Água"
