import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config  # noqa: E402


@pytest.fixture()
def app(tmp_path):
    class TestConfig(Config):
        TESTING = True
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{tmp_path / 'test.db'}"
        UPLOAD_FOLDER = str(tmp_path / "uploads")
        WTF_CSRF_ENABLED = False
        VORTEX_PHASH_PER_RUN = 50
        VORTEX_STATS_TTL_SECONDS = 0  # sem cache nos testes
        VORTEX_PHASH_RECHECK_SECONDS = 0
        CHAT_PRESENCE_GRACE_SECONDS = 0  # Fase 10: "offline" na hora (sem Timer solto nos testes)

    from app import create_app
    application = create_app(TestConfig)
    yield application


@pytest.fixture()
def db(app):
    from extensions import db as _db
    with app.app_context():
        yield _db


@pytest.fixture()
def user_token(app):
    """Cria um usuário + token Bearer e devolve (user_id, headers)."""
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        u = User(username="tester", email="t@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
        tok = ApiToken.generate_for(u)
        _db.session.commit()
        return u.id, {"Authorization": f"Bearer {tok.token}"}


@pytest.fixture(autouse=True)
def _isolate_vortex_control(tmp_path, monkeypatch):
    """O controle do Vortex (pausa/velocidade) tem cache de módulo e grava
    arquivos em instance/: cada teste começa limpo e não suja a pasta real."""
    import vortex_control
    monkeypatch.setattr(vortex_control, "STATS_FILE", str(tmp_path / "vortex_engine_stats.json"))
    monkeypatch.setattr(vortex_control, "PURGE_FILE", str(tmp_path / "vortex_purge_job.json"))
    vortex_control.invalidate_control_cache()
    vortex_control.clear_overview_cache()
    yield
    vortex_control.invalidate_control_cache()
    vortex_control.clear_overview_cache()


@pytest.fixture(autouse=True)
def _isolate_vortex_taste():
    """O motor de gosto guarda perfis, sessões de rolagem e a lista de posts em
    cache de módulo; cada teste usa um banco novo, então começa com tudo limpo."""
    import vortex_taste
    vortex_taste.clear_caches()
    yield
    vortex_taste.clear_caches()
