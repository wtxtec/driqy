"""Fase 2 do Ping: os tokens de tema existem nos dois temas (e o cache do SW subiu)."""
import re
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "static"
CSS = (STATIC / "css" / "style.css").read_text(encoding="utf-8")

DARK_TOKENS = [
    "--ping-gradient", "--ping-on-accent", "--ping-bg", "--ping-panel", "--ping-panel-hover",
    "--ping-row-active", "--ping-search-bg", "--ping-bubble-in", "--ping-bubble-in-text",
    "--ping-bubble-out", "--ping-bubble-out-text", "--ping-badge", "--ping-badge-muted",
    "--ping-pill-bg", "--ping-radius-panel", "--ping-radius-pill", "--ping-pattern",
]
LIGHT_OVERRIDES = [
    "--ping-on-accent", "--ping-bg", "--ping-panel", "--ping-panel-hover", "--ping-search-bg",
    "--ping-bubble-in", "--ping-bubble-in-text", "--ping-bubble-out-text", "--ping-badge-muted",
    "--ping-pill-bg", "--ping-pattern",
]


def _block(selector_start):
    i = CSS.index(selector_start, CSS.index("Tokens do Ping"))
    return CSS[i:CSS.index("\n}\n", i)]


def test_dark_tokens():
    block = _block(":root,\n[data-theme=\"dark\"] {")
    for t in DARK_TOKENS:
        assert re.search(re.escape(t) + r"\s*:", block), t


def test_light_overrides():
    block = _block("[data-theme=\"light\"] {")
    for t in LIGHT_OVERRIDES:
        assert re.search(re.escape(t) + r"\s*:", block), t


def test_pattern_class_and_sw_bumped():
    assert ".ping-bg {" in CSS
    sw = (STATIC / "sw.js").read_text(encoding="utf-8")
    assert re.search(r'driqy-shell-v(\d+)', sw) and int(re.search(r'driqy-shell-v(\d+)', sw).group(1)) >= 29
