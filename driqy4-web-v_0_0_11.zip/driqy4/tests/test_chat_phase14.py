"""Fase 14 — mensagem de chamada na conversa (`msg_type=call`), histórico na web e push de chamada."""
from tests.test_chat_phase11 import SDP, _answer, _start, _uid, users, _clean_hub  # noqa: F401
from tests.test_chat_phase12 import _login


def _thread(c, h, other):
    return c.get(f"/api/v1/messages/{other}", headers=h).get_json()["messages"]


def _calls(msgs):
    return [m for m in msgs if m["msg_type"] == "call"]


def test_ended_call_logs_one_message_with_duration(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    assert _answer(c, beto, cid).status_code == 200
    c.post(f"/api/v1/calls/{cid}/end", json={}, headers=ana)
    c.post(f"/api/v1/calls/{cid}/end", json={}, headers=ana)   # idempotente: não duplica
    msgs = _calls(_thread(c, ana, "beto"))
    assert len(msgs) == 1
    m = msgs[0]
    assert m["media_mime"] == "call/voice/ended" and m["mine"] is True
    assert m["content"].startswith("📞 Chamada de voz")
    assert m["can_edit"] is False and m["media_url"] is None
    # o outro lado vê a mesma mensagem (de quem ligou) e ela não conta como não lida
    mb = _calls(_thread(c, beto, "ana"))
    assert len(mb) == 1 and mb[0]["mine"] is False


def test_video_call_label_and_mime(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana, media="video").get_json()["id"]
    _answer(c, beto, cid)
    c.post(f"/api/v1/calls/{cid}/end", json={}, headers=beto)
    m = _calls(_thread(c, ana, "beto"))[0]
    assert m["media_mime"] == "call/video/ended" and "vídeo" in m["content"] and m["content"].startswith("📹")


def test_declined_and_canceled_and_busy(app, users):
    ana, beto, caio = users
    c = app.test_client()
    # recusada
    cid = _start(c, ana).get_json()["id"]
    c.post(f"/api/v1/calls/{cid}/decline", json={}, headers=beto)
    # cancelada pelo chamador = perdida
    cid2 = _start(c, ana).get_json()["id"]
    c.post(f"/api/v1/calls/{cid2}/end", json={}, headers=ana)
    states = [m["media_mime"] for m in _calls(_thread(c, ana, "beto"))]
    assert states == ["call/voice/declined", "call/voice/missed"]
    # perdida fica NÃO lida para quem recebeu; recusada não
    # (abrir a conversa marca como lida, então olhamos o banco antes)
    from models import Message
    with app.app_context():
        rows = Message.query.filter_by(msg_type="call").order_by(Message.id).all()
        assert [r.is_read for r in rows] == [True, False]
    # ocupado: beto em chamada com caio, ana liga -> mensagem busy
    cid3 = _start(c, caio, to="beto").get_json()["id"]
    r = _start(c, ana)
    assert r.status_code == 409 and r.get_json()["code"] == "busy"
    assert _calls(_thread(c, ana, "beto"))[-1]["media_mime"] == "call/voice/busy"
    c.post(f"/api/v1/calls/{cid3}/end", json={}, headers=caio)


def test_call_messages_not_searchable_not_forwardable(app, users):
    ana, beto, caio = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    _answer(c, beto, cid)
    c.post(f"/api/v1/calls/{cid}/end", json={}, headers=ana)
    mid = _calls(_thread(c, ana, "beto"))[0]["id"]
    r = c.get("/api/v1/messages/beto/search?q=chamada", headers=ana)
    assert r.status_code == 200 and r.get_json()["total"] == 0
    r = c.post(f"/api/v1/messages/{mid}/forward", json={"to": ["caio"]}, headers=ana)
    assert r.status_code == 400


def test_call_push_is_data_only_for_android(app, monkeypatch):
    import push

    class _Msg:
        def __init__(self, **kw):
            self.kw = kw

    sent = {}

    class _M:
        MulticastMessage = _Msg
        Notification = lambda **k: ("notif", k)  # noqa: E731
        AndroidConfig = lambda **k: k            # noqa: E731
        AndroidNotification = lambda **k: k      # noqa: E731
        APNSConfig = lambda **k: k               # noqa: E731
        APNSPayload = lambda **k: k              # noqa: E731
        Aps = lambda **k: k                      # noqa: E731
        ApsAlert = lambda **k: ("alert", k)      # noqa: E731

        @staticmethod
        def send_each_for_multicast(message, app=None):
            sent["m"] = message

            class R:
                responses = []
                success_count = 0
                failure_count = 0
            return R()

    import sys, types
    fake = types.ModuleType("firebase_admin")
    fake.messaging = _M
    monkeypatch.setitem(sys.modules, "firebase_admin", fake)
    monkeypatch.setattr(push, "_get_firebase_app", lambda: object())
    from extensions import db
    from models import DeviceToken, User
    with app.app_context():
        u = User(username="zed", email="zed@example.com"); u.set_password("senha1234")
        db.session.add(u); db.session.commit()
        db.session.add(DeviceToken(user_id=u.id, token="tok", platform="android")); db.session.commit()
        push.send_push_to_user(u.id, "Ana", "Chamada de voz recebida", data={"type": "call", "call_id": 1, "media": "voice"})
        kw = sent["m"].kw
        assert kw["notification"] is None
        assert kw["data"]["title"] == "Ana" and kw["data"]["body"] == "Chamada de voz recebida"
        assert kw["android"]["notification"] is None
        sent.clear()
        push.send_push_to_user(u.id, "Ana", "oi", data={"type": "message"})
        assert sent["m"].kw["notification"] is not None


def test_web_calls_history_page_and_assets(app, users):
    c = app.test_client()
    _login(app, c, "ana")
    html = c.get("/mensagens/chamadas").get_data(as_text=True)
    assert 'id="calls-history"' in html and "calls-history.js" in html
    assert 'id="chat-calls-link"' in c.get("/mensagens/").get_data(as_text=True)
    js = c.get("/static/js/calls-history.js").get_data(as_text=True)
    assert "driqyCalls.history" in js
    th = c.get("/static/js/chat-thread.js").get_data(as_text=True)
    assert "callBlock" in th and "Ligar de volta" in th
    assert ".cw-call" in c.get("/static/css/style.css").get_data(as_text=True)
    assert "driqy-shell-v" in c.get("/static/sw.js").get_data(as_text=True)
