"""Layout Parte 4: scripts dos widgets extras e do bloco de sugestões."""
import pathlib
import re

W = pathlib.Path("static/js/rail-widgets.js").read_text(encoding="utf-8")
S = pathlib.Path("static/js/rail-suggest.js").read_text(encoding="utf-8")
R = pathlib.Path("static/js/rail.js").read_text(encoding="utf-8")


def test_widgets_script_registers_the_four_extras():
    for wid in ("trending", "news", "vortex", "online"):
        assert f'id: "{wid}"' in W
    assert "no-referrer" in W and "noopener" in W  # miniaturas externas e links de notícia


def test_texts_from_server_never_go_through_innerhtml():
    for src in (W, S):
        uses = re.findall(r"innerHTML\s*=\s*([^;\n]{0,10})", src)
        assert all(u.strip().startswith('""') for u in uses), uses


def test_suggestions_reuse_follow_js_contract():
    assert "btn-follow" in S and "data-follow-username" in S and "exclude=" in S
    assert pathlib.Path("static/js/follow.js").read_text(encoding="utf-8").count("btn-follow") >= 1


def test_rail_first_render_waits_for_all_registrations():
    assert "setTimeout(start, 0)" in R and "function syncActive" in R


def test_feed_loads_scripts_in_order_and_urls(app):
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User(username="ana", email="ana@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": "ana", "password": "senha1234"})
    html = c.get("/").get_data(as_text=True)
    order = [html.index(f"js/{n}.js") for n in ("rail", "rail-weather", "rail-widgets", "rail-suggest")]
    assert order == sorted(order)
    assert 'data-widgets-url="/api/v1/widgets"' in html
