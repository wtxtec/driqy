"""Ping — fase 4b: botão "novo ping" + linhas estilo Telegram."""
import pytest


@pytest.fixture()
def site(app):
    from extensions import db as _db
    from models import Message, User
    with app.app_context():
        ids = {}
        for name in ("ana", "beto"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            ids[name] = u.id
        _db.session.add(Message(sender_id=ids["beto"], recipient_id=ids["ana"], content="oi ana"))
        _db.session.commit()
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(ids["ana"])
    return c


def test_fab_and_new_panel(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    assert 'id="ping-fab"' not in html and 'class="ping-fab"' not in html   # caneta removida
    for needle in ('id="ping-new-open"', 'id="ping-new"', 'id="ping-new-q"', 'data-search-url="/api/buscar"'):
        assert needle in html, needle


def test_no_fab_in_archived_view(site):
    html = site.get("/mensagens/?arquivadas=1").get_data(as_text=True)
    assert 'id="ping-fab"' not in html


def test_quick_search_returns_user(site):
    d = site.get("/api/buscar?q=beto").get_json()
    assert d["users"][0]["username"] == "beto"


def test_sw_bumped(site):
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", open("static/sw.js", encoding="utf-8").read()).group(1)) >= 57  # versão do cache do SW só pode subir

