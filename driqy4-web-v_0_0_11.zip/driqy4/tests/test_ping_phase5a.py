"""Ping — fase 5a: painel da conversa com fundo de padrão, bolhas e cabeçalho nas cores do Driqy."""
import pathlib

CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
BLOCK = CSS.split("fase 5a: painel da conversa")[1].split("fase 5b:")[0]


def test_css_block_scoped_to_ping_mode():
    rules = [l for l in BLOCK.splitlines() if l.rstrip().endswith("{") and not l.startswith(" ")]
    assert rules and all(r.startswith(".ping-mode") for r in rules)


def test_uses_ping_tokens():
    for tok in ("--ping-pattern", "--ping-bubble-in", "--ping-bubble-out", "--ping-panel"):
        assert tok in BLOCK, tok


def test_sw_bumped():
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 57  # versão do cache do SW só pode subir
