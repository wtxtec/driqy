"""Notícias: recomendador (pool por categoria, cobertura, penalidades),
classificador (peso do título / fontes mistas), URLs de imagem e layout."""
from datetime import timedelta

from models import NewsArticle, NewsInteraction, NewsSource, User, utcnow


def _source(db, name="Fonte", category=None):
    src = NewsSource(name=name, feed_url=f"https://{name}.example/rss", default_category=category, active=True)
    db.session.add(src)
    db.session.commit()
    return src


def _article(db, src, title, category="geral", hours_ago=1, image="https://img.example/a.jpg", n=[0]):
    n[0] += 1
    a = NewsArticle(
        source_id=src.id, title=title, summary="", url=f"https://x.example/{n[0]}",
        url_hash=f"h{n[0]:040d}", image_url=image, category=category,
        published_at=utcnow() - timedelta(hours=hours_ago),
    )
    db.session.add(a)
    db.session.commit()
    return a


def _fresh_cache():
    import news_recommender
    news_recommender._pool_cache._store.clear()


def test_feed_has_every_category_not_only_the_busiest(app, db):
    """Antes o pool era 'as 300 mais recentes do site': categoria de pouco
    volume sumia do 'Para você'."""
    from news_recommender import recommended_articles
    _fresh_cache()
    busy = _source(db, "Busy")
    quiet = _source(db, "Quiet")
    for i in range(120):
        _article(db, busy, f"Novidade tecnológica número {i} do mercado", "tecnologia", hours_ago=1 + i * 0.01)
    _article(db, quiet, "Senado aprova projeto polêmico", "politica", hours_ago=200)
    articles, _ = recommended_articles(None, limit=200)
    assert "politica" in {a.category for a in articles}


def test_articles_without_image_are_hidden_by_default(app, db):
    from news_recommender import recommended_articles
    _fresh_cache()
    src = _source(db)
    with_img = _article(db, src, "Alpha beta gamma delta", "geral")
    no_img = _article(db, src, "Epsilon zeta eta theta", "esportes", image=None)
    articles, _ = recommended_articles(None, limit=10)
    ids = [a.id for a in articles]
    assert with_img.id in ids and no_img.id not in ids


def test_articles_without_image_are_kept_but_ranked_lower(app, db):
    app.config["NEWS_ALLOW_NO_IMAGE"] = True
    from news_recommender import recommended_articles
    _fresh_cache()
    src = _source(db)
    with_img = _article(db, src, "Alpha beta gamma delta", "geral")
    no_img = _article(db, src, "Epsilon zeta eta theta", "esportes", image=None)
    articles, _ = recommended_articles(None, limit=10)
    ids = [a.id for a in articles]
    assert no_img.id in ids and ids.index(with_img.id) < ids.index(no_img.id)


def test_read_articles_sink_instead_of_disappearing(app, db):
    from news_recommender import recommended_articles
    _fresh_cache()
    src = _source(db)
    other = _source(db, "Other")
    read = _article(db, src, "Primeira matéria muito importante hoje", "geral", hours_ago=0.2)
    fresh = _article(db, other, "Segunda assunto completamente diferente aqui", "mundo", hours_ago=5)
    user = User(username="leitor", email="l@example.com")
    user.set_password("senha1234")
    db.session.add(user)
    db.session.commit()
    db.session.add(NewsInteraction(user_id=user.id, article_id=read.id, category="geral", created_at=utcnow()))
    db.session.commit()
    from types import SimpleNamespace
    viewer = SimpleNamespace(id=user.id, is_authenticated=True)
    articles, _ = recommended_articles(viewer, limit=10)
    ids = [a.id for a in articles]
    assert read.id in ids and ids.index(fresh.id) < ids.index(read.id)


def test_same_story_from_many_sources_is_grouped(app, db):
    from news_recommender import _cluster_same_story
    a, b, c = (_source(db, n) for n in "ABC")
    x1 = _article(db, a, "Governo anuncia novo pacote de medidas para a economia brasileira")
    x2 = _article(db, b, "Governo anuncia pacote de medidas para economia brasileira hoje")
    y = _article(db, c, "Flamengo vence clássico carioca no Maracanã lotado")
    coverage, dupes = _cluster_same_story([x1, x2, y])
    assert coverage[x1.id] == 2 and coverage[x2.id] == 2 and coverage[y.id] == 1
    assert len(dupes & {x1.id, x2.id}) == 1 and y.id not in dupes


def test_topic_affinity_from_clicked_titles(app, db):
    from news_recommender import _topic_score
    profile = {"copa": 1.0, "mundo": 0.8, "seleção": 0.9}
    assert _topic_score("Seleção entra na Copa do Mundo", profile) > _topic_score("Dólar fecha em queda", profile)


def test_classifier_title_weight_and_allowed():
    from config import Config
    from news_classifier import classify
    K = Config.NEWS_CATEGORY_KEYWORDS
    assert classify("Flamengo vence o Vasco no Brasileirão", "", K)[0] == "esportes"
    cat, _ = classify("Nasa registra buraco negro", "", K, default_category="saude", allowed={"ciencia"})
    assert cat == "ciencia"
    cat, _ = classify("Vacina contra dengue chega ao SUS", "", K, default_category="saude", allowed={"ciencia"})
    assert cat == "saude"


def test_image_url_upgrade_is_safe():
    from news_indexer import _upgrade_image_url
    assert _upgrade_image_url("https://x.com/up/a-300x200.jpg") == "https://x.com/up/a.jpg"
    assert "w=1200" in _upgrade_image_url("https://cdn.x.com/i.jpg?w=300&h=200")
    signed = "https://s2-g1.glbimg.com/abc=/540x304/top/x.jpg"
    assert _upgrade_image_url(signed) == signed
    assert _upgrade_image_url("https://x.com/plain.jpg") == "https://x.com/plain.jpg"


def test_image_proxy_resizes_and_never_upscales(app, db, tmp_path, monkeypatch):
    import io
    from PIL import Image
    import news
    src = _source(db)
    art = _article(db, src, "Com imagem grande")
    buf = io.BytesIO()
    Image.new("RGB", (2400, 1600), (30, 90, 160)).save(buf, "JPEG", quality=95)
    big = buf.getvalue()

    class Resp:
        headers = {"Content-Type": "image/jpeg"}
        def raise_for_status(self): pass
        def iter_content(self, chunk_size): yield big
        def close(self): pass

    monkeypatch.setattr(news.requests, "get", lambda *a, **k: Resp())
    client = app.test_client()
    r = client.get(f"/noticias/{art.id}/imagem?w=800")
    assert r.status_code == 200 and r.mimetype == "image/webp"
    assert Image.open(io.BytesIO(r.data)).width == 800
    r2 = client.get(f"/noticias/{art.id}/imagem?w=480")
    assert Image.open(io.BytesIO(r2.data)).width == 480


def test_news_page_renders_uniform_cards_and_categories(app, db):
    _fresh_cache()
    src = _source(db)
    for i in range(5):
        _article(db, src, f"Notícia de teste número {i} com assunto único {i*7}", "esportes")
    client = app.test_client()
    html = client.get("/noticias/").get_data(as_text=True)
    assert html.count('class="news-tile news-tile--normal') == 5
    assert "news-tile--wide" not in html and "srcset=" in html
    html = client.get("/noticias/?categoria=esportes").get_data(as_text=True)
    assert html.count("news-tile--normal") >= 5
    html = client.get("/noticias/?categoria=ciencia").get_data(as_text=True)
    assert "Nenhuma notícia" in html
