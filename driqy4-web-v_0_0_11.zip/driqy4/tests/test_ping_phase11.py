"""Fase 11 — aproximação final do Telegram (site)."""
import re
import pytest
from tests.test_ping_phase4a import site  # noqa: F401  (reaproveita a fixture)


def _css():
    return open("static/css/style.css", encoding="utf-8").read()


def test_list_has_dots_icon_avatar_and_two_line_notice(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    assert 'class="ping-ico-bars"' in html and 'class="ping-ico-dots"' not in html
    assert 'class="ping-me"' not in html   # a foto não abre mais configurações (agora é o menu lateral)
    assert 'class="ping-notice-text"' in html and "Organize suas conversas" in html


def test_archived_view_has_no_avatar(site):
    html = site.get("/mensagens/?arquivadas=1").get_data(as_text=True)
    assert 'class="ping-me"' not in html


def test_phase11_css_scoped_and_composer_order_untouched_in_dom(site):
    css = _css()
    i = css.index("fase 11: aproxima")
    # o bloco da fase 11 termina onde começa o CSS do painel de widgets (Layout), que vem depois no arquivo
    end = css.find("/* ---------- Coluna direita", i)
    block = css[css.rfind("/*", 0, i):(end if end != -1 else None)]
    block = re.sub(r"/\*.*?\*/", "", block, flags=re.S)  # sem comentários
    assert "#cw-attach-btn { order: -1; }" in block and "#cw-emoji-btn { order: 2; }" in block
    # a ordem do DOM do composer não mudou (chat-thread.js depende dos ids)
    html = site.get("/mensagens/beto").get_data(as_text=True)
    assert html.index('id="cw-emoji-btn"') < html.index('id="cw-input"') < html.index('id="cw-attach-btn"')
    # tudo sob .ping-mode ou classes exclusivas do Ping
    for sel in re.findall(r"^\s*([.#a-z][^{}@]*?)\s*\{", block, flags=re.M):
        for part in sel.split(","):
            part = part.strip()
            assert part.startswith((".ping-", "body.ping-")), part
