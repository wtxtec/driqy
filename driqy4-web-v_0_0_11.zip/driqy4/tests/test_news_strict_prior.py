from news_classifier import classify_article
from news_indexer import _strip_html, _trust_prior

KW = {
    "politica": ["eleição", "eleições", "governo"],
    "tecnologia": ["google", "iphone", "anthropic", "starlink"],
}


def test_portal_sem_evidencia_vira_geral():
    c = classify_article("Filho encontra mãe morta a facadas em casa", "Polícia investiga o caso",
                         KW, prior="tecnologia", trust_prior=False)
    assert c.category == "geral"


def test_portal_com_evidencia_de_texto_mantem_tecnologia():
    c = classify_article("Vivo se une à Starlink", "", KW, prior="tecnologia", trust_prior=False)
    assert c.category == "tecnologia"


def test_portal_eleicao_nao_fica_em_tecnologia():
    c = classify_article("Eleitor suspeito de matar policial após eleições", "", KW,
                         prior="tecnologia", trust_prior=False)
    assert c.category == "politica"


def test_site_especializado_mantem_prior():
    c = classify_article("Review do aparelho", "", KW, prior="tecnologia", trust_prior=True)
    assert c.category == "tecnologia"


def test_entidades_html():
    assert _strip_html("O Ita&uacute; est&aacute; <b>aqui</b>") == "O Itaú está aqui"
    assert _strip_html("O Ita&amp;uacute; anunciou") == "O Itaú anunciou"


def test_prefixos():
    cfg = {"NEWS_STRICT_PRIOR_PREFIXES": ("G1", "UOL")}
    assert not _trust_prior("UOL Tecnologia", cfg)
    assert _trust_prior("Canaltech", cfg)
