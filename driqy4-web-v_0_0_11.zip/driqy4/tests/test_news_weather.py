import pytest
from news_weather import hide_for_user, local_forecast_places, user_place_keys

NONE = frozenset()


@pytest.mark.parametrize("title", [
    "Previsão do tempo para Curitiba: frio de 3°C neste domingo",
    "Previsão do tempo: chuva forte em Porto Alegre hoje",
    "Campinas terá máxima de 35°C nesta quarta",
    "Como fica o tempo em Belo Horizonte neste fim de semana?",
    "Tempo hoje: Florianópolis tem sol e calor de 32°C",
    "São Paulo tem previsão de chuva hoje",
])
def test_city_forecast_hidden_for_others(title):
    assert hide_for_user(title, NONE)


@pytest.mark.parametrize("title", [
    "Previsão do tempo para o Brasil: frente fria avança no fim de semana",
    "Frio no Sul: geada deve atingir Santa Catarina e Paraná amanhã",
    "Onda de calor atinge o Brasil nesta semana",
    "El Niño deve trazer calor extremo nos próximos dias",
    "Previsão do tempo para o feriado de Natal",
    "Chuva em Recife deixa mortos",          # tragédia, não previsão
    "Governo anuncia plano em Brasília",
])
def test_general_climate_and_other_news_kept(title):
    assert not hide_for_user(title, NONE)


def test_user_city_sees_own_forecast():
    t = "Previsão do tempo para Curitiba: frio hoje"
    assert not hide_for_user(t, user_place_keys("Curitiba, PR"))
    assert not hide_for_user(t, user_place_keys("curitiba - paraná"))
    assert hide_for_user(t, user_place_keys("Londrina - PR"))
    assert hide_for_user(t, user_place_keys(""))


def test_places_extracted():
    assert local_forecast_places("Previsão para Porto Alegre hoje") == ("porto alegre",)
