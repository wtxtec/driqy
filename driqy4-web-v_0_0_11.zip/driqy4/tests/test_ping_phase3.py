"""Ping — fase 3: shell próprio, sem o chrome do Driqy (logo, busca do topo, menus)."""
import pytest


@pytest.fixture()
def site(app):
    from extensions import db as _db
    from models import Message, User
    with app.app_context():
        ids = {}
        for name in ("ana", "beto"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            ids[name] = u.id
        _db.session.add(Message(sender_id=ids["beto"], recipient_id=ids["ana"], content="oi ana"))
        _db.session.commit()
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(ids["ana"])
    return c


PAGES = ["/mensagens/", "/mensagens/beto", "/mensagens/chamadas"]
CHROME = ["class=\"topbar\"", "topbar-search", "brand-ring", "brand-name", "sidebar-toggle",
          "id=\"bottom-nav\"", "class=\"sidebar\"", "Buscar no "]


@pytest.mark.parametrize("path", PAGES)
def test_no_driqy_chrome(site, path):
    r = site.get(path)
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    for bad in CHROME:
        assert bad not in html, (path, bad)
    assert 'class="ping-title">Mensagens<' in html
    assert 'class="ping-back"' in html and 'href="/"' in html  # volta ao Driqy (feed)


@pytest.mark.parametrize("path", PAGES)
def test_all_pages_have_both_columns(site, path):
    html = site.get(path).get_data(as_text=True)
    assert 'id="ping-list-col"' in html and 'id="ping-main-col"' in html
    assert 'id="chat-inbox-list"' in html  # a lista aparece em todas (desktop: lado a lado)
    assert "beto" in html.split('id="ping-list-col"')[1].split('id="ping-main-col"')[0]


def test_view_classes_and_empty_state(site):
    inbox = site.get("/mensagens/").get_data(as_text=True)
    assert "ping-view-list" in inbox and "Selecione uma conversa" in inbox
    thread = site.get("/mensagens/beto").get_data(as_text=True)
    assert "ping-view-main" in thread and 'data-active-username="beto"' in thread
    assert 'id="cw"' in thread


def test_scripts_kept_for_calls_and_live(site):
    html = site.get("/mensagens/beto").get_data(as_text=True)
    for js in ("chat-live.js", "calls-api.js", "call-ui.js", "chat.js", "settings.js", "chat-thread.js", "ping-shell.js"):
        assert js in html, js
    for js in ("notifications.js", "search.js"):
        assert js not in html, js


def test_thread_marks_read_before_listing(site, app):
    from models import Message
    html = site.get("/mensagens/beto").get_data(as_text=True)
    assert "conv-unread" not in html  # a conversa aberta já conta como lida na lista
    with app.app_context():
        assert Message.query.filter_by(is_read=False).count() == 0
