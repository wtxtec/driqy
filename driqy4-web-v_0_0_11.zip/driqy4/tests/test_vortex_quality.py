"""Qualidade do Vortex: QR code, logo, imagem chapada, repetidas, nomes de
lixo, limpeza da grade e \"o que acabei de ver\"."""
import io
import random
from datetime import timedelta

import numpy as np
import pytest
from PIL import Image, ImageDraw, ImageFilter

import vortex_crawler as vc
import vortex_quality as vq
import vortex_taste as vt
from models import (
    ApiToken, User, VortexInteraction, VortexItem, VortexProfile, utcnow,
)
from test_vortex_crawler import FakeHttp, FakeResp, commons_payload, get_source

_n = [100000]


# ------------------------------------------------------------------ imagens
def to_bytes(img, fmt="PNG"):
    buf = io.BytesIO()
    img.save(buf, fmt)
    return buf.getvalue()


def fake_qr(modules=25, scale=12, quiet=4, seed=3):
    """QR desenhado à mão: 3 olhos 7x7 nos cantos + módulos aleatórios."""
    rnd = random.Random(seed)
    grid = [[rnd.random() < 0.5 for _ in range(modules)] for _ in range(modules)]

    def eye(r0, c0):
        for r in range(7):
            for c in range(7):
                ring = r in (0, 6) or c in (0, 6)
                core = 2 <= r <= 4 and 2 <= c <= 4
                grid[r0 + r][c0 + c] = ring or core
        for i in range(8):   # separador claro em volta
            for (rr, cc) in ((r0 + 7, c0 + i), (r0 + i, c0 + 7), (r0 + 7, c0 - 1 + 0)):
                if 0 <= rr < modules and 0 <= cc < modules and not (r0 <= rr < r0 + 7 and c0 <= cc < c0 + 7):
                    grid[rr][cc] = False

    eye(0, 0)
    eye(0, modules - 7)
    eye(modules - 7, 0)
    size = (modules + 2 * quiet) * scale
    img = Image.new("RGB", (size, size), "white")
    d = ImageDraw.Draw(img)
    for r in range(modules):
        for c in range(modules):
            if grid[r][c]:
                x0, y0 = (c + quiet) * scale, (r + quiet) * scale
                d.rectangle([x0, y0, x0 + scale - 1, y0 + scale - 1], fill="black")
    return img


def noisy_photo(w=900, h=600, seed=1):
    rng = np.random.default_rng(seed)
    x = np.linspace(0, 1, w)[None, :, None]
    y = np.linspace(0, 1, h)[:, None, None]
    base = np.concatenate([x * 255 * np.ones((h, 1, 1)), y * 200 * np.ones((1, w, 1)),
                           (1 - x) * 180 * np.ones((h, 1, 1))], axis=2)
    arr = np.clip(base + rng.normal(0, 25, (h, w, 3)), 0, 255).astype(np.uint8)
    img = Image.fromarray(arr)
    d = ImageDraw.Draw(img)
    for _ in range(40):
        c = tuple(int(v) for v in rng.integers(0, 255, 3))
        x0, y0 = int(rng.integers(0, w - 100)), int(rng.integers(0, h - 100))
        d.ellipse([x0, y0, x0 + int(rng.integers(30, 200)), y0 + int(rng.integers(30, 200))], fill=c)
    return img.filter(ImageFilter.GaussianBlur(1.5))


def flat_logo(w=1200, h=1200):
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    d.ellipse([300, 300, 900, 900], fill=(20, 80, 200))
    d.rectangle([450, 550, 750, 650], fill="white")
    return img


def sky_gradient(w=1000, h=700):
    y = np.linspace(0, 1, h)[:, None]
    r = (255 * (0.2 + 0.8 * y)) * np.ones((1, w))
    g = (180 * (1 - 0.6 * y)) * np.ones((1, w))
    b = (255 * (1 - 0.9 * y)) * np.ones((1, w))
    return Image.fromarray(np.stack([r, g, b], axis=2).astype(np.uint8))


def night_sky(seed=5):
    rng = np.random.default_rng(seed)
    arr = np.clip(rng.normal(14, 6, (700, 1000, 3)), 0, 255).astype(np.uint8)
    img = Image.fromarray(arr)
    d = ImageDraw.Draw(img)
    for _ in range(80):
        x, y = int(rng.integers(0, 1000)), int(rng.integers(0, 700))
        d.ellipse([x, y, x + 2, y + 2], fill=(255, 255, 240))
    return img.filter(ImageFilter.GaussianBlur(0.8))


# ------------------------------------------------------------------ 1) texto
@pytest.mark.parametrize("url,title,tags,junk", [
    ("https://x.org/img/qr-code-promo.png", "", "", True),
    ("https://x.org/uploads/logo_empresa.jpg", "", "", True),
    ("https://x.org/a/banner-home.jpg", "", "", True),
    ("https://x.org/wp-content/themes/foo/img/bg.jpg", "", "", True),
    ("https://x.org/a/f.jpg", "QR code on a poster", "", True),
    ("https://x.org/a/f.jpg", "Logo da empresa X", "", True),
    ("https://x.org/a/f.jpg", "Bruce Banner statue", "", False),     # palavra fraca em título
    ("https://x.org/a/f.jpg", "Belly button piercing", "badge", False),
    ("https://logo.com/a/waterfall.jpg", "Cachoeira", "rio", False),  # domínio não conta
    ("https://x.org/a/Catalog_of_birds.jpg", "Catalog", "", False),   # palavra inteira
    ("https://x.org/photos/sunset-beach.jpg", "Sunset", "beach", False),
])
def test_check_text(url, title, tags, junk):
    assert (vq.check_text(url, title, tags) is not None) is junk


# ------------------------------------------------------------------ 2) pixels
def test_qr_drawn_by_hand_is_detected():
    reason, m = vq.inspect_bytes(to_bytes(fake_qr()))
    assert reason == "qrcode" and m["qr"] is True


@pytest.mark.parametrize("data,box,border", [
    ("https://example.com/promo?x=1", 10, 4),
    ("https://example.com/" + "abcdef" * 25, 6, 4),
    ("hello world 12345", 30, 2),
])
def test_real_qr_codes_are_detected(data, box, border):
    qrcode = pytest.importorskip("qrcode")
    q = qrcode.QRCode(box_size=box, border=border)
    q.add_data(data)
    q.make(fit=True)
    img = q.make_image(fill_color="black", back_color="white").convert("RGB")
    for fmt in ("PNG", "JPEG"):
        reason, _m = vq.inspect_bytes(to_bytes(img, fmt))
        assert reason == "qrcode", fmt


def test_flat_logo_blank_and_transparent_are_flagged():
    assert vq.inspect_bytes(to_bytes(flat_logo()))[0] == "logo"
    assert vq.inspect_bytes(to_bytes(Image.new("RGB", (800, 800), (250, 250, 250))))[0] == "blank"
    cutout = Image.new("RGBA", (800, 800), (0, 0, 0, 0))
    ImageDraw.Draw(cutout).ellipse([100, 100, 700, 700], fill=(200, 30, 30, 255))
    assert vq.inspect_bytes(to_bytes(cutout))[0] == "transparent"


def test_real_looking_photos_are_never_flagged():
    for name, img in {
        "ruído": noisy_photo(), "ruído2": noisy_photo(seed=7),
        "céu em degradê": sky_gradient(), "noite": night_sky(),
        "p&b": noisy_photo(seed=9).convert("L").convert("RGB"),
    }.items():
        for fmt in ("JPEG", "PNG"):
            assert vq.inspect_bytes(to_bytes(img, fmt))[0] is None, (name, fmt)


def test_unreadable_or_empty_data_passes():
    assert vq.inspect_bytes(b"") == (None, None)
    assert vq.inspect_bytes(b"isto nao e uma imagem") == (None, None)


def test_flat_rule_does_not_apply_to_gifs_but_blank_does():
    assert vq.inspect_bytes(to_bytes(flat_logo(), "GIF"), "gif")[0] is None
    assert vq.inspect_bytes(to_bytes(Image.new("RGB", (400, 400), "white"), "GIF"), "gif")[0] == "blank"


def test_judge_checks_text_before_pixels():
    assert vq.judge(url="https://x.org/logo.png", data=to_bytes(noisy_photo())) == "text"
    assert vq.judge(url="https://x.org/a.png", data=to_bytes(noisy_photo())) is None
    assert vq.judge(url="https://x.org/a.png", data=to_bytes(fake_qr())) == "qrcode"


# ------------------------------------------------------------------ 3) repetidas
def test_find_clusters_groups_by_hamming_distance():
    base = 0x0F0F_0F0F_0F0F_0F0F
    rows = [(1, base), (2, base ^ 0b11), (3, base ^ 0b111111),       # 0, 2 e 6 bits
            (4, base ^ 0xFFFF), (5, ~base & 0xFFFF_FFFF_FFFF_FFFF)]  # longe
    clusters = vq.find_clusters(rows, 6)
    assert sorted(map(sorted, clusters)) == [[1, 2, 3]]


def test_find_clusters_large_bucket_uses_numpy_path():
    rng = random.Random(1)
    base = rng.getrandbits(64)
    rows = [(i, base ^ (1 << (i % 3))) for i in range(1, 60)]     # 59 quase iguais
    rows += [(1000 + i, rng.getrandbits(64)) for i in range(50)]  # ruído
    clusters = vq.find_clusters(rows, 6)
    big = max(clusters, key=len)
    assert set(big) == set(range(1, 60))


def mk_item(db, phash=None, w=800, h=600, handle="commons", title=None, source_name=None,
            media="photo", tags="", category="natureza", url=None, age_days=0.0):
    _n[0] += 1
    prof = VortexProfile.query.filter_by(handle=handle).first()
    url = url or f"https://x.org/{_n[0]}/foto.jpg"
    item = VortexItem(
        profile_id=prof.id, media_type=media, media_url=url, thumb_url=url + ".t.jpg",
        width=w, height=h, title=title or f"foto {_n[0]}", tags=tags, category=category,
        url_hash=vc._hash_url(url), phash=phash, source_name=source_name,
        created_at=utcnow() - timedelta(days=age_days),
    )
    db.session.add(item)
    db.session.commit()
    return item


def test_dedupe_keeps_best_copy_and_flags_the_rest(app, db):
    h = "0f0f0f0f0f0f0f0f"
    small = mk_item(db, h, w=400, h=300)
    big = mk_item(db, h, w=1600, h=1200)
    near = mk_item(db, "0f0f0f0f0f0f0f0e", w=800, h=600)
    other = mk_item(db, "f0f0f0f0f0f0f0f0")
    out = vq.dedupe_existing(app, db)
    assert out == {"duplicate": 2, "repeated": 0}
    for i in (small, near):
        db.session.refresh(i)
        assert (i.is_active, i.junk_reason) == (False, "duplicate")
    for i in (big, other):
        db.session.refresh(i)
        assert i.is_active and i.junk_reason is None


def test_dedupe_flags_everything_when_an_image_repeats_too_much(app, db):
    # 6+ cópias = banner/marca d'água do site: nenhuma fica
    items = [mk_item(db, "00ff00ff00ff00ff", w=800 + i) for i in range(6)]
    out = vq.dedupe_existing(app, db)
    assert out == {"duplicate": 0, "repeated": 6}
    for i in items:
        db.session.refresh(i)
        assert (i.is_active, i.junk_reason) == (False, "repeated")


def test_dedupe_dry_run_and_manual_ok_are_respected(app, db):
    a = mk_item(db, "abababababababab", w=1600, h=1200)
    b = mk_item(db, "abababababababab", w=400, h=300)
    assert vq.dedupe_existing(app, db, dry_run=True)["duplicate"] == 1
    db.session.refresh(b)
    assert b.is_active                              # dry-run não grava
    vq.restore(b)                                   # admin liberou a menor
    db.session.commit()
    vq.dedupe_existing(app, db)
    for i in (a, b):
        db.session.refresh(i)
    assert b.is_active and b.junk_reason == "manual_ok"   # nunca mais mexe
    assert a.is_active is False                    # a outra cópia cede
    assert a.junk_reason == "duplicate"


# ------------------------------------------------------------------ varreduras
def test_text_sweep_bars_junk_names_and_spares_restored(app, db):
    junk = mk_item(db, url="https://x.org/a/qr-code.png")
    fine = mk_item(db, url="https://x.org/a/cachoeira.jpg")
    kept = mk_item(db, url="https://x.org/a/logo-ok.png")
    vq.restore(kept)
    db.session.commit()
    assert vq.text_sweep(app, db) == 1
    for i in (junk, fine, kept):
        db.session.refresh(i)
    assert (junk.is_active, junk.junk_reason) == (False, "text")
    assert fine.is_active and fine.junk_reason is None
    assert kept.is_active and kept.junk_reason == "manual_ok"


def test_scan_rows_and_apply_scan(app, db):
    qr = mk_item(db, url="https://x.org/img/1.png")
    ok = mk_item(db, url="https://x.org/img/2.png")
    dead = mk_item(db, url="https://x.org/img/3.png")
    payload = {qr.thumb_url: to_bytes(fake_qr()), ok.thumb_url: to_bytes(noisy_photo())}
    results = vq.scan_rows([qr, ok, dead], payload.get)
    assert results == {qr.id: "qrcode", ok.id: None, dead.id: None}   # link morto passa
    assert vq.apply_scan(db, results) == 1
    for i in (qr, ok, dead):
        db.session.refresh(i)
    assert (qr.is_active, qr.junk_reason) == (False, "qrcode")
    assert ok.is_active and dead.is_active
    assert {i.quality_version for i in (qr, ok, dead)} == {vq.QUALITY_VERSION}
    assert vq.pending_count(db) == 0


# ------------------------------------------------------------------ integração no crawler
def _thumb_router(by_name):
    def thumb(url, kw):
        name = url.rsplit("/", 1)[-1]
        return FakeResp(200, content=by_name[name], headers={"Content-Type": "image/png"})
    return thumb


def test_crawler_drops_qr_logo_and_blank_but_keeps_photos(app, db):
    src = get_source(db)
    names = {
        "img1.jpg": to_bytes(fake_qr()), "img2.jpg": to_bytes(flat_logo()),
        "img3.jpg": to_bytes(Image.new("RGB", (800, 800), "white")),
        "img4.jpg": to_bytes(noisy_photo(seed=21)), "img5.jpg": to_bytes(noisy_photo(seed=22)),
        "qr-code.jpg": to_bytes(noisy_photo(seed=23)),     # barrada só pelo nome
    }
    http = FakeHttp({
        "https://commons.wikimedia.org/w/api.php": lambda u, k: FakeResp(
            200, json_data=commons_payload([{"name": n} for n in names], more=False)),
        "https://upload.wikimedia.org/thumb/": _thumb_router(names),
    })
    assert vc.crawl_source(app, db, src, http=http) == 2
    kept = {i.media_url.rsplit("/", 1)[-1] for i in VortexItem.query.all()}
    assert kept == {"img4.jpg", "img5.jpg"}
    assert {i.quality_version for i in VortexItem.query.all()} == {vq.QUALITY_VERSION}


def test_crawler_quality_can_be_turned_off(app, db):
    app.config["VORTEX_QUALITY_ENABLED"] = False
    src = get_source(db)
    names = {"img1.jpg": to_bytes(fake_qr())}
    http = FakeHttp({
        "https://commons.wikimedia.org/w/api.php": lambda u, k: FakeResp(
            200, json_data=commons_payload([{"name": n} for n in names], more=False)),
        "https://upload.wikimedia.org/thumb/": _thumb_router(names),
    })
    assert vc.crawl_source(app, db, src, http=http) == 1
    assert VortexItem.query.one().quality_version is None


# ------------------------------------------------------------------ grade: limpeza
def cand(key, phash=None, site=None):
    return vt.Cand(key, "c", int(key[1:]), "natureza", "photo", 1, frozenset(), utcnow(), phash, site)


def test_clean_sequence_drops_near_duplicates_and_spreads_sites():
    a1, a2 = cand("c1", 0xFF00FF00FF00FF00), cand("c2", 0xFF00FF00FF00FF01)   # quase iguais
    seq = [a1, a2] + [cand(f"c{10 + i}", i * 0x0123456789ABCDEF & ((1 << 64) - 1) | (1 << 63), "siteA")
                      for i in range(8)] + [cand(f"c{30 + i}", None, f"site{i}") for i in range(5)]
    out = vt._clean_sequence(seq, near_dup=9, window=6, per_site=2)
    keys = [c.key for c in out]
    assert "c1" in keys and "c2" not in keys                   # a cópia saiu
    # nunca mais de 2 do siteA em qualquer janela de 6 enquanto houver outra opção
    first = out[:9]
    for i in range(len(first)):
        win = first[max(0, i - 5):i + 1]
        assert sum(1 for c in win if c.site == "siteA") <= 2
    assert len(out) == len(seq) - 1                            # só a cópia foi embora


def test_clean_sequence_yields_on_site_when_nothing_else_is_left():
    seq = [cand(f"c{i}", None, "so-um-site") for i in range(10)]
    assert len(vt._clean_sequence(seq, per_site=2, window=5)) == 10


def test_feed_hides_junk_names_even_before_the_sweep(app, db):
    user = _user(db, "ana")
    junk = mk_item(db, url="https://x.org/promo/qr-code.png")      # ainda ativo (sem varredura)
    fine = [mk_item(db, url=f"https://x.org/ok/{k}.jpg", tags="praia") for k in range(6)]
    page = vt.ranked_page(app, user.id, include_users=False)
    assert f"c{junk.id}" not in page["keys"]
    assert {f"c{i.id}" for i in fine} <= set(page["keys"])


def test_feed_never_shows_the_same_image_twice(app, db):
    user = _user(db, "bia")
    a = mk_item(db, "1234567812345678", w=1600, h=1200)
    b = mk_item(db, "1234567812345679", w=500, h=400)          # a mesma foto, outra URL
    others = [mk_item(db, f"{(k + 1) * 0x1111111111111111 & ((1 << 64) - 1):016x}") for k in range(5)]
    keys = vt.ranked_page(app, user.id, include_users=False)["keys"]
    assert (f"c{a.id}" in keys) != (f"c{b.id}" in keys)         # exatamente uma das duas
    assert all(f"c{o.id}" in keys for o in others)


# ------------------------------------------------------------------ "visto recentemente"
def _user(db, name):
    u = User(username=name, email=f"{name}@example.com")
    u.set_password("senha1234")
    db.session.add(u)
    db.session.commit()
    return u


def _headers(db, user):
    tok = ApiToken.generate_for(user)
    db.session.commit()
    return {"Authorization": f"Bearer {tok.token}"}


def _seed_world(db):
    """12 itens de gatos (tags em comum) em meio a 60 itens de assuntos variados."""
    cats = [mk_item(db, category="animais", tags="gato,felino,bigodes", title=f"gato {i}",
                    source_name=f"site{i}.com") for i in range(12)]
    rnd = random.Random(7)
    others = [mk_item(db, category=rnd.choice(["natureza", "comida", "viagem", "arte"]),
                      tags=f"tema{i % 9},assunto{i % 5}", title=f"outro {i}",
                      source_name=f"outro{i % 20}.com") for i in range(60)]
    return cats, others


def test_recent_seed_ids_order_age_and_dislike(app, db):
    user = _user(db, "caio")
    items = [mk_item(db) for _ in range(5)]
    now = utcnow()
    vt.record(user.id, "open", item=items[0])
    vt.record(user.id, "open", item=items[1])
    vt.record(user.id, "open", item=items[2])
    vt.record(user.id, "less", item=items[1])      # \"menos disso\" tira da lista
    seeds = vt.recent_seed_ids(user.id, now)
    assert [i for i, _w in seeds] == [items[2].id, items[0].id]
    assert seeds[0][1] > seeds[1][1]                 # a mais recente pesa mais
    # clique velho demais não vira semente
    row = VortexInteraction.query.filter_by(item_id=items[0].id).first()
    row.created_at = now - timedelta(hours=vt.RECENT_HOURS + 1)
    db.session.commit()
    assert [i for i, _w in vt.recent_seed_ids(user.id, now)] == [items[2].id]


def _cats_on_top(app, user, cat_keys, exclude=None, runs=6, top=18):
    from extensions import db
    """Média de quantos gatos aparecem nas `top` primeiras posições, em `runs`
    rolagens novas (cada uma com semente diferente: a ordem sem sinal é aleatória)."""
    from models import VortexSeen
    counts = []
    for _ in range(runs):
        # cada rolagem simula um dia diferente: sem o livro de vistos (que, de
        # propósito, não repete o que já foi servido) as 6 rolagens competiriam
        # pelas mesmas peças
        VortexSeen.query.filter_by(user_id=user.id).delete()
        db.session.commit()
        keys = vt.ranked_page(app, user.id, include_users=False)["keys"][:top]
        counts.append(len([k for k in keys if k in cat_keys and k != exclude]))
    return counts


def test_clicking_an_item_pulls_similar_items_to_the_top(app, db):
    user = _user(db, "duda")
    cats, others = _seed_world(db)
    cat_keys = {f"c{c.id}" for c in cats}

    baseline = _cats_on_top(app, user, cat_keys)
    assert sum(baseline) / len(baseline) < 5          # sem sinal, gatos são 1/6 da grade

    assert vt.record(user.id, "open", item=cats[0]) is True
    vt.clear_caches()
    opened = f"c{cats[0].id}"
    after = _cats_on_top(app, user, cat_keys, exclude=opened)
    assert min(after) >= 6                            # em TODA rolagem nova os parecidos subiram
    assert min(after) > max(baseline)
    from models import VortexSeen
    VortexSeen.query.filter_by(user_id=user.id).delete()   # só o rebaixamento antigo está em teste
    db.session.commit()
    vt.clear_caches()
    keys = vt.ranked_page(app, user.id, include_users=False)["keys"]
    # ocupam as posições reservadas do começo da grade
    assert keys[1] in cat_keys
    assert len([k for k in keys[:12] if k in cat_keys]) >= 8   # o resto é exploração (1 a cada 5)
    assert opened not in keys[:6]                     # a própria peça aberta é rebaixada


def test_recent_boost_follows_the_latest_click_not_the_old_one(app, db):
    user = _user(db, "edu")
    cats, others = _seed_world(db)
    vt.record(user.id, "open", item=cats[0])
    boost_old = vt.recent_boost(app, user.id)
    assert any(k in boost_old for k in (f"c{c.id}" for c in cats[1:]))
    # agora o último clique é num assunto totalmente diferente
    odd = mk_item(db, category="arte", tags="pintura,tinta,quadro", title="pintura")
    twin = mk_item(db, category="arte", tags="pintura,tinta,quadro", title="pintura 2")
    vt.record(user.id, "open", item=odd)
    vt.clear_caches()
    boost = vt.recent_boost(app, user.id)
    assert boost.get(f"c{twin.id}", 0) > max(boost.get(f"c{c.id}", 0) for c in cats[1:])


def test_api_recent_endpoint_lists_what_the_user_opened(app, db):
    user = _user(db, "fabi")
    cats, _others = _seed_world(db)
    client = app.test_client()
    hdr = _headers(db, user)
    assert client.get("/api/v1/vortex/recent", headers=hdr).get_json()["tiles"] == []
    for c in (cats[0], cats[1], cats[0]):
        assert client.get(f"/api/v1/vortex/item/{c.id}?related=0", headers=hdr).status_code == 200
        vt.clear_caches()
    tiles = client.get("/api/v1/vortex/recent", headers=hdr).get_json()["tiles"]
    assert [t["item_id"] for t in tiles] == [cats[1].id, cats[0].id]    # sem repetir, mais novo 1º
    assert client.get("/api/v1/vortex/recent?type=video", headers=hdr).get_json()["tiles"] == []
    assert client.get("/api/v1/vortex/recent?type=zzz", headers=hdr).status_code == 400
    assert client.get("/api/v1/vortex/recent").status_code == 401


def test_api_feed_reacts_to_a_click_made_through_the_api(app, db):
    user = _user(db, "gabi")
    cats, _others = _seed_world(db)
    cat_keys = {f"c{c.id}" for c in cats}
    client = app.test_client()
    hdr = _headers(db, user)
    client.get(f"/api/v1/vortex/item/{cats[3].id}?related=0", headers=hdr)    # o clique
    tiles = client.get("/api/v1/vortex", headers=hdr).get_json()["tiles"]
    top = [t["key"] for t in tiles[:18]]
    assert len([k for k in top if k in cat_keys]) >= 4


# ------------------------------------------------------------------ admin
def test_admin_restore_marks_manual_ok_and_filter_lists_barred(app, db):
    admin = User(username="chefe", email="chefe@example.com", is_admin=True)
    admin.set_password("senha1234")
    db.session.add(admin)
    db.session.commit()
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(admin.id)
        sess["_fresh"] = True

    junk = mk_item(db, url="https://x.org/a/qr-code.png")
    vq.text_sweep(app, db)
    page = client.get("/admin/vortex/itens?motivo=auto")
    assert page.status_code == 200 and "QR" in page.get_data(as_text=True) or "Nome indica" in page.get_data(as_text=True)

    assert client.post(f"/admin/vortex/itens/{junk.id}/ocultar").status_code == 302
    db.session.refresh(junk)
    assert junk.is_active and junk.junk_reason == "manual_ok"
    vq.text_sweep(app, db)                     # o filtro não barra de novo
    db.session.refresh(junk)
    assert junk.is_active


def test_admin_clean_now_button(app, db):
    admin = User(username="chefe2", email="chefe2@example.com", is_admin=True)
    admin.set_password("senha1234")
    db.session.add(admin)
    db.session.commit()
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(admin.id)
        sess["_fresh"] = True
    mk_item(db, url="https://x.org/a/logo.png")
    mk_item(db, "abababababababab", w=1600, h=1200)
    mk_item(db, "abababababababab", w=400, h=300)
    resp = client.post("/admin/vortex/qualidade/limpar")
    assert resp.status_code == 302
    assert VortexItem.query.filter(VortexItem.junk_reason == "text").count() == 1
    assert VortexItem.query.filter(VortexItem.junk_reason == "duplicate").count() == 1
    common = app.test_client()
    assert common.post("/admin/vortex/qualidade/limpar").status_code in (302, 401, 403)
