"""Ping — fase 6b: mensagem fixada (por usuário), não lidas da abertura e botão ↓ com contador."""
import pathlib

import pytest

from chat_events import hub

API = "/api/v1/messages"


@pytest.fixture(autouse=True)
def _clean_hub():
    hub.reset()
    yield
    hub.reset()


@pytest.fixture()
def world(app):
    """ana e beto conversam; caio só existe. Devolve cabeçalhos de token e ids de mensagens."""
    from extensions import db as _db
    from models import ApiToken, Message, User
    with app.app_context():
        heads, ids = {}, {}
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            heads[name] = {"Authorization": f"Bearer {tok.token}"}
            ids[name] = u.id
        msgs = []
        for sender, rcpt, text in (("beto", "ana", "oi ana"), ("ana", "beto", "oi beto"),
                                   ("beto", "ana", "tudo bem?"), ("beto", "ana", "me responde")):
            m = Message(sender_id=ids[sender], recipient_id=ids[rcpt], content=text)
            _db.session.add(m)
            _db.session.commit()
            msgs.append(m.id)
        other = Message(sender_id=ids["beto"], recipient_id=ids["caio"], content="só do caio")
        _db.session.add(other)
        _db.session.commit()
        return {"heads": heads, "ids": ids, "msgs": msgs, "other": other.id}


def _pin(c, w, who, partner, mid):
    return c.put(f"{API}/{partner}/pin", headers=w["heads"][who], json={"message_id": mid})


def test_pin_roundtrip_and_replace(app, world):
    c, w = app.test_client(), world
    assert c.get(f"{API}/beto/pin", headers=w["heads"]["ana"]).get_json() == {"pinned_message": None}
    r = _pin(c, w, "ana", "beto", w["msgs"][0])
    assert r.status_code == 200
    p = r.get_json()["pinned_message"]
    assert p["id"] == w["msgs"][0] and p["preview"] == "oi ana" and p["mine"] is False
    # fixar outra substitui (uma por conversa)
    assert _pin(c, w, "ana", "beto", w["msgs"][1]).get_json()["pinned_message"]["id"] == w["msgs"][1]
    assert c.get(f"{API}/beto/pin", headers=w["heads"]["ana"]).get_json()["pinned_message"]["mine"] is True
    r = c.delete(f"{API}/beto/pin", headers=w["heads"]["ana"])
    assert r.status_code == 200 and r.get_json() == {"pinned_message": None}


def test_pin_is_per_user(app, world):
    c, w = app.test_client(), world
    _pin(c, w, "ana", "beto", w["msgs"][0])
    assert c.get(f"{API}/ana/pin", headers=w["heads"]["beto"]).get_json() == {"pinned_message": None}
    assert c.get(f"{API}/ana", headers=w["heads"]["beto"]).get_json()["pinned_message"] is None


def test_pin_validation(app, world):
    c, w = app.test_client(), world
    h = w["heads"]["ana"]
    assert c.put(f"{API}/beto/pin", headers=h, json={}).status_code == 400
    assert c.put(f"{API}/beto/pin", headers=h, json={"message_id": "1"}).status_code == 400
    assert c.put(f"{API}/beto/pin", headers=h, json={"message_id": True}).status_code == 400
    assert _pin(c, w, "ana", "beto", 99999).status_code == 404
    assert _pin(c, w, "ana", "beto", w["other"]).status_code == 404       # mensagem de outra conversa
    assert _pin(c, w, "ana", "ana", w["msgs"][0]).status_code == 400      # consigo mesma
    assert _pin(c, w, "ana", "nao_existe", w["msgs"][0]).status_code == 404
    assert c.put(f"{API}/beto/pin", json={"message_id": w["msgs"][0]}).status_code in (401, 403)


def test_cannot_pin_deleted_or_call(app, world):
    from extensions import db as _db
    from models import Message, utcnow
    c, w = app.test_client(), world
    with app.app_context():
        m = _db.session.get(Message, w["msgs"][2])
        m.deleted_at = utcnow()
        call = Message(sender_id=w["ids"]["beto"], recipient_id=w["ids"]["ana"], content="📞", msg_type="call")
        _db.session.add(call)
        _db.session.commit()
        call_id = call.id
    assert _pin(c, w, "ana", "beto", w["msgs"][2]).status_code == 400
    assert _pin(c, w, "ana", "beto", call_id).status_code == 400


def test_pin_disappears_when_deleted_for_all_or_hidden(app, world):
    from extensions import db as _db
    from models import Message, MessageHidden, utcnow
    c, w = app.test_client(), world
    _pin(c, w, "ana", "beto", w["msgs"][1])
    assert c.get(f"{API}/beto", headers=w["heads"]["ana"]).get_json()["pinned_message"]["id"] == w["msgs"][1]
    with app.app_context():
        _db.session.get(Message, w["msgs"][1]).deleted_at = utcnow()
        _db.session.commit()
    assert c.get(f"{API}/beto", headers=w["heads"]["ana"]).get_json()["pinned_message"] is None
    _pin(c, w, "ana", "beto", w["msgs"][0])
    with app.app_context():
        _db.session.add(MessageHidden(message_id=w["msgs"][0], user_id=w["ids"]["ana"]))
        _db.session.commit()
    assert c.get(f"{API}/beto/pin", headers=w["heads"]["ana"]).get_json() == {"pinned_message": None}


def test_get_thread_reports_unread_before_marking_read(app, world):
    c, w = app.test_client(), world
    d = c.get(f"{API}/beto", headers=w["heads"]["ana"]).get_json()
    assert d["first_unread_id"] == w["msgs"][0] and d["unread_count"] == 3
    d2 = c.get(f"{API}/beto", headers=w["heads"]["ana"]).get_json()
    assert d2["first_unread_id"] is None and d2["unread_count"] == 0     # já foram lidas na 1ª abertura
    assert d["prefs"] == {"pinned": False, "muted": False, "archived": False}   # prefs intacto


def _site(app, world, who="ana"):
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(world["ids"][who])
    return c


def test_page_and_fragment_carry_unread_attrs(app, world):
    html = _site(app, world).get("/mensagens/beto").get_data(as_text=True)
    assert f'data-first-unread="{world["msgs"][0]}"' in html and 'data-unread-count="3"' in html
    assert 'data-pin-url="/api/v1/messages/beto/pin"' in html
    for needle in ('id="cw-pinned"', 'id="cw-pinned-go"', 'id="cw-pinned-x"', 'id="cw-pinned-txt"'):
        assert needle in html, needle
    # 2ª abertura (agora pelo fragmento): já lidas → zero
    frag = _site(app, world).get("/mensagens/beto", headers={"X-Ping-Fragment": "1"}).get_data(as_text=True)
    assert 'data-first-unread="0"' in frag and 'data-unread-count="0"' in frag


def test_fragment_first_open_has_unread_attrs(app, world):
    frag = _site(app, world).get("/mensagens/beto", headers={"X-Ping-Fragment": "1"}).get_data(as_text=True)
    assert f'data-first-unread="{world["msgs"][0]}"' in frag and 'data-unread-count="3"' in frag


def test_old_database_gets_the_new_column(app):
    from sqlalchemy import inspect, text
    from app import _ensure_schema_upgrades
    from extensions import db as _db
    with app.app_context():
        with _db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE conversation_prefs DROP COLUMN pinned_message_id"))
        assert "pinned_message_id" not in {c["name"] for c in inspect(_db.engine).get_columns("conversation_prefs")}
        _ensure_schema_upgrades(_db)
        _ensure_schema_upgrades(_db)   # idempotente
        assert "pinned_message_id" in {c["name"] for c in inspect(_db.engine).get_columns("conversation_prefs")}


def test_pin_does_not_affect_prefs_or_inbox(app, world):
    c, w = app.test_client(), world
    _pin(c, w, "ana", "beto", w["msgs"][0])
    assert c.get(f"{API}/beto/prefs", headers=w["heads"]["ana"]).get_json() == {
        "pinned": False, "muted": False, "archived": False}


def test_js_css_and_sw_wiring():
    js = pathlib.Path("static/js/chat-thread.js").read_text(encoding="utf-8")
    for needle in ("pinMessage", "unpinMessage", "applyPinned", "pruneSeen", "mensagens não lidas",
                   "data.pinned_message", "root.dataset.firstUnread", "openAtUnread", "Fixar"):
        assert needle in js, needle
    assert "newWhileAway" not in js
    assert 'document.addEventListener(' not in js.replace("listenOn(document", "")   # regra da fase 6a
    css = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
    assert "fase 6b" in css and ".ping-mode .cw-pinned" in css and ".cw-unread" in css
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 57  # versão do cache do SW só pode subir
