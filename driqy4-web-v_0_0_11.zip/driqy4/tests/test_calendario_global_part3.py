"""Calendário global, parte 3: horários da Lua/estações no fuso do usuário, nomes de mês/dia e primeiro dia da
semana por região, e avisos de estação na hora local."""
from datetime import datetime, timedelta, timezone

import pytest

import holidays_world as hw
import season_alerts
import widgets_extra as we


def utc(*a):
    return datetime(*a, tzinfo=timezone.utc)


def _login(app, name):
    from extensions import db
    from models import User
    with app.app_context():
        u = User(username=name, email=f"{name}@x.com")
        u.set_password("senha1234")
        u.location = "Guarapari"
        u.location_lat, u.location_lng = -20.67, -40.5
        db.session.add(u)
        db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": name, "password": "senha1234"})
    return c


# ----------------------------------------------------------------- nomes e semana por região
def test_every_country_has_lang_and_week_start():
    for code in hw.COUNTRIES:
        r = hw.region_info(code)
        assert r["lang"] in hw.MONTH_NAMES and r["week_start"] in (0, 1)
        assert len(r["month_names"]) == 12 and len(r["weekdays"]) == 7


def test_calendar_brazil_is_portuguese_sunday_first():
    d = we.month_calendar(2026, 11)
    assert d["lang"] == "pt" and d["week_start"] == 0 and d["month_name"] == "novembro"
    assert d["weekdays"] == ["D", "S", "T", "Q", "Q", "S", "S"]
    assert d["first_weekday"] == 0 and d["first_offset"] == 0      # 1/nov/2026 é domingo


def test_calendar_germany_monday_first_in_german():
    d = we.month_calendar(2026, 11, country="DE")
    assert d["month_name"] == "November" and d["week_start"] == 1
    assert d["weekdays"] == ["M", "D", "M", "D", "F", "S", "S"]
    assert d["first_weekday"] == 0 and d["first_offset"] == 6      # domingo é o último da semana que começa na segunda
    d = we.month_calendar(2026, 12, country="DE")                   # 1/dez/2026 é terça
    assert d["first_weekday"] == 2 and d["first_offset"] == 1


def test_calendar_us_english_names_and_japan_kanji():
    d = we.month_calendar(2026, 7, country="US")
    assert d["month_name"] == "July" and d["weekdays"][0] == "S" and d["week_start"] == 0
    d = we.month_calendar(2026, 7, tz="Asia/Tokyo")
    assert d["country"] == "JP" and d["month_name"] == "7月" and d["weekdays"][0] == "日"


def test_first_offset_matches_a_real_week_grid():
    import calendar as pycal
    for code in hw.COUNTRIES:
        ws = hw.WEEK_START[code]
        for month in (1, 2, 5, 11):
            d = we.month_calendar(2026, month, country=code)
            cal = pycal.Calendar(firstweekday=0 if ws == 1 else 6)
            first_row = cal.monthdayscalendar(2026, month)[0]
            assert d["first_offset"] == first_row.index(1), (code, month)


# ----------------------------------------------------------------- Lua e estações no fuso do usuário
def test_tz_label():
    now = utc(2026, 11, 9, 12)
    assert we.tz_label(None, now) == "Brasília"
    assert we.tz_label(we._zone("America/Sao_Paulo"), now) == "Brasília"
    assert we.tz_label(we._zone("America/New_York"), now) == "GMT-5"
    assert we.tz_label(we._zone("Asia/Kolkata"), now) == "GMT+5:30"
    assert we.tz_label(we._zone("Asia/Tokyo"), now) == "GMT+9"


def test_moon_times_move_to_user_timezone():
    now = utc(2026, 11, 9, 12)
    br = we.moon_phase(now, -20.67, -40.5, "Guarapari")
    tk = we.moon_phase(now, -20.67, -40.5, "Guarapari", tzinfo=we._zone("Asia/Tokyo"))
    assert br["tz_label"] == "Brasília" and tk["tz_label"] == "GMT+9"
    # mesmo instante, relógios diferentes: Tóquio está 12 h à frente de Brasília
    h = lambda t: int(t[:2]) * 60 + int(t[3:])  # noqa: E731
    for k in ("rise", "set"):
        a, b = br["rise_set"][k], tk["rise_set"][k]
        if a and b:
            assert (h(b) - h(a)) % 1440 == 12 * 60
    e_br, e_tk = br["eclipses"][0], tk["eclipses"][0]
    assert e_br["kind"] == e_tk["kind"]
    t0 = datetime.fromisoformat(f"{e_br['date']}T{e_br['time']}") + timedelta(hours=12)
    assert datetime.fromisoformat(f"{e_tk['date']}T{e_tk['time']}") == t0


def test_today_follows_timezone_day():
    now = utc(2026, 11, 10, 2, 13)                     # 23:13 de 9/nov em Brasília, 11:13 de 10/nov em Tóquio
    tk = we._zone("Asia/Tokyo")
    assert we.season_info(now)["today"] == "2026-11-09"
    assert we.season_info(now, tzinfo=tk)["today"] == "2026-11-10"
    br_m, tk_m = we.moon_phase(now), we.moon_phase(now, tzinfo=tk)
    assert br_m["next_full"] == tk_m["next_full"] or br_m["days_to_full"] == tk_m["days_to_full"]  # nunca quebra
    assert tk_m["rise_set"]["next"]["today"] in (True, False)


def test_season_dates_and_labels_in_user_timezone():
    now = utc(2026, 12, 20, 12)
    br = we.season_info(now)
    nz = we.season_info(now, tzinfo=we._zone("Pacific/Auckland"))
    assert br["tz_label"] == "Brasília" and nz["tz_label"] == "GMT+13"
    # solstício de dezembro de 2026: 21/dez ~20:50 UTC -> 17:50 em Brasília, 09:50 do dia 22 em Auckland
    assert br["next"]["start_label"].startswith("21/12 17:") and br["next"]["start"] == "2026-12-21"
    assert nz["next"]["start_label"].startswith("22/12 09:") and nz["next"]["start"] == "2026-12-22"


def test_season_info_default_unchanged_without_tz():
    now = utc(2026, 11, 6, 12)
    assert we.season_info(now) == we.season_info(now, tzinfo=None)
    assert we.season_info(now)["current"]["name"] == "Primavera"


# ----------------------------------------------------------------- endpoints
def test_endpoints_accept_tz_and_remember_it(app):
    from models import User
    c = _login(app, "tz_user")
    d = c.get("/api/v1/widgets/moon?tz=Asia/Tokyo").get_json()
    assert d["tz_label"] == "GMT+9"
    d = c.get("/api/v1/widgets/seasons?tz=Europe/Lisbon").get_json()
    assert d["tz_label"] in ("GMT+0", "GMT+1")
    with app.app_context():
        assert User.query.filter_by(username="tz_user").one().tz_name == "Europe/Lisbon"
    assert c.get("/api/v1/widgets/moon").get_json()["tz_label"] == "Brasília"     # sem tz: Brasília
    c.get("/api/v1/widgets/calendar?tz=Asia/Tokyo")
    with app.app_context():
        assert User.query.filter_by(username="tz_user").one().tz_name == "Asia/Tokyo"


def test_invalid_tz_is_ignored_and_not_stored(app):
    from models import User
    c = _login(app, "tz_bad")
    d = c.get("/api/v1/widgets/moon?tz=Nao/Existe").get_json()
    assert d["tz_label"] == "Brasília"
    c.get("/api/v1/widgets/seasons?tz=" + "A" * 200)
    with app.app_context():
        assert User.query.filter_by(username="tz_bad").one().tz_name is None


def test_tz_offset_from_app_works_without_storing(app):
    from models import User
    c = _login(app, "tz_app")
    d = c.get("/api/v1/widgets/moon?tz_offset=-300").get_json()
    assert d["tz_label"] == "GMT-5"
    with app.app_context():
        assert User.query.filter_by(username="tz_app").one().tz_name is None


def test_calendar_endpoint_has_region_fields(app):
    c = _login(app, "cal_region")
    d = c.get("/api/v1/widgets/calendar?year=2026&month=11&country=GB").get_json()
    assert d["week_start"] == 1 and d["lang"] == "en" and d["month_name"] == "November"
    assert d["weekdays"][0] == "M" and d["first_offset"] == 6 and d["first_weekday"] == 0


# ----------------------------------------------------------------- avisos de estação na hora local
@pytest.fixture()
def users(app):
    from extensions import db
    from models import User, utcnow
    with app.app_context():
        for n, lat in (("ana", None), ("beto", 48.8)):
            u = User(username=n, email=f"{n}@example.com", last_seen_at=utcnow(), location_lat=lat)
            u.set_password("senha1234")
            db.session.add(u)
        db.session.commit()


def _set_tz(app, username, tz):
    from extensions import db
    from models import User
    with app.app_context():
        User.query.filter_by(username=username).one().tz_name = tz
        db.session.commit()


def test_pending_events_use_user_day_but_same_key():
    now = utc(2026, 12, 21, 12)       # 09h de 21/dez em Brasília (virada hoje); 21h de 21/dez em Tóquio (virada dia 22)
    br = season_alerts.pending_events(now)
    tk = season_alerts.pending_events(now, we._zone("Asia/Tokyo"))
    assert [(e[1], e[2]) for e in br] == [("day", 0)]
    assert [(e[1], e[2]) for e in tk] == [("pre", 1)]
    assert br[0][4].isoformat() == "2026-12-21" and tk[0][4].isoformat() == "2026-12-22"   # data local no texto
    assert br[0][0].split(":")[0] == tk[0][0].split(":")[0] == "2026-12-21"                # data-chave sempre de Brasília
    assert br[0][0].endswith(":day") and tk[0][0].endswith(":pre")


def test_alerts_follow_each_users_local_morning(app, users):
    _set_tz(app, "ana", "Asia/Tokyo")                       # beto fica sem fuso (Brasília)
    from models import Notification, User
    # 12:00 UTC de 18/dez: 09h em Brasília (3 dias antes) e 21h em Tóquio (para eles ainda faltam 4 dias)
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 18, 12)) == 1          # só o beto
    # 23:00 UTC de 18/dez: 08h de 19/dez em Tóquio, 3 dias antes da virada local (22/dez): agora a ana
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 18, 23)) == 1
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 19, 0)) == 0           # ninguém repete
    with app.app_context():
        ana = User.query.filter_by(username="ana").one()
        n = Notification.query.filter_by(recipient_id=ana.id, kind="season").one()
        assert "22/12" in n.verb                                                           # data no fuso dela


def test_alert_not_sent_before_8am_in_user_timezone(app, users):
    _set_tz(app, "ana", "America/Los_Angeles")
    # 12:00 UTC = 09h em Brasília, mas 04h em Los Angeles: só o beto recebe
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 18, 12)) == 1
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 18, 16)) == 1   # 08h em Los Angeles


def test_site_js_uses_region_fields_and_timezone():
    js = open("static/js/rail-new.js", encoding="utf-8").read()
    assert "d.weekdays" in js and "d.first_offset" in js and "tzQuery()" in js and "tzWords(d.tz_label)" in js
    assert '"/moon" + tzQuery()' in js and '"/seasons" + tzQuery()' in js
    assert "horário de Brasília\";" not in js.split("function renderMoon")[1].split("Estações")[0]
