"""Testes do motor contínuo de indexação (vortex_crawler.IngestEngine).
Servidor HTTP local simulado: nada de rede real."""
import hashlib
import io
import json
import random
import threading
import time
from datetime import timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace
from urllib.parse import parse_qs, urlparse

import pytest
from PIL import Image
from sqlalchemy import text

import vortex_crawler as vc
from models import VortexCrawlSource, VortexItem, VortexProfile, utcnow
from test_vortex_crawler import FakeHttp, FakeResp, png_bytes

PAGES_PER_TERM, PER_PAGE = 4, 20          # 80 itens por termo no servidor falso


def _noise_png(seed):
    """Imagem com 72 'pixels' aleatórios ampliados: dHashes bem distintos."""
    rnd = random.Random(seed)
    small = Image.new("L", (9, 8))
    small.putdata([rnd.randrange(256) for _ in range(72)])
    big = small.resize((300, 300), Image.Resampling.NEAREST)
    buf = io.BytesIO()
    big.save(buf, "PNG")
    return buf.getvalue()


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urlparse(self.path)
        if url.path == "/api":
            qs = parse_qs(url.query)
            term, page = qs["term"][0], int(qs["page"][0])
            items = []
            if page <= PAGES_PER_TERM:
                items = [{"term": term, "n": (page - 1) * PER_PAGE + i} for i in range(PER_PAGE)]
            body = json.dumps({"items": items, "more": page < PAGES_PER_TERM}).encode()
            self._send(200, body, "application/json")
        elif url.path.startswith("/img/"):
            seed = int(hashlib.sha1(url.path.encode()).hexdigest()[:8], 16)
            self._send(200, _noise_png(seed), "image/png")
        else:
            self._send(404, b"", "text/plain")


def fetch_mock(http, cfg, source, page):
    base = cfg["MOCK_BASE"]
    resp = http.get(f"{base}/api", params={"term": source.term, "page": page}, timeout=5)
    data = resp.json()
    out = [{
        "media_type": "photo", "media_url": f"{base}/img/{i['term']}/{i['n']}.png", "thumb_url": None,
        "width": 300, "height": 300, "title": f"{i['term']} {i['n']}", "description": "",
        "tags": [i["term"]], "source_url": f"{base}/p/{i['term']}/{i['n']}",
    } for i in data["items"]]
    return out, data["more"]


@pytest.fixture()
def engine_env(app, db, monkeypatch):
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    monkeypatch.setenv("no_proxy", "127.0.0.1,localhost")
    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    app.config.update(
        MOCK_BASE=f"http://127.0.0.1:{server.server_address[1]}",
        VORTEX_WORKERS=3, VORTEX_DOWNLOAD_WORKERS=8, VORTEX_BATCH_SIZE=10,
        VORTEX_FLUSH_SECONDS=0.3, VORTEX_SOURCE_MIN_DELAY=0.05, VORTEX_ROTATE_DELAY=0.05,
        VORTEX_HOST_INTERVALS={}, VORTEX_ALLOW_PRIVATE_HOSTS=True, VORTEX_DISCOVERY_ENABLED=False,
        VORTEX_EXPAND_TERMS={"natureza": [f"nat{i}" for i in range(1, 7)],
                             "animais": [f"ani{i}" for i in range(1, 7)],
                             "geral": ["geral1", "geral2"]},
    )
    monkeypatch.setitem(vc.ADAPTERS, "mock", fetch_mock)
    monkeypatch.setattr(vc, "_ROTATING_KINDS", vc._ROTATING_KINDS | {"mock"})
    VortexCrawlSource.query.update({"enabled": False})
    prof = VortexProfile.query.filter_by(handle="web").first()
    for name, cat, term in (("A", "natureza", "alphaone"), ("B", "animais", "betaone")):
        db.session.add(VortexCrawlSource(name=name, kind="mock", profile_id=prof.id,
                                         category=cat, term=term, media="photo"))
    db.session.commit()
    yield app
    server.shutdown()


def _count(db):
    with db.engine.connect() as conn:
        return conn.execute(text("SELECT COUNT(*) FROM vortex_items")).scalar()


def test_engine_keeps_indexing_past_first_term_and_saves_continuously(engine_env, db):
    app = engine_env
    engine = vc.IngestEngine(app, db).start(0)
    samples, t0 = [], time.monotonic()
    try:
        while time.monotonic() - t0 < 40:
            n = _count(db)
            samples.append(n)
            if n >= 500:
                break
            time.sleep(0.2)
    finally:
        engine.stop()
    elapsed = time.monotonic() - t0
    total = _count(db)
    print(f"\n[engine] {total} itens em {elapsed:.1f}s ({total / elapsed:.0f} itens/s, servidor local)")
    # 2 fontes x 80 itens no termo original = 160; passar disso prova a troca de termo
    assert total >= 500
    assert len(set(samples)) >= 5, "gravação não foi contínua (lotes pequenos)"
    titles = [r[0] for r in db.session.query(VortexItem.title).all()]
    assert any(t.startswith("nat1") for t in titles) and any(t.startswith("ani1") for t in titles)
    rows = {s.name: s for s in VortexCrawlSource.query.filter_by(kind="mock")}
    assert rows["A"].rotation >= 2 and rows["B"].rotation >= 2
    assert all(s.items_added > 0 for s in rows.values())
    assert db.session.query(VortexItem.phash).filter(VortexItem.phash.is_(None)).count() == 0


def test_restart_continues_without_duplicates(engine_env, db):
    app = engine_env
    engine = vc.IngestEngine(app, db).start(0)
    t0 = time.monotonic()
    while _count(db) < 200 and time.monotonic() - t0 < 30:
        time.sleep(0.2)
    engine.stop()
    first = _count(db)
    assert first >= 200

    engine2 = vc.IngestEngine(app, db).start(0)   # reinício: recarrega o que já foi indexado
    t0 = time.monotonic()
    while _count(db) < first + 150 and time.monotonic() - t0 < 30:
        time.sleep(0.2)
    engine2.stop()
    second = _count(db)
    assert second >= first + 150                              # seguiu de onde parou
    urls = [r[0] for r in db.session.query(VortexItem.media_url).all()]
    assert len(urls) == len(set(urls)) == second              # nada duplicado


def test_run_once_indexes_all_sources_in_parallel(engine_env, db):
    app = engine_env
    added = vc.crawl_all_sources(app, db)
    assert added == 2 * PER_PAGE                              # 1 página de cada fonte
    assert _count(db) == 2 * PER_PAGE


# ----------------------------------------------------------- agendamento
def _row(**kw):
    base = dict(kind="commons", category="natureza", next_page=1, rotation=0, fail_count=0,
                empty_streak=0, items_added=0, last_status=None, last_run_at=None, next_run_at=None)
    base.update(kw)
    return SimpleNamespace(**base)


def _res(**kw):
    base = dict(page=1, term="x", n=20, has_more=True, added=5, error=None, unavailable=False,
                retry_after=None)
    base.update(kw)
    return SimpleNamespace(**base)


def test_schedule_productive_source_advances_page(app):
    row, res = _row(), _res()
    vc.apply_source_result(app.config, row, res)
    assert row.next_page == 2 and row.rotation == 0 and row.fail_count == 0
    assert row.items_added == 5 and row.last_status.startswith("ok")
    assert row.next_run_at - utcnow() < timedelta(seconds=10)      # volta em segundos


def test_schedule_exhausted_term_rotates_instead_of_restarting(app):
    row = _row(next_page=7)
    vc.apply_source_result(app.config, row, _res(page=7, has_more=False, added=2))
    assert row.rotation == 1 and row.next_page == 1
    assert vc.effective_term(app.config, "commons", "waterfall", "natureza", row.rotation) == "mountain"


def test_schedule_three_empty_pages_rotate(app):
    row = _row(next_page=2, empty_streak=2)
    vc.apply_source_result(app.config, row, _res(page=2, added=0))
    assert row.rotation == 1 and row.empty_streak == 0


def test_schedule_error_on_deep_page_rotates_and_backs_off(app):
    row = _row(next_page=9)
    vc.apply_source_result(app.config, row, _res(page=9, error="erro: HTTP 500"))
    assert row.rotation == 1 and row.next_page == 1 and row.fail_count == 1
    first_wait = row.next_run_at - utcnow()
    vc.apply_source_result(app.config, row, _res(error="erro: HTTP 500"))
    assert row.fail_count == 2 and row.next_run_at - utcnow() > first_wait   # backoff cresce


def test_schedule_rate_limit_and_unavailable(app):
    row = _row()
    vc.apply_source_result(app.config, row, _res(retry_after=120, error="limite da API (429)"))
    assert row.next_run_at - utcnow() >= timedelta(seconds=115) and row.rotation == 0
    row = _row()
    vc.apply_source_result(app.config, row, _res(unavailable=True, error="pulada: sem PEXELS_API_KEY"))
    assert row.next_run_at - utcnow() > timedelta(hours=5)


def test_schedule_rss_waits_idle_delay_without_rotating(app):
    row = _row(kind="rss")
    vc.apply_source_result(app.config, row, _res(has_more=False))
    assert row.rotation == 0 and row.next_run_at - utcnow() > timedelta(minutes=10)


def test_api_429_becomes_rate_limited():
    http = FakeHttp({"https://api.x.org/": lambda u, k: FakeResp(429, headers={"Retry-After": "30"})})
    with pytest.raises(vc.RateLimited) as exc:
        vc._api_get(http, {"VORTEX_REQUEST_TIMEOUT": 5}, "https://api.x.org/a")
    assert exc.value.retry_after == 30


def test_host_limiter_spaces_requests_per_host():
    lim = vc.HostLimiter({"slow.example": 0.2})
    t0 = time.monotonic()
    for _ in range(3):
        lim.wait("https://slow.example/a")
    assert time.monotonic() - t0 >= 0.38
    t0 = time.monotonic()
    for _ in range(5):
        lim.wait("https://free.example/a")
    assert time.monotonic() - t0 < 0.1


def test_phash_set_claim_rejects_near_duplicates():
    s = vc.PhashSet()
    assert s.claim("00000000000000ff") is True
    assert s.claim("00000000000000fe") is False       # 1 bit de diferença
    assert s.claim("ffffffff00000000") is True


# ------------------------------------------------------ novos adaptadores
def _src(db, kind, query, media="photo", category="arte", handle=None):
    prof = VortexProfile.query.filter_by(handle=handle or kind).first()
    src = VortexCrawlSource(name="t", kind=kind, profile_id=prof.id, category=category,
                            term=query, media=media)
    db.session.add(src)
    db.session.commit()
    return src


def test_artic_adapter(app, db):
    src = _src(db, "artic", "zzz-artic")
    payload = {"pagination": {"total_pages": 3}, "config": {"iiif_url": "https://iiif.example/2"},
               "data": [{"id": 7, "title": "Paisagem", "image_id": "abc", "artist_title": "Fulano",
                         "subject_titles": ["landscapes"], "style_titles": ["Impressionism"],
                         "thumbnail": {"width": 800, "height": 600}},
                        {"id": 8, "title": "sem imagem", "image_id": None}]}
    http = FakeHttp({
        "https://api.artic.edu/api/v1/artworks/search": lambda u, k: FakeResp(200, json_data=payload),
        "https://iiif.example/2/abc/full/400,": lambda u, k: FakeResp(
            200, content=png_bytes(4), headers={"Content-Type": "image/jpeg"}),
    })
    assert vc.crawl_source(app, db, src, http=http) == 1
    item = VortexItem.query.filter_by(source_id=src.id).one()
    assert item.media_url == "https://iiif.example/2/abc/full/843,/0/default.jpg"
    assert item.attribution == "Fulano" and "landscapes" in item.tag_list
    assert src.next_page == 2


def test_met_adapter(app, db):
    vc._MET_IDS.clear()
    src = _src(db, "met", "zzz-met")
    obj = {"isPublicDomain": True, "primaryImage": "https://images.met.example/a.jpg",
           "primaryImageSmall": "https://images.met.example/a-small.jpg", "title": "Vaso",
           "objectURL": "https://met.example/o/1", "artistDisplayName": "", "objectName": "Vase",
           "tags": [{"term": "Flowers"}]}
    http = FakeHttp({
        "https://collectionapi.metmuseum.org/public/collection/v1/search":
            lambda u, k: FakeResp(200, json_data={"objectIDs": [1, 2]}),
        "https://collectionapi.metmuseum.org/public/collection/v1/objects/1":
            lambda u, k: FakeResp(200, json_data=obj),
        "https://collectionapi.metmuseum.org/public/collection/v1/objects/2":
            lambda u, k: FakeResp(200, json_data=dict(obj, isPublicDomain=False)),
        "https://images.met.example/a-small.jpg": lambda u, k: FakeResp(
            200, content=png_bytes(6), headers={"Content-Type": "image/jpeg"}),
    })
    assert vc.crawl_source(app, db, src, http=http) == 1
    item = VortexItem.query.filter_by(source_id=src.id).one()
    assert item.license.startswith("CC0") and "flowers" in item.tag_list
    assert item.attribution == "The Metropolitan Museum of Art"


def test_nasa_adapter_probes_medium_variant(app, db):
    src = _src(db, "nasa", "zzz-nasa", category="ciencia")
    payload = {"collection": {"links": [{"rel": "next"}], "items": [
        {"data": [{"title": "Nebulosa", "keywords": ["nebula"], "nasa_id": "N1",
                   "description": "<b>Bela</b>", "center": "JPL"}],
         "links": [{"rel": "preview", "href": "https://images-assets.nasa.example/N1/N1~thumb.jpg"}]}]}}
    http = FakeHttp({
        "https://images-api.nasa.gov/search": lambda u, k: FakeResp(200, json_data=payload),
        "https://images-assets.nasa.example/N1/N1~medium.jpg": lambda u, k: FakeResp(
            200, content=png_bytes(8), headers={"Content-Type": "image/jpeg",
                                                "Content-Range": "bytes 0-1023/90000"}),
    })
    assert vc.crawl_source(app, db, src, http=http) == 1
    item = VortexItem.query.filter_by(source_id=src.id).one()
    assert item.media_url.endswith("N1~medium.jpg") and "nebula" in item.tag_list
    assert item.width and item.width >= 200          # tamanho vindo da imagem baixada


def test_unsplash_needs_key_then_works(app, db):
    src = _src(db, "unsplash", "zzz-unsplash", category="natureza")
    assert vc.crawl_source(app, db, src, http=FakeHttp({})) == 0
    assert "sem UNSPLASH_ACCESS_KEY" in src.last_status
    app.config["UNSPLASH_ACCESS_KEY"] = "k"
    payload = {"total_pages": 2, "results": [{
        "urls": {"regular": "https://u.example/r.jpg", "small": "https://u.example/s.jpg"},
        "width": 4000, "height": 3000, "alt_description": "a mountain lake",
        "tags": [{"title": "lake"}], "links": {"html": "https://unsplash.example/p/1"},
        "user": {"name": "Ana"}}]}
    http = FakeHttp({
        "https://api.unsplash.com/search/photos": lambda u, k: FakeResp(200, json_data=payload),
        "https://u.example/s.jpg": lambda u, k: FakeResp(
            200, content=png_bytes(11), headers={"Content-Type": "image/jpeg"}),
    })
    assert vc.crawl_source(app, db, src, http=http) == 1
    assert VortexItem.query.filter_by(source_id=src.id).one().attribution == "Ana"
