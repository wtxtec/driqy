"""Chat rico — Fase 4: MIME por assinatura (GIF) e auth por sessão (site)."""
import io

import pytest

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
GIF = b"GIF89a" + b"\x00" * 64
JPG = b"\xff\xd8\xff\xe0" + b"\x00" * 64
WEBP = b"RIFF\x00\x00\x00\x00WEBP" + b"\x00" * 32


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _send(c, headers, data, name, **form):
    return c.post("/api/v1/messages/beto", headers=headers,
                  data={"file": (io.BytesIO(data), name), **form},
                  content_type="multipart/form-data")


@pytest.mark.parametrize("data,name,mime", [
    (PNG, "a.png", "image/png"), (GIF, "a.gif", "image/gif"),
    (JPG, "a.jpg", "image/jpeg"), (WEBP, "a.webp", "image/webp"),
])
def test_mime_comes_from_signature(app, users, data, name, mime):
    j = _send(app.test_client(), users[0], data, name).get_json()
    assert j["msg_type"] == "image" and j["media_mime"] == mime


def test_client_cannot_spoof_mime(app, users):
    c = app.test_client()
    r = c.post("/api/v1/messages/beto", headers=users[0],
               data={"file": (io.BytesIO(PNG), "a.png", "text/html")},
               content_type="multipart/form-data")
    assert r.get_json()["media_mime"] == "image/png"


def test_gif_served_with_gif_mimetype_and_nosniff(app, users):
    c = app.test_client()
    j = _send(c, users[0], GIF, "a.gif").get_json()
    r = c.get(j["media_url"], headers=users[1])
    assert r.status_code == 200 and r.mimetype == "image/gif"
    assert r.headers["X-Content-Type-Options"] == "nosniff"


def _login(app, name):
    c = app.test_client()
    with c.session_transaction() as s:
        from models import User
        with app.app_context():
            s["_user_id"] = str(User.query.filter_by(username=name).first().id)
            s["_fresh"] = True
    return c


def test_site_session_can_read_thread_and_media(app, users):
    api = app.test_client()
    j = _send(api, users[0], PNG, "a.png").get_json()
    beto = _login(app, "beto")
    assert beto.get("/api/v1/messages/ana").status_code == 200
    assert beto.get(j["media_url"]).status_code == 200
    assert _login(app, "caio").get(j["media_url"]).status_code == 404


def test_site_session_post_needs_fetch_header(app, users):
    ana = _login(app, "ana")
    r = ana.post("/api/v1/messages/beto", json={"content": "oi"})
    assert r.status_code == 400  # sem X-Requested-With: bloqueia (CSRF)
    r = ana.post("/api/v1/messages/beto", json={"content": "oi"},
                 headers={"X-Requested-With": "fetch"})
    assert r.status_code == 200 and r.get_json()["mine"] is True


def test_site_session_can_react(app, users):
    ana = _login(app, "ana")
    mid = ana.post("/api/v1/messages/beto", json={"content": "oi"},
                   headers={"X-Requested-With": "fetch"}).get_json()["id"]
    beto = _login(app, "beto")
    h = {"X-Requested-With": "fetch"}
    assert beto.put(f"/api/v1/messages/{mid}/reaction", json={"emoji": "👍"}).status_code == 400
    assert beto.put(f"/api/v1/messages/{mid}/reaction", json={"emoji": "👍"}, headers=h).status_code == 200


def test_anonymous_still_401(app):
    c = app.test_client()
    assert c.get("/api/v1/messages/ana").status_code == 401
    assert c.get("/api/v1/messages/media/1").status_code == 401


def test_invalid_bearer_does_not_fall_back_to_session(app, users):
    beto = _login(app, "beto")
    r = beto.get("/api/v1/messages/ana", headers={"Authorization": "Bearer lixo"})
    assert r.status_code == 401
