"""Peq-2: dispensar manchete no widget de Notícias (site)."""
import pathlib
import re

W = pathlib.Path("static/js/rail-widgets.js").read_text(encoding="utf-8")
CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")


def test_dismiss_button_and_local_storage_only():
    assert "rail-dismiss" in W and "Dispensar esta manchete" in W
    assert 'DISMISS_KEY = "driqy-news-dismissed"' in W
    assert "localStorage" in W and "try" in W  # sempre protegido: storage pode falhar


def test_refill_asks_server_for_more_headlines():
    assert "limit=" in W and "newsQuery" in W and "Math.min(" in W


def test_restore_link_and_css():
    assert "Mostrar as dispensadas" in W
    assert ".rail-dismiss" in CSS and ".rail-news-item" in CSS


def test_server_text_still_never_through_innerhtml():
    uses = re.findall(r"innerHTML\s*=\s*([^;\n]{0,10})", W)
    assert all(u.strip().startswith('""') for u in uses), uses


def test_service_worker_bumped():
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 63  # versão do cache do SW só pode subir
