"""Parte 8: curtir / \"menos disso\" na grade web do Vortex."""
import pathlib

from flask import render_template

from models import VortexInteraction, VortexSeen
from tests.test_vortex_seen import mk_item, mk_user

JS = pathlib.Path("static/js/vortex.js").read_text(encoding="utf-8")
CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")


def _login(app, user):
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["_fresh"] = True
    return client


def test_crawler_tile_has_only_less_button_like_is_inside_item_page(app, db):
    it = mk_item(db, "natureza")
    with app.test_request_context():
        html = render_template("_picture_tile.html",
                               tile={"kind": "crawler", "item": it, "key": f"c{it.id}"})
    assert 'data-kind="less"' in html and 'data-kind="like"' not in html  # curtir fica dentro da imagem (item)
    # os botões ficam FORA do <a>, senão o clique abriria o detalhe
    assert html.index("picture-tile-actions") > html.index("</a>")


def test_js_sends_reaction_and_hides_on_less():
    assert "/api/pictures/interact" in JS
    assert ".picture-tile-act" in JS and "is-liked" in JS and "tile.hidden = true" in JS
    assert "stopPropagation" in JS


def test_css_shows_actions_on_touch_and_hover():
    assert ".picture-tile-actions" in CSS
    assert "@media (hover: none) { .picture-tile-actions { opacity: 1; } }" in CSS
    assert ".picture-tile[hidden] { display: none !important; }" in CSS


def test_interact_like_and_less_for_crawler_item(app, db):
    u = mk_user(db, "ana")
    client = _login(app, u)
    it = mk_item(db, "natureza")
    r = client.post("/api/pictures/interact", json={"kind": "like", "item_id": it.id})
    assert r.status_code == 200 and r.get_json()["ok"] is True
    other = mk_item(db, "carros")
    r = client.post("/api/pictures/interact", json={"kind": "less", "item_id": other.id})
    assert r.status_code == 200
    kinds = {i.kind for i in VortexInteraction.query.filter_by(user_id=u.id)}
    assert {"like", "less"} <= kinds
    # \"menos disso\" entra no livro como rejeitado (nunca volta)
    assert VortexSeen.query.filter_by(user_id=u.id, key=f"c{other.id}").first() is not None


def test_interact_rejects_bad_payload(app, db):
    u = mk_user(db, "ana")
    client = _login(app, u)
    assert client.post("/api/pictures/interact", json={"kind": "like"}).status_code == 400
    assert client.post("/api/pictures/interact", json={"kind": "nada", "item_id": 1}).status_code == 400


def test_item_page_like_and_scroll_top_assets():
    import pathlib
    item = pathlib.Path("templates/vortex_item.html").read_text(encoding="utf-8")
    assert "vortex-item-like" in item and "vortex-item-frame" in item and "vortex-like.js" in item
    like = pathlib.Path("static/js/vortex-like.js").read_text(encoding="utf-8")
    assert '"like"' in like and "/api/pictures/interact" in like
    top = pathlib.Path("static/js/scroll-top.js").read_text(encoding="utf-8")
    assert ".pictures-page, .news-page" in top and "scrollTo" in top
