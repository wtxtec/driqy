"""Parte 3A — taxonomia de conceitos do Vortex (vortex_concepts.py).

Módulo puro: nenhum teste aqui precisa de app, banco ou rede.
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import vortex_concepts as vc  # noqa: E402
from config import Config  # noqa: E402


def ids(text, **kw):
    return [c for c, _ in vc.extract(title=text, **kw).concepts]


def sim(a, b):
    return vc.similarity(vc.extract(title=a), vc.extract(title=b))


# ---------------------------------------------------------------- integridade

def test_taxonomy_integrity():
    assert vc.stats()["roots"] == 14
    assert len(vc.TAXONOMY) >= 150
    for cid, c in vc.TAXONOMY.items():
        if c.parent:
            assert c.parent in vc.TAXONOMY
            assert c.depth == vc.TAXONOMY[c.parent].depth + 1
        assert c.root in vc.TAXONOMY and vc.TAXONOMY[c.root].parent is None
        assert vc.label_of(cid)


def test_every_concept_has_at_least_one_term():
    own = {}
    for term, cids in vc._TERMS.items():
        for c in cids:
            own[c] = own.get(c, 0) + 1
    # nós só-estruturais podem não ter termo próprio, mas quase todos têm
    missing = [c for c in vc.TAXONOMY if c not in own]
    assert len(missing) <= 5, missing


def test_every_vortex_category_has_a_root():
    slugs = [s for s, _ in Config.VORTEX_CATEGORIES if s != "outros"]
    for slug in slugs:
        assert vc.CATEGORY_ROOT[slug] in vc.TAXONOMY, slug


def test_links_and_overrides_point_to_real_concepts():
    for a, b, s in vc.LINKS:
        assert a in vc.TAXONOMY and b in vc.TAXONOMY and 0 < s < 1
    for label, cid in vc.VISUAL_LABEL_OVERRIDES.items():
        assert cid in vc.TAXONOMY, (label, cid)


def test_clip_vocabulary_is_fully_understood():
    """Todo rótulo que o CLIP pode devolver vira pelo menos 1 conceito."""
    missing = []
    for _en, pt, _cat in Config.VORTEX_VISUAL_CONCEPTS:
        if not vc.extract(visual_tags=pt).concepts:
            missing.append(pt)
    assert not missing, missing


# ----------------------------------------------------------------- hierarquia

def test_ancestors_family_root():
    assert vc.ancestors("carro_esportivo") == ["carro", "veiculo_rodas", "veiculo"]
    assert vc.root_of("moto") == "veiculo"
    assert vc.family_of("carro_esportivo") == "veiculo_rodas"
    assert vc.family_of("moto") == "veiculo_rodas"
    assert vc.family_of("veiculo") == "veiculo"
    assert "carro_antigo" in vc.descendants("carro")
    assert set(vc.children("veiculo_rodas")) >= {"carro", "moto", "caminhao", "bicicleta"}


def test_relation_levels():
    assert vc.relation("carro", "carro") == 1.0
    assert vc.relation("carro", "carro_esportivo") == 0.8       # pai/filho
    assert vc.relation("carro", "moto") == 0.65                 # irmãos
    assert vc.relation("carro_esportivo", "moto") == 0.5        # sobrinho/tio
    assert vc.relation("carro", "aviao") == 0.25                # só o domínio
    assert vc.relation("carro", "danca") == 0.0                 # domínios diferentes
    assert vc.relation("bicicleta", "ciclismo") == 0.7          # ligação explícita
    assert vc.relation("nao_existe", "carro") == 0.0


def test_relation_is_symmetric_and_bounded():
    sample = list(vc.TAXONOMY)[::7]
    for a in sample:
        for b in sample:
            r = vc.relation(a, b)
            assert 0.0 <= r <= 1.0
            assert r == vc.relation(b, a)


def test_related_concepts_for_car():
    rel = dict(vc.related_concepts("carro", min_score=0.45))
    for c in ("moto", "caminhao", "bicicleta", "onibus", "carro_esportivo", "carro_antigo"):
        assert c in rel, c
    for c in ("danca", "balao", "pizza", "gato", "festa"):
        assert c not in rel


# --------------------------------------------------- o problema do usuário

def test_car_never_suggests_dancing_or_balloons():
    car = vc.extract(title="Red sports car")
    for other in ("people dancing at a party", "colorful balloons", "pizza", "a cat",
                  "bride and groom wedding", "football match"):
        assert vc.similarity(car, vc.extract(title=other)) == 0.0, other


def test_car_suggests_other_wheeled_vehicles():
    car = vc.extract(title="Red sports car")
    for other in ("motorcycle", "truck", "bicycle", "bus", "Carro antigo", "tractor"):
        assert vc.similarity(car, vc.extract(title=other)) >= 0.45, other
    # outros veículos (sem rodas) ficam abaixo dos de rodas
    assert vc.similarity(car, vc.extract(title="airplane")) < vc.similarity(car, vc.extract(title="truck"))
    assert 0 < vc.similarity(car, vc.extract(title="airplane")) < 0.45


def test_party_balloon_is_not_a_vehicle():
    assert ids("Colorful balloons at a birthday party")[0] == "balao"
    assert vc.root_of("balao") == "pessoas"
    assert ids("hot air balloon over the valley")[0] == "balao_ar_quente"
    assert vc.root_of("balao_ar_quente") == "veiculo"
    # o rótulo do CLIP "balão" (categoria viagens) é o de ar quente
    assert vc.extract(visual_tags="balão").concepts[0][0] == "balao_ar_quente"


def test_dancing_is_a_person_activity():
    assert ids("pessoas dançando") == ["danca"]
    assert ids("Dancers on stage")[0] == "danca"
    assert vc.root_of("danca") == "pessoas"


# ------------------------------------------------------------------ extração

def test_longest_match_wins():
    assert ids("campo de futebol") == ["futebol"]            # não "campo"
    assert ids("Rio de Janeiro skyline") == ["cidade"]       # não "rio"
    assert ids("Bruce Banner") == []                          # "banner" não é cartaz
    assert ids("Porto Alegre") == ["cidade"]


def test_accents_case_and_plurals():
    assert ids("CACHOEIRAS") == ["cachoeira"]
    assert ids("Dançarinos") == ["danca"]
    assert ids("two dogs and a puppy")[0] == "cachorro"
    assert ids("ônibus escolar") == ["onibus"]
    assert ids("cães") == ["cachorro"]
    assert ids("balões")[0] == "balao"


def test_sources_are_combined_and_weighted():
    u = vc.extract(title="Sunday trip", tags="car,road,sunset", description="a beautiful day")
    names = [c for c, _ in u.concepts]
    assert "carro" in names and "estrada" in names and "por_do_sol" in names
    assert u.source == "text" and u.confidence > 0.5
    # título pesa mais que descrição
    t = vc.extract(title="dog", description="cat")
    assert t.concepts[0][0] == "cachorro"
    w = dict(t.concepts)
    assert w["gato"] < w["cachorro"]


def test_visual_tags_from_clip():
    u = vc.extract(title="Untitled 123", visual_tags="azul, escuro, cachoeira")
    assert u.concepts[0][0] == "cachoeira"
    assert u.domain == "natureza"


def test_ambiguous_term_splits_weight():
    found = vc._match_text("comics")          # quadrinhos (desenho) ou humor
    assert set(found) == {"desenho", "humor"}
    assert found["desenho"] == found["humor"] == 0.5     # peso dividido
    # "casamento" é casamento, não "festa" em geral (o mais específico vence)
    assert ids("casamento")[0] == "casamento"


def test_category_fallback_and_empty():
    u = vc.extract(title="IMG_20240101", category="carros")
    assert u.concepts == [] and u.domain == "veiculo" and u.source == "category"
    assert u.confidence == pytest.approx(0.15)
    e = vc.extract(title="", category="outros")
    assert e.concepts == [] and e.domain is None and e.source == "none"
    assert vc.similarity(u, e) == 0.0
    assert vc.concept_tags(u).strip() == "veiculo"


def test_max_concepts_and_order():
    text = "car truck bike bus tractor plane helicopter boat ship train"
    u = vc.extract(title=text)
    assert len(u.concepts) <= vc.MAX_CONCEPTS
    ws = [w for _, w in u.concepts]
    assert ws == sorted(ws, reverse=True) and ws[0] == 1.0


def test_families_and_domain():
    u = vc.extract(title="motorcycle and bicycle")
    assert u.domain == "veiculo"
    assert u.families == ["veiculo_rodas"]


# ---------------------------------------------------------------- similaridade

def test_similarity_is_symmetric_and_bounded():
    pairs = [("sports car", "truck"), ("cat", "dog"), ("pizza", "sushi"), ("beach", "surf")]
    for a, b in pairs:
        s1, s2 = sim(a, b), sim(b, a)
        assert s1 == s2 and 0.0 <= s1 <= 1.0


def test_similarity_orders_sensibly():
    assert sim("cat", "cat") == 1.0
    assert sim("cat", "dog") > sim("cat", "elephant") > sim("cat", "pizza")
    assert sim("pizza", "sushi") > sim("pizza", "motorcycle")
    assert sim("bicycle", "cycling race") > 0.6
    assert vc.similarity([], [("carro", 1.0)]) == 0.0


# ------------------------------------------------------------- gravar / ler

def test_encode_decode_roundtrip():
    u = vc.extract(title="red sports car", tags="road,sunset")
    text = vc.encode(u)
    assert len(text) <= 120
    back = vc.decode(text)
    assert [c for c, _ in back] == [c for c, _ in u.concepts]
    for (_, w1), (_, w2) in zip(u.concepts, back):
        assert abs(w1 - w2) < 0.011
    assert vc.decode("lixo,carro:abc,naoexiste:1,moto:0.5") == [("moto", 0.5)]
    assert vc.decode(None) == []


def test_concept_tags_include_ancestors():
    tags = vc.concept_tags(vc.extract(title="sports car"))
    for token in ("carro_esportivo", "carro", "veiculo_rodas", "veiculo"):
        assert " %s " % token in tags
    assert tags.startswith(" ") and tags.endswith(" ")
    assert vc.concept_tags(vc.extract(title="")) == ""


def test_find_concepts_for_queries():
    assert vc.find_concepts("fotos de carros esportivos")[0] == "carro_esportivo"
    assert "gato" in vc.find_concepts("gatinho fofo")
    assert vc.find_concepts("xyzzy") == []


def test_describe_and_cli(capsys):
    assert "Carro" in vc.describe(vc.extract(title="car"))
    assert "sem conceito" in vc.describe(vc.extract(title="xyzzy"))
    assert vc.main(["x", "red car", "motorcycle"]) == 0
    out = capsys.readouterr().out
    assert "similaridade" in out
    assert vc.main(["x", "--stats"]) == 0


def test_extract_is_fast_enough_for_backfill():
    import time
    t0 = time.time()
    for _ in range(500):
        vc.extract(title="red sports car on the road at sunset", tags="car,road,sunset",
                   description="A beautiful photo of a red sports car driving along a coastal road.")
    assert (time.time() - t0) / 500 < 0.005       # < 5 ms por item (100k itens ≈ 8 min)
