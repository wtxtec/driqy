"""Ping — fase 10: polimento (tema claro com contraste AA, acessibilidade, movimento reduzido, CSS morto)."""
import pathlib
import re

import pytest

CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")


def _lum(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def _contrast(a, b):
    la, lb = sorted((_lum(a), _lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def _light_block():
    m = re.search(r'\[data-theme="light"\] \{\s*--ping-on-accent[^}]*\}', CSS)
    assert m, "bloco claro dos tokens do Ping não encontrado"
    return m.group(0)


def test_light_gradient_has_aa_contrast_with_white_text():
    stops = re.search(r"--ping-gradient:\s*linear-gradient\(135deg,\s*(#[0-9a-f]{6}),\s*(#[0-9a-f]{6})\)", _light_block())
    assert stops, "gradiente claro do Ping sem override"
    for color in stops.groups():
        assert _contrast("#ffffff", color) >= 4.5, color


def test_light_active_tab_text_and_muted_have_aa_contrast():
    accent = re.search(r"--ping-accent-text:\s*(#[0-9a-f]{6})", _light_block()).group(1)
    for bg in ("#f0ece3", "#ffffff", "#f7f4ee"):
        assert _contrast(accent, bg) >= 4.5, (accent, bg)
    muted = re.search(r'\[data-theme="light"\] \.ping-mode \{ --text-muted: (#[0-9a-f]{6});', CSS).group(1)
    assert _contrast(muted, "#f0ece3") >= 4.5
    assert "color: var(--ping-accent-text" in CSS  # a aba ativa usa o token


def test_dead_chat_page_rules_removed_but_flash_rule_kept():
    for dead in ("body.chat-page .content", "body.chat-page .bottom-nav", "body.chat-page .site-footer"):
        assert dead not in CSS, dead
    assert "body.chat-page .flash-stack" in CSS
    assert 'classList.add("ping-view-main", "chat-page")' in pathlib.Path("static/js/ping-shell.js").read_text(encoding="utf-8")


def test_drop_zone_follows_theme():
    m = re.search(r"\.cw-drop \{[^}]*\}", CSS)
    assert "var(--ping-bg" in m.group(0)


def test_focus_reduced_motion_touch_targets_present():
    block = CSS[CSS.index("fase 10: polimento"):]
    assert ".ping-mode a:focus-visible" in block and ".ping-mode button:focus-visible" in block
    assert "@media (prefers-reduced-motion: reduce)" in block and ".ping-mode *" in block
    assert "@media (pointer: coarse)" in block and "44px" in block
    assert "@media (forced-colors: active)" in block


@pytest.fixture()
def me(app):
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User(username="ana", email="ana@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
        uid = u.id
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(uid)
    return c


def test_contacts_filter_is_nav_with_aria_current(me):
    html = me.get("/mensagens/contatos").get_data(as_text=True)
    assert '<nav class="ping-seg" aria-label="Filtrar contatos">' in html
    assert 'role="tab"' not in html and 'role="tablist"' not in html
    assert html.count('aria-current="page"') == 2  # aba "Contatos" da pílula + filtro "Seguindo"
    html = me.get("/mensagens/contatos?aba=seguidores").get_data(as_text=True)
    seg = html.split('<nav class="ping-seg"')[1].split("</nav>")[0]
    assert seg.count('aria-current="page"') == 1 and "Seguidores" in seg.split('aria-current="page"')[1].split("</a>")[0]


def test_service_worker_bumped():
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 57  # versão do cache do SW só pode subir
