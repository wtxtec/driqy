"""Livro de vistos do Vortex: o que já foi visto não volta."""
from datetime import timedelta

import pytest

import vortex_seen as vs
import vortex_taste as vt
from models import VortexItem, VortexSeen, utcnow
from tests.test_vortex_taste import headers_for, mk_item, mk_post, mk_user


@pytest.fixture(autouse=True)
def _clean(app):
    vt.clear_caches()
    yield
    vt.clear_caches()


def _first_page_keys(app, user, n=30):
    return vt.ranked_page(app, user.id, page_size=n)["keys"]


# ------------------------------------------------------------ gravação
def test_clean_keys_rejects_garbage_and_dedupes():
    assert vs.clean_keys(["c1", "c1", "p2", "x3", "c", "c9;drop", 5, None]) == ["c1", "p2"]
    assert len(vs.clean_keys([f"c{i}" for i in range(500)])) == vs.MAX_KEYS_PER_CALL


def test_mark_served_and_viewed_counts(app, db):
    u = mk_user(db, "ana")
    vs.mark_served(u.id, ["c1", "p2"])
    vs.mark_served(u.id, ["c1"])
    vs.mark_viewed(u.id, ["c1"])
    rows = {r.key: r for r in VortexSeen.query.filter_by(user_id=u.id)}
    assert rows["c1"].served_count == 2 and rows["c1"].viewed_count == 1
    assert rows["p2"].served_count == 1 and rows["p2"].viewed_count == 0
    assert rows["c1"].last_viewed_at is not None and rows["p2"].last_viewed_at is None


def test_viewed_without_served_still_creates_row(app, db):
    u = mk_user(db, "ana")
    vs.mark_viewed(u.id, ["c7"])
    r = VortexSeen.query.one()
    assert r.viewed_count == 1 and r.served_count == 1


def test_users_are_independent(app, db):
    a, b = mk_user(db, "ana"), mk_user(db, "bia")
    vs.mark_viewed(a.id, ["c1"])
    assert vs.load(a.id).is_blocked("c1") and not vs.load(b.id).is_blocked("c1")


# ------------------------------------------------------------ política
def _ledger_with(db, user, **kw):
    now = utcnow()
    row = VortexSeen(user_id=user.id, key="c1", first_seen_at=now, **kw)
    db.session.add(row)
    db.session.commit()
    return vs.load(user.id, now)


def test_served_only_is_blocked_for_hours_then_comes_back(app, db):
    u = mk_user(db, "ana")
    now = utcnow()
    led = _ledger_with(db, u, served_count=1, last_served_at=now - timedelta(hours=10))
    assert led.is_blocked("c1") and led.factor("c1") == 0.0
    led = vs.Ledger(list(led.rows.values()), now + timedelta(hours=40))
    assert not led.is_blocked("c1")
    assert vs.SOFT_FLOOR <= led.factor("c1") < 1.0


def test_viewed_blocks_for_weeks_and_ramps_back_to_full(app, db):
    u = mk_user(db, "ana")
    now = utcnow()
    led = _ledger_with(db, u, served_count=1, viewed_count=1,
                       last_served_at=now, last_viewed_at=now)
    rows = list(led.rows.values())
    assert vs.Ledger(rows, now + timedelta(days=29)).is_blocked("c1")
    assert not vs.Ledger(rows, now + timedelta(days=31)).is_blocked("c1")
    assert vs.Ledger(rows, now + timedelta(days=31 + vs.SOFT_RAMP_DAYS + 1)).factor("c1") == 1.0


def test_rejected_blocks_longer_than_viewed(app, db):
    u = mk_user(db, "ana")
    now = utcnow()
    led = _ledger_with(db, u, served_count=1, viewed_count=1, rejected=True,
                       last_served_at=now, last_viewed_at=now)
    assert vs.Ledger(list(led.rows.values()), now + timedelta(days=60)).is_blocked("c1")


# ------------------------------------------------------------ ranking
def test_pages_served_do_not_come_back_on_refresh(app, db):
    u = mk_user(db, "ana")
    for i in range(160):
        mk_item(db, "natureza" if i % 2 else "carros", tags=f"t{i}")
    first = set(_first_page_keys(app, u, 30))
    assert len(first) == 30
    vt.clear_caches()                     # "fechou e abriu o app": nova sessão
    second = set(_first_page_keys(app, u, 30))
    assert second and not (first & second)


def test_viewed_items_never_return_while_new_ones_exist(app, db):
    u = mk_user(db, "ana")
    items = [mk_item(db, "natureza", tags=f"t{i}") for i in range(120)]
    seen = {f"c{i.id}" for i in items[60:]}   # os 60 mais NOVOS (o topo do acervo)
    vs.mark_viewed(u.id, list(seen)[:60])
    vt.clear_caches()
    keys = vt.rank_keys(app, u.id)[0]
    assert keys and not (set(keys) & seen)


def test_pool_overfetch_finds_new_items_behind_a_wall_of_seen_ones(app, db):
    """Quem já viu o topo inteiro do acervo ainda recebe peças novas (mais antigas)."""
    u = mk_user(db, "ana")
    items = [mk_item(db, "natureza", tags=f"t{i}") for i in range(vt.POOL_RECENT + 80)]
    wall = [f"c{i.id}" for i in items[-vt.POOL_RECENT:]]   # as 700 mais novas, todas vistas
    for i in range(0, len(wall), 150):
        vs.mark_viewed(u.id, wall[i:i + 150])
    vt.clear_caches()
    keys = vt.rank_keys(app, u.id)[0]
    assert len(keys) >= 60
    assert not (set(keys) & set(wall))


def test_empty_catalog_recycles_oldest_seen_instead_of_blank_grid(app, db):
    u = mk_user(db, "ana")
    items = [mk_item(db, "natureza", tags=f"t{i}") for i in range(40)]
    now = utcnow()
    for n, it in enumerate(items):    # todas vistas; o 0 foi visto há mais tempo
        vs.mark_viewed(u.id, [f"c{it.id}"], now=now - timedelta(hours=2 * (40 - n)))
    vt.clear_caches()
    keys = vt.rank_keys(app, u.id)[0]
    assert len(keys) == 40            # nada de grade vazia
    assert keys[0] == f"c{items[0].id}"   # a vista há mais tempo vem primeiro


def test_recycle_never_brings_back_rejected(app, db):
    u = mk_user(db, "ana")
    a, b = mk_item(db, "natureza"), mk_item(db, "natureza")
    vs.mark_viewed(u.id, [f"c{a.id}"], rejected=True)
    vs.mark_viewed(u.id, [f"c{b.id}"])
    vt.clear_caches()
    keys = vt.rank_keys(app, u.id)[0]
    assert f"c{a.id}" not in keys and f"c{b.id}" in keys


def test_user_posts_are_also_remembered(app, db):
    u, author = mk_user(db, "ana"), mk_user(db, "bia")
    posts = [mk_post(db, author) for _ in range(5)]
    for i in range(80):
        mk_item(db, "natureza", tags=f"t{i}")
    vs.mark_viewed(u.id, [f"p{p.id}" for p in posts])
    vt.clear_caches()
    keys = vt.rank_keys(app, u.id)[0]
    assert not any(k.startswith("p") for k in keys)


def test_near_duplicate_of_a_seen_image_is_hidden(app, db):
    u = mk_user(db, "ana")
    seen_item = mk_item(db, "natureza")
    twin = mk_item(db, "natureza")
    other = mk_item(db, "natureza")
    seen_item.phash = "f0f0f0f0f0f0f0f0"
    twin.phash = "f0f0f0f0f0f0f0f1"       # 1 bit de diferença: a mesma imagem
    other.phash = "0f0f0f0f0f0f0f0f"      # totalmente diferente
    db.session.commit()
    vs.mark_viewed(u.id, [f"c{seen_item.id}"])
    vt.clear_caches()
    keys = set(vt.rank_keys(app, u.id)[0])
    assert f"c{twin.id}" not in keys and f"c{other.id}" in keys


def test_near_index_finds_only_close_hashes():
    idx = vs.NearIndex([0xF0F0F0F0F0F0F0F0])
    assert idx.near(0xF0F0F0F0F0F0F0F1)
    assert idx.near(0xF0F0F0F0F0F0F0F0 ^ 0b111111)          # 6 bits
    assert not idx.near(0x0F0F0F0F0F0F0F0F)
    assert not vs.NearIndex().near(0xF0F0F0F0F0F0F0F0)


def test_soft_factor_lowers_but_does_not_remove(app, db):
    u = mk_user(db, "ana")
    it = mk_item(db, "natureza")
    old = utcnow() - timedelta(days=vs.VIEWED_BLOCK_DAYS + 3)
    db.session.add(VortexSeen(user_id=u.id, key=f"c{it.id}", served_count=1, viewed_count=1,
                              first_seen_at=old, last_served_at=old, last_viewed_at=old))
    db.session.commit()
    vt.clear_caches()
    assert f"c{it.id}" in vt.rank_keys(app, u.id)[0]


def test_record_open_marks_item_as_viewed_and_less_as_rejected(app, db):
    u = mk_user(db, "ana")
    a, b = mk_item(db, "natureza"), mk_item(db, "carros")
    vt.record(u.id, "open", item=a)
    vt.record(u.id, "less", item=b)
    led = vs.load(u.id)
    assert led.is_blocked(f"c{a.id}") and led.is_blocked(f"c{b.id}")
    assert led.rows[f"c{b.id}"].rejected and not led.rows[f"c{a.id}"].rejected


# ------------------------------------------------------------ endpoints
def test_api_seen_endpoint_records_and_validates(app, db):
    client = app.test_client()
    u = mk_user(db, "ana")
    h = headers_for(db, u)
    it = mk_item(db, "natureza")
    r = client.post("/api/v1/vortex/seen", json={"keys": [f"c{it.id}", "lixo"]}, headers=h)
    assert r.status_code == 200 and r.get_json()["recorded"] == 1
    assert vs.load(u.id).is_blocked(f"c{it.id}")
    assert client.post("/api/v1/vortex/seen", json={"keys": "x"}, headers=h).status_code == 400
    assert client.post("/api/v1/vortex/seen", json={"keys": []}).status_code in (401, 403)


def test_api_vortex_grid_never_repeats_between_two_openings(app, db):
    client = app.test_client()
    u = mk_user(db, "ana")
    h = headers_for(db, u)
    for i in range(150):
        mk_item(db, "natureza" if i % 3 else "carros", tags=f"t{i}")
    a = client.get("/api/v1/vortex", headers=h).get_json()["tiles"]
    vt.clear_caches()
    b = client.get("/api/v1/vortex", headers=h).get_json()["tiles"]
    ka, kb = {t["key"] for t in a}, {t["key"] for t in b}
    assert ka and kb and not (ka & kb)


def test_web_seen_endpoint_requires_login(app, db):
    assert app.test_client().post("/api/pictures/seen", json={"keys": ["c1"]}).status_code == 401


def test_web_seen_endpoint_records(app, db):
    client = app.test_client()
    u = mk_user(db, "ana")
    with client.session_transaction() as sess:
        sess["_user_id"] = str(u.id)
        sess["_fresh"] = True
    it = mk_item(db, "natureza")
    r = client.post("/api/pictures/seen", json={"keys": [f"c{it.id}"]})
    assert r.status_code == 200 and r.get_json()["recorded"] == 1
    assert client.post("/api/pictures/seen", json={"keys": "x"}).status_code == 400


def test_tile_templates_carry_the_ledger_key(app, db):
    from flask import render_template
    it = mk_item(db, "natureza")
    with app.test_request_context():
        html = render_template("_picture_tile.html",
                               tile={"kind": "crawler", "item": it, "key": f"c{it.id}"})
    assert f'data-vkey="c{it.id}"' in html


def test_prune_removes_only_old_rows(app, db):
    u = mk_user(db, "ana")
    old = utcnow() - timedelta(days=vs.PRUNE_AFTER_DAYS + 5)
    db.session.add(VortexSeen(user_id=u.id, key="c1", first_seen_at=old,
                              last_served_at=old, served_count=1))
    db.session.commit()
    vs.mark_served(u.id, ["c2"])
    vs.prune()
    assert [r.key for r in VortexSeen.query.all()] == ["c2"]
