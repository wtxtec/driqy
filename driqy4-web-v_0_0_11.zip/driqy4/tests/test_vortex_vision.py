"""Sugestões pelo conteúdo da imagem: assinatura de aparência, ranking do
"mais como este", preenchimento em segundo plano e encanamento do CLIP
(com um codificador de mentira: o modelo real não roda nos testes)."""
import io
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
import pytest
from PIL import Image
from sqlalchemy import text

import vortex_crawler as vc
import vortex_search as vsearch
import vortex_vision as vv
from models import VortexItem, VortexProfile

KINDS = ["sea", "forest", "sunset", "night", "bw", "snow"]


def scene(kind, seed, size=120):
    r = random.Random(seed)
    img = Image.new("RGB", (size, size))
    px = img.load()
    base = [r.uniform(-12, 12) for _ in range(3)]

    def j(a):
        return max(0, min(255, int(a + r.uniform(-18, 18))))

    for y in range(size):
        t = y / size
        for x in range(size):
            if kind == "sea":
                c = (90 + base[0], 150 + base[1], 220 + base[2]) if t < 0.5 else (20 + base[0], 70 + base[1], 140 + base[2])
            elif kind == "forest":
                c = (30 + base[0] + r.uniform(-25, 25), 110 + base[1] + r.uniform(-40, 40), 40 + base[2] + r.uniform(-25, 25))
            elif kind == "sunset":
                c = (240 + base[0], 130 - 90 * t + base[1], 40 + base[2]) if t < 0.6 else (40 + base[0], 20 + base[1], 30 + base[2])
            elif kind == "night":
                c = (12, 14, 35) if r.random() > 0.004 else (250, 250, 200)
            elif kind == "bw":
                v = int(40 + 170 * t + base[0])
                c = (v, v, v)
            else:
                c = (235 + base[0] / 2, 240 + base[1] / 2, 248 + base[2] / 2)
            px[x, y] = tuple(j(v) for v in c)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=85)
    return buf.getvalue()


# ----------------------------------------------------------------- aparência
def test_describe_tags_and_roundtrip():
    sea = vv.describe_image(scene("sea", 1))
    assert len(sea["vec"]) == vv.FEAT_DIM and vv.vec_from_hex(sea["hex"]) == sea["vec"]
    assert {"azul", "ciano"} & set(sea["tags"]) and "tons frios" in sea["tags"]
    assert "verde" in vv.describe_image(scene("forest", 1))["tags"]
    assert "escuro" in vv.describe_image(scene("night", 1))["tags"]
    assert "preto e branco" in vv.describe_image(scene("bw", 1))["tags"]
    assert "preto e branco" not in vv.describe_image(scene("snow", 1))["tags"]
    assert vv.describe_image(b"isto nao e uma imagem") is None
    assert vv.vec_from_hex("") is None and vv.vec_from_hex("zz") is None


def test_same_scene_is_closer_than_other_scenes():
    d = {k: [vv.describe_image(scene(k, s))["vec"] for s in range(3)] for k in KINDS}
    same, diff = [], []
    for a in KINDS:
        for i in range(3):
            for b in KINDS:
                for j in range(3):
                    if (a, i) != (b, j):
                        (same if a == b else diff).append(vv.similarity(d[a][i], d[b][j]))
    assert min(same) > max(diff) + 0.15


# --------------------------------------------------- ranking pelo conteúdo
def _item(db, n, kind, tags, category="natureza", title=None, profile="commons", with_vision=True):
    prof = VortexProfile.query.filter_by(handle=profile).first()
    data = scene(kind, n)
    desc = vv.describe_image(data)
    it = VortexItem(
        profile_id=prof.id, media_type="photo", media_url=f"https://x.org/{kind}{n}.jpg",
        thumb_url=f"https://x.org/t/{kind}{n}.jpg", width=800, height=600,
        title=title or f"Foto {n}", tags=tags, category=category,
        url_hash=vc._hash_url(f"https://x.org/{kind}{n}.jpg"),
        vfeat=desc["hex"] if with_vision else None,
        visual_tags=",".join(desc["tags"]) if with_vision else None,
    )
    db.session.add(it)
    db.session.commit()
    return it


def test_related_follows_the_image_not_the_source_text(app, db):
    # a fonte descreveu TUDO igual (mesma categoria, mesmas tags, mesmo título):
    # só a imagem diferencia. Antes, a ordem seria arbitrária (id desc).
    base = _item(db, 0, "sea", "paisagem,viagem", title="Paisagem bonita")
    forests = [_item(db, 10 + i, "forest", "paisagem,viagem", title="Paisagem bonita") for i in range(4)]
    seas = [_item(db, 20 + i, "sea", "paisagem,viagem", title="Paisagem bonita") for i in range(3)]
    result = vsearch.related_items(app, base)
    top3 = [i.id for i in result["items"][:3]]
    assert set(top3) == {s.id for s in seas}, "as 3 imagens parecidas deveriam vir primeiro"
    assert {i.id for i in result["items"][3:]} == {f.id for f in forests}


def test_related_image_beats_misleading_tags(app, db):
    # tags iguais mas imagem diferente (floresta com tags do mar) x imagem
    # parecida com tags diferentes: a imagem parecida deve ganhar
    base = _item(db, 0, "sea", "mar,praia", title="Mar azul")
    decoy = _item(db, 1, "forest", "mar,praia", title="Mar azul")
    real = _item(db, 2, "sea", "oceano", category="viagens", title="Ondas")
    ids = [i.id for i in vsearch.related_items(app, base)["items"]]
    assert ids.index(real.id) < ids.index(decoy.id)


def test_related_without_vision_keeps_text_behaviour(app, db):
    base = _item(db, 0, "sea", "a,b", with_vision=False)
    other = _item(db, 1, "forest", "a,b", with_vision=False)
    assert [i.id for i in vsearch.related_items(app, base)["items"]] == [other.id]


def test_detail_exposes_visual_tags(app, db, user_token):
    _, headers = user_token
    it = _item(db, 0, "sea", "mar")
    resp = app.test_client().get(f"/api/v1/vortex/item/{it.id}?related=0", headers=headers)
    assert {"azul", "ciano"} & set(resp.get_json()["item"]["visual_tags"])


# ------------------------------------------------ preenchimento em 2º plano
class _SceneHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        parts = self.path.strip("/").split("/")
        if parts[0] == "img":
            body, code = scene(parts[1], int(parts[2].split(".")[0])), 200
            ctype = "image/jpeg"
        else:
            body, code, ctype = b"", 404, "text/plain"
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


@pytest.fixture()
def scene_server(app, db, monkeypatch):
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    server = ThreadingHTTPServer(("127.0.0.1", 0), _SceneHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    app.config.update(VORTEX_VISION_BATCH=10, VORTEX_VISION_IDLE_SECONDS=0.2, VORTEX_VISION_WORKERS=4,
                      VORTEX_HOST_INTERVALS={}, VORTEX_ALLOW_PRIVATE_HOSTS=True,
                      VORTEX_DISCOVERY_ENABLED=False)
    from models import VortexCrawlSource
    VortexCrawlSource.query.update({"enabled": False})
    db.session.commit()
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()


def _legacy_item(db, base_url, n, path, category="outros", tags=""):
    prof = VortexProfile.query.filter_by(handle="commons").first()
    it = VortexItem(profile_id=prof.id, media_type="photo", media_url=f"{base_url}{path}",
                    thumb_url=f"{base_url}{path}", width=800, height=600, title=f"Antigo {n}",
                    tags=tags, category=category, url_hash=vc._hash_url(f"{base_url}{path}{n}"))
    db.session.add(it)
    db.session.commit()
    return it


def _wait(predicate, timeout=20):
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if predicate():
            return True
        time.sleep(0.2)
    return False


def _pending(db):
    with db.engine.connect() as conn:
        return conn.execute(text("SELECT COUNT(*) FROM vortex_items WHERE vfeat IS NULL")).scalar()


def test_backfill_analyses_old_items_and_marks_unreadable(app, db, scene_server):
    good = [_legacy_item(db, scene_server, n, f"/img/{k}/{n}.jpg")
            for n, k in enumerate(["sea", "forest", "sunset", "night"] * 3)]
    bad = _legacy_item(db, scene_server, 99, "/nao-existe.jpg")
    engine = vc.IngestEngine(app, db).start(0)
    try:
        assert _wait(lambda: _pending(db) == 0), "backfill não terminou"
        stats = engine.stats()
    finally:
        engine.stop()
    db.session.expire_all()
    assert all(vv.vec_from_hex(db.session.get(VortexItem, g.id).vfeat) for g in good)
    assert db.session.get(VortexItem, bad.id).vfeat == ""            # não tenta de novo
    first_tags = db.session.get(VortexItem, good[0].id).visual_tags
    assert "azul" in first_tags or "ciano" in first_tags
    assert stats["vision_done"] >= len(good) and stats["vision_failed"] >= 1


# ------------------------------------------------------------------- CLIP
CONCEPTS = [("ocean waves", "ondas do mar", "natureza"), ("a forest", "floresta", "natureza"),
            ("a dog", "cachorro", "animais")]


class StubEncoder:
    """Finge um CLIP: a 'semântica' vem da cor dominante da imagem."""

    def encode_texts(self, texts):
        return np.eye(len(texts), dtype=np.float32)

    def encode_images(self, images):
        out = []
        for img in images:
            r, g, b = np.asarray(img.resize((8, 8))).reshape(-1, 3).mean(axis=0)
            v = np.array([b, g, 1.0], dtype=np.float32)   # mar ~ azul, floresta ~ verde, resto: cachorro
            if b > g and b > r:
                v = np.array([1.0, 0.05, 0.05], dtype=np.float32)
            elif g > r and g > b:
                v = np.array([0.05, 1.0, 0.05], dtype=np.float32)
            else:
                v = np.array([0.05, 0.05, 1.0], dtype=np.float32)
            out.append(v / np.linalg.norm(v))
        return np.stack(out)


def test_clip_pack_roundtrip_and_concepts():
    clip = vv.ClipVision(StubEncoder(), CONCEPTS)
    vec = np.array([0.9, 0.1, 0.1], dtype=np.float32)
    vec /= np.linalg.norm(vec)
    assert np.allclose(vv.clip_unpack(vv.clip_pack(vec)), vec, atol=1e-3)
    best = clip.concepts_for(vec, top=2)
    assert best[0][0] == "ondas do mar" and best[0][2] > 0.9 and len(best) == 2
    assert vv.build_clip({"VORTEX_CLIP_MODEL": ""}) is None          # desligado por padrão
    assert vv.build_clip({"VORTEX_CLIP_MODEL": "modelo-inexistente",
                          "VORTEX_VISUAL_CONCEPTS": CONCEPTS}) is None   # sem sentence-transformers


def test_clip_tags_category_and_semantic_related(app, db, scene_server, monkeypatch):
    monkeypatch.setattr(vv, "build_clip", lambda cfg: vv.ClipVision(StubEncoder(), CONCEPTS))
    app.config.update(VORTEX_CLIP_MODEL="stub")
    seas = [_legacy_item(db, scene_server, n, f"/img/sea/{n}.jpg", tags="a") for n in range(3)]
    forest = _legacy_item(db, scene_server, 7, "/img/forest/7.jpg", tags="a")
    engine = vc.IngestEngine(app, db).start(0)
    try:
        def done():
            db.session.expire_all()
            return all(db.session.get(VortexItem, i.id).clip_vec for i in seas + [forest])
        assert _wait(done), "CLIP não preencheu os itens"
        assert engine.stats()["clip_enabled"] is True
    finally:
        engine.stop()
    db.session.expire_all()
    sea0 = db.session.get(VortexItem, seas[0].id)
    assert sea0.visual_tags.startswith("ondas do mar")               # conceito primeiro, aparência depois
    assert "ondas do mar" in sea0.tag_list                           # entra na busca
    assert sea0.category == "natureza"                               # "outros" reclassificado
    ids = [i.id for i in vsearch.related_items(app, sea0)["items"]]
    assert set(ids[:2]) == {seas[1].id, seas[2].id} and ids[2] == forest.id


# --------------------------------------------------------------- migração
def test_old_database_gets_vision_columns(app, db):
    from sqlalchemy import inspect
    from app import _ensure_schema_upgrades
    with db.engine.begin() as conn:
        conn.execute(text("DROP INDEX IF EXISTS ix_vortex_items_vision_pending"))
        for col in ("vfeat", "visual_tags", "clip_vec", "vision_version"):
            conn.execute(text(f"ALTER TABLE vortex_items DROP COLUMN {col}"))
    _ensure_schema_upgrades(db)
    _ensure_schema_upgrades(db)                                       # idempotente
    cols = {c["name"] for c in inspect(db.engine).get_columns("vortex_items")}
    assert {"vfeat", "visual_tags", "clip_vec", "vision_version"} <= cols
