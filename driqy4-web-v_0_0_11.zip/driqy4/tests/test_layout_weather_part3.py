"""Layout Parte 3: widget de clima no painel direito + menu para pular entre widgets."""
import pathlib

JS = pathlib.Path("static/js/rail.js").read_text(encoding="utf-8")
WX = pathlib.Path("static/js/rail-weather.js").read_text(encoding="utf-8")


def test_rail_switcher_has_menu_arrows_and_stale_guard():
    for needle in ("rail-widget-menu-btn", "isActive", "rail-widget-menu-item", "DriqyRail", "Escape"):
        assert needle in JS


def test_weather_widget_states_and_endpoint():
    for needle in ("no_location", "not_found", "unavailable", "disabled", "Tentar de novo",
                   "weather-url", "edit-profile-url", "O clima hoje"):
        assert needle in WX
    # texto vindo do servidor só entra via textContent: innerHTML só limpa ("") ou monta o <svg> fixo
    import re
    uses = re.findall(r"innerHTML\s*=\s*([^;\n]{0,20})", WX)
    assert all(u.strip().startswith(('""', "'<svg")) for u in uses), uses


def test_feed_has_weather_urls_and_scripts(app):
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User(username="ana", email="ana@example.com", location="Guarapari - ES")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": "ana", "password": "senha1234"})
    html = c.get("/").get_data(as_text=True)
    assert 'data-weather-url="/api/v1/widgets/weather"' in html
    assert 'data-edit-profile-url="' in html
    assert html.index("js/rail.js") < html.index("js/rail-weather.js")
    assert "rail-widget-menu-btn" in html


def test_places_search_and_region_picker_assets():
    """Sugestões de cidade (perfil + widget): rota, script do seletor e troca de região no clima."""
    pp = pathlib.Path("static/js/place-picker.js").read_text(encoding="utf-8")
    api = pathlib.Path("api_widgets.py").read_text(encoding="utf-8")
    assert "/places/search" in api and "DriqyPlacePicker" in pp
    for needle in ("driqy-weather-region", "Alterar região", "places-url", "lat="):
        assert needle in WX
    assert "innerHTML" not in pp.replace('list.innerHTML = ""', "")


def test_apply_profile_location_keeps_or_drops_coords():
    from types import SimpleNamespace
    from widgets_weather import apply_profile_location, parse_coords
    u = SimpleNamespace(location="Gramado, Rio Grande do Sul, Brasil", location_lat=-29.37, location_lng=-50.87)
    apply_profile_location(u, "Gramado, Rio Grande do Sul, Brasil", None, None)  # texto igual: mantém
    assert u.location_lat == -29.37
    apply_profile_location(u, "Outra coisa", None, None)  # digitado à mão: descarta
    assert u.location_lat is None and u.location_lng is None
    apply_profile_location(u, "Vitória, Espírito Santo, Brasil", "-20.31", "-40.31")
    assert (u.location_lat, u.location_lng) == (-20.31, -40.31)
    assert parse_coords("999", "0") is None and parse_coords("x", "1") is None


def test_rail_customization_assets_and_prefs_normalization():
    """Personalizar painel: JS, rotas de preferências e normalização (ids inválidos, ordem completa)."""
    cz = pathlib.Path("static/js/rail-customize.js").read_text(encoding="utf-8")
    api = pathlib.Path("api_widgets.py").read_text(encoding="utf-8")
    for needle in ("Personalizar painel", "rail_hidden", "suggest_first", "X-Requested-With"):
        assert needle in cz
    assert "/widgets/prefs" in api
    from api_widgets import normalize_prefs
    p = normalize_prefs('{"order":["news","x","news"],"disabled":["weather","zz"],"suggest":false,"rail_hidden":1}')
    assert p["order"][0] == "news" and set(p["order"]) >= {"weather", "trending", "news", "vortex", "online"} and len(p["order"]) == 16
    assert p["disabled"] == ["weather"] and p["suggest"] is False and p["rail_hidden"] is True
    assert normalize_prefs("lixo")["suggest"] is True
