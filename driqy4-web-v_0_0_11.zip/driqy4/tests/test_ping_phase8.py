"""Ping — fase 8: telas Contatos e Configurações dentro do Ping (site + API usada pelo Flutter)."""
import pathlib

import pytest


@pytest.fixture()
def world(app):
    from extensions import db as _db
    from models import Follow, User
    with app.app_context():
        ids = {}
        for name in ("ana", "beto", "caio", "dora", "eva"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            ids[name] = u.id
        eva = _db.session.get(User, ids["eva"])
        eva.is_banned = True
        for a, b in (("ana", "beto"), ("ana", "caio"), ("ana", "eva"), ("dora", "ana")):
            _db.session.add(Follow(follower_id=ids[a], followed_id=ids[b]))
        _db.session.commit()
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(ids["ana"])
    return c


def test_contacts_lists_following_without_banned(world):
    html = world.get("/mensagens/contatos").get_data(as_text=True)
    assert 'data-username="beto"' in html and 'data-username="caio"' in html
    assert 'data-username="eva"' not in html and 'data-username="dora"' not in html
    assert 'href="/mensagens/beto"' in html            # abre a conversa
    assert 'href="/u/beto"' in html                    # perfil continua a um toque


def test_contacts_followers_tab(world):
    html = world.get("/mensagens/contatos?aba=seguidores").get_data(as_text=True)
    assert 'data-username="dora"' in html and 'data-username="beto"' not in html


def test_contacts_and_settings_are_ping_pages_without_driqy_chrome(world):
    for url in ("/mensagens/contatos",):
        html = world.get(url).get_data(as_text=True)
        assert "ping-tabpage" in html and 'id="ping-tabbar"' in html, url
        assert "bottom-nav" not in html and 'id="search-form"' not in html, url
        assert 'id="chat-inbox-list"' in html, url      # lista de conversas segue ao lado no desktop


def test_active_tab_per_page(world):
    def active(url):
        html = world.get(url).get_data(as_text=True)
        return [seg.split('ping-tab-label">')[1].split("<")[0]
                for seg in html.split('<a class="ping-tab')[1:] if seg.startswith(" is-active")]
    assert active("/mensagens/") == ["Chats"]
    assert active("/mensagens/beto") == ["Chats"]
    assert active("/mensagens/contatos") == ["Contatos"]
    assert active("/mensagens/chamadas") == ["Chamadas"]
    # fase 10: o atributo saía escapado (&#34;) pelo Jinja — tem que ser HTML válido
    html = world.get("/mensagens/contatos").get_data(as_text=True)
    assert '&#34;' not in html.split('id="ping-tabbar"')[1].split("</nav>")[0]
    assert html.split('id="ping-tabbar"')[1].split("</nav>")[0].count('aria-current="page"') == 1


def test_old_settings_url_redirects_and_options_live_in_drawer(world):
    r = world.get("/mensagens/configuracoes")
    assert r.status_code == 302 and r.headers["Location"].endswith("/mensagens/#configuracoes")
    html = world.get("/mensagens/").get_data(as_text=True)
    assert 'id="chat-privacy-toggle"' in html and "/api/v1/messages/privacy" in html
    assert 'class="theme-option"' in html and 'id="setting-sound"' in html
    assert html.count('id="chat-privacy-toggle"') == 1


def test_routes_do_not_shadow_usernames_and_are_reserved(world):
    from auth import RESERVED_USERNAMES
    assert {"contatos", "configuracoes"} <= RESERVED_USERNAMES


def test_requires_login(app):
    c = app.test_client()
    for url in ("/mensagens/contatos", "/mensagens/configuracoes"):
        assert c.get(url).status_code in (301, 302, 401)


def test_api_contacts(world, app):
    from extensions import db as _db
    from models import User
    with app.app_context():
        ana = User.query.filter_by(username="ana").first()
    tok = _login_token(world, app)
    h = {"Authorization": f"Bearer {tok}"}
    c = app.test_client()
    d = c.get("/api/v1/contacts", headers=h).get_json()
    assert [u["username"] for u in d["users"]] == ["beto", "caio"]
    assert d["counts"] == {"following": 3, "followers": 1} and d["has_next"] is False
    d = c.get("/api/v1/contacts?tab=followers", headers=h).get_json()
    assert [u["username"] for u in d["users"]] == ["dora"]
    d = c.get("/api/v1/contacts?q=ca", headers=h).get_json()
    assert [u["username"] for u in d["users"]] == ["caio"]
    assert c.get("/api/v1/contacts").status_code == 401


def _login_token(client, app):
    r = app.test_client().post("/api/v1/auth/login", json={"identifier": "ana", "username": "ana", "password": "senha1234"})
    assert r.status_code == 200, r.get_data(as_text=True)
    j = r.get_json()
    return j.get("token") or j.get("access_token")


def test_assets_and_sw_bumped():
    js = pathlib.Path("static/js/ping-pages.js").read_text(encoding="utf-8")
    assert "document.addEventListener" not in js and "window.addEventListener" not in js
    css = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
    assert "body.ping-tabpage .ping-tabbar" in css and "fase 8" in css
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 57  # versão do cache do SW só pode subir
