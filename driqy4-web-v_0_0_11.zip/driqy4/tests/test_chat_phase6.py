"""Chat rico — Fase 6: vídeo (assinatura, MIME, miniatura, Range, página web)."""
import io

import pytest

MP4 = b"\x00\x00\x00\x20ftypisom" + b"\x00" * 64
MOV = b"\x00\x00\x00\x14ftypqt  " + b"\x00" * 64
WEBM = b"\x1a\x45\xdf\xa3" + b"\x00" * 64
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 200


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _send(c, headers, data, name, mimetype=None, thumb=None, **form):
    payload = {"file": (io.BytesIO(data), name, mimetype) if mimetype else (io.BytesIO(data), name)}
    if thumb is not None:
        payload["thumb"] = (io.BytesIO(thumb), "t.jpg", "image/jpeg")
    return c.post("/api/v1/messages/beto", headers=headers,
                  data={**payload, **form}, content_type="multipart/form-data")


@pytest.mark.parametrize("data,name,mt,mime", [
    (MP4, "v.mp4", "video/mp4", "video/mp4"),
    (MOV, "v.mov", "video/quicktime", "video/quicktime"),
    (WEBM, "v.webm", "video/webm", "video/webm"),
])
def test_video_mime_from_signature(app, users, data, name, mt, mime):
    r = _send(app.test_client(), users[0], data, name, mt,
              duration_ms="8000", width="1280", height="720")
    assert r.status_code == 200
    j = r.get_json()
    assert j["msg_type"] == "video"
    assert j["media_mime"] == mime
    assert j["media_duration_ms"] == 8000
    assert (j["media_width"], j["media_height"]) == (1280, 720)
    assert j["media_thumb_url"] is None


def test_fake_video_rejected(app, users):
    r = _send(app.test_client(), users[0], b"isso nao e video" * 8, "v.mp4", "video/mp4")
    assert r.status_code == 400


def test_video_too_big(app, users):
    app.config["CHAT_MAX_VIDEO_BYTES"] = 1024
    r = _send(app.test_client(), users[0], MP4 + b"\x00" * 2000, "v.mp4", "video/mp4")
    assert r.status_code == 413


def test_thumb_saved_and_private(app, users):
    c = app.test_client()
    r = _send(c, users[0], MP4, "v.mp4", "video/mp4", thumb=JPEG)
    j = r.get_json()
    assert j["media_thumb_url"].endswith(f"/messages/media/{j['id']}/thumb")
    ok = c.get(j["media_thumb_url"], headers=users[1])  # destinatário
    assert ok.status_code == 200 and ok.mimetype == "image/jpeg"
    assert c.get(j["media_thumb_url"], headers=users[2]).status_code == 404  # estranho
    assert c.get(j["media_thumb_url"]).status_code == 401


def test_bad_thumb_ignored(app, users):
    r = _send(app.test_client(), users[0], MP4, "v.mp4", "video/mp4",
              thumb=b"nao sou imagem")
    assert r.status_code == 200
    assert r.get_json()["media_thumb_url"] is None


def test_video_range(app, users):
    c = app.test_client()
    j = _send(c, users[0], MP4, "v.mp4", "video/mp4").get_json()
    r = c.get(j["media_url"], headers={**users[1], "Range": "bytes=0-9"})
    assert r.status_code == 206
    assert r.headers["Content-Type"].startswith("video/mp4")


def test_thumb_of_non_video_404(app, users):
    c = app.test_client()
    j = c.post("/api/v1/messages/beto", headers=users[0], json={"content": "oi"}).get_json()
    assert c.get(f"/api/v1/messages/media/{j['id']}/thumb", headers=users[1]).status_code == 404


def test_inbox_preview_video(app, users):
    c = app.test_client()
    _send(c, users[0], MP4, "v.mp4", "video/mp4")
    r = c.get("/api/v1/messages", headers=users[1])
    assert r.status_code == 200
    assert "🎥" in r.get_json()["conversations"][0]["last_message"]["content"]


def test_web_thread_page_accepts_video(app, users):
    from extensions import db as _db
    from models import User
    c = app.test_client()
    with app.app_context():
        uid = User.query.filter_by(username="ana").first().id
    with c.session_transaction() as sess:
        sess["_user_id"] = str(uid)
        sess["_fresh"] = True
    html = c.get("/mensagens/beto").get_data(as_text=True)
    assert "video/mp4" in html and 'id="cw-preview-video"' in html
