"""Chat rico — Fase 3: reações às mensagens."""
import pytest


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _msg(c, h, to="beto"):
    return c.post(f"/api/v1/messages/{to}", headers=h, json={"content": "oi"}).get_json()["id"]


def test_react_and_summary(app, users):
    c = app.test_client()
    mid = _msg(c, users[0])
    r = c.put(f"/api/v1/messages/{mid}/reaction", headers=users[1], json={"emoji": "👍"})
    assert r.status_code == 200
    assert r.get_json()["reactions"] == [{"emoji": "👍", "count": 1, "mine": True}]
    # a outra pessoa vê mine=False
    msgs = c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"]
    assert msgs[0]["reactions"] == [{"emoji": "👍", "count": 1, "mine": False}]


def test_react_again_replaces(app, users):
    c = app.test_client()
    mid = _msg(c, users[0])
    c.put(f"/api/v1/messages/{mid}/reaction", headers=users[1], json={"emoji": "👍"})
    r = c.put(f"/api/v1/messages/{mid}/reaction", headers=users[1], json={"emoji": "❤️"})
    assert r.get_json()["reactions"] == [{"emoji": "❤️", "count": 1, "mine": True}]


def test_both_react_counts(app, users):
    c = app.test_client()
    mid = _msg(c, users[0])
    c.put(f"/api/v1/messages/{mid}/reaction", headers=users[1], json={"emoji": "😂"})
    r = c.put(f"/api/v1/messages/{mid}/reaction", headers=users[0], json={"emoji": "😂"})
    assert r.get_json()["reactions"] == [{"emoji": "😂", "count": 2, "mine": True}]


def test_remove_reaction(app, users):
    c = app.test_client()
    mid = _msg(c, users[0])
    c.put(f"/api/v1/messages/{mid}/reaction", headers=users[1], json={"emoji": "👍"})
    r = c.delete(f"/api/v1/messages/{mid}/reaction", headers=users[1])
    assert r.status_code == 200 and r.get_json()["reactions"] == []


def test_invalid_emoji_rejected(app, users):
    c = app.test_client()
    mid = _msg(c, users[0])
    for bad in ("", "a", "oi", "1", " ", "x" * 20, None):
        r = c.put(f"/api/v1/messages/{mid}/reaction", headers=users[1], json={"emoji": bad})
        assert r.status_code == 400, bad


def test_outsider_cannot_react_or_unreact(app, users):
    c = app.test_client()
    mid = _msg(c, users[0])
    assert c.put(f"/api/v1/messages/{mid}/reaction", headers=users[2], json={"emoji": "👍"}).status_code == 404
    assert c.delete(f"/api/v1/messages/{mid}/reaction", headers=users[2]).status_code == 404


def test_requires_login_and_missing_message(app, users):
    c = app.test_client()
    assert c.put("/api/v1/messages/1/reaction", json={"emoji": "👍"}).status_code == 401
    assert c.put("/api/v1/messages/999/reaction", headers=users[1], json={"emoji": "👍"}).status_code == 404


def test_send_response_has_empty_reactions(app, users):
    c = app.test_client()
    j = c.post("/api/v1/messages/beto", headers=users[0], json={"content": "x"}).get_json()
    assert j["reactions"] == []


def test_deleted_message_cannot_be_reacted(app, users):
    from extensions import db as _db
    from models import Message, utcnow
    c = app.test_client()
    mid = _msg(c, users[0])
    with app.app_context():
        m = _db.session.get(Message, mid)
        m.deleted_at = utcnow()
        _db.session.commit()
    assert c.put(f"/api/v1/messages/{mid}/reaction", headers=users[1], json={"emoji": "👍"}).status_code == 404
