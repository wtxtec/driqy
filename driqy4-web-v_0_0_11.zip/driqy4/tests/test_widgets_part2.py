"""Layout Parte 2: API de widgets (clima) e sugestões de seguir."""
from datetime import timedelta

import pytest


class _Resp:
    def __init__(self, data):
        self._d = data

    def raise_for_status(self):
        pass

    def json(self):
        return self._d


FORECAST = {
    "current": {"temperature_2m": 27.6, "apparent_temperature": 30.2, "relative_humidity_2m": 70,
                "weather_code": 0, "wind_speed_10m": 12.4, "is_day": 1},
    "daily": {"temperature_2m_max": [31.1], "temperature_2m_min": [22.4], "precipitation_probability_max": [20]},
}


@pytest.fixture()
def world(app):
    from extensions import db as _db
    from models import ApiToken, Follow, User, utcnow
    with app.app_context():
        users = {}
        for name, loc in (("ana", "Guarapari - ES"), ("beto", "Guarapari - ES"), ("caio", "Cidade Fantasma"),
                          ("dani", ""), ("edu", "Curitiba")):
            u = User(username=name, email=f"{name}@example.com", location=loc, last_seen_at=utcnow())
            u.set_password("senha1234")
            _db.session.add(u)
            users[name] = u
        _db.session.commit()
        ids = {k: v.id for k, v in users.items()}
        tok = ApiToken.generate_for(users["ana"])
        _db.session.commit()
        # ana segue edu; edu segue beto (beto: 1 conta em comum); dani segue ana (seguir de volta)
        _db.session.add_all([Follow(follower_id=ids["ana"], followed_id=ids["edu"]),
                             Follow(follower_id=ids["edu"], followed_id=ids["beto"]),
                             Follow(follower_id=ids["dani"], followed_id=ids["ana"])])
        _db.session.commit()
        return {"h": {"Authorization": f"Bearer {tok.token}"}, "ids": ids}


def test_requires_login(app):
    c = app.test_client()
    for path in ("/api/v1/widgets", "/api/v1/widgets/weather", "/api/v1/widgets/suggestions"):
        assert c.get(path).status_code == 401


def test_widgets_list(app, world):
    r = app.test_client().get("/api/v1/widgets", headers=world["h"]).get_json()
    assert r["widgets"][0]["id"] == "weather" and r["widgets"][0]["title"] == "Clima"


def test_weather_ok_and_cached(app, world, monkeypatch):
    import widgets_weather as w
    w._WX_CACHE._store.clear()
    calls = []

    def fake_get(url, params=None, timeout=None):
        calls.append(url)
        return _Resp(FORECAST)

    monkeypatch.setattr(w.requests, "get", fake_get)
    c = app.test_client()
    r = c.get("/api/v1/widgets/weather", headers=world["h"]).get_json()
    assert r["ok"] is True and r["location"] == "Guarapari, ES"
    assert r["temperature"] == 28 and r["condition"] == "Ensolarado" and r["icon"] == "sun"
    assert (r["temp_min"], r["temp_max"], r["rain_chance"]) == (22, 31, 20)
    c.get("/api/v1/widgets/weather", headers=world["h"])
    assert len(calls) == 1  # segunda chamada veio do cache


def test_weather_reasons(app, world, monkeypatch):
    import widgets_weather as w
    from extensions import db as _db
    from models import User

    def boom(*a, **k):
        raise RuntimeError("sem rede")

    monkeypatch.setattr(w.requests, "get", boom)
    with app.app_context():
        u = _db.session.get(User, world["ids"]["ana"])
        u.location = ""
        _db.session.commit()
        assert w.weather_for_user(u) == {"ok": False, "reason": "no_location"}
        u.location = "Cidade Fantasma"  # fora da lista local + geocodificação falha
        w._GEO_CACHE._store.clear()
        assert w.weather_for_user(u)["reason"] == "not_found"
        u.location = "Vitória, ES"      # na lista local, mas a previsão falha
        w._WX_CACHE._store.clear()
        assert w.weather_for_user(u)["reason"] == "unavailable"


def test_geocoding_fallback_and_negative_cache(monkeypatch):
    import widgets_weather as w
    w._GEO_CACHE._store.clear()
    n = {"c": 0}

    def fake_get(url, params=None, timeout=None):
        n["c"] += 1
        if "Nowhere" in params["name"]:
            return _Resp({})
        return _Resp({"results": [{"name": "Gramado", "admin1": "Rio Grande do Sul", "latitude": -29.37, "longitude": -50.87}]})

    monkeypatch.setattr(w.requests, "get", fake_get)
    assert w.resolve_coords("Gramado, RS")[2] == "Gramado, Rio Grande do Sul"
    assert w.resolve_coords("Gramado, RS")[2] == "Gramado, Rio Grande do Sul" and n["c"] == 1
    assert w.resolve_coords("Nowhere") is None and w.resolve_coords("Nowhere") is None and n["c"] == 2


def test_state_abbreviation_alone_does_not_pick_a_capital():
    from widgets_weather import _local_city
    assert _local_city("Gramado, RS") is None
    assert _local_city("Guarapari - ES")[2] == "Guarapari, ES"
    assert _local_city("sao paulo")[2] == "São Paulo, SP"


def test_wmo_night_labels():
    from widgets_weather import describe_code
    assert describe_code(0, False) == ("Céu limpo", "moon")
    assert describe_code(95, True)[1] == "storm"


def test_suggestions_rules_and_order(app, world):
    c = app.test_client()
    r = c.get("/api/v1/widgets/suggestions?limit=10", headers=world["h"]).get_json()["users"]
    names = [u["username"] for u in r]
    assert "ana" not in names and "edu" not in names  # nem você, nem quem já segue
    assert set(names) == {"beto", "caio", "dani"}
    by = {u["username"]: u for u in r}
    assert by["dani"]["reason"] == "Segue você" and by["dani"]["follows_you"] is True
    assert by["beto"]["mutuals"] == 1 and by["beto"]["reason"].startswith("Seguido por 1 conta ")
    # beto (conta em comum + mesma cidade) > dani (segue você) > caio (só atividade recente)
    assert names == ["beto", "dani", "caio"]
    assert by["dani"]["is_following"] is False


def test_suggestions_exclude_banned_and_limit(app, world):
    from extensions import db as _db
    from models import User
    with app.app_context():
        _db.session.get(User, world["ids"]["caio"]).is_banned = True
        _db.session.commit()
    c = app.test_client()
    r = c.get("/api/v1/widgets/suggestions?limit=1&exclude=dani", headers=world["h"]).get_json()["users"]
    assert [u["username"] for u in r] == ["beto"]


def test_suggestions_follow_flow_removes_candidate(app, world):
    c = app.test_client()
    assert c.post("/api/v1/users/dani/follow", headers=world["h"]).status_code == 200
    names = [u["username"] for u in c.get("/api/v1/widgets/suggestions", headers=world["h"]).get_json()["users"]]
    assert "dani" not in names
