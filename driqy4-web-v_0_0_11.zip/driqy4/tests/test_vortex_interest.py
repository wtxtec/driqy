"""Parte 5: interesse por conceito, mistura interesse/adjacente/descoberta,
limite de saturação por assunto e aviso de pausa."""
from datetime import timedelta

import pytest

import vortex_concepts as vcn
import vortex_taste as vt
from models import VortexInteraction, VortexItem, utcnow
from test_vortex_related_concepts import cmk
from test_vortex_search import get


@pytest.fixture(autouse=True)
def _clear():
    vt.clear_caches()
    yield
    vt.clear_caches()


def open_items(user_id, *items):
    for it in items:
        assert vt.record(user_id, "open", item=it)


def cand(db, item):
    return vt._item_cands([item.id])[0]


def test_record_copies_concepts_and_search_maps_words_to_concepts(app, db, user_token):
    uid, _ = user_token
    car = cmk(db, "Red car", ("carro", 1.0), "", "carros")
    open_items(uid, car)
    row = VortexInteraction.query.filter_by(user_id=uid, kind="open").first()
    assert vcn.decode(row.concepts)[0][0] == "carro"
    assert vt.record(uid, "search", query="motorcycle")
    srow = VortexInteraction.query.filter_by(user_id=uid, kind="search").first()
    assert "moto" in [c for c, _ in vcn.decode(srow.concepts)]


def test_profile_spreads_credit_to_ancestors(app, db, user_token):
    uid, _ = user_token
    open_items(uid, *[cmk(db, f"Car {i}", ("carro", 1.0), "", "carros") for i in range(4)])
    prof = vt.build_profile(uid)
    assert prof.own_concept["carro"] == 1.0
    assert prof.concept["carro"] == 1.0
    assert 0.55 < prof.concept["veiculo_rodas"] < 0.65 and prof.concept["veiculo"] < prof.concept["veiculo_rodas"]
    assert prof.top_concepts[0] == "carro"


def test_taste_orders_same_then_relative_then_domain_then_other(app, db, user_token):
    uid, _ = user_token
    open_items(uid, *[cmk(db, f"Car {i}", ("carro", 1.0), "", "outros") for i in range(6)])
    prof = vt.build_profile(uid)
    assert prof.confidence == 1.0
    mk = lambda t, c: cand(db, cmk(db, t, (c, 1.0), "", "natureza"))   # categoria sem afinidade
    s = {c: vt.taste_score(mk(c, c), prof) for c in ("carro", "moto", "aviao", "danca")}
    assert s["carro"] > s["moto"] > s["aviao"] > s["danca"]
    assert s["danca"] <= vt.W_TYPE + vt.W_SOURCE_C + 1e-9   # só tipo de mídia e perfil-robô contam


def test_adjacent_is_a_relative_the_user_never_clicked(app, db, user_token):
    uid, _ = user_token
    open_items(uid, *[cmk(db, f"Car {i}", ("carro", 1.0), "", "outros") for i in range(4)])
    prof = vt.build_profile(uid)
    new = lambda c: cand(db, cmk(db, c, (c, 1.0), "", "outros"))
    assert vt.adjacency(new("moto"), prof) >= 0.4
    assert vt.adjacency(new("carro"), prof) == 0.0     # já é interesse
    assert vt.adjacency(new("danca"), prof) == 0.0     # outro assunto
    assert vt.adjacency(new("gato"), prof) == 0.0
    # depois de clicar em moto ela deixa de ser "adjacente" e vira interesse
    open_items(uid, *[cmk(db, f"moto clicada {i}", ("moto", 1.0), "", "outros") for i in range(3)])
    prof = vt.build_profile(uid)
    assert vt.adjacency(new("moto"), prof) == 0.0


def test_assemble_places_adjacent_in_reserved_slot_and_not_in_discovery(app, db, user_token):
    uid, _ = user_token
    open_items(uid, *[cmk(db, f"Car {i}", ("carro", 1.0), "", "carros") for i in range(6)])
    prof = vt.build_profile(uid)
    cars = [cmk(db, f"Car x{i}", ("carro", 1.0), "", "carros") for i in range(20)]
    motos = [cmk(db, f"Moto x{i}", ("moto", 1.0), "", "carros") for i in range(6)]
    dances = [cmk(db, f"Dance x{i}", ("danca", 1.0), "", "natureza") for i in range(6)]
    cands = vt._item_cands([i.id for i in cars + motos + dances])
    now = utcnow()
    pop = {"c": {}, "max": 0.0}
    scored = sorted(((c, vt.score_cand(c, prof, now, 5, pop)) for c in cands), key=lambda x: -x[1])
    out = vt._assemble(scored, prof, now, 5, pop)
    kinds = {f"c{m.id}": "moto" for m in motos} | {f"c{d.id}": "danca" for d in dances}
    seq = [kinds.get(c.key, "carro") for c in out]
    # slot % 5 == 3  ->  índices 2, 7, 12: adjacente (moto)
    assert [seq[i] for i in (2, 7, 12)] == ["moto", "moto", "moto"]
    # slot % 5 == 0  ->  índices 4, 9, 14: descoberta (fora do gosto: dança, nunca moto)
    assert [seq[i] for i in (4, 9, 14)] == ["danca", "danca", "danca"]


def test_without_concepts_the_old_mix_is_unchanged(app, db, user_token):
    uid, _ = user_token
    prof = vt.build_profile(uid)
    assert prof.concept == {} and prof.top_concepts == []
    raw = cand(db, cmk(db, "sem pista", None, "", "outros"))
    assert vt.adjacency(raw, prof) == 0.0
    assert raw.cset == frozenset()


def test_cap_subject_limits_domain_in_every_window_and_yields_when_alone(app, db):
    mk = lambda i, d: vt.Cand(f"c{i}", "c", i, None, "photo", 1, frozenset(), None, domain=d)
    ranked = [mk(i, "veiculo") for i in range(30)] + [mk(100 + i, "animais") for i in range(30)]
    out = vt._cap_subject(ranked, window=12, limit=6)
    assert len(out) == 60 and {c.key for c in out} == {c.key for c in ranked}
    for i in range(len(out) - 11):
        assert sum(1 for c in out[i:i + 12] if c.domain == "veiculo") <= 6
    only = vt._cap_subject([mk(i, "veiculo") for i in range(15)])
    assert [c.key for c in only] == [f"c{i}" for i in range(15)]          # cede: não há outro assunto
    nodomain = vt._cap_subject([mk(i, None) for i in range(20)])
    assert len(nodomain) == 20


def test_rank_keys_end_to_end_respects_saturation(app, db, user_token):
    uid, _ = user_token
    open_items(uid, *[cmk(db, f"Car {i}", ("carro", 1.0), "", "outros") for i in range(6)])
    for i in range(40):
        cmk(db, f"Car y{i}", ("carro", 1.0), "", "outros")
    for i in range(30):
        cmk(db, f"Gato y{i}", ("gato", 1.0), "", "outros")
    keys, _ = vt.rank_keys(app, uid, seed=3, include_users=False)
    domains = {f"c{i.id}": vcn.root_of(vcn.decode(i.concepts)[0][0]) for i in VortexItem.query.all() if i.concepts}
    seq = [domains.get(k) for k in keys]
    last_other = max(i for i, d in enumerate(seq) if d != "veiculo")   # depois disso só sobrou carro: cede
    assert last_other > 12
    for i in range(0, last_other - 10):
        assert sum(1 for d in seq[i:i + 12] if d == "veiculo") <= 6


def test_wellbeing_measures_continuous_use_and_suggests_a_break(app, db, user_token):
    uid, _ = user_token
    now = utcnow()
    assert vt.wellbeing(uid, now, app)["suggest_break"] is False
    for m in range(0, 36, 3):        # atividade a cada 3 min por 33 min, terminando há 2 min
        db.session.add(VortexInteraction(user_id=uid, kind="open", weight=1.0, item_id=1,
                                         created_at=now - timedelta(minutes=35 - m)))
    db.session.commit()
    w = vt.wellbeing(uid, now, app)
    assert w["suggest_break"] and w["level"] == 1 and 30 <= w["minutes"] <= 35 and "pausa" in w["message"]
    assert vt.wellbeing(uid, now + timedelta(minutes=20), app)["minutes"] == 0     # silêncio > 10 min zera
    app.config["VORTEX_BREAK_AFTER_MINUTES"] = 0
    assert vt.wellbeing(uid, now, app)["suggest_break"] is False                   # desligado


def test_wellbeing_gap_cuts_the_session(app, db, user_token):
    uid, _ = user_token
    now = utcnow()
    for m in (60, 59, 58, 20, 18, 5, 2):       # blocos separados por silêncio > 10 min
        db.session.add(VortexInteraction(user_id=uid, kind="open", weight=1.0, item_id=1,
                                         created_at=now - timedelta(minutes=m)))
    db.session.commit()
    w = vt.wellbeing(uid, now, app)
    assert w["minutes"] <= 5 and not w["suggest_break"]


def test_api_vortex_returns_wellbeing_field(app, db, user_token):
    _, headers = user_token
    cmk(db, "Car", ("carro", 1.0), "", "carros")
    status, data = get(app.test_client(), headers, "/api/v1/vortex")
    assert status == 200 and data["wellbeing"] == {"minutes": 0, "level": 0, "suggest_break": False, "message": None}
