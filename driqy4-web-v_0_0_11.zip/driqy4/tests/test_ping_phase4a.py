"""Ping — fase 4a: ☰ + busca estilo Telegram + aviso dispensável (ids do chat.js preservados)."""
import pytest


@pytest.fixture()
def site(app):
    from extensions import db as _db
    from models import Message, User
    with app.app_context():
        ids = {}
        for name in ("ana", "beto"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            ids[name] = u.id
        _db.session.add(Message(sender_id=ids["beto"], recipient_id=ids["ana"], content="oi ana"))
        _db.session.commit()
    c = app.test_client()
    with c.session_transaction() as s:
        s["_user_id"] = str(ids["ana"])
    return c


def test_searchbar_menu_and_notice(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    for needle in ('id="ping-menu-btn"', 'id="ping-search"', 'id="ping-notice"',
                   'id="ping-notice-close"', 'id="ping-search-empty"'):
        assert needle in html, needle


def test_chat_js_ids_preserved_inside_menu(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    for needle in ('id="chat-archived-link"', 'id="chat-archived-count"', 'id="chat-calls-link"',
                   'id="chat-privacy-toggle"', 'id="chat-inbox-list"', "data-updates-url", "data-prefs-root"):
        assert needle in html, needle
    assert 'id="ping-drawer-wrap" hidden' in html  # menu lateral começa fechado


def test_archived_view_has_search_but_no_hamburger(site):
    html = site.get("/mensagens/?arquivadas=1").get_data(as_text=True)
    assert 'id="ping-search"' in html
    assert 'id="ping-menu-btn"' not in html and 'id="ping-notice"' not in html
    assert "Voltar às conversas" in html  # link "Voltar" fica visível


def test_present_in_thread_and_sw_bumped(site, app):
    html = site.get("/mensagens/beto").get_data(as_text=True)
    assert 'id="ping-search"' in html
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", open("static/sw.js", encoding="utf-8").read()).group(1)) >= 57  # versão do cache do SW só pode subir
