"""Mensagens (antigo Ping) — parte 1: renomear, sem caneta/avatar-configurações, menu lateral com as opções."""
import pathlib
import pytest
from test_ping_phase7 import site  # noqa: F401  (fixture: usuária 'ana' logada, conversa com 'beto')


def _read(p):
    return pathlib.Path(p).read_text(encoding="utf-8")


@pytest.mark.parametrize("url", ["/mensagens/", "/mensagens/beto", "/mensagens/chamadas", "/mensagens/contatos"])
def test_renamed_to_mensagens_no_visible_ping(site, url):
    html = site.get(url).get_data(as_text=True)
    assert 'class="ping-title">Mensagens<' in html and "<title>" in html
    assert "— Ping<" not in html and ">Ping<" not in html
    assert 'content="Mensagens"' in html


def test_driqy_nav_label_renamed(site):
    html = site.get("/").get_data(as_text=True)
    assert 'aria-label="Mensagens"' in html and 'aria-label="Ping"' not in html


def test_drawer_has_every_option_and_chat_js_ids(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    for needle in ('id="ping-drawer"', 'id="ping-new-open"', 'id="chat-calls-link"', 'id="chat-archived-link"',
                   'id="chat-archived-count"', 'id="chat-privacy-toggle"', 'id="setting-sound"', 'class="theme-option"',
                   'href="/mensagens/contatos"', "Editar perfil", "Sair da conta", 'id="ping-menu-btn"'):
        assert needle in html, needle
    assert 'class="ping-fab"' not in html and 'class="ping-me"' not in html


def test_drawer_is_outside_the_list_column(site):
    html = site.get("/mensagens/contatos").get_data(as_text=True)
    # no celular a coluna da lista some em Contatos/Chamadas: o menu tem que estar fora dela
    assert html.index('id="ping-drawer-wrap"') > html.index("</aside>")


def test_old_settings_template_and_dead_assets_gone():
    assert not pathlib.Path("templates/ping_settings.html").exists()
    css, js = _read("static/css/style.css"), _read("static/js/ping-shell.js")
    assert ".ping-fab {" not in css and ".ping-me {" not in css
    assert "ping-drawer" in css and "prefers-reduced-motion" in css
    assert "ping-new-open" in js and 'getElementById("ping-fab")' not in js
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", _read("static/sw.js")).group(1)) >= 57  # versão do cache do SW só pode subir
