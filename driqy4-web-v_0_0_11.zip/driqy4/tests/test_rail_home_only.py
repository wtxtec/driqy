"""O painel direito (widgets + sugestões) só existe na Home; nas outras páginas a coluna não existe."""
import pathlib

CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
BASE = pathlib.Path("templates/base.html").read_text(encoding="utf-8")
FEED = pathlib.Path("templates/feed.html").read_text(encoding="utf-8")


def test_css_usa_lista_branca_so_da_home():
    assert "body.home-page:not(.rail-off) .rail" in CSS
    assert "body.home-page:not(.rail-off) .site-shell" in CSS
    assert "body.home-page .settings-rail-section" in CSS
    # a lista negra antiga (que deixava o painel vazar para as outras páginas) acabou
    assert "body:not(.pictures-page):not(.news-page)" not in CSS


def test_feed_marca_a_home_e_base_so_desenha_o_painel_nela():
    assert "home-page" in FEED
    assert "_rail_home" in BASE and "_rail_scripts" in BASE


def _login(app):
    from extensions import db
    from models import User
    with app.app_context():
        u = User(username="homeonly", email="homeonly@example.com")
        u.set_password("senha1234")
        db.session.add(u)
        db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": "homeonly", "password": "senha1234"})
    return c


def test_painel_aparece_na_home_e_nao_em_outras_paginas(app):
    c = _login(app)
    home = c.get("/").get_data(as_text=True)
    assert 'id="rail"' in home and "js/rail.js" in home and "home-page" in home
    assert "Painel direito" in home  # Configurações: personalizar o painel

    for url in ("/notificacoes", "/u/homeonly", "/noticias/"):
        r = c.get(url)
        assert r.status_code == 200, url
        html = r.get_data(as_text=True)
        assert 'id="rail"' not in html, url
        assert "js/rail.js" not in html and "__railCfg" not in html, url
        assert "Painel direito" not in html, url


def test_pagina_widgets_do_celular_continua_com_o_painel(app):
    c = _login(app)
    html = c.get("/widgets").get_data(as_text=True)
    assert html.count('id="rail"') == 1 and "js/rail.js" in html and "widgets-page" in html
