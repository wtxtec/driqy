"""Parte 8: painel de saúde do Vortex (fila + recomendação)."""
import hashlib
from datetime import timedelta

import pytest

import vortex_health
from models import User, VortexFrontier, VortexInteraction, VortexSeen, utcnow


@pytest.fixture()
def admin_client(app, db):
    user = User(username="chefe", email="chefe@example.com", is_admin=True)
    user.set_password("senha1234")
    db.session.add(user)
    db.session.commit()
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["_fresh"] = True
    return client


def _user(db, n):
    u = User(username=f"u{n}", email=f"u{n}@example.com")
    u.set_password("senha1234")
    db.session.add(u)
    db.session.commit()
    return u.id


def _front(db, url, status="pending", done_hours=None):
    now = utcnow()
    db.session.add(VortexFrontier(
        url_hash=hashlib.sha256(url.encode()).hexdigest(), url=url, host="site.com", depth=0, status=status,
        created_at=now, done_at=(now - timedelta(hours=done_hours)) if done_hours is not None else None))


def test_empty_database_is_healthy(app, db):
    h = vortex_health.health(app)
    assert h["alerts"] == []
    assert h["queue"]["pending"] == 0 and h["queue"]["eta_hours"] is None
    assert h["reco"]["h24"]["less_rate"] is None and h["reco"]["seen"]["repeat_rate"] is None


def test_queue_rate_and_eta(app, db):
    for i in range(48):
        _front(db, f"https://site.com/done{i}", "done", done_hours=1)
    for i in range(10):
        _front(db, f"https://site.com/p{i}")
    db.session.commit()
    q = vortex_health.health(app)["queue"]
    assert q["pending"] == 10 and q["done_24h"] == 48 and q["rate_per_hour"] == 2.0
    assert q["eta_hours"] == 5.0


def test_pending_without_progress_raises_alert(app, db):
    _front(db, "https://site.com/x")
    db.session.commit()
    assert any("nenhuma foi visitada" in a for a in vortex_health.health(app)["alerts"])


def test_less_rate_alert_needs_enough_signals(app, db):
    uid = _user(db, 1)
    for i in range(5):   # poucos sinais: não alerta
        db.session.add(VortexInteraction(user_id=uid, kind="less", weight=-1.5, item_id=i))
    db.session.commit()
    assert not any("menos disso" in a for a in vortex_health.health(app)["alerts"])
    for i in range(30):
        db.session.add(VortexInteraction(user_id=uid, kind="open", weight=1.0, item_id=100 + i))
    for i in range(10):
        db.session.add(VortexInteraction(user_id=uid, kind="less", weight=-1.5, item_id=200 + i))
    db.session.commit()
    h = vortex_health.health(app)
    assert h["reco"]["h24"]["kinds"]["less"] == 15 and h["reco"]["h24"]["users"] == 1
    assert any("menos disso" in a for a in h["alerts"])


def test_seen_repeat_rate(app, db):
    uid = _user(db, 2)
    for i in range(300):
        db.session.add(VortexSeen(user_id=uid, key=f"c{i}", served_count=2 if i < 120 else 1,
                                  viewed_count=1, rejected=(i < 3)))
    db.session.commit()
    s = vortex_health.health(app)
    assert s["reco"]["seen"]["rejected"] == 3 and s["reco"]["seen"]["repeat_rate"] == 0.4
    assert any("repetição alta" in a for a in s["alerts"])


def test_pages_render_and_are_admin_only(app, db, admin_client):
    page = admin_client.get("/admin/vortex/saude")
    assert page.status_code == 200 and "Fila de indexação" in page.get_data(as_text=True)
    assert "Vortex (saúde)" in page.get_data(as_text=True)
    data = admin_client.get("/admin/vortex/saude.json").get_json()
    assert set(data) >= {"queue", "reco", "concepts", "alerts"}


def test_common_user_is_refused(app, db):
    uid = _user(db, 3)
    c = app.test_client()
    with c.session_transaction() as sess:
        sess["_user_id"] = str(uid)
        sess["_fresh"] = True
    assert c.get("/admin/vortex/saude").status_code == 403
    assert c.get("/admin/vortex/saude.json").status_code == 403


def test_anonymous_is_redirected(app, db):
    anon = app.test_client()
    assert anon.get("/admin/vortex/saude").status_code in (302, 401)
    assert anon.get("/admin/vortex/saude.json").status_code in (302, 401)
