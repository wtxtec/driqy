"""Testes da Parte 3: busca (FTS5 + fallback LIKE), "mais como este",
estatísticas, categorias e as páginas web do Vortex."""
from datetime import timedelta

import pytest

import vortex_crawler as vc
import vortex_search as vs
from models import Post, PostMedia, VortexItem, VortexProfile, utcnow

BASE_HASH = 0x0123456789ABCDEF


def flip(value, bits):
    """Inverte os `bits` primeiros bits menos significativos (distância = bits)."""
    return value ^ ((1 << bits) - 1)


def mk(db, title, tags="", category="natureza", media="photo", phash=None,
       profile="commons", desc="", n=[0]):
    n[0] += 1
    prof = VortexProfile.query.filter_by(handle=profile).first()
    url = f"https://x.org/{n[0]}/{title.replace(' ', '_')}.jpg"
    item = VortexItem(
        profile_id=prof.id, media_type=media, media_url=url, thumb_url=url + ".t.jpg",
        width=800, height=600, title=title, description=desc, tags=tags, category=category,
        url_hash=vc._hash_url(url),
        phash=f"{phash:016x}" if isinstance(phash, int) else phash,
    )
    db.session.add(item)
    db.session.commit()
    return item


def get(client, headers, url):
    r = client.get(url, headers=headers)
    return r.status_code, r.get_json()


def ids_of(payload):
    return [t["item_id"] for t in payload["tiles"]]


# ------------------------------------------------------------------ índice
def test_fts_is_created_and_follows_inserts_updates_deletes(app, db):
    assert vs.fts_available(app)
    a = mk(db, "Cachoeira linda", "cachoeira,agua")
    assert vs.search_items(app, "cachoeira")["total"] == 1
    a.title = "Montanha nevada"
    a.tags = "montanha"
    db.session.commit()
    assert vs.search_items(app, "cachoeira")["total"] == 0
    assert vs.search_items(app, "montanha")["total"] == 1
    db.session.delete(a)
    db.session.commit()
    assert vs.search_items(app, "montanha")["total"] == 0


def test_startup_reindexes_items_that_predate_the_index(app, db):
    from sqlalchemy import text
    mk(db, "Girassol amarelo", "girassol,flor")
    with db.engine.begin() as conn:  # simula banco da Parte 2: sem índice
        conn.execute(text("DROP TABLE vortex_items_fts"))
        for trig in ("ai", "ad", "au"):
            conn.execute(text(f"DROP TRIGGER IF EXISTS vortex_items_fts_{trig}"))
    assert vs.ensure_search_index(app, db) is True
    assert vs.search_items(app, "girassol")["total"] == 1


def test_prune_keeps_index_in_sync(app, db):
    app.config["VORTEX_MAX_ITEMS"] = 5
    for i in range(12):
        mk(db, f"Praia numero {i}", "praia")
    vc.prune_old_items(app, db)
    assert VortexItem.query.count() == 5
    assert vs.search_items(app, "praia")["total"] == 5


# ------------------------------------------------------------------- busca
def test_search_ranks_title_over_description_and_ignores_accents(app, db):
    mk(db, "Rio calmo", "rio", desc="uma cachoeira ao fundo")
    mk(db, "Cachoeira grande", "agua")
    res = vs.search_items(app, "cachoeirá")  # acento na consulta
    assert [i.title for i in res["items"]] == ["Cachoeira grande", "Rio calmo"]
    assert res["mode"] == "fts" and res["relaxed"] is False


def test_search_prefix_and_simple_plural(app, db):
    mk(db, "Gato dormindo", "gato,animal")
    assert vs.search_items(app, "gat")["total"] == 1       # prefixo
    assert vs.search_items(app, "gatos")["total"] == 1     # plural -> gato
    assert vs.search_items(app, "cachorro")["total"] == 0


def test_search_matches_category_slug(app, db):
    mk(db, "Foto 1", "x1", category="animais")
    mk(db, "Foto 2", "x2", category="natureza")
    assert [i.title for i in vs.search_items(app, "animais")["items"]] == ["Foto 1"]


def test_search_relaxes_to_any_word_when_no_item_has_all(app, db):
    mk(db, "Gato preto", "gato")
    mk(db, "Montanha alta", "montanha")
    res = vs.search_items(app, "gato montanha")
    assert res["relaxed"] is True and res["total"] == 2


def test_search_total_is_capped_and_flagged(app, db, user_token):
    _, headers = user_token
    app.config["VORTEX_SEARCH_MAX_RESULTS"] = 20
    for i in range(35):
        mk(db, f"Estrada {i}", "estrada")
    data = get(app.test_client(), headers, "/api/v1/vortex/search?q=estrada")[1]
    assert data["total"] == 20 and data["total_capped"] is True and len(data["tiles"]) == 20
    assert data["has_next"] is False
    app.config["VORTEX_SEARCH_MAX_RESULTS"] = 400
    data = get(app.test_client(), headers, "/api/v1/vortex/search?q=estrada")[1]
    assert data["total"] == 35 and data["total_capped"] is False


def test_search_hostile_input_never_breaks(app, db):
    mk(db, "Flor", "flor")
    for q in ['"; DROP TABLE vortex_items; --', "flor AND OR NOT (", "* ^ : ' \"", "flor*", "NEAR(flor x)"]:
        res = vs.search_items(app, q)
        assert isinstance(res["total"], int)
    assert VortexItem.query.count() == 1


def test_search_like_fallback_when_fts_is_off(app, db):
    mk(db, "Cachoeira linda", "cachoeira,agua")
    mk(db, "Rio calmo", "rio", desc="com uma cachoeira")
    mk(db, "Deserto", "areia")
    app.extensions["vortex_search"]["fts"] = False
    res = vs.search_items(app, "cachoeira")
    assert res["mode"] == "like"
    assert [i.title for i in res["items"]] == ["Cachoeira linda", "Rio calmo"]
    assert vs.search_items(app, "gato rio")["relaxed"] is True
    assert vs.search_items(app, "100%_")["total"] == 0   # curingas do LIKE não vazam


def test_search_endpoint_filters_pagination_and_validation(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    for i in range(40):
        mk(db, f"Paisagem verde {i}", "paisagem", category="natureza", media="photo")
    for i in range(35):
        mk(db, f"Paisagem animada {i}", "paisagem", category="arte", media="gif")
    mk(db, "Paisagem oculta", "paisagem").is_active = False
    db.session.commit()

    seen, cursor, pages = [], None, 0
    while True:
        url = "/api/v1/vortex/search?q=paisagem" + (f"&cursor={cursor}" if cursor else "")
        status, data = get(client, headers, url)
        assert status == 200
        seen += ids_of(data)
        pages += 1
        assert pages < 10
        cursor = data["next_cursor"]
        if not data["has_next"]:
            break
    assert len(seen) == 75 and len(set(seen)) == 75 and data["total"] == 75
    assert all(t["source"] == "crawler" for t in data["tiles"])

    _, data = get(client, headers, "/api/v1/vortex/search?q=paisagem&type=gif")
    assert data["total"] == 35 and {t["media_type"] for t in data["tiles"]} == {"gif"}
    _, data = get(client, headers, "/api/v1/vortex/search?q=paisagem&category=arte&type=photo")
    assert data["total"] == 0 and data["tiles"] == []

    assert client.get("/api/v1/vortex/search?q=x", headers=headers).status_code == 400
    assert client.get("/api/v1/vortex/search", headers=headers).status_code == 400
    assert client.get("/api/v1/vortex/search?q=ok&type=zzz", headers=headers).status_code == 400
    assert client.get("/api/v1/vortex/search?q=ok&category=zzz", headers=headers).status_code == 400
    assert client.get("/api/v1/vortex/search?q=paisagem").status_code == 401


# ------------------------------------------------------------ mais como este
def test_related_orders_by_shared_tags_and_skips_self_and_hidden(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    base = mk(db, "Lago azul", "lago,agua,azul")
    best = mk(db, "Lago de montanha", "lago,agua,montanha")
    ok = mk(db, "Rio comprido", "agua,rio")
    other_cat = mk(db, "Gato", "gato", category="animais")
    hidden = mk(db, "Lago escondido", "lago,agua,azul")
    hidden.is_active = False
    db.session.commit()

    status, data = get(client, headers, f"/api/v1/vortex/item/{base.id}/related")
    assert status == 200
    got = ids_of(data)
    assert base.id not in got and hidden.id not in got
    assert got == [best.id, ok.id]                # quem compartilha mais tags vem antes
    assert other_cat.id not in got                # outra categoria e sem nenhum sinal: nem entra


def test_related_works_without_phash_and_fills_with_same_category(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    base = mk(db, "Foto unica", "zzzunico", category="comida")
    same_cat = [mk(db, f"Prato {i}", f"prato{i}", category="comida") for i in range(3)]
    stranger = mk(db, "Cachorro", "cachorro", category="animais")
    _, data = get(client, headers, f"/api/v1/vortex/item/{base.id}/related")
    got = ids_of(data)
    # sem tags/título/phash em comum: só o preenchimento por categoria (mais novos primeiro)
    assert got == [i.id for i in reversed(same_cat)]
    assert stranger.id not in got


def test_related_uses_phash_and_drops_duplicates(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    base = mk(db, "Original", "alfa", phash=BASE_HASH)
    dup = mk(db, "Copia identica", "beta", phash=flip(BASE_HASH, 2))      # mesma imagem
    near = mk(db, "Parecida", "gama", phash=flip(BASE_HASH, 9))           # parecida
    far = mk(db, "Diferente", "delta", phash=BASE_HASH ^ ((1 << 64) - 1))  # 64 bits de distância
    _, data = get(client, headers, f"/api/v1/vortex/item/{base.id}/related")
    got = ids_of(data)
    assert dup.id not in got
    assert got.index(near.id) < got.index(far.id)


def test_related_same_profile_is_only_a_tiebreaker(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    base = mk(db, "Base", "cor,flor", profile="commons")
    strong_other = mk(db, "Forte", "cor,flor", profile="openverse")
    weak_same = mk(db, "Fraca", "cor", profile="commons")
    tie_same = mk(db, "Empate A", "cor,flor,x1", profile="commons")
    tie_other = mk(db, "Empate B", "cor,flor,x2", profile="openverse")
    got = ids_of(get(client, headers, f"/api/v1/vortex/item/{base.id}/related")[1])
    assert got.index(strong_other.id) < got.index(weak_same.id)   # perfil não passa a tag
    assert got.index(tie_same.id) < got.index(tie_other.id)       # mas desempata


def test_related_pagination_has_no_repeats_and_detail_embeds_first_page(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    base = mk(db, "Base", "mar,onda")
    for i in range(70):
        mk(db, f"Mar {i}", "mar,onda" if i % 2 else "mar")
    status, detail = get(client, headers, f"/api/v1/vortex/item/{base.id}")
    assert status == 200 and detail["item"]["tags"] == ["mar", "onda"]
    assert len(detail["related"]["tiles"]) == 30 and detail["related"]["has_next"]

    seen, cursor, pages = [], None, 0
    while True:
        url = f"/api/v1/vortex/item/{base.id}/related" + (f"?cursor={cursor}" if cursor else "")
        _, data = get(client, headers, url)
        seen += ids_of(data)
        pages += 1
        assert pages < 10
        cursor = data["next_cursor"]
        if not data["has_next"]:
            break
    assert len(seen) == 70 and len(set(seen)) == 70
    assert seen[:30] == ids_of(detail["related"])

    _, slim = get(client, headers, f"/api/v1/vortex/item/{base.id}?related=0")
    assert "related" not in slim


def test_related_404_for_hidden_or_missing_and_requires_auth(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    item = mk(db, "X", "y")
    assert client.get(f"/api/v1/vortex/item/{item.id}/related").status_code == 401
    assert client.get("/api/v1/vortex/item/99999/related", headers=headers).status_code == 404
    item.is_active = False
    db.session.commit()
    assert client.get(f"/api/v1/vortex/item/{item.id}/related", headers=headers).status_code == 404


def test_related_without_fts_still_finds_tag_matches(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    app.extensions["vortex_search"]["fts"] = False
    base = mk(db, "Base", "lago,agua")
    match = mk(db, "Parecido", "agua,rio", category="arte")
    mk(db, "Longe", "deserto", category="animais")
    got = ids_of(get(client, headers, f"/api/v1/vortex/item/{base.id}/related")[1])
    assert got[0] == match.id


# -------------------------------------------------------- stats e categorias
def _make_user_post(db, uid, kind="photo", expired=False):
    post = Post(user_id=uid, post_type=kind, media_filename=f"u.{kind}", duration_minutes=60)
    db.session.add(post)
    db.session.flush()
    db.session.add(PostMedia(post_id=post.id, filename=f"u.{kind}", media_type=kind, position=0))
    if expired:
        post.expires_at = utcnow() - timedelta(minutes=5)
    db.session.commit()
    return post


def test_stats_and_categories_counts(app, db, user_token):
    uid, headers = user_token
    client = app.test_client()
    for i in range(5):
        mk(db, f"n{i}", f"n{i}", category="natureza", media="photo")
    for i in range(2):
        mk(db, f"a{i}", f"a{i}", category="animais", media="gif")
    mk(db, "v", "v", category="natureza", media="video")
    mk(db, "oculto", "o", category="natureza").is_active = False
    mk(db, "outro perfil", "p", category="humor", profile="openverse")
    db.session.commit()
    _make_user_post(db, uid, "photo")
    _make_user_post(db, uid, "video")
    _make_user_post(db, uid, "photo", expired=True)   # expirado não conta

    status, st = get(client, headers, "/api/v1/vortex/stats")
    assert status == 200
    assert st["crawler_items"] == 9 and st["user_posts"] == 2
    assert (st["photos"], st["gifs"], st["videos"]) == (7, 2, 2) and st["total"] == 11
    assert st["profiles"] == 2
    assert [c["slug"] for c in st["by_category"]] == ["natureza", "animais", "humor"]
    assert st["by_category"][0] == {"slug": "natureza", "label": "Natureza", "count": 6}

    _, cats = get(client, headers, "/api/v1/vortex/categories")
    assert [c["slug"] for c in cats["categories"]] == ["natureza", "animais", "humor"]
    nat = cats["categories"][0]
    assert (nat["count"], nat["photos"], nat["gifs"], nat["videos"]) == (6, 5, 0, 1)
    assert cats["types"] == {"all": 11, "photo": 7, "gif": 2, "video": 2}

    _, only = get(client, headers, "/api/v1/vortex/categories?category=natureza")
    assert only["types"] == {"all": 6, "photo": 5, "gif": 0, "video": 1}
    _, every = get(client, headers, "/api/v1/vortex/categories?all=1")
    assert len(every["categories"]) == len(app.config["VORTEX_CATEGORIES"])
    assert client.get("/api/v1/vortex/categories?category=zzz", headers=headers).status_code == 400
    assert client.get("/api/v1/vortex/stats").status_code == 401


def test_stats_hide_inactive_profile_and_are_cached(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    mk(db, "a", "a")
    VortexProfile.query.filter_by(handle="commons").one().is_active = False
    db.session.commit()
    assert get(client, headers, "/api/v1/vortex/stats")[1]["crawler_items"] == 0

    app.config["VORTEX_STATS_TTL_SECONDS"] = 300
    app.extensions["vortex_search"].pop("cache", None)
    VortexProfile.query.filter_by(handle="commons").one().is_active = True
    db.session.commit()
    assert get(client, headers, "/api/v1/vortex/stats")[1]["crawler_items"] == 1
    mk(db, "b", "b")
    assert get(client, headers, "/api/v1/vortex/stats")[1]["crawler_items"] == 1   # veio do cache
    vs.clear_stats_cache(app)
    assert get(client, headers, "/api/v1/vortex/stats")[1]["crawler_items"] == 2


def test_format_count():
    assert vs.format_count(0) == "0" and vs.format_count(1234567) == "1.234.567"


# ---------------------------------------------------------------------- web
def login(client, db, username="webuser"):
    from models import User
    u = User(username=username, email=f"{username}@example.com")
    u.set_password("senha1234")
    db.session.add(u)
    db.session.commit()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(u.id)
        sess["_fresh"] = True
    return u


def test_web_vortex_requires_login(app, db):
    client = app.test_client()
    item = mk(db, "Foto", "foto")
    assert client.get("/pictures").status_code == 302
    assert client.get(f"/pictures/item/{item.id}").status_code == 302
    assert client.get("/api/pictures/mais").status_code == 401
    assert client.get(f"/api/pictures/item/{item.id}/mais").status_code == 401


def test_web_grid_shows_crawler_items_stats_and_chips(app, db):
    client = app.test_client()
    user = login(client, db)
    mk(db, "Cachoeira alta", "cachoeira", category="natureza")
    mk(db, "Gatinho", "gato", category="animais", media="gif")
    mk(db, "Voo de passaro", "passaro", category="animais", media="video")
    _make_user_post(db, user.id, "photo")
    html = client.get("/pictures").get_data(as_text=True)
    assert html.count("picture-tile-crawler") >= 3 and "/post/" in html      # crawler + usuário
    assert "<strong>2</strong> imagens" in html and "<strong>1</strong> GIFs" in html \
        and "<strong>1</strong> vídeos" in html
    assert "categoria=animais" in html and "tipo=gif" in html
    # vídeo do crawler: capa + play, nada de <video data-src> carregando na grade
    assert "picture-tile-play" in html and "data-src=" not in html
    # GIF do crawler usa o arquivo animado
    assert 'src="https://x.org/' in html and "GIF</span>" in html


def test_web_filters_search_and_empty_states(app, db):
    client = app.test_client()
    login(client, db)
    mk(db, "Cachoeira alta", "cachoeira", category="natureza")
    mk(db, "Gatinho", "gato", category="animais", media="gif")

    html = client.get("/pictures?categoria=animais").get_data(as_text=True)
    assert "Gatinho" in html and "Cachoeira alta" not in html

    html = client.get("/pictures?tipo=gif").get_data(as_text=True)
    assert "Gatinho" in html and "Cachoeira alta" not in html

    html = client.get("/pictures?q=cachoeira").get_data(as_text=True)
    assert "Cachoeira alta" in html and "Gatinho" not in html
    assert "<strong>1</strong> resultado" in html and "limpar busca" in html

    html = client.get("/pictures?q=zzzinexistente").get_data(as_text=True)
    assert "Nada encontrado" in html and "picture-tile-crawler" not in html

    # filtros inválidos são ignorados em vez de dar erro
    assert client.get("/pictures?categoria=zzz&tipo=zzz&q=%22%27").status_code == 200


def test_web_infinite_scroll_has_no_repeats_across_pages(app, db):
    import re
    client = app.test_client()
    user = login(client, db)
    for i in range(70):
        mk(db, f"Foto {i}", "foto")
    for _ in range(8):
        _make_user_post(db, user.id, "photo")

    def keys(html):
        return re.findall(r'picture-tile-crawler.*?item/(\d+)"', html, re.S)

    first = client.get("/pictures").get_data(as_text=True)
    cursor = re.search(r'data-next-cursor="([^"]+)"', first).group(1)
    seen = keys(first)
    posts = set(re.findall(r"/post/(\d+)", first))
    for _ in range(10):
        r = client.get(f"/api/pictures/mais?cursor={cursor}").get_json()
        html = "".join(r["tiles"])
        seen += keys(html)
        posts |= set(re.findall(r"/post/(\d+)", html))
        if not r["has_next"]:
            break
        cursor = r["next_cursor"]
    else:
        pytest.fail("não terminou")
    assert len(seen) == 70 and len(set(seen)) == 70
    assert len(posts) == 8


def test_web_search_pagination_keeps_filters(app, db):
    client = app.test_client()
    login(client, db)
    for i in range(45):
        mk(db, f"Montanha {i}", "montanha", media="photo")
    for i in range(5):
        mk(db, f"Montanha animada {i}", "montanha", media="gif")
    first = client.get("/pictures?q=montanha&tipo=photo").get_data(as_text=True)
    assert 'data-more-url="/api/pictures/mais?q=montanha&amp;tipo=photo"' in first
    r = client.get("/api/pictures/mais?q=montanha&tipo=photo&cursor=o30").get_json()
    assert len(r["tiles"]) == 15 and r["has_next"] is False
    assert "animada" not in "".join(r["tiles"])


def test_web_item_detail_page_and_related(app, db):
    client = app.test_client()
    login(client, db)
    base = mk(db, "Lago azul", "lago,agua,azul", desc="Um lago calmo")
    base.attribution, base.license = "Maria Silva", "CC BY-SA 4.0"
    base.source_url, base.source_name = "https://commons.example/wiki/Lago", "Wikimedia Commons"
    db.session.commit()
    mk(db, "Lago de montanha", "lago,agua,montanha")
    mk(db, "Deserto", "areia", category="animais")

    html = client.get(f"/pictures/item/{base.id}").get_data(as_text=True)
    assert "Lago azul" in html and "Maria Silva" in html and "CC BY-SA 4.0" in html
    assert 'href="https://commons.example/wiki/Lago"' in html and 'rel="noopener noreferrer"' in html
    assert "Mais como este" in html and "Lago de montanha" in html and "Deserto" not in html
    assert "q=lago" in html                                   # tags viram buscas
    assert 'data-next-cursor=""' in html                      # só 1 página: nada mais a carregar
    assert "perfil do Vortex" in html and "Wikimedia Commons" in html


def test_web_item_detail_video_gif_unsafe_link_and_hidden(app, db):
    client = app.test_client()
    login(client, db)
    video = mk(db, "Rio correndo", "rio", media="video")
    video.source_url = "javascript:alert(1)"
    db.session.commit()
    html = client.get(f"/pictures/item/{video.id}").get_data(as_text=True)
    assert "<video" in html and "controls" in html
    assert "javascript:alert" not in html                     # link inseguro não é renderizado
    video.is_active = False
    db.session.commit()
    assert client.get(f"/pictures/item/{video.id}").status_code == 404
    assert client.get(f"/api/pictures/item/{video.id}/mais").status_code == 404
    assert client.get("/pictures/item/99999").status_code == 404


def test_web_item_related_infinite_scroll_has_no_repeats(app, db):
    import re
    client = app.test_client()
    login(client, db)
    base = mk(db, "Base", "mar,onda")
    for i in range(70):
        mk(db, f"Mar {i}", "mar")
    first = client.get(f"/pictures/item/{base.id}").get_data(as_text=True)
    assert f"/api/pictures/item/{base.id}/mais" in first
    cursor = re.search(r'data-next-cursor="([^"]+)"', first).group(1)
    seen = re.findall(r'picture-tile-crawler.*?item/(\d+)"', first, re.S)
    while cursor:
        r = client.get(f"/api/pictures/item/{base.id}/mais?cursor={cursor}").get_json()
        seen += re.findall(r'picture-tile-crawler.*?item/(\d+)"', "".join(r["tiles"]), re.S)
        cursor = r["next_cursor"] if r["has_next"] else None
    assert len(seen) == 70 and len(set(seen)) == 70
