"""Mensagens — parte 4 (site): Novo grupo no menu, seção Grupos na lista, página da conversa de grupo."""
import pathlib
import pytest
from test_ping_phase7 import site  # noqa: F401  (fixture: 'ana' logada; existe também 'beto')


def _read(p):
    return pathlib.Path(p).read_text(encoding="utf-8")


def _make_group(site, owner="ana", members=("beto",)):
    from extensions import db as _db
    from models import ChatGroup, ChatGroupMember, User
    with site.application.app_context():
        u = {n: User.query.filter_by(username=n).first() for n in {owner, *members}}
        g = ChatGroup(name="Turma do Zap", created_by_id=u[owner].id) if hasattr(ChatGroup, "created_by_id") else ChatGroup(name="Turma do Zap")
        _db.session.add(g)
        _db.session.flush()
        _db.session.add(ChatGroupMember(group_id=g.id, user_id=u[owner].id, role="owner"))
        for m in members:
            _db.session.add(ChatGroupMember(group_id=g.id, user_id=u[m].id, role="member"))
        _db.session.commit()
        return g.id


@pytest.mark.parametrize("url", ["/mensagens/", "/mensagens/beto", "/mensagens/contatos", "/mensagens/chamadas"])
def test_new_group_entry_points_on_every_page(site, url):
    html = site.get(url).get_data(as_text=True)
    assert html.count('id="ping-group-open"') == 1           # item do menu lateral
    assert 'id="ping-group-new"' in html and 'id="ping-group-create"' in html
    assert 'id="ping-groups"' in html and 'id="ping-groups-list"' in html
    assert "js/groups.js" in html
    assert "ping-fab" not in html                             # a caneta continua removida


def test_drawer_lists_new_group_before_contacts(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    drawer = html[html.index('id="ping-drawer-wrap"'):]
    assert drawer.index("Novo grupo") < drawer.index("Contatos")


def test_archived_view_has_groups_section_but_no_panel(site):
    html = site.get("/mensagens/?arquivadas=1").get_data(as_text=True)
    assert 'data-archived="1"' in html and 'id="ping-group-new"' not in html


def test_group_page_for_member(site):
    gid = _make_group(site)
    r = site.get(f"/mensagens/grupo/{gid}")
    html = r.get_data(as_text=True)
    assert r.status_code == 200
    assert 'id="gw"' in html and f'data-group-id="{gid}"' in html and 'data-my-role="owner"' in html
    assert "js/group-thread.js" in html and 'id="gw-info"' in html
    assert f'data-active="{gid}"' in html                       # linha do grupo destacada na lista
    assert 'id="ping-settings"' in html and 'id="ping-drawer-wrap"' in html


def test_group_page_404_for_non_member_and_missing(site):
    gid = _make_group(site, owner="beto", members=())
    assert site.get(f"/mensagens/grupo/{gid}").status_code == 404
    assert site.get("/mensagens/grupo/99999").status_code == 404


def test_group_route_does_not_clash_with_usernames(site):
    assert site.get("/mensagens/beto").status_code == 200


def test_live_and_shell_handle_group_events():
    assert '"group"' in _read("static/js/chat-live.js")
    shell = _read("static/js/ping-shell.js")
    assert 'rest === "grupo"' in shell and "ping-group-row" in shell and "window.pingShell" in shell


def test_group_thread_script_uses_safe_dom_and_api():
    js = _read("static/js/group-thread.js")
    assert ".innerHTML" not in js
    for needle in ("/messages", "/members", "/leave", "/prefs", "/typing", "/read", "/avatar", 'driqyLive'):
        assert needle in js, needle


def test_group_css_present_and_sw_bumped():
    css = _read("static/css/style.css")
    for sel in (".ping-group-new", ".gw-info", ".gw-member", ".gw-sender", ".ping-groups"):
        assert sel in css, sel
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", _read("static/sw.js")).group(1)) >= 57  # versão do cache do SW só pode subir
