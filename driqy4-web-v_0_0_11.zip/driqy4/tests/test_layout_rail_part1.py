"""Layout Parte 1: menu esquerdo em caixa arredondada + coluna direita de widgets."""
import pathlib

CSS = pathlib.Path("static/css/style.css").read_text(encoding="utf-8")
BASE = pathlib.Path("templates/base.html").read_text(encoding="utf-8")


def test_sidebar_is_rounded_floating_box():
    i = CSS.index("Menu esquerdo numa caixa arredondada")
    block = CSS[i:i + 700]
    assert "border-radius: 22px" in block and "margin: 16px 0 16px 16px" in block


def test_rail_partial_and_assets():
    assert '{% include "_rail.html" %}' in BASE
    assert "js/rail.js" in BASE
    html = pathlib.Path("templates/_rail.html").read_text(encoding="utf-8")
    for el in ("rail-widget-body", "rail-widget-prev", "rail-widget-next", "rail-suggest-list"):
        assert el in html
    assert "DriqyRail" in pathlib.Path("static/js/rail.js").read_text(encoding="utf-8")


def test_rail_hidden_on_wide_pages_and_small_screens():
    assert ".rail { display: none; }" in CSS
    assert "body.home-page:not(.rail-off) .rail" in CSS


def test_feed_renders_rail_only_when_logged_in(app):
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User(username="ana", email="ana@example.com")
        u.set_password("senha1234")
        _db.session.add(u)
        _db.session.commit()
    c = app.test_client()
    anon = c.get("/").get_data(as_text=True)
    assert 'id="rail"' not in anon
    c.post("/login", data={"identifier": "ana", "password": "senha1234"})
    logged = c.get("/").get_data(as_text=True)
    assert 'id="rail"' in logged and "js/rail.js" in logged
