"""Layout Parte 4: dados dos widgets (Em alta, Notícias, Vortex, Quem está online)."""
from datetime import timedelta

import pytest


@pytest.fixture()
def world(app):
    from extensions import db as _db
    from models import (ApiToken, Comment, Like, NewsArticle, NewsSource, Post, User, VortexItem,
                        VortexProfile, VortexSeen, utcnow)
    with app.app_context():
        now = utcnow()
        U = {}
        for n in ("ana", "beto", "caio", "dani"):
            u = User(username=n, email=f"{n}@example.com", last_seen_at=now)
            u.set_password("senha1234")
            _db.session.add(u)
            U[n] = u
        _db.session.commit()
        tok = ApiToken.generate_for(U["ana"])
        _db.session.commit()
        P = {}
        for key, author, text, mins in (("quiet", "beto", "ninguém reagiu", 30), ("hot", "caio", "post muito comentado " * 8, 60),
                                        ("warm", "beto", "post curtido", 90), ("expired", "caio", "expirou", 10)):
            p = Post(user_id=U[author].id, post_type="text", text_content=text, duration_minutes=60 * 24 * 3,
                     created_at=now - timedelta(minutes=mins))
            if key == "expired":
                p.expires_at = now - timedelta(minutes=1)
            _db.session.add(p)
            P[key] = p
        _db.session.commit()
        _db.session.add_all([Like(user_id=U["ana"].id, post_id=P["warm"].id),
                             Comment(user_id=U["ana"].id, post_id=P["hot"].id, content="a"),
                             Comment(user_id=U["dani"].id, post_id=P["hot"].id, content="b"),
                             Like(user_id=U["ana"].id, post_id=P["expired"].id)])
        # vortex: 3 fotos, uma rejeitada pela ana; 1 vídeo (fica de fora); 1 sem miniatura
        prof = VortexProfile(handle="vx", display_name="Vx")
        _db.session.add(prof)
        _db.session.commit()
        items = []
        for i, (mt, thumb) in enumerate((("photo", "http://t/1.jpg"), ("photo", "http://t/2.jpg"), ("gif", "http://t/3.gif"),
                                         ("video", "http://t/4.jpg"), ("photo", None))):
            it = VortexItem(profile_id=prof.id, media_type=mt, media_url=f"http://m/{i}", thumb_url=thumb,
                            url_hash=f"h{i}", created_at=now - timedelta(minutes=i))
            _db.session.add(it)
            items.append(it)
        _db.session.commit()
        _db.session.add(VortexSeen(user_id=U["ana"].id, key=f"c{items[0].id}", rejected=True))
        src = NewsSource(name="Fonte X", feed_url="http://f/x")
        _db.session.add(src)
        _db.session.commit()
        _db.session.add(NewsArticle(source_id=src.id, title="Manchete de teste", url="http://n/1", url_hash="n1",
                                    published_at=now, image_url="http://n/img.jpg"))
        _db.session.commit()
        return {"h": {"Authorization": f"Bearer {tok.token}"}, "U": {k: v.id for k, v in U.items()}}


def get(app, world, path):
    return app.test_client().get(f"/api/v1/widgets/{path}", headers=world["h"]).get_json()


def test_registry_lists_all_widgets(app, world):
    ids = [w["id"] for w in app.test_client().get("/api/v1/widgets", headers=world["h"]).get_json()["widgets"]]
    assert ids[:5] == ["weather", "trending", "news", "vortex", "online"] and len(ids) == 16


def test_trending_orders_by_reactions_and_skips_expired_and_quiet(app, world):
    posts = get(app, world, "trending")["posts"]
    assert [p["author"]["username"] for p in posts] == ["caio", "beto"]
    assert posts[0]["comments"] == 2 and posts[0]["snippet"].endswith("…") and len(posts[0]["snippet"]) <= 91
    assert posts[1]["likes"] == 1 and posts[0]["url"].startswith("/p")


def test_news_headlines(app, world):
    arts = get(app, world, "news")["articles"]
    assert arts and arts[0]["title"] == "Manchete de teste" and arts[0]["source"] == "Fonte X"
    assert arts[0]["url"].endswith("/abrir") and "w=480" in arts[0]["image_url"]


def test_news_limit_param_is_accepted_and_clamped(app, world):
    # Peq-2: o cliente pede mais manchetes para repor as dispensadas; valor ruim cai no padrão/limite
    for q in ("news?limit=1", "news?limit=999", "news?limit=0", "news?limit=abc"):
        arts = get(app, world, q)["articles"]
        assert isinstance(arts, list) and 0 < len(arts) <= 12
    assert len(get(app, world, "news?limit=1")["articles"]) == 1


def test_vortex_preview_skips_rejected_video_and_no_thumb(app, world):
    items = get(app, world, "vortex")["items"]
    assert [i["thumb_url"] for i in items] == ["http://t/2.jpg", "http://t/3.gif"]


def test_vortex_preview_does_not_touch_seen_ledger(app, world):
    from extensions import db as _db
    from models import VortexSeen
    with app.app_context():
        before = VortexSeen.query.count()
    get(app, world, "vortex")
    with app.app_context():
        assert VortexSeen.query.count() == before


def test_online_counts_recent_others_and_respects_privacy(app, world):
    from extensions import db as _db
    from models import User, utcnow
    with app.app_context():
        _db.session.get(User, world["U"]["beto"]).last_seen_at = utcnow() - timedelta(hours=2)
        _db.session.get(User, world["U"]["dani"]).show_presence = False
        _db.session.commit()
    r = get(app, world, "online")
    assert r["hidden"] is False and r["count"] == 1 and [u["username"] for u in r["users"]] == ["caio"]
    with app.app_context():
        _db.session.get(User, world["U"]["ana"]).show_presence = False
        _db.session.commit()
    assert get(app, world, "online") == {"hidden": True, "count": 0, "users": []}


def test_endpoints_require_login(app):
    c = app.test_client()
    for p in ("trending", "news", "vortex", "online"):
        assert c.get(f"/api/v1/widgets/{p}").status_code == 401
