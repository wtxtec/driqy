"""Fila de indexação progressiva (vortex_queue.py + ligação com vortex_discovery)."""
import hashlib
from datetime import timedelta
from types import SimpleNamespace

import pytest

import vortex_discovery as vd
import vortex_queue as vq
from models import VortexDomain, VortexFrontier, utcnow

CFG = {
    "VORTEX_DISCOVERY_MAX_FRONTIER": 1000, "VORTEX_FRONTIER_PER_HOST_MAX": 5,
    "VORTEX_DISCOVERY_MAX_DOMAINS": 1000, "VORTEX_URL_BLOCK_TERMS": (), "VORTEX_DOMAIN_DENYLIST": set(),
}


def _row(url, host, depth=0, status="pending", age_days=0, done_days=None):
    now = utcnow()
    return VortexFrontier(
        url_hash=hashlib.sha256(url.encode()).hexdigest(), url=url, host=host, depth=depth, status=status,
        created_at=now - timedelta(days=age_days),
        done_at=(now - timedelta(days=done_days)) if done_days is not None else None)


def _fill(db, hosts, per_host, depth_of=lambda i: i % 3):
    rows = []
    for h in range(hosts):
        for i in range(per_host):
            rows.append(_row(f"https://h{h}.example/p/{i}", f"h{h}.example", depth_of(i)))
    db.session.bulk_save_objects(rows)
    db.session.commit()


# ------------------------------------------------------------- funções puras
def test_level_for_thresholds():
    assert vq.level_for(0, CFG) == "open"
    assert vq.level_for(599, CFG) == "open"
    assert vq.level_for(600, CFG) == "tight"
    assert vq.level_for(999, CFG) == "tight"
    assert vq.level_for(1000, CFG) == "full"
    assert vq.level_for(50, {}) == "open"            # sem config: usa os padrões


def test_shape_entries_caps_same_host_and_one_link_per_other_site():
    cfg = dict(CFG, VORTEX_FRONTIER_SAME_HOST_PER_PAGE=4, VORTEX_FRONTIER_OTHER_PER_PAGE=3)
    entries = [(f"https://a.com/x/{i}", 1) for i in range(30)]
    entries += [(f"https://b.com/p{i}", 0) for i in range(10)]         # 10 links, um site só
    entries += [(f"https://c{i}.com/", 0) for i in range(10)]
    same, other = vq.shape_entries(cfg, "a.com", entries, "open")
    assert len(same) == 4 and all("a.com" in u for u, _ in same)
    hosts = [vq._host_of(u) for u, _ in other]
    assert len(other) == 3 and len(set(hosts)) == 3                    # um por site, no máximo 3


def test_shape_entries_prefers_shallow_and_is_stable():
    cfg = dict(CFG, VORTEX_FRONTIER_SAME_HOST_PER_PAGE=2)
    entries = [("https://a.com/x", 3), ("https://a.com/y", 1), ("https://a.com/z", 2), ("https://a.com/w", 1)]
    same1, _ = vq.shape_entries(cfg, "a.com", entries, "open")
    same2, _ = vq.shape_entries(cfg, "a.com", list(reversed(entries)), "open")
    assert {d for _, d in same1} == {1} and same1 == same2


def test_shape_entries_levels():
    entries = [("https://a.com/1", 1), ("https://a.com/2", 3), ("https://z.org/", 0)]
    assert vq.shape_entries(CFG, "a.com", entries, "full") == ([], [])
    same, other = vq.shape_entries(CFG, "a.com", entries, "tight")
    assert [d for _, d in same] == [1]                                  # só links rasos
    assert len(other) == 1


def test_shape_entries_sitemap_has_bigger_budget():
    cfg = dict(CFG, VORTEX_FRONTIER_SAME_HOST_PER_PAGE=3, VORTEX_FRONTIER_SITEMAP_PER_PAGE=12)
    entries = [(f"https://a.com/g/{i}", 1) for i in range(30)]
    assert len(vq.shape_entries(cfg, "a.com", entries, "open")[0]) == 3
    assert len(vq.shape_entries(cfg, "a.com", entries, "open", from_sitemap=True)[0]) == 12


# ------------------------------------------------------------------ admissão
def test_enqueue_respects_per_host_budget(app, db):
    with app.app_context():
        entries = [(f"https://gigante.com/p/{i}", 1) for i in range(50)]
        added, _ = vd.enqueue_urls(db, CFG, entries)
        assert added == 5
        added, _ = vd.enqueue_urls(db, CFG, [("https://gigante.com/outra", 1)])
        assert added == 0                                              # orçamento do site esgotado
        added, _ = vd.enqueue_urls(db, CFG, [("https://pequeno.com/a", 0)])
        assert added == 1                                              # outro site não é afetado
        assert VortexFrontier.query.filter_by(host="gigante.com", status="pending").count() == 5


def test_enqueue_budget_frees_up_as_pages_are_visited(app, db):
    with app.app_context():
        vd.enqueue_urls(db, CFG, [(f"https://s.com/p/{i}", 1) for i in range(5)])
        VortexFrontier.query.filter_by(host="s.com").limit(2).all()
        for row in VortexFrontier.query.filter_by(host="s.com").limit(2).all():
            row.status = "done"
        db.session.commit()
        added, _ = vd.enqueue_urls(db, CFG, [(f"https://s.com/q/{i}", 1) for i in range(10)])
        assert added == 2                                              # vagas = as 2 que saíram


# ------------------------------------------------------------ esvaziar passivo
def test_trim_drains_a_huge_backlog_in_batches_and_keeps_shallow_pages(app, db):
    with app.app_context():
        _fill(db, hosts=40, per_host=100)                              # 4000 pendentes, 100 por site
        cfg = dict(CFG, VORTEX_DISCOVERY_MAX_FRONTIER=150, VORTEX_FRONTIER_PER_HOST_MAX=5)
        steps = 0
        while True:
            out = vq.trim_step(app, db, cfg, batch=700)
            steps += 1
            assert out["deleted"] <= 700                               # nunca excede o lote
            if not out["deleted"]:
                break
        assert steps > 3                                               # foi progressivo, não de uma vez
        total = VortexFrontier.query.filter_by(status="pending").count()
        assert total == 40 * 5 or total <= 150
        assert total <= 150
        counts = {}
        for h, in db.session.query(VortexFrontier.host).filter_by(status="pending").all():
            counts[h] = counts.get(h, 0) + 1
        assert max(counts.values()) <= 5                               # orçamento por site
        # ficaram as páginas mais rasas de cada site
        deepest_kept = db.session.query(VortexFrontier.depth).filter_by(status="pending") \
            .order_by(VortexFrontier.depth.desc()).first()[0]
        assert deepest_kept <= 1


def test_trim_keeps_visited_pages_and_drops_stale_pending(app, db):
    with app.app_context():
        db.session.add_all([
            _row("https://a.com/velha", "a.com", age_days=40),
            _row("https://a.com/nova", "a.com", age_days=0),
            _row("https://a.com/feita", "a.com", status="done", age_days=40, done_days=1),
        ])
        db.session.commit()
        out = vq.trim_step(app, db, CFG)
        assert out["stale"] == 1
        urls = {r.url: r.status for r in VortexFrontier.query.all()}
        assert urls == {"https://a.com/nova": "pending", "https://a.com/feita": "done"}


def test_trim_is_a_noop_when_queue_is_healthy(app, db):
    with app.app_context():
        _fill(db, hosts=3, per_host=4)
        out = vq.trim_step(app, db, CFG)
        assert out["deleted"] == 0 and out["pending"] == 12 and out["level"] == "open"


def test_prune_finished_respects_retention(app, db):
    with app.app_context():
        db.session.add_all([
            _row("https://a.com/1", "a.com", status="done", done_days=45),
            _row("https://a.com/2", "a.com", status="failed", done_days=45),
            _row("https://a.com/3", "a.com", status="done", done_days=3),
            _row("https://a.com/4", "a.com", status="pending"),
        ])
        db.session.commit()
        assert vq.prune_finished(app, db, dict(CFG, VORTEX_FRONTIER_PRUNE_BATCH=1)) == 2
        assert sorted(r.url for r in VortexFrontier.query.all()) == ["https://a.com/3", "https://a.com/4"]


def test_visited_url_is_not_requeued_while_it_is_remembered(app, db):
    with app.app_context():
        db.session.add(_row("https://a.com/vista", "a.com", status="done", done_days=2))
        db.session.commit()
        added, _ = vd.enqueue_urls(db, CFG, [("https://a.com/vista", 1)])
        assert added == 0


def test_queue_stats(app, db):
    with app.app_context():
        _fill(db, hosts=4, per_host=30)
        st = vq.queue_stats(app, db, CFG)
        assert st["pending"] == 120 and st["hosts_waiting"] == 4 and st["level"] == "open"
        assert len(st["top_hosts"]) == 4 and st["top_hosts"][0]["pending"] == 30
        assert sum(st["by_depth"].values()) == 120


# ----------------------------------------------- escolha: nunca o mesmo site 2x
def _crawler(app, db, cfg):
    engine = SimpleNamespace(app=app, db=db, cfg=cfg, control=lambda: {"paused": False, "speed": 1.0})
    crawler = vd.DiscoveryCrawler(engine)
    crawler.limiter._intervals.clear()
    return crawler


def test_pick_never_repeats_a_site_and_visits_least_recent_first(app, db):
    cfg = dict(app.config, VORTEX_DISCOVERY_PAGE_INTERVAL=0.0, VORTEX_DISCOVERY_PAGES_PER_DOMAIN_HOUR=1000)
    with app.app_context():
        now = utcnow()
        for i, h in enumerate(("a.com", "b.com", "c.com", "d.com")):
            db.session.add(VortexDomain(host=h, status="active", last_fetch_at=now - timedelta(minutes=i)))
        db.session.commit()
        _fill_host = [_row(f"https://{h}/p/{i}", h) for h in ("a.com", "b.com", "c.com", "d.com") for i in range(6)]
        db.session.bulk_save_objects(_fill_host)
        db.session.commit()
    crawler = _crawler(app, db, cfg)
    seen = []
    for _ in range(4):                                    # 4 rodadas de 2 páginas
        tasks = crawler._pick(2)
        hosts = [t.host for t in tasks]
        assert len(hosts) == len(set(hosts))               # nenhum site duas vezes no mesmo lote
        seen.extend(hosts)
    assert seen[:2] == ["d.com", "c.com"]                  # o menos recentemente visitado primeiro
    assert set(seen) == {"a.com", "b.com", "c.com", "d.com"}
    assert {seen.count(h) for h in set(seen)} == {2}       # todo mundo igual: nada de monopólio


# ------------------------------------------------- ligação com o motor (_persist)
def test_persist_applies_page_budget_and_stops_when_full(app, db):
    cfg = dict(app.config, VORTEX_FRONTIER_SAME_HOST_PER_PAGE=3, VORTEX_FRONTIER_PER_HOST_MAX=50,
               VORTEX_DISCOVERY_MAX_FRONTIER=200)
    with app.app_context():
        db.session.add(VortexDomain(host="s.com", status="active"))
        db.session.commit()
    crawler = _crawler(app, db, cfg)
    task = SimpleNamespace(frontier_id=None, url="https://s.com/", host="s.com", depth=0, feeds_found=0)

    def page(n):
        return SimpleNamespace(task=task, error=None, blocked=False, retry_after=None, feeds=[], queued=0,
                               sitemaps=[], from_sitemap=False,
                               links=[f"https://s.com/g/{n}/{i}" for i in range(40)])
    crawler._persist(page(1))
    with app.app_context():
        assert VortexFrontier.query.filter_by(host="s.com").count() == 3        # 40 links -> 3
    cfg["VORTEX_DISCOVERY_MAX_FRONTIER"] = 3                                    # fila "cheia"
    crawler._counts["level_at"] = 0
    crawler._persist(page(2))
    with app.app_context():
        assert VortexFrontier.query.filter_by(host="s.com").count() == 3        # nada novo entrou


def test_discovery_stats_expose_queue_numbers(app, db):
    crawler = _crawler(app, db, dict(app.config))
    stats = crawler.stats()
    for key in ("frontier_level", "frontier_cap", "frontier_trimmed"):
        assert key in stats
