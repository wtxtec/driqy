"""Chamadas — Fase 13: vídeo. O backend não mudou o protocolo (media=video já existia na Fase 11);
estes testes garantem que vídeo atravessa a sinalização inteira e que a UI web de vídeo está servida."""
import pytest

from chat_events import hub
from tests.test_chat_phase11 import SDP, _answer, _drain, _start, _uid, users, _clean_hub  # noqa: F401
from tests.test_chat_phase12 import _login


def test_video_call_roundtrip_keeps_media(app, users):
    ana, beto, _ = users
    c = app.test_client()
    qb = hub.subscribe(_uid(app, "beto"))
    r = _start(c, ana, media="video")
    assert r.status_code == 201 and r.get_json()["media"] == "video"
    cid = r.get_json()["id"]
    ev = [e for e in _drain(qb) if e[0] == "call_incoming"]
    assert len(ev) == 1 and ev[0][1]["media"] == "video" and ev[0][1]["offer"]["sdp"] == SDP
    # destinatário vê a mesma mídia ao consultar; aceitar não muda
    got = c.get(f"/api/v1/calls/{cid}", headers=beto).get_json()
    assert got["media"] == "video" and got["direction"] == "incoming"
    assert _answer(c, beto, cid).status_code == 200
    assert c.get(f"/api/v1/calls/{cid}", headers=ana).get_json()["media"] == "video"
    assert c.post(f"/api/v1/calls/{cid}/end", json={}, headers=ana).get_json()["state"] == "ended"


def test_video_call_appears_in_history_with_media(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana, media="video").get_json()["id"]
    c.post(f"/api/v1/calls/{cid}/end", json={}, headers=ana)
    hist = c.get("/api/v1/calls", headers=ana).get_json()
    items = hist.get("calls") or hist.get("items") or hist
    assert any(i["id"] == cid and i["media"] == "video" for i in items)


def test_invalid_media_still_rejected(app, users):
    ana, _, _ = users
    c = app.test_client()
    r = c.post("/api/v1/calls/beto", json={"media": "hologram", "offer": {"type": "offer", "sdp": SDP}}, headers=ana)
    assert r.status_code == 400


def test_web_thread_has_video_button(app, users):
    c = app.test_client()
    _login(app, c, "ana")
    html = c.get("/mensagens/beto").get_data(as_text=True)
    assert 'id="cw-video-btn"' in html and 'data-call-media="video"' in html
    assert 'id="cw-call-btn"' in html            # a de voz continua
    assert html.count('data-call-user="beto"') == 2


def test_call_ui_has_video_features(app):
    c = app.test_client()
    js = c.get("/static/js/call-ui.js").get_data(as_text=True)
    for needle in ("getMedia", "offerToReceiveVideo", "toggleCam", "flipCam", "replaceTrack", "cl-has-remote",
                   "data-call-media", "limitVideo", "Câmera indisponível"):
        assert needle in js, needle
    css = c.get("/static/css/style.css").get_data(as_text=True)
    assert ".cl-video" in css and ".cl-local" in css and ".cl-remote" in css
    assert "driqy-shell-v" in c.get("/static/sw.js").get_data(as_text=True)
