"""Lua com mais informações + widget Estações (progresso) + avisos de virada de estação."""
from datetime import date, datetime, timedelta, timezone

import pytest

import season_alerts
import widgets_extra as we


def utc(*a):
    return datetime(*a, tzinfo=timezone.utc)


# ----------------------------------------------------------------- Lua
def test_moon_extra_fields():
    m = we.moon_phase(utc(2026, 11, 6, 12))
    for k in ("phase", "emoji", "illumination", "age_days", "next_full", "next_new", "days_to_full", "days_to_new"):
        assert k in m  # campos antigos continuam
    assert m["waxing"] is False and m["trend"] == "Minguando"
    assert 0 <= m["cycle_pct"] <= 100 and m["cycle_days"] == 29.5
    assert 350000 <= m["distance_km"] <= 410000 and m["distance_label"]
    ev = m["events"]
    assert [e["name"] for e in sorted(ev, key=lambda e: e["days"])] == [e["name"] for e in ev]  # do mais perto ao mais longe
    assert {e["name"] for e in ev} == {"Lua nova", "Quarto crescente", "Lua cheia", "Quarto minguante"}
    assert ev[0]["name"] == "Lua nova"  # a nova de 9/nov/2026 é a próxima


def test_moon_waxing_before_full():
    assert we.moon_phase(utc(2026, 11, 20, 12))["waxing"] is True


# ----------------------------------------------------------------- Estações
def test_season_instants_match_astronomy():
    # valores oficiais (UTC): 20/03 14:46, 21/06 08:24, 23/09 00:05, 21/12 20:50 de 2026
    exp = {0: (3, 20, 14, 46), 1: (6, 21, 8, 24), 2: (9, 23, 0, 5), 3: (12, 21, 20, 50)}
    for k, (mo, d, h, mi) in exp.items():
        got = we.season_event(2026, k)
        assert (got.month, got.day) == (mo, d)
        assert abs((got - utc(2026, mo, d, h, mi)).total_seconds()) < 5 * 60


def test_season_info_south_default():
    s = we.season_info(utc(2026, 11, 6, 12))
    assert s["hemisphere"] == "sul"
    cur = s["current"]
    assert cur["name"] == "Primavera" and cur["status"] == "current" and 0 < cur["progress"] < 100
    assert cur["start"] == "2026-09-22" and cur["end"] == "2026-12-21"
    assert s["next"]["name"] == "Verão" and s["days_to_next"] == cur["days_left"] == 45
    assert [c["name"] for c in s["cycle"]] == ["Verão", "Outono", "Inverno", "Primavera"]
    assert [c["status"] for c in s["cycle"]] == ["past", "past", "past", "current"]
    assert [c["progress"] for c in s["cycle"][:3]] == [100.0, 100.0, 100.0]
    assert 0 < s["year_progress"] < 100 and s["alert"] is None


def test_season_info_north_is_inverted():
    s = we.season_info(utc(2026, 11, 6, 12), lat=40.0)
    assert s["hemisphere"] == "norte" and s["current"]["name"] == "Outono" and s["next"]["name"] == "Inverno"
    assert [c["name"] for c in s["cycle"]] == ["Inverno", "Primavera", "Verão", "Outono"]
    assert we.season_info(utc(2026, 11, 6, 12), lat=-20.0)["hemisphere"] == "sul"


def test_season_alert_text_window():
    assert we.season_info(utc(2026, 12, 17, 12))["alert"] is None          # 4 dias antes
    assert we.season_info(utc(2026, 12, 18, 12))["alert"] == "Verão começa em 3 dias (21/12)"
    assert we.season_info(utc(2026, 12, 20, 12))["alert"] == "Verão começa amanhã (21/12)"
    assert we.season_info(utc(2026, 12, 21, 12))["alert"] == "Hoje começa o Verão"
    assert we.season_info(utc(2026, 9, 21, 12))["alert"] == "Primavera começa amanhã (22/09)"
    assert we.season_info(utc(2026, 9, 22, 12))["alert"] == "Hoje começa a Primavera"


def test_year_cycle_progress_is_continuous_across_new_year():
    s = we.season_info(utc(2027, 1, 15, 12))
    assert s["current"]["name"] == "Verão" and [c["status"] for c in s["cycle"]] == ["current", "future", "future", "future"]
    assert s["current"]["start"] == "2026-12-21"


# ----------------------------------------------------------------- Avisos
def test_pending_events_3_days_before_and_on_the_day():
    assert season_alerts.pending_events(utc(2026, 12, 17, 12)) == []
    pre = season_alerts.pending_events(utc(2026, 12, 18, 12))
    assert [(e[0], e[1], e[2]) for e in pre] == [("2026-12-21:pre", "pre", 3)]
    late = season_alerts.pending_events(utc(2026, 12, 20, 12))       # servidor parado: recupera o aviso
    assert [(e[0], e[1], e[2]) for e in late] == [("2026-12-21:pre", "pre", 1)]
    day = season_alerts.pending_events(utc(2026, 12, 21, 12))
    assert [(e[0], e[1]) for e in day] == [("2026-12-21:day", "day")]
    assert season_alerts.pending_events(utc(2026, 12, 22, 12)) == []


def test_alert_text_per_hemisphere():
    ev = season_alerts.pending_events(utc(2026, 12, 18, 12))[0]
    _, kind, days, k, day = ev
    assert season_alerts.alert_text(kind, days, k, day, "sul")[1].startswith("☀️ Verão começa em 3 dias (21/12)")
    assert season_alerts.alert_text(kind, days, k, day, "norte")[1].startswith("❄️ Inverno começa em 3 dias (21/12)")
    ev = season_alerts.pending_events(utc(2026, 9, 22, 12))[0]
    assert "Hoje começa a Primavera" in season_alerts.alert_text(ev[1], ev[2], ev[3], ev[4], "sul")[1]


@pytest.fixture()
def users(app):
    from extensions import db
    from models import User, utcnow
    with app.app_context():
        for n, lat in (("ana", None), ("beto", 48.8)):
            u = User(username=n, email=f"{n}@example.com", last_seen_at=utcnow(), location_lat=lat)
            u.set_password("senha1234")
            db.session.add(u)
        db.session.commit()


def test_run_season_alerts_once_per_user(app, users):
    from models import Notification, SeasonAlert, User
    now = utc(2026, 12, 18, 12)               # 09h em Brasília, 3 dias antes
    assert season_alerts.run_season_alerts(app, now=now) == 2
    assert season_alerts.run_season_alerts(app, now=now) == 0                       # não repete
    assert season_alerts.run_season_alerts(app, now=now + timedelta(hours=5)) == 0
    with app.app_context():
        ana = User.query.filter_by(username="ana").one()
        beto = User.query.filter_by(username="beto").one()
        na = Notification.query.filter_by(recipient_id=ana.id).one()
        nb = Notification.query.filter_by(recipient_id=beto.id).one()
        assert na.kind == "season" and "Verão" in na.verb and nb.kind == "season" and "Inverno" in nb.verb
        assert na.is_read is False and ana.unread_notifications_count == 1
        assert SeasonAlert.query.count() == 2
    # no dia: um segundo aviso, diferente
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 21, 12)) == 2
    with app.app_context():
        assert Notification.query.filter_by(kind="season").count() == 4


def test_run_season_alerts_waits_until_8am(app, users):
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 18, 6)) == 0      # 03h em Brasília
    assert season_alerts.run_season_alerts(app, now=utc(2026, 12, 18, 11)) == 2     # 08h


def test_nothing_to_send_on_ordinary_day(app, users):
    assert season_alerts.run_season_alerts(app, now=utc(2026, 11, 6, 12)) == 0


def test_api_seasons_and_notification_payload(app, users):
    from extensions import db
    from models import ApiToken, User
    with app.app_context():
        h = {"Authorization": f"Bearer {ApiToken.generate_for(User.query.filter_by(username='ana').one()).token}"}
        db.session.commit()
    c = app.test_client()
    assert c.get("/api/v1/widgets/seasons").status_code == 401
    d = c.get("/api/v1/widgets/seasons", headers=h).get_json()
    assert d["hemisphere"] == "sul" and len(d["cycle"]) == 4 and {"current", "next", "year_progress"} <= d.keys()
    assert "seasons" in [w["id"] for w in c.get("/api/v1/widgets", headers=h).get_json()["widgets"]]
    season_alerts.run_season_alerts(app, now=utc(2026, 12, 21, 12))
    n = c.get("/api/v1/notifications", headers=h).get_json()["notifications"][0]
    assert n["kind"] == "season" and n["verb"].startswith("☀️ Hoje começa o Verão")


def test_widgets_page_for_mobile(app):
    # no celular o painel da direita não existe: a página /widgets traz o painel (com Estações) dentro do conteúdo
    from extensions import db
    from models import User
    with app.app_context():
        u = User(username="wp_user", email="wp@x.com")
        u.set_password("senha1234")
        db.session.add(u); db.session.commit()
    c = app.test_client()
    assert c.get("/widgets").status_code in (301, 302, 401)  # sem login
    c.post("/login", data={"identifier": "wp_user", "password": "senha1234"})
    r = c.get("/widgets")
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and 'id="rail-widgets"' in html and "widgets-page" in html
    assert html.count('id="rail"') == 1  # o painel não aparece duas vezes


# ----------------------------------------------------------------- nascer/pôr da Lua e eclipses
def test_eclipses_match_known_dates():
    import moon_astro
    got = {(e["kind"], e["type"], e["when"].strftime("%Y-%m-%d %H:%M")) for e in moon_astro.next_eclipses(utc(2026, 1, 1), 8)}
    # datas/horas (UT) publicadas pela NASA, com folga de 2 min
    known = [("solar", "anular", utc(2026, 2, 17, 12, 12)), ("lunar", "total", utc(2026, 3, 3, 11, 33)),
             ("solar", "total", utc(2026, 8, 12, 17, 46)), ("lunar", "parcial", utc(2026, 8, 28, 4, 13)),
             ("solar", "anular", utc(2027, 2, 6, 15, 59)), ("solar", "total", utc(2027, 8, 2, 10, 7))]
    evs = moon_astro.next_eclipses(utc(2026, 1, 1), 8)
    for kind, typ, when in known:
        assert any(e["kind"] == kind and e["type"] == typ and abs((e["when"] - when).total_seconds()) < 120 for e in evs), (kind, typ, when)


def test_next_eclipse_in_moon_phase():
    m = we.moon_phase(utc(2026, 11, 9, 15), lat=-20.67, lng=-40.5, place="Guarapari")
    ecl = m["eclipses"]
    assert len(ecl) == 3 and ecl[0]["date"] == "2027-02-06" and ecl[0]["kind"] == "solar" and ecl[0]["visible_here"] is None
    assert ecl[1]["kind"] == "lunar" and ecl[1]["visible_here"] in (True, False) and "magnitude" in ecl[1]
    assert [e["days"] for e in ecl] == sorted(e["days"] for e in ecl) and ecl[0]["days"] > 0


def test_moon_rise_set_plausible():
    m = we.moon_phase(utc(2026, 11, 9, 15), lat=-20.67, lng=-40.5, place="Guarapari")
    rs = m["rise_set"]
    assert rs["place"] == "Guarapari" and rs["approximate"] is False
    # Lua nova (9/nov): nasce perto do nascer do Sol (~5h) e se põe perto do pôr do Sol (~18h), em Brasília
    assert "04:00" <= rs["rise"] <= "06:00" and "17:30" <= rs["set"] <= "19:30"
    assert rs["up_now"] is True and rs["next"]["label"] == "Se põe" and rs["next"]["today"] is True


def test_full_moon_rises_near_sunset():
    import moon_astro
    r = moon_astro.moon_rise_set(date(2026, 11, 24), -20.67, -40.5)
    assert 17 <= r["rise"].hour <= 19  # cheia nasce ao anoitecer


def test_moon_rise_set_without_place_uses_brasilia():
    rs = we.moon_phase(utc(2026, 11, 9, 15))["rise_set"]
    assert rs["approximate"] is True and rs["place"] == "Brasília"


def test_moon_endpoint_has_rise_set_and_eclipses(app):
    from extensions import db
    from models import User
    with app.app_context():
        u = User(username="moon_user", email="moon@x.com")
        u.set_password("senha1234")
        u.location = "Guarapari"
        u.location_lat, u.location_lng = -20.67, -40.5
        db.session.add(u); db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": "moon_user", "password": "senha1234"})
    d = c.get("/api/v1/widgets/moon").get_json()
    assert d["rise_set"]["place"] == "Guarapari" and d["rise_set"]["approximate"] is False
    assert len(d["eclipses"]) == 3 and d["phase"]  # campos antigos continuam


# ----------------------------------------------------------------- calendário: "hoje" no fuso do usuário
def test_calendar_today_follows_user_timezone():
    now = utc(2026, 11, 10, 2, 13)  # 23:13 de 9/nov em Brasília
    assert we.month_calendar(now=now)["today"] == "2026-11-09"                                # padrão: Brasília
    assert we.month_calendar(now=now, tz="America/Sao_Paulo")["today"] == "2026-11-09"
    assert we.month_calendar(now=now, tz="Asia/Tokyo")["today"] == "2026-11-10"
    assert we.month_calendar(now=now, tz="Pacific/Auckland")["today"] == "2026-11-10"
    assert we.month_calendar(now=now, tz="America/Los_Angeles")["today"] == "2026-11-09"
    assert we.month_calendar(now=now, tz_offset=540)["today"] == "2026-11-10"                  # app: UTC+9
    assert we.month_calendar(now=now, tz_offset=-180)["today"] == "2026-11-09"
    for bad in ("Nao/Existe", "../etc/passwd", "x" * 90, "", None):
        assert we.month_calendar(now=now, tz=bad)["today"] == "2026-11-09"                      # inválido: Brasília
    assert we.month_calendar(now=now, tz_offset=99999)["today"] == "2026-11-09"


def test_calendar_nov_2026_days_and_holidays():
    d = we.month_calendar(2026, 11, now=utc(2026, 11, 10, 2, 13))
    assert d["first_weekday"] == 0 and d["days_in_month"] == 30  # 1/nov/2026 é domingo
    assert [(h["day"], h["name"]) for h in d["holidays"]] == [(2, "Finados"), (15, "Proclamação da República"), (20, "Consciência Negra")]
    assert date(2026, 11, 15).weekday() == 6  # 15/11 cai num domingo


def test_rail_blocks_browser_translation(app):
    from extensions import db
    from models import User
    with app.app_context():
        u = User(username="tr_user", email="tr@x.com")
        u.set_password("senha1234")
        db.session.add(u); db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": "tr_user", "password": "senha1234"})
    html = c.get("/widgets").get_data(as_text=True)
    assert 'id="rail" translate="no"' in html and "notranslate" in html
    js = open("static/js/rail-new.js", encoding="utf-8").read()
    assert 'grid.setAttribute("translate", "no")' in js and "resolvedOptions().timeZone" in js


# ----------------------------------------------------------------- parte 2: feriados por país
def _hol(code, year=2026):
    import holidays_world as hw
    return {d.isoformat(): n for d, (n, k) in hw.holidays_for(code, year).items()}


def test_holidays_world_known_2026_dates():
    us = _hol("US")
    assert us["2026-01-19"] == "Dia de Martin Luther King Jr." and us["2026-02-16"] == "Dia dos Presidentes"
    assert us["2026-05-25"] == "Memorial Day" and us["2026-06-19"] == "Juneteenth" and us["2026-09-07"] == "Dia do Trabalho"
    assert us["2026-10-12"].startswith("Dia de Colombo") and us["2026-11-26"] == "Ação de Graças"
    gb = _hol("GB")
    assert gb["2026-04-06"] == "Segunda-feira de Páscoa" and gb["2026-05-04"].startswith("Early May")
    assert gb["2026-05-25"].startswith("Spring") and gb["2026-08-31"].startswith("Summer") and gb["2026-12-26"] == "Boxing Day"
    de, fr = _hol("DE"), _hol("FR")
    assert de["2026-04-03"] == "Sexta-feira Santa" and de["2026-05-14"] == "Ascensão" and de["2026-05-25"].startswith("Segunda-feira de Pent")
    assert fr["2026-05-14"] == "Ascensão" and fr["2026-07-14"] == "Festa Nacional"
    jp = _hol("JP")
    assert jp["2026-03-20"] == "Equinócio da Primavera" and jp["2026-09-23"] == "Equinócio de Outono"
    assert jp["2026-01-12"] == "Dia da Maioridade" and jp["2026-07-20"] == "Dia do Mar" and jp["2026-10-12"] == "Dia do Esporte"
    ca = _hol("CA")
    assert ca["2026-05-18"] == "Dia da Rainha Vitória" and ca["2026-10-12"] == "Ação de Graças" and ca["2026-09-07"] == "Dia do Trabalho"
    mx = _hol("MX")
    assert mx["2026-02-02"] == "Dia da Constituição" and mx["2026-03-16"].startswith("Natalício") and mx["2026-11-16"] == "Dia da Revolução"
    au = _hol("AU")
    assert au["2026-04-03"] == "Sexta-feira Santa" and au["2026-04-04"] == "Sábado de Páscoa" and au["2026-04-06"].startswith("Segunda")
    pt = _hol("PT")
    assert pt["2026-06-04"] == "Corpo de Deus" and pt["2026-04-25"] == "Dia da Liberdade" and pt["2026-10-05"] == "Implantação da República"
    assert _hol("BR")["2026-11-15"] == "Proclamação da República"


def test_holidays_world_all_countries_all_years():
    import holidays_world as hw
    for code in hw.COUNTRIES:
        for y in (1990, 2024, 2026, 2030, 2099):
            hol = hw.holidays_for(code, y)
            assert hol and all(d.year == y for d in hol)  # nenhuma data escapa do ano (inclui Páscoa e equinócios)


def test_country_resolution_from_tz_and_choice():
    import holidays_world as hw
    assert hw.resolve_country(None, "Europe/Lisbon") == ("PT", False)
    assert hw.resolve_country(None, "America/New_York") == ("US", False)
    assert hw.resolve_country(None, "America/Argentina/Cordoba") == ("AR", False)
    assert hw.resolve_country(None, "America/Toronto") == ("CA", False)
    assert hw.resolve_country(None, "Australia/Perth") == ("AU", False)
    assert hw.resolve_country(None, "America/Sao_Paulo") == ("BR", False)
    assert hw.resolve_country(None, "Pacific/Honolulu") == ("US", False)
    assert hw.resolve_country(None, "Africa/Lagos") == ("BR", False)      # sem tabela: padrão do site
    assert hw.resolve_country("jp", "America/Sao_Paulo") == ("JP", True)  # escolha manual vence o fuso
    for bad in ("XX", "BRA", "1", "", None, "../"):
        assert hw.resolve_country(bad, None)[0] == "BR"


def test_month_calendar_country_fields():
    now = utc(2026, 11, 26, 15)
    d = we.month_calendar(2026, 11, now=now, tz="America/New_York")
    assert d["country"] == "US" and d["country_chosen"] is False and (26, "Ação de Graças") in [(h["day"], h["name"]) for h in d["holidays"]]
    d = we.month_calendar(2026, 11, now=now, tz="America/New_York", country="BR")
    assert d["country"] == "BR" and d["country_chosen"] is True and [h["day"] for h in d["holidays"]] == [2, 15, 20]
    assert d["countries"][0] == {"code": "BR", "name": "Brasil"} and len(d["countries"]) == 13
    assert we.month_calendar(2026, 11, now=now)["country"] == "BR"  # sem fuso nem escolha


def test_calendar_endpoint_country_param(app):
    from extensions import db
    from models import User
    with app.app_context():
        u = User(username="cal_user", email="cal@x.com")
        u.set_password("senha1234")
        db.session.add(u); db.session.commit()
    c = app.test_client()
    c.post("/login", data={"identifier": "cal_user", "password": "senha1234"})
    d = c.get("/api/v1/widgets/calendar?year=2026&month=7&tz=Asia/Tokyo").get_json()
    assert d["country"] == "JP" and [h["day"] for h in d["holidays"]] == [20]  # Dia do Mar
    d = c.get("/api/v1/widgets/calendar?year=2026&month=7&tz=Asia/Tokyo&country=US").get_json()
    assert d["country"] == "US" and [h["day"] for h in d["holidays"]] == [4]
    js = open("static/js/rail-new.js", encoding="utf-8").read()
    assert "driqy.cal.country" in js and "País dos feriados" in js
