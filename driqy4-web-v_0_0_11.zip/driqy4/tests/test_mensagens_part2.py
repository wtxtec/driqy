"""Mensagens — parte 2: painel de Configurações (estilo Telegram) dentro de Mensagens."""
import pathlib
import pytest
from test_ping_phase7 import site  # noqa: F401  (fixture: usuária 'ana' logada, conversa com 'beto')


def _read(p):
    return pathlib.Path(p).read_text(encoding="utf-8")


@pytest.mark.parametrize("url", ["/mensagens/", "/mensagens/beto", "/mensagens/contatos", "/mensagens/chamadas"])
def test_settings_panel_on_every_mensagens_page(site, url):
    html = site.get(url).get_data(as_text=True)
    assert 'id="ping-settings"' in html and 'id="ping-settings-back"' in html
    for view in ("home", "notif", "privacy", "appearance"):
        assert f'data-view="{view}"' in html, view
    # o painel mora na coluna da lista; o menu lateral fica fora dela
    assert html.index('id="ping-settings"') < html.index('id="ping-drawer-wrap"')


def test_each_setting_id_exists_exactly_once(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    for needle in ('id="chat-privacy-toggle"', 'id="setting-sound"', 'id="setting-volume"', 'id="ping-settings-open"'):
        assert html.count(needle) == 1, needle
    for sound in ("padrao", "ding", "pop"):
        assert f'data-sound="{sound}"' in html
    assert 'class="theme-option"' in html


def test_drawer_no_longer_holds_loose_settings(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    drawer = html[html.index('id="ping-drawer-wrap"'):]
    assert "ping-drawer-toggle" not in drawer and "ping-drawer-theme" not in drawer
    assert "Configurações" in drawer and 'id="ping-settings-open"' in drawer


def test_old_settings_url_opens_the_panel(site):
    r = site.get("/mensagens/configuracoes")
    assert r.status_code == 302 and r.headers["Location"].endswith("/mensagens/#configuracoes")


def test_privacy_toggle_still_wired_to_api(site):
    html = site.get("/mensagens/").get_data(as_text=True)
    i = html.index('id="chat-privacy-toggle"')
    tag = html[i:html.index(">", i)]
    assert 'data-url="/api/' in tag and "privacy" in tag and "checked" in tag


def test_js_and_css_hooks():
    shell, st, css = _read("static/js/ping-shell.js"), _read("static/js/settings.js"), _read("static/css/style.css")
    assert "openSettings" in shell and "#configuracoes" in shell and "ping-settings-open" in shell
    for needle in ("driqy-msg-sound-choice", "driqy-msg-volume", "previewMessageSound", "messageChoice", "_playDing"):
        assert needle in st, needle
    for needle in (".ping-settings {", ".ping-set-row", ".ping-set-card", ".ping-list-col.is-settings"):
        assert needle in css, needle
    assert ".ping-drawer-toggle" not in css and ".ping-drawer-theme" not in css
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", _read("static/sw.js")).group(1)) >= 57  # versão do cache do SW só pode subir
