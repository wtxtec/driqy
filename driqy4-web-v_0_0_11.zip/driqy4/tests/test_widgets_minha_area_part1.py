"""Minha área, Parte 1: widgets próprios (CRUD + validação), preferências com ids custom e
os 10 widgets novos (dados do servidor)."""
from datetime import datetime, timedelta, timezone

import pytest


@pytest.fixture()
def world(app):
    from extensions import db as _db
    from models import ApiToken, Follow, Post, User, utcnow
    with app.app_context():
        U = {}
        for n in ("ana", "beto", "caio"):
            u = User(username=n, email=f"{n}@example.com", last_seen_at=utcnow())
            u.set_password("senha1234")
            _db.session.add(u)
            U[n] = u
        _db.session.commit()
        ta, tb = ApiToken.generate_for(U["ana"]), ApiToken.generate_for(U["beto"])
        _db.session.commit()
        _db.session.add(Follow(follower_id=U["ana"].id, followed_id=U["beto"].id))
        _db.session.add(Follow(follower_id=U["caio"].id, followed_id=U["ana"].id))
        now = utcnow()
        _db.session.add(Post(user_id=U["beto"].id, post_type="text", text_content="some logo", duration_minutes=60,
                             created_at=now))
        _db.session.add(Post(user_id=U["beto"].id, post_type="text", text_content="fica uma semana",
                             duration_minutes=60 * 24 * 7, created_at=now))
        _db.session.add(Post(user_id=U["beto"].id, post_type="text", text_content="permanente", duration_minutes=0))
        _db.session.add(Post(user_id=U["caio"].id, post_type="text", text_content="não sigo o caio", duration_minutes=30))
        _db.session.commit()
        return {"a": {"Authorization": f"Bearer {ta.token}"}, "b": {"Authorization": f"Bearer {tb.token}"}}


def call(app, method, path, h, **kw):
    return getattr(app.test_client(), method)(f"/api/v1/widgets/{path}", headers=h, **kw)


# ----------------------------------------------------------------- widgets próprios
def test_custom_crud(app, world):
    r = call(app, "post", "custom", world["a"], json={"kind": "checklist", "title": "  Compras  ",
                                                      "data": {"items": [{"text": "pão"}, {"text": "  "}, {"text": "leite", "done": 1}]}})
    assert r.status_code == 201
    w = r.get_json()["widget"]
    assert w["id"] == f"custom:{w['widget_id']}" and w["title"] == "Compras" and w["kind"] == "checklist"
    assert [i["text"] for i in w["data"]["items"]] == ["pão", "leite"] and w["data"]["items"][1]["done"] is True
    assert all(i["id"] for i in w["data"]["items"])
    wid = w["widget_id"]
    r = call(app, "put", f"custom/{wid}", world["a"], json={"title": "Mercado", "data": {"items": [{"id": "x1", "text": "ovo"}]}})
    assert r.get_json()["widget"]["title"] == "Mercado" and r.get_json()["widget"]["data"]["items"][0]["id"] == "x1"
    assert call(app, "get", f"custom/{wid}", world["a"]).status_code == 200
    lst = call(app, "get", "custom", world["a"]).get_json()
    assert len(lst["widgets"]) == 1 and lst["max"] == 12 and {k["kind"] for k in lst["kinds"]} == {
        "note", "checklist", "links", "countdown", "counter"}
    assert call(app, "delete", f"custom/{wid}", world["a"]).get_json() == {"ok": True}
    assert call(app, "get", f"custom/{wid}", world["a"]).status_code == 404


def test_custom_is_private(app, world):
    wid = call(app, "post", "custom", world["a"], json={"kind": "note", "data": {"text": "segredo"}}).get_json()["widget"]["widget_id"]
    for m in ("get", "delete"):
        assert call(app, m, f"custom/{wid}", world["b"]).status_code == 404
    assert call(app, "put", f"custom/{wid}", world["b"], json={"title": "x"}).status_code == 404
    assert call(app, "get", "custom", world["b"]).get_json()["widgets"] == []


def test_custom_validation(app, world):
    h = world["a"]
    bad = [
        {"kind": "nope"},
        {"kind": "note", "data": {"text": "x" * 2001}},
        {"kind": "links", "data": {"links": [{"url": "javascript:alert(1)"}]}},
        {"kind": "links", "data": {"links": [{"url": "ftp://x.com"}]}},
        {"kind": "links", "data": {"links": [{"url": "https://a b.com"}]}},
        {"kind": "countdown", "data": {"date": "31/12/2026"}},
        {"kind": "checklist", "data": {"items": [{"text": "a"}] * 51}},
    ]
    for body in bad:
        assert call(app, "post", "custom", h, json=body).status_code == 400, body
    ok = call(app, "post", "custom", h, json={"kind": "links", "data": {"links": [{"title": "", "url": "www.exemplo.com/x"}]}}).get_json()["widget"]
    assert ok["data"]["links"] == [{"title": "exemplo.com", "url": "https://www.exemplo.com/x"}]
    c = call(app, "post", "custom", h, json={"kind": "counter", "data": {"value": "5", "step": 0, "goal": "", "unit": "copos"}}).get_json()["widget"]
    assert c["data"] == {"value": 5, "step": 1, "goal": None, "unit": "copos"}
    d = call(app, "post", "custom", h, json={"kind": "countdown", "title": "", "data": {"label": "Viagem", "date": "2027-01-10"}}).get_json()["widget"]
    assert d["title"] == "Contagem" and d["data"]["date"] == "2027-01-10"
    # tipo é imutável e dados são validados pelo tipo do widget
    assert call(app, "put", f"custom/{c['widget_id']}", h, json={"data": {"value": 10 ** 9}}).get_json()["widget"]["data"]["value"] == 999999


def test_custom_limit(app, world):
    app.config["MAX_USER_WIDGETS"] = 2
    for _ in range(2):
        assert call(app, "post", "custom", world["a"], json={"kind": "note"}).status_code == 201
    r = call(app, "post", "custom", world["a"], json={"kind": "note"})
    assert r.status_code == 400 and "Limite" in r.get_json()["error"]
    assert call(app, "post", "custom", world["b"], json={"kind": "note"}).status_code == 201


def test_session_needs_header_for_writes(app, world):
    from extensions import db as _db
    from models import User
    c = app.test_client()
    with app.app_context():
        uid = User.query.filter_by(username="ana").first().id
    with c.session_transaction() as s:
        s["_user_id"] = str(uid)
        s["_fresh"] = True
    assert c.post("/api/v1/widgets/custom", json={"kind": "note"}).status_code == 400
    assert c.post("/api/v1/widgets/custom", json={"kind": "note"}, headers={"X-Requested-With": "fetch"}).status_code == 201


# ----------------------------------------------------------------- preferências
def test_prefs_know_custom_widgets(app, world):
    h = world["a"]
    wid = call(app, "post", "custom", h, json={"kind": "note"}).get_json()["widget"]["id"]
    lst = call(app, "get", "", h).get_json() if False else app.test_client().get("/api/v1/widgets", headers=h).get_json()
    assert wid in [w["id"] for w in lst["all_widgets"]] and wid in lst["prefs"]["order"]
    assert len(lst["all_widgets"]) == 17 and "data" not in [w for w in lst["all_widgets"] if w["id"] == wid][0]
    r = call(app, "post", "prefs", h, json={"order": [wid, "news"], "disabled": ["weather", wid, "custom:999", "zz"]}).get_json()
    assert r["prefs"]["order"][:2] == [wid, "news"] and r["prefs"]["disabled"] == ["weather", wid]
    # outro usuário não pode referenciar o id do primeiro
    r = call(app, "post", "prefs", world["b"], json={"order": [wid]}).get_json()
    assert wid not in r["prefs"]["order"]
    # apagar o widget limpa das preferências
    wnum = int(wid.split(":")[1])
    call(app, "delete", f"custom/{wnum}", h)
    prefs = call(app, "get", "prefs", h).get_json()["prefs"]
    assert wid not in prefs["order"] and wid not in prefs["disabled"]


def test_default_order_has_16_builtin(app, world):
    p = call(app, "get", "prefs", world["a"]).get_json()["prefs"]
    assert p["order"][:5] == ["weather", "trending", "news", "vortex", "online"] and len(p["order"]) == 16
    assert p["order"][5:] == ["clock", "calendar", "moon", "seasons", "quotes", "stats", "expiring", "phrase", "pomodoro", "calc", "breathe"]


# ----------------------------------------------------------------- widgets novos
def test_clock(app, world):
    from widgets_extra import world_clock
    now = datetime(2026, 11, 2, 15, 0, tzinfo=timezone.utc)  # sem horário de verão no Brasil
    r = world_clock(now=now)
    by = {c["id"]: c for c in r["cities"]}
    assert by["America/Sao_Paulo"]["local"] == "2026-11-02T12:00:00" and by["America/Sao_Paulo"]["utc_label"] == "UTC-3"
    assert by["Asia/Tokyo"]["local"] == "2026-11-03T00:00:00" and by["Asia/Tokyo"]["day_offset"] == 1
    assert by["America/New_York"]["offset_minutes"] == -300  # EST depois de 1º/nov
    assert world_clock(["Asia/Tokyo", "bobagem", "Asia/Tokyo"], now=now)["cities"][0]["id"] == "Asia/Tokyo"
    assert len(world_clock(["bobagem"], now=now)["cities"]) == 5
    j = call(app, "get", "clock?zones=Europe/Paris", world["a"]).get_json()
    assert j["ok"] and [c["id"] for c in j["cities"]] == ["Europe/Paris"] and len(j["available"]) == 10


def test_calendar_and_holidays(app, world):
    from datetime import date
    import widgets_extra as x
    assert x.easter(2026) == date(2026, 4, 5) and x.easter(2024) == date(2024, 3, 31) and x.easter(2025) == date(2025, 4, 20)
    h = x.holidays(2026)
    assert h[date(2026, 2, 17)] == ("Carnaval", "facultativo") and h[date(2026, 4, 3)][0] == "Sexta-feira Santa"
    assert h[date(2026, 6, 4)] == ("Corpus Christi", "facultativo") and h[date(2026, 4, 5)][1] == "data"
    assert date(2023, 11, 20) not in x.holidays(2023) and date(2024, 11, 20) in x.holidays(2024)
    c = x.month_calendar(2026, 11, now=datetime(2026, 11, 2, 12, tzinfo=timezone.utc))
    assert c["days_in_month"] == 30 and c["first_weekday"] == 0 and c["today"] == "2026-11-02"  # 1/nov/2026 = domingo
    assert [(d["day"], d["name"]) for d in c["holidays"]] == [(2, "Finados"), (15, "Proclamação da República"), (20, "Consciência Negra")]
    assert x.month_calendar(2024, 2)["days_in_month"] == 29 and x.month_calendar(2026, 12)["days_in_month"] == 31
    j = call(app, "get", "calendar?year=9999&month=13", world["a"]).get_json()
    assert 1900 <= j["year"] <= 2200 and 1 <= j["month"] <= 12  # entrada ruim cai em hoje


def test_moon(app, world):
    from widgets_extra import moon_phase
    new = moon_phase(datetime(2000, 1, 6, 18, 14, tzinfo=timezone.utc))
    assert new["phase"] == "Lua nova" and new["illumination"] == 0
    full = moon_phase(datetime(2026, 11, 24, 14, 0, tzinfo=timezone.utc))  # cheia real: 24/nov/2026 ~14h UTC
    assert full["phase"] == "Lua cheia" and full["illumination"] >= 98
    m = moon_phase(datetime(2026, 11, 2, 12, tzinfo=timezone.utc))
    assert 0 <= m["age_days"] < 29.6 and m["next_full"] > "2026-11-02" and 0 <= m["days_to_full"] <= 30
    assert call(app, "get", "moon", world["a"]).get_json()["phase"]


class _Resp:
    def __init__(self, data, status=200):
        self._d, self.status_code = data, status

    def json(self):
        return self._d

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError("http")


QUOTES = {"USDBRL": {"bid": "5.41", "pctChange": "-0.3", "high": "5.5", "low": "5.4"},
          "EURBRL": {"bid": "6.2", "pctChange": "0.1", "high": "6.3", "low": "6.1"},
          "BTCBRL": {"bid": "bobagem"}}


def test_quotes_cache_stale_and_errors(app, world, monkeypatch):
    import widgets_extra as x
    x._QUOTES_CACHE._store.clear()
    x._LAST_GOOD.clear()
    calls = []
    state = {"ok": True}

    def fake(url, timeout=None):
        calls.append(url)
        if not state["ok"]:
            raise RuntimeError("sem rede")
        return _Resp(QUOTES)

    monkeypatch.setattr(x.requests, "get", fake)
    r = call(app, "get", "quotes", world["a"]).get_json()
    assert r["ok"] and [i["code"] for i in r["items"]] == ["USD", "EUR"] and r["items"][0]["value"] == 5.41  # BTC inválido some
    assert r["items"][0]["change_pct"] == -0.3 and r["stale"] is False
    call(app, "get", "quotes", world["a"])
    assert len(calls) == 1  # cache
    x._QUOTES_CACHE._store.clear()
    state["ok"] = False
    r = call(app, "get", "quotes", world["a"]).get_json()
    assert r["ok"] and r["stale"] is True  # serve a última boa
    x._LAST_GOOD.clear()
    assert call(app, "get", "quotes", world["a"]).get_json() == {"ok": False, "reason": "unavailable"}
    app.config["QUOTES_ENABLED"] = False
    assert call(app, "get", "quotes", world["a"]).get_json()["reason"] == "disabled"


def test_stats(app, world):
    j = call(app, "get", "stats", world["a"]).get_json()
    assert (j["followers"], j["following"], j["new_followers_7d"], j["posts_live"], j["posts_total"]) == (1, 1, 1, 0, 0)
    b = call(app, "get", "stats", world["b"]).get_json()
    assert b["posts_total"] == 3 and b["posts_live"] == 3 and b["followers"] == 1


def test_expiring(app, world):
    j = call(app, "get", "expiring", world["a"]).get_json()["posts"]
    assert [p["snippet"] for p in j] == ["some logo"]  # só temporário < 48 h, de quem a ana segue
    assert 0 < j[0]["seconds_left"] <= 3600 and j[0]["expires_at"].endswith("Z") and j[0]["mine"] is False
    assert j[0]["author"]["username"] == "beto"
    mine = call(app, "get", "expiring", world["b"]).get_json()["posts"]
    assert [p["mine"] for p in mine] == [True]


def test_phrase(app, world):
    import widgets_extra as x
    a = x.phrase_of_the_day(datetime(2026, 11, 2, 12, tzinfo=timezone.utc))
    assert a == x.phrase_of_the_day(datetime(2026, 11, 2, 20, tzinfo=timezone.utc))  # estável no dia
    assert a != x.phrase_of_the_day(datetime(2026, 11, 3, 12, tzinfo=timezone.utc))
    assert all(t and len(t) < 90 for t, _a in x.PHRASES) and len({t for t, _a in x.PHRASES}) == len(x.PHRASES)
    assert call(app, "get", "phrase", world["a"]).get_json()["text"]


def test_new_routes_require_login(app):
    c = app.test_client()
    for p in ("clock", "calendar", "moon", "seasons", "quotes", "stats", "expiring", "phrase", "custom"):
        assert c.get(f"/api/v1/widgets/{p}").status_code == 401
