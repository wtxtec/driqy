"""Chat rico — Fase 5: áudio (assinatura, MIME, duração)."""
import io

import pytest

OGG = b"OggS\x00\x02" + b"\x00" * 64
WEBM = b"\x1a\x45\xdf\xa3" + b"\x00" * 64
M4A = b"\x00\x00\x00\x20ftypM4A " + b"\x00" * 64
WAV = b"RIFF\x00\x00\x00\x00WAVE" + b"\x00" * 32
MP3 = b"ID3\x03\x00" + b"\x00" * 64


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _send(c, headers, data, name, mimetype=None, **form):
    f = (io.BytesIO(data), name, mimetype) if mimetype else (io.BytesIO(data), name)
    return c.post("/api/v1/messages/beto", headers=headers,
                  data={"file": f, **form}, content_type="multipart/form-data")


@pytest.mark.parametrize("data,name,mt,mime", [
    (OGG, "a.ogg", "audio/ogg", "audio/ogg"),
    (WEBM, "a.webm", "audio/webm", "audio/webm"),
    (M4A, "a.m4a", "audio/mp4", "audio/mp4"),
    (WAV, "a.wav", "audio/wav", "audio/wav"),
    (MP3, "a.mp3", "audio/mpeg", "audio/mpeg"),
])
def test_audio_mime_from_signature(app, users, data, name, mt, mime):
    r = _send(app.test_client(), users[0], data, name, mt, duration_ms="4200")
    assert r.status_code == 200
    j = r.get_json()
    assert j["msg_type"] == "audio"
    assert j["media_mime"] == mime
    assert j["media_duration_ms"] == 4200


def test_fake_audio_rejected(app, users):
    r = _send(app.test_client(), users[0], b"texto qualquer, nao e audio" * 4,
              "a.mp3", "audio/mpeg")
    assert r.status_code == 400


def test_webm_video_is_not_audio(app, users):
    r = _send(app.test_client(), users[0], WEBM, "v.webm", "video/webm")
    assert r.status_code == 200
    assert r.get_json()["msg_type"] == "video"


def test_audio_served_with_range(app, users):
    c = app.test_client()
    j = _send(c, users[0], OGG, "a.ogg", "audio/ogg").get_json()
    r = c.get(j["media_url"], headers={**users[1], "Range": "bytes=0-3"})
    assert r.status_code == 206
    assert r.data == b"OggS"


# ---- caixa de entrada da web (portada da Fase 2) ----
def _login(app, name):
    from models import User
    c = app.test_client()
    with c.session_transaction() as s:
        with app.app_context():
            s["_user_id"] = str(User.query.filter_by(username=name).first().id)
            s["_fresh"] = True
    return c


def test_web_inbox_preview_icon_ticks_and_order(app, users):
    api = app.test_client()
    # ana -> beto: áudio de 65 s; depois beto -> ana: texto (outra conversa seria mais antiga)
    j = _send(api, users[0], OGG, "a.ogg", "audio/ogg", duration_ms="65000").get_json()
    assert j["msg_type"] == "audio"
    ana = _login(app, "ana")
    html = ana.get("/mensagens/").get_data(as_text=True)
    assert "🎤 1:05" in html          # prévia com ícone + duração
    assert "conv-ticks" in html        # a última mensagem é minha: tem ticks
    upd = ana.get("/mensagens/api/atualizacoes", headers={"X-Requested-With": "fetch"}).get_json()
    assert upd["conversations"][0]["html"].count("data-partner-id") == 1
    assert 'data-sig="' in upd["conversations"][0]["html"]


def test_web_thread_page_has_mic(app, users):
    _send(app.test_client(), users[0], OGG, "a.ogg", "audio/ogg")
    html = _login(app, "ana").get("/mensagens/beto").get_data(as_text=True)
    assert 'id="cw-mic"' in html and 'id="cw-rec"' in html
