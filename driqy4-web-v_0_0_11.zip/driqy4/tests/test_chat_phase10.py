"""Chat rico — Fase 10: presença (online/visto por último), privacidade, fixar/silenciar/arquivar, push."""
import json
from datetime import timedelta

import pytest

import chat_extras as cx
from chat_events import hub


@pytest.fixture(autouse=True)
def _clean_hub():
    hub.reset()
    yield
    hub.reset()


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _uid(app, name):
    from models import User
    with app.app_context():
        return User.query.filter_by(username=name).first().id


def _open(c, headers):
    resp = c.get("/api/v1/messages/stream", headers=headers, buffered=False)
    assert resp.status_code == 200
    return resp, iter(resp.response)


def _events(it, until):
    """Lê eventos até achar `until` (devolve (nome, dados)); descarta o resto."""
    while True:
        chunk = next(it)
        if isinstance(chunk, bytes):
            chunk = chunk.decode()
        if chunk.startswith("event:"):
            lines = chunk.strip().split("\n")
            name, data = lines[0][7:], json.loads(lines[1][6:])
            if name == until:
                return name, data


def _text(c, h, to, text):
    r = c.post(f"/api/v1/messages/{to}", headers=h, json={"content": text})
    assert r.status_code == 200, r.get_data(as_text=True)
    return r.get_json()


def _talk(c, users):
    """ana <-> beto já têm conversa."""
    _text(c, users[0], "beto", "oi")
    _text(c, users[1], "ana", "e aí")


# ---------------- presença ----------------

def test_presence_online_and_offline_events(app, users):
    c = app.test_client()
    _talk(c, users)
    resp_b, it_b = _open(c, users[1])
    _events(it_b, "ready")
    resp_a, it_a = _open(c, users[0])                    # ana conecta -> beto vê "online"
    _, d = _events(it_b, "presence")
    assert d["partner"] == "ana" and d["visible"] is True and d["online"] is True
    resp_a.close()                                       # ana sai -> beto vê "offline" + horário
    _, d = _events(it_b, "presence")
    assert d["partner"] == "ana" and d["online"] is False and d["last_seen_at"].endswith("Z")
    resp_b.close()


def test_presence_second_connection_does_not_re_announce(app, users):
    c = app.test_client()
    _talk(c, users)
    resp_b, it_b = _open(c, users[1])
    _events(it_b, "ready")
    r1, _i1 = _open(c, users[0])
    _events(it_b, "presence")
    r2, _i2 = _open(c, users[0])                          # 2ª aba da ana: sem novo aviso
    r1.close()                                           # ainda sobra uma conexão: continua online
    assert hub.connections(_uid(app, "ana")) == 1
    r2.close()
    _, d = _events(it_b, "presence")
    assert d["online"] is False
    resp_b.close()


def test_presence_not_sent_to_strangers(app, users):
    c = app.test_client()
    _talk(c, users)                                       # caio não tem conversa com ana
    resp_c, it_c = _open(c, users[2])
    _events(it_c, "ready")
    r, _i = _open(c, users[0])
    r.close()
    # nada de "presence" pro caio: o próximo evento que ele recebe é o desta mensagem
    hub.publish(_uid(app, "caio"), "fim", {})
    name, _ = _events(it_c, "fim")
    assert name == "fim"
    resp_c.close()


def test_thread_and_inbox_carry_presence(app, users):
    c = app.test_client()
    _talk(c, users)
    t = c.get("/api/v1/messages/beto", headers=users[0]).get_json()
    assert t["partner"]["presence"] == {"visible": True, "online": False, "last_seen_at": None}
    assert t["prefs"] == {"pinned": False, "muted": False, "archived": False}
    rb, ib = _open(c, users[1])
    _events(ib, "ready")
    t = c.get("/api/v1/messages/beto", headers=users[0]).get_json()
    assert t["partner"]["presence"]["online"] is True
    inbox = c.get("/api/v1/messages", headers=users[0]).get_json()
    assert inbox["conversations"][0]["partner"]["presence"]["online"] is True
    rb.close()


def test_last_seen_written_on_disconnect(app, users):
    from models import User
    c = app.test_client()
    _talk(c, users)
    r, i = _open(c, users[0])
    _events(i, "ready")
    with app.app_context():
        User.query.filter_by(username="ana").update({"last_seen_at": None})
        from extensions import db
        db.session.commit()
    r.close()
    with app.app_context():
        assert User.query.filter_by(username="ana").first().last_seen_at is not None


# ---------------- privacidade ----------------

def test_privacy_get_put_validation(app, users):
    c = app.test_client()
    assert c.get("/api/v1/messages/privacy", headers=users[0]).get_json() == {"show_presence": True}
    assert c.put("/api/v1/messages/privacy", headers=users[0], json={"show_presence": "x"}).status_code == 400
    assert c.put("/api/v1/messages/privacy", headers=users[0], json={}).status_code == 400
    r = c.put("/api/v1/messages/privacy", headers=users[0], json={"show_presence": False})
    assert r.get_json() == {"show_presence": False}


def test_hiding_presence_hides_both_ways_and_announces(app, users):
    c = app.test_client()
    _talk(c, users)
    rb, ib = _open(c, users[1])
    _events(ib, "ready")
    ra, ia = _open(c, users[0])
    _events(ib, "presence")
    c.put("/api/v1/messages/privacy", headers=users[0], json={"show_presence": False})
    _, d = _events(ib, "presence")
    assert d["partner"] == "ana" and d["visible"] is False and d["online"] is False and d["last_seen_at"] is None
    # ana esconde -> beto não vê a ana...
    t = c.get("/api/v1/messages/ana", headers=users[1]).get_json()
    assert t["partner"]["presence"]["visible"] is False
    # ...e ana também não vê o beto (reciprocidade)
    t = c.get("/api/v1/messages/beto", headers=users[0]).get_json()
    assert t["partner"]["presence"] == {"visible": False, "online": False, "last_seen_at": None}
    ra.close(); rb.close()


def test_presence_payload_unit(app, users):
    from models import User, utcnow
    with app.app_context():
        a = User.query.filter_by(username="ana").first()
        b = User.query.filter_by(username="beto").first()
        b.last_seen_at = utcnow() - timedelta(seconds=30)
        assert cx.presence_payload(b, a)["online"] is False                    # sem stream: não é online
        assert cx.presence_payload(b, a, sse_enabled=False)["online"] is True  # sem tempo real: requisição recente
        assert cx.presence_payload(None, a)["visible"] is False


# ---------------- fixar / silenciar / arquivar ----------------

def _convs(c, h, archived=False):
    url = "/api/v1/messages" + ("?archived=1" if archived else "")
    return c.get(url, headers=h).get_json()


def test_prefs_validation_and_unknown(app, users):
    c = app.test_client()
    _talk(c, users)
    assert c.put("/api/v1/messages/beto/prefs", headers=users[0], json={}).status_code == 400
    assert c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": "sim"}).status_code == 400
    assert c.put("/api/v1/messages/ana/prefs", headers=users[0], json={"pinned": True}).status_code == 400
    assert c.put("/api/v1/messages/nao_existe/prefs", headers=users[0], json={"pinned": True}).status_code == 404
    r = c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"muted": True})
    assert r.get_json() == {"pinned": False, "muted": True, "archived": False}
    assert c.get("/api/v1/messages/beto/prefs", headers=users[0]).get_json()["muted"] is True
    # só vale para quem configurou
    assert c.get("/api/v1/messages/ana/prefs", headers=users[1]).get_json()["muted"] is False


def test_pinned_first_and_limit(app, users):
    c = app.test_client()
    app.config["CHAT_MAX_PINNED"] = 1
    _text(c, users[0], "beto", "1")
    _text(c, users[0], "caio", "2")          # caio é a conversa mais recente
    first = _convs(c, users[0])["conversations"][0]["partner"]["username"]
    assert first == "caio"
    assert c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": True}).status_code == 200
    convs = _convs(c, users[0])["conversations"]
    assert [x["partner"]["username"] for x in convs] == ["beto", "caio"] and convs[0]["prefs"]["pinned"]
    r = c.put("/api/v1/messages/caio/prefs", headers=users[0], json={"pinned": True})
    assert r.status_code == 400 and "1" in r.get_json()["error"]
    # repetir a fixação da mesma conversa não conta como outra
    assert c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": True}).status_code == 200
    # desafixar volta à ordem por data
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": False})
    assert _convs(c, users[0])["conversations"][0]["partner"]["username"] == "caio"


def test_newest_pin_goes_on_top(app, users):
    c = app.test_client()
    _text(c, users[0], "beto", "1")
    _text(c, users[0], "caio", "2")
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": True})
    c.put("/api/v1/messages/caio/prefs", headers=users[0], json={"pinned": True})
    names = [x["partner"]["username"] for x in _convs(c, users[0])["conversations"]]
    assert names == ["caio", "beto"]


def test_archive_hides_from_main_list_and_unpins(app, users):
    c = app.test_client()
    _talk(c, users)
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": True})
    r = c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"archived": True})
    assert r.get_json() == {"pinned": False, "muted": False, "archived": True}
    main = _convs(c, users[0])
    assert main["conversations"] == [] and main["archived_count"] == 1
    arch = _convs(c, users[0], archived=True)
    assert [x["partner"]["username"] for x in arch["conversations"]] == ["beto"]
    # fixar tira do arquivo
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": True})
    assert _convs(c, users[0])["archived_count"] == 0
    # o outro lado não é afetado
    assert len(_convs(c, users[1])["conversations"]) == 1


def test_new_message_unarchives_unless_muted(app, users):
    c = app.test_client()
    _talk(c, users)
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"archived": True})
    _text(c, users[1], "ana", "volta!")
    assert _convs(c, users[0])["conversations"][0]["partner"]["username"] == "beto"
    # arquivada + silenciada: fica no arquivo
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"archived": True, "muted": True})
    _text(c, users[1], "ana", "ainda aqui")
    assert _convs(c, users[0])["conversations"] == []
    assert _convs(c, users[0])["archived_count"] == 1
    # quem arquivou e ENVIA, desarquiva
    _text(c, users[0], "beto", "respondi")
    assert _convs(c, users[0])["archived_count"] == 0


def test_prefs_event_sent_to_my_other_tabs_only(app, users):
    c = app.test_client()
    _talk(c, users)
    ra, ia = _open(c, users[0])
    _events(ia, "ready")
    rb, ib = _open(c, users[1])
    _events(ib, "ready")
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"muted": True})
    _, d = _events(ia, "prefs")
    assert d == {"partner": "beto"}
    hub.publish(_uid(app, "beto"), "fim", {})           # beto não recebeu nada de "prefs"
    seen = []
    while True:
        chunk = next(ib)
        chunk = chunk.decode() if isinstance(chunk, bytes) else chunk
        if chunk.startswith("event:"):
            seen.append(chunk.split("\n")[0][7:])
            if seen[-1] == "fim":
                break
    assert "prefs" not in seen
    ra.close(); rb.close()


def test_migration_adds_show_presence_to_old_db(tmp_path):
    """Banco antigo (users sem `show_presence`) é migrado no boot; usuário antigo continua visível."""
    import sqlite3
    db_file = tmp_path / "old.db"
    con = sqlite3.connect(db_file)
    con.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, cover_filename VARCHAR(255), reset_token VARCHAR(64),"
                " reset_token_expires DATETIME, google_id VARCHAR(255), last_seen_at DATETIME)")
    con.execute("INSERT INTO users (id) VALUES (1)")
    con.commit(); con.close()

    from flask import Flask
    from extensions import db as _db
    from app import _ensure_schema_upgrades
    a = Flask(__name__)
    a.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_file}"
    _db.init_app(a)
    with a.app_context():
        _ensure_schema_upgrades(_db)
        _ensure_schema_upgrades(_db)  # idempotente
        from sqlalchemy import inspect, text
        assert "show_presence" in {c["name"] for c in inspect(_db.engine).get_columns("users")}
        assert _db.session.execute(text("SELECT show_presence FROM users")).scalar() == 1


def test_conversation_prefs_table_created_on_fresh_db(app):
    from sqlalchemy import inspect
    from extensions import db
    with app.app_context():
        assert "conversation_prefs" in inspect(db.engine).get_table_names()


# ---------------- push ----------------

def test_push_body_variants(app, users):
    from models import Message
    m = Message(content="📷 Foto", msg_type="image")
    assert cx.push_body(m) == "📷 Foto"
    m = Message(content="olha isso", msg_type="image")
    assert cx.push_body(m) == "📷 olha isso"
    m = Message(content="🎤 Áudio", msg_type="audio", media_duration_ms=65000)
    assert cx.push_body(m) == "🎤 Áudio (1:05)"
    m = Message(content="oi", msg_type="text")
    assert cx.push_body(m, forwarded=True) == "↪ oi"


def test_push_muted_skipped_and_grouped(app, users, monkeypatch):
    sent = []
    import push as push_mod
    monkeypatch.setattr(push_mod, "send_push_to_user",
                        lambda uid, title, body, data=None, count=None: sent.append((uid, title, body, data, count)))
    c = app.test_client()
    _text(c, users[0], "beto", "primeira")
    assert len(sent) == 1 and sent[0][1] == "ana" and sent[0][3]["unread_count"] == 1
    _text(c, users[0], "beto", "segunda")
    assert sent[-1][1] == "ana (2 mensagens)" and sent[-1][2] == "segunda" and sent[-1][4] == 2
    n = len(sent)
    c.put("/api/v1/messages/ana/prefs", headers=users[1], json={"muted": True})   # beto silencia a ana
    _text(c, users[0], "beto", "terceira")
    assert len(sent) == n                                                         # nada de push
    # a silenciada continua entregando a mensagem normalmente
    assert len(c.get("/api/v1/messages/ana", headers=users[1]).get_json()["messages"]) == 3


# ---------------- site (HTML) ----------------

def _login_site(app, name="ana"):
    from models import User
    c = app.test_client()
    with c.session_transaction() as s:
        with app.app_context():
            s["_user_id"] = str(User.query.filter_by(username=name).first().id)
            s["_fresh"] = True
    return c


def test_site_inbox_shows_pin_mute_archive_and_privacy(app, users):
    api = app.test_client()
    _talk(api, users)
    api.put("/api/v1/messages/beto/prefs", headers=users[0], json={"pinned": True, "muted": True})
    site = _login_site(app)
    html = site.get("/mensagens/").get_data(as_text=True)
    assert 'data-pinned="1"' in html and 'data-muted="1"' in html
    assert "chat-privacy-toggle" in html and "conv-menu-btn" in html
    api.put("/api/v1/messages/beto/prefs", headers=users[0], json={"archived": True})
    html = site.get("/mensagens/").get_data(as_text=True)
    assert 'data-username="beto"' not in html and "Arquivadas (" in html
    html = site.get("/mensagens/?arquivadas=1").get_data(as_text=True)
    assert 'data-username="beto"' in html and "Conversas arquivadas" in html
    upd = site.get("/mensagens/api/atualizacoes?arquivadas=1").get_json()
    assert len(upd["conversations"]) == 1 and upd["archived_count"] == 1


def test_site_inbox_online_dot(app, users):
    api = app.test_client()
    _talk(api, users)
    rb, ib = _open(api, users[1])
    _events(ib, "ready")
    site = _login_site(app)
    assert "presence-dot" in site.get("/mensagens/").get_data(as_text=True)
    rb.close()
    assert "presence-dot" not in site.get("/mensagens/").get_data(as_text=True)


def test_site_assets_have_phase10_hooks(app, users):
    site = _login_site(app)
    js = site.get("/static/js/chat-thread.js").get_data(as_text=True)
    assert "applyPresence" in js and "visto por último" in js
    live = site.get("/static/js/chat-live.js").get_data(as_text=True)
    assert '"presence"' in live and '"prefs"' in live
    assert "driqy-shell-v" in site.get("/static/sw.js").get_data(as_text=True)


def test_inbox_archived_all_for_forward(app, users):
    c = app.test_client()
    _talk(c, users)
    c.put("/api/v1/messages/beto/prefs", headers=users[0], json={"archived": True})
    assert _convs(c, users[0])["conversations"] == []
    r = c.get("/api/v1/messages?archived=all", headers=users[0]).get_json()
    assert [x["partner"]["username"] for x in r["conversations"]] == ["beto"]
