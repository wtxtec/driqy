"""Chamadas — Fase 12: UI web de voz (arquivos/botão) e `end` com reason=error -> failed."""
import pytest

from chat_events import hub
from tests.test_chat_phase11 import SDP, _answer, _start, _uid, users, _clean_hub  # noqa: F401


def test_end_with_error_marks_failed(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    assert _answer(c, beto, cid).status_code == 200
    r = c.post(f"/api/v1/calls/{cid}/end", json={"reason": "error"}, headers=ana)
    j = r.get_json()
    assert r.status_code == 200 and j["state"] == "failed" and j["end_reason"] == "error"
    # idempotente
    assert c.post(f"/api/v1/calls/{cid}/end", json={}, headers=beto).get_json()["state"] == "failed"


def test_end_without_reason_is_hangup(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    _answer(c, beto, cid)
    j = c.post(f"/api/v1/calls/{cid}/end", json={}, headers=beto).get_json()
    assert j["state"] == "ended" and j["end_reason"] == "hangup"


def test_error_reason_ignored_while_ringing(app, users):
    ana, beto, _ = users
    c = app.test_client()
    cid = _start(c, ana).get_json()["id"]
    j = c.post(f"/api/v1/calls/{cid}/end", json={"reason": "error"}, headers=ana).get_json()
    assert j["state"] == "missed" and j["end_reason"] == "canceled"


def _login(app, c, name):
    from models import User
    with app.app_context():
        uid = User.query.filter_by(username=name).first().id
    with c.session_transaction() as s:
        s["_user_id"] = str(uid)
        s["_fresh"] = True


def test_web_thread_has_call_button_and_script(app, users):
    c = app.test_client()
    _login(app, c, "ana")
    html = c.get("/mensagens/beto").get_data(as_text=True)
    assert 'id="cw-call-btn"' in html and 'data-call-user="beto"' in html
    assert "call-ui.js" in html and "calls-api.js" in html


def test_call_ui_asset_served(app, users):
    c = app.test_client()
    r = c.get("/static/js/call-ui.js")
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    assert "RTCPeerConnection" in body and "call_incoming" in body and "driqyCallUI" in body
