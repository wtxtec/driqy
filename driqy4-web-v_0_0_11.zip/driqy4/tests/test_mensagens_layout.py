"""Mensagens — layout estilo Telegram: hora na bolha, seletor de emojis, campo (privado e grupo)."""
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_picker_module_and_loaded_in_ping_base():
    js = _read("static/js/emoji-picker.js")
    assert "DriqyEmojiPicker" in js and "Buscar Emojis" in js and "Frequentemente Usado" in js
    assert "js/emoji-picker.js" in _read("templates/ping_base.html")


def test_private_and_group_use_picker():
    assert "DriqyEmojiPicker" in _read("static/js/chat-thread.js")
    gj = _read("static/js/group-thread.js")
    assert "DriqyEmojiPicker" in gj and "cw-inline-meta" in gj
    g = _read("templates/messages_group.html")
    assert 'id="gw-emoji-btn"' in g and 'id="gw-emoji-panel"' in g and 'placeholder="Mensagem"' in g


def test_inline_meta_css_scoped_to_ping_mode():
    css = _read("static/css/style.css")
    assert ".ping-mode .cw-bubble.cw-inline-meta > .cw-meta" in css
    assert ".ping-mode .cw-ep.cw-ep-tg" in css


def test_no_global_document_listener_in_thread_script():
    js = _read("static/js/chat-thread.js").replace("listenOn(document", "")
    assert "document.addEventListener(" not in js


def test_attach_menu_camera_and_mic_always_visible():
    js = _read("static/js/chat-thread.js")
    assert "cw-attach-menu" in js and "openCamera" in js and "getUserMedia" in js
    assert "const showMic = !has && !recording;" in js
    assert ".ping-mode .cw-cam-card" in _read("static/css/style.css")


def test_vortex_pinterest_style_and_more_sources():
    css = _read("static/css/style.css")
    assert "body.pictures-page" in css and "border-radius: 16px" in css and "var(--ar, auto)" in css
    assert "--ar" in _read("templates/_picture_tile.html") and "clampRatio" in _read("static/js/vortex.js")
    from config import Config
    urls = [u for _, u, _c in Config.NEWS_DEFAULT_SOURCES]
    assert len(urls) == len(set(urls)) and len(urls) >= 140
    assert any("g1.globo.com/rss/g1/es/" in u for u in urls)
