"""Admin do Vortex: pausa/velocidade do motor, tempo real, visão geral e
exclusão em massa (por categoria, fonte, site, perfil, tipo)."""
import time
from types import SimpleNamespace

import pytest

import vortex_control as vcl
import vortex_crawler as vc
import vortex_search as vs
from models import (
    User, VortexCrawlSource, VortexDomain, VortexItem, VortexProfile, VortexTombstone, utcnow,
)
from test_vortex_engine import _count, engine_env  # noqa: F401  (fixture reaproveitada)
from test_vortex_search import mk


def _src(db, name="Fonte", category=None, enabled=True, profile="commons"):
    prof = VortexProfile.query.filter_by(handle=profile).first()
    src = VortexCrawlSource(name=name, kind="rss", profile_id=prof.id, category=category,
                            term=f"https://x.org/{name}.xml", media="photo", enabled=enabled)
    db.session.add(src)
    db.session.commit()
    return src


def _wait(cond, timeout=15.0, step=0.1):
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if cond():
            return True
        time.sleep(step)
    return False


# ------------------------------------------------------------------ controle
def test_control_defaults_persist_and_clamp(app, db):
    assert vcl.read_control(app, ttl=0) == {"paused": False, "speed": 1.0, "purge_seq": 0}
    vcl.set_paused(True)
    assert vcl.set_speed(2) == 2.0
    ctl = vcl.read_control(app, ttl=0)
    assert ctl["paused"] is True and ctl["speed"] == 2.0
    assert vcl.set_speed(99) == vcl.MAX_SPEED
    assert vcl.set_speed(0.001) == vcl.MIN_SPEED
    for bad in ("nan", "inf", "abc"):
        with pytest.raises(ValueError):
            vcl.set_speed(bad)
    vcl.set_paused(False)
    assert vcl.read_control(app, ttl=0)["paused"] is False


def test_control_cache_is_invalidated_by_writes(app, db):
    vcl.read_control(app, ttl=0)
    vcl.set_paused(True)                              # invalida o cache do processo
    assert vcl.read_control(app, ttl=60)["paused"] is True


def test_item_conditions_need_a_filter():
    with pytest.raises(ValueError):
        vcl.item_conditions()
    with pytest.raises(ValueError):
        vcl.item_conditions(media_type="audio")
    assert len(vcl.item_conditions(category="natureza", media_type="gif")) == 2


# ------------------------------------------------------------------ velocidade
def test_effective_workers_follow_speed(engine_env, db):          # noqa: F811  (WORKERS=3)
    engine = vc.IngestEngine(engine_env, db)
    got = {}
    for speed in (0.25, 1, 2, 4):
        vcl.set_speed(speed)
        got[speed] = engine._effective_workers()
    assert got == {0.25: 1, 1: 3, 2: 6, 4: 12}


def test_dispatch_slow_mode_limits_parallel_sources(engine_env, db):   # noqa: F811
    engine = vc.IngestEngine(engine_env, db)
    submitted = []
    engine._submit = lambda snap: submitted.append(snap.id)
    engine._dispatch_once()
    assert len(submitted) == 2                                    # fontes A e B, folga de sobra
    submitted.clear()
    vcl.set_speed(0.25)                                           # 1 por vez
    engine._dispatch_once()
    assert len(submitted) == 1


def test_speed_scales_next_run_but_never_shortens_errors(engine_env, db):   # noqa: F811
    engine = vc.IngestEngine(engine_env, db)
    ok = SimpleNamespace(error=None, unavailable=False, retry_after=None)

    def wait_after(res, speed):
        vcl.set_speed(speed)
        row = SimpleNamespace(next_run_at=utcnow().replace(microsecond=0) + __import__("datetime").timedelta(seconds=100))
        engine._scale_next_run(row, res)
        return (row.next_run_at - utcnow()).total_seconds()

    assert 45 <= wait_after(ok, 2) <= 52          # 2x: metade da espera
    assert 190 <= wait_after(ok, 0.5) <= 202      # 0,5x: o dobro
    assert 95 <= wait_after(ok, 1) <= 101         # 1x: intacto
    bad = SimpleNamespace(error="erro", unavailable=False, retry_after=None)
    assert 95 <= wait_after(bad, 4) <= 101        # erro: rápido não encurta o backoff
    limited = SimpleNamespace(error="429", unavailable=False, retry_after=60)
    assert 95 <= wait_after(limited, 4) <= 101    # 429: respeita o Retry-After
    assert 190 <= wait_after(bad, 0.5) <= 202     # lento estica até o backoff


def test_host_limiter_scale_slows_requests():
    lim = vc.HostLimiter({"h.test": 0.2})
    lim.scale = 3.0                               # 0,2 s x 3 = 0,6 s entre requisições
    lim.wait("http://h.test/a")
    t0 = time.monotonic()
    lim.wait("http://h.test/b")
    assert time.monotonic() - t0 >= 0.5


# ------------------------------------------------------------------ motor de ponta a ponta
def test_pause_stops_new_content_and_resume_continues(engine_env, db):    # noqa: F811
    app = engine_env
    engine = vc.IngestEngine(app, db).start(0)
    try:
        assert _wait(lambda: _count(db) >= 40, 30)
        vcl.set_paused(True)
        # o que estava em andamento termina e é gravado; depois, silêncio
        assert _wait(lambda: engine.stats()["sources_in_flight"] == 0 and engine.q.qsize() == 0, 30)
        time.sleep(0.8)
        frozen = _count(db)
        time.sleep(3.0)
        assert _count(db) == frozen, "o motor continuou indexando pausado"
        assert engine.stats()["paused"] is True
        vcl.set_paused(False)
        assert _wait(lambda: _count(db) > frozen + 20, 30), "não retomou"
    finally:
        engine.stop()


def test_heartbeat_publishes_live_snapshot_for_other_processes(engine_env, db):   # noqa: F811
    engine = vc.IngestEngine(engine_env, db).start(0)
    try:
        assert _wait(lambda: vcl.read_stats_file() is not None, 10)
        snap = vcl.read_stats_file()
        assert snap["running"] is True and snap["paused"] is False and snap["speed"] == 1.0
        assert "series" in snap and "saved_last_minute" in snap and snap["pid"]
    finally:
        engine.stop()
    # instantâneo velho = motor parado
    assert vcl.read_stats_file(max_age=-1) is None


# ------------------------------------------------------------------ exclusão em massa
def test_purge_by_category_tombstones_fts_and_disables_sources(app, db):
    nat = _src(db, "Natureza", category="natureza")
    other = _src(db, "Animais", category="animais")
    for i in range(3):
        mk(db, f"cachoeira {i}", "cachoeira", category="natureza")
    for i in range(2):
        mk(db, f"cachorro {i}", "cachorro", category="animais")
    assert vs.search_items(app, "cachoeira")["total"] == 3

    deleted = vcl.run_purge(app, {"category": "natureza"}, tombstone=True, disable_sources=True, label="natureza")
    db.session.expire_all()
    assert deleted == 3
    assert VortexItem.query.count() == 2
    assert {i.category for i in VortexItem.query.all()} == {"animais"}
    assert VortexTombstone.query.count() == 3
    assert vs.search_items(app, "cachoeira")["total"] == 0          # gatilho do FTS limpou o índice
    assert vs.search_items(app, "cachorro")["total"] == 2
    assert db.session.get(VortexCrawlSource, nat.id).enabled is False
    assert db.session.get(VortexCrawlSource, other.id).enabled is True
    assert vcl.read_control(app, ttl=0)["purge_seq"] == 1
    job = vcl.read_purge_job()
    assert job["state"] == "done" and job["deleted"] == 3


def test_purge_filters_combine_with_and(app, db):
    src = _src(db, "Misto")
    a = mk(db, "foto um", category="natureza", media="photo")
    b = mk(db, "gif um", category="natureza", media="gif")
    c = mk(db, "gif dois", category="animais", media="gif")
    for it in (a, b):
        it.source_id = src.id
    db.session.commit()
    vcl.run_purge(app, {"category": "natureza", "media_type": "gif"}, tombstone=False)
    db.session.expire_all()
    assert {i.title for i in VortexItem.query.all()} == {"foto um", "gif dois"}
    assert VortexTombstone.query.count() == 0                      # sem lápide
    vcl.run_purge(app, {"source_id": src.id}, tombstone=True, disable_sources=True)
    db.session.expire_all()
    assert {i.title for i in VortexItem.query.all()} == {"gif dois"}
    assert db.session.get(VortexCrawlSource, src.id).enabled is False
    assert c.id and VortexItem.query.count() == 1


def test_purge_by_site_can_block_the_site(app, db):
    it = mk(db, "foto do site", category="natureza")
    it.source_name = "exemplo.com"
    mk(db, "outra", category="natureza").source_name = "outro.com"
    db.session.commit()
    vcl.run_purge(app, {"site": "exemplo.com"}, tombstone=True, block_site=True)
    db.session.expire_all()
    assert [i.source_name for i in VortexItem.query.all()] == ["outro.com"]
    assert VortexDomain.query.filter_by(host="exemplo.com").one().status == "blocked"


def test_purge_refuses_empty_filters(app, db):
    mk(db, "intacto")
    assert vcl.run_purge(app, {}, tombstone=True) == 0
    assert VortexItem.query.count() == 1
    assert vcl.read_purge_job()["state"] == "error"


def test_deleted_urls_do_not_come_back_and_can_be_released(app, db):
    """O motor recarrega o que conhece quando o admin apaga: com lápide a URL
    fica bloqueada; sem lápide ela volta a ser candidata."""
    a = mk(db, "com lapide", category="natureza")
    b = mk(db, "sem lapide", category="animais")
    engine = vc.IngestEngine(app, db)
    engine._load_known()
    assert {a.url_hash, b.url_hash} <= engine._known
    engine._apply_control()                                        # 1ª leitura: só guarda a sequência
    vcl.run_purge(app, {"category": "natureza"}, tombstone=True)
    vcl.run_purge(app, {"category": "animais"}, tombstone=False)
    engine._apply_control()                                        # purge_seq mudou: recarrega
    assert a.url_hash in engine._known                             # lápide: segue bloqueada
    assert b.url_hash not in engine._known                         # liberada
    assert len(engine._phashes) == 0


def test_delete_item_leaves_tombstone(app, db):
    it = mk(db, "apagar um")
    h = it.url_hash
    assert vcl.delete_item(app, it.id) is True
    assert VortexItem.query.count() == 0
    assert db.session.get(VortexTombstone, h) is not None
    assert vcl.delete_item(app, 999999) is False


def test_overview_groups_everything(app, db):
    src = _src(db, "Fonte X")
    a = mk(db, "um", category="natureza", media="photo")
    b = mk(db, "dois", category="natureza", media="gif")
    mk(db, "tres", category="animais", media="video")
    hidden = mk(db, "oculto", category="animais")
    hidden.is_active = False
    a.source_id = b.source_id = src.id
    a.source_name = b.source_name = "flickr.com"
    db.session.commit()
    ov = vcl.overview(app, ttl=0)
    assert ov["total"]["total"] == 3 and ov["total"]["photos"] == 1 and ov["total"]["gifs"] == 1
    assert ov["total"]["videos"] == 1 and ov["hidden"] == 1 and ov["total"]["last_24h"] == 3
    cats = {c["slug"]: c for c in ov["categories"]}
    assert cats["natureza"]["total"] == 2 and cats["animais"]["videos"] == 1
    srcs = {s["name"]: s for s in ov["sources"]}
    assert srcs["Fonte X"]["total"] == 2
    assert "Descoberta (páginas da web)" in srcs                   # itens sem fonte cadastrada
    assert ov["sites"][0] == {"host": "flickr.com", "total": 2, "last_at": ov["sites"][0]["last_at"]}
    assert len(ov["timeline"]) == 24 and sum(h["count"] for h in ov["timeline"]) == 3


# ------------------------------------------------------------------ rotas do admin
@pytest.fixture()
def admin_client(app, db):
    user = User(username="chefe", email="chefe@example.com", is_admin=True)
    user.set_password("senha1234")
    db.session.add(user)
    db.session.commit()
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["_fresh"] = True
    return client


FETCH = {"X-Requested-With": "fetch"}


def test_admin_pages_require_login(app, db):
    anon = app.test_client()
    for url in ("/admin/vortex/conteudo", "/admin/vortex/status", "/admin/vortex/conteudo/previa?categoria=x"):
        assert anon.get(url).status_code in (302, 401)
    assert anon.post("/admin/vortex/controle", data={"acao": "pausar"}).status_code in (302, 401)
    assert vcl.read_control(app, ttl=0)["paused"] is False


def test_admin_pages_refuse_common_users(app, db):
    # (um cliente por teste: o contexto do app do fixture `db` compartilha o `g` do Flask-Login)
    user = User(username="comum", email="c@example.com")
    user.set_password("senha1234")
    db.session.add(user)
    db.session.commit()
    common = app.test_client()
    with common.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["_fresh"] = True
    assert common.get("/admin/vortex/conteudo").status_code == 403
    assert common.post("/admin/vortex/controle", data={"acao": "pausar"}).status_code == 403
    mk(db, "intocado", category="natureza")
    assert common.post("/admin/vortex/conteudo/apagar",
                       data={"categoria": "natureza", "confirmar": "APAGAR"}).status_code == 403
    assert VortexItem.query.count() == 1 and vcl.read_control(app, ttl=0)["paused"] is False


def test_content_page_renders_with_data(app, db, admin_client):
    _src(db, "Fonte Z")
    mk(db, "uma foto", category="natureza")
    page = admin_client.get("/admin/vortex/conteudo")
    assert page.status_code == 200
    html = page.get_data(as_text=True)
    assert "Controle da indexação" in html and "Apagar conteúdo" in html
    assert "Natureza" in html or "natureza" in html
    assert "Vortex (conteúdo)" in html                              # aba no menu


def test_control_endpoint_pause_resume_speed(app, db, admin_client):
    r = admin_client.post("/admin/vortex/controle", data={"acao": "pausar"}, headers=FETCH)
    assert r.status_code == 200 and r.get_json()["control"]["paused"] is True
    r = admin_client.post("/admin/vortex/controle", data={"acao": "velocidade", "valor": "2"}, headers=FETCH)
    assert r.get_json()["control"]["speed"] == 2.0
    r = admin_client.post("/admin/vortex/controle", data={"acao": "velocidade", "valor": "100"}, headers=FETCH)
    assert r.get_json()["control"]["speed"] == vcl.MAX_SPEED
    assert admin_client.post("/admin/vortex/controle", data={"acao": "velocidade", "valor": "x"},
                             headers=FETCH).status_code == 400
    assert admin_client.post("/admin/vortex/controle", data={"acao": "explodir"}, headers=FETCH).status_code == 400
    r = admin_client.post("/admin/vortex/controle", data={"acao": "retomar"}, headers=FETCH)
    assert r.get_json()["control"]["paused"] is False
    # sem JS: redireciona de volta à central
    r = admin_client.post("/admin/vortex/controle", data={"acao": "pausar"})
    assert r.status_code == 302 and r.headers["Location"].endswith("/admin/vortex/conteudo")


def test_run_now_is_refused_while_paused(app, db, admin_client, monkeypatch):
    called = []
    monkeypatch.setattr(vc, "run_in_background", lambda *a, **k: called.append(1))
    vcl.set_paused(True)
    r = admin_client.post("/admin/vortex/rodar", data={})
    assert r.status_code == 302 and not called
    vcl.set_paused(False)
    admin_client.post("/admin/vortex/rodar", data={})
    assert called == [1]


def test_crawl_all_sources_does_nothing_while_paused(app, db):
    vcl.set_paused(True)
    assert vc.crawl_all_sources(app, db) == 0


def test_status_endpoint_is_live_json(app, db, admin_client):
    mk(db, "uma", media="photo")
    mk(db, "dois", media="gif")
    j = admin_client.get("/admin/vortex/status").get_json()
    assert j["engine"] is None                                      # nenhum motor neste teste
    assert j["control"] == {"paused": False, "speed": 1.0, "purge_seq": 0}
    assert j["totals"]["photos"] == 1 and j["totals"]["gifs"] == 1 and j["total_items"] == 2
    assert j["speed_levels"] == list(vcl.SPEED_LEVELS)
    assert len(j["recent"]) == 2 and j["recent"][0]["title"] == "dois"
    assert j["purge"] is None


def test_status_uses_engine_snapshot_from_another_process(app, db, admin_client):
    vcl.write_stats_file({"ts": time.time(), "running": True, "paused": False, "speed": 2.0,
                          "saved_last_minute": 42, "inflight_ids": [], "series": [[1, 3]]})
    j = admin_client.get("/admin/vortex/status").get_json()
    assert j["engine"]["saved_last_minute"] == 42 and j["engine"]["series"] == [[1, 3]]


def test_purge_endpoint_flow(app, db, admin_client):
    for i in range(4):
        mk(db, f"praia {i}", category="natureza")
    mk(db, "gato", category="animais")
    # prévia
    assert admin_client.get("/admin/vortex/conteudo/previa").status_code == 400
    j = admin_client.get("/admin/vortex/conteudo/previa?categoria=natureza").get_json()
    assert j["ok"] and j["count"] == 4
    # sem confirmação: nada acontece
    r = admin_client.post("/admin/vortex/conteudo/apagar", data={"categoria": "natureza"}, headers=FETCH)
    assert r.status_code == 400 and VortexItem.query.count() == 5
    # sem filtro: recusa (nunca apaga tudo sem querer)
    r = admin_client.post("/admin/vortex/conteudo/apagar", data={"confirmar": "APAGAR"}, headers=FETCH)
    assert r.status_code == 400 and VortexItem.query.count() == 5
    # nada casa
    r = admin_client.post("/admin/vortex/conteudo/apagar", data={"categoria": "arte", "confirmar": "APAGAR"}, headers=FETCH)
    assert r.status_code == 404
    # confirmado
    r = admin_client.post("/admin/vortex/conteudo/apagar", headers=FETCH,
                          data={"categoria": "natureza", "confirmar": "apagar", "lapide": "1"})
    assert r.status_code == 200 and r.get_json()["ok"]
    assert _wait(lambda: (vcl.read_purge_job() or {}).get("state") == "done", 15)
    db.session.expire_all()
    assert {i.title for i in VortexItem.query.all()} == {"gato"}
    assert VortexTombstone.query.count() == 4
    assert admin_client.get("/admin/vortex/status").get_json()["purge"]["deleted"] == 4


def test_purge_rejects_second_job_while_running(app, db, admin_client):
    mk(db, "x", category="natureza")
    vcl._write_json(vcl.PURGE_FILE, {"state": "running", "label": "outra", "deleted": 1, "total": 9,
                                     "started": time.time(), "ts": time.time()})
    r = admin_client.post("/admin/vortex/conteudo/apagar", data={"categoria": "natureza", "confirmar": "APAGAR"},
                          headers=FETCH)
    assert r.status_code == 409 and VortexItem.query.count() == 1
    # job "running" velho (processo caiu) vira "interrupted" e libera
    vcl._write_json(vcl.PURGE_FILE, {"state": "running", "label": "x", "deleted": 1, "total": 9,
                                     "started": 1, "ts": time.time() - 120})
    assert vcl.read_purge_job()["state"] == "interrupted"


def test_item_list_filters_and_single_delete(app, db, admin_client):
    src = _src(db, "F")
    a = mk(db, "alvo especial", category="natureza")
    b = mk(db, "zzfora", category="animais")
    a.source_id, a.source_name = src.id, "meusite.com"
    db.session.commit()
    html = admin_client.get(f"/admin/vortex/itens?fonte={src.id}").get_data(as_text=True)
    assert "alvo especial" in html and "zzfora" not in html
    html = admin_client.get("/admin/vortex/itens?site=meusite.com&q=especial").get_data(as_text=True)
    assert "alvo especial" in html and "Apagar" in html
    r = admin_client.post(f"/admin/vortex/itens/{b.id}/apagar")
    assert r.status_code == 302
    db.session.expire_all()
    assert VortexItem.query.count() == 1 and db.session.get(VortexTombstone, b.url_hash) is not None


def test_release_tombstones(app, db, admin_client):
    it = mk(db, "volta", category="natureza")
    vcl.delete_item(app, it.id)
    assert VortexTombstone.query.count() == 1
    r = admin_client.post("/admin/vortex/conteudo/lapides/limpar", data={"categoria": "animais"})
    assert r.status_code == 302 and VortexTombstone.query.count() == 1      # outra categoria: intacta
    admin_client.post("/admin/vortex/conteudo/lapides/limpar", data={})
    db.session.expire_all()
    assert VortexTombstone.query.count() == 0
