"""Mensagens — parte 3: grupos (backend): criar, membros/papéis, mensagens, leitura, prefs, tempo real, push."""
import io
import pytest


@pytest.fixture()
def world(app):
    from extensions import db as _db
    from models import ApiToken, User
    heads, ids = {}, {}
    with app.app_context():
        for name in ("ana", "beto", "caio", "dani"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            heads[name] = {"Authorization": f"Bearer {tok.token}"}
            ids[name] = u.id
    c = app.test_client()
    c.h, c.ids = heads, ids
    return c


def _req(c, who, method, url, **kw):
    return getattr(c, method)("/api/v1" + url, headers=c.h[who], **kw)


def _make(c, who="ana", name="Turma", members=("beto", "caio")):
    r = _req(c, who, "post", "/groups", json={"name": name, "members": list(members)})
    assert r.status_code == 201, r.get_json()
    return r.get_json()["group"]


def _say(c, who, gid, text, **extra):
    r = _req(c, who, "post", f"/groups/{gid}/messages", json={"content": text, **extra})
    assert r.status_code == 200, r.get_json()
    return r.get_json()["message"]


def test_create_group_roles_and_system_message(world):
    g = _make(world)
    roles = {m["username"]: m["role"] for m in g["members"]}
    assert roles == {"ana": "owner", "beto": "member", "caio": "member"} and g["member_count"] == 3
    msgs = _req(world, "beto", "get", f"/groups/{g['id']}/messages").get_json()["messages"]
    assert len(msgs) == 1 and msgs[0]["kind"] == "system" and "criou o grupo" in msgs[0]["content"]


@pytest.mark.parametrize("payload,code", [
    ({"name": "", "members": ["beto"]}, 400),
    ({"name": "X" * 61, "members": ["beto"]}, 400),
    ({"name": "Sem gente", "members": []}, 400),
    ({"name": "Sem gente", "members": ["ana"]}, 400),
    ({"name": "Fantasma", "members": ["ninguem"]}, 404),
])
def test_create_validation(world, payload, code):
    assert _req(world, "ana", "post", "/groups", json=payload).status_code == code


def test_requires_login(world):
    assert world.get("/api/v1/groups").status_code == 401


def test_outsider_gets_404_everywhere(world):
    g = _make(world)
    gid = g["id"]
    for method, url in (("get", f"/groups/{gid}"), ("get", f"/groups/{gid}/messages"), ("post", f"/groups/{gid}/read"),
                        ("post", f"/groups/{gid}/leave"), ("delete", f"/groups/{gid}")):
        assert _req(world, "dani", method, url).status_code == 404, (method, url)
    assert _req(world, "dani", "post", f"/groups/{gid}/messages", json={"content": "oi"}).status_code == 404


def test_messages_unread_read_and_idempotency(world):
    gid = _make(world)["id"]
    a = _say(world, "ana", gid, "oi turma", client_id="c1")
    again = _say(world, "ana", gid, "oi turma", client_id="c1")
    assert a["id"] == again["id"] and a["mine"] is True
    _say(world, "caio", gid, "e aí")
    lst = _req(world, "beto", "get", "/groups").get_json()["groups"]
    assert lst[0]["unread"] == 2 and lst[0]["last_message"]["content"] == "e aí"
    assert lst[0]["last_preview"].endswith(": e aí")
    # quem manda não fica com não lida da própria mensagem
    assert _req(world, "ana", "get", "/groups").get_json()["groups"][0]["unread"] == 1
    r = _req(world, "beto", "post", f"/groups/{gid}/read", json={})
    assert r.get_json()["unread"] == 0
    assert _req(world, "beto", "get", "/groups").get_json()["groups"][0]["unread"] == 0


def test_reply_edit_delete_rules(world):
    gid = _make(world)["id"]
    m1 = _say(world, "beto", gid, "primeira")
    m2 = _say(world, "caio", gid, "resposta", reply_to_id=m1["id"])
    assert m2["reply_to"]["id"] == m1["id"] and m2["reply_to"]["preview"] == "primeira"
    assert _req(world, "ana", "post", f"/groups/{gid}/messages", json={"content": "x", "reply_to_id": 99999}).status_code == 400
    # editar: só o autor
    assert _req(world, "caio", "put", f"/groups/{gid}/messages/{m1['id']}", json={"content": "x"}).status_code == 403
    ok = _req(world, "beto", "put", f"/groups/{gid}/messages/{m1['id']}", json={"content": "editada"}).get_json()["message"]
    assert ok["edited"] is True and ok["content"] == "editada"
    # apagar: autor ou admin; membro comum não apaga a dos outros
    assert _req(world, "caio", "delete", f"/groups/{gid}/messages/{m1['id']}").status_code == 403
    gone = _req(world, "ana", "delete", f"/groups/{gid}/messages/{m1['id']}").get_json()["message"]  # dona = admin
    assert gone["deleted"] is True and gone["content"] == ""
    # mensagem de sistema não apaga
    first = _req(world, "ana", "get", f"/groups/{gid}/messages").get_json()["messages"][0]
    assert first["kind"] == "system" and _req(world, "ana", "delete", f"/groups/{gid}/messages/{first['id']}").status_code == 403


def test_pagination(world):
    gid = _make(world)["id"]
    ids = [_say(world, "ana", gid, f"m{i}")["id"] for i in range(5)]
    page = _req(world, "ana", "get", f"/groups/{gid}/messages?limit=3").get_json()
    assert [m["id"] for m in page["messages"]] == ids[-3:] and page["has_more"] is True
    older = _req(world, "ana", "get", f"/groups/{gid}/messages?before={ids[-3]}&limit=50").get_json()
    assert older["has_more"] is False and ids[0] in [m["id"] for m in older["messages"]]
    newer = _req(world, "ana", "get", f"/groups/{gid}/messages?after={ids[2]}").get_json()["messages"]
    assert [m["id"] for m in newer] == ids[3:]


def test_new_member_does_not_see_history(world):
    gid = _make(world)["id"]
    _say(world, "ana", gid, "segredo antigo")
    r = _req(world, "ana", "post", f"/groups/{gid}/members", json={"usernames": ["dani", "beto"]})
    assert r.status_code == 200 and r.get_json()["group"]["member_count"] == 4
    texts = [m["content"] for m in _req(world, "dani", "get", f"/groups/{gid}/messages").get_json()["messages"]]
    assert "segredo antigo" not in " ".join(texts) and any("adicionou" in t for t in texts)
    assert _req(world, "dani", "get", "/groups").get_json()["groups"][0]["unread"] == 0
    _say(world, "ana", gid, "boas-vindas")
    assert _req(world, "dani", "get", "/groups").get_json()["groups"][0]["unread"] == 1
    assert _req(world, "ana", "post", f"/groups/{gid}/members", json={"usernames": ["beto"]}).status_code == 400  # já está


def test_permissions_members_and_roles(world):
    gid = _make(world)["id"]
    assert _req(world, "beto", "post", f"/groups/{gid}/members", json={"usernames": ["dani"]}).status_code == 403
    assert _req(world, "beto", "put", f"/groups/{gid}", json={"name": "Novo"}).status_code == 403
    assert _req(world, "beto", "put", f"/groups/{gid}/members/caio", json={"role": "admin"}).status_code == 403
    assert _req(world, "ana", "put", f"/groups/{gid}/members/beto", json={"role": "admin"}).status_code == 200
    assert _req(world, "ana", "put", f"/groups/{gid}/members/ana", json={"role": "member"}).status_code == 403
    # admin adiciona e remove membro comum, mas não remove outro admin nem o dono
    assert _req(world, "beto", "post", f"/groups/{gid}/members", json={"usernames": ["dani"]}).status_code == 200
    assert _req(world, "beto", "delete", f"/groups/{gid}/members/ana").status_code == 403
    assert _req(world, "beto", "delete", f"/groups/{gid}/members/dani").status_code == 200
    assert _req(world, "ana", "put", f"/groups/{gid}/members/caio", json={"role": "admin"}).status_code == 200
    assert _req(world, "beto", "delete", f"/groups/{gid}/members/caio").status_code == 403  # admin x admin
    assert _req(world, "ana", "delete", f"/groups/{gid}/members/caio").status_code == 200  # dono remove admin
    assert _req(world, "caio", "get", f"/groups/{gid}").status_code == 404  # quem saiu perde o acesso


def test_rename_description_and_avatar(world):
    gid = _make(world)["id"]
    g = _req(world, "ana", "put", f"/groups/{gid}", json={"name": "Família", "description": "só os de casa"}).get_json()["group"]
    assert g["name"] == "Família" and g["description"] == "só os de casa"
    msgs = [m["content"] for m in _req(world, "beto", "get", f"/groups/{gid}/messages").get_json()["messages"]]
    assert any("mudou o nome" in t for t in msgs)
    png = (b"\x89PNG\r\n\x1a\n" + b"0" * 32)
    r = _req(world, "ana", "post", f"/groups/{gid}/avatar", data={"file": (io.BytesIO(png), "foto.png")}, content_type="multipart/form-data")
    assert r.status_code == 200 and r.get_json()["group"]["avatar_url"]
    bad = _req(world, "ana", "post", f"/groups/{gid}/avatar", data={"file": (io.BytesIO(b"x"), "a.exe")}, content_type="multipart/form-data")
    assert bad.status_code == 400
    assert _req(world, "beto", "post", f"/groups/{gid}/avatar", data={"file": (io.BytesIO(png), "f.png")}, content_type="multipart/form-data").status_code == 403
    assert _req(world, "ana", "delete", f"/groups/{gid}/avatar").get_json()["group"]["avatar_url"] is None


def test_leave_transfers_ownership_and_last_one_deletes(world, app):
    gid = _make(world, members=("beto", "caio"))["id"]
    assert _req(world, "ana", "post", f"/groups/{gid}/leave").get_json() == {"left": True, "deleted": False}
    g = _req(world, "beto", "get", f"/groups/{gid}").get_json()["group"]
    assert {m["username"]: m["role"] for m in g["members"]} == {"beto": "owner", "caio": "member"}
    assert _req(world, "ana", "get", f"/groups/{gid}").status_code == 404
    _req(world, "caio", "post", f"/groups/{gid}/leave")
    assert _req(world, "beto", "post", f"/groups/{gid}/leave").get_json()["deleted"] is True
    from models import ChatGroup, ChatGroupMessage
    with app.app_context():
        assert ChatGroup.query.count() == 0 and ChatGroupMessage.query.count() == 0


def test_only_owner_deletes_group(world):
    gid = _make(world)["id"]
    assert _req(world, "beto", "delete", f"/groups/{gid}").status_code == 403
    assert _req(world, "ana", "delete", f"/groups/{gid}").get_json() == {"deleted": True}
    assert _req(world, "beto", "get", f"/groups/{gid}").status_code == 404


def test_prefs_pin_mute_archive_and_limit(world):
    ids = [_make(world, name=f"G{i}")["id"] for i in range(4)]
    for gid in ids[:3]:
        assert _req(world, "ana", "put", f"/groups/{gid}/prefs", json={"pinned": True}).status_code == 200
    assert _req(world, "ana", "put", f"/groups/{ids[3]}/prefs", json={"pinned": True}).status_code == 400  # limite 3
    assert _req(world, "ana", "put", f"/groups/{ids[0]}/prefs", json={"muted": "sim"}).status_code == 400
    r = _req(world, "ana", "put", f"/groups/{ids[0]}/prefs", json={"archived": True}).get_json()["prefs"]
    assert r == {"pinned": False, "muted": False, "archived": True}  # arquivar desafixa
    lst = _req(world, "ana", "get", "/groups").get_json()
    assert ids[0] not in [g["id"] for g in lst["groups"]] and lst["archived_count"] == 1
    arch = _req(world, "ana", "get", "/groups?arquivadas=1").get_json()["groups"]
    assert [g["id"] for g in arch] == [ids[0]]
    # mensagem nova desarquiva para quem tinha arquivado
    _say(world, "beto", ids[0], "volta")
    assert _req(world, "ana", "get", "/groups?arquivadas=1").get_json()["groups"] == []
    # prefs são de cada um
    assert _req(world, "beto", "get", "/groups").get_json()["groups"][0]["prefs"]["pinned"] is False


def test_pinned_first_in_list(world):
    g1, g2 = _make(world, name="A")["id"], _make(world, name="B")["id"]
    _say(world, "ana", g2, "mais recente")
    assert _req(world, "ana", "get", "/groups").get_json()["groups"][0]["id"] == g2
    _req(world, "ana", "put", f"/groups/{g1}/prefs", json={"pinned": True})
    assert _req(world, "ana", "get", "/groups").get_json()["groups"][0]["id"] == g1


def test_realtime_events_reach_members(world, app):
    from chat_events import hub
    hub.reset()
    qb, qa = hub.subscribe(world.ids["beto"]), hub.subscribe(world.ids["ana"])
    gid = _make(world)["id"]
    assert qb.get_nowait() == ("group", {"group_id": gid, "kind": "members"})
    _say(world, "ana", gid, "oi")
    ev = qb.get_nowait()
    assert ev[0] == "group" and ev[1]["kind"] == "message" and ev[1]["group_id"] == gid
    while not qa.empty():
        qa.get_nowait()
    _req(world, "ana", "post", f"/groups/{gid}/typing", json={"state": "typing"})
    got = [qb.get_nowait() for _ in range(qb.qsize())]
    assert any(e[1].get("kind") == "typing" and e[1].get("username") == "ana" for e in got)
    assert qa.empty()  # quem digita não recebe o próprio aviso
    _req(world, "ana", "delete", f"/groups/{gid}/members/beto")
    kinds = [qb.get_nowait()[1]["kind"] for _ in range(qb.qsize())]
    assert "removed" in kinds
    hub.reset()


def test_push_goes_to_unmuted_members_only(world, monkeypatch):
    sent = []
    import push
    monkeypatch.setattr(push, "send_push_to_user", lambda uid, title, body, data=None, count=None: sent.append((uid, title, body, data)))
    gid = _make(world)["id"]
    _req(world, "caio", "put", f"/groups/{gid}/prefs", json={"muted": True})
    _say(world, "ana", gid, "olá grupo")
    assert [s[0] for s in sent] == [world.ids["beto"]]
    uid, title, body, data = sent[0]
    assert title == "Turma" and body.lower().startswith("ana") and body.endswith(": olá grupo")
    assert data["type"] == "group_message" and data["group_id"] == gid


def test_group_does_not_touch_one_to_one_chat(world, app):
    from models import Message
    gid = _make(world)["id"]
    _say(world, "ana", gid, "no grupo")
    with app.app_context():
        assert Message.query.count() == 0
    # a lista de conversas 1-para-1 do Beto não ganhou nada por causa do grupo
    assert world.get("/mensagens/", headers=world.h["beto"]).status_code in (200, 302)


def test_username_grupo_is_reserved():
    from auth import RESERVED_USERNAMES
    assert {"grupo", "grupos"} <= RESERVED_USERNAMES
