"""Testes do crawler do Vortex e dos endpoints /api/v1/vortex*.
HTTP é simulado (a rede real não é usada)."""
import io
import json

import pytest
from PIL import Image

import vortex_crawler as vc
from models import Post, PostMedia, VortexCrawlSource, VortexItem, VortexProfile


# ------------------------------------------------------------------ helpers
def png_bytes(seed=0, size=(300, 300)):
    """Imagem com padrão diferente por `seed` (dHash diferente)."""
    img = Image.new("L", size, 0)
    px = img.load()
    for x in range(size[0]):
        for y in range(size[1]):
            px[x, y] = ((x * (seed + 1)) // 7 + (y * (seed * 3 + 1)) // 11) % 256
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


class FakeResp:
    def __init__(self, status=200, json_data=None, content=b"", headers=None, text=""):
        self.status_code = status
        self._json = json_data
        self.content = content
        self.text = text or (content.decode("utf-8", "ignore") if isinstance(content, bytes) else "")
        self.headers = headers or {}

    def json(self):
        return self._json

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")

    def iter_content(self, n):
        for i in range(0, len(self.content), n):
            yield self.content[i:i + n]

    def close(self):
        pass


class FakeHttp:
    """Roteia por prefixo de URL -> função(url, kwargs) -> FakeResp."""

    def __init__(self, routes):
        self.routes = routes
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append(url)
        for prefix, fn in self.routes.items():
            if url.startswith(prefix):
                return fn(url, kwargs)
        return FakeResp(404)


def commons_payload(entries, more=True):
    pages = []
    for i, e in enumerate(entries):
        pages.append({
            "title": f"File:{e['name']}", "index": i + 1,
            "imageinfo": [{
                "url": f"https://upload.wikimedia.org/{e['name']}",
                "thumburl": f"https://upload.wikimedia.org/thumb/{e['name']}",
                "width": e.get("w", 1600), "height": e.get("h", 1200), "size": e.get("size", 500000),
                "mime": e.get("mime", "image/jpeg"),
                "descriptionurl": f"https://commons.wikimedia.org/wiki/File:{e['name']}",
                "extmetadata": {
                    "ObjectName": {"value": e.get("title", "")},
                    "Artist": {"value": '<a href="x">Maria Silva</a>'},
                    "LicenseShortName": {"value": "CC BY-SA 4.0"},
                    "Categories": {"value": e.get("cats", "Waterfalls|Rivers of Brazil")},
                    "ImageDescription": {"value": e.get("desc", "<b>Uma cachoeira</b>")},
                },
            }],
        })
    data = {"query": {"pages": pages}}
    if more:
        data["continue"] = {"gsroffset": 30}
    return data


def make_commons_http(entries, thumb_for=None, more=True):
    def api(url, kw):
        return FakeResp(200, json_data=commons_payload(entries, more))

    def thumb(url, kw):
        seed = (thumb_for or {}).get(url.rsplit("/", 1)[-1], 0)
        return FakeResp(200, content=png_bytes(seed), headers={"Content-Type": "image/png"})

    return FakeHttp({
        "https://commons.wikimedia.org/w/api.php": api,
        "https://upload.wikimedia.org/thumb/": thumb,
    })


def get_source(db, kind="commons", media="photo", category="natureza", query="waterfall"):
    profile = VortexProfile.query.filter_by(handle=kind).first()
    src = VortexCrawlSource.query.filter_by(kind=kind, term=query, media=media).first()
    if src is None:
        src = VortexCrawlSource(name="t", kind=kind, profile_id=profile.id, category=category,
                                term=query, media=media)
        db.session.add(src)
        db.session.commit()
    return src


# -------------------------------------------------------------------- seeds
def test_seed_creates_profiles_and_sources_idempotent(app, db):
    n_profiles = VortexProfile.query.count()
    n_sources = VortexCrawlSource.query.count()
    assert n_profiles >= 5 and n_sources >= 20
    vc.seed_vortex_defaults(app, db)
    assert VortexProfile.query.count() == n_profiles
    assert VortexCrawlSource.query.count() == n_sources


# ------------------------------------------------------------------ crawler
def test_commons_photo_is_stored_with_metadata(app, db):
    src = get_source(db)
    http = make_commons_http([{"name": "A.jpg", "title": "Cachoeira bonita"}])
    added = vc.crawl_source(app, db, src, http=http)
    assert added == 1
    item = VortexItem.query.one()
    assert item.media_type == "photo"
    assert item.media_url == "https://upload.wikimedia.org/A.jpg"
    assert item.thumb_url.endswith("/thumb/A.jpg")
    assert item.category == "natureza"          # categoria fixa da fonte
    assert item.license == "CC BY-SA 4.0"
    assert item.attribution == "Maria Silva"    # HTML removido
    assert "waterfalls" in item.tag_list and "cachoeira" in item.tag_list
    assert item.phash and len(item.phash) == 16
    assert item.profile.handle == "commons"
    assert src.next_page == 2 and src.items_added == 1
    assert src.last_status.startswith("ok")


def test_duplicates_and_near_duplicates_are_skipped(app, db):
    src = get_source(db)
    entries = [{"name": "A.jpg"}, {"name": "B.jpg"}, {"name": "C.jpg"}]
    # A e B têm a MESMA imagem (seed 1) -> quase-duplicata; C é diferente
    http = make_commons_http(entries, thumb_for={"A.jpg": 1, "B.jpg": 1, "C.jpg": 5})
    assert vc.crawl_source(app, db, src, http=http) == 2
    assert {i.media_url.rsplit("/", 1)[-1] for i in VortexItem.query.all()} == {"A.jpg", "C.jpg"}
    # segunda rodada com os mesmos resultados: nada novo (url_hash)
    assert vc.crawl_source(app, db, src, http=http) == 0


def test_filters_small_blocked_and_wrong_mime(app, db):
    src = get_source(db)
    http = make_commons_http([
        {"name": "small.jpg", "w": 100, "h": 100},
        {"name": "wide.jpg", "w": 4000, "h": 400},            # proporção extrema
        {"name": "nude.jpg", "title": "Nude beach"},
        {"name": "anim.gif", "mime": "image/gif"},             # fonte é de fotos
        {"name": "icon-logo.png", "mime": "image/png"},         # url ruim
        {"name": "ok.jpg"},
    ])
    assert vc.crawl_source(app, db, src, http=http) == 1
    assert VortexItem.query.one().media_url.endswith("ok.jpg")


def test_commons_gif_and_video_types(app, db):
    gif_src = get_source(db, media="gif", category=None, query="animal")
    http = make_commons_http([
        {"name": "a.gif", "mime": "image/gif", "size": 1000000, "title": "Cat video funny"},
        {"name": "big.gif", "mime": "image/gif", "size": 50_000_000},
    ])
    assert vc.crawl_source(app, db, gif_src, http=http) == 1
    gif = VortexItem.query.one()
    assert gif.media_type == "gif"

    vid_src = get_source(db, media="video", query="nature")
    http = make_commons_http([{"name": "v.webm", "mime": "video/webm"},
                              {"name": "v.ogv", "mime": "video/ogg"}])
    assert vc.crawl_source(app, db, vid_src, http=http) == 1
    assert VortexItem.query.filter_by(media_type="video").count() == 1


def test_auto_category_when_source_has_none(app, db):
    src = get_source(db, category=None, query="misc")
    http = make_commons_http([{"name": "gato.jpg", "title": "Gato cat kitten", "cats": "Cats",
                               "desc": "A cute cat"}])
    vc.crawl_source(app, db, src, http=http)
    assert VortexItem.query.one().category == "animais"


def test_api_error_is_recorded_not_raised_and_resets_page(app, db):
    src = get_source(db)
    src.next_page = 5
    db.session.commit()
    http = FakeHttp({"https://commons.wikimedia.org/": lambda u, k: FakeResp(500)})
    assert vc.crawl_source(app, db, src, http=http) == 0
    assert src.last_status.startswith("erro")
    assert src.next_page == 1


def test_keyed_source_is_skipped_without_key(app, db):
    src = get_source(db, kind="pexels", query="nature")
    assert vc.crawl_source(app, db, src, http=FakeHttp({})) == 0
    assert "sem PEXELS_API_KEY" in src.last_status


def test_openverse_and_giphy_adapters(app, db):
    ov = get_source(db, kind="openverse", category="animais", query="dogs")
    ov_payload = {"results": [
        {"url": "https://x.org/dog.jpg", "thumbnail": "https://api.openverse.org/v1/images/1/thumb/",
         "width": 1200, "height": 800, "title": "Dog", "tags": [{"name": "dog"}, {"name": "pet"}],
         "license": "by", "license_version": "4.0", "creator": "Ana",
         "foreign_landing_url": "https://x.org/p/1"},
        {"url": "https://x.org/mature.jpg", "mature": True, "width": 1200, "height": 800, "title": "x"},
    ]}
    http = FakeHttp({
        "https://api.openverse.org/v1/images/?": lambda u, k: FakeResp(200, json_data=ov_payload),
        "https://api.openverse.org/v1/images/1/thumb/": lambda u, k: FakeResp(
            200, content=png_bytes(2), headers={"Content-Type": "image/png"}),
    })
    # o fake roteia por prefixo; params vão em kwargs, então a URL base é "…/images/"
    http.routes["https://api.openverse.org/v1/images/"] = (
        lambda u, k: FakeResp(200, json_data=ov_payload) if "thumb" not in u else
        FakeResp(200, content=png_bytes(2), headers={"Content-Type": "image/png"}))
    assert vc.crawl_source(app, db, ov, http=http) == 1
    item = VortexItem.query.one()
    assert item.license == "BY 4.0" and item.attribution == "Ana" and "pet" in item.tag_list

    app.config["GIPHY_API_KEY"] = "k"
    gs = get_source(db, kind="giphy", media="gif", category="humor", query="funny")
    giphy = {"data": [{"title": "Funny cat", "url": "https://giphy.com/g/1", "username": "u",
                       "images": {"original": {"url": "https://media.giphy.com/1.gif", "width": "480",
                                               "height": "360", "size": "900000"},
                                  "fixed_width_still": {"url": "https://media.giphy.com/1s.gif"}}}],
             "pagination": {"total_count": 100}}
    http = FakeHttp({"https://api.giphy.com/": lambda u, k: FakeResp(200, json_data=giphy),
                     "https://media.giphy.com/1s.gif": lambda u, k: FakeResp(
                         200, content=png_bytes(9), headers={"Content-Type": "image/gif"})})
    assert vc.crawl_source(app, db, gs, http=http) == 1
    assert VortexItem.query.filter_by(media_type="gif").one().category == "humor"


def test_page_adapter_respects_robots(app, db):
    prof = VortexProfile.query.filter_by(handle="web").first()
    src = VortexCrawlSource(name="p", kind="page", profile_id=prof.id, category="arte",
                            term="https://blocked.example/page", media="photo")
    db.session.add(src)
    db.session.commit()
    vc._ROBOTS_CACHE.clear()
    http = FakeHttp({
        "https://blocked.example/robots.txt": lambda u, k: FakeResp(
            200, text="User-agent: *\nDisallow: /\n"),
    })
    assert vc.crawl_source(app, db, src, http=http) == 0
    assert "robots" in src.last_status

    vc._ROBOTS_CACHE.clear()
    src.term = "https://open.example/page"
    html = '<meta property="og:image" content="https://open.example/img/big.png">' \
           '<meta property="og:title" content="Obra de arte">'
    http = FakeHttp({
        "https://open.example/robots.txt": lambda u, k: FakeResp(404),
        "https://open.example/page": lambda u, k: FakeResp(200, text=html),
        "https://open.example/img/big.png": lambda u, k: FakeResp(
            200, content=png_bytes(3), headers={"Content-Type": "image/png",
                                                 "Content-Range": "bytes 0-1023/90000"}),
    })
    assert vc.crawl_source(app, db, src, http=http) == 1
    assert VortexItem.query.one().title == "Obra de arte"


# ---------------------------------------------------------------- endpoints
def _seed_items(db, n=5, category="natureza", media="photo", profile="commons", start=0):
    prof = VortexProfile.query.filter_by(handle=profile).first()
    for i in range(start, start + n):
        db.session.add(VortexItem(
            profile_id=prof.id, media_type=media, media_url=f"https://x.org/{category}{media}{i}.jpg",
            thumb_url=f"https://x.org/t/{category}{media}{i}.jpg", width=800, height=600,
            title=f"Item {i}", tags="a,b", category=category,
            url_hash=vc._hash_url(f"https://x.org/{category}{media}{i}.jpg"), phash=None,
        ))
    db.session.commit()


def test_vortex_requires_auth(app):
    assert app.test_client().get("/api/v1/vortex").status_code == 401


def test_vortex_grid_mixes_and_filters(app, db, user_token):
    uid, headers = user_token
    client = app.test_client()
    _seed_items(db, 40, "natureza", "photo")
    _seed_items(db, 5, "animais", "gif")
    _seed_items(db, 5, "humor", "video")
    from models import User
    post = Post(user_id=uid, post_type="photo", media_filename="p.jpg", duration_minutes=60)
    db.session.add(post)
    db.session.flush()
    db.session.add(PostMedia(post_id=post.id, filename="p.jpg", media_type="photo", position=0))
    db.session.commit()

    r = client.get("/api/v1/vortex", headers=headers).get_json()
    assert len(r["tiles"]) <= 30 and r["has_next"] and r["next_cursor"]
    sources = {t["source"] for t in r["tiles"]}
    assert sources == {"user", "crawler"}
    crawler_tile = next(t for t in r["tiles"] if t["source"] == "crawler")
    assert crawler_tile["profile"]["handle"] == "commons" and crawler_tile["author"] is None
    user_tile = next(t for t in r["tiles"] if t["source"] == "user")
    assert user_tile["author"]["username"] == "tester" and user_tile["post_id"] == post.id

    # filtro de categoria: só crawler
    r = client.get("/api/v1/vortex?category=animais", headers=headers).get_json()
    assert {t["category"] for t in r["tiles"]} == {"animais"} and len(r["tiles"]) == 5
    # filtro de tipo
    r = client.get("/api/v1/vortex?type=video", headers=headers).get_json()
    assert {t["media_type"] for t in r["tiles"]} == {"video"}
    assert client.get("/api/v1/vortex?type=zzz", headers=headers).status_code == 400
    assert client.get("/api/v1/vortex?category=zzz", headers=headers).status_code == 400


def test_vortex_pagination_has_no_repeats_or_gaps(app, db, user_token):
    _, headers = user_token
    client = app.test_client()
    _seed_items(db, 95, "natureza", "photo")
    seen, cursor, pages = [], None, 0
    while True:
        url = "/api/v1/vortex" + (f"?cursor={cursor}" if cursor else "")
        r = client.get(url, headers=headers).get_json()
        seen += [t["item_id"] for t in r["tiles"]]
        pages += 1
        cursor = r["next_cursor"]
        if not r["has_next"]:
            break
        assert pages < 10
    assert len(seen) == 95 and len(set(seen)) == 95


def test_crawler_items_never_reach_feed_or_search(app, db, user_token):
    _, headers = user_token
    _seed_items(db, 5)
    client = app.test_client()
    feed = client.get("/api/v1/feed", headers=headers).get_json()
    assert feed["posts"] == []
    pics = client.get("/api/v1/pictures", headers=headers).get_json()
    assert pics["tiles"] == []


def test_hidden_items_and_profiles_are_excluded(app, db, user_token):
    _, headers = user_token
    _seed_items(db, 3)
    client = app.test_client()
    first = VortexItem.query.first()
    first.is_active = False
    db.session.commit()
    r = client.get("/api/v1/vortex", headers=headers).get_json()
    assert len(r["tiles"]) == 2
    assert client.get(f"/api/v1/vortex/item/{first.id}", headers=headers).status_code == 404
    VortexProfile.query.filter_by(handle="commons").one().is_active = False
    db.session.commit()
    assert client.get("/api/v1/vortex", headers=headers).get_json()["tiles"] == []


def test_item_detail_and_profile_endpoint(app, db, user_token):
    _, headers = user_token
    _seed_items(db, 4, "natureza", "photo")
    _seed_items(db, 2, "humor", "gif", start=10)
    client = app.test_client()
    item = VortexItem.query.first()
    d = client.get(f"/api/v1/vortex/item/{item.id}", headers=headers).get_json()["item"]
    assert d["tags"] == ["a", "b"] and "source_url" in d and d["profile"]["is_bot"] is True
    p = client.get("/api/v1/vortex/profile/commons", headers=headers).get_json()
    assert p["counts"] == {"photos": 4, "gifs": 2, "videos": 0, "total": 6}
    assert len(p["tiles"]) == 6 and p["profile"]["display_name"] == "Wikimedia Commons"
    only_gif = client.get("/api/v1/vortex/profile/commons?type=gif", headers=headers).get_json()
    assert len(only_gif["tiles"]) == 2
    assert client.get("/api/v1/vortex/profile/naoexiste", headers=headers).status_code == 404


def test_prune_keeps_newest(app, db):
    app.config["VORTEX_MAX_ITEMS"] = 10
    _seed_items(db, 25)
    vc.prune_old_items(app, db)
    assert VortexItem.query.count() == 10
    assert VortexItem.query.order_by(VortexItem.id).first().id == 16


# -------------------------------------------------------------------- admin
def test_admin_pages_render_and_actions(app, db):
    from models import User
    admin = User(username="boss", email="b@example.com", is_admin=True)
    admin.set_password("senha1234")
    db.session.add(admin)
    db.session.commit()
    _seed_items(db, 3)
    client = app.test_client()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(admin.id)
        sess["_fresh"] = True
    r = client.get("/admin/vortex")
    assert r.status_code == 200 and b"Nova fonte" in r.data
    r = client.get("/admin/vortex/itens")
    assert r.status_code == 200
    item = VortexItem.query.first()
    client.post(f"/admin/vortex/itens/{item.id}/ocultar")
    assert db.session.get(VortexItem, item.id).is_active is False
    src = VortexCrawlSource.query.first()
    client.post(f"/admin/vortex/fontes/{src.id}/alternar")
    assert db.session.get(VortexCrawlSource, src.id).enabled is False
    prof = VortexProfile.query.first()
    r = client.post("/admin/vortex/fontes/nova", data={
        "name": "Nova", "kind": "commons", "query": "teste unico", "media": "photo",
        "profile_id": prof.id, "category": "arte"})
    assert VortexCrawlSource.query.filter_by(term="teste unico").count() == 1
