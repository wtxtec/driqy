"""Chat rico — Fase 9: tempo real (SSE), digitando, entregue/lido ao vivo."""
import json

import pytest

import chat_events
from chat_events import ChatHub, hub


@pytest.fixture(autouse=True)
def _clean_hub():
    hub.reset()
    yield
    hub.reset()


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = []
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out.append({"Authorization": f"Bearer {tok.token}"})
        return out


def _uid(app, name):
    from models import User
    with app.app_context():
        return User.query.filter_by(username=name).first().id


def _open(c, headers):
    resp = c.get("/api/v1/messages/stream", headers=headers, buffered=False)
    assert resp.status_code == 200
    return resp, iter(resp.response)


def _next_event(it):
    """Lê do fluxo até achar um evento completo; ignora 'retry' e 'ping'."""
    while True:
        chunk = next(it)
        if isinstance(chunk, bytes):
            chunk = chunk.decode()
        if chunk.startswith("event:"):
            lines = chunk.strip().split("\n")
            if lines[0][7:] == "presence":   # Fase 10 (coberto em test_chat_phase10): aqui não interessa
                continue
            return lines[0][7:], json.loads(lines[1][6:])


def _text(c, h, to, text):
    r = c.post(f"/api/v1/messages/{to}", headers=h, json={"content": text})
    assert r.status_code == 200, r.get_data(as_text=True)
    return r.get_json()


def _drain_ready(it):
    ev, data = _next_event(it)
    assert ev == "ready"
    return data


# ---------------- hub (unidade) ----------------

def test_hub_publish_subscribe_and_online():
    h = ChatHub()
    q = h.subscribe(1)
    assert h.is_online(1) and not h.is_online(2)
    assert h.publish(1, "x", {"a": 1}) == 1
    assert q.get_nowait() == ("x", {"a": 1})
    h.unsubscribe(1, q)
    assert not h.is_online(1)
    assert h.publish(1, "x") == 0


def test_hub_cap_drops_oldest():
    h = ChatHub(max_per_user=2)
    q1, q2, q3 = h.subscribe(1), h.subscribe(1), h.subscribe(1)
    assert h.connections(1) == 2
    assert q1.get_nowait() is None  # a mais antiga foi derrubada
    h.publish(1, "e")
    assert q2.get_nowait()[0] == "e" and q3.get_nowait()[0] == "e"


def test_hub_slow_client_gets_resync():
    h = ChatHub(queue_size=3)
    q = h.subscribe(1)
    for i in range(5):
        h.publish(1, "e", {"i": i})
    items = []
    while not q.empty():
        items.append(q.get_nowait())
    assert items[-1][0] in ("resync", "e")
    assert any(ev == "resync" for ev, _ in items)
    assert len(items) <= 3


def test_hub_typing_throttle():
    h = ChatHub()
    assert h.typing_allowed(1, 2) is True
    assert h.typing_allowed(1, 2) is False
    assert h.typing_allowed(1, 3) is True
    assert h.typing_allowed(2, 1) is True


def test_sse_format():
    out = chat_events.sse("message", {"partner": "ana", "t": "ç"})
    assert out.startswith("event: message\ndata: ") and out.endswith("\n\n")
    assert json.loads(out.split("data: ")[1]) == {"partner": "ana", "t": "ç"}


# ---------------- stream ----------------

def test_stream_requires_auth(app):
    c = app.test_client()
    assert c.get("/api/v1/messages/stream").status_code == 401


def test_stream_ready_and_headers(app, users):
    c = app.test_client()
    resp, it = _open(c, users[0])
    assert resp.mimetype == "text/event-stream"
    assert "no-cache" in resp.headers["Cache-Control"]
    assert resp.headers["X-Accel-Buffering"] == "no"
    assert _drain_ready(it)["user_id"] == _uid(app, "ana")
    assert hub.connections(_uid(app, "ana")) == 1
    resp.close()
    assert hub.connections(_uid(app, "ana")) == 0


def test_stream_disabled_returns_503(app, users):
    app.config["CHAT_SSE_ENABLED"] = False
    assert app.test_client().get("/api/v1/messages/stream", headers=users[0]).status_code == 503


def test_stream_close_without_reading_still_unsubscribes(app, users):
    c = app.test_client()
    resp = c.get("/api/v1/messages/stream", headers=users[0], buffered=False)
    assert hub.connections(_uid(app, "ana")) == 1
    resp.close()  # o gerador nunca começou
    assert hub.connections(_uid(app, "ana")) == 0


def test_message_event_goes_to_both_sides(app, users):
    c = app.test_client()
    ra, ita = _open(c, users[0])
    rb, itb = _open(c, users[1])
    _drain_ready(ita); _drain_ready(itb)
    m = _text(c, users[0], "beto", "oi")
    assert _next_event(itb) == ("message", {"partner": "ana", "id": m["id"]})
    assert _next_event(ita) == ("message", {"partner": "beto", "id": m["id"]})
    ra.close(); rb.close()


def test_stranger_gets_nothing(app, users):
    c = app.test_client()
    rc, itc = _open(c, users[2])
    _drain_ready(itc)
    _text(c, users[0], "beto", "privado")
    assert hub.publish(_uid(app, "caio"), "probe") == 1
    assert _next_event(itc)[0] == "probe"  # o primeiro evento é o probe: nada vazou antes
    rc.close()


def test_delivered_when_recipient_online(app, users):
    c = app.test_client()
    rb, itb = _open(c, users[1])
    _drain_ready(itb)
    m = _text(c, users[0], "beto", "chegou")
    assert m["delivered_at"] is not None and m["read_at"] is None
    rb.close()
    m2 = _text(c, users[0], "beto", "offline")
    assert m2["delivered_at"] is None


def test_connect_marks_pending_delivered_and_notifies_sender(app, users):
    c = app.test_client()
    ra, ita = _open(c, users[0])
    _drain_ready(ita)
    m = _text(c, users[0], "beto", "espera")
    assert m["delivered_at"] is None
    rb, itb = _open(c, users[1])   # beto abre o app
    ev = _next_event(ita)
    # ana recebe: o "message" que ela mesma gerou foi primeiro; depois "delivered"
    while ev[0] != "delivered":
        ev = _next_event(ita)
    assert ev[1] == {"partner": "beto"}
    thread = c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"]
    assert thread[0]["delivered_at"] is not None and thread[0]["read_at"] is None
    ra.close(); rb.close()


def test_inbox_marks_delivered(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "x")
    assert m["delivered_at"] is None
    c.get("/api/v1/messages", headers=users[1])
    t = c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"]
    assert t[0]["delivered_at"] is not None and t[0]["read_at"] is None


def test_read_event_and_delivered_not_overwritten(app, users):
    c = app.test_client()
    ra, ita = _open(c, users[0])
    _drain_ready(ita)
    m = _text(c, users[0], "beto", "leia")
    assert _next_event(ita)[0] == "message"
    c.get("/api/v1/messages", headers=users[1])  # entrega
    t0 = c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"][0]["delivered_at"]
    assert t0
    # drena "delivered"
    while _next_event(ita)[0] != "delivered":
        pass
    c.get("/api/v1/messages/ana", headers=users[1])  # beto abre a conversa = lê
    ev = _next_event(ita)
    assert ev == ("read", {"partner": "beto"})
    t = c.get("/api/v1/messages/beto", headers=users[0]).get_json()["messages"][0]
    assert t["read_at"] and t["delivered_at"] == t0  # entregue não foi sobrescrito pela leitura
    ra.close()


def test_read_self_event_for_other_tabs(app, users):
    c = app.test_client()
    _text(c, users[0], "beto", "x")
    rb, itb = _open(c, users[1])
    _drain_ready(itb)
    c.get("/api/v1/messages/ana", headers=users[1])
    assert _next_event(itb) == ("read_self", {"partner": "ana"})
    rb.close()


def test_update_events_edit_delete_reaction_hide(app, users):
    c = app.test_client()
    m = _text(c, users[0], "beto", "texto")
    rb, itb = _open(c, users[1])
    ra, ita = _open(c, users[0])
    _drain_ready(itb); _drain_ready(ita)
    c.patch(f"/api/v1/messages/{m['id']}", headers=users[0], json={"content": "novo"})
    assert _next_event(itb) == ("update", {"partner": "ana", "id": m["id"], "kind": "edit"})
    assert _next_event(ita) == ("update", {"partner": "beto", "id": m["id"], "kind": "edit"})
    c.put(f"/api/v1/messages/{m['id']}/reaction", headers=users[1], json={"emoji": "👍"})
    assert _next_event(ita)[1]["kind"] == "reaction"
    assert _next_event(itb)[1]["kind"] == "reaction"
    c.delete(f"/api/v1/messages/{m['id']}/reaction", headers=users[1])
    assert _next_event(ita)[1]["kind"] == "reaction"
    _next_event(itb)
    c.delete(f"/api/v1/messages/{m['id']}?scope=me", headers=users[0])  # só ana
    assert _next_event(ita) == ("update", {"partner": "beto", "id": m["id"], "kind": "hide"})
    n = _text(c, users[0], "beto", "outra")
    _next_event(ita); _next_event(itb)  # message x2 (beto: pode haver 'message' pendente)
    c.delete(f"/api/v1/messages/{n['id']}?scope=all", headers=users[0])
    evs = []
    for it in (itb,):
        ev = _next_event(it)
        while ev[0] != "update":
            ev = _next_event(it)
        evs.append(ev)
    assert evs[0][1]["kind"] == "delete"
    ra.close(); rb.close()


def test_forward_notifies_target(app, users):
    c = app.test_client()
    m = _text(c, users[1], "ana", "encaminhe")
    rc, itc = _open(c, users[2])
    _drain_ready(itc)
    r = c.post(f"/api/v1/messages/{m['id']}/forward", headers=users[0], json={"usernames": ["caio"]})
    assert r.status_code == 200
    ev = _next_event(itc)
    assert ev[0] == "message" and ev[1]["partner"] == "ana"
    assert r.get_json()["forwarded"][0]["message"]["delivered_at"] is not None  # caio estava online
    rc.close()


# ---------------- digitando ----------------

def test_typing_event_and_throttle(app, users):
    c = app.test_client()
    rb, itb = _open(c, users[1])
    _drain_ready(itb)
    url = "/api/v1/messages/beto/typing"
    r = c.post(url, headers=users[0], json={"state": "typing"})
    assert r.status_code == 200 and r.get_json()["delivered"] is True
    assert _next_event(itb) == ("typing", {"partner": "ana", "state": "typing"})
    # segundo aviso dentro de 1,5 s é ignorado
    assert c.post(url, headers=users[0], json={"state": "typing"}).get_json()["delivered"] is False
    # "stop" nunca é barrado
    assert c.post(url, headers=users[0], json={"state": "stop"}).get_json()["delivered"] is True
    assert _next_event(itb) == ("typing", {"partner": "ana", "state": "stop"})
    rb.close()


def test_typing_validation(app, users):
    c = app.test_client()
    assert c.post("/api/v1/messages/ana/typing", headers=users[0], json={}).status_code == 400  # a si mesma
    assert c.post("/api/v1/messages/fantasma/typing", headers=users[0], json={}).status_code == 404
    assert c.post("/api/v1/messages/beto/typing", headers=users[0], json={"state": "dançando"}).status_code == 400
    assert c.post("/api/v1/messages/beto/typing", json={"state": "typing"}).status_code == 401
    # offline: ok, mas ninguém recebeu
    r = c.post("/api/v1/messages/beto/typing", headers=users[0], json={"state": "typing"})
    assert r.status_code == 200 and r.get_json()["delivered"] is False


def test_typing_not_delivered_to_third_party(app, users):
    c = app.test_client()
    rc, itc = _open(c, users[2])
    _drain_ready(itc)
    c.post("/api/v1/messages/beto/typing", headers=users[0], json={"state": "typing"})
    hub.publish(_uid(app, "caio"), "probe")
    assert _next_event(itc)[0] == "probe"
    rc.close()


# ---------------- web: sessão e páginas ----------------

def test_web_pages_load_live_script(app, users):
    c = app.test_client()
    from extensions import db as _db
    from models import User
    with app.app_context():
        u = User.query.filter_by(username="ana").first()
        uid = u.id
    with c.session_transaction() as s:
        s["_user_id"] = str(uid)
        s["_fresh"] = True
    html = c.get("/mensagens/beto").get_data(as_text=True)
    assert "chat-live.js" in html and 'id="cw-partner-sub"' in html
    inbox = c.get("/mensagens/").get_data(as_text=True)
    assert "chat-live.js" in inbox
