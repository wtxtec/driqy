"""Flash (stories de 24h): publicar, anel no avatar, visto/não visto, expiração, permissões."""
import io
from datetime import timedelta

import pytest

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 200
EXE = b"MZ" + b"\x00" * 64


@pytest.fixture()
def users(app):
    from extensions import db as _db
    from models import ApiToken, User
    with app.app_context():
        out = {}
        for name in ("ana", "beto", "caio"):
            u = User(username=name, email=f"{name}@example.com")
            u.set_password("senha1234")
            _db.session.add(u)
            _db.session.commit()
            tok = ApiToken.generate_for(u)
            _db.session.commit()
            out[name] = (u.id, {"Authorization": f"Bearer {tok.token}"})
        return out


def _post(c, h, data=PNG, name="a.png", caption=None):
    form = {"file": (io.BytesIO(data), name, "image/png")}
    if caption is not None:
        form["caption"] = caption
    return c.post("/api/v1/flashes", headers=h, content_type="multipart/form-data", data=form)


def test_publish_and_ring_on_profile(app, users):
    c = app.test_client()
    _, ana = users["ana"]
    _, beto = users["beto"]
    assert c.get("/api/v1/users/ana", headers=beto).get_json()["has_flash"] is False
    r = _post(c, ana, caption="oi")
    assert r.status_code == 201
    fl = r.get_json()["flash"]
    assert fl["caption"] == "oi" and fl["image_url"]
    prof = c.get("/api/v1/users/ana", headers=beto).get_json()
    assert prof["has_flash"] is True and prof["flash_unseen"] is True


def test_seen_turns_ring_gray(app, users):
    c = app.test_client()
    _, ana = users["ana"]
    _, beto = users["beto"]
    fid = _post(c, ana).get_json()["flash"]["id"]
    assert c.post(f"/api/v1/flashes/{fid}/view", headers=beto).status_code == 200
    prof = c.get("/api/v1/users/ana", headers=beto).get_json()
    assert prof["has_flash"] is True and prof["flash_unseen"] is False
    # contador só aparece pro dono
    mine = c.get("/api/v1/users/ana/flashes", headers=ana).get_json()["flashes"][0]
    assert mine["views_count"] == 1
    theirs = c.get("/api/v1/users/ana/flashes", headers=beto).get_json()["flashes"][0]
    assert theirs["views_count"] is None and theirs["seen"] is True
    # ver duas vezes não duplica
    c.post(f"/api/v1/flashes/{fid}/view", headers=beto)
    assert c.get("/api/v1/users/ana/flashes", headers=ana).get_json()["flashes"][0]["views_count"] == 1


def test_rejects_non_image_even_with_png_name(app, users):
    c = app.test_client()
    _, ana = users["ana"]
    assert _post(c, ana, data=EXE, name="x.png").status_code == 400
    assert _post(c, ana, data=JPEG, name="x.jpg").status_code == 201


def test_expires_after_24h(app, users):
    from extensions import db
    from models import Flash, utcnow
    c = app.test_client()
    _, ana = users["ana"]
    _, beto = users["beto"]
    fl = _post(c, ana).get_json()["flash"]
    exp = c.get("/api/v1/users/ana/flashes", headers=beto).get_json()["flashes"][0]["expires_at"]
    assert exp  # ~24h à frente
    with app.app_context():
        row = Flash.query.get(fl["id"])
        assert timedelta(hours=23) < row.expires_at - row.created_at <= timedelta(hours=24)
        row.expires_at = utcnow() - timedelta(seconds=1)
        db.session.commit()
    assert c.get("/api/v1/users/ana", headers=beto).get_json()["has_flash"] is False
    assert c.get("/api/v1/users/ana/flashes", headers=beto).get_json()["flashes"] == []
    from scheduler import purge_expired_flashes
    assert purge_expired_flashes(app) == 1
    with app.app_context():
        assert Flash.query.count() == 0


def test_tray_orders_unseen_first_and_only_followed(app, users):
    from extensions import db
    from models import Follow
    c = app.test_client()
    ana_id, ana = users["ana"]
    beto_id, beto = users["beto"]
    caio_id, caio = users["caio"]
    with app.app_context():
        db.session.add_all([Follow(follower_id=ana_id, followed_id=beto_id),
                            Follow(follower_id=ana_id, followed_id=caio_id)])
        db.session.commit()
    _post(c, beto)
    fid = _post(c, caio).get_json()["flash"]["id"]
    c.post(f"/api/v1/flashes/{fid}/view", headers=ana)  # ana viu o do caio
    tray = c.get("/api/v1/flashes/tray", headers=ana).get_json()
    assert [i["user"]["username"] for i in tray["items"]] == ["beto", "caio"]
    assert [i["unseen"] for i in tray["items"]] == [True, False]
    # quem não é seguido não aparece
    assert c.get("/api/v1/flashes/tray", headers=caio).get_json()["items"] == []


def test_only_owner_can_delete_or_list_viewers(app, users):
    c = app.test_client()
    _, ana = users["ana"]
    _, beto = users["beto"]
    fid = _post(c, ana).get_json()["flash"]["id"]
    assert c.delete(f"/api/v1/flashes/{fid}", headers=beto).status_code == 403
    assert c.get(f"/api/v1/flashes/{fid}/viewers", headers=beto).status_code == 403
    c.post(f"/api/v1/flashes/{fid}/view", headers=beto)
    v = c.get(f"/api/v1/flashes/{fid}/viewers", headers=ana).get_json()["viewers"]
    assert [x["username"] for x in v] == ["beto"]
    assert c.delete(f"/api/v1/flashes/{fid}", headers=ana).status_code == 200
    assert c.get("/api/v1/users/ana/flashes", headers=ana).get_json()["flashes"] == []


def test_requires_login(app):
    c = app.test_client()
    assert c.get("/api/v1/flashes/tray").status_code == 401


def test_web_profile_shows_ring_class(app, users):
    c = app.test_client()
    _, ana = users["ana"]
    page = c.get("/u/ana")
    assert page.status_code == 200 and b"flash-ring" not in page.data.split(b"</style>")[-1]
    _post(c, ana)
    html = c.get("/u/ana").get_data(as_text=True)
    assert 'data-flash-user="ana"' in html and "flash-ring--unseen" in html
