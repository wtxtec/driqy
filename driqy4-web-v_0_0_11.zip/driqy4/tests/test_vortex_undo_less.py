"""Desfazer o "menos disso" (Parte 9)."""
import pathlib

import vortex_taste as vt
from models import VortexInteraction, VortexSeen
from tests.test_vortex_seen import mk_item, mk_user
from tests.test_vortex_web_actions import _login


def _rejected(user, it):
    return VortexSeen.query.filter_by(user_id=user.id, key=f"c{it.id}").first()


def test_undo_less_clears_signal_and_rejected(app, db):
    it, u = mk_item(db, "natureza"), mk_user(db, "undo1")
    assert vt.record(u.id, "less", item=it)
    assert _rejected(u, it).rejected is True
    assert vt.undo_less(u.id, item=it) == 1
    assert VortexInteraction.query.filter_by(user_id=u.id, kind="less").count() == 0
    row = _rejected(u, it)
    assert row.rejected is False and row.viewed_count >= 1
    assert vt.undo_less(u.id, item=it) == 0
    assert vt.undo_less(u.id) == 0


def test_endpoint_undo_less(app, db):
    it, u = mk_item(db, "natureza"), mk_user(db, "undo2")
    client = _login(app, u)
    r = client.post("/api/pictures/interact", json={"kind": "less", "item_id": it.id})
    assert r.status_code == 200 and _rejected(u, it).rejected is True
    r = client.post("/api/pictures/interact", json={"kind": "undo_less", "item_id": it.id})
    assert r.status_code == 200 and r.get_json()["recorded"] is True
    assert _rejected(u, it).rejected is False
    assert client.post("/api/pictures/interact", json={"kind": "xx", "item_id": it.id}).status_code == 400


def test_web_assets_have_undo():
    assert int(__import__("re").search(r"driqy-shell-v(\d+)", pathlib.Path("static/sw.js").read_text(encoding="utf-8")).group(1)) >= 57  # versão do cache do SW só pode subir
    js = pathlib.Path("static/js/vortex.js").read_text(encoding="utf-8")
    assert "undo_less" in js and "Desfazer" in js
