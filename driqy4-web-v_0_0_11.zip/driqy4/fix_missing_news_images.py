"""
Script de correção única: tenta buscar uma imagem (og:image da página
original) para as notícias JÁ SALVAS no banco que ficaram sem imagem —
essas são as que aparecem como card de cor sólida, sem foto.

Sem esse script, a melhoria no fallback de busca de imagem
(news_indexer.py) só vale pra notícias novas.

Como rodar (na raiz do projeto, com o venv ativado):
    python fix_missing_news_images.py
"""
import time

from app import create_app
from extensions import db
from models import NewsArticle
from news_indexer import _fetch_og_image

# pausa entre requisições pra não sobrecarregar os sites de origem
_DELAY_SECONDS = 0.3


def main():
    app = create_app()
    with app.app_context():
        articles = NewsArticle.query.filter(
            (NewsArticle.image_url.is_(None)) | (NewsArticle.image_url == "")
        ).all()

        print(f"{len(articles)} notícia(s) sem imagem encontrada(s). Buscando...")
        found = 0
        for i, article in enumerate(articles, start=1):
            image_url = _fetch_og_image(article.url)
            if image_url:
                article.image_url = image_url[:700]
                found += 1
            if i % 20 == 0:
                db.session.commit()
                print(f"  ...{i}/{len(articles)} processadas, {found} imagem(ns) encontrada(s) até agora")
            time.sleep(_DELAY_SECONDS)

        db.session.commit()
        print(f"Concluído: {found} de {len(articles)} notícia(s) ganharam imagem.")


if __name__ == "__main__":
    main()
