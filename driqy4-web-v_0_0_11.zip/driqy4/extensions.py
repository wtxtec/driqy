from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from authlib.integrations.flask_client import OAuth
from sqlalchemy import event
from sqlalchemy.engine import Engine

db = SQLAlchemy()
login_manager = LoginManager()


@event.listens_for(Engine, "connect")
def _set_sqlite_pragmas(dbapi_connection, connection_record):
    """Roda em toda nova conexão SQLite: WAL permite leitura/escrita
    simultâneas (o modo padrão bloqueia o banco inteiro numa escrita), e
    busy_timeout faz o SQLite esperar em vez de falhar na hora quando
    encontra outra conexão escrevendo. Isso é o que evita o
    "database is locked" que aparecia quando o scheduler de notícias e uma
    requisição (ou dois processos do reloader) escreviam ao mesmo tempo.
    Só faz sentido pra SQLite; outros bancos (Postgres etc.) ignoram
    silenciosamente se o driver não tiver esse método."""
    if not hasattr(dbapi_connection, "execute"):
        return
    try:
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        # com WAL, NORMAL é seguro e bem mais rápido pra gravações em lote
        # (o crawler do Vortex grava o tempo todo)
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.close()
    except Exception:
        pass
login_manager.login_view = "auth.login"
login_manager.login_message = "Faça login para continuar."
login_manager.login_message_category = "warning"

oauth = OAuth()
