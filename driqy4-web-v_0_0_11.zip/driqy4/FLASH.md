# Flash (stories de 24h)

- Publicar: `POST /api/v1/flashes` (multipart `file` + `caption`). Dura `FLASH_TTL_HOURS` (24h, `config.py`).
- Anel no avatar: `has_flash` / `flash_unseen` em todo `serialize_user`; no site, classe `flash-ring--unseen|seen`.
- Bandeja: `GET /api/v1/flashes/tray`. Ver: `GET /api/v1/users/<u>/flashes` + `POST /flashes/<id>/view`.
- Dono: `GET /flashes/<id>/viewers`, `DELETE /flashes/<id>`.
- Limpeza: job `purge_expired_flashes` (scheduler, a cada 60s) apaga banco + arquivo.
- Tabelas novas (`flashes`, `flash_views`) são criadas sozinhas pelo `db.create_all()` ao subir o app.
- Para renomear "Flash" na interface: textos em `static/js/flash.js` e `lib/widgets/flash_ring.dart`.
