# Alertas de clima antecipados (proposta para implementar depois)

Objetivo: avisar o usuário **antes** do tempo mudar, sem ele abrir o widget.
Exemplos: "Prepare o guarda-chuva: chuva a partir das 13h amanhã" ou
"Fim de semana chuvoso à vista (sex–dom)", enviado já na quinta.

Reaproveita o que já existe: coordenadas da cidade no perfil (`location_lat/lng`),
Open-Meteo (`widgets_weather.py`), o APScheduler (`scheduler.py` e o job de
notícias em `app.py`), a tabela `Notification` e o push FCM (`push.py`,
`send_push_to_user`).

---

## 1. Tipos de alerta (começar pelos três primeiros)

| Código | Quando dispara | Texto de exemplo |
|---|---|---|
| `rain_soon` | Chuva provável nas próximas ~24h | "Prepare o guarda-chuva ☂️ Chuva a partir das 13h, amanhã." |
| `rain_weekend` | Sáb/dom com chuva provável, avisado de quarta a sexta | "Fim de semana chuvoso: sábado e domingo com previsão de chuva." |
| `storm` | Tempestade/granizo (códigos WMO 95, 96, 99) nas próximas 48h | "Tempestade prevista para amanhã à tarde. Evite deixar roupas no varal." |
| `heat` | Máxima ≥ limite (ex.: 35 °C) | "Calorão amanhã: máxima de 36°. Hidrate-se." |
| `cold` | Mínima ≤ limite (ex.: 8 °C) ou queda de ≥ 8 °C | "Frio chegando: mínima de 7° amanhã." |
| `wind` | Rajadas ≥ 60 km/h | "Ventania prevista a partir das 15h." |

Os limites de calor e frio variam por região (30 °C é normal em Manaus, não em
Curitiba). Em vez de números fixos, usar o limite relativo ao clima da cidade
(ex.: máxima acima do percentil 90 dos últimos 30 dias) ou deixar configurável.

## 2. Dados de previsão

Open-Meteo, uma chamada por cidade (não por usuário), com horas e dias:

```
GET https://api.open-meteo.com/v1/forecast
  ?latitude=..&longitude=..&timezone=auto&forecast_days=4
  &hourly=precipitation_probability,precipitation,weather_code,wind_gusts_10m,temperature_2m
  &daily=weather_code,precipitation_probability_max,precipitation_sum,temperature_2m_max,temperature_2m_min
```

- Agrupar usuários por **cidade arredondada** (`round(lat,1)`, `round(lng,1)` ≈ 11 km)
  e buscar a previsão uma vez por grupo. Mil usuários em 50 cidades = 50 chamadas.
- Cache em memória (`TTLCache`) de 30 a 60 min por grupo.
- `timezone=auto` devolve horários no fuso local da cidade: o "a partir das 13h"
  é a hora local do usuário.

### Regra de chuva (`rain_soon`)
1. Olhar as próximas 24 h.
2. Achar a primeira hora com `precipitation_probability ≥ 60` **e** `precipitation ≥ 0,3 mm`.
3. Exigir pelo menos 2 horas seguidas (evita alerta por um chuvisco de 1 h).
4. Texto: "a partir das HHh" + "hoje"/"amanhã". Se for já nas próximas 2 h: "Chuva chegando em breve".

### Regra de fim de semana (`rain_weekend`)
- Rodar de **quarta a sexta**. Sábado e domingo entram se
  `precipitation_probability_max ≥ 60` ou `precipitation_sum ≥ 5 mm`.
- Mensagem diferente para 1 dia ("Sábado chuvoso") e 2 dias ("Fim de semana chuvoso").
- Enviar no máximo **um** alerta de fim de semana por usuário por semana
  (chave `rain_weekend:2026-W44`).

## 3. Quando e quanto enviar

- **Job** a cada 30 min (APScheduler, mesmo padrão do job de notícias, só no
  processo "dono" do scheduler). Para cada cidade com usuários ativos, calcula
  os alertas candidatos.
- **Horário de silêncio**: nunca enviar entre 22h e 7h no fuso do usuário.
  Se o alerta cair na janela, adiar para 7h (se ainda fizer sentido).
- **Limite diário**: no máximo 2 alertas de clima por usuário por dia.
- **Sem repetição**: cada alerta tem uma `dedupe_key`
  (`rain_soon:2026-11-02:13h`). Se já foi enviado, não repete, a não ser que a
  previsão mude de forma relevante (começo da chuva adiantado em 2 h ou mais).
- **Antecedência**: `rain_soon` ~3 a 6 h antes do início (e um aviso de véspera às 18–20h
  se for chover cedo no dia seguinte); `rain_weekend` na quinta (ou na quarta,
  se a previsão for forte); `storm` ~24 h antes e de novo ~3 h antes.
- **Cancelamento**: se a previsão virar e a chuva não vier mais, não mandar aviso de
  "falso alarme" (ruído). Só atualizar a notificação ainda não lida, se houver.

## 4. Modelo de dados

Duas tabelas novas, mais colunas no usuário.

```python
class WeatherAlertPref(db.Model):       # 1 linha por usuário (criada na primeira vez que ele mexe)
    user_id        # PK/FK
    enabled        # bool, padrão True
    kinds          # string CSV: "rain,storm,heat,cold,wind" (cada tipo liga/desliga)
    quiet_start    # "22:00"
    quiet_end      # "07:00"
    push_enabled   # bool (push FCM além da notificação dentro do app)

class WeatherAlertLog(db.Model):        # histórico + anti-repetição
    id
    user_id        # index
    kind           # "rain_soon", "rain_weekend", ...
    dedupe_key     # único por (user_id, dedupe_key)
    payload_json   # horário previsto, probabilidade, cidade
    sent_at
```

`Notification` hoje exige `actor_id` e tem `KIND_LIKE/COMMENT/FOLLOW/REPLY`.
Para alertas do sistema:
- novo `KIND_WEATHER = "weather"`;
- `actor_id` passa a aceitar nulo (migração em `app.py`, no mesmo estilo das outras
  colunas) **ou** usar um usuário "sistema" fixo;
- guardar o texto pronto em uma coluna nova `body` (e `meta_json`), já que o
  texto não deriva de post/comentário;
- ajustar `notifications.html`, `notifications.js` e `NotificationsScreen` (app)
  para renderizar `kind == "weather"` com ícone do clima e sem avatar.

## 5. Entrega

1. **Dentro do app/site**: cria `Notification(kind="weather")` → aparece no sino
   e na lista (já existem).
2. **Push (FCM)**: `send_push_to_user(user_id, title, body, data={"type":"weather","screen":"home"})`.
   Respeitar `push_enabled` e o horário de silêncio. Canal Android próprio
   ("Clima") para o usuário poder silenciar só isso no sistema.
3. **Toque na notificação**: abre o Feed com o widget de clima já selecionado
   (no app estreito, onde não há painel direito, abrir uma tela simples
   "Previsão" com os próximos dias; ver "Fase 3").

## 6. Configuração do usuário

Em Configurações (site e app), seção "Alertas de clima":
- Interruptor geral.
- Interruptores por tipo (chuva, tempestade, calor/frio, vento).
- Horário de silêncio.
- "Receber por push" ligado/desligado.
- Cidade usada: mostra a cidade do perfil (link para editar). A região escolhida só no widget
  **não** muda os alertas, a menos que o usuário peça ("Receber alertas desta região").

Endpoints sugeridos (`/api/v1`):
- `GET /weather/alerts/prefs` e `POST /weather/alerts/prefs`
- `GET /weather/alerts/preview`: o que seria avisado agora (útil para testar e para o widget)

## 7. Privacidade e custo

- Só o centro da cidade é usado (já é o que o perfil guarda). Nenhum rastreio por GPS.
- Usuário sem cidade no perfil não recebe alerta; o widget convida a escolher a cidade (já faz isso).
- Open-Meteo é gratuito para uso não comercial, com limite de requisições diárias. O agrupamento
  por cidade mantém o volume baixo; para uso comercial é preciso plano pago ou outro provedor.
  Se a chamada falhar, **não** enviar nada e tentar na próxima rodada.
- Dar a opção de desligar tudo em um toque. Alerta que incomoda faz o usuário desligar as notificações do app inteiro.

## 8. Plano em fases

**Fase 1 (MVP, ~2 dias):** `rain_soon` e `rain_weekend`, notificação dentro do app + push,
tabela de log com dedupe, horário de silêncio fixo (22h–7h), interruptor geral.

**Fase 2:** tempestade, calor/frio, vento; tela de preferências por tipo; limite
diário; limites de calor/frio relativos à região.

**Fase 3:** tela "Previsão" (próximas horas e 7 dias), alertas para a região salva no widget,
resumo matinal opcional ("Hoje: 22°, chuva às 16h"), prévia "o que eu receberia".

## 9. Testes

- Unitários (sem rede, previsão simulada): chuva às 13h de amanhã gera "a partir das 13h, amanhã";
  1 hora isolada de chuva não gera alerta; quinta com sábado chuvoso gera `rain_weekend` uma vez só;
  dedupe impede repetir; horário de silêncio adia; limite diário respeitado; usuário com `enabled=False` não recebe.
- Fuso: usuário em fuso diferente do servidor recebe a hora local certa.
- Falha do Open-Meteo: nada enviado, sem exceção no job.
- Integração: job cria `Notification` e chama `send_push_to_user` uma vez.

## 10. Texto dos alertas (tom)

Curto, útil, com a hora. Evitar alarmismo.
- "Prepare o guarda-chuva ☂️ Chuva a partir das 13h, amanhã."
- "Fim de semana chuvoso à vista: sábado e domingo com chuva. Planeje com antecedência."
- "Tempestade prevista para amanhã à tarde. Cuidado com ventos e alagamentos."
- "Frio chegando: mínima de 7° amanhã. Hora de pegar o casaco."
