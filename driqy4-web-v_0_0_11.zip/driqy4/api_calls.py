"""Chamadas de voz/vídeo — Fase 11: SINALIZAÇÃO (offer/answer/ICE/estado).

O áudio/vídeo não passa por aqui: vai direto entre os aparelhos (WebRTC), ou via TURN
quando a rede não deixa (ver COTURN.md). Este módulo só troca os "bilhetes" (SDP e
candidatos ICE) e guarda o estado da chamada.

Eventos SSE (além dos da Fase 9; `partner` = @ do outro lado):
  call_incoming  -> callee: {call_id, partner, media, created_at, ring_seconds, offer}
  call_signal    -> o outro lado: {call_id, partner, kind: answer|ice, answer?|candidate?}
  call_state     -> os dois lados: {call_id, partner, state, reason, by}
Diferente dos eventos de mensagem, estes CARREGAM corpo (SDP/ICE): não dá para "rebuscar"
com latência aceitável. Quem conecta tarde recupera pelo REST (`GET /calls/active`,
`GET /calls/<id>`). Sem stream aberto, só o push avisa (a Fase 14 cuida do app fechado).

Regras: só os dois participantes enxergam a chamada (outros -> 404); cada usuário tem no
máximo UMA chamada viva; `ringing` expira (CALL_RING_SECONDS -> `missed`); `accepted` sem
ping/ICE por CALL_STALE_SECONDS é encerrada (`stale`); SDP <= 16 KB; ICE limitado por chamada.
Chamadas IGNORAM "silenciar conversa" (silenciar vale só para mensagens).
LIMITE: barramento/timers vivem em UM processo (igual à Fase 9).
"""
import base64
import hashlib
import hmac
import json
import threading
import time
from datetime import timedelta

from flask import current_app, jsonify, request

from api import api_bp, chat_login_required, current_api_user, serialize_user
from chat_events import hub
from extensions import db
from models import Call, User, utcnow

ACTIVE = ("ringing", "accepted")
MEDIA = ("voice", "video")

_lock = threading.Lock()
_ice = {}      # call_id -> {"buf": {user_id: [candidatos]}, "count": {user_id: n}}
_timers = {}   # call_id -> threading.Timer (toque expirando)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _iso(dt):
    return dt.isoformat() + "Z" if dt else None


def _cfg(name, default):
    return current_app.config.get(name, default)


def _err(msg, status=400, **extra):
    return jsonify({"error": msg, **extra}), status


def _other(call, user_id):
    return call.callee if call.caller_id == user_id else call.caller


def _duration(call):
    if call.answered_at and call.ended_at:
        return max(0, int((call.ended_at - call.answered_at).total_seconds()))
    return 0


def serialize_call(call, viewer, with_signal=False):
    partner = _other(call, viewer.id)
    out = {
        "id": call.id,
        "media": call.media,
        "state": call.state,
        "end_reason": call.end_reason,
        "direction": "outgoing" if call.caller_id == viewer.id else "incoming",
        "partner": serialize_user(partner, viewer),
        "created_at": _iso(call.created_at),
        "answered_at": _iso(call.answered_at),
        "ended_at": _iso(call.ended_at),
        "duration_s": _duration(call),
        "ring_seconds": int(_cfg("CALL_RING_SECONDS", 45)),
    }
    if with_signal and call.state in ACTIVE:
        if call.callee_id == viewer.id:
            out["offer"] = _sdp_obj("offer", call.offer_sdp)
        elif call.state == "accepted":
            out["answer"] = _sdp_obj("answer", call.answer_sdp)
        with _lock:
            out["ice"] = list(_ice.get(call.id, {}).get("buf", {}).get(partner.id, []))
    return out


def _sdp_obj(kind, sdp):
    return {"type": kind, "sdp": sdp} if sdp else None


def _parse_sdp(value, kind):
    """`{"type": kind, "sdp": "..."}` -> (sdp, erro). Aceita também a string crua."""
    if isinstance(value, dict):
        if value.get("type") not in (None, kind):
            return None, (f"O campo precisa ser do tipo {kind}.", 400)
        value = value.get("sdp")
    if not isinstance(value, str) or not value.strip():
        return None, (f"Envie {kind} com o SDP.", 400)
    if len(value.encode("utf-8")) > int(_cfg("CALL_SDP_MAX_BYTES", 16 * 1024)):
        return None, ("SDP grande demais.", 413)
    if not value.lstrip().startswith("v="):
        return None, ("SDP inválido.", 400)
    return value, None


def reset():
    """Zera buffers de ICE e cancela timers (usado nos testes: cada banco novo recomeça os ids)."""
    for t in list(_timers.values()):
        t.cancel()
    _timers.clear()
    with _lock:
        _ice.clear()


def _cancel_timer(call_id):
    t = _timers.pop(call_id, None)
    if t is not None:
        t.cancel()


def _forget(call_id):
    _cancel_timer(call_id)
    with _lock:
        _ice.pop(call_id, None)


def _announce_state(call, reason=None, by=None):
    """Avisa os dois lados (`call_state`)."""
    for me, other in ((call.caller, call.callee), (call.callee, call.caller)):
        hub.publish(me.id, "call_state", {
            "call_id": call.id, "partner": other.username, "state": call.state,
            "reason": reason or call.end_reason, "by": by or "",
        })


def _finish(call_id, from_states, state, reason, by=None):
    """Transição atômica para um estado final: só vence quem encontrar a chamada ainda num
    dos `from_states` (duas ações simultâneas não passam as duas). Devolve a Call ou None."""
    now = utcnow()
    n = Call.query.filter(Call.id == call_id, Call.state.in_(from_states)).update(
        {"state": state, "end_reason": reason, "ended_at": now, "offer_sdp": None, "answer_sdp": None},
        synchronize_session=False)
    db.session.commit()
    if not n:
        return None
    _forget(call_id)
    call = db.session.get(Call, call_id)
    db.session.refresh(call)
    _announce_state(call, reason, by)
    log_call_message(call)
    return call


def _fmt_dur(sec):
    sec = max(0, int(sec or 0))
    return f"{sec // 60}:{sec % 60:02d}"


def call_message_label(call):
    """Rótulo neutro (vale para os dois lados) da mensagem de chamada na conversa."""
    kind = "vídeo" if call.media == "video" else "voz"
    icon = "📹" if call.media == "video" else "📞"
    if call.state == "ended":
        return f"{icon} Chamada de {kind} · {_fmt_dur(_duration(call))}"
    if call.state == "missed":
        return f"{icon} Chamada de {kind} perdida"
    if call.state == "declined":
        return f"{icon} Chamada de {kind} recusada"
    if call.state == "busy":
        return f"{icon} Chamada de {kind} · ocupado"
    return f"{icon} Chamada de {kind} falhou"


def log_call_message(call):
    """Fase 14: grava UMA mensagem `msg_type=call` na conversa quando a chamada termina.
    Idempotente (client_id = `call:<id>`). `media_mime` = `call/<voice|video>/<estado>`;
    `media_duration_ms` = duração. Remetente = quem ligou. Só perdida fica como não lida.
    Nunca derruba a chamada."""
    try:
        from models import Message
        from api import _after_send
        cid = f"call:{call.id}"
        if Message.query.filter_by(client_id=cid).first() is not None:
            return None
        msg = Message(
            sender_id=call.caller_id, recipient_id=call.callee_id,
            content=call_message_label(call), msg_type="call", client_id=cid,
            media_mime=f"call/{call.media}/{call.state}"[:60],
            media_duration_ms=_duration(call) * 1000,
            is_read=call.state != "missed",
            created_at=call.ended_at or utcnow(),
        )
        db.session.add(msg)
        db.session.commit()
        _after_send(msg, call.caller, call.callee)
        return msg
    except Exception:
        db.session.rollback()
        return None


def _push_call(callee, caller, call):
    from push import send_push_to_user
    kind = "vídeo" if call.media == "video" else "voz"
    send_push_to_user(callee.id, title=caller.display_label, body=f"Chamada de {kind} recebida",
                      data={"type": "call", "call_id": call.id, "media": call.media,
                            "username": caller.username})


def _push_missed(call):
    from push import send_push_to_user
    caller = call.caller
    kind = "vídeo" if call.media == "video" else "voz"
    send_push_to_user(call.callee_id, title=caller.display_label, body=f"Chamada de {kind} perdida",
                      data={"type": "call_missed", "call_id": call.id, "media": call.media,
                            "username": caller.username})


def _mark_missed(call_id, reason, by=None):
    call = _finish(call_id, ("ringing",), "missed", reason, by)
    if call is not None:
        try:
            _push_missed(call)
        except Exception:  # push nunca derruba a chamada
            pass
    return call


def _expire(call):
    """Expiração preguiçosa (vale mesmo se o Timer se perdeu num reinício). Devolve a chamada atual."""
    now = utcnow()
    if call.state == "ringing":
        ring = int(_cfg("CALL_RING_SECONDS", 45))
        if now - call.created_at > timedelta(seconds=ring):
            return _mark_missed(call.id, "timeout") or db.session.get(Call, call.id)
    elif call.state == "accepted":
        stale = int(_cfg("CALL_STALE_SECONDS", 90))
        last = call.heartbeat_at or call.answered_at or call.created_at
        if now - last > timedelta(seconds=stale):
            return _finish(call.id, ("accepted",), "ended", "stale") or db.session.get(Call, call.id)
    return call


def _active_call_for(user_id):
    rows = Call.query.filter(
        Call.state.in_(ACTIVE), (Call.caller_id == user_id) | (Call.callee_id == user_id)
    ).order_by(Call.id.desc()).all()
    for c in rows:
        c = _expire(c)
        if c is not None and c.state in ACTIVE:
            return c
    return None


def _schedule_ring_timeout(app, call_id, seconds):
    def work():
        with app.app_context():
            try:
                _timers.pop(call_id, None)
                _mark_missed(call_id, "timeout")
            except Exception:
                db.session.rollback()
    t = threading.Timer(max(1, seconds), work)
    t.daemon = True
    _timers[call_id] = t
    t.start()


def _participant_call(call_id, user):
    call = db.session.get(Call, call_id)
    if call is None or user.id not in (call.caller_id, call.callee_id):
        return None
    return _expire(call)


def _ice_servers(user):
    cfg = current_app.config
    servers = []
    stun = list(cfg.get("CALL_STUN_URLS") or [])
    if stun:
        servers.append({"urls": stun})
    turn = list(cfg.get("CALL_TURN_URLS") or [])
    if turn:
        secret = cfg.get("CALL_TURN_SECRET") or ""
        if secret:  # coturn `use-auth-secret`: usuário = expira:id, senha = HMAC-SHA1
            exp = int(time.time()) + int(cfg.get("CALL_TURN_TTL_SECONDS", 6 * 3600))
            username = f"{exp}:{user.id}"
            cred = base64.b64encode(hmac.new(secret.encode(), username.encode(), hashlib.sha1).digest()).decode()
            servers.append({"urls": turn, "username": username, "credential": cred})
        elif cfg.get("CALL_TURN_USERNAME"):
            servers.append({"urls": turn, "username": cfg["CALL_TURN_USERNAME"],
                            "credential": cfg.get("CALL_TURN_CREDENTIAL", "")})
        else:
            servers.append({"urls": turn})
    return servers


# ---------------------------------------------------------------------------
# rotas
# ---------------------------------------------------------------------------

def _enabled():
    if not _cfg("CALL_ENABLED", True):
        return _err("Chamadas desativadas neste servidor.", 503)
    return None


@api_bp.route("/calls/config", methods=["GET"])
@chat_login_required
def call_config():
    """Servidores ICE (STUN/TURN) + tempos. Com `CALL_TURN_SECRET` a credencial TURN é
    temporária e própria do usuário. `turn_configured=false` -> só STUN (falha em ~10–20% das redes)."""
    user = current_api_user()
    return jsonify({
        "enabled": bool(_cfg("CALL_ENABLED", True)),
        "ice_servers": _ice_servers(user),
        "turn_configured": bool(_cfg("CALL_TURN_URLS", [])),
        "ring_seconds": int(_cfg("CALL_RING_SECONDS", 45)),
        "ping_seconds": int(_cfg("CALL_PING_SECONDS", 20)),
    })


@api_bp.route("/calls/active", methods=["GET"])
@chat_login_required
def call_active():
    """Minha chamada viva (tocando ou em andamento), ou `{"call": null}`. O cliente chama ao
    conectar o stream/abrir o app para retomar a tela de chamada."""
    user = current_api_user()
    call = _active_call_for(user.id)
    return jsonify({"call": serialize_call(call, user, with_signal=True) if call else None})


@api_bp.route("/calls", methods=["GET"])
@chat_login_required
def call_history():
    """Histórico (mais recentes primeiro). `limit` (30, máx. 100) e `before_id` paginam."""
    user = current_api_user()
    try:
        limit = max(1, min(100, int(request.args.get("limit", 30))))
    except ValueError:
        limit = 30
    q = Call.query.filter((Call.caller_id == user.id) | (Call.callee_id == user.id))
    before = request.args.get("before_id", type=int)
    if before:
        q = q.filter(Call.id < before)
    rows = q.order_by(Call.id.desc()).limit(limit + 1).all()
    more = len(rows) > limit
    rows = [_expire(c) or c for c in rows[:limit]]
    return jsonify({"calls": [serialize_call(c, user) for c in rows], "has_more": more})


@api_bp.route("/calls/<username>", methods=["POST"])
@chat_login_required
def call_start(username):
    """Inicia uma chamada. JSON `{"media": "voice"|"video", "offer": {"type":"offer","sdp":"v=0..."},
    "client_id"?}`. 409 `busy` (o outro está em chamada) ou `already_in_call` (eu estou).
    Responde 201 com a chamada; o outro lado recebe `call_incoming` (+ push)."""
    off = _enabled()
    if off:
        return off
    user = current_api_user()
    callee = User.query.filter_by(username=username).first()
    if callee is None or callee.is_banned:
        return _err("Usuário não encontrado.", 404)
    if callee.id == user.id:
        return _err("Você não pode ligar para si mesmo.")
    data = request.get_json(silent=True) or {}
    media = (data.get("media") or "voice").lower()
    if media not in MEDIA:
        return _err("media precisa ser voice ou video.")
    sdp, e = _parse_sdp(data.get("offer"), "offer")
    if e:
        return _err(*e)
    client_id = str(data.get("client_id") or "")[:64] or None

    if client_id:  # reenvio seguro
        dup = Call.query.filter_by(caller_id=user.id, client_id=client_id).first()
        if dup is not None:
            return jsonify(serialize_call(_expire(dup) or dup, user, with_signal=True)), 200

    mine = _active_call_for(user.id)
    if mine is not None:
        return _err("Você já está em uma chamada.", 409, code="already_in_call", call_id=mine.id)

    if _active_call_for(callee.id) is not None:
        now = utcnow()
        call = Call(caller_id=user.id, callee_id=callee.id, media=media, state="busy", end_reason="busy",
                    client_id=client_id, created_at=now, ended_at=now)
        db.session.add(call)
        db.session.commit()
        log_call_message(call)
        return _err("Ocupado em outra chamada.", 409, code="busy", call_id=call.id)

    call = Call(caller_id=user.id, callee_id=callee.id, media=media, state="ringing",
                client_id=client_id, offer_sdp=sdp)
    db.session.add(call)
    db.session.commit()

    ring = int(_cfg("CALL_RING_SECONDS", 45))
    _schedule_ring_timeout(current_app._get_current_object(), call.id, ring)
    hub.publish(callee.id, "call_incoming", {
        "call_id": call.id, "partner": user.username, "media": media,
        "created_at": _iso(call.created_at), "ring_seconds": ring, "offer": _sdp_obj("offer", sdp),
    })
    # minhas outras abas/aparelhos sabem que estou ligando
    hub.publish(user.id, "call_state", {"call_id": call.id, "partner": callee.username,
                                        "state": "ringing", "reason": None, "by": user.username})
    try:
        _push_call(callee, user, call)
    except Exception:
        pass
    return jsonify(serialize_call(call, user, with_signal=True)), 201


@api_bp.route("/calls/<int:call_id>", methods=["GET"])
@chat_login_required
def call_get(call_id):
    """Estado da chamada. Enquanto viva traz `offer` (callee), `answer` (caller, após aceitar) e `ice`
    (candidatos já enviados pelo outro lado — o cliente aplica os que perdeu)."""
    user = current_api_user()
    call = _participant_call(call_id, user)
    if call is None:
        return _err("Chamada não encontrada.", 404)
    return jsonify(serialize_call(call, user, with_signal=True))


@api_bp.route("/calls/<int:call_id>/answer", methods=["POST"])
@chat_login_required
def call_answer(call_id):
    """O destinatário atende: `{"answer": {"type":"answer","sdp":"..."}}`. Só `ringing` -> `accepted`.
    O chamador recebe `call_signal`(answer); os dois lados (e minhas outras abas) recebem `call_state`."""
    user = current_api_user()
    call = _participant_call(call_id, user)
    if call is None:
        return _err("Chamada não encontrada.", 404)
    if call.callee_id != user.id:
        return _err("Só quem recebe a chamada pode atendê-la.", 403)
    sdp, e = _parse_sdp((request.get_json(silent=True) or {}).get("answer"), "answer")
    if e:
        return _err(*e)
    if call.state != "ringing":
        return _err("Esta chamada não está mais tocando.", 409, state=call.state)
    now = utcnow()
    n = Call.query.filter(Call.id == call.id, Call.state == "ringing").update(
        {"state": "accepted", "answered_at": now, "heartbeat_at": now, "answer_sdp": sdp},
        synchronize_session=False)
    db.session.commit()
    if not n:
        return _err("Esta chamada não está mais tocando.", 409)
    _cancel_timer(call.id)
    call = db.session.get(Call, call.id)
    db.session.refresh(call)
    hub.publish(call.caller_id, "call_signal", {
        "call_id": call.id, "partner": call.callee.username, "kind": "answer",
        "answer": _sdp_obj("answer", sdp)})
    _announce_state(call, None, user.username)
    return jsonify(serialize_call(call, user, with_signal=True))


@api_bp.route("/calls/<int:call_id>/decline", methods=["POST"])
@chat_login_required
def call_decline(call_id):
    """O destinatário recusa (só enquanto toca)."""
    user = current_api_user()
    call = _participant_call(call_id, user)
    if call is None:
        return _err("Chamada não encontrada.", 404)
    if call.callee_id != user.id:
        return _err("Só quem recebe a chamada pode recusá-la.", 403)
    if call.state in ACTIVE:
        done = _finish(call.id, ("ringing",), "declined", "declined", user.username)
        if done is None:
            call = db.session.get(Call, call.id)
            return _err("Esta chamada não está mais tocando.", 409, state=call.state)
        call = done
    return jsonify(serialize_call(call, user))


@api_bp.route("/calls/<int:call_id>/end", methods=["POST"])
@chat_login_required
def call_end(call_id):
    """Encerra. Em andamento -> `ended` (hangup; com `{"reason":"error"}` -> `failed`). Tocando: o CHAMADOR cancela (`missed`/canceled, o
    outro recebe push de perdida); o DESTINATÁRIO recusa (`declined`). Idempotente."""
    user = current_api_user()
    call = _participant_call(call_id, user)
    if call is None:
        return _err("Chamada não encontrada.", 404)
    if call.state == "accepted":
        # Fase 12: falha de mídia (WebRTC não conectou) -> `failed`/`error`; senão desligar normal.
        errored = (request.get_json(silent=True) or {}).get("reason") == "error"
        st, why = ("failed", "error") if errored else ("ended", "hangup")
        call = _finish(call.id, ("accepted",), st, why, user.username) or db.session.get(Call, call.id)
    elif call.state == "ringing":
        if call.caller_id == user.id:
            call = _mark_missed(call.id, "canceled", user.username) or db.session.get(Call, call.id)
        else:
            call = _finish(call.id, ("ringing",), "declined", "declined", user.username) or db.session.get(Call, call.id)
    return jsonify(serialize_call(call, user))


@api_bp.route("/calls/<int:call_id>/ice", methods=["POST"])
@chat_login_required
def call_ice(call_id):
    """Candidato ICE para o outro lado: `{"candidate": {...}}` (objeto do `RTCIceCandidate`).
    `null` (fim dos candidatos) é aceito e ignorado. Limites: 2 KB cada, `CALL_ICE_MAX_PER_CALL`
    por usuário e chamada (excesso -> 429). Também conta como sinal de vida."""
    user = current_api_user()
    call = _participant_call(call_id, user)
    if call is None:
        return _err("Chamada não encontrada.", 404)
    if call.state not in ACTIVE:
        return _err("Chamada encerrada.", 409, state=call.state)
    cand = (request.get_json(silent=True) or {}).get("candidate")
    if cand is None:
        return jsonify({"ok": True, "relayed": False})
    if not isinstance(cand, dict):
        return _err("candidate inválido.")
    if len(json.dumps(cand, ensure_ascii=False).encode("utf-8")) > int(_cfg("CALL_ICE_MAX_BYTES", 2048)):
        return _err("Candidato grande demais.", 413)
    partner = _other(call, user.id)
    with _lock:
        slot = _ice.setdefault(call.id, {"buf": {}, "count": {}})
        n = slot["count"].get(user.id, 0)
        if n >= int(_cfg("CALL_ICE_MAX_PER_CALL", 150)):
            return _err("Candidatos demais nesta chamada.", 429)
        slot["count"][user.id] = n + 1
        slot["buf"].setdefault(user.id, []).append(cand)
    if call.state == "accepted":
        call.heartbeat_at = utcnow()
        db.session.commit()
    hub.publish(partner.id, "call_signal", {
        "call_id": call.id, "partner": user.username, "kind": "ice", "candidate": cand})
    return jsonify({"ok": True, "relayed": True})


@api_bp.route("/calls/<int:call_id>/ping", methods=["POST"])
@chat_login_required
def call_ping(call_id):
    """Sinal de vida (a cada `ping_seconds`). Sem ele, a chamada aceita é encerrada como `stale`
    (app fechado/sem rede não deixa o usuário \"ocupado\" para sempre). Devolve o estado atual."""
    user = current_api_user()
    call = _participant_call(call_id, user)
    if call is None:
        return _err("Chamada não encontrada.", 404)
    if call.state == "accepted":
        call.heartbeat_at = utcnow()
        db.session.commit()
    return jsonify({"state": call.state, "end_reason": call.end_reason})
