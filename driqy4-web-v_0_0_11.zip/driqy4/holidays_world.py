"""Feriados por país para o widget Calendário (parte 2 do "calendário no mundo todo").

Cada país tem uma função `{data: (nome, tipo)}` por ano; tipo = `feriado` (nacional), `facultativo` ou `data`
(só comemorativa). Móveis saem da Páscoa ou de "n-ésima segunda-feira do mês"; nada vem da rede.
Só feriados NACIONAIS: estaduais, municipais e "ponte"/dia compensado quando cai no fim de semana ficam de fora.
Países sem tabela aqui caem no Brasil (padrão do site) e o seletor do widget deixa a pessoa escolher.
"""
import re
from datetime import date, timedelta

H, F, D = "feriado", "facultativo", "data"


def _easter(year):
    import widgets_extra
    return widgets_extra.easter(year)


def nth_weekday(year, month, weekday, n):
    """n-ésimo [weekday] (0 = segunda … 6 = domingo) do mês."""
    first = date(year, month, 1)
    return first + timedelta(days=(weekday - first.weekday()) % 7 + 7 * (n - 1))


def last_weekday(year, month, weekday):
    nxt = date(year + (month == 12), month % 12 + 1, 1)
    last = nxt - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _fixed(year, table, kind=H):
    return {date(year, m, d): (n, kind) for (m, d), n in table.items()}


def _br(year):
    import widgets_extra
    return widgets_extra.holidays(year)


def _pt(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (4, 25): "Dia da Liberdade", (5, 1): "Dia do Trabalhador", (6, 10): "Dia de Portugal",
                        (8, 15): "Assunção de Nossa Senhora", (10, 5): "Implantação da República", (11, 1): "Todos os Santos",
                        (12, 1): "Restauração da Independência", (12, 8): "Imaculada Conceição", (12, 25): "Natal"})
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", H)
    out[e] = ("Páscoa", H)
    out[e + timedelta(days=60)] = ("Corpo de Deus", H)
    out[e - timedelta(days=47)] = ("Carnaval", F)
    return out


def _us(year):
    out = _fixed(year, {(1, 1): "Ano Novo", (6, 19): "Juneteenth", (7, 4): "Dia da Independência", (11, 11): "Dia dos Veteranos",
                        (12, 25): "Natal"})
    out[nth_weekday(year, 1, 0, 3)] = ("Dia de Martin Luther King Jr.", H)
    out[nth_weekday(year, 2, 0, 3)] = ("Dia dos Presidentes", H)
    out[last_weekday(year, 5, 0)] = ("Memorial Day", H)
    out[nth_weekday(year, 9, 0, 1)] = ("Dia do Trabalho", H)
    out[nth_weekday(year, 10, 0, 2)] = ("Dia de Colombo / Povos Indígenas", H)
    out[nth_weekday(year, 11, 3, 4)] = ("Ação de Graças", H)
    return out


def _gb(year):  # Inglaterra e País de Gales
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (12, 25): "Natal", (12, 26): "Boxing Day"})
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", H)
    out[e] = ("Páscoa", D)
    out[e + timedelta(days=1)] = ("Segunda-feira de Páscoa", H)
    out[nth_weekday(year, 5, 0, 1)] = ("Early May Bank Holiday", H)
    out[last_weekday(year, 5, 0)] = ("Spring Bank Holiday", H)
    out[last_weekday(year, 8, 0)] = ("Summer Bank Holiday", H)
    return out


def _es(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (1, 6): "Reis Magos", (5, 1): "Dia do Trabalhador", (8, 15): "Assunção",
                        (10, 12): "Festa Nacional da Espanha", (11, 1): "Todos os Santos", (12, 6): "Dia da Constituição",
                        (12, 8): "Imaculada Conceição", (12, 25): "Natal"})
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", H)
    out[e] = ("Páscoa", D)
    return out


def _fr(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (5, 1): "Dia do Trabalho", (5, 8): "Vitória de 1945", (7, 14): "Festa Nacional",
                        (8, 15): "Assunção", (11, 1): "Todos os Santos", (11, 11): "Armistício de 1918", (12, 25): "Natal"})
    out[e] = ("Páscoa", D)
    out[e + timedelta(days=1)] = ("Segunda-feira de Páscoa", H)
    out[e + timedelta(days=39)] = ("Ascensão", H)
    out[e + timedelta(days=50)] = ("Segunda-feira de Pentecostes", H)
    return out


def _de(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (5, 1): "Dia do Trabalho", (10, 3): "Dia da Unidade Alemã",
                        (12, 25): "Natal", (12, 26): "Segundo dia de Natal"})
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", H)
    out[e] = ("Páscoa", D)
    out[e + timedelta(days=1)] = ("Segunda-feira de Páscoa", H)
    out[e + timedelta(days=39)] = ("Ascensão", H)
    out[e + timedelta(days=50)] = ("Segunda-feira de Pentecostes", H)
    return out


def _it(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (1, 6): "Epifania", (4, 25): "Dia da Libertação", (5, 1): "Dia do Trabalho",
                        (6, 2): "Festa da República", (8, 15): "Ferragosto", (11, 1): "Todos os Santos",
                        (12, 8): "Imaculada Conceição", (12, 25): "Natal", (12, 26): "Santo Estêvão"})
    out[e] = ("Páscoa", H)
    out[e + timedelta(days=1)] = ("Segunda-feira de Páscoa", H)
    return out


def _ar(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (3, 24): "Dia da Memória", (4, 2): "Dia das Malvinas", (5, 1): "Dia do Trabalhador",
                        (5, 25): "Revolução de Maio", (6, 20): "Dia da Bandeira", (7, 9): "Dia da Independência",
                        (12, 8): "Imaculada Conceição", (12, 25): "Natal"})
    out[e - timedelta(days=48)] = ("Carnaval", H)
    out[e - timedelta(days=47)] = ("Carnaval", H)
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", H)
    return out


def _mx(year):
    out = _fixed(year, {(1, 1): "Ano Novo", (5, 1): "Dia do Trabalho", (9, 16): "Dia da Independência", (12, 25): "Natal"})
    out[nth_weekday(year, 2, 0, 1)] = ("Dia da Constituição", H)
    out[nth_weekday(year, 3, 0, 3)] = ("Natalício de Benito Juárez", H)
    out[nth_weekday(year, 11, 0, 3)] = ("Dia da Revolução", H)
    return out


def _ca(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (7, 1): "Dia do Canadá", (9, 30): "Verdade e Reconciliação", (12, 25): "Natal"})
    out[date(year, 12, 26)] = ("Boxing Day", D)
    out[date(year, 11, 11)] = ("Dia da Lembrança", D)
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", H)
    may25 = date(year, 5, 25)
    out[may25 - timedelta(days=(may25.weekday() - 0) % 7 or 7)] = ("Dia da Rainha Vitória", H)  # segunda anterior a 25/5
    out[nth_weekday(year, 9, 0, 1)] = ("Dia do Trabalho", H)
    out[nth_weekday(year, 10, 0, 2)] = ("Ação de Graças", H)
    return out


def _jp(year):
    y = year - 1980
    spring = int(20.8431 + 0.242194 * y - y // 4)   # equinócios (fórmula válida de 1980 a 2099)
    autumn = int(23.2488 + 0.242194 * y - y // 4)
    out = _fixed(year, {(1, 1): "Ano Novo", (2, 11): "Dia da Fundação", (2, 23): "Aniversário do Imperador",
                        (4, 29): "Dia Shōwa", (5, 3): "Dia da Constituição", (5, 4): "Dia do Verde", (5, 5): "Dia das Crianças",
                        (8, 11): "Dia da Montanha", (11, 3): "Dia da Cultura", (11, 23): "Ação de Graças do Trabalho"})
    out[date(year, 3, spring)] = ("Equinócio da Primavera", H)
    out[date(year, 9, autumn)] = ("Equinócio de Outono", H)
    out[nth_weekday(year, 1, 0, 2)] = ("Dia da Maioridade", H)
    out[nth_weekday(year, 7, 0, 3)] = ("Dia do Mar", H)
    out[nth_weekday(year, 9, 0, 3)] = ("Respeito aos Idosos", H)
    out[nth_weekday(year, 10, 0, 2)] = ("Dia do Esporte", H)
    return out


def _au(year):
    e = _easter(year)
    out = _fixed(year, {(1, 1): "Ano Novo", (1, 26): "Dia da Austrália", (4, 25): "Dia Anzac", (12, 25): "Natal",
                        (12, 26): "Boxing Day"})
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", H)
    out[e - timedelta(days=1)] = ("Sábado de Páscoa", H)
    out[e + timedelta(days=1)] = ("Segunda-feira de Páscoa", H)
    return out


# código -> (nome, função)
COUNTRIES = {
    "BR": ("Brasil", _br), "PT": ("Portugal", _pt), "US": ("Estados Unidos", _us), "GB": ("Reino Unido (Inglaterra)", _gb),
    "ES": ("Espanha", _es), "FR": ("França", _fr), "DE": ("Alemanha", _de), "IT": ("Itália", _it),
    "AR": ("Argentina", _ar), "MX": ("México", _mx), "CA": ("Canadá", _ca), "JP": ("Japão", _jp), "AU": ("Austrália", _au),
}
DEFAULT_COUNTRY = "BR"

_TZ_EXACT = {"Europe/Lisbon": "PT", "Atlantic/Azores": "PT", "Atlantic/Madeira": "PT", "Europe/London": "GB",
             "Europe/Madrid": "ES", "Atlantic/Canary": "ES", "Europe/Paris": "FR", "Europe/Berlin": "DE", "Europe/Rome": "IT",
             "Asia/Tokyo": "JP", "America/Mexico_City": "MX", "America/Cancun": "MX", "America/Monterrey": "MX",
             "America/Merida": "MX", "America/Tijuana": "MX", "America/Chihuahua": "MX", "America/Hermosillo": "MX"}
_TZ_PREFIX = (("America/Argentina/", "AR"), ("Australia/", "AU"))
_TZ_US = {"New_York", "Chicago", "Denver", "Los_Angeles", "Phoenix", "Anchorage", "Detroit", "Boise", "Indiana/Indianapolis",
          "Kentucky/Louisville", "Juneau", "Adak"}
_TZ_CA = {"Toronto", "Vancouver", "Edmonton", "Winnipeg", "Halifax", "St_Johns", "Regina", "Montreal", "Moncton", "Whitehorse"}
_TZ_BR = {"Sao_Paulo", "Fortaleza", "Recife", "Bahia", "Manaus", "Belem", "Cuiaba", "Campo_Grande", "Rio_Branco", "Noronha",
          "Araguaina", "Maceio", "Porto_Velho", "Boa_Vista", "Santarem", "Eirunepe"}


def country_from_tz(tz):
    """Código do país pelo nome do fuso (só os países com tabela); None se não souber."""
    if not isinstance(tz, str):
        return None
    if tz in _TZ_EXACT:
        return _TZ_EXACT[tz]
    for prefix, code in _TZ_PREFIX:
        if tz.startswith(prefix):
            return code
    if tz.startswith("America/") or tz == "Pacific/Honolulu":
        city = tz.split("/", 1)[1]
        if tz == "Pacific/Honolulu" or city in _TZ_US:
            return "US"
        if city in _TZ_CA:
            return "CA"
        if city in _TZ_BR:
            return "BR"
    if tz == "Pacific/Honolulu":
        return "US"
    return None


def resolve_country(country=None, tz=None):
    """(código, escolhido_pelo_usuário). Ordem: escolha explícita > fuso > Brasil."""
    if isinstance(country, str) and re.fullmatch(r"[A-Za-z]{2}", country) and country.upper() in COUNTRIES:
        return country.upper(), True
    return country_from_tz(tz) or DEFAULT_COUNTRY, False


def holidays_for(country, year):
    return COUNTRIES.get(country, COUNTRIES[DEFAULT_COUNTRY])[1](year)


def country_options():
    return [{"code": c, "name": n} for c, (n, _) in COUNTRIES.items()]


# ---------------------------------------------------------------- idioma e semana por região (parte 3)
# Idioma dos nomes de mês/dia da semana e primeiro dia da semana (0 = domingo, 1 = segunda), como no CLDR.
# Os NOMES DOS FERIADOS continuam em português (o site e o app são em português).
REGION_LANG = {"BR": "pt", "PT": "pt", "US": "en", "GB": "en", "ES": "es", "FR": "fr", "DE": "de", "IT": "it",
               "AR": "es", "MX": "es", "CA": "en", "JP": "ja", "AU": "en"}
WEEK_START = {"BR": 0, "PT": 0, "US": 0, "GB": 1, "ES": 1, "FR": 1, "DE": 1, "IT": 1, "AR": 1, "MX": 0, "CA": 0,
              "JP": 0, "AU": 0}
MONTH_NAMES = {
    "pt": ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
           "novembro", "dezembro"],
    "en": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
           "November", "December"],
    "es": ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
           "noviembre", "diciembre"],
    "fr": ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
           "novembre", "décembre"],
    "de": ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober",
           "November", "Dezember"],
    "it": ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre",
           "novembre", "dicembre"],
    "ja": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
}
# iniciais dos dias da semana, de domingo a sábado
WEEKDAY_INITIALS = {
    "pt": ["D", "S", "T", "Q", "Q", "S", "S"], "en": ["S", "M", "T", "W", "T", "F", "S"],
    "es": ["D", "L", "M", "X", "J", "V", "S"], "fr": ["D", "L", "M", "M", "J", "V", "S"],
    "de": ["S", "M", "D", "M", "D", "F", "S"], "it": ["D", "L", "M", "M", "G", "V", "S"],
    "ja": ["日", "月", "火", "水", "木", "金", "土"],
}


def region_info(country):
    """{lang, week_start, month_names, weekdays} do país (desconhecido = Brasil). `weekdays` já vem na ordem da
    grade (começando no primeiro dia da semana da região)."""
    code = country if country in COUNTRIES else DEFAULT_COUNTRY
    lang = REGION_LANG.get(code, "pt")
    ws = WEEK_START.get(code, 0)
    base = WEEKDAY_INITIALS[lang]
    return {"lang": lang, "week_start": ws, "month_names": MONTH_NAMES[lang], "weekdays": base[ws:] + base[:ws]}
