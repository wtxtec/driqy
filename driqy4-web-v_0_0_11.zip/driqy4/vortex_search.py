"""
Busca, "mais como este", estatísticas e categorias do Vortex (Parte 3).

Tudo aqui trabalha só com os itens do crawler (`vortex_items`); posts de
usuários não têm título/tags/categoria, então só entram nas contagens da
`vortex_stats`.

Busca
-----
Usa uma tabela virtual SQLite FTS5 (`vortex_items_fts`, "external content"
ligada a `vortex_items` por gatilhos) sobre title + tags + description +
category, com `remove_diacritics` (busca "cachoeira" acha "Cachoeira" e
"cachoeirá"). O ranking é bm25 (título pesa mais que tags, que pesam mais que
descrição) misturado com um pouco de recência. Se o SQLite do usuário não tiver
FTS5, ou se a consulta falhar, cai numa busca LIKE com ranking por tokens
(`mode == "like"` no resultado).

"Mais como este"
----------------
Sinais, do mais forte pro mais fraco: distância de Hamming do dHash (só
quando os dois itens têm `phash`), tags em comum (Jaccard), palavras em comum
no título, mesma categoria, mesmo tipo de mídia; o mesmo perfil só desempata.
Funciona sem `phash` (só tags/título/categoria). Quase-duplicatas (mesma
imagem em outra URL) são omitidas. Itens sem nenhum sinal real só entram
depois dos que têm (preenchimento por categoria, pra rolagem infinita).

Paginação
---------
Busca e similares devolvem uma lista ranqueada (até `VORTEX_SEARCH_MAX_RESULTS`
/ `VORTEX_RELATED_MAX_RESULTS`) e paginam por deslocamento (`cursor` = "o30").
Se o crawler gravar itens novos entre duas páginas, o ranking pode mudar um
pouco — o cliente deve ignorar peças com `key` repetida.
"""
import math
import re
import threading
import time
import unicodedata
from datetime import datetime, timedelta

from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import joinedload

from cache import TTLCache
from extensions import db
from models import Post, PostMedia, VortexInteraction, VortexItem, VortexProfile, utcnow
import vortex_concepts as vcn
import vortex_vision as vv
from vortex_phash import DUPLICATE_DISTANCE, SIMILAR_DISTANCE, hamming

try:
    import numpy as np
except Exception:  # sem numpy: sem índice visual (cai nos sinais de texto/phash)
    np = None

VORTEX_TYPES = ("photo", "gif", "video")

FTS_TABLE = "vortex_items_fts"
_FTS_COLUMNS = "title, tags, description, category"
# pesos do bm25, na ordem das colunas acima
_BM25_WEIGHTS = "10.0, 6.0, 2.0, 3.0"

_TOKEN_RE = re.compile(r"\w+", re.UNICODE)
_QUERY_STOPWORDS = {
    "de", "da", "do", "das", "dos", "e", "a", "o", "as", "os", "em", "no", "na", "um", "uma",
    "the", "of", "and", "in", "on", "at", "to", "for",
}
MAX_QUERY_TOKENS = 8

_popcount = int.bit_count if hasattr(int, "bit_count") else (lambda n: bin(n).count("1"))


# ---------------------------------------------------------------------------
# configuração
# ---------------------------------------------------------------------------

def _cfg(app, name, default):
    return app.config.get(name, default)


def page_size(app):
    return _cfg(app, "VORTEX_PAGE_SIZE", 30)


# ---------------------------------------------------------------------------
# cursores
# ---------------------------------------------------------------------------

def parse_grid_cursor(raw):
    """\"p123|c456\" -> (123, 456). Parte ausente/inválida = None (sem limite)."""
    post_cursor = item_cursor = None
    for part in (raw or "").split("|"):
        if part[:1] == "p" and part[1:].isdigit():
            post_cursor = int(part[1:])
        elif part[:1] == "c" and part[1:].isdigit():
            item_cursor = int(part[1:])
    return post_cursor, item_cursor


def format_grid_cursor(post_cursor, item_cursor):
    parts = []
    if post_cursor is not None:
        parts.append(f"p{post_cursor}")
    if item_cursor is not None:
        parts.append(f"c{item_cursor}")
    return "|".join(parts)


def parse_offset_cursor(raw):
    """Converte "o30" em 30. Qualquer coisa inválida vira 0."""
    raw = (raw or "").strip()
    if raw[:1] == "o" and raw[1:].isdigit():
        return int(raw[1:])
    return 0


def format_offset_cursor(offset):
    return f"o{int(offset)}"


# ---------------------------------------------------------------------------
# consulta base (itens visíveis)
# ---------------------------------------------------------------------------

def item_query(category=None, media_type=None):
    """Itens ativos de perfis ativos, com filtros opcionais."""
    query = (
        VortexItem.query.join(VortexProfile, VortexItem.profile_id == VortexProfile.id)
        .filter(VortexItem.is_active.is_(True), VortexProfile.is_active.is_(True))
    )
    if category:
        query = query.filter(VortexItem.category == category)
    if media_type:
        query = query.filter(VortexItem.media_type == media_type)
    return query


def load_items(ids):
    """Carrega itens visíveis pelos ids, NA ORDEM de `ids` (some quem estiver oculto)."""
    if not ids:
        return []
    rows = (
        item_query().options(joinedload(VortexItem.profile))
        .filter(VortexItem.id.in_(list(ids))).all()
    )
    by_id = {r.id: r for r in rows}
    return [by_id[i] for i in ids if i in by_id]


# ---------------------------------------------------------------------------
# índice FTS5
# ---------------------------------------------------------------------------

def _ext(app):
    return app.extensions.setdefault("vortex_search", {"fts": None})


def fts_available(app):
    """True se o índice FTS5 foi criado e está em uso neste app."""
    return bool(_ext(app).get("fts"))


def ensure_search_index(app, database=None):
    """Cria (se faltar) a tabela FTS5 + gatilhos e reindexa se o número de
    linhas não bater com `vortex_items`. Idempotente, seguro a cada subida.
    Devolve True se o FTS5 está disponível."""
    database = database or db
    state = _ext(app)
    try:
        with database.engine.begin() as conn:
            conn.execute(text(
                f"CREATE VIRTUAL TABLE IF NOT EXISTS {FTS_TABLE} USING fts5("
                f"{_FTS_COLUMNS}, content='vortex_items', content_rowid='id', "
                "tokenize='unicode61 remove_diacritics 2', prefix='2 3')"
            ))
            conn.execute(text(
                "CREATE TRIGGER IF NOT EXISTS vortex_items_fts_ai AFTER INSERT ON vortex_items BEGIN "
                f"INSERT INTO {FTS_TABLE}(rowid, {_FTS_COLUMNS}) "
                "VALUES (new.id, new.title, new.tags, new.description, new.category); END"
            ))
            conn.execute(text(
                "CREATE TRIGGER IF NOT EXISTS vortex_items_fts_ad AFTER DELETE ON vortex_items BEGIN "
                f"INSERT INTO {FTS_TABLE}({FTS_TABLE}, rowid, {_FTS_COLUMNS}) "
                "VALUES ('delete', old.id, old.title, old.tags, old.description, old.category); END"
            ))
            conn.execute(text(
                "CREATE TRIGGER IF NOT EXISTS vortex_items_fts_au "
                "AFTER UPDATE OF title, tags, description, category ON vortex_items BEGIN "
                f"INSERT INTO {FTS_TABLE}({FTS_TABLE}, rowid, {_FTS_COLUMNS}) "
                "VALUES ('delete', old.id, old.title, old.tags, old.description, old.category); "
                f"INSERT INTO {FTS_TABLE}(rowid, {_FTS_COLUMNS}) "
                "VALUES (new.id, new.title, new.tags, new.description, new.category); END"
            ))
            total = conn.execute(text("SELECT COUNT(*) FROM vortex_items")).scalar()
            indexed = conn.execute(text(f"SELECT COUNT(*) FROM {FTS_TABLE}_docsize")).scalar()
            if total != indexed:
                conn.execute(text(f"INSERT INTO {FTS_TABLE}({FTS_TABLE}) VALUES ('rebuild')"))
        state["fts"] = True
    except Exception as exc:  # sem FTS5 (ou banco que não é SQLite): usa LIKE
        app.logger.warning("Vortex: FTS5 indisponível (%s); busca usará LIKE.", exc)
        state["fts"] = False
    return state["fts"]


def rebuild_search_index(app, database=None):
    """Reconstrói o índice do zero (use se suspeitar que ficou fora de sincronia)."""
    database = database or db
    if not fts_available(app):
        return False
    with database.engine.begin() as conn:
        conn.execute(text(f"INSERT INTO {FTS_TABLE}({FTS_TABLE}) VALUES ('rebuild')"))
    return True


# ---------------------------------------------------------------------------
# interpretação da consulta
# ---------------------------------------------------------------------------

def _strip_accents(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def tokenize_query(raw):
    """Palavras da busca: minúsculas, sem pontuação, sem stopwords (a menos que
    só sobrem stopwords), no máx. MAX_QUERY_TOKENS, sem repetir."""
    words = [w for w in _TOKEN_RE.findall((raw or "").lower()) if len(w) >= 2]
    seen, all_tokens = set(), []
    for w in words:
        w = w[:40]
        if w not in seen:
            seen.add(w)
            all_tokens.append(w)
    meaningful = [w for w in all_tokens if w not in _QUERY_STOPWORDS]
    return (meaningful or all_tokens)[:MAX_QUERY_TOKENS]


def _variants(token):
    """Formas do token que valem a mesma busca (plural simples pt/en)."""
    out = [token]
    if token.endswith("s") and len(token) > 3:
        out.append(token[:-1])
    if token.endswith("es") and len(token) > 4:
        out.append(token[:-2])
    return out


def _fts_group(token):
    parts = []
    for v in _variants(token):
        parts.append(f'"{v}"*' if len(v) >= 3 else f'"{v}"')
    return "(" + " OR ".join(parts) + ")"


def build_match(tokens, mode="and"):
    """Expressão MATCH do FTS5 (tokens só têm letras/números: seguros pra aspas)."""
    joiner = " AND " if mode == "and" else " OR "
    return joiner.join(_fts_group(t) for t in tokens)


# ---------------------------------------------------------------------------
# ranking
# ---------------------------------------------------------------------------

def _parse_dt(value):
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def _recency(created_at, now, half_life_days=30.0):
    dt = _parse_dt(created_at)
    if dt is None:
        return 0.0
    age_days = max(0.0, (now - dt).total_seconds() / 86400.0)
    return 0.5 ** (age_days / half_life_days)


def _blend(rows, now):
    """rows: [(id, relevance>=0, created_at)] -> ids ordenados por relevância
    normalizada (85 %) + recência (15 %); empate: id mais novo primeiro."""
    if not rows:
        return []
    top = max(r[1] for r in rows) or 1.0
    scored = []
    for item_id, rel, created_at in rows:
        score = 0.85 * (rel / top) + 0.15 * _recency(created_at, now)
        scored.append((-round(score, 6), -item_id, item_id))
    scored.sort()
    return [s[2] for s in scored]


# ---------------------------------------------------------------------------
# busca
# ---------------------------------------------------------------------------

def _fts_candidates(match, category, media_type, limit):
    sql = (
        f"SELECT i.id AS id, -bm25({FTS_TABLE}, {_BM25_WEIGHTS}) AS rel, i.created_at AS created_at "
        f"FROM {FTS_TABLE} JOIN vortex_items i ON i.id = {FTS_TABLE}.rowid "
        "JOIN vortex_profiles p ON p.id = i.profile_id "
        f"WHERE {FTS_TABLE} MATCH :m AND i.is_active = 1 AND p.is_active = 1 "
    )
    params = {"m": match, "k": limit}
    if category:
        sql += "AND i.category = :c "
        params["c"] = category
    if media_type:
        sql += "AND i.media_type = :t "
        params["t"] = media_type
    sql += "ORDER BY rel DESC LIMIT :k"
    rows = db.session.execute(text(sql), params).all()
    return [(r.id, max(float(r.rel or 0.0), 0.0), r.created_at) for r in rows]


def _like_candidates(tokens, mode, category, media_type, limit):
    """Fallback sem FTS5: LIKE em título/tags/descrição; relevância = onde o
    termo aparece (título 3, tags 2, descrição 1) somado por token."""
    def token_clause(tok):
        variants = {v for t in _variants(tok) for v in (t, _strip_accents(t))}
        clauses = []
        for v in variants:
            clauses += [
                db.func.lower(VortexItem.title).contains(v, autoescape=True),
                db.func.lower(VortexItem.tags).contains(v, autoescape=True),
                db.func.lower(VortexItem.description).contains(v, autoescape=True),
            ]
        return db.or_(*clauses)

    clauses = [token_clause(t) for t in tokens]
    query = item_query(category, media_type).filter(
        db.and_(*clauses) if mode == "and" else db.or_(*clauses)
    )
    rows = query.order_by(VortexItem.id.desc()).limit(limit).all()
    out = []
    for r in rows:
        title, tags, desc = (r.title or "").lower(), (r.tags or "").lower(), (r.description or "").lower()
        rel = 0.0
        for tok in tokens:
            vs = _variants(tok)
            rel += 3.0 * any(v in title for v in vs) + 2.0 * any(v in tags for v in vs) \
                + 1.0 * any(v in desc for v in vs)
        out.append((r.id, rel, r.created_at))
    return out


def _run_search(app, tokens, mode, category, media_type, limit):
    """(candidatos, motor usado). Cai pra LIKE se o FTS5 falhar."""
    if fts_available(app):
        try:
            return _fts_candidates(build_match(tokens, mode), category, media_type, limit), "fts"
        except OperationalError as exc:
            db.session.rollback()
            app.logger.warning("Vortex: consulta FTS5 falhou (%s); usando LIKE.", exc)
    return _like_candidates(tokens, mode, category, media_type, limit), "like"


def search_items(app, q, category=None, media_type=None, offset=0, limit=None):
    """Busca por texto. Devolve dict: items, has_next, next_cursor, total,
    mode ('fts'|'like'), relaxed (True se precisou aceitar 'qualquer palavra'),
    tokens. `total` conta até o teto de resultados (`capped` = True quando bateu no teto)."""
    tokens = tokenize_query(q)
    limit = limit or page_size(app)
    cap = _cfg(app, "VORTEX_SEARCH_MAX_RESULTS", 400)
    result = {"items": [], "has_next": False, "next_cursor": None, "total": 0, "capped": False,
              "mode": "fts" if fts_available(app) else "like", "relaxed": False, "tokens": tokens}
    if not tokens:
        return result

    candidates, engine = _run_search(app, tokens, "and", category, media_type, cap)
    relaxed = False
    if not candidates and len(tokens) > 1:
        candidates, engine = _run_search(app, tokens, "or", category, media_type, cap)
        relaxed = bool(candidates)

    ids = _blend(candidates, utcnow())
    page = ids[offset:offset + limit]
    has_next = offset + limit < len(ids)
    result.update({
        "items": load_items(page),
        "has_next": has_next,
        "next_cursor": format_offset_cursor(offset + limit) if has_next else None,
        "total": len(ids),
        "capped": len(ids) >= cap,
        "mode": engine,
        "relaxed": relaxed,
    })
    return result


# ---------------------------------------------------------------------------
# "mais como este"
# ---------------------------------------------------------------------------

class _PhashIndex:
    """Cópia em memória (id, dHash como inteiro) dos itens ativos com phash.
    Distância de Hamming não tem índice no SQL, então varre a lista em Python
    (~60 mil itens = poucas dezenas de ms). Recarrega quando a assinatura
    (quantidade, maior id) muda, checada no máximo a cada `recheck` segundos."""

    def __init__(self, recheck=20.0):
        self._lock = threading.Lock()
        self._sig = None
        self._checked = 0.0
        self._ids = []
        self._vals = []
        self._recheck = recheck

    def _signature(self):
        row = db.session.execute(text(
            "SELECT COUNT(*), COALESCE(MAX(id), 0) FROM vortex_items "
            "WHERE phash IS NOT NULL AND is_active = 1"
        )).one()
        return (row[0], row[1])

    def _refresh(self):
        now = time.monotonic()
        if self._sig is not None and now - self._checked < self._recheck:
            return
        sig = self._signature()
        self._checked = now
        if sig == self._sig:
            return
        rows = db.session.execute(text(
            "SELECT id, phash FROM vortex_items WHERE phash IS NOT NULL AND is_active = 1"
        )).all()
        ids, vals = [], []
        for item_id, ph in rows:
            try:
                vals.append(int(ph, 16))
                ids.append(item_id)
            except (TypeError, ValueError):
                continue
        self._ids, self._vals, self._sig = ids, vals, sig

    def neighbors(self, phash, max_distance, exclude_id=None, limit=150):
        """[(id, distância)] dos mais próximos (<= max_distance), do mais perto pro mais longe."""
        try:
            target = int(phash, 16)
        except (TypeError, ValueError):
            return []
        with self._lock:
            self._refresh()
            ids, vals = self._ids, self._vals
        found = []
        for item_id, val in zip(ids, vals):
            if item_id == exclude_id:
                continue
            d = _popcount(target ^ val)
            if d <= max_distance:
                found.append((d, -item_id, item_id))
        found.sort()
        return [(i, d) for d, _neg, i in found[:limit]]


def _phash_index(app):
    ext = _ext(app)
    if "phash_index" not in ext:
        ext["phash_index"] = _PhashIndex(recheck=_cfg(app, "VORTEX_PHASH_RECHECK_SECONDS", 20.0))
    return ext["phash_index"]


class _VisionIndex:
    """Cópia em memória das assinaturas visuais dos itens ativos: aparência
    (uint8 x 69) e, se existir, embedding CLIP (float16). Recarrega quando a
    assinatura (quantidades, maior id) muda, checada a cada `recheck` s.
    Vetorizado com numpy (~60 mil itens = poucos ms por consulta)."""

    def __init__(self, recheck=20.0):
        self._lock = threading.Lock()
        self._sig = None
        self._checked = 0.0
        self._recheck = recheck
        self._pix_ids, self._pix_pos, self._pix = [], {}, None
        self._clip_ids, self._clip_pos, self._clip = [], {}, None
        self._w = vv.weights_array()

    def available(self):
        return np is not None

    def _signature(self):
        row = db.session.execute(text(
            "SELECT COUNT(*), COALESCE(MAX(id), 0), "
            "SUM(CASE WHEN clip_vec IS NOT NULL AND clip_vec != '' THEN 1 ELSE 0 END) "
            "FROM vortex_items WHERE vfeat IS NOT NULL AND vfeat != '' AND is_active = 1"
        )).one()
        return (row[0], row[1], row[2] or 0)

    def _refresh(self):
        now = time.monotonic()
        if self._sig is not None and now - self._checked < self._recheck:
            return
        sig = self._signature()
        self._checked = now
        if sig == self._sig:
            return
        rows = db.session.execute(text(
            "SELECT id, vfeat, clip_vec FROM vortex_items "
            "WHERE vfeat IS NOT NULL AND vfeat != '' AND is_active = 1"
        )).all()
        pix_ids, pix_chunks, clip_ids, clip_chunks = [], [], [], []
        clip_dim = None
        for item_id, vfeat, clip_vec in rows:
            vec = vv.vec_from_hex(vfeat)
            if vec is None:
                continue
            pix_ids.append(item_id)
            pix_chunks.append(vec)
            if clip_vec:
                cv = vv.clip_unpack(clip_vec)
                if cv is not None and (clip_dim is None or len(cv) == clip_dim):
                    clip_dim = len(cv)
                    clip_ids.append(item_id)
                    clip_chunks.append(cv.astype(np.float16))
        self._pix_ids = pix_ids
        self._pix_pos = {i: n for n, i in enumerate(pix_ids)}
        self._pix = (np.frombuffer(b"".join(pix_chunks), dtype=np.uint8).reshape(-1, vv.FEAT_DIM)
                     if pix_chunks else None)
        self._clip_ids = clip_ids
        self._clip_pos = {i: n for n, i in enumerate(clip_ids)}
        self._clip = np.stack(clip_chunks) if clip_chunks else None
        self._sig = sig

    def _pix_sims(self, vec, rows=None):
        m = self._pix if rows is None else self._pix[rows]
        diff = np.abs(m.astype(np.int16) - np.frombuffer(vec, dtype=np.uint8).astype(np.int16))
        dist = (diff * self._w).sum(axis=1) / (255.0 * vv._W_SUM)
        return np.clip(1.0 - dist / vv.DIST_SCALE, 0.0, 1.0)

    def pixel_neighbors(self, vec, k, exclude_id=None):
        """[(id, similaridade 0-1)] das assinaturas mais parecidas."""
        if np is None or vec is None:
            return []
        with self._lock:
            self._refresh()
            if self._pix is None:
                return []
            sims = self._pix_sims(vec)
            ids = self._pix_ids
        order = np.argsort(-sims)[: k + 1]
        return [(ids[i], float(sims[i])) for i in order if ids[i] != exclude_id][:k]

    def pixel_sims(self, vec, wanted_ids):
        if np is None or vec is None:
            return {}
        with self._lock:
            self._refresh()
            if self._pix is None:
                return {}
            pos = [(i, self._pix_pos[i]) for i in wanted_ids if i in self._pix_pos]
            if not pos:
                return {}
            sims = self._pix_sims(vec, [p for _i, p in pos])
        return {i: float(s) for (i, _p), s in zip(pos, sims)}

    def clip_neighbors(self, qvec, k, exclude_id=None):
        """[(id, cosseno)] dos embeddings CLIP mais próximos."""
        if np is None or qvec is None:
            return []
        with self._lock:
            self._refresh()
            if self._clip is None or self._clip.shape[1] != len(qvec):
                return []
            sims = self._clip.astype(np.float32) @ qvec
            ids = self._clip_ids
        order = np.argsort(-sims)[: k + 1]
        return [(ids[i], float(sims[i])) for i in order if ids[i] != exclude_id][:k]

    def clip_sims(self, qvec, wanted_ids):
        if np is None or qvec is None:
            return {}
        with self._lock:
            self._refresh()
            if self._clip is None or self._clip.shape[1] != len(qvec):
                return {}
            pos = [(i, self._clip_pos[i]) for i in wanted_ids if i in self._clip_pos]
            if not pos:
                return {}
            sims = self._clip[[p for _i, p in pos]].astype(np.float32) @ qvec
        return {i: float(s) for (i, _p), s in zip(pos, sims)}


def _vision_index(app):
    ext = _ext(app)
    if "vision_index" not in ext:
        ext["vision_index"] = _VisionIndex(recheck=_cfg(app, "VORTEX_PHASH_RECHECK_SECONDS", 20.0))
    return ext["vision_index"]


def _title_tokens(title):
    return {w for w in _TOKEN_RE.findall((title or "").lower())
            if len(w) >= 3 and w not in _QUERY_STOPWORDS and not w.isdigit()}


def _jaccard(a, b):
    if not a or not b:
        return 0.0
    inter = len(a & b)
    return inter / len(a | b) if inter else 0.0


def _tag_candidate_ids(app, item, limit):
    """Ids de itens que compartilham alguma tag com `item`."""
    tags = item.tag_list[:12]
    if not tags:
        return []
    if fts_available(app):
        phrases = []
        for tag in tags:
            words = _TOKEN_RE.findall(tag)
            if words:
                phrases.append('"' + " ".join(words) + '"')
        if phrases:
            try:
                rows = db.session.execute(text(
                    f"SELECT {FTS_TABLE}.rowid AS id FROM {FTS_TABLE} "
                    f"WHERE {FTS_TABLE} MATCH :m ORDER BY bm25({FTS_TABLE}, {_BM25_WEIGHTS}) LIMIT :k"
                ), {"m": "tags : (" + " OR ".join(phrases) + ")", "k": limit}).all()
                return [r.id for r in rows]
            except OperationalError:
                db.session.rollback()
    padded = db.literal(",") + db.func.coalesce(VortexItem.tags, "") + db.literal(",")
    conds = [padded.contains(f",{t},", autoescape=True) for t in tags]
    rows = (
        VortexItem.query.with_entities(VortexItem.id)
        .filter(VortexItem.is_active.is_(True), db.or_(*conds))
        .order_by(VortexItem.id.desc()).limit(limit).all()
    )
    return [r.id for r in rows]


# pesos do "mais como este": o que a IMAGEM mostra pesa mais que o texto da fonte
_W_CLIP, _W_PIX = 8.0, 5.0
_TEXT_SCALE_WITH_VISION = 0.6     # texto/tags da fonte valem menos quando há sinal visual
_TEXT_SCALE_CONTRADICTED = 0.3    # ...e menos ainda se a imagem CONTRADIZ o texto


# Parte 4: o que a peça É (conceitos) manda no "mais como este"
_W_CONCEPT = 6.0            # peso do parentesco de conceitos (carro x moto ~ 0,65 -> +3,9)
_W_COCLICK = 1.5            # bônus máximo de co-clique
_MIN_CONCEPT_SIM = 0.3      # abaixo disso a peça é de outro assunto (domínio-só = 0,25 NÃO passa)
_COCLICK_MIN_USERS = 2      # só vale se >= 2 pessoas diferentes abriram as duas
_COCLICK_WINDOW_HOURS = 2.0
_COCLICK_DAYS = 60


def _concept_candidate_ids(app, item, base, limit):
    """Ids de peças do MESMO conceito / da MESMA família (ex.: carro -> todo
    veículo de rodas) que `item`, achadas por `concept_tags` sem juntar tabelas."""
    wanted = []
    for cid, _w in base[:3]:
        for x in (cid, vcn.family_of(cid)):
            if x and x not in wanted and len(wanted) < 5:
                wanted.append(x)
    ids = set()
    for cid in wanted:
        rows = (
            VortexItem.query.with_entities(VortexItem.id)
            .filter(VortexItem.is_active.is_(True), VortexItem.id != item.id,
                    VortexItem.concept_tags.contains(f" {cid} ", autoescape=True))
            .order_by(VortexItem.id.desc()).limit(max(30, limit // 2)).all()
        )
        ids.update(r.id for r in rows)
    return ids


def coclick_counts(item_id, limit=60):
    """{item_id: nº de pessoas} que abriram/curtiram `item_id` E também a outra
    peça com poucas horas de diferença (\"quem viu isto também viu aquilo\").
    Tolerante: qualquer erro de banco vira {} (a sugestão segue sem o sinal)."""
    since = utcnow().replace(tzinfo=None) - timedelta(days=_COCLICK_DAYS)
    try:
        rows = db.session.execute(text(
            "SELECT b.item_id AS other, COUNT(DISTINCT b.user_id) AS n "
            "FROM vortex_interactions a JOIN vortex_interactions b "
            "ON a.user_id = b.user_id AND b.item_id IS NOT NULL AND b.item_id != a.item_id "
            "AND b.kind IN ('open','like') AND b.weight > 0 "
            "AND ABS(julianday(a.created_at) - julianday(b.created_at)) <= :win "
            "WHERE a.item_id = :id AND a.kind IN ('open','like') AND a.weight > 0 "
            "AND a.created_at >= :since "
            "GROUP BY b.item_id HAVING COUNT(DISTINCT b.user_id) >= :minu "
            "ORDER BY n DESC LIMIT :k"
        ), {"id": item_id, "since": since, "win": _COCLICK_WINDOW_HOURS / 24.0,
            "minu": _COCLICK_MIN_USERS, "k": limit}).all()
        return {r.other: int(r.n) for r in rows}
    except Exception:
        db.session.rollback()
        return {}


def related_items(app, item, offset=0, limit=None):
    """\"Mais como este\": dict com items, has_next, next_cursor, total.

    Sinais, do mais forte pro mais fraco: embedding CLIP (o que a imagem
    representa), assinatura de aparência (cores, luz, layout), distância de
    Hamming do dHash, tags em comum, palavras do título, tags visuais,
    categoria e tipo de mídia; o mesmo perfil só desempata. Itens ainda sem
    análise visual caem nos sinais de texto/phash, como antes.

    Parte 4: se a peça tem CONCEITOS (vortex_concepts), eles mandam: só entram
    peças de assunto parente (carro -> moto, caminhão, bicicleta; nunca dança
    ou balão de festa), o parentesco soma na nota (carro > moto > ônibus) e
    quem não pôde ser confirmado precisa de nota mínima; o preenchimento por
    categoria só aceita peça confirmada. Co-cliques (>= 2 pessoas) dão bônus."""
    limit = limit or page_size(app)
    cap = _cfg(app, "VORTEX_RELATED_MAX_RESULTS", 150)
    pool = _cfg(app, "VORTEX_RELATED_CANDIDATES", 300)

    near = {}  # id -> distância de Hamming
    if item.phash and item.media_type in ("photo", "gif"):
        for other_id, dist in _phash_index(app).neighbors(
                item.phash, SIMILAR_DISTANCE, exclude_id=item.id, limit=pool):
            near[other_id] = dist

    vision = _vision_index(app)
    pix_vec = vv.vec_from_hex(item.vfeat) if item.vfeat else None
    clip_q = vv.clip_unpack(item.clip_vec) if item.clip_vec else None
    pix_near = dict(vision.pixel_neighbors(pix_vec, pool, exclude_id=item.id)) if pix_vec else {}
    clip_near = dict(vision.clip_neighbors(clip_q, pool, exclude_id=item.id)) if clip_q is not None else {}
    has_vision = pix_vec is not None or clip_q is not None
    text_scale = _TEXT_SCALE_WITH_VISION if has_vision else 1.0

    base_concepts = item.concept_list           # [(id, peso)]; vazio = sem pista
    coclick = coclick_counts(item.id)
    min_score = _cfg(app, "VORTEX_RELATED_MIN_SCORE", 0.9)

    candidate_ids = set(near) | set(pix_near) | set(clip_near) | set(coclick)
    candidate_ids.update(_tag_candidate_ids(app, item, pool))
    if base_concepts:
        candidate_ids.update(_concept_candidate_ids(app, item, base_concepts, pool))
    same_category = (
        VortexItem.query.with_entities(VortexItem.id)
        .filter(VortexItem.is_active.is_(True), VortexItem.category == item.category,
                VortexItem.id != item.id)
        .order_by(VortexItem.id.desc()).limit(pool).all()
    )
    candidate_ids.update(r.id for r in same_category)
    candidate_ids.discard(item.id)
    if not candidate_ids:
        return {"items": [], "has_next": False, "next_cursor": None, "total": 0}

    rows = (
        VortexItem.query.join(VortexProfile, VortexItem.profile_id == VortexProfile.id)
        .filter(VortexItem.id.in_(list(candidate_ids)),
                VortexItem.is_active.is_(True), VortexProfile.is_active.is_(True))
        .with_entities(VortexItem.id, VortexItem.tags, VortexItem.title, VortexItem.category,
                       VortexItem.media_type, VortexItem.profile_id, VortexItem.visual_tags,
                       VortexItem.concepts)
        .all()
    )
    pix_sim = vision.pixel_sims(pix_vec, candidate_ids) if pix_vec else {}
    clip_sim = vision.clip_sims(clip_q, candidate_ids) if clip_q is not None else {}

    base_tags = set(item.tag_list)
    base_title = _title_tokens(item.title)
    base_vtags = set(item.visual_tag_list)
    strong, fill = [], []
    for r in rows:
        dist = near.get(r.id)
        if dist is not None and dist <= DUPLICATE_DISTANCE:
            continue  # é a mesma imagem em outra URL: não sugere
        tags = {t for t in (r.tags or "").split(",") if t}
        shared = len(base_tags & tags)
        title_j = _jaccard(base_title, _title_tokens(r.title))
        vtags = {t for t in (r.visual_tags or "").split(",") if t}
        vtag_shared = len(base_vtags & vtags)
        same_cat = r.category == item.category
        same_type = r.media_type == item.media_type
        same_profile = r.profile_id == item.profile_id

        # Parte 4: parentesco de conceitos (None = a outra peça ainda não foi analisada)
        concept_sim = None
        if base_concepts:
            other = vcn.decode(r.concepts)
            if other:
                concept_sim = vcn.similarity(base_concepts, other)
                if concept_sim < _MIN_CONCEPT_SIM:
                    continue  # assunto diferente (carro x dança): nunca sugere
        confirmed = concept_sim is not None

        visual, has_visual = 0.0, False
        cs, ps = clip_sim.get(r.id), pix_sim.get(r.id)
        if cs is not None:        # cosseno CLIP típico de imagens relacionadas: 0.6-1.0
            visual += _W_CLIP * max(0.0, (cs - 0.55) / 0.45)
            has_visual = has_visual or cs >= 0.65
        if ps is not None:        # aparência: >= 0.6 já é "mesma cena/mesmas cores"
            visual += _W_PIX * max(0.0, (ps - 0.45) / 0.55)
            has_visual = has_visual or ps >= 0.6
        visual += 1.0 * _jaccard(base_vtags, vtags)

        coclicks = coclick.get(r.id, 0)
        if shared or title_j or dist is not None or has_visual or vtag_shared >= 2 or confirmed:
            text_score = 4.0 * _jaccard(base_tags, tags) + 0.6 * min(shared, 3) + 1.0 * title_j
            # imagens claramente diferentes: o texto da fonte não pode empurrar
            # o item pra cima (ex.: floresta legendada "mar")
            contradicted = (cs is not None and cs < 0.5) or (cs is None and ps is not None and ps < 0.3)
            scale = _TEXT_SCALE_CONTRADICTED if contradicted else text_scale
            score = scale * text_score + visual
            if dist is not None:
                score += 3.0 * (1.0 - dist / (SIMILAR_DISTANCE + 1))
            score += 0.6 * same_cat + 0.25 * same_type
            if confirmed:
                score += _W_CONCEPT * concept_sim
            if coclicks:
                score += _W_COCLICK * min(coclicks, 5) / 5.0
            # sem confirmação por conceito: precisa de nota mínima (corte de relevância)
            if base_concepts and not confirmed and score < min_score:
                continue
            # o mesmo perfil só desempata (por isso fica fora da nota)
            strong.append((-round(score, 2), -int(same_profile), -r.id, r.id))
        elif base_concepts:
            continue  # peça com assunto conhecido não se completa com o que não foi confirmado
        else:
            fill.append((-round(visual, 2), -int(same_cat), -int(same_type), -int(same_profile),
                         -r.id, r.id))
    strong.sort()
    fill.sort()
    ids = ([s[-1] for s in strong] + [f[-1] for f in fill])[:cap]

    page = ids[offset:offset + limit]
    has_next = offset + limit < len(ids)
    return {
        "items": load_items(page),
        "has_next": has_next,
        "next_cursor": format_offset_cursor(offset + limit) if has_next else None,
        "total": len(ids),
    }


# ---------------------------------------------------------------------------
# estatísticas e categorias
# ---------------------------------------------------------------------------

def _cache(app):
    ext = _ext(app)
    if "cache" not in ext:
        ext["cache"] = TTLCache(ttl_seconds=_cfg(app, "VORTEX_STATS_TTL_SECONDS", 60), max_entries=64)
    return ext["cache"]


def clear_stats_cache(app):
    _cache(app).clear()


def _category_labels(app):
    return dict(app.config["VORTEX_CATEGORIES"])


def _crawler_counts_by_type(category=None):
    query = (
        db.session.query(VortexItem.media_type, db.func.count(VortexItem.id))
        .join(VortexProfile, VortexItem.profile_id == VortexProfile.id)
        .filter(VortexItem.is_active.is_(True), VortexProfile.is_active.is_(True))
    )
    if category:
        query = query.filter(VortexItem.category == category)
    counts = dict(query.group_by(VortexItem.media_type).all())
    return {t: int(counts.get(t, 0)) for t in VORTEX_TYPES}


def _user_counts_by_type():
    """Peças vindas de posts de usuários ainda no ar — mesma regra de `/vortex`:
    cada post conta uma vez, pelo tipo da primeira mídia visual dele."""
    from sqlalchemy.orm import selectinload
    has_visual = Post.id.in_(
        db.session.query(PostMedia.post_id).filter(PostMedia.media_type.in_(VORTEX_TYPES))
    )
    posts = (
        Post.query.options(selectinload(Post.media_items))
        .filter(Post.expires_at > utcnow())
        .filter(db.or_(Post.post_type.in_(VORTEX_TYPES), has_visual))
        .all()
    )
    counts = {t: 0 for t in VORTEX_TYPES}
    for post in posts:
        media = next((m for m in post.display_media if m["media_type"] in VORTEX_TYPES), None)
        if media:
            counts[media["media_type"]] += 1
    return counts


def vortex_stats(app):
    """{total, photos, gifs, videos, crawler_items, user_posts, profiles, by_category}.
    photos/gifs/videos/total somam crawler + posts de usuários; by_category só
    tem itens do crawler (posts de usuários não têm categoria)."""
    cache = _cache(app)
    cached = cache.get("stats")
    if cached is not None:
        return cached

    crawler = _crawler_counts_by_type()
    user = _user_counts_by_type()
    labels = _category_labels(app)

    cat_rows = (
        db.session.query(VortexItem.category, db.func.count(VortexItem.id))
        .join(VortexProfile, VortexItem.profile_id == VortexProfile.id)
        .filter(VortexItem.is_active.is_(True), VortexProfile.is_active.is_(True))
        .group_by(VortexItem.category).all()
    )
    order = {slug: i for i, slug in enumerate(labels)}
    by_category = sorted(
        ({"slug": slug, "label": labels.get(slug, slug.capitalize()), "count": int(n)}
         for slug, n in cat_rows if n),
        key=lambda c: (-c["count"], order.get(c["slug"], 999)),
    )
    profiles = (
        db.session.query(db.func.count(db.distinct(VortexItem.profile_id)))
        .join(VortexProfile, VortexItem.profile_id == VortexProfile.id)
        .filter(VortexItem.is_active.is_(True), VortexProfile.is_active.is_(True)).scalar()
    ) or 0

    photos = crawler["photo"] + user["photo"]
    gifs = crawler["gif"] + user["gif"]
    videos = crawler["video"] + user["video"]
    stats = {
        "total": photos + gifs + videos,
        "photos": photos,
        "gifs": gifs,
        "videos": videos,
        "crawler_items": sum(crawler.values()),
        "user_posts": sum(user.values()),
        "profiles": int(profiles),
        "by_category": by_category,
    }
    cache.set("stats", stats)
    return stats


def vortex_categories(app, category=None, include_empty=False):
    """{categories:[{slug,label,count,photos,gifs,videos}], types:{all,photo,gif,video}}.
    `types` conta o que o filtro de tipo mostraria hoje: sem `category`, crawler +
    posts de usuários; com `category`, só o crawler (posts não têm categoria)."""
    cache = _cache(app)
    key = ("categories", category or "", bool(include_empty))
    cached = cache.get(key)
    if cached is not None:
        return cached

    labels = _category_labels(app)
    order = {slug: i for i, slug in enumerate(labels)}
    rows = (
        db.session.query(VortexItem.category, VortexItem.media_type, db.func.count(VortexItem.id))
        .join(VortexProfile, VortexItem.profile_id == VortexProfile.id)
        .filter(VortexItem.is_active.is_(True), VortexProfile.is_active.is_(True))
        .group_by(VortexItem.category, VortexItem.media_type).all()
    )
    per_cat = {}
    for slug, media_type, n in rows:
        entry = per_cat.setdefault(slug, {"photo": 0, "gif": 0, "video": 0})
        if media_type in entry:
            entry[media_type] += int(n)

    categories = []
    for slug in set(labels) | set(per_cat):
        t = per_cat.get(slug, {"photo": 0, "gif": 0, "video": 0})
        count = sum(t.values())
        if count or include_empty:
            categories.append({
                "slug": slug, "label": labels.get(slug, slug.capitalize()), "count": count,
                "photos": t["photo"], "gifs": t["gif"], "videos": t["video"],
            })
    categories.sort(key=lambda c: (-c["count"], order.get(c["slug"], 999)))

    if category:
        by_type = _crawler_counts_by_type(category)
    else:
        crawler, user = _crawler_counts_by_type(), _user_counts_by_type()
        by_type = {t: crawler[t] + user[t] for t in VORTEX_TYPES}
    data = {
        "categories": categories,
        "types": {"all": sum(by_type.values()), **by_type},
    }
    cache.set(key, data)
    return data


def format_count(n):
    """12345 -> '12.345' (pt-BR)."""
    return f"{int(n):,}".replace(",", ".")


if __name__ == "__main__":  # python vortex_search.py --reindex
    import sys
    from app import create_app

    flask_app = create_app()
    with flask_app.app_context():
        ok = ensure_search_index(flask_app, db)
        if "--reindex" in sys.argv and ok:
            rebuild_search_index(flask_app, db)
        print("FTS5:", "ok" if ok else "indisponível (busca usa LIKE)")
