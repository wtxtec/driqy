# Widget "Estações" + Lua com mais informações

## Lua (`GET /api/v1/widgets/moon`)
Campos antigos continuam. Novos: `waxing`, `trend` (Crescendo/Minguando), `cycle_pct` e `cycle_days`
(progresso da lunação), `distance_km` e `distance_label` (perigeu/apogeu), `events` (nova, quarto crescente,
cheia e quarto minguante, do mais perto ao mais longe, com data e dias que faltam).

## Estações (`GET /api/v1/widgets/seasons`, id `seasons`, logo depois da Lua)
- Equinócios/solstícios calculados por Meeus (`widgets_extra.season_event`), erro de poucos minutos.
- Hemisfério vem da latitude do perfil; sem localização = sul (Verão começa em dezembro).
- `current` (progresso %, dia X de Y, dias que faltam), `next`, `cycle` (as 4 estações, de solstício de
  dezembro a solstício de dezembro: passada = 100%, atual = parcial, futura = 0%), `year_progress` e `alert`
  (texto quando faltam 3 dias ou menos).

## Avisos (`season_alerts.py`, job de hora em hora no `scheduler.py`)
- **3 dias antes** ("Verão começa em 3 dias (21/12)") e **no dia** ("Hoje começa o Verão").
- Se o servidor ficou parado, o aviso "antes" ainda sai nos dias seguintes (1 a 3 dias antes), uma vez só.
- Só a partir das 8h de Brasília. Cada aviso sai uma vez por usuário (tabela `season_alerts`).
- Chega no sino do site, na lista de notificações do app (tipo `season`) e como push (FCM) se configurado.
- Banco: tabela nova `season_alerts` (criada sozinha) e coluna `notifications.text` (adicionada sozinha
  por `_ensure_schema_upgrades`). Nas notificações `season`, `actor_id` é o próprio usuário (a coluna é
  obrigatória); o site e o app ignoram o autor nesse tipo.

## Onde ver os widgets (celular)
O painel da direita só existe em tela larga (site ≥ 1200 px; app em layout largo). No celular, os widgets
(Clima, Lua, **Estações**...) abrem pelo item **Widgets** do menu:
- Site: página `/widgets` (`widgets_page.html`), link "Widgets" no menu lateral (some em tela larga).
- App: `WidgetsScreen`, item "Widgets" no menu (Drawer) quando a coluna da direita não cabe.
Para quem já tinha ordem salva, "Estações" fica depois dos outros widgets: use ‹ › ou o botão de grade
(Todos os widgets) para ir direto a ela.

## Lua: nascer/pôr e próximos eclipses
`GET /widgets/moon` agora também devolve:
- `rise_set`: `{place, approximate, rise, set, up_now, next:{label,time,today}}` — nascer e pôr da Lua de hoje, no
  local do perfil (coordenadas salvas ou cidade). Sem local, usa Brasília e `approximate: true` (o widget avisa
  "defina sua cidade no perfil"). Horários sempre em Brasília. `rise`/`set` podem ser `null`: a Lua atrasa ~50 min
  por dia e há dias sem nascer (ou sem pôr).
- `eclipses`: os 3 próximos (solares e lunares): `{kind, type, name, emoji, date, time, days, visible_here, magnitude?}`.
  `time` é o máximo do eclipse (Brasília). `visible_here` só existe para eclipse lunar (Lua acima do horizonte no máximo);
  no solar vale `null`, porque depende da faixa de sombra e o widget não palpita.
Tudo calculado em `moon_astro.py` (Python puro, sem rede e sem dependência nova): posição da Lua pela série abreviada
de Meeus e eclipses pelo cap. 54 do mesmo livro. Os testes conferem 6 eclipses de 2026/2027 contra as datas da NASA.
Site: `renderMoon` (rail-new.js). App: `RailMoonWidget` (`MoonRiseSet`, `EclipseInfo` em `models/rail_extra.dart`).

## Fuso do usuário (calendário global, parte 3)
Os horários e datas da Lua e das Estações seguem `?tz=`/`?tz_offset=` (ver CALENDARIO_GLOBAL.md); sem eles, Brasília como
antes. `tz_label` indica o fuso usado. Os avisos de virada de estação saem a partir das 8h do fuso guardado do usuário.
