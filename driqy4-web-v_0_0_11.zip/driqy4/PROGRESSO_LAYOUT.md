# PROGRESSO — Layout: menu em caixa + painel de widgets (6 partes)

> **Índice geral e o que ainda resta (verificado em 10/11/2026): `PROGRESSO_INDICE.md`.**
> **REGRA VIGENTE (vale sobre qualquer trecho antigo abaixo):** o painel direito (widgets + Sugestões) existe SÓ na Home (feed), no site e no Flutter; no Flutter, em tela larga (≥ 901 dp), as telas abertas pelo miolo ficam dentro dele com a caixa do menu visível (Rotas-1); Mensagens (Ping) e os visualizadores de tela cheia seguem por cima de tudo. Ver as duas últimas seções deste arquivo.

> Documento de passagem de bastão (igual nos dois projetos). Atualize ao fim de cada parte.
> Regra do usuário: 6 partes (a 5 foi dividida em 5A e 5B), parar ao fim de cada uma e devolver os DOIS zips completos.
> Pediu só o que está escrito (menu esquerdo em caixa arredondada; à direita um quadrado com widget
> de clima/tempo onde o usuário pula entre vários widgets da rede; abaixo, "Seguir" com recomendações).
> NÃO imitar o tema/visual da imagem de referência.

## Plano
1. Site desktop: menu esquerdo em caixa arredondada + coluna direita (estrutura). **FEITA**
2. Backend: API de widgets (clima por localização do perfil, cache) + API de sugestões de seguir. **FEITA**
3. Site desktop: widget de clima + seletor para pular entre widgets (`DriqyRail.register`). **FEITA**
4. Site desktop: demais widgets da rede + bloco "Sugestões para você" com botão Seguir. **FEITA**
5. Flutter: caixa do menu + painel direito em tela larga. Dividida em duas, a pedido do usuário:
   - **5A** (menu em caixa + painel direito com seletor + widget de clima + casca de "Sugestões"). **FEITA**
   - **5B** (os outros 4 widgets + "Sugestões para você" com botão Seguir). **FEITA**
6. Polimento, testes, docs. **FEITA** (plano das 6 partes concluído)

## Parte 1 — o que foi feito (SÓ desktop do site)
- `templates/base.html`: inclui `_rail.html` (só logado) após `<main>` e carrega `static/js/rail.js`.
- `templates/_rail.html` (novo): `aside#rail` com cartão de widgets (título, setas ‹ ›, bolinhas) e cartão "Sugestões para você" (`#rail-suggest-list`, vazio por enquanto).
- `static/js/rail.js` (novo): `DriqyRail.register({id, title, render(bodyEl)})`; lembra o último widget em `localStorage` (`driqy-rail-widget`).
- `static/css/style.css`: `.sidebar` ≥901px vira caixa flutuante (raio 22px, margem 16px, borda, sombra, altura automática); `.rail` aparece ≥1200px (grade de 3 colunas 260px/conteúdo/320px), fica oculta em `pictures-page` e `news-page` (precisam da largura toda) e abaixo de 1200px.
- Celular (≤900px): sem mudança. Flutter: sem mudança nesta parte.
- `sw.js` → `driqy-shell-v52` (testes que fixavam v51 atualizados). Teste novo: `tests/test_layout_rail_part1.py` (4). Rodados com ele: theme_site, mensagens_part1, ping_phase4a/7 = 23 passando.
- **Não verificado:** página não aberta num navegador (altura da caixa com muitos itens no admin, tema claro).

## Parte 2 — o que foi feito (backend; site e Flutter ainda não usam)
- Rotas em `/api/v1` (arquivo novo `api_widgets.py`, importado no fim de `api.py`). Aceitam token Bearer (Flutter) e sessão do site; só GET:
  - `GET /widgets` -> `{widgets:[{id,title}]}` (hoje só `weather`; as próximas partes acrescentam em `WIDGETS`).
  - `GET /widgets/weather` -> `{ok:true, location, temperature, feels_like, humidity, wind_kmh, condition, icon, is_day, temp_min, temp_max, rain_chance}` ou `{ok:false, reason}` com reason = `no_location | not_found | unavailable | disabled`. `icon` ∈ sun, moon, sun-cloud, moon-cloud, cloud, fog, drizzle, rain, snow, storm.
  - `GET /widgets/suggestions?limit=5&exclude=a,b` -> `{users:[serialize_user + reason, mutuals, follows_you]}`. Seguir/deixar de seguir usam as rotas que já existiam (`POST /users/<u>/follow`, `/unfollow`; no site `POST /u/<u>/seguir`).
- `widgets_weather.py`: Open-Meteo (sem chave). Cidade vem de `User.location`: lista local por NOME de cidade (siglas de estado sozinhas NÃO casam — `geo_lookup.resolve` casaria "RS" com Porto Alegre) e, se não achar, geocodificação do Open-Meteo. Cache em memória: coordenadas 7 dias (inclui "não achei"), previsão 15 min. Falha de rede -> `unavailable`, nunca erro 500. `WEATHER_ENABLED` em `config.py`.
- `suggestions.py`: nunca sugere você, quem já segue nem banidos. Pontos: +4 segue você, +3 por conta em comum (máx. 4), +2 mesma cidade, +1 verificado, +1 ativo em 7 dias, +1 com post no ar, mais desempate por popularidade e embaralhado estável por dia. Considera os 250 usuários vistos mais recentemente.
- Testes novos: `tests/test_widgets_part2.py` (10). Rodados junto: layout Parte 1, chat_phase4, vortex_undo_less, mensagens_part4, ping_phase8 = todos passando. Suíte inteira NÃO rodada.
- **Não verificado:** chamada real ao Open-Meteo (o sandbox não tem essa rede; os testes simulam a resposta no formato documentado — conferir `current`/`daily` com uma chamada real). Contagem de seguidores/vistos: `User.last_seen_at` só é atualizado por requisições autenticadas.
- `templates/discover.html` continua órfão (sem rota); não foi pedido.

## Parte 3 — o que foi feito (site desktop: clima + pular entre widgets)
- `static/js/rail.js` (reescrito): além de ‹ › e bolinhas, botão de grade abre um menu com todos os widgets (fecha ao clicar fora/Esc). Aparecem só quando há 2+ widgets. `render(bodyEl, ctx)`: `ctx.isActive()` evita que resposta atrasada de um widget escreva por cima de outro. `DriqyRail.config("weather-url")` lê os `data-*` do `#rail`.
- `static/js/rail-weather.js` (novo): widget "O clima hoje" — ícone SVG por condição, temperatura, condição, cidade, máx./mín., sensação, chuva, umidade e vento. Atualiza a cada 15 min (pausa com a aba oculta). Estados: carregando; `no_location` e `not_found` (botão "Editar perfil"); `unavailable` ("Tentar de novo"); `disabled`. Texto vindo do servidor entra só por `textContent`.
- `_rail.html`: `data-weather-url`, `data-edit-profile-url` e o botão/menu de widgets. `base.html` carrega `rail-weather.js` depois de `rail.js`. CSS no fim de `style.css` (`.wx-*`, `.rail-widget-menu*`).
- `sw.js` -> `driqy-shell-v53` (testes que fixavam a versão atualizados). Teste novo: `tests/test_layout_weather_part3.py` (3). Rodados com ele: layout Parte 1, widgets Parte 2, theme_site, mensagens_part1, ping_phase4a/7 = 37 passando.
- O JS foi exercitado num DOM simulado (jsdom, fora do repositório): clima desenhado, pular por seta e por menu, 4 estados, e resposta atrasada ignorada. Passou.
- **Não verificado:** página não aberta num navegador real (aparência, tema claro, rolagem da coluna); previsão real do Open-Meteo (ver Parte 2). Hoje só existe 1 widget, então setas/menu/bolinhas ficam escondidos até a Parte 4 registrar os outros.

## Parte 4 — o que foi feito (site desktop: mais widgets + sugestões com Seguir)
- **Backend** (`widgets_data.py`, só leitura; rotas em `api_widgets.py`, todas GET e com sessão ou token):
  - `/widgets/trending` -> `{posts:[{id,url,author,snippet,likes,comments}]}`: posts no ar dos últimos 7 dias; curtida=2, comentário=3, +1 se de hoje; sem reação não entra; sem banidos.
  - `/widgets/news` -> `{articles:[{id,title,source,url,image_url}]}`: usa `recommended_articles` (mesmo recomendador do feed, já filtra previsão de outras cidades); `url` passa por `/noticias/<id>/abrir` (conta clique); imagem por `/noticias/<id>/imagem?w=480`.
  - `/widgets/vortex` -> `{items:[{id,thumb_url,title,url}]}`: 6 fotos/GIFs mais novos com miniatura, sem os marcados "menos disso" pelo usuário. NÃO grava nada no livro de vistos.
  - `/widgets/online` -> `{hidden,count,users}`: visto nos últimos `ONLINE_WINDOW_SECONDS` (300, em `config.py`); respeita `show_presence` (quem esconde o seu não aparece e também não vê os outros: `hidden:true`).
  - `GET /widgets` agora lista: weather, trending, news, vortex, online (ordem do seletor).
- **Site**: `static/js/rail-widgets.js` (os 4 widgets, com "Tentar de novo"), `static/js/rail-suggest.js` (cartão "Sugestões para você": 4 pessoas com motivo e botão Seguir; o clique é tratado por `follow.js`; ao virar "Seguindo" a linha some e entra outra sugestão via `?limit=1&exclude=...`). `base.html` carrega os scripts nessa ordem; `_rail.html` ganhou `data-widgets-url`. CSS no fim de `style.css` (`.rail-*`).
- `rail.js`: o primeiro desenho agora espera todos os widgets se registrarem (antes cada registro re-renderizava o atual e o clima seria buscado várias vezes) e abre no último widget usado.
- `sw.js` -> `driqy-shell-v54`. Testes novos: `test_widgets_part4.py` (7), `test_layout_rail_part4.py` (5). Rodados junto: layout 1/3, widgets 2, theme_site, mensagens_part1, ping 4a/7/8, chat_phase4, vortex undo_less/web_actions = todos passando. Suíte inteira NÃO rodada.
- JS exercitado em DOM simulado (jsdom, fora do repositório): 1 busca inicial do clima, os 5 widgets em sequência, links e atributos de segurança (`noopener`, `no-referrer`), sugestões e reposição sem repetir pessoa, linha mantida se o seguir falha. Passou.
- **Não verificado:** página em navegador real (visual, tema claro, rolagem da coluna); miniaturas do Vortex dependem de a origem aceitar hotlink; `/noticias/<id>/imagem` baixa a imagem no primeiro acesso (pode demorar no 1º carregamento do widget).
- Pendências conhecidas: "Seguir" não tem "desfazer" no cartão; o widget de notícias não permite dispensar manchete. **[RESOLVIDO nas Peq-1 (desfazer do Seguir) e Peq-2 (dispensar manchete)]**
- Próxima (Parte 5): Flutter — caixa arredondada para o menu e painel direito em tela larga reaproveitando `/api/v1/widgets/*` (weather, trending, news, vortex, online, suggestions); Seguir/deixar de seguir por `POST /api/v1/users/<u>/follow|unfollow`.

## Parte 5A — o que foi feito (Flutter: menu em caixa + painel direito com clima)
**Só Flutter; o backend não mudou** (as rotas `/api/v1/widgets/*` da Parte 2/4 já bastam). **NÃO compilado** (sem SDK aqui).

- **Pontos de corte iguais aos do site** (`lib/widgets/wide_layout.dart`): menu em caixa a partir de **901 dp**; painel direito a
  partir de **1200 dp** e **nunca na aba Vortex** (como `pictures-page`) **[SUPERADO: hoje só na Home]**. Larguras 260 / conteúdo / 320, respiro 16, raio 22.
- **`HomeShell`** (`lib/screens/home_shell.dart`): em tela larga o `Drawer` e a barra inferior somem e entra `Row[caixa do menu | abas | painel]`.
  O `LayoutBuilder` decide pela largura da janela. As abas ficam num `KeyedSubtree` com `GlobalKey`, então girar o aparelho / redimensionar a
  janela NÃO zera a rolagem do feed. Abaixo de 901 dp nada mudou (Drawer + barra inferior).
- **Menu extraído** (`lib/widgets/home_menu.dart`): `HomeMenu` + `HomeMenuItem` (antes `_DrawerItem`) servem ao Drawer e à caixa; os links
  são os mesmos, na mesma ordem. `DriqyBox` (`driqy_box.dart`) é a caixa (borda, sombra, raio 22; é um `Material` para o realce do item
  selecionado aparecer).
- **`WideShell`** (InheritedWidget, como o `PingWide`): a `DriqyTopBar` esconde o ☰ e a marca quando o menu está em caixa (a marca já está na caixa).
  Fora da `HomeShell` (rotas empilhadas) continua igual.
- **Painel direito** (`lib/widgets/rail/`):
  - `rail_panel.dart` — `RailPanel`: título do widget, setas ‹ ›, botão de grade (menu com todos) e bolinhas; só aparecem com 2+ widgets.
    A ordem vem de `GET /widgets` (ids que o app não conhece são ignorados; se a chamada falhar vale a ordem local). Lembra o último
    widget em `SharedPreferences` (`driqy-rail-widget`, a mesma chave do site). Cartão "Sugestões para você" por enquanto só com
    "Sem sugestões por enquanto." (parâmetro `suggestions` para a 5B).
  - `weather_widget.dart` — "O clima hoje": ícone (Material, nas cores do site), temperatura, condição, cidade, máx./mín./sensação/chuva/umidade/vento;
    estados carregando, `no_location`/`not_found` (botão "Editar perfil" → `EditProfileScreen`, e ao voltar busca de novo), `unavailable`
    ("Tentar de novo"), `disabled`. Atualiza a cada 15 min, pausa com o app em segundo plano; a atualização automática que falha NÃO troca o
    clima bom por mensagem de erro.
  - `driqy_rail.dart` — liga tudo ao login (`buildRailSpecs`), largura fixa, rolagem sem barra. **A 5B acrescenta os widgets em `buildRailSpecs`.**
- Novos: `models/rail_widgets.dart` (`WeatherResult`), `services/widgets_service.dart` (`getWidgetIds`, `getWeather`).
- Os títulos do seletor são locais ("O clima hoje"); só a ORDEM e a disponibilidade vêm do servidor (o `title` de `GET /widgets` é curto: "Clima").
- **Testes novos** (`flutter test`, NÃO rodados): `wide_layout_test.dart`, `home_menu_test.dart`, `rail_panel_test.dart`, `rail_weather_test.dart`.
- **Verificação feita aqui:** só análise **sintática** dos arquivos novos/alterados (parser tree-sitter-dart: sem erros). Não houve `flutter analyze`,
  `flutter test` nem execução. Pode haver erro de tipo/import que só o compilador pega.
- **Não verificado / pendências da 5A:**
  - rodar `flutter analyze` e `flutter test` (inclui os 4 testes novos); `Icons.foggy`/`Icons.thunderstorm` exigem Flutter >= 3.7.
  - ver numa janela larga (web/desktop/tablet): alinhamento do topo das caixas com a `AppBar` das abas (a caixa começa no topo da tela; no site ela
    fica abaixo da topbar), tema claro, e a janela passando de 900 para 901 dp.
  - O feed/notificações NÃO limitam a largura do miolo (no site o card de post é estreito e centralizado): numa tela de 1900 dp o miolo fica enorme → Parte 6.
  - Rotas empilhadas (Notícias, Perfil, Mensagens/Ping, Configurações) abrem em tela cheia, sem a caixa do menu (no site o menu continua visível). **[SUPERADO pela Rotas-1, exceto Mensagens/Ping]**
  - Sem teste de widget da `HomeShell` inteira (depende de login, chat ao vivo e rede).

## Parte 5B — o que foi feito (Flutter: os outros 4 widgets + Sugestões com Seguir)
**Só Flutter; o backend não mudou** (rotas da Parte 2/4). **NÃO compilado** (sem SDK aqui): só análise sintática (tree-sitter-dart) de todos os arquivos novos/alterados, sem erros. Não houve `flutter analyze`, `flutter test` nem execução.

- `models/rail_widgets.dart`: + `RailPerson`, `TrendingPost`, `NewsHeadline`, `VortexPreviewItem`, `OnlineResult`, `SuggestedUser` (`DriqyUser` + `reason`).
- `services/widgets_service.dart`: + `getTrending`, `getNews`, `getVortex`, `getOnline`, `getSuggestions(limit, exclude)`. Diferente do clima, **estes deixam a exceção subir** (o widget mostra "Tentar de novo").
- `widgets/rail/rail_common.dart` (novo): `RailMessage` (texto + botão), `RailAvatar` (foto ou inicial), `RailLoader<T>` (Carregando… → conteúdo ou "Não consegui carregar agora." + "Tentar de novo"; resposta atrasada é ignorada).
- `widgets/rail/rail_lists.dart` (novo), mesmos títulos e textos do site:
  - **Em alta** (`trending`): avatar, @autor, trecho, ♥/💬; toque abre `PostDetailScreen`.
  - **Notícias** (`news`): miniatura (some se não carregar), título, fonte; toque chama `NewsService.openArticle` (conta o clique) e abre a fonte no navegador (`url_launcher`); falha vira SnackBar.
  - **Vortex** (`vortex`): grade 3x2; toque numa peça abre `VortexDetailScreen`; "Abrir o Vortex" troca para a aba Vortex (callback `onOpenVortex` da `HomeShell`, que usa `kVortexTabIndex`).
  - **Quem está online** (`online`): contagem (singular/plural), avatares (toque abre o perfil), "+N pessoas"; `hidden` mostra o aviso de privacidade.
- `widgets/rail/rail_suggestions.dart` (novo): cartão "Sugestões para você" com 4 pessoas (nome, @, motivo, botão **Seguir** via `UserService.follow`). Ao seguir, a linha some e entra outra (`limit=1` + `exclude` com todos os já mostrados, máx. 50). Se o seguir falha, a linha fica e aparece um SnackBar. Toque na pessoa abre o perfil.
- `driqy_rail.dart`: `buildRailSpecs(auth, {onOpenVortex})` agora tem os 5 widgets (a ordem real vem de `GET /widgets`); `DriqyRail(onOpenVortex:)` e passa `RailSuggestions` ao `RailPanel`. `home_shell.dart`: `DriqyRail(onOpenVortex: () => _selectTab(kVortexTabIndex))`.
- **Testes novos** (`flutter test`, NÃO rodados): `test/rail_lists_test.dart` (6), `test/rail_suggestions_test.dart` (3).
- **Não verificado / pendências da 5B:**
  - rodar `flutter analyze` e `flutter test` (inclui os 9 testes novos e os da 5A).
  - ver numa janela larga de verdade: altura do painel com os 5 widgets, tema claro, miniaturas do Vortex (a origem pode bloquear hotlink; no Flutter não há como mandar `no-referrer`).
  - "Seguir" não tem "desfazer"; o widget de notícias não permite dispensar manchete (iguais ao site). **[RESOLVIDO nas Peq-1/Peq-2]**
  - O widget de notícias abre direto no navegador do aparelho (no site é link `target=_blank`).
  - Rotas empilhadas continuam sem a caixa do menu e o miolo do feed ainda não tem largura máxima (ver Parte 6).

## Parte 6 — o que foi feito (polimento)
- **Flutter:** `ContentColumn` (`wide_layout.dart`) limita o miolo do Feed e das Notificações a **620 dp**, centralizado, quando o menu está em caixa (igual a `.content { max-width: 620px }` do site). O Vortex continua com a largura toda. A árvore tem o mesmo formato nos dois modos, então a rolagem do feed não zera ao redimensionar. Teste novo: `test/content_column_test.dart` (2, NÃO rodado; só sintaxe conferida).
- **Site (CSS revisado, sem mudança de código):** ≤900px não tem caixa nem painel; 901–1199px só o menu em caixa; ≥1200px menu + painel. A caixa do menu já tem `max-height` + `overflow-y: auto`, então com muitos itens (admin) ela rola por dentro.
- **Backend:** não mudou. Rodados aqui e passando: `test_layout_rail_part1/3/4`, `test_widgets_part2/4` (29). **A suíte inteira NÃO terminou** (travou/ficou lenta no sandbox) e `test_theme_site` não terminou em 50 s: rodar localmente com `pytest`.
- **Decisão sobre rotas empilhadas** (Notícias, Perfil, Mensagens/Ping, Configurações): continuam em tela cheia, sem a caixa do menu. **[SUPERADA pela Rotas-1; só Mensagens/Ping continua em tela cheia]** O Ping é de propósito um app à parte; manter a caixa em todas exigiria um shell com navegação aninhada — fica como melhoria futura.

## O que ainda precisa ser feito por quem tiver o ambiente (nada disso foi possível aqui)
1. `flutter analyze` e `flutter test` (5A + 5B + 6) e corrigir erros de tipo/import que só o compilador pega.
2. `pytest` completo do backend.
3. Abrir site e app numa janela larga real: aparência, tema claro, alinhamento do topo da caixa do menu com a `AppBar` das abas (no Flutter a caixa começa no topo da tela; no site fica abaixo da topbar), miniaturas do Vortex (hotlink), chamada real ao Open-Meteo.
4. Pendências pequenas: "desfazer" no Seguir do cartão; dispensar manchete no widget de notícias. **[RESOLVIDO nas Peq-1/Peq-2]**

---

# MINHA ÁREA + EDIÇÃO DE WIDGETS + 10 WIDGETS NOVOS (plano de 6 partes)

> Novo pedido do usuário (depois da Parte 14 do layout): poder **editar** os widgets (remover da lista) e ter uma
> **área própria** (criativa e minimalista), mais **10 widgets novos 100% funcionais**. 6 partes, uma por vez,
> sempre os DOIS zips completos (`driqy4-noticias-api_widgets_parteN` e `driqy_flutter_widgets_parteN`).
> Já existia: diálogo "Personalizar painel" (esconder painel, tirar/ordenar widgets, sugestões) no site e no Flutter,
> com `rail_prefs` no servidor. Esta série constrói em cima disso.

## Plano
1. Backend: widgets próprios (`custom:<id>`), preferências cientes deles, dados dos 10 widgets novos. **FEITA**
2. Site: modo "Editar" direto no cartão (remover, reordenar, restaurar, catálogo para adicionar de volta). **FEITA**
3. Site: "Minha área" (criar/editar/apagar widgets próprios) + os 10 widgets novos no seletor. **FEITA**
4. Flutter: modo Editar + preferências. **FEITA (sem compilar: ver Parte 4)**
5. Flutter: "Minha área". **FEITA (sem compilar: ver Parte 5)**
6. Flutter: os 10 widgets novos + polimento e docs. **FEITA (sem compilar: ver Parte 6)**

## Os 10 widgets novos (ids)
`clock` Relógio mundial · `calendar` Calendário com feriados · `moon` Fase da Lua · `quotes` Cotações (dólar/euro/bitcoin) ·
`stats` Seu Driqy (números) · `expiring` Acabando (posts temporários) · `phrase` Frase do dia ·
`pomodoro` Foco · `calc` Calculadora · `breathe` Respirar. Os três últimos rodam só no aparelho (`client: true`, sem rota).

## "Minha área" — tipos de widget próprio
`note` (texto ≤2000) · `checklist` (≤50 itens ≤120) · `links` (≤12, só http/https) · `countdown` (rótulo + data AAAA-MM-DD) ·
`counter` (valor, passo, meta opcional, unidade). Máx. 12 por usuário (`MAX_USER_WIDGETS`), título ≤40.

## Parte 1 — o que foi feito (SÓ backend; site e Flutter ainda não usam)
- `models.py`: tabela nova `UserWidget` (`user_widgets`; criada por `db.create_all`, sem ALTER).
- `widgets_custom.py` (novo): validação (`clean_data`), CRUD. O servidor nunca confia no formato do cliente.
- `widgets_extra.py` (novo): `world_clock`, `month_calendar`/`holidays`/`easter`, `moon_phase`, `get_quotes`, `my_stats`,
  `expiring_posts`, `phrase_of_the_day`.
- `api_widgets.py`: `WIDGETS` agora tem 15 ids (os 5 antigos + 10 novos; cada um com `desc`; `client:true` nos 3 locais).
  `widgets_for(user)` = prontos + próprios. `normalize_prefs(raw, extra_ids)` aceita `custom:<id>` só do dono; apagar o widget
  o remove de `order`/`disabled` na leitura. `GET /widgets` -> `all_widgets` inclui os próprios (sem `data`).
- Rotas novas em `/api/v1/widgets` (sessão ou Bearer; escrita por sessão exige `X-Requested-With: fetch`):
  - `GET /clock?zones=a,b` -> `{ok, now_utc, cities:[{id,name,offset_minutes,utc_label,local,day_offset}], available}`. `local` é a hora
    da cidade na hora da resposta: o cliente soma o tempo decorrido (e rebusca a cada ~30 min por causa do horário de verão). `day_offset` é
    em relação a Brasília.
  - `GET /calendar?year=&month=` -> `{year,month,month_name,days_in_month,first_weekday(0=domingo),today,holidays:[{day,name,kind}]}`;
    `kind` = `feriado` | `facultativo` | `data`. Fuso do "hoje": Brasília.
  - `GET /moon` -> `{phase,emoji,index(0-7),age_days,illumination(%),next_full,next_new,days_to_full,days_to_new}` (lunação média, erro de horas).
  - `GET /quotes` -> `{ok,currency:"BRL",items:[{code,name,symbol,value,change_pct,high,low}],updated_at,stale}` ou `{ok:false,reason}`
    (`unavailable`|`disabled`). Fonte: AwesomeAPI (sem chave). Cache 5 min; se a rede cair serve a última boa com `stale:true`.
  - `GET /stats` -> `{followers,following,new_followers_7d,posts_live,posts_total,views,likes,comments}`.
  - `GET /expiring` -> `{posts:[{id,url,mine,author,snippet,expires_at,seconds_left}]}`: temporários seus e de quem você segue que somem em <48 h.
  - `GET /phrase` -> `{text,author|null,date}` (40 provérbios/ditados; um por dia).
  - `GET|POST /custom`, `GET|PUT|PATCH|DELETE /custom/<id>`. POST `{kind,title,data}` -> 201 `{widget}`; erro 400 `{error}` em português.
    Resposta `{widget:{id:"custom:N",widget_id,kind,title,desc,custom:true,data,updated_at}}`; `GET /custom` também traz `kinds` e `max`.
- Config nova: `QUOTES_ENABLED`, `MAX_USER_WIDGETS`. `requirements.txt` + `tzdata` (Windows não tem base de fusos; sem ela o relógio devolve `unavailable`).
- Testes: `tests/test_widgets_minha_area_part1.py` (15). Ajustados 3 testes antigos que fixavam a lista de 5 widgets
  (`test_layout_weather_part3`, `test_widgets_part2`, `test_widgets_part4`). Rodados: esses + layout parte 1/4 = 47 passando. Suíte inteira NÃO rodada.
- **Não verificado:** chamada real à AwesomeAPI (sandbox sem rede; testes simulam o formato `{"USDBRL":{"bid","pctChange","high","low"}}`).
  Fase da Lua conferida só contra a lua cheia de 24/nov/2026.
- **Efeito no site agora:** `rail.js` só mostra widgets registrados em JS, então os 10 novos e os próprios ainda NÃO aparecem no seletor do site
  (o diálogo "Personalizar painel" já os lista). Isso muda na Parte 3.
- Flutter: nenhuma mudança (zip reempacotado). `buildRailSpecs` ignora ids desconhecidos.

## Parte 2 — o que foi feito (SÓ site desktop: modo "Editar widgets")
- **Lápis** (`#rail-widget-edit`) no cabeçalho do cartão de widgets. Clique = o corpo do cartão vira o editor: lista "No painel (N)" com ▲ ▼ ✕ e lista
  "Disponíveis" com +. "Concluir" salva em `POST /widgets/prefs` (manda `order` completa + `disabled`; mantém `rail_hidden/suggest/suggest_first`
  como estavam) e o painel se atualiza **sem recarregar**, voltando ao widget que estava aberto. "Cancelar" e Esc descartam; "Restaurar" volta tudo
  ativo na ordem padrão (ainda precisa Concluir). Falha de rede mantém o editor aberto com aviso. Sem mudança = não faz POST.
- Widgets do usuário (`custom:*`) aparecem com a etiqueta "seu" e aqui só podem ser tirados/colocados do painel (apagar de vez fica na Parte 3).
- `static/js/rail-edit.js` (novo; texto do servidor só por `textContent`). `rail.js`: `DriqyRail.openEditor(fn)`, `reapply`, estado vazio
  ("Nenhum widget no painel. Use o lápis para adicionar."). `_rail.html`: o cartão **sempre** existe (antes sumia sem widgets ativos, sem caminho de volta).
  `base.html` carrega `rail-edit.js` logo após `rail.js`. CSS no fim de `style.css` (`.rail-ed-*`). `sw.js` -> `driqy-shell-v55` (testes que fixavam v54 atualizados).
- O diálogo antigo "Personalizar painel" (menu da esquerda) continua: serve para esconder o painel inteiro e para o cartão de sugestões.
- Testes: `tests/test_layout_rail_edit_part2.py` (4). Rodados junto: layout 1/4, weather 3, widgets 2/4, minha_area 1, mensagens 1/2/4, ping 4a/4b/6b/7/8, vortex_theme_site = 116 passando. Suíte inteira NÃO rodada.
- JS exercitado em DOM simulado (jsdom, fora do repositório): entrar/sair do modo, remover, subir, tag "seu", erro de rede, POST correto, voltar ao widget aberto,
  cancelar/Esc sem salvar, painel vazio com lápis visível, adicionar de volta, restaurar, título malicioso não vira HTML. Passou.
- **Não verificado:** página em navegador real (visual do editor na coluna de 320px, tema claro, altura com 15+ widgets). Os 10 widgets novos e os próprios ainda
  não têm renderização no site (aparecem no editor, mas só entram no seletor na Parte 3).
- Próxima (Parte 3): site — "Minha área": criar (nota, tarefas, atalhos, contagem, contador), editar e apagar widgets próprios, registrá-los no seletor
  (`DriqyRail.register` para `custom:*`) e renderizar os 10 widgets novos.

## Parte 3 — o que foi feito (site desktop: os 10 widgets novos + "Minha área")
- `static/js/rail-new.js` (novo): registra os 10 ids. Relógio mundial (anda a cada segundo no aparelho, rebusca a cada 30 min; "Cidades" escolhe até 6,
  guardado em localStorage `driqy-rail-clock-zones`), Calendário (‹ › por mês, hoje, feriados, botão Hoje), Fase da Lua, Cotações (atualiza a cada 5 min;
  mostra "dados antigos" se `stale`; `reason: disabled` vira aviso sem retry), Seu Driqy, Acabando (contagem regressiva viva), Frase do dia,
  Foco (pomodoro 25/5/15; estado em localStorage `driqy-rail-pomo`, sobrevive a trocar de widget/página; apita ao fim, também com outro widget na tela),
  Calculadora (sem `eval`; teclado; 1÷0 = "Erro"; 0,1+0,2 = 0,3), Respirar (1 min: 4 s inspira, 4 s segura, 6 s expira; respeita reduced-motion).
- `static/js/rail-mine.js` (novo): "Minha área". Cada `custom:<n>` do catálogo vira um item do seletor; ao abrir busca `GET /custom/<n>`.
  nota (salva sozinha ao digitar/sair), tarefas (marcar, remover, limpar feitas), atalhos (servidor valida/normaliza; só http/https; `rel=noopener noreferrer`),
  contagem (dias restantes/atrás), contador (+/− com passo, meta com barra, unidade, zerar). Rodapé: status "Salvo" + Renomear.
  `window.DriqyMine.create(kind)` / `.remove(id)` são usados pelo editor.
- `rail-edit.js`: seção **"Criar o seu"** (5 chips; desabilita no limite `cfg.max_custom`) e botão 🗑 "Apagar de vez" (com `confirm`) nas linhas dos widgets seus.
  Ao Concluir/Cancelar abre o widget recém-criado. Criar/apagar vão ao servidor na hora (Cancelar NÃO desfaz criação nem exclusão; só ordem/ocultar são adiados).
- `rail.js`: `DriqyRail.unregister/rename/showId`; `register` depois do início mantém o widget aberto (antes o índice podia trocar). `rail_context` ganhou `max_custom`.
- `base.html`: `rail-new.js` e `rail-mine.js` entre `rail-widgets.js` e `rail-suggest.js`. `sw.js` -> `driqy-shell-v57`. CSS no fim de `style.css` (`.wx-*`, `.mine-*`).
- Testes: `tests/test_widgets_minha_area_part3.py` (5). Rodados: partes 1/2/3 + layout + widgets + mensagens + ping + vortex = 121 passando. Suíte inteira NÃO rodada.
  JS em DOM simulado (jsdom, fora do repositório, backend falso): 56 verificações passaram (todos os 10 widgets, criar/editar/renomear/apagar os 5 tipos, link inválido
  recusado, limite, título malicioso inofensivo, contagem de 10 dias).
- **Não verificado:** navegador real (visual/tema claro/altura), apito do pomodoro (WebAudio depende de gesto prévio; iniciar já é um clique), horário de verão
  no relógio, cotações reais (sem rede no sandbox).
- Próxima (Parte 4): Flutter — modo Editar (remover/reordenar/readicionar) + preferências. Partes 5 e 6: Minha área e os 10 widgets no Flutter.

## Parte 4 — o que foi feito (Flutter: modo Editar no cartão de widgets)
- **Lápis** (`Key('rail-edit')`, ícone `edit_outlined`) no cabeçalho do cartão de widgets (também com 1 widget ou nenhum). Abre o editor dentro do próprio cartão:
  "NO PAINEL (n)" com subir/descer/remover (`rail-ed-up-<id>`, `rail-ed-down-<id>`, `rail-ed-remove-<id>`) e "DISPONÍVEIS" com + (`rail-ed-add-<id>`).
  Botões: Restaurar (`rail-ed-reset`, volta tudo ao padrão do app; ainda precisa Concluir), Cancelar (`rail-ed-cancel`), Concluir (`rail-ed-done`).
  Concluir faz UMA chamada (`onSavePrefs`); sem mudança não chama; falha mostra "Não foi possível salvar agora." e mantém o editor.
  Depois de salvar o painel continua no widget que estava aberto (se ainda estiver ativo).
- `RailPanel` ganhou `onSavePrefs: Future<bool> Function(RailPrefs)?` (sem ele: sem lápis e o comportamento antigo, inclusive o cartão sumir com tudo removido).
  Com lápis o cartão **não some** mais com tudo removido ("Nenhum widget no painel. Use o lápis para adicionar."), como no site.
  `DriqyRail` repassa; `HomeShell` liga em `_railPrefs!.save` (o mesmo `RailPrefsController`, que já notifica e redesenha).
- O editor só lista widgets que o app **sabe desenhar** (`specs`). Ids do servidor que esta versão ainda não desenha (os 10 novos, `custom:*`) ficam
  intactos em `order`/`disabled` ao salvar (`_compose`). Eles passam a aparecer nas Partes 5 e 6.
- `rail_customize.dart` ("Personalizar painel" do menu): passou a listar só ids conhecidos (antes mostraria "clock", "custom:3" crus) e a preservar os demais ao reordenar.
- Testes Dart: `test/rail_edit_test.dart` (9 casos: sem lápis, cancelar, remover+subir+salvar, adicionar de volta, sem mudança, falha de rede, tudo removido,
  ids desconhecidos preservados, restaurar).
- **NÃO VERIFICADO — ambiente sem Flutter/Dart:** nada disto foi compilado nem rodado (nem os 9 testes novos, nem os existentes). Conferi só balanceamento de
  chaves/parênteses e li a lógica dos testes contra o código. Rode `flutter analyze` e `flutter test` (principalmente `rail_edit_test`, `rail_panel_test`,
  `rail_prefs_test`) antes de confiar. Pontos de maior risco: tipos de `IconButton`/`Wrap` no editor e a espera de `pumpAndSettle` nos testes.
- Backend e site: inalterados nesta parte (zip reempacotado).
- Próxima (Parte 5): Flutter — "Minha área" (criar/editar/apagar widgets próprios: nota, tarefas, atalhos, contagem, contador). Parte 6: os 10 widgets novos no Flutter.

## Parte 5 — o que foi feito (Flutter: "Minha área")
**Só Flutter; o backend não mudou** (rotas `/api/v1/widgets/custom` da Parte 1). **NÃO compilado** (sem SDK aqui): só análise sintática
(tree-sitter-dart) dos arquivos novos/alterados, sem erros. Não houve `flutter analyze`, `flutter test` nem execução.

- `models/rail_widgets.dart`: + `CustomKind`, `CustomWidget` (`id` = `custom:N`, `widgetId` = N, `kind`, `title`, `data`), `CustomCatalog`
  (widgets, tipos, limite) e `kDefaultCustomKinds` (os 5 tipos, caso a lista não chegue).
- `services/widgets_service.dart`: + `getCustomCatalog` (falha -> catálogo vazio), `getCustom`, `createCustom`, `updateCustom`, `deleteCustom`
  (estes deixam a exceção subir; `ApiException.message` traz o texto do servidor em português).
- `services/rail_prefs_controller.dart`: agora também guarda os widgets próprios. `load()` busca preferências e catálogo juntos (só marca `loaded`
  quando os dois voltam, para o painel abrir já com os próprios no lugar). `createCustom(kind)` (cria no servidor e relê as preferências; o novo entra no
  fim da ordem, ativo), `deleteCustom(id)`, `renameCustomLocally(id, título)`.
- `widgets/rail/rail_mine.dart` (novo): `RailMineWidget` com os 5 tipos, igual ao `rail-mine.js`: **nota** (salva 800 ms depois de parar de digitar, ao sair
  do campo e ao trocar de widget), **tarefas** (marcar, ✕, "Limpar feitas", contagem n/total, máx. 50), **atalhos** (só entra se o servidor aceitar; erro
  aparece no formulário; abre no navegador; máx. 12), **contagem** (dias para/desde, "Hoje"; data pelo seletor; contas em UTC por causa do horário de verão),
  **contador** (−/+ pelo passo, meta com barra, unidade, Zerar, Ajustar). Rodapé: "Salvando…/Salvo"/erro + **Renomear**. Salvamentos em fila; a resposta
  do servidor só substitui a tela quando não há edição mais nova; se falha, o que foi digitado fica na tela com o aviso.
- `rail_panel.dart`: `RailWidgetSpec.custom`; editor (lápis) ganhou etiqueta **"seu"**, lixeira "Apagar de vez" (com confirmação) nos widgets próprios e a seção
  **"CRIAR O SEU (n/máx.)"** com um chip por tipo (desligados no limite). Criar/apagar vão ao servidor na hora (**Cancelar não desfaz**, igual ao site); o recém-criado
  abre ao Concluir ou Cancelar. `didUpdateWidget` agora refaz a lista a cada mudança de specs/preferências mantendo o widget aberto (antes só quando as preferências mudavam),
  por isso widgets próprios que chegam depois e títulos renomeados aparecem.
- `driqy_rail.dart`: `buildCustomSpecs` (um spec por widget próprio) e novos parâmetros (`customs`, `customKinds`, `customMax`, `onCreateCustom`, `onDeleteCustom`,
  `onRenameCustom`); `home_shell.dart` liga tudo ao `RailPrefsController`.
- **Testes novos** (`flutter test`, NÃO rodados): `rail_mine_test.dart` (14), `rail_mine_edit_test.dart` (8), `rail_prefs_customs_test.dart` (5).
- **Não verificado / pendências da 5:**
  - rodar `flutter analyze` e `flutter test` (inclui `rail_edit_test`, `rail_panel_test` e `rail_prefs_test`, já que o `didUpdateWidget` do painel mudou). Pontos de maior risco: tipos
    em `rail_mine.dart` (`_with` do contador com valor padrão `_keep`), `ActionChip` no editor e `pumpAndSettle` com `showDatePicker`/diálogos nos testes.
  - ver numa janela larga de verdade: altura do painel com a nota/lista longa, tema claro, teclado em cima dos campos do painel no celular/tablet.
  - o painel direito só existe em tela larga (≥ 1200 dp): no celular estreito não há "Minha área" (igual ao site, que também não tem o painel no celular).
  - "Personalizar painel" (menu da esquerda) continua só com os 5 widgets antigos; os próprios ficam intactos ao salvar (são preservados em `order`/`disabled`).
- Próxima (Parte 6): Flutter — os 10 widgets novos (`clock`, `calendar`, `moon`, `quotes`, `stats`, `expiring`, `phrase`, `pomodoro`, `calc`, `breathe`) em `buildRailSpecs`
  + polimento e docs. Rotas e formatos estão na Parte 1 (acima); `client: true` = só no aparelho.

## Parte 6 — o que foi feito (Flutter: os 10 widgets novos + polimento)
**Só Flutter; o backend não mudou** (rotas da Parte 1). **NÃO compilado** (sem SDK aqui): só análise sintática (tree-sitter-dart) dos arquivos
novos/alterados, sem erros. Não houve `flutter analyze`, `flutter test` nem execução. **Fecha o plano das 6 partes.**

- `models/rail_extra.dart` (novo): `ClockResult/ClockCity/ClockZone`, `CalendarMonth/CalHoliday`, `MoonInfo`, `QuotesResult/QuoteItem`, `StatsInfo`,
  `ExpiringPost`, `PhraseInfo`. `services/widgets_service.dart`: `getClock(zones)`, `getCalendar(year, month)`, `getMoon`, `getQuotes` (qualquer falha vira
  `unavailable`), `getStats`, `getExpiring`, `getPhrase` (os demais deixam a exceção subir -> "Tentar de novo").
- `widgets/rail/rail_extra.dart` (novo), mesmos textos do `rail-new.js`:
  - **Relógio mundial**: hora anda a cada segundo no aparelho (soma o tempo desde a resposta), rebusca a cada 30 min (horário de verão); "Cidades" escolhe de 1 a 6,
    salvo em `SharedPreferences` `driqy-rail-clock-zones` (mesma chave do site, mas cada aparelho guarda a sua); Fechar busca de novo.
  - **Calendário**: ‹ › por mês, hoje destacado, feriados (rosa) e facultativos/datas (âmbar), lista do mês, botão "Hoje".
  - **Fase da Lua**, **Seu Driqy** (6 números com milhar em pt-BR + novos seguidores em 7 dias), **Frase do dia**.
  - **Cotações**: R$ em pt-BR (formatação própria, sem depender de locale), ▲/▼ coloridos, atualiza a cada 5 min; atualização automática que falha NÃO troca o
    que estava bom por erro; `stale` mostra "dados antigos"; `disabled` não tem "Tentar de novo".
  - **Acabando**: posts temporários que somem em < 48 h; contagem anda sozinha (30 s); toque abre `PostDetailScreen`.
- `widgets/rail/rail_local.dart` (novo), só no aparelho:
  - **Foco** (pomodoro 25/5/15; de 4 em 4 focos a pausa é longa): estado em `SharedPreferences` `driqy-rail-pomo` (JSON, com `endAt`), então sobrevive a trocar de widget
    e fechar o app; ao reabrir, se o tempo já acabou mostra a etapa seguinte (só apita se acabou há < 5 s). Aviso = `SystemSound.alert` + vibração. **Diferença do site:**
    o aviso só toca com o widget Foco na tela (no site toca com outro widget aberto).
  - **Calculadora**: `CalcEngine` sem `eval` (0,1+0,2 = 0,3; 1÷0 = "Erro"), 14 dígitos, teclado físico (dígitos, , . + - * / Enter Backspace Esc %).
  - **Respirar**: 1 min, inspira 4 s / segura 4 s / expira 6 s, `AnimatedScale`; respeita "reduzir animações".
- `driqy_rail.dart`: `buildRailSpecs` agora tem os **15 widgets**; `kRailWidgetIds` ganhou os 10 (mesma ordem do servidor); `rail_customize.dart` (“Personalizar painel”) lista e
  nomeia os 10.
- **Polimento:** as bolinhas do seletor agora quebram de linha (`Wrap`) — com 15 widgets + os próprios não cabiam numa linha de 320 dp.
- **Testes novos** (`flutter test`, NÃO rodados): `rail_extra_test.dart` (13), `rail_local_test.dart` (15).
- **Não verificado / pendências (precisa de quem tiver o ambiente):**
  1. `flutter analyze` e `flutter test` (todos: 5A, 5B, 6 do layout + Partes 4, 5 e 6 de widgets). Pontos de maior risco: `Focus(onKeyEvent:)` (Flutter >= 3.18), `FontFeature`,
     `withOpacity` (aviso de depreciação em Flutter novo), `pumpAndSettle` com timers periódicos nos testes, leitura do `SharedPreferences` logo após salvar no teste do Foco.
  2. Ver numa janela larga de verdade: altura do painel com Calendário/Calculadora, tema claro, teclado físico na calculadora, som do Foco no aparelho.
  3. Chamadas reais: AwesomeAPI (cotações), Open-Meteo (clima), base de fusos do relógio (`tzdata` no servidor).
  4. Rodar `pytest` completo do backend (nunca terminou no sandbox).
  5. Pequenas, herdadas: "desfazer" no Seguir do cartão; dispensar manchete no widget de notícias; “Personalizar painel” ainda não lista os widgets "seu" (ficam preservados);
     rotas empilhadas (Notícias, Perfil, Mensagens, Configurações) abrem em tela cheia sem a caixa do menu.

---

# CALENDÁRIO GLOBAL — Parte 3 (horários, nomes e semana por região)

> Pendência dos widgets que vinha depois do plano das 6 partes (ver `CALENDARIO_GLOBAL.md`). Partes 1 e 2 já estavam feitas.

## Parte 3 — o que foi feito (backend + site; o Flutter NÃO mudou)
- `widgets_extra.py`: `tz_label`; `moon_phase/moon_rise_set_info/eclipse_list/season_info` aceitam `tzinfo` (sem ele = Brasília, igual a antes);
  `month_calendar` devolve `lang`, `week_start`, `weekdays`, `first_offset` e `month_name` no idioma da região. `holidays_world.region_info`.
- `api_widgets.py`: `/widgets/moon` e `/widgets/seasons` aceitam `tz`/`tz_offset`; `tz` IANA válido é guardado em `User.tz_name`
  (também pelo `/widgets/calendar`). Coluna criada por `_ensure_schema_upgrades`.
- `season_alerts.py`: avisos por fuso (8h locais, data local no texto, chave anti-repetição inalterada, em Brasília).
- Site (`rail-new.js`): grade do calendário usa `weekdays`/`first_offset`; Lua e Estações mandam o `tz` do navegador e mostram "seu horário (GMT±N)"
  quando não é Brasília. `sw.js` -> `driqy-shell-v59`.
- Testes: `tests/test_calendario_global_part3.py` (18). Rodados com ele: seasons_moon, layout 1/3/4, rail_edit 2, widgets 2/4, minha_area 1/3 = **102 passando**.
  Suíte inteira NÃO rodada.
- **Compatibilidade:** o app Flutter atual não manda `tz` para Lua/Estações (continua tudo em Brasília) e usa `first_weekday` (domingo primeiro); os campos antigos foram mantidos.
- **Não verificado:** navegador real (visual da grade em semana de segunda, nomes em japonês); `flutter` nada foi tocado.
- **Limite:** nomes dos feriados continuam em português; só mês/dia da semana mudam de idioma.

---

# PLANO DA SÉRIE FINAL (parte por parte, sempre devolvendo os DOIS zips completos) — NADA PENDENTE

> Pedido do usuário (10/11/2026): "coloque o que falta no .md e vá fazendo aos poucos, parte por parte, sempre retornando os zips completos como estão".
> Nomes dos zips: `driqy4-web-v_0_0_N.zip` e `driqy-flutter_v_0_0_N.zip` (N sobe a cada parte). Ao fim de cada parte: atualizar ESTE arquivo nos dois projetos.

| Parte | O que é | Onde | Estado |
|---|---|---|---|
| Cal-3 | Horários/nomes/semana por região (backend + site) | backend, site | **FEITA** (v_0_0_2) |
| **Cal-4a** | Flutter: calendário com país dos feriados, nomes e semana da região | Flutter | **FEITA** (v_0_0_3, sem compilar) |
| Cal-4b | Flutter: Lua e Estações mandam `tz_offset` e mostram `tz_label` ("seu horário (GMT-5)") em vez de "horário de Brasília" fixo; testes | Flutter | **FEITA** (v_0_0_4, sem compilar) |
| Peq-1 | "Desfazer" no Seguir do cartão "Sugestões para você" (site `rail-suggest.js` + Flutter `rail_suggestions.dart`) | site + Flutter | **FEITA** (v_0_0_5, Flutter sem compilar) |
| Peq-2 | Dispensar manchete no widget de Notícias (site + Flutter; guardar dispensadas no aparelho) | site + Flutter | **FEITA** (v_0_0_7, Flutter sem compilar) |
| Peq-3 | "Personalizar painel" (menu da esquerda) listar também os widgets "seu" (`custom:*`) e os 10 novos no site | site + Flutter | **FEITA** (v_0_0_8, Flutter sem compilar) |
| Rotas-1 | Flutter: Navigator interno no miolo (tela larga): Notícias, Perfil, Widgets e tudo que o miolo/painel direito abrem ficam dentro, com a caixa do menu visível; voltar do sistema; larguras | Flutter | **FEITA** (v_0_0_9, sem compilar) |

## Cal-4a — o que foi feito (SÓ Flutter; backend/site não mudaram)
**NÃO compilado** (sem SDK aqui): só conferi balanceamento de chaves/parênteses e li a lógica contra o código e os testes. Rode `flutter analyze` e `flutter test`.
- `models/rail_extra.dart`: `CalCountry`; `CalendarMonth` ganhou `weekdays`, `firstOffset`, `country`, `countryName`, `countryChosen`, `countries` e os getters
  `gridWeekdays` (7 iniciais; sem dado do servidor = D S T Q Q S S) e `blanks` (`firstOffset` ou, em servidor antigo, `firstWeekday`).
- `services/widgets_service.dart`: `getCalendar({year, month, country})` manda `country` (só 2 letras). **Quem estende `WidgetsService` em teste precisa aceitar o novo parâmetro** (o fake de `rail_extra_test.dart` já foi ajustado).
- `widgets/rail/rail_extra.dart`: `RailCalendarWidget` lê o país de `SharedPreferences` (`kCalendarCountryKey` = `driqy.cal.country`, a mesma chave do site; cada aparelho guarda a sua),
  refaz a busca ao trocar (chave por mês+país) e mostra o seletor "Feriados:" (`Key('cal-country')`, "Automático (país)" + 13 países). Grade e cabeçalho usam `weekdays`/`firstOffset`: semana na segunda em GB/ES/FR/DE/IT/AR.
  `month_name` já vem no idioma da região. Nomes dos feriados continuam em português (limite do servidor).
- Testes novos em `test/rail_extra_test.dart`: país muda nomes/semana e fica guardado; escolha guardada é usada na abertura; campos da região e servidor antigo.
- Risco maior: `DropdownButton` dentro do painel de 320 dp e `tap(find.text('Alemanha').last)` no teste (o item aparece duas vezes com o menu aberto).

## Cal-4b — o que foi feito (SÓ Flutter; backend/site não mudaram)
**NÃO compilado** (sem SDK aqui): só balanceamento de chaves/parênteses e leitura da lógica contra os testes. Rode `flutter analyze` e `flutter test`.
- `services/widgets_service.dart`: `getMoon()` e `getSeasons()` mandam `tz_offset` (minutos do aparelho). Assinaturas iguais (o fake de teste não precisou mudar).
- `models/rail_extra.dart`: `MoonInfo.tzLabel` e `SeasonInfo.tzLabel` (vazio = servidor antigo = Brasília); função `tzWords(label)` ("horário de Brasília" / "seu horário (GMT-5)").
- `widgets/rail/rail_extra.dart`: nota do nascer/pôr da Lua e título "Próximos eclipses" usam `tzWords`; a linha "Próxima: ..." das Estações mostra `· GMT+9` quando o fuso não é Brasília.
- Testes (`test/rail_extra_test.dart`): ajustado o texto do título dos eclipses; novos: Lua com `tz_label`, Estações com `tz_label`, `tzWords` e leitura do campo.
- Diferença para o site: o app manda só o deslocamento (não o nome IANA), então o servidor NÃO grava `User.tz_name` por ele (os avisos de estação continuam na hora de Brasília para quem só usa o app).
  Se quiser avisos na hora local também para quem só usa o app: mandar o nome do fuso do aparelho (ex.: pacote `flutter_timezone`) — fica como melhoria futura.

## Peq-1 — o que foi feito (site + Flutter; backend não mudou)
**Flutter NÃO compilado** (sem SDK aqui): só balanceamento de chaves/parênteses e leitura da lógica contra os testes. Rode `flutter analyze` e `flutter test`.
- Comportamento novo (igual nos dois): ao seguir alguém no cartão "Sugestões para você", a linha **não é mais trocada logo em seguida**. Ela mostra "Seguindo" + **"Desfazer"** por 6 s;
  passado o tempo sem desfazer, a linha sai e entra outra sugestão (sem repetir quem já apareceu). "Desfazer" chama a rota de deixar de seguir que já existia, volta o botão "Seguir" e a linha fica.
  Se o desfazer falhar, a pessoa continua seguida, a janela de 6 s reabre e (no app) aparece o aviso "Não consegui desfazer agora".
- Site (`static/js/rail-suggest.js`, `static/css/style.css`): botão `.rail-suggest-undo` (escondido até seguir); um `MutationObserver` em `data-following` (o atributo que o `follow.js` já troca) inicia/cancela o prazo,
  então clicar em "Seguindo" (que deixa de seguir pelo `follow.js`) também cancela a reposição. Desfazer usa `POST /u/<u>/deixar-de-seguir`. `sw.js` -> `driqy-shell-v60`.
- Flutter (`widgets/rail/rail_suggestions.dart`): `_undo` (mapa nome -> `Timer`), `kSuggestUndoWindow` (6 s), `_startUndoWindow`/`_leave`/`_undoFollow`; usa `UserService.unfollow` (já existia). Timers cancelados em `dispose` e em `_load`.
  Chaves de teste: `suggest-follow-<u>` (Seguir) e `suggest-undo-<u>` (Desfazer).
- Testes: site `tests/test_layout_suggest_undo_peq1.py` (5, conferem o código-fonte); `tests/test_layout_rail_edit_part2.py` passou a esperar `v60`. Flutter `test/rail_suggestions_test.dart`: o teste de "seguir" foi reescrito para a janela do Desfazer e há 2 novos (desfazer; desfazer que falha).
- O JS do site foi exercitado num DOM simulado (jsdom, fora do repositório) com relógio falso: seguir -> Seguindo+Desfazer; desfazer volta a Seguir sem trocar a linha; sem desfazer a linha é trocada após 6 s;
  clicar em "Seguindo" cancela; desfazer que falha mantém o Desfazer. Tudo passou.
- **Não verificado:** navegador real (largura do Desfazer ao lado do botão no painel de 320 px); Flutter inteiro (`DropdownButton`/`TextButton` com `Row` apertada em 300 dp: o nome da pessoa vai cortar com reticências).
- **Atenção (herdado):** vários testes antigos do site ainda esperam `driqy-shell-v57` (`test_mensagens_part1/2`, `test_ping_phase4a/4b/7/8`), mas o `sw.js` já estava em v59 antes desta parte; eles falham por isso, não por esta mudança. Vale trocar por uma checagem `>=`. **[RESOLVIDO em 10/11/2026: esses testes (e mais 4) agora checam `>=` em vez de uma versão fixa]**

## Peq-2 — o que foi feito (backend pequeno + site + Flutter)
**Flutter NÃO compilado** (sem SDK aqui): só balanceamento de chaves/parênteses e leitura da lógica contra os testes. Rode `flutter analyze` e `flutter test`.
- Comportamento (igual nos dois): cada manchete do widget de Notícias ganhou um "×" (dispensar). A manchete some, o servidor é consultado de novo com `limit` maior (4 + nº de dispensadas, máx. 12) e entra outra no lugar,
  então continuam aparecendo 4. Com alguma dispensada aparece "Mostrar as dispensadas (N)", que limpa a lista. Se todas as de agora foram dispensadas: "Você dispensou as manchetes de agora." + o link de restaurar.
- **Só neste aparelho**: site em `localStorage` (`driqy-news-dismissed`), app em `SharedPreferences` (`driqy.news.dismissed`, lista de ids em texto). Guarda os 60 ids mais recentes. Não vai para o servidor nem sincroniza entre aparelhos.
- Backend: `GET /api/v1/widgets/news` aceita `?limit=` (1 a 12; inválido/zero = 4). Sem `limit` responde como antes (compatível com app antigo).
- Site (`rail-widgets.js`, `style.css`): `load()` aceita uma função de query (`newsQuery`) e passa `redo` ao desenho; `drawNews` filtra as dispensadas; storage sempre em try/catch (valor corrompido é ignorado). `sw.js` -> `driqy-shell-v61`.
- Flutter (`widgets/rail/rail_lists.dart`): `RailNewsWidget` virou `StatefulWidget` (saiu do `RailLoader` para poder repor sem voltar a "Carregando…"); `WidgetsService.getNews({limit = 4})`. Chaves de teste: `news-dismiss-<id>`, `news-restore`.
- Testes: site `tests/test_layout_news_dismiss_peq2.py` (5) e `test_news_limit_param_is_accepted_and_clamped` em `test_widgets_part4.py`; Flutter `test/rail_lists_test.dart` (3 novos; o fake de `getNews` agora aceita `limit`).
- O JS do site foi exercitado num DOM simulado (jsdom, fora do repositório): mostra 4; dispensar repõe a 5ª e pede `limit=5`; id guardado; restaurar volta a manchete; storage corrompido ignorado. Tudo passou.
- **Não verificado:** navegador real (posição do "×" sobre a miniatura); Flutter inteiro. Ao repor, o site volta por um instante a "Carregando…" (o app não).

## Peq-3 — o que foi feito (site + Flutter; backend não mudou)
**Flutter NÃO compilado** (sem SDK aqui): só balanceamento de chaves/parênteses e leitura da lógica contra os testes. Rode `flutter analyze` e `flutter test`.
- **Correção do diagnóstico:** o diálogo do **site** já listava os 16 widgets prontos (os 10 novos incluídos) e os próprios, porque monta a lista a partir de `cfg.widgets` (= `rail_context`, que já traz `custom:N`). Conferi num DOM simulado. A lacuna real era só no **Flutter**.
- Flutter (`widgets/rail/rail_customize.dart`): o diálogo filtrava a ordem só por `kRailWidgetNames`, então os widgets próprios ficavam escondidos (mas preservados). Agora lista também os `custom:N` que o `RailPrefsController.customs` conhece, com o título do usuário e a etiqueta "seu"
  (`Key('cz-own-<id>')`). Ids que nem o app nem o catálogo conhecem (de outra versão) continuam fora da tela, mas são mantidos na ordem ao salvar/reordenar.
- Site (`rail-customize.js`): só a etiqueta "seu" (classe `.rail-ed-tag`, já existente) ao lado dos widgets próprios. `sw.js` -> `driqy-shell-v62`.
- Testes: site `tests/test_layout_customize_peq3.py` (4, inclui `rail_context` com um widget próprio); Flutter `test/rail_customize_test.dart` (2 novos: lista prontos + próprios + etiqueta, id desconhecido fica de fora; desligar um próprio salva em `disabled` e mantém o id desconhecido na ordem).
- **Não verificado:** Flutter inteiro; navegador real (largura da etiqueta com título longo). Reordenar com arrastar usa índices da lista visível; o caso com widgets próprios misturados não foi exercitado em tela.

## Rotas-1 — o que foi feito (SÓ Flutter; backend/site não mudaram)
**NÃO compilado** (sem SDK aqui): só análise sintática (tree-sitter-dart) dos arquivos novos/alterados, sem erros. Não houve `flutter analyze`, `flutter test` nem execução. Rode `flutter analyze` e `flutter test`.
- **Ideia:** em tela larga (≥ 901 dp) o miolo da `HomeShell` ganhou um `Navigator` PRÓPRIO. O que o miolo abre (Perfil, Notícias, Post, Busca, Vortex detalhe, Editar perfil, Widgets...) é empilhado ali dentro, então a caixa do menu (e o painel direito) continuam na tela, como no site. Abaixo de 901 dp **nada mudou** (rotas por cima de tudo, Drawer + barra inferior).
- `widgets/inner_nav_host.dart` (novo): `InnerNavHost` (Navigator interno + `HeroControllerScope.none` + `WillPopScope` + coluna de largura) e `InnerDepthObserver` (conta as telas empilhadas por cima da inicial: push/pop/pushAndRemoveUntil/popUntil). `homeBuilder` precisa se atualizar sozinho (o Navigator não reconstrói a rota quando o pai reconstrói).
- `widgets/wide_layout.dart`: + `ShellNav` (InheritedWidget com a chave do Navigator interno) e `shellNavigatorOf(context)` = Navigator interno se existir, senão `Navigator.of(context)` (celular, testes, fora da HomeShell). Serve para quem está FORA do miolo (menu e painel direito).
- `screens/home_shell.dart`: a aba atual virou `ValueNotifier<int> _tab` (`_index` é getter/setter dele); `_innerNavKey`; `_wide` (última decisão do LayoutBuilder). `_pushStacked` (Notícias, Meu perfil, Widgets): em tela larga faz `pushAndRemoveUntil(..., isFirst)` no interno, ou seja, clicar de novo num item do menu SUBSTITUI a tela em vez de empilhar; no celular é push normal. `_pushRoot` (só o Ping) segue por cima de tudo. `_selectTab` e `_goToCompose` fecham as telas empilhadas do miolo antes de trocar a aba. Na tela de Widgets, "Abrir o Vortex" só faz `maybePop` no celular (em tela larga o `_selectTab` já fecha; antes o `maybePop` iria no Navigator raiz e fecharia a própria HomeShell).
- **Painel direito** (`rail_lists`, `rail_extra`, `rail_suggestions`, `weather_widget`): os `Navigator.of(context).push` viraram `shellNavigatorOf(context).push` (perfil, post, Vortex detalhe, editar perfil).
- **Continuam por cima de tudo (Navigator raiz):** Mensagens/Ping (`DriqyTopBar._openMessages` e `_openPing`; é um app à parte, tem layout próprio de 2 painéis e não cabe na coluna), visualizador de imagens (`MediaLightbox.open`), visualizador de Flash (`openFlash`) e os diálogos (`showDialog` já usa a raiz). No celular `rootNavigator: true` é o mesmo Navigator de antes.
- **Largura:** com tela empilhada o miolo fica limitado a 620 dp (`kContentMaxWidth`, como `.content` do site); sem nada empilhado a aba Vortex usa a largura toda (`homeFullWidth`). A largura troca no começo da transição de empilhar/voltar (o observer atualiza na hora).
- **Voltar do sistema (Android):** `WillPopScope` (o mesmo que o app já usa em 4 lugares) fecha primeiro a tela empilhada do miolo; sem nenhuma, o gesto segue para o raiz. Com "voltar preditivo" do Android 14+ ligado o `WillPopScope` não intercepta direito (limitação que o app já tinha); migrar tudo para `PopScope` fica como melhoria.
- **Testes novos** (`flutter test`, NÃO rodados): `test/inner_nav_host_test.dart` (6): push do miolo fica no interno e o menu continua; `shellNavigatorOf` do menu empilha no interno; sem `ShellNav` cai no raiz; voltar do sistema fecha a tela do miolo; larguras (620 / tela cheia) incluindo a volta; contagem com `popUntil` e `pushAndRemoveUntil`.
- **Limites conhecidos / não verificado:**
  1. Redimensionar a janela atravessando 901 dp: a pilha do miolo (tela larga) é perdida ao ficar estreita (o Navigator interno some) e telas abertas no celular ficam por cima da HomeShell (sem a caixa) ao ficar larga, até serem fechadas. A KeyedSubtree das abas é reaproveitada pela `GlobalKey` entre os dois formatos de árvore: é o ponto de maior risco (a rolagem do feed pode zerar se o reaproveitamento não acontecer).
  3. Toque numa notificação push (`main.dart`, `_handleNotificationTap`) ainda empilha no Navigator raiz (tela cheia, sem a caixa).
  4. O sino da topbar em tela larga empilha OUTRA tela de Notificações no miolo (a aba já existe); o item do menu não fica destacado quando Notícias/Perfil/Widgets está aberto.
  5. Pontos de maior risco de compilação: `HeroControllerScope.none`, `WillPopScope` aninhado no `ContentColumn`, e `ValueListenableBuilder` dentro da rota inicial. Ver numa janela larga de verdade: transição ao abrir Perfil, altura/alinhamento da coluna de 620 com o menu, tema claro.
- Zips: `driqy4-web-v_0_0_9.zip` (só o `.md` mudou) e `driqy-flutter_v_0_0_9.zip`.

## Painel direito SÓ na Home (site + Flutter) — substitui as regras antigas de onde o painel aparece
> Pedido do usuário (10/11/2026): "remova essas partes que falta e deixe os widgets apenas na home principal, não deixando extrapolar para outras regiões da rede".
> **As partes pendentes da tabela (Rotas-2, Verif., Fut-1 a Fut-4) foram REMOVIDAS do plano a pedido do usuário: não há mais nada marcado como "a fazer" neste arquivo.**
- **Regra nova (igual nos dois):** o painel direito (widgets + "Sugestões para você") existe SÓ na Home (feed). Em qualquer outra página/aba/tela ele não existe: nem desenhado, nem carregado. A única exceção é a tela própria "Widgets" do celular/tela média (item do menu), que já era uma tela só de widgets.
- **Site:** `feed.html` marca `body.home-page`. `base.html` calcula `_rail_home` (home) e `_rail_scripts` (home ou `/widgets`) a partir do `body_class` e só inclui `_rail.html`, `window.__railCfg` e os `rail*.js` nesses casos (as outras páginas não fazem mais as chamadas de clima/notícias/sugestões nem carregam esses scripts; `place-picker.js` continua em toda página logada porque o Editar perfil usa). A seção "Painel direito" das Configurações também só existe na Home. `style.css`: a lista negra (`:not(.pictures-page):not(.news-page)...`) virou lista branca `body.home-page:not(.rail-off)`; antes o painel vazava para Notificações, Post, Busca, Seguidores etc. `sw.js` -> `driqy-shell-v63` (testes que fixavam v62 atualizados). Teste novo: `tests/test_rail_home_only.py` (4). Rodados com ele: layout 1/3/4, rail_edit 2, customize, news_dismiss, suggest_undo, minha_area 3, seasons_moon, calendario_global 3 = 88 passando. Suíte inteira NÃO rodada.
- **Flutter:** `railFits` agora exige a aba Feed (`kFeedTabIndex = 0`) e, na `HomeShell`, nenhuma tela empilhada no miolo (`InnerNavHost.onDepthChanged` -> `_innerDepth`). O item "Widgets" do menu aparece sempre que a coluna não cabe na largura (< 1200 dp), em qualquer aba. `wide_layout_test` atualizado (Notificações e Vortex = sem painel) e teste novo `onDepthChanged` em `inner_nav_host_test`. **NÃO compilado/rodado** (só sintaxe conferida).
- **Efeito colateral:** ao abrir uma tela por cima da Home (perfil, post...) o painel some e, ao voltar, ele é recriado (os widgets buscam os dados de novo). No site isso é natural (outra página).
- Zips: `driqy4-web-v_0_0_10.zip` e `driqy-flutter_v_0_0_10.zip`.
