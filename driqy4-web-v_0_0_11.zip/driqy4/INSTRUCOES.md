# Driqy — rodando sozinho para sempre (Windows)

Isso faz duas coisas:
1. Se o `app.py` cair por qualquer motivo, ele **reinicia sozinho em 5 segundos**.
2. O Driqy **liga automaticamente quando você faz login no Windows** — sem precisar abrir o VS Code nem o terminal.

## 1. Ajuste os caminhos

Abra os dois arquivos abaixo num editor de texto e troque `C:\Users\Wandrew\Downloads\driqy4`
pelo caminho real da pasta do projeto na sua máquina:

- `run_forever.bat` → linha `set "PROJECT_DIR=..."`
- `iniciar_oculto.vbs` → linha `WshShell.Run ...`

Coloque os dois arquivos **dentro da pasta do projeto** (ex: `C:\Users\Wandrew\Downloads\driqy4\`).

## 2. Teste manualmente primeiro

Dê duplo clique em `run_forever.bat`. Uma janela preta vai abrir e o Driqy deve
subir normalmente em `http://localhost:5000`. Feche a janela (Ctrl+C ou fechando
mesmo) e veja se ela reabre sozinha em ~5s — isso confirma que o loop funciona.

Depois teste o `iniciar_oculto.vbs`: dando duplo clique nele, o Driqy deve subir
**sem nenhuma janela aparecer**. Confira em `logs\app.log` dentro da pasta do
projeto se ele realmente iniciou.

## 3. Criar a tarefa para rodar sozinho ao ligar o PC / logar

### Opção A — pelo Agendador de Tarefas (interface gráfica)

1. Abra o menu Iniciar → digite **"Agendador de Tarefas"** (Task Scheduler) → abra.
2. Clique em **"Criar Tarefa..."** (não use "Criar Tarefa Básica").
3. Aba **Geral**:
   - Nome: `Driqy AutoStart`
   - Marque **"Executar com privilégios mais altos"**
4. Aba **Disparadores** → **Novo...**:
   - Iniciar a tarefa: **Ao fazer logon** (recomendado — garante que seu venv/PATH
     de usuário funcione normalmente)
   - Se quiser que rode mesmo sem ninguém logar, use **"Ao iniciar o computador"**,
     mas aí a tarefa roda como SYSTEM e pode não enxergar seu venv/Python do usuário.
5. Aba **Ações** → **Nova...**:
   - Programa/script: `wscript.exe`
   - Argumentos: `"C:\Users\Wandrew\Downloads\driqy4\iniciar_oculto.vbs"`
6. Aba **Condições**: desmarque "Iniciar a tarefa somente se o computador estiver
   com energia CA" se for notebook.
7. Aba **Configurações**: marque **"Se a tarefa falhar, reiniciar a cada"** →
   1 minuto, tentar 3 vezes (proteção extra além do próprio loop do .bat).
8. Salvar. Vai pedir sua senha do Windows (por causa dos privilégios altos).

### Opção B — via linha de comando (mais rápido)

Abra o **PowerShell como Administrador** e rode (ajustando o caminho):

```powershell
schtasks /create /tn "Driqy AutoStart" /tr "wscript.exe \"C:\Users\Wandrew\Downloads\driqy4\iniciar_oculto.vbs\"" /sc onlogon /rl highest /f
```

Para testar sem reiniciar o PC:

```powershell
schtasks /run /tn "Driqy AutoStart"
```

Para remover, se precisar:

```powershell
schtasks /delete /tn "Driqy AutoStart" /f
```

## 4. Acompanhar se está tudo bem

- `logs\watchdog.log` → mostra cada vez que o Driqy iniciou/caiu e por quê (código de saída).
- `logs\app.log` → a saída normal do Flask (prints, erros do Python, etc.).

## Observação sobre `debug=True`

Seu `app.py` termina com:

```python
app.run(debug=True, host="0.0.0.0", port=5000)
```

O modo debug é ótimo para desenvolver (recarrega sozinho quando você salva um
arquivo), mas ele roda dois processos Python e não é pensado para ficar rodando
"para sempre" sem supervisão — pode ficar instável em uso prolongado. Se essa
automação for para deixar o Driqy sempre disponível (não só enquanto você
desenvolve), me avisa que eu ajusto o `app.py` para rodar sem debug/reloader
nesse cenário — é uma mudança pequena e evita reinícios desnecessários toda
vez que qualquer arquivo é tocado.
