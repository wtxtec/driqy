"""Controle e gestão do Vortex pelo admin (só web; o app Flutter não usa).

Quatro coisas, todas independentes do processo em que o admin cai:

1. **Pausar / velocidade** do motor de indexação. O estado fica na tabela
   `vortex_control` (banco); o motor lê com cache curto (~2 s). Pausar =
   não buscar conteúdo NOVO (o que já está em andamento termina e o gravador
   esvazia a fila; a análise visual dos itens já indexados continua).
   Velocidade é um fator de 0,1x a 4x: mais fontes em paralelo e pausas menores
   entre rodadas (rápido) ou o contrário (lento). Nunca fica mais agressiva
   com os sites do que a configuração: intervalos por host, `Crawl-delay` e
   o teto de páginas/hora por site só aumentam em modo lento.
2. **Tempo real**: o motor grava a cada 2 s um instantâneo em
   `instance/vortex_engine_stats.json`; o admin lê (ou usa o motor do próprio
   processo, se for o caso).
3. **Visão geral do que foi indexado** (`overview`): totais, por tipo,
   categoria, fonte, site, perfil, linha do tempo e cobertura da análise visual.
4. **Exclusão em massa** (`start_purge`/`run_purge`) por categoria, fonte, site,
   perfil e/ou tipo, em lotes (não trava o banco nem a requisição) e, por
   padrão, com "lápide" (`vortex_tombstones`): a URL apagada não volta a ser
   indexada.
"""
import json
import logging
import os
import threading
import time
from datetime import timedelta

from sqlalchemy import func, text
from sqlalchemy.exc import IntegrityError, OperationalError

from extensions import db
from models import (
    VortexControl, VortexCrawlSource, VortexItem, VortexProfile, VortexTombstone,
    to_brasilia, utcnow,
)

log = logging.getLogger("vortex")

SPEED_LEVELS = (0.25, 0.5, 1.0, 2.0, 4.0)
MIN_SPEED, MAX_SPEED = 0.1, 4.0
DEFAULT_CONTROL = {"paused": False, "speed": 1.0, "purge_seq": 0}

_INSTANCE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "instance")
STATS_FILE = os.path.join(_INSTANCE, "vortex_engine_stats.json")
PURGE_FILE = os.path.join(_INSTANCE, "vortex_purge_job.json")
STATS_MAX_AGE = 15          # s: instantâneo mais velho que isso = motor parado


# ---------------------------------------------------------------------------
# arquivos JSON atômicos (instantâneo do motor e estado da exclusão)
# ---------------------------------------------------------------------------

def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    os.replace(tmp, path)


def _read_json(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def write_stats_file(data):
    _write_json(STATS_FILE, data)


def read_stats_file(max_age=STATS_MAX_AGE):
    """Instantâneo gravado pelo motor (qualquer processo), ou None se velho."""
    data = _read_json(STATS_FILE)
    if not data or time.time() - data.get("ts", 0) > max_age:
        return None
    return data


# ---------------------------------------------------------------------------
# controle: pausa, velocidade, sequência de exclusões
# ---------------------------------------------------------------------------

_cache = {"at": 0.0, "data": dict(DEFAULT_CONTROL)}
_cache_lock = threading.Lock()


def _parse(rows):
    data = dict(DEFAULT_CONTROL)
    for key, value in rows:
        try:
            if key == "paused":
                data["paused"] = value == "1"
            elif key == "speed":
                data["speed"] = min(MAX_SPEED, max(MIN_SPEED, float(value)))
            elif key == "purge_seq":
                data["purge_seq"] = int(value)
        except ValueError:
            pass
    return data


def read_control(app, ttl=2.0):
    """Estado atual do controle (cache de `ttl` s). Em falha do banco devolve
    o último valor conhecido: o motor nunca para por causa disso."""
    now = time.monotonic()
    with _cache_lock:
        if ttl and now - _cache["at"] < ttl:
            return dict(_cache["data"])
    try:
        with app.app_context():
            rows = db.session.query(VortexControl.key, VortexControl.value).all()
        data = _parse(rows)
    except Exception:
        with _cache_lock:
            return dict(_cache["data"])
    with _cache_lock:
        _cache["at"], _cache["data"] = now, data
    return dict(data)


def invalidate_control_cache():
    with _cache_lock:
        _cache["at"] = 0.0


def _set(key, value):
    """Grava uma chave (no contexto de app atual) e comita."""
    for _ in range(3):
        row = db.session.get(VortexControl, key)
        if row is None:
            db.session.add(VortexControl(key=key, value=str(value)))
        else:
            row.value = str(value)
        try:
            db.session.commit()
            break
        except IntegrityError:      # dois escritores criaram a chave ao mesmo tempo
            db.session.rollback()
    invalidate_control_cache()


def clamp_speed(value):
    value = float(value)
    if value != value or value in (float("inf"), float("-inf")):
        raise ValueError("velocidade inválida")
    return round(min(MAX_SPEED, max(MIN_SPEED, value)), 2)


def set_paused(paused):
    _set("paused", "1" if paused else "0")


def set_speed(value):
    """Devolve a velocidade gravada (já limitada a MIN_SPEED..MAX_SPEED)."""
    speed = clamp_speed(value)
    _set("speed", speed)
    return speed


def bump_purge_seq():
    row = db.session.get(VortexControl, "purge_seq")
    try:
        current = int(row.value) if row else 0
    except ValueError:
        current = 0
    _set("purge_seq", current + 1)


# ---------------------------------------------------------------------------
# visão geral do que foi indexado
# ---------------------------------------------------------------------------

_ov_cache = {"at": 0.0, "data": None}
_ov_lock = threading.Lock()


def _bump(bucket, media_type, n):
    bucket["total"] += n
    if media_type in ("photo", "gif", "video"):
        bucket[{"photo": "photos", "gif": "gifs", "video": "videos"}[media_type]] += n


def _empty():
    return {"total": 0, "photos": 0, "gifs": 0, "videos": 0, "last_at": None, "last_24h": 0}


def _newest(current, candidate):
    return candidate if candidate and (current is None or candidate > current) else current


def _iso(dt):
    return dt.isoformat() + "Z" if dt else None


def overview(app, ttl=5.0):
    """Tudo que foi indexado, agrupado. Cache curto (as consultas varrem a
    tabela inteira agrupando; com 60 mil itens é rápido, mas a página consulta
    a cada poucos segundos)."""
    now = time.monotonic()
    with _ov_lock:
        if ttl and _ov_cache["data"] is not None and now - _ov_cache["at"] < ttl:
            return _ov_cache["data"]
    data = _build_overview(app)
    with _ov_lock:
        _ov_cache["at"], _ov_cache["data"] = now, data
    return data


def clear_overview_cache():
    with _ov_lock:
        _ov_cache["at"], _ov_cache["data"] = 0.0, None


def _build_overview(app):
    labels = dict(app.config["VORTEX_CATEGORIES"])
    since = utcnow() - timedelta(hours=24)
    with app.app_context():
        S = db.session
        active = VortexItem.is_active.is_(True)
        total = _empty()
        by_cat, by_src, by_site, by_prof = {}, {}, {}, {}

        for cat, mt, n, last in (S.query(VortexItem.category, VortexItem.media_type,
                                         func.count(VortexItem.id), func.max(VortexItem.created_at))
                                 .filter(active).group_by(VortexItem.category, VortexItem.media_type)):
            b = by_cat.setdefault(cat, _empty())
            _bump(b, mt, n)
            _bump(total, mt, n)
            b["last_at"] = _newest(b["last_at"], last)
            total["last_at"] = _newest(total["last_at"], last)
        for cat, n in (S.query(VortexItem.category, func.count(VortexItem.id))
                       .filter(active, VortexItem.created_at >= since).group_by(VortexItem.category)):
            by_cat.setdefault(cat, _empty())["last_24h"] = n
        total["last_24h"] = sum(b["last_24h"] for b in by_cat.values())

        for sid, mt, n, last in (S.query(VortexItem.source_id, VortexItem.media_type,
                                         func.count(VortexItem.id), func.max(VortexItem.created_at))
                                 .filter(active).group_by(VortexItem.source_id, VortexItem.media_type)):
            b = by_src.setdefault(sid, _empty())
            _bump(b, mt, n)
            b["last_at"] = _newest(b["last_at"], last)
        for pid, mt, n in (S.query(VortexItem.profile_id, VortexItem.media_type, func.count(VortexItem.id))
                           .filter(active).group_by(VortexItem.profile_id, VortexItem.media_type)):
            _bump(by_prof.setdefault(pid, _empty()), mt, n)
        site_rows = (S.query(VortexItem.source_name, func.count(VortexItem.id), func.max(VortexItem.created_at))
                     .filter(active, VortexItem.source_name.isnot(None))
                     .group_by(VortexItem.source_name).order_by(func.count(VortexItem.id).desc()).limit(60).all())
        sites_total = (S.query(func.count(func.distinct(VortexItem.source_name)))
                       .filter(active, VortexItem.source_name.isnot(None)).scalar() or 0)
        for host, n, last in site_rows:
            by_site[host] = {"total": n, "last_at": last}

        sources = {s.id: s for s in VortexCrawlSource.query.all()}
        profiles = {p.id: p for p in VortexProfile.query.all()}
        hidden = S.query(func.count(VortexItem.id)).filter(VortexItem.is_active.is_(False)).scalar() or 0
        vision = {
            "analysed": S.query(func.count(VortexItem.id)).filter(VortexItem.vfeat.isnot(None), VortexItem.vfeat != "").scalar() or 0,
            "pending": S.query(func.count(VortexItem.id)).filter(VortexItem.vfeat.is_(None)).scalar() or 0,
            "unreadable": S.query(func.count(VortexItem.id)).filter(VortexItem.vfeat == "").scalar() or 0,
            "with_phash": S.query(func.count(VortexItem.id)).filter(VortexItem.phash.isnot(None)).scalar() or 0,
        }
        tombstones = S.query(func.count(VortexTombstone.url_hash)).scalar() or 0

        timeline = []
        try:    # strftime: SQLite (é o banco do projeto); em outro banco a linha do tempo fica vazia
            rows = (S.query(func.strftime("%Y-%m-%d %H", VortexItem.created_at), func.count(VortexItem.id))
                    .filter(active, VortexItem.created_at >= since)
                    .group_by(func.strftime("%Y-%m-%d %H", VortexItem.created_at)).all())
            counts = {k: n for k, n in rows}
            cursor = utcnow().replace(minute=0, second=0, microsecond=0) - timedelta(hours=23)
            for _ in range(24):
                key = cursor.strftime("%Y-%m-%d %H")
                timeline.append({"hour": to_brasilia(cursor).strftime("%H:00"), "count": counts.get(key, 0)})
                cursor += timedelta(hours=1)
        except Exception:
            S.rollback()

    def pack(bucket):
        return {**bucket, "last_at": _iso(bucket["last_at"])}

    cats = [{"slug": c, "label": labels.get(c, c), **pack(b)} for c, b in by_cat.items()]
    cats.sort(key=lambda r: -r["total"])
    srcs = []
    for sid, b in by_src.items():
        s = sources.get(sid)
        srcs.append({
            "id": sid, "name": s.name if s else "Descoberta (páginas da web)", "kind": s.kind if s else "web",
            "enabled": bool(s.enabled) if s else True, "category": s.category if s else None,
            "profile": profiles[s.profile_id].handle if s and s.profile_id in profiles else None, **pack(b),
        })
    srcs.sort(key=lambda r: -r["total"])
    sites = [{"host": h, "total": v["total"], "last_at": _iso(v["last_at"])} for h, v in by_site.items()]
    profs = [{"id": pid, "handle": profiles[pid].handle if pid in profiles else f"#{pid}",
              "name": profiles[pid].display_name if pid in profiles else "", **pack(b)}
             for pid, b in by_prof.items()]
    profs.sort(key=lambda r: -r["total"])
    return {
        "total": pack(total), "hidden": hidden, "categories": cats, "sources": srcs, "sites": sites,
        "sites_total": sites_total, "profiles": profs, "timeline": timeline, "vision": vision,
        "tombstones": tombstones, "concepts": _concepts_overview(app),
    }


def _concepts_overview(app):
    """Cobertura da compreensão de conteúdo (conceitos). Nunca derruba a página."""
    try:
        import vortex_understand
        return vortex_understand.coverage(app, ttl=0)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# filtros e exclusão em massa
# ---------------------------------------------------------------------------

def item_conditions(category=None, source_id=None, site=None, profile_id=None, media_type=None,
                    hidden_only=False):
    """Condições SQLAlchemy (AND) para os itens do Vortex. Precisa de pelo
    menos um filtro: nunca devolve 'tudo' sem querer."""
    conds = []
    if category:
        conds.append(VortexItem.category == category)
    if source_id:
        conds.append(VortexItem.source_id == int(source_id))
    if site:
        conds.append(VortexItem.source_name == site)
    if profile_id:
        conds.append(VortexItem.profile_id == int(profile_id))
    if media_type:
        if media_type not in ("photo", "gif", "video"):
            raise ValueError("tipo inválido")
        conds.append(VortexItem.media_type == media_type)
    if hidden_only:
        conds.append(VortexItem.is_active.is_(False))
    if not conds:
        raise ValueError("escolha pelo menos um filtro")
    return conds


def filters_from_args(args):
    """Lê os filtros de um formulário/querystring (campos em português)."""
    def num(name):
        value = (args.get(name) or "").strip()
        return int(value) if value.isdigit() else None
    return {
        "category": (args.get("categoria") or "").strip() or None,
        "source_id": num("fonte"),
        "site": (args.get("site") or "").strip().lower() or None,
        "profile_id": num("perfil"),
        "media_type": (args.get("tipo") or "").strip() or None,
        "hidden_only": args.get("ocultos") == "1",
    }


def count_items(filters):
    return VortexItem.query.filter(*item_conditions(**filters)).count()


def describe_filters(filters, labels=None):
    parts = []
    if filters.get("category"):
        parts.append(f"categoria {(labels or {}).get(filters['category'], filters['category'])}")
    if filters.get("source_id"):
        parts.append(f"fonte #{filters['source_id']}")
    if filters.get("site"):
        parts.append(f"site {filters['site']}")
    if filters.get("profile_id"):
        parts.append(f"perfil #{filters['profile_id']}")
    if filters.get("media_type"):
        parts.append({"photo": "fotos", "gif": "GIFs", "video": "vídeos"}[filters["media_type"]])
    if filters.get("hidden_only"):
        parts.append("só ocultos")
    return ", ".join(parts)


PURGE_BATCH = 500
_purge_lock = threading.Lock()


def read_purge_job():
    """Estado da última exclusão em massa (arquivo; vale entre processos)."""
    job = _read_json(PURGE_FILE)
    if job and job.get("state") == "running" and time.time() - job.get("ts", 0) > 60:
        job["state"] = "interrupted"     # o processo caiu no meio
    return job


def _retry(fn, attempts=5):
    for attempt in range(attempts):
        try:
            return fn()
        except OperationalError:
            db.session.rollback()
            time.sleep(0.5 * (attempt + 1))
    return fn()


def run_purge(app, filters, tombstone=True, disable_sources=False, block_site=False, label=""):
    """Apaga (de verdade) os itens que casam com `filters`, em lotes. Bloqueia
    até acabar e devolve quantos foram apagados. Roda dentro de uma thread no
    admin (`start_purge`) e direto nos testes."""
    job = {"state": "running", "label": label, "deleted": 0, "total": 0, "started": time.time(),
           "ts": time.time(), "tombstone": bool(tombstone)}
    try:
        with app.app_context():
            S = db.session
            conds = item_conditions(**filters)
            job["total"] = S.query(func.count(VortexItem.id)).filter(*conds).scalar() or 0
            _write_json(PURGE_FILE, job)
            while True:
                ids = [r[0] for r in S.query(VortexItem.id).filter(*conds).order_by(VortexItem.id).limit(PURGE_BATCH)]
                if not ids:
                    break
                marks = ",".join(str(int(i)) for i in ids)      # ids vêm do banco: inteiros

                def _batch():
                    if tombstone:
                        S.execute(text(
                            "INSERT OR IGNORE INTO vortex_tombstones (url_hash, category, source_name, created_at) "
                            f"SELECT url_hash, category, source_name, :now FROM vortex_items WHERE id IN ({marks})"
                        ), {"now": utcnow()})
                    S.execute(text(f"DELETE FROM vortex_items WHERE id IN ({marks})"))
                    S.commit()

                _retry(_batch)
                job["deleted"] += len(ids)
                job["ts"] = time.time()
                _write_json(PURGE_FILE, job)
                time.sleep(0.05)       # deixa o gravador do motor respirar

            if disable_sources:
                src_q = VortexCrawlSource.query
                if filters.get("source_id"):
                    src_q = src_q.filter(VortexCrawlSource.id == filters["source_id"])
                elif filters.get("category"):
                    src_q = src_q.filter(VortexCrawlSource.category == filters["category"])
                elif filters.get("profile_id"):
                    src_q = src_q.filter(VortexCrawlSource.profile_id == filters["profile_id"])
                else:
                    src_q = None
                if src_q is not None:
                    src_q.update({"enabled": False}, synchronize_session=False)
                    S.commit()
            if block_site and filters.get("site"):
                from vortex_discovery import block_domain
                block_domain(db, filters["site"], True)
            bump_purge_seq()          # o motor recarrega URLs/phashes conhecidos
            clear_overview_cache()
            try:
                from vortex_search import clear_stats_cache
                clear_stats_cache(app)
            except Exception:
                pass
        job.update(state="done", finished=time.time(), ts=time.time())
    except Exception as exc:
        log.exception("[vortex] falha na exclusão em massa")
        job.update(state="error", error=str(exc)[:300], ts=time.time())
        try:
            with app.app_context():
                db.session.rollback()
        except Exception:
            pass
    _write_json(PURGE_FILE, job)
    return job["deleted"]


def start_purge(app, filters, **options):
    """Dispara a exclusão numa thread. Devolve False se já existe uma rodando."""
    if not _purge_lock.acquire(blocking=False):
        return False
    current = read_purge_job()
    if current and current.get("state") == "running":
        _purge_lock.release()
        return False

    def work():
        try:
            run_purge(app, filters, **options)
        finally:
            _purge_lock.release()

    _write_json(PURGE_FILE, {"state": "running", "label": options.get("label", ""), "deleted": 0,
                             "total": 0, "started": time.time(), "ts": time.time()})
    threading.Thread(target=work, name="vortex-purge", daemon=True).start()
    return True


def delete_item(app, item_id):
    """Apaga um item só (com lápide). Devolve True se existia."""
    item = db.session.get(VortexItem, item_id)
    if item is None:
        return False
    db.session.merge(VortexTombstone(url_hash=item.url_hash, category=item.category,
                                     source_name=item.source_name))
    db.session.delete(item)
    db.session.commit()
    bump_purge_seq()
    clear_overview_cache()
    try:
        from vortex_search import clear_stats_cache
        clear_stats_cache(app)
    except Exception:
        pass
    return True
