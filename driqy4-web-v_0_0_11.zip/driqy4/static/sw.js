/*
 * Service worker mínimo do Driqy — existe principalmente pra deixar o site
 * instalável como app (Android/Chrome exige um SW com "fetch" registrado).
 * Guarda em cache só o essencial pra abrir mais rápido e mostrar uma tela
 * de "sem conexão" quando o celular está offline; nunca serve em cache
 * páginas de post/feed/chat (isso tem que vir sempre da rede, atualizado).
 */
const CACHE_NAME = "driqy-shell-v63";
const APP_SHELL = [
  "/static/css/style.css",
  "/static/brand/driqy-logo.png",
  "/static/icons/android-icon-192x192.png",
  "/offline",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      cache.addAll(APP_SHELL).catch(() => {})
    )
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return; // nunca mexe em POST (like, comentário, upload etc.)

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // navegação (abrir uma página): tenta rede primeiro, sempre fresco;
  // só cai pro cache/offline se não tiver internet
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).catch(() =>
        caches.match("/offline").then((res) => res || caches.match(req))
      )
    );
    return;
  }

  // sons: deixa o navegador tratar direto (o <audio> pede o arquivo em
  // partes/Range, o que não combina com a resposta completa do cache)
  if (url.pathname.startsWith("/static/sounds/")) return;

  // assets estáticos (css/js/ícones): cache primeiro, atualiza em segundo plano
  if (url.pathname.startsWith("/static/")) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fetchPromise = fetch(req)
          .then((res) => {
            if (res && res.ok) {
              const clone = res.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
            }
            return res;
          })
          .catch(() => cached);
        return cached || fetchPromise;
      })
    );
  }
});
