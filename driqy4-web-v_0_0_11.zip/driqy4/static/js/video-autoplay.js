/*
 * Player de vídeo dos posts (mídia única). Cuida de:
 * - autoplay mudo quando o vídeo entra na tela (scroll), pausa quando sai;
 * - alternar play/pause por toque/clique no vídeo ou no botão central;
 * - barra de progresso arrastável (seek) com tempo atual/duração;
 * - alternar som e tela cheia.
 * Um vídeo pausado manualmente pelo usuário não volta a tocar sozinho
 * quando reentra na tela, até ele mesmo mandar tocar de novo.
 */
(function () {
  function formatTime(seconds) {
    if (!isFinite(seconds) || seconds < 0) seconds = 0;
    const total = Math.floor(seconds);
    const m = Math.floor(total / 60);
    const s = total % 60;
    return m + ":" + String(s).padStart(2, "0");
  }

  function setMuteIcon(btn, muted) {
    if (!btn) return;
    const iconMuted = btn.querySelector(".icon-muted");
    const iconUnmuted = btn.querySelector(".icon-unmuted");
    if (iconMuted) iconMuted.hidden = !muted;
    if (iconUnmuted) iconUnmuted.hidden = muted;
    btn.dataset.muted = String(muted);
    const label = muted ? "Ativar som" : "Desativar som";
    btn.setAttribute("aria-label", label);
    btn.setAttribute("title", label);
  }

  function setPlayIcon(overlay, playing) {
    if (!overlay) return;
    const iconPlay = overlay.querySelector(".icon-play");
    const iconPause = overlay.querySelector(".icon-pause");
    if (iconPlay) iconPlay.hidden = playing;
    if (iconPause) iconPause.hidden = !playing;
    overlay.setAttribute("aria-label", playing ? "Pausar vídeo" : "Reproduzir vídeo");
  }

  function setupVideoWrap(wrap) {
    if (!wrap || wrap.dataset.autoplayReady) return;
    const video = wrap.querySelector("video.feed-video");
    if (!video) return;
    wrap.dataset.autoplayReady = "1";

    const muteBtn = wrap.querySelector(".video-mute-toggle");
    const playOverlay = wrap.querySelector(".video-play-overlay");
    const fullscreenBtn = wrap.querySelector(".video-fullscreen-btn");
    const progress = wrap.querySelector(".video-progress");
    const progressFill = wrap.querySelector(".video-progress-fill");
    const timeCurrent = wrap.querySelector(".video-time-current");
    const timeDuration = wrap.querySelector(".video-time-duration");

    video.muted = true;
    video.defaultMuted = true;
    setMuteIcon(muteBtn, true);

    function markPlaying(playing) {
      wrap.dataset.playing = String(playing);
      setPlayIcon(playOverlay, playing);
    }

    function play() {
      const p = video.play();
      if (p && p.catch) p.catch(() => {});
    }

    function togglePlay(fromUser) {
      if (video.paused) {
        if (fromUser) delete wrap.dataset.userPaused;
        play();
      } else {
        if (fromUser) wrap.dataset.userPaused = "1";
        video.pause();
      }
    }

    // --- som ---
    let controlsTimer = null;
    function showControls() {
      wrap.classList.add("controls-visible");
      if (controlsTimer) clearTimeout(controlsTimer);
      controlsTimer = setTimeout(() => {
        wrap.classList.remove("controls-visible");
        controlsTimer = null;
      }, 3000);
    }

    if (muteBtn) {
      muteBtn.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        video.muted = !video.muted;
        setMuteIcon(muteBtn, video.muted);
        showControls();
      });
    }

    // --- play/pause (toque no vídeo ou no botão central) ---
    if (playOverlay) {
      playOverlay.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        togglePlay(true);
        showControls();
      });
    }

    video.addEventListener("play", () => markPlaying(true));
    video.addEventListener("pause", () => markPlaying(false));

    // --- tela cheia ---
    if (fullscreenBtn) {
      fullscreenBtn.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        showControls();
        if (document.fullscreenElement === wrap) {
          if (document.exitFullscreen) document.exitFullscreen();
        } else if (wrap.requestFullscreen) {
          wrap.requestFullscreen().catch(() => {});
        } else if (video.requestFullscreen) {
          video.requestFullscreen().catch(() => {});
        }
      });
    }

    // --- tempo / progresso ---
    video.addEventListener("loadedmetadata", () => {
      if (timeDuration) timeDuration.textContent = formatTime(video.duration);
    });

    video.addEventListener("timeupdate", () => {
      if (!video.duration) return;
      const pct = (video.currentTime / video.duration) * 100;
      if (progressFill) progressFill.style.width = pct + "%";
      if (progress) progress.setAttribute("aria-valuenow", String(Math.round(pct)));
      if (timeCurrent) timeCurrent.textContent = formatTime(video.currentTime);
    });

    // --- arrastar/clicar na barra de progresso (mouse + toque) ---
    if (progress) {
      let dragging = false;

      function seekFromEvent(clientX) {
        const rect = progress.getBoundingClientRect();
        const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
        if (isFinite(video.duration) && video.duration > 0) {
          video.currentTime = ratio * video.duration;
          if (progressFill) progressFill.style.width = (ratio * 100) + "%";
        }
      }

      function pointerDown(event) {
        event.preventDefault();
        event.stopPropagation();
        dragging = true;
        showControls();
        progress.classList.add("dragging");
        const clientX = event.touches ? event.touches[0].clientX : event.clientX;
        seekFromEvent(clientX);
        window.addEventListener("mousemove", pointerMove);
        window.addEventListener("touchmove", pointerMove, { passive: false });
        window.addEventListener("mouseup", pointerUp);
        window.addEventListener("touchend", pointerUp);
      }

      function pointerMove(event) {
        if (!dragging) return;
        event.preventDefault();
        showControls();
        const clientX = event.touches ? event.touches[0].clientX : event.clientX;
        seekFromEvent(clientX);
      }

      function pointerUp() {
        dragging = false;
        progress.classList.remove("dragging");
        window.removeEventListener("mousemove", pointerMove);
        window.removeEventListener("touchmove", pointerMove);
        window.removeEventListener("mouseup", pointerUp);
        window.removeEventListener("touchend", pointerUp);
      }

      progress.addEventListener("mousedown", pointerDown);
      progress.addEventListener("touchstart", pointerDown, { passive: false });
      progress.addEventListener("keydown", (event) => {
        if (!isFinite(video.duration) || !video.duration) return;
        if (event.key === "ArrowRight") video.currentTime = Math.min(video.duration, video.currentTime + 5);
        if (event.key === "ArrowLeft") video.currentTime = Math.max(0, video.currentTime - 5);
      });
    }

    // --- autoplay ao entrar na tela, pausa ao sair ---
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            if (wrap.dataset.userPaused !== "1") play();
          } else {
            video.pause();
          }
        });
      },
      { threshold: [0, 0.5, 1] }
    );
    observer.observe(video);
    wrap._autoplayObserver = observer;
  }

  function setupCard(scope) {
    (scope || document).querySelectorAll(".video-wrap").forEach(setupVideoWrap);
  }

  window.driqyVideoAutoplay = { setupCard, setupVideoWrap };

  document.addEventListener("DOMContentLoaded", () => setupCard(document));
})();
