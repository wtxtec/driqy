/* Modo "Editar widgets" direto no cartão do painel: tirar, reordenar e adicionar de volta.
   O catálogo vem do servidor (window.__railCfg.widgets, que já inclui os widgets do usuário);
   "Concluir" salva em /widgets/prefs e o painel se atualiza sem recarregar a página.
   Texto vindo do servidor entra só via textContent. */
(function () {
  "use strict";
  var btn = document.getElementById("rail-widget-edit");
  var cfg = window.__railCfg;
  var url = window.__railPrefsUrl;
  if (!btn || !cfg || !url || !window.DriqyRail || !window.DriqyRail.openEditor) return;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function open() {
    var all = cfg.widgets || [];
    var byId = {};
    all.forEach(function (w) { byId[w.id] = w; });
    var p = cfg.prefs || {};
    var off = (p.disabled || []).filter(function (id) { return byId[id]; });
    var active = (p.order || []).filter(function (id) { return byId[id] && off.indexOf(id) < 0; });
    all.forEach(function (w) {
      if (active.indexOf(w.id) < 0 && off.indexOf(w.id) < 0) active.push(w.id);
    });
    var startJson = JSON.stringify([active, off]);
    var lastCreated = null;
    var KINDS = [["note", "Nota"], ["checklist", "Tarefas"], ["links", "Atalhos"], ["countdown", "Contagem"], ["counter", "Contador"]];

    window.DriqyRail.openEditor(function (body, done) {
      var busy = false;

      function btnEl(label, text, cls, disabled, fn, key) {
        var b = el("button", cls, text);
        b.type = "button";
        b.setAttribute("aria-label", label);
        b.dataset.k = key;
        b.disabled = !!disabled || busy;
        b.addEventListener("click", fn);
        return b;
      }

      function row(id, isActive, i) {
        var w = byId[id];
        var li = el("li", "rail-ed-row");
        var txt = el("div", "rail-ed-txt");
        var name = el("b", null, w.title);
        if (w.custom) name.appendChild(el("span", "rail-ed-tag", "seu"));
        txt.appendChild(name);
        if (w.desc) txt.appendChild(el("small", null, w.desc));
        li.appendChild(txt);
        if (isActive) {
          if (w.custom) li.appendChild(trash(id, w));
          li.appendChild(btnEl("Subir " + w.title, "▲", "rail-ed-btn", i === 0, function () { swap(i, -1, "up:" + id); }, "up:" + id));
          li.appendChild(btnEl("Descer " + w.title, "▼", "rail-ed-btn", i === active.length - 1, function () { swap(i, 1, "down:" + id); }, "down:" + id));
          li.appendChild(btnEl("Remover " + w.title, "✕", "rail-ed-btn rail-ed-remove", false, function () {
            active.splice(i, 1); off.unshift(id); render("add:" + id);
          }, "rm:" + id));
        } else {
          if (w.custom) li.appendChild(trash(id, w));
          li.appendChild(btnEl("Adicionar " + w.title, "+", "rail-ed-btn rail-ed-add", false, function () {
            off.splice(off.indexOf(id), 1); active.push(id); render("rm:" + id);
          }, "add:" + id));
        }
        return li;
      }

      function trash(id, w) {
        return btnEl("Apagar " + w.title + " de vez", "🗑", "rail-ed-btn rail-ed-remove", false, function () {
          if (!window.confirm("Apagar “" + w.title + "” de vez? O conteúdo não pode ser recuperado.")) return;
          busy = true; render("");
          window.DriqyMine.remove(id).then(function () {
            busy = false;
            active = active.filter(function (x) { return x !== id; });
            off = off.filter(function (x) { return x !== id; });
            if (lastCreated === id) lastCreated = null;
            startJson = JSON.stringify([active, off]);  // apagar já foi salvo; não conta como mudança pendente
            render("");
          }).catch(function (e) { busy = false; errEl.textContent = (e && e.message) || "Não foi possível apagar."; render(""); });
        }, "del:" + id);
      }

      function swap(i, d, key) {
        var j = i + d;
        if (j < 0 || j >= active.length) return;
        var t = active[i]; active[i] = active[j]; active[j] = t;
        render(key);
      }

      var errEl = el("p", "rail-ed-err");

      function render(focusKey) {
        body.textContent = "";
        body.appendChild(el("h3", "rail-ed-sub", "No painel (" + active.length + ")"));
        if (active.length) {
          var ul = el("ul", "rail-ed-list");
          active.forEach(function (id, i) { ul.appendChild(row(id, true, i)); });
          body.appendChild(ul);
        } else {
          body.appendChild(el("p", "hint rail-empty", "Nada no painel. Adicione abaixo."));
        }
        if (off.length) {
          body.appendChild(el("h3", "rail-ed-sub", "Disponíveis"));
          var ul2 = el("ul", "rail-ed-list");
          off.forEach(function (id) { ul2.appendChild(row(id, false, 0)); });
          body.appendChild(ul2);
        }
        if (window.DriqyMine) {
          var customCount = all.filter(function (w) { return w.custom; }).length;
          var max = cfg.max_custom || 12;
          body.appendChild(el("h3", "rail-ed-sub", "Criar o seu"));
          var chips = el("div", "rail-ed-chips");
          KINDS.forEach(function (k) {
            chips.appendChild(btnEl("Criar widget " + k[1], "+ " + k[1], "wx-chip", customCount >= max, function () {
              busy = true; errEl.textContent = ""; render("");
              window.DriqyMine.create(k[0]).then(function (w) {
                busy = false; byId[w.id] = w; lastCreated = w.id; active.push(w.id); render("");
              }).catch(function (e) { busy = false; render(""); errEl.textContent = (e && e.message) || "Não foi possível criar."; });
            }, "new:" + k[0]));
          });
          body.appendChild(chips);
          if (customCount >= max) body.appendChild(el("p", "hint", "Limite de " + max + " widgets seus."));
        }
        body.appendChild(errEl);
        var actions = el("div", "rail-ed-actions");
        var reset = btnEl("Restaurar padrão", "Restaurar", "rail-ed-link", false, function () {
          active = all.map(function (w) { return w.id; }); off = []; render("");
        }, "reset");
        var cancel = btnEl("Cancelar edição", "Cancelar", "rail-ed-link", false, finish.bind(null, null), "cancel");
        var ok = btnEl("Concluir edição", busy ? "Salvando…" : "Concluir", "btn rail-ed-ok", false, save, "ok");
        actions.appendChild(reset); actions.appendChild(cancel); actions.appendChild(ok);
        body.appendChild(actions);
        if (focusKey) {
          var f = body.querySelector('[data-k="' + focusKey.replace(/"/g, "") + '"]');
          if (f && !f.disabled) f.focus();
        }
      }

      function onKey(e) { if (e.key === "Escape" && !busy) finish(null); }
      document.addEventListener("keydown", onKey);

      function finish(prefs) {
        document.removeEventListener("keydown", onKey);
        done(prefs);
        if (lastCreated) window.DriqyRail.showId(lastCreated);
      }

      function save() {
        if (JSON.stringify([active, off]) === startJson) { finish(null); return; }
        busy = true; errEl.textContent = ""; render("ok");
        var next = {
          rail_hidden: !!p.rail_hidden, suggest: p.suggest !== false, suggest_first: !!p.suggest_first,
          order: active.concat(off), disabled: off.slice()
        };
        fetch(url, {
          method: "POST", credentials: "same-origin",
          headers: { "Content-Type": "application/json", "X-Requested-With": "fetch", Accept: "application/json" },
          body: JSON.stringify(next)
        }).then(function (r) {
          if (!r.ok) throw new Error("http");
          return r.json();
        }).then(function (j) {
          finish((j && j.prefs) || next);
        }).catch(function () {
          busy = false; render("ok");
          errEl.textContent = "Não foi possível salvar agora. Tente de novo.";
        });
      }

      render("");
    });
  }

  btn.addEventListener("click", open);
})();
