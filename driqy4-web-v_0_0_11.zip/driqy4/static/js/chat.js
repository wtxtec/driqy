(function () {
  const scriptTag = document.currentScript;
  const POLL_MS = 4000;
  const INBOX_POLL_MS = 5000;

  function setBadge(el, count) {
    if (!el) return;
    if (count > 0) {
      el.textContent = count > 99 ? "99+" : String(count);
      el.hidden = false;
    } else {
      el.hidden = true;
    }
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  document.addEventListener("DOMContentLoaded", () => {
    const countUrl = scriptTag && scriptTag.dataset.chatCountUrl;

    // Mesma ideia do notifications.js: detecta quando a contagem de não lidas
    // sobe para tocar o aviso sonoro em qualquer página, não só dentro da
    // conversa aberta.
    let lastUnreadCount = null;

    function pollBadge() {
      if (!countUrl) return;
      fetch(countUrl, { headers: { "X-Requested-With": "fetch" } })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (!data) return;
          setBadge(document.getElementById("chat-badge"), data.unread);
          setBadge(document.getElementById("chat-badge-sidebar"), data.unread);
          setBadge(document.getElementById("chat-badge-bottomnav"), data.unread);
          setBadge(document.getElementById("chat-badge-pingtab"), data.unread);
          if (lastUnreadCount !== null && data.unread > lastUnreadCount && window.driqySettings) {
            window.driqySettings.playMessageSound();
          }
          lastUnreadCount = data.unread;
        })
        .catch(() => {});
    }

    // Fase 9: com o tempo real ligado o polling vira rede de segurança (a cada ~30 s)
    const live = window.driqyLive;
    let badgeTick = 0;
    if (countUrl) {
      pollBadge();
      setInterval(() => { if (!live || !live.connected() || ++badgeTick % 6 === 0) pollBadge(); }, POLL_MS);
      if (live) live.on(["message", "read_self", "ready", "resync"], pollBadge);
    }

    // ---------- Thread de conversa (mensagens em tempo real) ----------
    const threadEl = document.getElementById("chat-thread");
    if (threadEl) {
      const pollUrl = threadEl.dataset.pollUrl;
      const sendUrl = threadEl.dataset.sendUrl;
      const form = document.getElementById("chat-form");
      const input = document.getElementById("chat-input");
      let lastId = parseInt(threadEl.dataset.lastId || "0", 10);

      function scrollToBottom() {
        threadEl.scrollTop = threadEl.scrollHeight;
      }
      scrollToBottom();

      function bubbleHtml(m) {
        return (
          '<div class="chat-bubble-row ' + (m.mine ? "mine" : "") + '" data-msg-id="' + m.id + '">' +
          '<div class="chat-bubble">' + escapeHtml(m.content) + '</div>' +
          '<div class="chat-bubble-meta">' + m.created_at + '</div>' +
          '</div>'
        );
      }

      function pollMessages() {
        fetch(pollUrl + "?since_id=" + lastId, { headers: { "X-Requested-With": "fetch" } })
          .then((res) => (res.ok ? res.json() : null))
          .then((data) => {
            if (!data || !data.messages || !data.messages.length) return;
            const wasNearBottom = threadEl.scrollHeight - threadEl.scrollTop - threadEl.clientHeight < 120;
            let receivedNew = false;
            data.messages.forEach((m) => {
              if (m.id > lastId) lastId = m.id;
              if (!m.mine) receivedNew = true;
              threadEl.insertAdjacentHTML("beforeend", bubbleHtml(m));
            });
            if (wasNearBottom) scrollToBottom();
            if (receivedNew && window.driqySettings) window.driqySettings.playMessageSound();
          })
          .catch(() => {});
      }

      if (pollUrl) setInterval(pollMessages, POLL_MS);

      if (form && input && sendUrl) {
        form.addEventListener("submit", (event) => {
          event.preventDefault();
          const content = input.value.trim();
          if (!content) return;
          input.disabled = true;
          fetch(sendUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "X-Requested-With": "fetch",
            },
            body: "content=" + encodeURIComponent(content),
          })
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => {
              if (data && data.message) {
                lastId = Math.max(lastId, data.message.id);
                threadEl.insertAdjacentHTML("beforeend", bubbleHtml(data.message));
                scrollToBottom();
                input.value = "";
              }
            })
            .catch(() => {})
            .finally(() => {
              input.disabled = false;
              input.focus();
            });
        });
      }
    }

    // ---------- Caixa de entrada: prévias e contadores ao vivo ----------
    const inboxList = document.getElementById("chat-inbox-list");
    if (inboxList) {
      const updatesUrl = inboxList.dataset.updatesUrl;
      if (updatesUrl) {
        const refreshInbox = () => {
          fetch(updatesUrl, { headers: { "X-Requested-With": "fetch" } })
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => {
              if (!data) return;
              const conversations = data.conversations || [];

              // Fase 10: arquivadas (contador/atalho) e linhas que saíram da lista (arquivou, apagou)
              const archLink = document.getElementById("chat-archived-link");
              if (archLink && typeof data.archived_count === "number") {
                const cnt = document.getElementById("chat-archived-count");
                if (cnt) cnt.textContent = String(data.archived_count);
                archLink.hidden = data.archived_count === 0;
              }
              const keep = new Set(conversations.map((c) => String(c.partner_id)));
              inboxList.querySelectorAll("[data-partner-id]").forEach((row) => {
                if (!keep.has(row.dataset.partnerId)) row.remove();
              });
              if (!conversations.length) return;

              const emptyState = document.getElementById("chat-inbox-empty-state");
              if (emptyState) emptyState.remove();

              const template = document.createElement("template");
              // `conversations` já vem ordenada (mais recente primeiro): troca só as
              // linhas que mudaram (data-sig) e mantém a ordem do servidor.
              let cursor = inboxList.firstElementChild;
              conversations.forEach((c) => {
                let row = inboxList.querySelector('[data-partner-id="' + c.partner_id + '"]');
                if (c.html) {
                  template.innerHTML = c.html.trim();
                  const fresh = template.content.firstElementChild;
                  if (fresh && (!row || row.dataset.sig !== fresh.dataset.sig)) {
                    if (row) row.replaceWith(fresh); else inboxList.insertBefore(fresh, cursor);
                    row = fresh;
                  }
                }
                if (!row) return;
                if (row !== cursor) inboxList.insertBefore(row, cursor);
                else cursor = cursor.nextElementSibling;
              });
            })
            .catch(() => {});
        };
        // ---------- Fase 10: menu da conversa (fixar / silenciar / arquivar) ----------
        const prefsRoot = inboxList.dataset.prefsRoot || "";
        let menuEl = null;
        const closeMenu = () => { if (menuEl) { menuEl.remove(); menuEl = null; } };
        const toast = (msg) => {
          const t = document.createElement("div");
          t.className = "chat-toast"; t.setAttribute("role", "status"); t.textContent = msg;
          document.body.appendChild(t);
          setTimeout(() => t.remove(), 3200);
        };
        const putPrefs = (username, body) =>
          fetch(prefsRoot + "/" + encodeURIComponent(username) + "/prefs", {
            method: "PUT", credentials: "same-origin",
            headers: { "Content-Type": "application/json", "X-Requested-With": "fetch" },
            body: JSON.stringify(body),
          }).then((r) => r.json().then((j) => ({ ok: r.ok, j: j })))
            .then((res) => { if (!res.ok) toast((res.j && res.j.error) || "Não foi possível salvar."); refreshInbox(); })
            .catch(() => toast("Sem conexão. Tente de novo."));
        const openMenu = (row, x, y) => {
          closeMenu();
          const u = row.dataset.username;
          const pinned = row.dataset.pinned === "1", muted = row.dataset.muted === "1", arch = row.dataset.archived === "1";
          const items = [];
          if (!arch) items.push([pinned ? "Desafixar" : "Fixar no topo", { pinned: !pinned }]);
          items.push([muted ? "Reativar notificações" : "Silenciar", { muted: !muted }]);
          items.push([arch ? "Desarquivar" : "Arquivar", { archived: !arch }]);
          menuEl = document.createElement("div");
          menuEl.className = "chat-conv-menu"; menuEl.setAttribute("role", "menu");
          items.forEach((it) => {
            const b = document.createElement("button");
            b.type = "button"; b.setAttribute("role", "menuitem"); b.textContent = it[0];
            b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); closeMenu(); putPrefs(u, it[1]); });
            menuEl.appendChild(b);
          });
          document.body.appendChild(menuEl);
          const w = menuEl.offsetWidth, h = menuEl.offsetHeight;
          menuEl.style.left = Math.max(8, Math.min(x, window.innerWidth - w - 8)) + "px";
          menuEl.style.top = Math.max(8, Math.min(y, window.innerHeight - h - 8)) + "px";
          const first = menuEl.querySelector("button"); if (first) first.focus();
        };
        inboxList.addEventListener("click", (e) => {
          const btn = e.target.closest(".conv-menu-btn");
          if (!btn) return;
          e.preventDefault(); e.stopPropagation();       // a linha é um <a>: não abrir a conversa
          const r = btn.getBoundingClientRect();
          openMenu(btn.closest(".chat-inbox-row"), r.left - 120, r.bottom + 4);
        });
        inboxList.addEventListener("contextmenu", (e) => {
          const row = e.target.closest(".chat-inbox-row");
          if (!row) return;
          e.preventDefault(); openMenu(row, e.clientX, e.clientY);
        });
        let pressTimer = null, pressed = false;
        inboxList.addEventListener("touchstart", (e) => {
          const row = e.target.closest(".chat-inbox-row");
          if (!row || e.touches.length !== 1) return;
          const t = e.touches[0]; pressed = false;
          pressTimer = setTimeout(() => { pressed = true; openMenu(row, t.clientX, t.clientY); }, 520);
        }, { passive: true });
        ["touchend", "touchmove", "touchcancel"].forEach((ev) =>
          inboxList.addEventListener(ev, (e) => { clearTimeout(pressTimer); if (ev === "touchend" && pressed) { e.preventDefault(); pressed = false; } }));
        document.addEventListener("click", (e) => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); });
        document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); });
        window.addEventListener("scroll", closeMenu, { passive: true });

        const privacy = document.getElementById("chat-privacy-toggle");
        if (privacy) {
          privacy.addEventListener("change", () => {
            const want = privacy.checked;
            fetch(privacy.dataset.url, {
              method: "PUT", credentials: "same-origin",
              headers: { "Content-Type": "application/json", "X-Requested-With": "fetch" },
              body: JSON.stringify({ show_presence: want }),
            }).then((r) => { if (!r.ok) throw new Error(); refreshInbox(); })
              .catch(() => { privacy.checked = !want; toast("Não foi possível salvar."); });
          });
        }

        let inboxTick = 0, inboxTimer = null;
        setInterval(() => { if (!live || !live.connected() || ++inboxTick % 6 === 0) refreshInbox(); }, INBOX_POLL_MS);
        if (live) {
          live.on(["message", "update", "read", "read_self", "delivered", "ready", "resync", "prefs", "presence"], () => {
            clearTimeout(inboxTimer);
            inboxTimer = setTimeout(refreshInbox, 150);
          });
        }
      }
    }
  });
})();
