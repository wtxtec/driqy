(function () {
  const THEME_KEY = "driqy-theme";
  const SOUND_KEY = "driqy-notif-sound";
  const PANEL_KEY = "driqy-notif-panel";
  const CHOICE_KEY = "driqy-msg-sound-choice"; // padrao | ding | pop
  const VOLUME_KEY = "driqy-msg-volume";       // 0..100
  const CHOICES = ["padrao", "ding", "pop"];

  function applyTheme(key) {
    document.documentElement.setAttribute("data-theme", key);
    try { localStorage.setItem(THEME_KEY, key); } catch (e) {}
    document.querySelectorAll(".theme-option").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.themeKey === key);
    });
  }

  function readBool(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw === null ? fallback : raw === "1";
    } catch (e) {
      return fallback;
    }
  }

  function writeBool(key, value) {
    try { localStorage.setItem(key, value ? "1" : "0"); } catch (e) {}
  }

  // Um único AudioContext reaproveitado — criar um novo a cada aviso faz o
  // navegador aplicar a política de autoplay e suspender o contexto sempre
  // que a chamada não vier de um gesto do usuário (como acontece durante o
  // polling em segundo plano), silenciando o som "em tempo real".
  let audioCtx = null;
  let messageAudio = null; // <audio> do som de mensagem (criado no 1º uso)
  function getAudioContext() {
    if (!audioCtx) {
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (e) {
        return null;
      }
    }
    return audioCtx;
  }

  // Qualquer interação do usuário destrava/retoma o contexto, para que os
  // avisos futuros disparados pelo polling automático já toquem sem precisar
  // de um novo gesto. Também tentamos retomar ao voltar para a aba, já que
  // alguns navegadores suspendem o contexto quando a página fica em segundo
  // plano por um tempo.
  let audioUnlocked = false;
  function unlockAudioContext() {
    const ctx = getAudioContext();
    if (!ctx) return;
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    if (audioUnlocked) return;
    // iOS Safari mais antigo não considera o contexto destravado só com
    // resume(); é preciso tocar um buffer de verdade dentro do próprio
    // gesto do toque. Isso é silencioso (1 amostra) e só precisa rodar 1x.
    try {
      const buffer = ctx.createBuffer(1, 1, 22050);
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.start(0);
      audioUnlocked = true;
    } catch (e) {}
  }
  ["pointerdown", "keydown", "touchstart"].forEach((evt) => {
    document.addEventListener(evt, unlockAudioContext, { passive: true });
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") unlockAudioContext();
  });
  window.addEventListener("focus", unlockAudioContext);
  // Cria o contexto assim que possível (em vez de só no primeiro aviso), para
  // que ele já esteja pronto — e eventualmente destravado — quando a primeira
  // notificação em tempo real chegar.
  getAudioContext();

  // Evita "bipes" duplicados quando duas fontes (por exemplo o contador do
  // sino e a lista de notificações em tempo real) disparam o aviso quase ao
  // mesmo tempo para o mesmo evento.
  let lastPlayedAt = 0;
  const MIN_INTERVAL_MS = 400;

  // Exposto para notifications.js / chat.js consultarem as preferências do usuário.
  window.driqySettings = {
    soundEnabled: () => readBool(SOUND_KEY, false),
    panelEnabled: () => readBool(PANEL_KEY, true),
    playNotifSound: function () {
      if (!this.soundEnabled()) return;
      const now = Date.now();
      if (now - lastPlayedAt < MIN_INTERVAL_MS) return;
      lastPlayedAt = now;
      const ctx = getAudioContext();
      if (!ctx) return;
      const tone = (freq, startOffset, duration, peakGain) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const startTime = ctx.currentTime + startOffset;
        osc.type = "sine";
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.0001, startTime);
        gain.gain.exponentialRampToValueAtTime(peakGain, startTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
        osc.connect(gain).connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + duration + 0.02);
      };
      // Pequeno "ding" de duas notas (sobe de tom), mais agradável e mais
      // fácil de notar do que um bipe único.
      const beep = () => {
        try {
          tone(660, 0, 0.16, 0.1);
          tone(880, 0.1, 0.22, 0.11);
        } catch (e) {}
      };
      if (ctx.state === "suspended") {
        ctx.resume().then(beep).catch(() => {});
      } else {
        beep();
      }
    },
    // Mensagens: som escolhido e volume (Configurações → Notificações e sons).
    messageChoice: () => {
      try { const v = localStorage.getItem(CHOICE_KEY); return CHOICES.indexOf(v) !== -1 ? v : "padrao"; } catch (e) { return "padrao"; }
    },
    messageVolume: () => {
      try {
        const n = parseInt(localStorage.getItem(VOLUME_KEY), 10);
        return isNaN(n) ? 1 : Math.min(100, Math.max(0, n)) / 100;
      } catch (e) { return 1; }
    },
    // Toca uma opção agora (prévia ao escolher): ignora o interruptor de som e o intervalo mínimo.
    previewMessageSound: function (choice) {
      this._playChoice(choice || this.messageChoice());
    },
    _playChoice: function (choice) {
      const vol = this.messageVolume();
      if (vol <= 0) return;
      if (choice === "ding") return this._playDing(vol);
      if (choice === "pop") return this._playMessageFallback(vol);
      try {
        if (!messageAudio) {
          messageAudio = new Audio("/static/sounds/message.mp3");
          messageAudio.preload = "auto";
        }
        messageAudio.volume = vol;
        messageAudio.currentTime = 0;
        const playing = messageAudio.play();
        if (playing && playing.catch) playing.catch(() => this._playMessageFallback(vol));
        return;
      } catch (e) {}
      this._playMessageFallback(vol);
    },
    _playDing: function (vol) {
      const ctx = getAudioContext();
      if (!ctx) return;
      const tone = (freq, startOffset, duration, peakGain) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const startTime = ctx.currentTime + startOffset;
        osc.type = "sine";
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.0001, startTime);
        gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, peakGain * vol), startTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
        osc.connect(gain).connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + duration + 0.02);
      };
      const beep = () => { try { tone(660, 0, 0.16, 0.2); tone(880, 0.1, 0.22, 0.22); } catch (e) {} };
      if (ctx.state === "suspended") ctx.resume().then(beep).catch(() => {}); else beep();
    },

    // Som separado para mensagens de chat: dois "pops" curtos e graves,
    // pra soar diferente do "ding" de notificações e dar pra distinguir de
    // ouvido qual tipo de aviso chegou sem olhar pra tela.
    playMessageSound: function () {
      if (!this.soundEnabled()) return;
      const now = Date.now();
      if (now - lastPlayedAt < MIN_INTERVAL_MS) return;
      lastPlayedAt = now;
      this._playChoice(this.messageChoice());
    },

    _playMessageFallback: function (vol) {
      if (typeof vol !== "number") vol = this.messageVolume();
      const ctx = getAudioContext();
      if (!ctx) return;
      const pop = (freq, startOffset, duration, peakGain) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const startTime = ctx.currentTime + startOffset;
        osc.type = "triangle";
        osc.frequency.setValueAtTime(freq, startTime);
        osc.frequency.exponentialRampToValueAtTime(freq * 0.82, startTime + duration);
        gain.gain.setValueAtTime(0.0001, startTime);
        gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, peakGain * vol), startTime + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
        osc.connect(gain).connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + duration + 0.02);
      };
      const beep = () => {
        try {
          pop(520, 0, 0.1, 0.24);
          pop(520, 0.11, 0.13, 0.24);
        } catch (e) {}
      };
      if (ctx.state === "suspended") {
        ctx.resume().then(beep).catch(() => {});
      } else {
        beep();
      }
    },
  };

  document.addEventListener("DOMContentLoaded", () => {
    const current = document.documentElement.getAttribute("data-theme") || "dark";
    applyTheme(current);

    document.querySelectorAll(".theme-option").forEach((btn) => {
      btn.addEventListener("click", () => applyTheme(btn.dataset.themeKey));
    });

    // ---------- Painel de configurações (modal) ----------
    const openBtn = document.getElementById("settings-open-btn");
    const modal = document.getElementById("settings-modal");
    const overlay = document.getElementById("settings-overlay");
    const closeBtn = document.getElementById("settings-close");
    const soundToggle = document.getElementById("setting-sound");
    const panelToggle = document.getElementById("setting-panel");

    if (soundToggle) soundToggle.checked = readBool(SOUND_KEY, false);
    if (panelToggle) panelToggle.checked = readBool(PANEL_KEY, true);

    if (soundToggle) {
      soundToggle.addEventListener("change", () => {
        writeBool(SOUND_KEY, soundToggle.checked);
        if (soundToggle.checked) window.driqySettings.playNotifSound();
      });
    }
    if (panelToggle) {
      panelToggle.addEventListener("change", () => writeBool(PANEL_KEY, panelToggle.checked));
    }

    // ---------- Mensagens: som escolhido + volume (painel Configurações) ----------
    const soundOpts = document.querySelectorAll(".ping-sound-opt");
    const volume = document.getElementById("setting-volume");
    function markSound() {
      const cur = window.driqySettings.messageChoice();
      soundOpts.forEach((b) => {
        const on = b.dataset.sound === cur;
        b.classList.toggle("active", on);
        b.setAttribute("aria-checked", on ? "true" : "false");
      });
    }
    if (soundOpts.length) {
      markSound();
      soundOpts.forEach((b) => b.addEventListener("click", () => {
        try { localStorage.setItem(CHOICE_KEY, b.dataset.sound); } catch (e) {}
        markSound();
        window.driqySettings.previewMessageSound(b.dataset.sound);
      }));
    }
    if (volume) {
      volume.value = String(Math.round(window.driqySettings.messageVolume() * 100));
      volume.addEventListener("input", () => { try { localStorage.setItem(VOLUME_KEY, volume.value); } catch (e) {} });
      volume.addEventListener("change", () => window.driqySettings.previewMessageSound());
    }

    if (openBtn && modal && overlay) {
      const openModal = () => {
        modal.hidden = false;
        overlay.hidden = false;
        document.body.style.overflow = "hidden";
        // fecha a sidebar por trás, se estiver aberta
        const sidebar = document.getElementById("sidebar");
        const sidebarOverlay = document.getElementById("sidebar-overlay");
        if (sidebar) sidebar.classList.remove("open");
        if (sidebarOverlay) sidebarOverlay.classList.remove("open");
      };
      const closeModal = () => {
        modal.hidden = true;
        overlay.hidden = true;
        document.body.style.overflow = "";
      };

      openBtn.addEventListener("click", openModal);
      overlay.addEventListener("click", closeModal);
      if (closeBtn) closeBtn.addEventListener("click", closeModal);
      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && !modal.hidden) closeModal();
      });
    }
  });
})();
