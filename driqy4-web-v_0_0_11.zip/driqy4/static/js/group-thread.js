/* Mensagens parte 4 — conversa de grupo (só texto) + painel "Dados do grupo" (estilo Telegram).
 * Página: messages_group.html (#gw). API: /api/v1/groups/<id>… (parte 3). Tempo real: evento SSE `group`.
 * Tudo com textContent (nada de innerHTML com dados de usuário). */
(function () {
  const root = document.getElementById("gw");
  if (!root) return;

  const GID = root.dataset.groupId;
  const API = root.dataset.api.replace(/\/?$/, "/") + GID;
  const MY_ID = Number(root.dataset.myId);
  const INBOX = root.dataset.inboxUrl;
  const SEARCH = root.dataset.searchUrl;
  const HDR = { "X-Requested-With": "fetch" };
  const JSON_HDR = { "Content-Type": "application/json", "X-Requested-With": "fetch" };

  const $ = (id) => document.getElementById(id);
  const listEl = $("gw-list"), form = $("gw-form"), input = $("gw-input"), sendBtn = $("gw-send");
  const jumpBtn = $("gw-jump"), typingEl = $("gw-typing"), subEl = $("gw-head-sub");
  const replyBar = $("gw-replybar");
  const infoPanel = $("gw-info"), infoBody = $("gw-info-body");

  let group = null;            // detalhes + membros
  let msgs = [];               // mensagens (ordem crescente de id), inclui as "enviando"
  let hasMore = false;
  let replyTo = null;          // mensagem sendo respondida
  let editing = null;          // mensagem sendo editada
  let tempSeq = 0;
  let typingTimer = null, lastTypingSent = 0;
  const typingUsers = new Map();
  let destroyed = false;

  // ------------------------------------------------------------------ utilidades
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function pad(n) { return n < 10 ? "0" + n : String(n); }
  function clock(iso) { const d = new Date(iso); return isNaN(d) ? "" : pad(d.getHours()) + ":" + pad(d.getMinutes()); }
  function sameDay(a, b) { return a.toDateString() === b.toDateString(); }
  function dayLabel(d) {
    const now = new Date(), y = new Date(now); y.setDate(now.getDate() - 1);
    if (sameDay(d, now)) return "Hoje";
    if (sameDay(d, y)) return "Ontem";
    return pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear();
  }
  function colorFor(id) { return "hsl(" + ((id * 67) % 360) + ", 65%, 62%)"; }
  function isAdmin() { return group && (group.my_role === "owner" || group.my_role === "admin"); }
  function toast(t) {
    const n = el("div", "cw-toast", t);
    document.body.appendChild(n);
    setTimeout(() => n.remove(), 2600);
  }
  function api(path, opts) {
    opts = opts || {};
    const o = { credentials: "same-origin", method: opts.method || "GET", headers: opts.form ? HDR : (opts.body ? JSON_HDR : HDR) };
    if (opts.form) o.body = opts.form;
    else if (opts.body) o.body = JSON.stringify(opts.body);
    return fetch(API + path, o).then((r) => r.json().catch(() => ({})).then((j) => {
      if (!r.ok) { const e = new Error(j.error || "Algo deu errado."); e.status = r.status; throw e; }
      return j;
    }));
  }
  function nearBottom() { return listEl.scrollHeight - listEl.scrollTop - listEl.clientHeight < 120; }
  function scrollBottom() { listEl.scrollTop = listEl.scrollHeight; }
  function lastRealId() { for (let i = msgs.length - 1; i >= 0; i--) if (msgs[i].id > 0) return msgs[i].id; return 0; }

  // ------------------------------------------------------------------ cabeçalho
  function renderHeader() {
    if (!group) return;
    $("gw-head-name").textContent = group.name;
    document.title = group.name + " — Mensagens";
    const av = $("gw-head-av");
    av.replaceChildren();
    if (group.avatar_url) { const im = el("img", "avatar-img"); im.src = group.avatar_url; im.alt = ""; av.appendChild(im); }
    else av.textContent = (group.name || "?").charAt(0).toUpperCase();
    updateSub();
  }
  function updateSub() {
    if (!group) return;
    if (typingUsers.size) {
      const names = Array.from(typingUsers.values());
      subEl.textContent = (names.length === 1 ? names[0] + " está digitando…" : names.length + " pessoas digitando…");
      return;
    }
    subEl.textContent = group.member_count + (group.member_count === 1 ? " participante" : " participantes");
  }

  // ------------------------------------------------------------------ mensagens
  function buildSystem(m) {
    const d = el("div", "cw-day gw-system");
    d.appendChild(el("span", null, m.content));
    return d;
  }
  function buildMessage(m, grouped) {
    const row = el("div", "cw-row" + (m.mine ? " mine" : "") + (grouped ? " grouped" : ""));
    if (m.id > 0) row.dataset.msgId = m.id;
    const bubble = el("div", "cw-bubble" + (m.deleted ? " is-deleted" : ""));
    if (m.deleted) {
      bubble.appendChild(el("span", "cw-deleted", "🚫 Mensagem apagada"));
    } else {
      if (!m.mine && !grouped && m.sender) {
        const who = el("div", "gw-sender", m.sender.display_name);
        who.style.color = colorFor(m.sender.id);
        bubble.appendChild(who);
      }
      if (m.reply_to) {
        const q = el("div", "cw-reply");
        q.appendChild(el("strong", "cw-reply-who", m.reply_to.sender_name || "Mensagem"));
        q.appendChild(el("span", "cw-reply-txt", m.reply_to.deleted ? "Mensagem apagada" : (m.reply_to.preview || "")));
        q.tabIndex = 0; q.setAttribute("role", "button");
        q.addEventListener("click", (e) => { e.stopPropagation(); jumpTo(m.reply_to.id); });
        bubble.appendChild(q);
      }
      bubble.appendChild(el("div", "cw-text", m.content));
      const meta = el("div", "cw-meta");
      if (m.edited) meta.appendChild(el("span", null, "editada"));
      meta.appendChild(el("span", null, clock(m.created_at)));
      if (m._state === "sending") meta.appendChild(el("span", "cw-ticks", "🕓"));
      if (m._state === "failed") meta.appendChild(el("span", "cw-ticks", "⚠️"));
      bubble.appendChild(meta);
      bubble.classList.add("cw-inline-meta"); // hora na mesma linha do fim do texto (estilo Telegram)
      if (m._state === "failed") { bubble.classList.add("is-failed"); bubble.addEventListener("click", () => retry(m)); }
      else if (m.id > 0) {
        bubble.addEventListener("contextmenu", (e) => { e.preventDefault(); openMenu(m, e.clientX, e.clientY); });
        bubble.addEventListener("click", (e) => { if (!window.getSelection().toString()) openMenu(m, e.clientX, e.clientY); });
      }
    }
    const holder = el("div", "cw-holder");
    holder.appendChild(bubble);
    row.appendChild(holder);
    return row;
  }
  function render(forceBottom) {
    const stick = forceBottom || nearBottom();
    const nodes = [];
    if (hasMore) {
      const more = el("button", "btn-outline gw-more", "Carregar mensagens anteriores");
      more.type = "button"; more.addEventListener("click", loadOlder);
      nodes.push(more);
    }
    if (!msgs.length) nodes.push(el("p", "hint cw-empty", "Nenhuma mensagem ainda. Diga oi! 👋"));
    let prev = null;
    msgs.forEach((m) => {
      const d = new Date(m.created_at);
      const newDay = !prev || !sameDay(new Date(prev.created_at), d);
      if (newDay) { const sep = el("div", "cw-day"); sep.appendChild(el("span", null, dayLabel(d))); nodes.push(sep); }
      if (m.kind === "system") { nodes.push(buildSystem(m)); prev = null; return; }
      const sameSender = prev && prev.kind !== "system" && prev.sender && m.sender && prev.sender.id === m.sender.id;
      const grouped = !!prev && !newDay && sameSender && (d - new Date(prev.created_at)) < 300000;
      nodes.push(buildMessage(m, grouped));
      prev = m;
    });
    listEl.replaceChildren.apply(listEl, nodes);
    if (stick) scrollBottom();
    jumpBtn.hidden = nearBottom();
  }
  function jumpTo(id) {
    const row = listEl.querySelector('[data-msg-id="' + id + '"]');
    if (!row) { toast("Mensagem antiga: carregue as anteriores."); return; }
    row.scrollIntoView({ block: "center", behavior: "smooth" });
    row.classList.add("cw-search-current");
    setTimeout(() => row.classList.remove("cw-search-current"), 1400);
  }
  function replaceMsg(m) {
    const i = msgs.findIndex((x) => x.id === m.id || (m.client_id && x.client_id === m.client_id));
    if (i >= 0) msgs[i] = m; else msgs.push(m);
    msgs.sort((a, b) => (a.id > 0 && b.id > 0 ? a.id - b.id : 0));
  }

  // ------------------------------------------------------------------ carregar
  function loadGroup() {
    return api("").then((d) => { group = d.group; renderHeader(); if (!infoPanel.hidden) renderInfo(); });
  }
  function loadInitial() {
    return Promise.all([loadGroup(), api("/messages?limit=50")]).then((r) => {
      msgs = r[1].messages; hasMore = r[1].has_more;
      render(true); markRead();
    });
  }
  function loadOlder() {
    const first = msgs.find((m) => m.id > 0);
    if (!first) return;
    const prevH = listEl.scrollHeight;
    api("/messages?limit=50&before=" + first.id).then((d) => {
      msgs = d.messages.concat(msgs); hasMore = d.has_more;
      render(false);
      listEl.scrollTop += listEl.scrollHeight - prevH;
    }).catch((e) => toast(e.message));
  }
  function loadNew() {
    const after = lastRealId();
    return api("/messages?limit=100&after=" + after).then((d) => {
      const stick = nearBottom();
      d.messages.forEach(replaceMsg);
      render(stick);
      if (d.messages.length) markRead();
      if (d.messages.length && !stick && d.messages.some((m) => !m.mine)) jumpBtn.hidden = false;
    }).catch(handleGone);
  }
  function refreshEdits() { // editar/apagar: rebusca a janela atual
    const first = msgs.find((m) => m.id > 0);
    if (!first) return Promise.resolve();
    return api("/messages?limit=200&after=" + (first.id - 1)).then((d) => {
      d.messages.forEach(replaceMsg); render(false);
    }).catch(handleGone);
  }
  function handleGone(e) {
    if (e && e.status === 404 && !destroyed) { toast("Você não faz parte deste grupo."); setTimeout(() => { location.href = INBOX; }, 900); }
  }
  let readTimer = null;
  function markRead() {
    clearTimeout(readTimer);
    readTimer = setTimeout(() => {
      const up = lastRealId();
      if (up && document.visibilityState !== "hidden") api("/read", { method: "POST", body: { up_to_id: up } }).then(() => { if (window.driqyGroups) window.driqyGroups.refresh(); }).catch(() => {});
    }, 250);
  }

  // ------------------------------------------------------------------ enviar / editar / apagar
  function autosize() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 140) + "px"; sendBtn.disabled = !input.value.trim(); }
  function setReply(m) {
    replyTo = m; editing = null;
    if (!m) { replyBar.hidden = true; return; }
    $("gw-replybar-who").textContent = m.mine ? "Você" : (m.sender ? m.sender.display_name : "");
    $("gw-replybar-txt").textContent = m.content.slice(0, 80);
    replyBar.hidden = false; input.focus();
  }
  function setEditing(m) {
    editing = m; replyTo = null;
    if (!m) { replyBar.hidden = true; return; }
    $("gw-replybar-who").textContent = "Editando";
    $("gw-replybar-txt").textContent = m.content.slice(0, 80);
    replyBar.hidden = false; input.value = m.content; autosize(); input.focus();
  }
  function cancelCompose() { const was = editing; setReply(null); setEditing(null); if (was) { input.value = ""; autosize(); } }
  $("gw-replybar-x").addEventListener("click", cancelCompose);

  function submit() {
    const text = input.value.trim();
    if (!text) return;
    if (editing) {
      const m = editing;
      api("/messages/" + m.id, { method: "PUT", body: { content: text } })
        .then((d) => { replaceMsg(d.message); render(false); })
        .catch((e) => toast(e.message));
      cancelCompose(); return;
    }
    const tmp = {
      id: -(++tempSeq), kind: "text", mine: true, content: text, client_id: "w" + Date.now().toString(36) + tempSeq,
      created_at: new Date().toISOString(), sender: { id: MY_ID }, reply_to: replyTo ? { id: replyTo.id, sender_name: replyTo.mine ? "Você" : (replyTo.sender ? replyTo.sender.display_name : ""), preview: replyTo.content.slice(0, 80) } : null,
      _state: "sending", _reply_id: replyTo ? replyTo.id : null,
    };
    msgs.push(tmp); input.value = ""; setReply(null); autosize(); render(true);
    deliver(tmp);
    stopTyping();
  }
  function deliver(tmp) {
    tmp._state = "sending";
    api("/messages", { method: "POST", body: { content: tmp.content, client_id: tmp.client_id, reply_to_id: tmp._reply_id || undefined } })
      .then((d) => {
        const i = msgs.findIndex((x) => x.client_id === tmp.client_id);
        const real = d.message;
        if (i >= 0) msgs.splice(i, 1);
        if (!msgs.some((x) => x.id === real.id)) msgs.push(real);
        msgs.sort((a, b) => (a.id > 0 && b.id > 0 ? a.id - b.id : 0));
        render(true);
      })
      .catch((e) => { tmp._state = "failed"; render(false); if (e.status === 404) handleGone(e); else toast(e.message); });
    render(false);
  }
  function retry(m) { deliver(m); }
  // ---- emojis (mesmo seletor do privado) ----
  const emojiBtn = $("gw-emoji-btn"), emojiPanel = $("gw-emoji-panel");
  const coarse = !!(window.matchMedia && window.matchMedia("(pointer: coarse)").matches);
  let emojiBuilt = false;
  function toggleEmoji(force) {
    if (!emojiBtn || !emojiPanel || !window.DriqyEmojiPicker) return;
    const open = force != null ? force : emojiPanel.hidden;
    if (open && !emojiBuilt) { emojiPanel.appendChild(window.DriqyEmojiPicker.build({ onPick: insertEmoji, onBackspace: backspaceInput })); emojiBuilt = true; }
    emojiPanel.hidden = !open;
    emojiBtn.classList.toggle("on", open);
    if (open && coarse) input.blur(); else if (!open && !coarse) input.focus();
  }
  function insertEmoji(e) {
    const s = input.selectionStart == null ? input.value.length : input.selectionStart;
    const end = input.selectionEnd == null ? s : input.selectionEnd;
    input.value = input.value.slice(0, s) + e + input.value.slice(end);
    input.setSelectionRange(s + e.length, s + e.length);
    autosize(); sendTyping();
    if (!coarse) input.focus();
  }
  function backspaceInput() {
    const s = input.selectionStart == null ? input.value.length : input.selectionStart;
    const end = input.selectionEnd == null ? s : input.selectionEnd;
    if (s !== end) { input.value = input.value.slice(0, s) + input.value.slice(end); input.setSelectionRange(s, s); }
    else if (s > 0) {
      const before = Array.from(input.value.slice(0, s));
      let cut = before.pop() || "";
      while (before.length && /^[\u200d\ufe0f\u{1F3FB}-\u{1F3FF}]$/u.test(cut.slice(0, 1)) && cut.length <= 2) { cut = before.pop() + cut; }
      const start = s - cut.length;
      input.value = input.value.slice(0, start) + input.value.slice(s); input.setSelectionRange(start, start);
    }
    autosize();
  }
  if (emojiBtn) emojiBtn.addEventListener("click", (e) => { e.stopPropagation(); toggleEmoji(); });
  document.addEventListener("click", (e) => {
    if (!emojiPanel || emojiPanel.hidden || coarse) return;
    if (emojiPanel.contains(e.target) || emojiBtn.contains(e.target)) return;
    toggleEmoji(false);
  });
  input.addEventListener("focus", () => { if (coarse && emojiPanel && !emojiPanel.hidden) toggleEmoji(false); });

  form.addEventListener("submit", (e) => { e.preventDefault(); submit(); });
  input.addEventListener("input", () => { autosize(); sendTyping(); });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); }
    else if (e.key === "Escape") cancelCompose();
  });

  function sendTyping() {
    if (!input.value.trim()) return;
    if (Date.now() - lastTypingSent > 3000) { lastTypingSent = Date.now(); api("/typing", { method: "POST", body: { state: "typing" } }).catch(() => {}); }
    clearTimeout(typingTimer); typingTimer = setTimeout(stopTyping, 4000);
  }
  function stopTyping() {
    if (!lastTypingSent) return;
    lastTypingSent = 0; clearTimeout(typingTimer);
    api("/typing", { method: "POST", body: { state: "stop" } }).catch(() => {});
  }

  // ------------------------------------------------------------------ menu da mensagem
  let menuEl = null;
  function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
  function openMenu(m, x, y) {
    closeMenu();
    const items = [["Responder", () => setReply(m)]];
    if (!m.deleted) items.push(["Copiar", () => { try { navigator.clipboard.writeText(m.content); toast("Copiado"); } catch (e) {} }]);
    if (m.mine && !m.deleted) items.push(["Editar", () => setEditing(m)]);
    if ((m.mine || isAdmin()) && !m.deleted) items.push(["Apagar", () => confirmBox("Apagar mensagem?", "Ela some para todos do grupo.", "Apagar", () => {
      api("/messages/" + m.id, { method: "DELETE" }).then((d) => { replaceMsg(d.message); render(false); }).catch((e) => toast(e.message));
    })]);
    menuEl = el("div", "chat-conv-menu gw-menu"); menuEl.setAttribute("role", "menu");
    items.forEach((it) => {
      const b = el("button", "chat-conv-menu-item", it[0]); b.type = "button"; b.setAttribute("role", "menuitem");
      b.addEventListener("click", (e) => { e.stopPropagation(); closeMenu(); it[1](); });
      menuEl.appendChild(b);
    });
    document.body.appendChild(menuEl);
    const w = menuEl.offsetWidth, h = menuEl.offsetHeight;
    menuEl.style.position = "fixed";
    menuEl.style.left = Math.max(8, Math.min(x, window.innerWidth - w - 8)) + "px";
    menuEl.style.top = Math.max(8, Math.min(y, window.innerHeight - h - 8)) + "px";
    menuEl.style.zIndex = 1200;
  }
  document.addEventListener("click", (e) => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); }, true);
  document.addEventListener("scroll", closeMenu, true);

  // ------------------------------------------------------------------ confirmação
  const conf = $("gw-confirm");
  let confirmCb = null;
  function confirmBox(title, text, yes, cb) {
    $("gw-confirm-title").textContent = title; $("gw-confirm-text").textContent = text;
    $("gw-confirm-yes").textContent = yes; confirmCb = cb; conf.hidden = false;
  }
  $("gw-confirm-no").addEventListener("click", () => { conf.hidden = true; confirmCb = null; });
  $("gw-confirm-yes").addEventListener("click", () => { const cb = confirmCb; conf.hidden = true; confirmCb = null; if (cb) cb(); });

  // ------------------------------------------------------------------ painel "Dados do grupo"
  function openInfo() { infoPanel.hidden = false; renderInfo(); loadGroup().catch(handleGone); }
  function closeInfo() { infoPanel.hidden = true; }
  $("gw-open-info").addEventListener("click", openInfo);
  $("gw-info-btn").addEventListener("click", openInfo);
  $("gw-info-close").addEventListener("click", closeInfo);
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (!conf.hidden) conf.hidden = true; else if (!infoPanel.hidden) closeInfo();
  });

  function row(icon, label, onClick, danger) {
    const b = el("button", "gw-info-row" + (danger ? " is-danger" : ""));
    b.type = "button";
    b.appendChild(el("span", "gw-info-ico", icon));
    b.appendChild(el("span", null, label));
    b.addEventListener("click", onClick);
    return b;
  }
  function personRow(u) {
    const r = el("div", "gw-member");
    const av = el("span", "avatar-dot");
    if (u.avatar_url) { const im = el("img", "avatar-img"); im.src = u.avatar_url; im.alt = ""; av.appendChild(im); }
    else av.textContent = (u.display_name || u.username || "?").charAt(0).toUpperCase();
    const txt = el("span", "gw-member-txt");
    txt.appendChild(el("strong", null, u.id === MY_ID ? "Você" : u.display_name));
    txt.appendChild(el("small", null, "@" + u.username));
    r.append(av, txt);
    if (u.role === "owner") r.appendChild(el("span", "gw-role", "dono"));
    else if (u.role === "admin") r.appendChild(el("span", "gw-role", "admin"));
    const me = group.my_role;
    const canRemove = u.id !== MY_ID && ((me === "owner" && u.role !== "owner") || (me === "admin" && u.role === "member"));
    if (me === "owner" && u.id !== MY_ID && u.role !== "owner") {
      const b = el("button", "gw-mini", u.role === "admin" ? "Tirar admin" : "Tornar admin"); b.type = "button";
      b.addEventListener("click", () => api("/members/" + encodeURIComponent(u.username), { method: "PUT", body: { role: u.role === "admin" ? "member" : "admin" } })
        .then((d) => { group = d.group; renderInfo(); }).catch((e) => toast(e.message)));
      r.appendChild(b);
    }
    if (canRemove) {
      const b = el("button", "gw-mini is-danger", "Remover"); b.type = "button";
      b.addEventListener("click", () => confirmBox("Remover " + u.display_name + "?", "A pessoa sai do grupo.", "Remover", () =>
        api("/members/" + encodeURIComponent(u.username), { method: "DELETE" }).then((d) => { group = d.group; renderHeader(); renderInfo(); }).catch((e) => toast(e.message))));
      r.appendChild(b);
    }
    return r;
  }
  function renderInfo() {
    if (!group) return;
    infoBody.replaceChildren();
    // topo: foto, nome, nº de participantes
    const top = el("div", "gw-info-top");
    const av = el("span", "avatar-dot gw-av gw-av-big");
    if (group.avatar_url) { const im = el("img", "avatar-img"); im.src = group.avatar_url; im.alt = ""; av.textContent = ""; av.appendChild(im); }
    else av.textContent = group.name.charAt(0).toUpperCase();
    top.appendChild(av);
    top.appendChild(el("h3", "gw-info-name", group.name));
    top.appendChild(el("p", "post-meta", group.member_count + (group.member_count === 1 ? " participante" : " participantes")));
    if (group.description) top.appendChild(el("p", "gw-info-desc", group.description));
    infoBody.appendChild(top);

    const actions = el("div", "gw-info-card");
    if (isAdmin()) {
      actions.appendChild(row("✏️", "Editar nome e descrição", () => editDialog()));
      actions.appendChild(row("🖼️", "Trocar foto do grupo", () => pickAvatar()));
      if (group.avatar_url) actions.appendChild(row("🗑️", "Remover foto", () => api("/avatar", { method: "DELETE" }).then((d) => { group = d.group; renderHeader(); renderInfo(); }).catch((e) => toast(e.message))));
    }
    const p = group.prefs;
    actions.appendChild(row(p.muted ? "🔔" : "🔕", p.muted ? "Reativar notificações" : "Silenciar notificações", () => setPref({ muted: !p.muted })));
    actions.appendChild(row("📌", p.pinned ? "Desafixar da lista" : "Fixar na lista", () => setPref({ pinned: !p.pinned })));
    actions.appendChild(row("🗄️", p.archived ? "Desarquivar" : "Arquivar", () => setPref({ archived: !p.archived })));
    infoBody.appendChild(actions);

    // membros
    const head = el("div", "gw-info-sec", "Participantes");
    infoBody.appendChild(head);
    if (isAdmin()) infoBody.appendChild(row("➕", "Adicionar participantes", () => addDialog()));
    const list = el("div", "gw-info-card gw-members");
    (group.members || []).forEach((u) => list.appendChild(personRow(u)));
    infoBody.appendChild(list);

    const danger = el("div", "gw-info-card");
    danger.appendChild(row("🚪", "Sair do grupo", () => confirmBox("Sair do grupo?", group.my_role === "owner" ? "Você é o dono: o grupo passa para outra pessoa." : "Você deixa de receber as mensagens.", "Sair", () =>
      api("/leave", { method: "POST" }).then(() => { location.href = INBOX; }).catch((e) => toast(e.message))), true));
    if (group.my_role === "owner") {
      danger.appendChild(row("⛔", "Apagar grupo", () => confirmBox("Apagar o grupo?", "Todas as mensagens somem para todo mundo. Não dá para desfazer.", "Apagar", () =>
        api("", { method: "DELETE" }).then(() => { location.href = INBOX; }).catch((e) => toast(e.message))), true));
    }
    infoBody.appendChild(danger);
  }
  function setPref(patch) {
    api("/prefs", { method: "PUT", body: patch })
      .then((d) => { group.prefs = d.prefs; renderInfo(); if (window.driqyGroups) window.driqyGroups.refresh(); if (patch.archived) { toast("Grupo arquivado"); } })
      .catch((e) => toast(e.message));
  }
  function pickAvatar() {
    const f = el("input"); f.type = "file"; f.accept = "image/*";
    f.addEventListener("change", () => {
      if (!f.files[0]) return;
      const fd = new FormData(); fd.append("file", f.files[0]);
      api("/avatar", { method: "POST", form: fd }).then((d) => { group = d.group; renderHeader(); renderInfo(); loadNew(); }).catch((e) => toast(e.message));
    });
    f.click();
  }

  // diálogo simples (nome/descrição) reaproveitando o modal de confirmação visual
  function dialog(title, fields, okLabel, onOk) {
    const wrap = el("div", "cw-modal"); wrap.setAttribute("role", "dialog"); wrap.setAttribute("aria-modal", "true");
    const card = el("div", "cw-modal-card");
    card.appendChild(el("h3", null, title));
    const inputs = fields.map((f) => {
      const i = el(f.area ? "textarea" : "input"); i.placeholder = f.label; i.value = f.value || ""; i.maxLength = f.max || 100;
      i.setAttribute("aria-label", f.label); if (f.area) i.rows = 3; card.appendChild(i); return i;
    });
    const err = el("p", "hint ping-group-msg"); err.hidden = true; card.appendChild(err);
    const act = el("div", "cw-modal-actions");
    const no = el("button", "btn-outline", "Cancelar"); no.type = "button";
    const ok = el("button", "btn", okLabel); ok.type = "button";
    act.append(no, ok); card.appendChild(act); wrap.appendChild(card); document.body.appendChild(wrap);
    inputs[0].focus();
    const close = () => wrap.remove();
    no.addEventListener("click", close);
    ok.addEventListener("click", () => {
      ok.disabled = true;
      Promise.resolve(onOk(inputs.map((i) => i.value.trim()))).then(close).catch((e) => { err.textContent = e.message; err.hidden = false; ok.disabled = false; });
    });
  }
  function editDialog() {
    dialog("Editar grupo", [{ label: "Nome do grupo", value: group.name, max: 60 }, { label: "Descrição (opcional)", value: group.description, max: 200, area: true }], "Salvar",
      (v) => api("", { method: "PUT", body: { name: v[0], description: v[1] } }).then((d) => { group = d.group; renderHeader(); renderInfo(); loadNew(); }));
  }
  function addDialog() {
    const picked = new Map();
    const wrap = el("div", "cw-modal"); wrap.setAttribute("role", "dialog"); wrap.setAttribute("aria-modal", "true");
    const card = el("div", "cw-modal-card");
    card.appendChild(el("h3", null, "Adicionar participantes"));
    const chips = el("div", "ping-group-chips"); card.appendChild(chips);
    const q = el("input"); q.type = "search"; q.placeholder = "Buscar pessoa"; q.setAttribute("aria-label", "Buscar pessoa"); card.appendChild(q);
    const res = el("div", "ping-new-results"); card.appendChild(res);
    const err = el("p", "hint ping-group-msg"); err.hidden = true; card.appendChild(err);
    const act = el("div", "cw-modal-actions");
    const no = el("button", "btn-outline", "Cancelar"); no.type = "button";
    const ok = el("button", "btn", "Adicionar"); ok.type = "button"; ok.disabled = true;
    act.append(no, ok); card.appendChild(act); wrap.appendChild(card); document.body.appendChild(wrap);
    q.focus();
    const existing = new Set((group.members || []).map((u) => u.username.toLowerCase()));
    function sync() {
      chips.replaceChildren();
      picked.forEach((u) => {
        const c = el("button", "ping-group-chip", u.display_name + " ✕"); c.type = "button";
        c.addEventListener("click", () => { picked.delete(u.username); sync(); }); chips.appendChild(c);
      });
      ok.disabled = picked.size === 0;
    }
    let t = null, seq = 0;
    q.addEventListener("input", () => {
      clearTimeout(t);
      const term = q.value.trim();
      if (!term) { res.replaceChildren(); return; }
      t = setTimeout(() => {
        const mine = ++seq;
        fetch(SEARCH + "?q=" + encodeURIComponent(term), { credentials: "same-origin" }).then((r) => r.json()).then((d) => {
          if (mine !== seq) return;
          res.replaceChildren();
          (d.users || []).filter((u) => !existing.has(u.username.toLowerCase())).forEach((u) => {
            const b = el("button", "ping-new-row"); b.type = "button";
            const av = el("span", "avatar-dot");
            if (u.avatar) { const im = el("img", "avatar-img"); im.src = u.avatar; im.alt = ""; av.appendChild(im); } else av.textContent = u.initial;
            b.append(av, el("span", null, u.display_name + " (@" + u.username + ")"));
            b.addEventListener("click", () => { picked.set(u.username, { username: u.username, display_name: u.display_name }); sync(); });
            res.appendChild(b);
          });
          if (!res.children.length) res.appendChild(el("p", "ping-search-empty", "Ninguém encontrado."));
        }).catch(() => {});
      }, 200);
    });
    const close = () => wrap.remove();
    no.addEventListener("click", close);
    ok.addEventListener("click", () => {
      ok.disabled = true;
      api("/members", { method: "POST", body: { usernames: Array.from(picked.keys()) } })
        .then((d) => { group = d.group; renderHeader(); renderInfo(); loadNew(); close(); })
        .catch((e) => { err.textContent = e.message; err.hidden = false; ok.disabled = false; });
    });
  }

  // ------------------------------------------------------------------ tempo real
  jumpBtn.addEventListener("click", () => { scrollBottom(); jumpBtn.hidden = true; });
  listEl.addEventListener("scroll", () => { jumpBtn.hidden = nearBottom(); }, { passive: true });

  const live = window.driqyLive;
  let liveTimer = null;
  function onGroup(d) {
    if (destroyed || String(d.group_id) !== String(GID)) return;
    if (d.kind === "typing") {
      if (d.state === "stop") typingUsers.delete(d.username);
      else { typingUsers.set(d.username, d.username); setTimeout(() => { typingUsers.delete(d.username); updateSub(); }, 5000); }
      updateSub(); return;
    }
    if (d.kind === "removed") { toast("Você saiu deste grupo."); setTimeout(() => { location.href = INBOX; }, 700); return; }
    clearTimeout(liveTimer);
    liveTimer = setTimeout(() => {
      if (d.kind === "message") loadNew();
      else if (d.kind === "update") refreshEdits();
      else if (d.kind === "members" || d.kind === "info" || d.kind === "prefs") { loadGroup().catch(handleGone); if (d.kind !== "prefs") loadNew(); }
    }, 120);
  }
  if (live) live.on(["group", "resync"], (d, type) => { if (type === "resync") loadNew(); else onGroup(d); });
  // rede de segurança quando o tempo real não está conectado
  const poll = setInterval(() => { if (!live || !live.connected()) loadNew(); }, 8000);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") { loadNew(); markRead(); } });
  window.addEventListener("pagehide", () => { destroyed = true; clearInterval(poll); });

  autosize();
  loadInitial().catch((e) => {
    if (e.status === 404) handleGone(e);
    else { $("gw-loading") && ($("gw-loading").textContent = e.message || "Não foi possível carregar o grupo."); }
  });
})();
