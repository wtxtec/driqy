/*
 * Modal de ajuste de enquadramento (crop) para fotos escolhidas no seletor
 * de mídia (composer e página de publicar). Deixa a pessoa escolher uma
 * proporção, arrastar a foto para posicionar e usar um zoom antes de
 * confirmar — o resultado substitui o arquivo original (ainda dentro do
 * navegador, nada é enviado ao servidor nesse passo).
 *
 * Uso: window.driqyOpenImageCropper(file, { onApply(newFile), onCancel() })
 */
(function () {
  const ASPECTS = [
    { key: "4:5", label: "Retrato (feed)", ratio: 4 / 5 },
    { key: "1:1", label: "Quadrado", ratio: 1 },
    { key: "original", label: "Original", ratio: null },
    { key: "16:9", label: "Paisagem", ratio: 16 / 9 },
  ];

  const BOX = 340; // lado máximo (px) do quadro de recorte no modal
  const OUTPUT_LONG_SIDE = 1440; // maior lado da imagem final exportada

  let overlay, frame, img, viewport, zoomSlider, aspectRow, applyBtn, cancelBtn, closeBtn;
  let ready = false;

  let state = null; // estado da edição em andamento

  function buildOverlay() {
    overlay = document.createElement("div");
    overlay.className = "crop-modal";
    overlay.setAttribute("aria-hidden", "true");
    overlay.innerHTML = `
      <div class="crop-modal-backdrop"></div>
      <div class="crop-modal-box" role="dialog" aria-modal="true" aria-label="Ajustar enquadramento da foto">
        <div class="crop-modal-head">
          <span class="crop-modal-title">Ajustar enquadramento</span>
          <button type="button" class="crop-modal-close" aria-label="Fechar">✕</button>
        </div>

        <div class="crop-aspect-row"></div>

        <div class="crop-viewport">
          <img class="crop-viewport-img" alt="Pré-visualização para recorte" draggable="false">
          <div class="crop-viewport-grid" aria-hidden="true"></div>
        </div>

        <div class="crop-zoom-row">
          <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M15.5 14h-.8l-.3-.3a6.5 6.5 0 1 0-.7.7l.3.3v.8l5 5L20.5 19l-5-5zm-6 0a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>
          <input type="range" class="crop-zoom-slider" min="100" max="300" value="100" aria-label="Zoom">
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M15.5 14h-.8l-.3-.3a6.5 6.5 0 1 0-.7.7l.3.3v.8l5 5L20.5 19l-5-5zm-6-1.5h4v-1h-4z"/></svg>
        </div>

        <p class="hint crop-hint">Arraste a foto para posicionar e use o controle para dar zoom.</p>

        <div class="crop-modal-actions">
          <button type="button" class="btn-outline crop-cancel-btn">Cancelar</button>
          <button type="button" class="btn crop-apply-btn">Aplicar recorte</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    frame = overlay.querySelector(".crop-modal-box");
    viewport = overlay.querySelector(".crop-viewport");
    img = overlay.querySelector(".crop-viewport-img");
    zoomSlider = overlay.querySelector(".crop-zoom-slider");
    aspectRow = overlay.querySelector(".crop-aspect-row");
    applyBtn = overlay.querySelector(".crop-apply-btn");
    cancelBtn = overlay.querySelector(".crop-cancel-btn");
    closeBtn = overlay.querySelector(".crop-modal-close");

    ASPECTS.forEach((a) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "crop-aspect-btn";
      btn.textContent = a.label;
      btn.dataset.key = a.key;
      btn.addEventListener("click", () => selectAspect(a.key));
      aspectRow.appendChild(btn);
    });

    overlay.querySelector(".crop-modal-backdrop").addEventListener("click", () => finish(null));
    closeBtn.addEventListener("click", () => finish(null));
    cancelBtn.addEventListener("click", () => finish(null));
    applyBtn.addEventListener("click", applyCrop);

    zoomSlider.addEventListener("input", () => {
      if (!state) return;
      state.zoom = Number(zoomSlider.value) / 100;
      clampOffset();
      renderTransform();
    });

    // ---------- arrastar (mouse + toque) ----------
    let dragging = false;
    let startX = 0, startY = 0, startOffsetX = 0, startOffsetY = 0;

    function pointerDown(e) {
      if (!state) return;
      dragging = true;
      viewport.classList.add("dragging");
      const p = e.touches ? e.touches[0] : e;
      startX = p.clientX;
      startY = p.clientY;
      startOffsetX = state.offsetX;
      startOffsetY = state.offsetY;
      e.preventDefault();
    }
    function pointerMove(e) {
      if (!dragging || !state) return;
      const p = e.touches ? e.touches[0] : e;
      state.offsetX = startOffsetX + (p.clientX - startX);
      state.offsetY = startOffsetY + (p.clientY - startY);
      clampOffset();
      renderTransform();
      e.preventDefault();
    }
    function pointerUp() {
      dragging = false;
      viewport.classList.remove("dragging");
    }

    viewport.addEventListener("mousedown", pointerDown);
    viewport.addEventListener("touchstart", pointerDown, { passive: false });
    window.addEventListener("mousemove", pointerMove, { passive: false });
    window.addEventListener("touchmove", pointerMove, { passive: false });
    window.addEventListener("mouseup", pointerUp);
    window.addEventListener("touchend", pointerUp);

    // zoom com a roda do mouse, sem precisar do slider
    viewport.addEventListener(
      "wheel",
      (e) => {
        if (!state) return;
        e.preventDefault();
        const next = Math.min(3, Math.max(1, state.zoom - e.deltaY * 0.0015));
        state.zoom = next;
        zoomSlider.value = String(Math.round(next * 100));
        clampOffset();
        renderTransform();
      },
      { passive: false }
    );

    document.addEventListener("keydown", (e) => {
      if (overlay.getAttribute("aria-hidden") === "true") return;
      if (e.key === "Escape") finish(null);
    });

    ready = true;
  }

  function setFrameSize(ratio) {
    const effectiveRatio = ratio || state.naturalRatio;
    let w, h;
    if (effectiveRatio >= 1) {
      w = BOX;
      h = Math.round(BOX / effectiveRatio);
    } else {
      h = BOX;
      w = Math.round(BOX * effectiveRatio);
    }
    viewport.style.width = w + "px";
    viewport.style.height = h + "px";
    state.frameW = w;
    state.frameH = h;
  }

  function baseCoverScale() {
    return Math.max(state.frameW / state.naturalW, state.frameH / state.naturalH);
  }

  function clampOffset() {
    const scale = baseCoverScale() * state.zoom;
    const dispW = state.naturalW * scale;
    const dispH = state.naturalH * scale;
    const minX = state.frameW - dispW;
    const minY = state.frameH - dispH;
    state.offsetX = Math.min(0, Math.max(minX, state.offsetX));
    state.offsetY = Math.min(0, Math.max(minY, state.offsetY));
    state.dispW = dispW;
    state.dispH = dispH;
  }

  function renderTransform() {
    img.style.width = state.dispW + "px";
    img.style.height = state.dispH + "px";
    img.style.transform = `translate(${state.offsetX}px, ${state.offsetY}px)`;
  }

  function selectAspect(key) {
    if (!state) return;
    state.aspectKey = key;
    aspectRow.querySelectorAll(".crop-aspect-btn").forEach((b) => {
      b.classList.toggle("selected", b.dataset.key === key);
    });
    const found = ASPECTS.find((a) => a.key === key);
    setFrameSize(found.ratio);
    // recentraliza ao trocar de proporção
    const scale = baseCoverScale() * state.zoom;
    state.offsetX = (state.frameW - state.naturalW * scale) / 2;
    state.offsetY = (state.frameH - state.naturalH * scale) / 2;
    clampOffset();
    renderTransform();
  }

  function applyCrop() {
    if (!state) return;
    const scale = baseCoverScale() * state.zoom;

    // retângulo visível, em coordenadas da imagem original
    const sx = -state.offsetX / scale;
    const sy = -state.offsetY / scale;
    const sW = state.frameW / scale;
    const sH = state.frameH / scale;

    const outRatio = state.frameW / state.frameH;
    let outW, outH;
    if (outRatio >= 1) {
      outW = OUTPUT_LONG_SIDE;
      outH = Math.round(OUTPUT_LONG_SIDE / outRatio);
    } else {
      outH = OUTPUT_LONG_SIDE;
      outW = Math.round(OUTPUT_LONG_SIDE * outRatio);
    }

    const canvas = document.createElement("canvas");
    canvas.width = outW;
    canvas.height = outH;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(state.imageEl, sx, sy, sW, sH, 0, 0, outW, outH);

    const isPng = /\.png$/i.test(state.file.name) || state.file.type === "image/png";
    const mime = isPng ? "image/png" : "image/jpeg";
    const quality = isPng ? undefined : 0.9;

    canvas.toBlob((blob) => {
      if (!blob) {
        finish(null);
        return;
      }
      const newName = state.file.name.replace(/\.[^.]+$/, isPng ? ".png" : ".jpg");
      const newFile = new File([blob], newName, { type: mime, lastModified: Date.now() });
      finish(newFile);
    }, mime, quality);
  }

  function finish(result) {
    const cb = state ? state.callbacks : null;
    if (state && state.objectUrl) URL.revokeObjectURL(state.objectUrl);
    state = null;
    overlay.setAttribute("aria-hidden", "true");
    document.body.classList.remove("crop-modal-open");
    if (cb) {
      if (result) cb.onApply && cb.onApply(result);
      else cb.onCancel && cb.onCancel();
    }
  }

  function open(file, callbacks) {
    if (!ready) buildOverlay();
    if (!file || !file.type || !file.type.startsWith("image/")) return;

    const objectUrl = URL.createObjectURL(file);
    const imageEl = new Image();
    imageEl.onload = () => {
      state = {
        file,
        callbacks,
        objectUrl,
        imageEl,
        naturalW: imageEl.naturalWidth,
        naturalH: imageEl.naturalHeight,
        naturalRatio: imageEl.naturalWidth / imageEl.naturalHeight,
        zoom: 1,
        offsetX: 0,
        offsetY: 0,
        aspectKey: "original",
      };

      img.src = objectUrl;
      zoomSlider.value = "100";
      overlay.setAttribute("aria-hidden", "false");
      document.body.classList.add("crop-modal-open");

      selectAspect("4:5");
    };
    imageEl.onerror = () => {
      URL.revokeObjectURL(objectUrl);
    };
    imageEl.src = objectUrl;
  }

  window.driqyOpenImageCropper = open;
})();
