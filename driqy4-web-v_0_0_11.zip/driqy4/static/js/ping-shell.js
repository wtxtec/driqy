/* Mensagens (antigo Ping) — shell (fase 3): marca na lista a conversa aberta (desktop: lista + conversa lado a lado).
   A lista é atualizada ao vivo por chat.js (linhas entram/saem), então reaplicamos a marca. */
(function () {
  const shell = document.getElementById("ping-shell");
  if (!shell) return;
  const list = document.getElementById("chat-inbox-list");
  if (!list) return;

  // A conversa aberta pode mudar sem recarregar (fase 6a): lê do shell a cada vez.
  function mark() {
    const active = shell.dataset.activeUsername || "";
    list.querySelectorAll(".chat-inbox-row").forEach((row) => {
      row.classList.toggle("is-active", !!active && row.dataset.username === active);
    });
  }
  mark();
  // childList apenas (alterar classe não dispara de novo → sem laço).
  new MutationObserver(mark).observe(list, { childList: true, subtree: true });

  // ---- Menu lateral (☰ da lista e aba "Menu" da pílula): abre/fecha, Esc, toque fora, foco ----
  const drawerWrap = document.getElementById("ping-drawer-wrap");
  const drawer = document.getElementById("ping-drawer");
  const menuBtns = [document.getElementById("ping-menu-btn"), document.getElementById("ping-tab-menu")].filter(Boolean);
  let drawerFrom = null;
  function drawerOpen() { return !!drawerWrap && !drawerWrap.hidden; }
  function openDrawer(from) {
    if (!drawerWrap || drawerOpen()) return;
    drawerFrom = from || null;
    drawerWrap.hidden = false;
    void drawerWrap.offsetWidth; // força o layout para a transição de entrada rodar
    drawerWrap.classList.add("is-open");
    menuBtns.forEach((b) => b.setAttribute("aria-expanded", "true"));
    const first = drawer.querySelector("a, button:not(.ping-drawer-close)");
    if (first) first.focus({ preventScroll: true });
  }
  function closeDrawer(restoreFocus) {
    if (!drawerOpen()) return;
    drawerWrap.classList.remove("is-open");
    drawerWrap.hidden = true;
    menuBtns.forEach((b) => b.setAttribute("aria-expanded", "false"));
    if (restoreFocus !== false && drawerFrom) { try { drawerFrom.focus({ preventScroll: true }); } catch (e) {} }
  }
  window.pingShell = { closeDrawer: closeDrawer }; // usado pelo groups.js (Novo grupo)
  if (drawerWrap) {
    menuBtns.forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); openDrawer(b); }));
    document.getElementById("ping-drawer-close").addEventListener("click", () => closeDrawer());
    document.getElementById("ping-drawer-backdrop").addEventListener("click", () => closeDrawer());
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && drawerOpen()) closeDrawer(); });
    // link de navegação = sai da página; o menu fecha antes (evita voltar com ele aberto pelo bfcache)
    drawer.addEventListener("click", (e) => { if (e.target.closest("a[href]")) closeDrawer(false); });
  }

  // ---- Configurações (estilo Telegram): painel sobre a coluna da lista; subtelas dentro dele ----
  const setPanel = document.getElementById("ping-settings");
  const setOpenBtn = document.getElementById("ping-settings-open");
  const listCol = document.getElementById("ping-list-col");
  const setTitle = document.getElementById("ping-settings-title");
  function setOpen() { return !!setPanel && !setPanel.hidden; }
  function showSetView(name) {
    if (!setPanel) return;
    let found = false;
    setPanel.querySelectorAll(".ping-set-view").forEach((v) => {
      const on = v.dataset.view === name;
      v.hidden = !on;
      if (on) { found = true; if (setTitle) setTitle.textContent = v.dataset.title || "Configurações"; }
    });
    if (!found) showSetView("home");
    const body = setPanel.querySelector(".ping-set-body");
    if (body) body.scrollTop = 0;
  }
  function openSettings() {
    if (!setPanel || setOpen()) return;
    closeDrawer(false);
    if (listCol) { listCol.scrollTop = 0; listCol.classList.add("is-settings"); }
    showSetView("home");
    setPanel.hidden = false;
    const back = document.getElementById("ping-settings-back");
    if (back) back.focus({ preventScroll: true });
    try { if (location.hash !== "#configuracoes") history.replaceState(null, "", location.pathname + location.search + "#configuracoes"); } catch (e) {}
  }
  function closeSettings() {
    if (!setOpen()) return;
    setPanel.hidden = true;
    if (listCol) listCol.classList.remove("is-settings");
    try { if (location.hash === "#configuracoes") history.replaceState(null, "", location.pathname + location.search); } catch (e) {}
    if (setOpenBtn) { try { setOpenBtn.focus({ preventScroll: true }); } catch (e) {} }
  }
  if (setPanel) {
    // voltar: subtela → início; início → fecha o painel
    document.getElementById("ping-settings-back").addEventListener("click", () => {
      const cur = setPanel.querySelector(".ping-set-view:not([hidden])");
      if (cur && cur.dataset.view !== "home") showSetView("home"); else closeSettings();
    });
    setPanel.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => showSetView(b.dataset.go)));
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape" || !setOpen() || drawerOpen()) return;
      const cur = setPanel.querySelector(".ping-set-view:not([hidden])");
      if (cur && cur.dataset.view !== "home") showSetView("home"); else closeSettings();
    });
    if (setOpenBtn) setOpenBtn.addEventListener("click", () => {
      // em Contatos/Chamadas (celular) a coluna da lista está escondida: vai para a lista com o painel aberto
      if (listCol && listCol.offsetParent === null) { location.href = setOpenBtn.dataset.settingsUrl; return; }
      openSettings();
    });
    if (location.hash === "#configuracoes") openSettings();
  }

  const input = document.getElementById("ping-search");
  const emptyMsg = document.getElementById("ping-search-empty");
  function norm(t) {
    return (t || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }
  function filter() {
    const q = norm(input && input.value.trim());
    let shown = 0;
    list.querySelectorAll(".chat-inbox-row").forEach((row) => {
      const hit = !q || norm(row.textContent).includes(q) || norm(row.dataset.username).includes(q);
      row.hidden = !hit; // atributo hidden: não dispara o observer de childList
      if (hit) shown++;
    });
    if (emptyMsg) emptyMsg.hidden = !(q && shown === 0 && list.querySelector(".chat-inbox-row"));
  }
  if (input) {
    input.addEventListener("input", filter);
    // linhas entram/saem ao vivo (chat.js): reaplica o filtro
    new MutationObserver(filter).observe(list, { childList: true });
  }

  const notice = document.getElementById("ping-notice");
  const noticeClose = document.getElementById("ping-notice-close");
  if (notice) {
    let dismissed = false;
    try { dismissed = localStorage.getItem("ping-notice-v1") === "1"; } catch (e) {}
    notice.hidden = dismissed;
    if (noticeClose) noticeClose.addEventListener("click", () => {
      notice.hidden = true;
      try { localStorage.setItem("ping-notice-v1", "1"); } catch (e) {}
    });
  }
  // ---- Fase 4b: botão "novo ping" → painel de busca de pessoas → abre a conversa ----
  // ---- "Nova conversa" (item do menu lateral; a caneta/FAB foi removida) → busca de pessoas → abre a conversa ----
  const fab = document.getElementById("ping-new-open");
  const panel = document.getElementById("ping-new");
  if (fab && panel) {
    const q = document.getElementById("ping-new-q");
    const box = document.getElementById("ping-new-results");
    let timer = null, seq = 0;
    const base = (fab.dataset.threadBase || "/mensagens/").replace(/\/?$/, "/");
    function close() { panel.hidden = true; }
    fab.addEventListener("click", () => {
      closeDrawer(false);
      panel.hidden = false; q.value = ""; box.textContent = "";
      if (panel.scrollIntoView) panel.scrollIntoView({ block: "nearest" });
      q.focus();
    });
    document.getElementById("ping-new-close").addEventListener("click", close);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !panel.hidden) close(); });
    function render(users) {
      box.textContent = "";
      if (!users.length) {
        const p = document.createElement("p");
        p.className = "ping-search-empty";
        p.textContent = q.value.trim() ? "Ninguém encontrado." : "";
        box.appendChild(p);
        return;
      }
      users.forEach((u) => {
        const a = document.createElement("a");
        a.className = "ping-new-row";
        a.href = base + encodeURIComponent(u.username);
        const av = document.createElement("span");
        av.className = "avatar-dot";
        if (u.avatar) { const im = document.createElement("img"); im.className = "avatar-img"; im.src = u.avatar; im.alt = ""; av.appendChild(im); }
        else { av.textContent = u.initial; }
        const nm = document.createElement("span");
        nm.textContent = u.display_name + " (@" + u.username + ")";
        a.append(av, nm);
        box.appendChild(a);
      });
    }
    q.addEventListener("input", () => {
      clearTimeout(timer);
      const term = q.value.trim();
      if (!term) { render([]); return; }
      timer = setTimeout(() => {
        const mine = ++seq;
        fetch(fab.dataset.searchUrl + "?q=" + encodeURIComponent(term), { credentials: "same-origin" })
          .then((r) => r.json())
          .then((d) => { if (mine === seq) render(d.users || []); })
          .catch(() => {});
      }, 200);
    });
  }
  // ---- Fase 6a (só desktop ≥900px): abrir conversa sem recarregar a página ----
  // Busca só o miolo da conversa (cabeçalho X-Ping-Fragment), desmonta o chat-thread.js anterior
  // (`window.__pingThreadDestroy`), troca o #ping-main-col e roda o script de novo. Qualquer
  // problema → navegação normal (location.href), então nunca fica pior que antes.
  const mainCol = document.getElementById("ping-main-col");
  const scriptUrl = shell.dataset.threadScript || "";
  const wide = window.matchMedia("(min-width: 900px)");
  const BASE = (fab && fab.dataset.threadBase) || "/mensagens/";
  let scriptText = null, navSeq = 0;

  function loadScriptText() {
    if (scriptText !== null) return Promise.resolve(scriptText);
    return fetch(scriptUrl, { credentials: "same-origin" })
      .then((r) => { if (!r.ok) throw new Error("script"); return r.text(); })
      .then((t) => (scriptText = t));
  }
  function usernameFromPath(path) {
    const base = BASE.replace(/\/?$/, "/");
    if (!path.startsWith(base)) return "";
    const rest = path.slice(base.length).split("/")[0];
    if (!rest || rest === "chamadas" || rest === "grupo") return "";
    try { return decodeURIComponent(rest); } catch (e) { return ""; }
  }
  function openThread(href, push) {
    const url = new URL(href, location.href);
    const username = usernameFromPath(url.pathname);
    if (!username || !scriptUrl || !mainCol) { location.href = href; return; }
    const mine = ++navSeq;
    Promise.all([
      fetch(url.pathname, { credentials: "same-origin", headers: { "X-Ping-Fragment": "1", "X-Requested-With": "fetch" } })
        .then((r) => { if (!r.ok || r.redirected) throw new Error("fragment"); return r.text(); }),
      loadScriptText(),
    ]).then(([html, code]) => {
      if (mine !== navSeq) return; // clicou noutra conversa enquanto carregava
      if (typeof window.__pingThreadDestroy === "function") window.__pingThreadDestroy();
      mainCol.innerHTML = html;
      shell.dataset.activeUsername = username;
      document.body.classList.remove("ping-view-list");
      document.body.classList.add("ping-view-main", "chat-page");
      const name = (mainCol.querySelector("#cw") || {}).dataset;
      document.title = (name && name.partnerName ? "Conversa com " + name.partnerName : "Ping") + " — Ping";
      if (push) history.pushState({ pingThread: username }, "", url.pathname);
      mark();
      // limpa o selo de não lidas da linha (o servidor já marcou como lidas ao montar o fragmento)
      const row = list.querySelector('.chat-inbox-row[data-username="' + username.replace(/"/g, "") + '"]');
      if (row) {
        row.classList.remove("conv-unread");
        const b = row.querySelector(".notif-badge-inline");
        if (b) { b.hidden = true; b.textContent = "0"; }
      }
      const sc = document.createElement("script");
      sc.textContent = code; // roda o chat-thread.js sobre o novo #cw
      document.body.appendChild(sc);
      sc.remove();
    }).catch(() => { if (mine === navSeq) location.href = href; });
  }

  list.addEventListener("click", (e) => {
    if (!wide.matches || e.defaultPrevented || e.button !== 0) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (e.target.closest(".conv-menu-btn")) return;
    const row = e.target.closest("a.chat-inbox-row");
    if (!row || !list.contains(row)) return;
    if (row.classList.contains("ping-group-row")) return; // grupo: navegação normal (página própria)
    if (row.dataset.username === shell.dataset.activeUsername && mainCol.querySelector("#cw")) { e.preventDefault(); return; }
    e.preventDefault();
    openThread(row.getAttribute("href"), true);
  });
  window.addEventListener("popstate", () => {
    const u = usernameFromPath(location.pathname);
    if (u && wide.matches) openThread(location.pathname, false);
    else location.reload(); // voltou para a lista/estado vazio: recarrega (simples e correto)
  });

})();
