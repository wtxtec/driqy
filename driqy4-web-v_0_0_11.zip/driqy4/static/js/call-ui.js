/* Chamada de VOZ (Fase 12) e VÍDEO (Fase 13) — WebRTC + tela de chamada, em qualquer página logada.
 *
 * Usa a sinalização da Fase 11 (`window.driqyCalls`) e os eventos ao vivo (`window.driqyLive`):
 *   call_incoming (tem a offer) · call_signal (answer | ice) · call_state (terminou/aceitou)
 * Se o SSE não estiver ligado, um polling leve de `GET /calls/<id>` cobre answer, ICE e estado.
 * Botão de ligar: qualquer elemento com `data-call-user="username"` (+ `data-call-name`, `data-call-avatar`).
 * Vídeo: `data-call-media="video"` no botão (ou 4º argumento de `start`). Só chamadas que COMEÇAM como vídeo têm
 * imagem (sem renegociação); dá pra desligar/ligar a câmera e alternar entre câmeras. Câmera falhou → segue só com áudio.
 * API: `window.driqyCallUI.start(username, name, avatarUrl, media)`, `.busy()`.
 * Microfone exige HTTPS (ou localhost) — ver Risco 12 do PROGRESSO_CHAT.md.
 */
(function () {
  "use strict";
  if (window.driqyCallUI || !window.driqyCalls) return;
  var C = window.driqyCalls;
  var L = window.driqyLive || { on: function () {}, connected: function () { return false; } };
  var OWNER_KEY = "driqy_call_owner";
  var ENDED = { ended: 1, declined: 1, missed: 1, failed: 1, busy: 1 };
  var cur = null;          // chamada deste documento
  var seen = {};           // call_id -> true (dedupe de toques)
  var cfgP = null;
  var els = null;
  var tone = null;

  function noop() {}
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function supported() { return !!(window.RTCPeerConnection && navigator.mediaDevices && navigator.mediaDevices.getUserMedia); }
  function fmt(s) { s = Math.max(0, Math.floor(s)); var m = Math.floor(s / 60), r = s % 60; return m + ":" + (r < 10 ? "0" : "") + r; }
  function cfg() { if (!cfgP) cfgP = C.config().catch(function (e) { cfgP = null; throw e; }); return cfgP; }

  /* ---------- toques (WebAudio, sem arquivos) ---------- */
  function toneStop() {
    if (!tone) return;
    clearInterval(tone.iv);
    try { tone.ctx.close(); } catch (e) {}
    tone = null;
  }
  function toneStart(kind) {      // ring = chamada recebida · back = chamando
    toneStop();
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    var ctx;
    try { ctx = new AC(); } catch (e) { return; }
    function burst() {
      try {
        if (ctx.state === "suspended") ctx.resume().catch(noop);
        var freqs = kind === "ring" ? [[880, 0], [660, 0.22], [880, 0.44], [660, 0.66]] : [[425, 0]];
        var dur = kind === "ring" ? 0.18 : 1.0;
        freqs.forEach(function (f) {
          var o = ctx.createOscillator(), g = ctx.createGain();
          o.type = "sine"; o.frequency.value = f[0];
          var t0 = ctx.currentTime + f[1];
          g.gain.setValueAtTime(0.0001, t0);
          g.gain.exponentialRampToValueAtTime(0.12, t0 + 0.02);
          g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
          o.connect(g); g.connect(ctx.destination);
          o.start(t0); o.stop(t0 + dur + 0.05);
        });
      } catch (e) {}
    }
    burst();
    tone = { ctx: ctx, iv: setInterval(burst, kind === "ring" ? 2200 : 3000) };
  }

  /* ---------- interface ---------- */
  function build() {
    if (els) return els;
    var ov = document.createElement("div");
    ov.className = "cl-ov"; ov.hidden = true;
    ov.setAttribute("role", "dialog"); ov.setAttribute("aria-modal", "true"); ov.setAttribute("aria-label", "Chamada de voz");
    ov.innerHTML =
      '<video id="cl-remote" class="cl-remote" autoplay playsinline muted></video>' +
      '<video id="cl-local" class="cl-local" autoplay playsinline muted></video>' +
      '<div class="cl-card">' +
        '<div class="cl-avatar" id="cl-avatar"></div>' +
        '<h2 class="cl-name" id="cl-name"></h2>' +
        '<p class="cl-status" id="cl-status" aria-live="polite"></p>' +
        '<p class="cl-warn" id="cl-warn" hidden></p>' +
        '<div class="cl-actions" id="cl-actions"></div>' +
      '</div>' +
      '<audio id="cl-audio" autoplay playsinline></audio>';
    document.body.appendChild(ov);
    els = {
      ov: ov, avatar: $("#cl-avatar", ov), name: $("#cl-name", ov), status: $("#cl-status", ov),
      warn: $("#cl-warn", ov), actions: $("#cl-actions", ov), audio: $("#cl-audio", ov),
      remote: $("#cl-remote", ov), local: $("#cl-local", ov),
    };
    els.actions.addEventListener("click", function (ev) {
      var b = ev.target.closest("button[data-act]");
      if (!b || !cur) return;
      var a = b.getAttribute("data-act");
      if (a === "accept") accept();
      else if (a === "decline") decline();
      else if (a === "hangup") hangup();
      else if (a === "mute") toggleMute(b);
      else if (a === "cam") toggleCam(b);
      else if (a === "flip") flipCam();
      else if (a === "full") toggleFull();
    });
    els.remote.addEventListener("click", function () { els.ov.classList.toggle("cl-ctl-hidden"); });
    document.addEventListener("fullscreenchange", function () { if (els) els.ov.classList.toggle("cl-isfull", !!document.fullscreenElement); });
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" && cur && !els.ov.hidden && cur.state !== "incoming") hangup();
    });
    return els;
  }
  var ICON = {
    phone: '<svg viewBox="0 0 24 24" width="28" height="28" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8a15.1 15.1 0 006.6 6.6l2.2-2.2a1 1 0 011-.25 11.4 11.4 0 003.6.57 1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h3.5a1 1 0 011 1c0 1.25.2 2.45.57 3.6a1 1 0 01-.25 1z"/></svg>',
    mic: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/></svg>',
    cam: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="6" width="14" height="12" rx="2"/><path d="M22 8l-6 4 6 4z"/></svg>',
    camoff: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="6" width="14" height="12" rx="2"/><path d="M22 8l-6 4 6 4zM3 3l18 18"/></svg>',
    flip: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 0115-6.7L21 8M21 3v5h-5M21 12a9 9 0 01-15 6.7L3 16M3 21v-5h5"/></svg>',
    full: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/></svg>',
    micoff: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3M3 3l18 18"/></svg>',
  };
  function btn(act, cls, label, icon) {
    return '<button type="button" class="cl-btn ' + cls + '" data-act="' + act + '" aria-label="' + label + '" title="' + label + '">' + icon + '<span>' + label + '</span></button>';
  }
  function setActions(state) {
    var h = "";
    if (state === "incoming") h = btn("decline", "cl-red", "Recusar", ICON.phone) + btn("accept", "cl-green", "Atender", ICON.phone);
    else if (state === "active" || state === "connecting") {
      var vid = !!(cur && cur.media === "video");
      h = btn("mute", "cl-grey", "Mudo", ICON.mic) +
        (vid ? btn("cam", "cl-grey" + (cur.camOff ? " on" : ""), cur.camOff ? "Ligar câmera" : "Câmera", cur.camOff ? ICON.camoff : ICON.cam) + btn("flip", "cl-grey", "Virar", ICON.flip) +
          (els.ov.requestFullscreen ? btn("full", "cl-grey", "Tela cheia", ICON.full) : "") : "") +
        btn("hangup", "cl-red", "Desligar", ICON.phone);
    }
    else if (state === "calling") h = btn("hangup", "cl-red", "Cancelar", ICON.phone);
    els.actions.innerHTML = h;
    els.ov.classList.toggle("cl-incoming", state === "incoming");
  }
  function paintPartner() {
    var p = cur.partner || {};
    var name = p.name || p.username || "";
    els.name.textContent = name;
    if (p.avatar) els.avatar.innerHTML = '<img src="' + esc(p.avatar) + '" alt="">';
    else els.avatar.textContent = (name || "?").charAt(0).toUpperCase();
  }
  function status(t) { if (els) els.status.textContent = t; }
  function warn(t) { if (!els) return; els.warn.hidden = !t; els.warn.textContent = t || ""; }
  function open(state) {
    build();
    cur.state = state;
    var isVid = cur.media === "video";
    els.ov.classList.toggle("cl-video", isVid);
    els.ov.setAttribute("aria-label", isVid ? "Chamada de vídeo" : "Chamada de voz");
    paintPartner(); setActions(state);
    els.ov.hidden = false;
    document.documentElement.classList.add("cl-open");
  }
  function closeUi() {
    if (els) {
      els.ov.hidden = true; els.audio.srcObject = null; els.remote.srcObject = null; els.local.srcObject = null;
      els.ov.classList.remove("cl-video", "cl-has-remote", "cl-has-local", "cl-cam-off", "cl-ctl-hidden", "cl-isfull");
      warn("");
    }
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) {}
    document.documentElement.classList.remove("cl-open");
  }

  /* ---------- posse entre abas (não encerrar chamada que outra aba conduz) ---------- */
  function ownerSet(id) { try { localStorage.setItem(OWNER_KEY, JSON.stringify({ id: id, ts: Date.now() })); } catch (e) {} }
  function ownerClear() { try { localStorage.removeItem(OWNER_KEY); } catch (e) {} }
  function ownerFresh(id) {
    try { var o = JSON.parse(localStorage.getItem(OWNER_KEY) || "null"); return !!o && o.id === id && Date.now() - o.ts < 20000; }
    catch (e) { return false; }
  }

  /* ---------- WebRTC ---------- */
  function micError(e) {
    var n = e && e.name;
    if (!window.isSecureContext) return "O microfone só funciona em HTTPS (ou localhost).";
    if (n === "NotAllowedError" || n === "SecurityError") return "Permissão do microfone negada. Libere nas configurações do navegador.";
    if (n === "NotFoundError" || n === "OverconstrainedError") return "Nenhum microfone encontrado.";
    if (n === "NotReadableError") return "O microfone está em uso por outro programa.";
    return "Não foi possível acessar o microfone.";
  }
  var AUDIO_C = { echoCancellation: true, noiseSuppression: true, autoGainControl: true };
  var VIDEO_C = { width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24, max: 30 }, facingMode: "user" };   // banda: 640×480 a 24 fps
  function getMic() { return navigator.mediaDevices.getUserMedia({ audio: AUDIO_C, video: false }); }
  /* Vídeo pedido: tenta áudio+vídeo; se a câmera falhar, degrada para só áudio (e avisa). */
  function getMedia(wantVideo, who) {
    if (!wantVideo) return getMic();
    return navigator.mediaDevices.getUserMedia({ audio: AUDIO_C, video: VIDEO_C }).catch(function () {
      return getMic().then(function (s) { if (who) who.noCam = true; return s; });
    });
  }
  function camError() { return "Câmera indisponível: a outra pessoa não vai te ver (só áudio)."; }
  function showLocal() {
    if (!els || !cur || !cur.stream) return;
    var vt = cur.stream.getVideoTracks();
    if (vt.length) { els.local.srcObject = new MediaStream([vt[0]]); els.local.play().catch(noop); }
    els.ov.classList.toggle("cl-has-local", !!vt.length);
    if (cur.noCam) warn(camError());
  }
  function limitVideo(pc) {      // teto de banda do vídeo enviado (~800 kbps)
    try {
      pc.getSenders().forEach(function (sd) {
        if (!sd.track || sd.track.kind !== "video" || !sd.getParameters) return;
        var p = sd.getParameters();
        if (!p.encodings || !p.encodings.length) p.encodings = [{}];
        p.encodings[0].maxBitrate = 800000;
        sd.setParameters(p).catch(noop);
      });
    } catch (e) {}
  }
  function makePc(config) {
    var pc = new RTCPeerConnection({ iceServers: (config && config.ice_servers) || [] });
    cur.pc = pc; cur.outIce = []; cur.pendIce = []; cur.seenIce = {}; cur.remoteSet = false;
    cur.stream.getTracks().forEach(function (t) { pc.addTrack(t, cur.stream); });
    pc.ontrack = function (ev) {
      if (!els) return;
      var st = ev.streams && ev.streams[0] ? ev.streams[0] : new MediaStream([ev.track]);
      els.audio.srcObject = st;
      els.audio.play().catch(noop);
      if (ev.track.kind === "video") {
        els.remote.srcObject = st;
        els.remote.play().catch(noop);
        if (!ev.track.muted) els.ov.classList.add("cl-has-remote");
        ev.track.onunmute = function () { els.ov.classList.add("cl-has-remote"); };
        ev.track.onmute = function () { els.ov.classList.remove("cl-has-remote"); };
      }
    };
    pc.onicecandidate = function (ev) {
      if (!ev.candidate) return;
      var c = ev.candidate.toJSON ? ev.candidate.toJSON() : ev.candidate;
      if (cur && cur.id) C.ice(cur.id, c).catch(noop); else if (cur) cur.outIce.push(c);
    };
    pc.onconnectionstatechange = function () {
      if (!cur || cur.pc !== pc) return;
      var s = pc.connectionState;
      if (s === "connected") {
        clearTimeout(cur.discTimer);
        if (cur.state !== "active") goActive();
        else status(fmt((Date.now() - cur.t0) / 1000));
      } else if (s === "disconnected") {
        status("Reconectando…");
        clearTimeout(cur.discTimer);
        cur.discTimer = setTimeout(function () { if (cur && cur.pc === pc && pc.connectionState !== "connected") fail("A conexão caiu."); }, 12000);
      } else if (s === "failed") {
        fail(cfgTurnHint("Não foi possível conectar a chamada."));
      }
    };
    return pc;
  }
  var turnMissing = false;
  function cfgTurnHint(msg) { return turnMissing ? msg + " (Servidor TURN não configurado: veja COTURN.md.)" : msg; }
  function flushOutIce() {
    if (!cur || !cur.id) return;
    var q = cur.outIce || []; cur.outIce = [];
    q.forEach(function (c) { C.ice(cur.id, c).catch(noop); });
  }
  function addRemoteIce(c) {
    if (!cur || !c) return;
    var k = JSON.stringify(c);
    if (cur.seenIce[k]) return;
    cur.seenIce[k] = true;
    if (!cur.remoteSet) { cur.pendIce.push(c); return; }
    cur.pc.addIceCandidate(c).catch(noop);
  }
  function flushPendIce() {
    var q = cur.pendIce || []; cur.pendIce = [];
    q.forEach(function (c) { cur.pc.addIceCandidate(c).catch(noop); });
  }
  function applyAnswer(ans) {
    if (!cur || cur.role !== "caller" || cur.remoteSet || cur.settingAnswer || !ans || !ans.sdp) return;
    cur.settingAnswer = true;
    cur.pc.setRemoteDescription({ type: "answer", sdp: ans.sdp }).then(function () {
      if (!cur) return;
      cur.remoteSet = true; flushPendIce();
      if (cur.state === "calling") { toneStop(); cur.state = "connecting"; setActions("connecting"); status("Conectando…"); }
    }).catch(function () { fail("Resposta da chamada inválida."); });
  }

  /* ---------- ciclo da chamada ---------- */
  function goActive() {
    cur.state = "active"; cur.t0 = Date.now();
    toneStop(); setActions("active"); status("0:00");
    if (cur.media === "video") { limitVideo(cur.pc); lockScreen(); }
    clearInterval(cur.clock);
    cur.clock = setInterval(function () { if (cur && cur.state === "active") status(fmt((Date.now() - cur.t0) / 1000)); }, 1000);
  }
  function lockScreen() {        // vídeo: não deixa a tela apagar no celular
    try { if (navigator.wakeLock) navigator.wakeLock.request("screen").then(function (l) { if (cur) cur.wake = l; else l.release(); }).catch(noop); } catch (e) {}
  }
  function pauseMedia() {
    [].forEach.call(document.querySelectorAll("audio, video"), function (m) { if (els && m === els.audio) return; try { if (!m.paused) m.pause(); } catch (e) {} });
  }
  function startTimers() {
    var pingMs = 20000;
    cfg().then(function (c) { if (c && c.ping_seconds) pingMs = Math.max(5, c.ping_seconds) * 1000; }).catch(noop).then(function () {
      if (!cur) return;
      clearInterval(cur.pingIv);
      cur.pingIv = setInterval(function () {
        if (!cur || !cur.id) return;
        ownerSet(cur.id);
        C.ping(cur.id).then(function (d) { if (cur && d && d.state && ENDED[d.state]) finish(endText(d)); }).catch(function (e) { if (e.status === 404) finish("Chamada encerrada."); });
      }, pingMs);
    });
    cur.pollIv = setInterval(poll, 2500);
    ownerSet(cur.id);
  }
  var polling = false;
  function poll() {
    if (!cur || !cur.id || polling || cur.state === "incoming") return;
    if (cur.state === "active" && L.connected()) return;   // com SSE vivo e já conectado, ping basta
    polling = true;
    var id = cur.id;
    C.get(id).then(function (d) {
      if (!cur || cur.id !== id) return;
      if (ENDED[d.state]) { finish(endText(d)); return; }
      if (d.answer) applyAnswer(d.answer);
      (d.ice || []).forEach(addRemoteIce);
    }).catch(function (e) { if (e && e.status === 404 && cur && cur.id === id) finish("Chamada encerrada."); })
      .then(function () { polling = false; });
  }
  function endText(d) {
    var r = d.end_reason || d.reason, s = d.state;
    if (s === "declined") return cur && cur.role === "caller" ? "Chamada recusada." : "Chamada recusada.";
    if (s === "missed") return cur && cur.role === "callee" ? "Chamada perdida." : "Sem resposta.";
    if (s === "busy") return "Ocupado.";
    if (s === "failed") return "A chamada falhou.";
    if (r === "stale") return "Chamada encerrada (sem sinal).";
    return "Chamada encerrada.";
  }
  function cleanup() {
    if (!cur) return;
    clearInterval(cur.pollIv); clearInterval(cur.pingIv); clearInterval(cur.clock); clearTimeout(cur.discTimer); clearTimeout(cur.ringTimer);
    try { if (cur.pc) { cur.pc.onconnectionstatechange = null; cur.pc.close(); } } catch (e) {}
    try { if (cur.stream) cur.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (cur.wake) cur.wake.release(); } catch (e) {}
    toneStop(); ownerClear();
  }
  function finish(msg, silent) {
    if (!cur) return;
    var c = cur, dur = c.state === "active" ? fmt((Date.now() - c.t0) / 1000) : "";
    cleanup();
    cur = null;
    if (silent || !els || els.ov.hidden) { closeUi(); return; }
    setActions("none"); els.actions.innerHTML = "";
    status((msg || "Chamada encerrada.") + (dur ? " · " + dur : ""));
    setTimeout(function () { if (!cur) closeUi(); }, 1800);
  }
  function fail(msg) {
    var id = cur && cur.id;
    if (id) C.end(id, "error").catch(noop);
    finish(msg);
  }

  function start(username, name, avatar, media) {
    if (cur) { if (els) els.ov.hidden = false; return; }
    if (!username) return;
    if (!supported() || !window.isSecureContext) {
      toast(!window.isSecureContext ? "Chamadas exigem HTTPS (ou localhost)." : "Seu navegador não suporta chamadas.");
      return;
    }
    build();
    cur = { role: "caller", media: media === "video" ? "video" : "voice", partner: { username: username, name: name || username, avatar: avatar || "" }, id: null, clientId: "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8) };
    open("calling"); status("Preparando…");
    pauseMedia();
    var me = cur;
    cfg().then(function (config) {
      if (!config.enabled) throw { soft: "As chamadas estão desativadas no servidor." };
      turnMissing = !config.turn_configured;
      if (turnMissing) warn("Modo de teste: sem servidor TURN, a chamada pode ficar muda em algumas redes.");
      return getMedia(me.media === "video", me).catch(function (e) { throw { soft: micError(e) }; }).then(function (stream) {
        if (cur !== me) { stream.getTracks().forEach(function (t) { t.stop(); }); throw { silent: true }; }
        me.stream = stream; showLocal();
        var pc = makePc(config);
        return pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: me.media === "video" }).then(function (offer) {
          return pc.setLocalDescription(offer).then(function () { return offer; });
        });
      });
    }).then(function (offer) {
      return C.start(username, me.media, offer.sdp, me.clientId);
    }).then(function (call) {
      if (cur !== me) { C.end(call.id).catch(noop); return; }
      me.id = call.id; seen[call.id] = true;
      status("Chamando…"); toneStart("back");
      flushOutIce(); startTimers();
      me.ringTimer = setTimeout(function () { if (cur === me && me.state === "calling") poll(); }, ((call.ring_seconds || 45) + 3) * 1000);
    }).catch(function (e) {
      if (e && e.silent) return;
      var msg = (e && e.soft) || null;
      if (!msg && e && e.code === "busy") msg = "Está em outra chamada.";
      else if (!msg && e && e.code === "already_in_call") msg = "Você já está em uma chamada.";
      else if (!msg && e && e.status === 404) msg = "Usuário não encontrado.";
      else if (!msg && e && e.status === 503) msg = "As chamadas estão desativadas no servidor.";
      else if (!msg) msg = "Não foi possível iniciar a chamada.";
      if (cur === me) finish(msg);
    });
  }

  function incoming(d) {
    if (!d || !d.call_id || seen[d.call_id]) return;
    seen[d.call_id] = true;
    if (cur) return;                       // já em chamada: o servidor já respondeu "ocupado"
    build();
    cur = { role: "callee", id: d.call_id, media: d.media || "voice", offer: d.offer || null, partner: { username: d.partner, name: d.partner, avatar: "" } };
    var me = cur;
    open("incoming");
    status(me.media === "video" ? "Chamada de vídeo recebida" : "Chamada de voz recebida");
    pauseMedia(); toneStart("ring");
    C.get(d.call_id).then(function (call) {
      if (cur !== me) return;
      if (call.partner) me.partner = { username: call.partner.username, name: call.partner.display_name || call.partner.username, avatar: call.partner.avatar_url || "" };
      if (!me.offer && call.offer) me.offer = call.offer;
      paintPartner();
    }).catch(noop);
    me.ringTimer = setTimeout(function () { if (cur === me && me.state === "incoming") finish("Chamada perdida."); }, ((d.ring_seconds || 45) + 5) * 1000);
    try {
      if (document.hidden && window.Notification && Notification.permission === "granted") {
        var n = new Notification(me.media === "video" ? "Chamada de vídeo" : "Chamada de voz", { body: "@" + d.partner + " está ligando", tag: "driqy-call", requireInteraction: true });
        n.onclick = function () { window.focus(); n.close(); };
        setTimeout(function () { try { n.close(); } catch (e) {} }, 30000);
      }
    } catch (e) {}
  }

  function accept() {
    var me = cur;
    if (!me || me.state !== "incoming" || me.answering) return;
    if (!supported() || !window.isSecureContext) { toast("Atender exige HTTPS (ou localhost) e microfone."); return; }
    me.answering = true; toneStop(); status("Conectando…");
    setActions("connecting");
    var config;
    cfg().then(function (c) {
      config = c; turnMissing = !c.turn_configured;
      return getMedia(me.media === "video", me).catch(function (e) { throw { soft: micError(e) }; });
    }).then(function (stream) {
      if (cur !== me) { stream.getTracks().forEach(function (t) { t.stop(); }); throw { silent: true }; }
      me.stream = stream; showLocal();
      return me.offer ? me.offer : C.get(me.id).then(function (call) { if (!call.offer) throw { soft: "A chamada não está mais disponível." }; return call.offer; });
    }).then(function (offer) {
      var pc = makePc(config);
      return pc.setRemoteDescription({ type: "offer", sdp: offer.sdp }).then(function () {
        me.remoteSet = true;
        return pc.createAnswer();
      }).then(function (ans) { return pc.setLocalDescription(ans).then(function () { return ans; }); });
    }).then(function (ans) {
      return C.answer(me.id, ans.sdp);
    }).then(function () {
      if (cur !== me) return;
      me.state = "connecting"; flushOutIce();
      startTimers();
      return C.get(me.id).then(function (call) { if (cur === me) (call.ice || []).forEach(addRemoteIce); flushPendIce(); }).catch(noop);
    }).catch(function (e) {
      if (e && e.silent) return;
      var msg = (e && e.soft) || (e && e.status === 409 ? "Esta chamada não está mais tocando." : "Não foi possível atender.");
      if (cur === me) { if (me.id && !(e && e.status === 409)) C.end(me.id).catch(noop); finish(msg); }
    });
  }
  function decline() {
    var id = cur && cur.id;
    if (id) C.decline(id).catch(noop);
    finish("Chamada recusada.", true);
  }
  function hangup() {
    var id = cur && cur.id;
    if (id) C.end(id).catch(noop);
    finish("Chamada encerrada.");
  }
  function toggleMute(b) {
    if (!cur || !cur.stream) return;
    cur.muted = !cur.muted;
    cur.stream.getAudioTracks().forEach(function (t) { t.enabled = !cur.muted; });
    b.classList.toggle("on", !!cur.muted);
    b.setAttribute("aria-pressed", cur.muted ? "true" : "false");
    b.querySelector("span").textContent = cur.muted ? "Ativar som" : "Mudo";
    b.innerHTML = (cur.muted ? ICON.micoff : ICON.mic) + "<span>" + (cur.muted ? "Ativar mic" : "Mudo") + "</span>";
  }

  function toggleCam(b) {
    if (!cur || !cur.stream) return;
    var vt = cur.stream.getVideoTracks();
    if (!vt.length) { toast(camError()); return; }
    cur.camOff = !cur.camOff;
    vt.forEach(function (t) { t.enabled = !cur.camOff; });
    els.ov.classList.toggle("cl-cam-off", !!cur.camOff);
    b.classList.toggle("on", !!cur.camOff);
    b.setAttribute("aria-pressed", cur.camOff ? "true" : "false");
    b.innerHTML = (cur.camOff ? ICON.camoff : ICON.cam) + "<span>" + (cur.camOff ? "Ligar câmera" : "Câmera") + "</span>";
  }
  function flipCam() {           // alterna entre as câmeras (celular: frontal/traseira; desktop: próxima)
    var me = cur;
    if (!me || !me.stream || me.flipping) return;
    var old = me.stream.getVideoTracks()[0];
    if (!old) { toast(camError()); return; }
    me.flipping = true;
    navigator.mediaDevices.enumerateDevices().then(function (list) {
      var cams = list.filter(function (d) { return d.kind === "videoinput"; });
      if (cams.length < 2) { toast("Só há uma câmera neste aparelho."); throw { silent: true }; }
      var curId = (old.getSettings && old.getSettings().deviceId) || "";
      var i = 0;
      cams.forEach(function (c, k) { if (c.deviceId === curId) i = k; });
      var next = cams[(i + 1) % cams.length];
      var v = { width: VIDEO_C.width, height: VIDEO_C.height, frameRate: VIDEO_C.frameRate, deviceId: { exact: next.deviceId } };
      return navigator.mediaDevices.getUserMedia({ audio: false, video: v });
    }).then(function (ns) {
      var nt = ns.getVideoTracks()[0];
      if (cur !== me || !nt) { if (nt) nt.stop(); return; }
      nt.enabled = !me.camOff;
      var sender = me.pc && me.pc.getSenders().filter(function (sd) { return sd.track && sd.track.kind === "video"; })[0];
      return (sender ? sender.replaceTrack(nt) : Promise.resolve()).then(function () {
        me.stream.removeTrack(old); old.stop(); me.stream.addTrack(nt);
        showLocal();
      });
    }).catch(function (e) { if (!e || !e.silent) toast("Não foi possível trocar a câmera."); })
      .then(function () { me.flipping = false; });
  }
  function toggleFull() {
    try {
      if (document.fullscreenElement) document.exitFullscreen();
      else if (els.ov.requestFullscreen) els.ov.requestFullscreen().catch(noop);
    } catch (e) {}
  }

  function toast(t) {
    var el = document.getElementById("cl-toast");
    if (!el) { el = document.createElement("div"); el.id = "cl-toast"; el.className = "cl-toast"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    el.textContent = t; el.hidden = false;
    clearTimeout(el._t); el._t = setTimeout(function () { el.hidden = true; }, 4500);
  }

  /* ---------- eventos ao vivo ---------- */
  L.on("call_incoming", incoming);
  L.on("call_signal", function (d) {
    if (!cur || !d || d.call_id !== cur.id || !cur.pc) return;
    if (d.kind === "answer") applyAnswer(d.answer);
    else if (d.kind === "ice") addRemoteIce(d.candidate);
  });
  L.on("call_state", function (d) {
    if (!d || !cur || d.call_id !== cur.id) return;
    if (ENDED[d.state]) { finish(endText(d), cur.state === "incoming" && cur.role === "callee" && d.by && d.state !== "missed"); return; }
    if (d.state === "accepted") {
      if (cur.role === "callee" && cur.state === "incoming" && !cur.answering) finish("", true);   // atendida em outra aba/aparelho
      else if (cur.role === "caller" && cur.state === "calling") { status("Conectando…"); }
    }
  });
  L.on("resync", function () { if (cur && cur.id) poll(); });

  /* ---------- botão de ligar (delegação) ---------- */
  document.addEventListener("click", function (ev) {
    var b = ev.target.closest && ev.target.closest("[data-call-user]");
    if (!b) return;
    ev.preventDefault();
    start(b.getAttribute("data-call-user"), b.getAttribute("data-call-name"), b.getAttribute("data-call-avatar"), b.getAttribute("data-call-media"));
  });

  /* ---------- sair da página = desligar (senão o servidor espera o "stale") ---------- */
  window.addEventListener("pagehide", function () {
    if (!cur || !cur.id) return;
    try { fetch("/api/v1/calls/" + cur.id + "/end", { method: "POST", keepalive: true, credentials: "same-origin", headers: { "X-Requested-With": "fetch", "Content-Type": "application/json" }, body: "{}" }); } catch (e) {}
  });

  /* ---------- ao abrir a página: retomar toque ou limpar chamada órfã ---------- */
  function resume() {
    C.active().then(function (call) {
      if (!call || cur) return;
      if (call.state === "ringing" && call.direction === "incoming") {
        incoming({ call_id: call.id, partner: call.partner && call.partner.username, media: call.media, offer: call.offer, ring_seconds: call.ring_seconds });
        return;
      }
      if (ownerFresh(call.id)) return;       // outra aba conduz essa chamada
      C.end(call.id).catch(noop);
      toast("Uma chamada anterior foi encerrada ao recarregar a página.");
    }).catch(noop);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", resume); else resume();

  window.driqyCallUI = { start: start, busy: function () { return !!cur; }, supported: supported };
})();
