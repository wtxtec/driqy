/* Coluna direita: seletor que pula entre widgets.
   Cada widget se registra com:
     DriqyRail.register({ id, title, render(bodyEl, ctx) })
   `render` desenha dentro de bodyEl (pode ser assíncrono). `ctx.isActive()` diz se o widget
   ainda é o que está na tela (use antes de escrever depois de um await/fetch).
   Pular: setas ‹ ›, bolinhas e o botão de grade (menu com todos os widgets). */
(function () {
  "use strict";
  var rail = document.getElementById("rail");
  if (document.body.classList.contains("rail-off")) return; // painel escondido pelo usuário
  var body = document.getElementById("rail-widget-body");
  if (!rail || !body) return;
  var titleEl = document.getElementById("rail-widget-title");
  var dotsEl = document.getElementById("rail-widget-dots");
  var prev = document.getElementById("rail-widget-prev");
  var next = document.getElementById("rail-widget-next");
  var menuBtn = document.getElementById("rail-widget-menu-btn");
  var menu = document.getElementById("rail-widget-menu");
  var editBtn = document.getElementById("rail-widget-edit");
  var editing = false;
  var registry = [];
  var widgets = [];
  var current = -1;
  var token = 0;
  var STORE = "driqy-rail-widget";

  function savedId() {
    try { return localStorage.getItem(STORE); } catch (e) { return null; }
  }

  function show(i) {
    if (!widgets.length) return;
    current = (i + widgets.length) % widgets.length;
    var w = widgets[current];
    var mine = ++token;
    titleEl.textContent = w.title;
    body.innerHTML = "";
    try {
      w.render(body, { isActive: function () { return token === mine; } });
    } catch (e) {
      body.innerHTML = '<p class="hint rail-empty">Não consegui carregar este widget.</p>';
    }
    syncActive();
    try { localStorage.setItem(STORE, w.id); } catch (e) {}
  }

  function indexOfId(id) {
    for (var i = 0; i < widgets.length; i++) if (widgets[i].id === id) return i;
    return -1;
  }

  function syncActive() {
    var dots = dotsEl.querySelectorAll(".rail-dot");
    for (var d = 0; d < dots.length; d++) {
      dots[d].classList.toggle("active", d === current);
      dots[d].setAttribute("aria-selected", d === current ? "true" : "false");
    }
    var items = menu.querySelectorAll(".rail-widget-menu-item");
    for (var m = 0; m < items.length; m++) items[m].classList.toggle("active", m === current);
  }

  function closeMenu() {
    menu.hidden = true;
    menuBtn.setAttribute("aria-expanded", "false");
  }

  function build() {
    if (editing) return;
    dotsEl.innerHTML = "";
    menu.innerHTML = "";
    widgets.forEach(function (w, i) {
      var dot = document.createElement("button");
      dot.type = "button";
      dot.className = "rail-dot";
      dot.setAttribute("role", "tab");
      dot.setAttribute("aria-label", w.title);
      dot.addEventListener("click", function () { show(i); });
      dotsEl.appendChild(dot);

      var item = document.createElement("button");
      item.type = "button";
      item.className = "rail-widget-menu-item";
      item.setAttribute("role", "menuitem");
      item.textContent = w.title;
      item.addEventListener("click", function () { closeMenu(); show(i); });
      menu.appendChild(item);
    });
    var multi = widgets.length > 1;
    prev.hidden = next.hidden = menuBtn.hidden = dotsEl.hidden = !multi;
    if (!multi) closeMenu();
  }

  prev.addEventListener("click", function () { show(current - 1); });
  next.addEventListener("click", function () { show(current + 1); });
  menuBtn.addEventListener("click", function (e) {
    e.stopPropagation();
    var open = menu.hidden;
    menu.hidden = !open;
    menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
  });
  document.addEventListener("click", function (e) {
    if (!menu.hidden && !menu.contains(e.target)) closeMenu();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeMenu();
  });
  prev.hidden = next.hidden = menuBtn.hidden = dotsEl.hidden = true;

  var started = false;

  // Personalização do usuário (rail-customize.js / servidor): tira os removidos e segue a ordem escolhida.
  function applyPrefs() {
    var prefs = (window.__railCfg && window.__railCfg.prefs) || {};
    var disabled = prefs.disabled || [], order = prefs.order || [];
    widgets = registry.filter(function (w) { return disabled.indexOf(w.id) < 0; });
    widgets.sort(function (a, b) {
      var ia = order.indexOf(a.id), ib = order.indexOf(b.id);
      return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib);
    });
    build();
  }

  // Os scripts dos widgets carregam em sequência; o primeiro desenho só acontece depois de todos
  // se registrarem (evita buscar o clima de novo a cada registro) e já abre o último widget usado.
  function renderEmpty() {
    current = -1;
    token++;
    titleEl.textContent = "Widgets";
    body.innerHTML = '<p class="hint rail-empty">Nenhum widget no painel. Use o lápis para adicionar.</p>';
  }

  // Depois de editar: reaplica as preferências (sem recarregar a página) e volta ao widget que estava aberto.
  function reapply(prefs, keepId) {
    if (prefs && window.__railCfg) window.__railCfg.prefs = prefs;
    applyPrefs();
    if (!widgets.length) { renderEmpty(); return; }
    var idx = 0;
    for (var i = 0; i < widgets.length; i++) if (widgets[i].id === keepId) idx = i;
    show(idx);
  }

  // Modo editar: `fn(bodyEl, done)` desenha o editor no corpo do cartão; `done(novasPrefs|null)` volta ao normal.
  function openEditor(fn) {
    if (editing) return;
    var keep = widgets[current] && widgets[current].id;
    token++;
    editing = true;
    closeMenu();
    prev.hidden = next.hidden = menuBtn.hidden = dotsEl.hidden = true;
    if (editBtn) editBtn.hidden = true;
    titleEl.textContent = "Editar widgets";
    body.innerHTML = "";
    fn(body, function done(newPrefs) {
      editing = false;
      if (editBtn) editBtn.hidden = false;
      reapply(newPrefs, keep);
    });
  }

  function start() {
    started = true;
    applyPrefs();
    if (!widgets.length) { renderEmpty(); return; }
    var saved = savedId(), idx = 0;
    for (var i = 0; i < widgets.length; i++) if (widgets[i].id === saved) idx = i;
    show(idx);
  }

  window.DriqyRail = {
    register: function (w) {
      registry.push(w);
      if (editing) return;
      var curId = current >= 0 && widgets[current] ? widgets[current].id : null;
      applyPrefs();
      if (!started) { clearTimeout(window.DriqyRail._t); window.DriqyRail._t = setTimeout(start, 0); }
      else if (current < 0) { if (widgets.length) show(0); }
      else { var k = indexOfId(curId); if (k >= 0) current = k; syncActive(); }
    },
    // widgets criados/apagados em tempo de execução ("Minha área")
    unregister: function (id) {
      var curId = current >= 0 && widgets[current] ? widgets[current].id : null;
      registry = registry.filter(function (w) { return w.id !== id; });
      applyPrefs();
      if (editing) return;
      if (!widgets.length) { renderEmpty(); return; }
      if (curId === id) { show(Math.min(Math.max(current, 0), widgets.length - 1)); return; }
      var k = indexOfId(curId); if (k >= 0) current = k; syncActive();
    },
    rename: function (id, title) {
      for (var i = 0; i < registry.length; i++) if (registry[i].id === id) registry[i].title = title;
      if (editing) return;
      build();
      if (current >= 0 && widgets[current] && widgets[current].id === id) titleEl.textContent = title;
      syncActive();
    },
    showId: function (id) { var k = indexOfId(id); if (k >= 0 && !editing) show(k); },
    openEditor: openEditor,
    // para os widgets lerem urls do servidor (data-*) sem repetir getElementById
    config: function (name) { return rail.getAttribute("data-" + name) || ""; }
  };
})();
