/* Chat em tempo real (Fase 9) — UMA conexão SSE por navegador.
 *
 * Navegadores limitam ~6 conexões HTTP/1.1 por site; se cada aba abrisse a sua, abas
 * demais travariam o site. Então as abas disputam um Web Lock ("driqy-chat-stream"): a
 * vencedora (líder) abre o EventSource e repassa cada evento às outras pelo
 * BroadcastChannel. Se a líder fechar, outra assume sozinha.
 * Sem Web Locks/BroadcastChannel (navegador antigo): só as páginas do chat abrem a
 * própria conexão. Se o stream não funcionar (servidor sem SSE), `connected()` fica
 * falso e quem usa continua no polling.
 *
 *   window.driqyLive.on("message", (data) => {...})        // data.partner = @ do outro lado
 *   window.driqyLive.on(["message","update"], fn)
 *   window.driqyLive.connected()
 * Tipos: ready, message, update, read, read_self, delivered, typing, resync,
 * prefs (Fase 10: fixar/silenciar/arquivar mudou), presence (Fase 10: online/visto por último),
 * group (Mensagens parte 4: {group_id, kind}; kind = message|update|members|info|prefs|read|removed|typing).
 */
(function () {
  if (window.driqyLive) return;
  var tag = document.currentScript;
  var URL_ = tag && tag.dataset.streamUrl;
  if (!URL_ || !window.EventSource) { window.driqyLive = { on: function () {}, connected: function () { return false; } }; return; }

  var listeners = {};
  var up = false;          // este documento sabe que há stream vivo (próprio ou do líder)
  var lastBeat = 0;
  var EVENTS = ["ready", "message", "update", "read", "read_self", "delivered", "typing", "resync", "prefs", "presence", "call_incoming", "call_signal", "call_state", "group"];
  var bc = null;
  try { bc = window.BroadcastChannel ? new BroadcastChannel("driqy-chat-live") : null; } catch (e) { bc = null; }

  function emit(type, data) {
    (listeners[type] || []).concat(listeners["*"] || []).forEach(function (fn) {
      try { fn(data || {}, type); } catch (e) { /* um ouvinte ruim não derruba os outros */ }
    });
  }
  function setUp(v) { up = v; lastBeat = Date.now(); }

  var live = {
    on: function (types, fn) {
      [].concat(types).forEach(function (t) { (listeners[t] = listeners[t] || []).push(fn); });
    },
    connected: function () { return up && (Date.now() - lastBeat < 45000); },
  };
  window.driqyLive = live;

  var es = null, leader = false, beat = null;
  function post(msg) { if (bc) { try { bc.postMessage(msg); } catch (e) {} } }

  function open() {
    if (es) return;
    es = new EventSource(URL_, { withCredentials: true });
    EVENTS.forEach(function (t) {
      es.addEventListener(t, function (ev) {
        var data = {};
        try { data = JSON.parse(ev.data || "{}"); } catch (e) {}
        if (t === "ready") setUp(true);
        emit(t, data);
        post({ t: t, d: data });
      });
    });
    es.onerror = function () {          // o navegador reconecta sozinho; enquanto isso: polling
      setUp(false); post({ state: false });
      if (es && es.readyState === 2) { es.close(); es = null; if (leader) setTimeout(open, 5000); }
    };
    if (!beat) beat = setInterval(function () { if (up) { lastBeat = Date.now(); post({ state: true }); } }, 20000);
  }

  if (bc) {
    bc.onmessage = function (ev) {
      var m = ev.data || {};
      if (leader) return;
      if (m.state !== undefined) { setUp(!!m.state); return; }
      if (m.t) { setUp(true); emit(m.t, m.d); }
    };
  }

  var onChatPage = !!document.getElementById("cw") || !!document.getElementById("chat-inbox-list");
  if (navigator.locks && bc) {
    navigator.locks.request("driqy-chat-stream", function () {
      leader = true;
      open();
      return new Promise(function () {});   // segura o lock até a aba fechar
    });
  } else if (onChatPage) {
    leader = true;
    open();
  }
  window.addEventListener("pagehide", function () { if (es) { es.close(); es = null; } });
})();
