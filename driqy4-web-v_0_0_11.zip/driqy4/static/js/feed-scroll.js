/*
 * Feed global: rolagem infinita.
 *
 * Mesmo padrão do news.js / vortex.js — um sentinela invisível no fim da
 * lista dispara o carregamento da próxima leva assim que entra (ou está
 * perto de entrar) na tela, sem precisar de botão "carregar mais" nem de
 * paginação clássica por número de página.
 */
(function () {
  const list = document.getElementById("feed-list");
  const sentinel = document.getElementById("feed-sentinel");
  if (!list || !sentinel) return;

  const moreUrl = sentinel.dataset.moreUrl;
  const spinnerEl = sentinel.querySelector(".vortex-sentinel-spinner");
  const endEl = sentinel.querySelector(".vortex-sentinel-end");

  let loading = false;

  function showState(state) {
    if (spinnerEl) spinnerEl.hidden = state !== "loading";
    if (endEl) endEl.hidden = state !== "end";
  }

  function loadMore() {
    const cursor = sentinel.dataset.nextCursor;
    if (loading || !cursor || !moreUrl) return;
    loading = true;

    const spinnerTimer = setTimeout(() => showState("loading"), 400);

    fetch(`${moreUrl}?cursor=${encodeURIComponent(cursor)}`, {
      headers: { "X-Requested-With": "fetch" },
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(res)))
      .then((data) => {
        const template = document.createElement("template");
        (data.posts || []).forEach((html) => {
          template.innerHTML = html.trim();
          const card = template.content.firstElementChild;
          if (!card) return;
          list.appendChild(card);
          if (window.driqySetupPostCard) window.driqySetupPostCard(card);
        });

        if (data.has_next && data.next_cursor) {
          sentinel.dataset.nextCursor = data.next_cursor;
          showState("idle");
        } else {
          sentinel.dataset.nextCursor = "";
          showState("end");
        }
      })
      .catch(() => showState("idle"))
      .finally(() => {
        clearTimeout(spinnerTimer);
        loading = false;
      });
  }

  const scrollObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) loadMore();
      });
    },
    // margem grande: começa a buscar a próxima leva bem antes do
    // sentinela aparecer de verdade na tela, pra rolagem rápida no
    // desktop (tela grande, scroll rápido com mouse/trackpad) nunca
    // alcançar o fim do que já foi carregado.
    { rootMargin: "3000px 0px" }
  );
  scrollObserver.observe(sentinel);
})();
