/* Sugestões de cidade/estado/país enquanto o usuário digita (perfil e widget de clima).
   Usa GET /api/v1/places/search?q=. Todo texto vindo do servidor entra via textContent. */
(function () {
  "use strict";

  var MIN_CHARS = 2;
  var DELAY_MS = 250;

  function attach(input, opts) {
    opts = opts || {};
    var url = opts.url || input.getAttribute("data-places-url");
    if (!input || !url) return null;

    var wrap = input.parentNode;
    if (getComputedStyle(wrap).position === "static") wrap.style.position = "relative";
    var list = document.createElement("ul");
    list.className = "place-suggest";
    list.setAttribute("role", "listbox");
    list.hidden = true;
    input.insertAdjacentElement("afterend", list);
    input.setAttribute("autocomplete", "off");
    input.setAttribute("aria-autocomplete", "list");

    var timer = null, seq = 0, items = [], active = -1;

    function close() { list.hidden = true; active = -1; }

    function highlight(i) {
      active = i;
      Array.prototype.forEach.call(list.children, function (li, n) {
        li.classList.toggle("is-active", n === i);
        li.setAttribute("aria-selected", n === i ? "true" : "false");
      });
    }

    function choose(place) {
      close();
      if (opts.onSelect) opts.onSelect(place);
    }

    function render(places, query) {
      items = places;
      list.innerHTML = "";
      if (!places.length) {
        var empty = document.createElement("li");
        empty.className = "place-suggest-empty";
        empty.textContent = "Nenhuma cidade encontrada para “" + query + "”.";
        list.appendChild(empty);
      }
      places.forEach(function (p, i) {
        var li = document.createElement("li");
        li.className = "place-suggest-item";
        li.setAttribute("role", "option");
        var name = document.createElement("strong");
        name.textContent = p.name;
        var rest = document.createElement("span");
        rest.textContent = [p.admin1, p.country].filter(Boolean).join(", ");
        li.appendChild(name);
        li.appendChild(rest);
        // mousedown (não click) para escolher antes do input perder o foco
        li.addEventListener("mousedown", function (e) { e.preventDefault(); choose(p); });
        li.addEventListener("mouseenter", function () { highlight(i); });
        list.appendChild(li);
      });
      list.hidden = false;
      active = -1;
    }

    function search() {
      var q = input.value.trim();
      if (q.length < MIN_CHARS) { close(); return; }
      var mine = ++seq;
      fetch(url + (url.indexOf("?") < 0 ? "?" : "&") + "q=" + encodeURIComponent(q),
            { credentials: "same-origin", headers: { Accept: "application/json" } })
        .then(function (r) { return r.ok ? r.json() : { places: [] }; })
        .catch(function () { return { places: [] }; })
        .then(function (d) {
          if (mine !== seq || document.activeElement !== input) return; // resposta velha / campo sem foco
          render(d.places || [], q);
        });
    }

    input.addEventListener("input", function () {
      if (opts.onType) opts.onType();
      clearTimeout(timer);
      timer = setTimeout(search, DELAY_MS);
    });
    input.addEventListener("focus", function () { if (input.value.trim().length >= MIN_CHARS && !items.length) search(); });
    input.addEventListener("blur", function () { setTimeout(close, 120); });
    input.addEventListener("keydown", function (e) {
      if (list.hidden || !items.length) return;
      if (e.key === "ArrowDown") { e.preventDefault(); highlight((active + 1) % items.length); }
      else if (e.key === "ArrowUp") { e.preventDefault(); highlight((active - 1 + items.length) % items.length); }
      else if (e.key === "Enter" && active >= 0) { e.preventDefault(); choose(items[active]); }
      else if (e.key === "Escape") { close(); }
    });

    return { close: close };
  }

  window.DriqyPlacePicker = { attach: attach };
})();
