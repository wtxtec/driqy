/*
 * Caixa de publicação rápida no topo do feed ("O que está acontecendo?").
 * Cuida de: auto-crescer o textarea, anexar mídia com prévia (fotos, vídeos
 * ou GIFs, detectando o tipo do post pela extensão do arquivo), escolher a
 * duração do post (com um painel fluido de abrir/fechar) e habilitar o
 * botão de postar só quando há conteúdo válido. Anexar uma mídia apenas
 * monta a prévia — o post só é publicado quando a pessoa clica em "Postar".
 */
(function () {
  document.addEventListener("DOMContentLoaded", () => {
    const card = document.getElementById("composer");
    if (!card) return; // página sem composer (ex: usuário não logado)

    const form = document.getElementById("composer-form");
    const textArea = document.getElementById("composer-text");
    const postTypeInput = document.getElementById("composer-post-type");
    const durationInput = document.getElementById("composer-duration-input");
    const durationLabel = document.getElementById("composer-duration-label");
    const durationBtn = document.getElementById("composer-duration-btn");
    const durationPanel = document.getElementById("composer-duration-panel");
    const durationBackdrop = document.getElementById("composer-duration-backdrop");
    const durationCloseBtn = document.getElementById("composer-duration-close");
    const postBtn = document.getElementById("composer-post-btn");
    const charCount = document.getElementById("composer-char-count");
    const errorEl = document.getElementById("composer-error");

    const mediaFileInput = document.getElementById("composer-media-file");
    const mediaPreview = document.getElementById("composer-media-preview");

    const attachBtn = document.getElementById("composer-attach-btn");

    const MAX_MEDIA_ITEMS = 10;
    let hasMedia = false;

    // ---------- Textarea que cresce sozinho ----------
    function autoGrow() {
      textArea.style.height = "auto";
      textArea.style.height = textArea.scrollHeight + "px";
    }

    function showError(msg) {
      if (!errorEl) return;
      errorEl.textContent = msg || "";
      errorEl.hidden = !msg;
    }

    // O botão "Postar" fica sempre aceso (igual ao app); a validação de
    // conteúdo vazio acontece no envio, com uma mensagem embaixo.
    function updatePostState() {
      if (textArea.value.trim().length > 0 || hasMedia) showError("");

      const len = textArea.value.length;
      if (len > 800) {
        charCount.hidden = false;
        charCount.textContent = (1000 - len).toString();
        charCount.classList.toggle("warn", len >= 1000);
      } else {
        charCount.hidden = true;
      }
    }

    textArea.addEventListener("input", () => {
      autoGrow();
      updatePostState();
    });

    // ---------- Painel de duração ----------
    // Desktop: popover flutuante ancorado no botão. Mobile (<=640px): folha
    // (bottom sheet) que sobe do rodapé, com fundo escurecido e trava de
    // scroll — muito mais fácil de ler e tocar do que uma fileira horizontal
    // com setinhas escondidas.
    const isMobileSheet = () => window.matchMedia("(max-width: 640px)").matches;

    function closeDurationPanel() {
      if (!durationPanel) return;
      durationPanel.classList.remove("open");
      durationPanel.setAttribute("aria-hidden", "true");
      if (durationBackdrop) durationBackdrop.classList.remove("open");
      if (durationBtn) durationBtn.setAttribute("aria-expanded", "false");
      document.body.classList.remove("composer-duration-lock-scroll");
    }

    function openDurationPanel() {
      if (!durationPanel) return;
      durationPanel.classList.add("open");
      durationPanel.setAttribute("aria-hidden", "false");
      if (durationBackdrop) durationBackdrop.classList.add("open");
      if (durationBtn) durationBtn.setAttribute("aria-expanded", "true");
      if (isMobileSheet()) document.body.classList.add("composer-duration-lock-scroll");

      // Leva a opção selecionada pra dentro da área visível, pra quem tem
      // muitas opções não precisar rolar até achar o valor atual.
      const selected = durationPanel.querySelector(".composer-duration-opt.selected");
      if (selected) selected.scrollIntoView({ block: "nearest" });
    }

    function toggleDurationPanel() {
      if (!durationPanel) return;
      if (durationPanel.classList.contains("open")) closeDurationPanel();
      else openDurationPanel();
    }

    document.addEventListener("click", (e) => {
      if (!card.contains(e.target)) closeDurationPanel();
    });

    if (durationBackdrop) {
      durationBackdrop.addEventListener("click", closeDurationPanel);
    }
    if (durationCloseBtn) {
      durationCloseBtn.addEventListener("click", closeDurationPanel);
    }
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeDurationPanel();
    });
    window.addEventListener("resize", closeDurationPanel);

    // ---------- Anexar mídia (fotos, vídeos ou GIFs — até 10 por post) ----------
    // Só monta a prévia; a publicação só acontece quando a pessoa clicar em
    // "Postar" (antes disso, dá pra revisar/remover/ouvir qualquer item).
    window.driqyAttachMediaPicker({
      fileInput: mediaFileInput,
      previewContainer: mediaPreview,
      counterEl: null,
      maxItems: MAX_MEDIA_ITEMS,
      onChange: (count) => {
        hasMedia = count > 0;
        postTypeInput.value = hasMedia ? "media" : "text";
        updatePostState();
      },
      onLimit: (max) => {
        alert(`Você pode anexar no máximo ${max} itens por post.`);
      },
    });

    if (attachBtn) {
      attachBtn.addEventListener("click", () => mediaFileInput.click());
    }

    // ---------- Duração ----------
    if (durationBtn && durationPanel) {
      durationBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleDurationPanel();
      });
      durationPanel.addEventListener("click", (e) => {
        const btn = e.target.closest(".composer-duration-opt");
        if (!btn) return;
        const label = btn.querySelector(".opt-label")?.textContent || btn.textContent;
        durationPanel.querySelectorAll(".composer-duration-opt").forEach((b) => b.classList.remove("selected"));
        btn.classList.add("selected");
        durationInput.value = btn.dataset.minutes;
        durationLabel.textContent = btn.dataset.minutes ? "Some em " + label.toLowerCase() : "Sem expiração";
        closeDurationPanel();
      });
    }

    // ---------- Confirmação do tempo no ar antes de publicar ----------
    // Ninguém publica sem antes ver e confirmar por quanto tempo o post vai
    // ficar visível — só depois disso o formulário é enviado de verdade.
    form.addEventListener("submit", (e) => {
      if (form.dataset.confirmed === "1") {
        postBtn.disabled = true;
        postBtn.textContent = "Publicando…";
        return; // já confirmado: deixa o envio nativo seguir
      }

      e.preventDefault();

      if (textArea.value.trim().length === 0 && !hasMedia) {
        showError("Escreva algo ou selecione uma foto/vídeo para publicar.");
        return;
      }

      const minutes = parseInt(durationInput.value, 10);
      const label = durationLabel ? durationLabel.textContent.replace(/^Some em\s*/i, "") : null;

      // Post permanente (sem duração escolhida): não precisa de confirmação.
      if (!minutes) {
        form.dataset.confirmed = "1";
        postBtn.disabled = true;
        postBtn.textContent = "Publicando…";
        if (form.requestSubmit) form.requestSubmit();
        else form.submit();
        return;
      }

      window.driqyPublishConfirm.confirmPublish(minutes, { label }).then((confirmed) => {
        if (!confirmed) return;
        form.dataset.confirmed = "1";
        postBtn.disabled = true;
        postBtn.textContent = "Publicando…";
        if (form.requestSubmit) form.requestSubmit();
        else form.submit();
      });
    });

    updatePostState();
  });
})();
