/*
 * Carrossel de mídia dentro do próprio card do post (feed, perfil, post
 * único). Quando o post tem mais de uma foto/vídeo, elas aparecem como
 * slides — arrasta/rola pros lados (ou usa as setas/bolinhas) pra ver as
 * outras, sem precisar abrir nada em tela cheia.
 */
(function () {
  function setupCarousel(el) {
    if (!el || el.dataset.carouselReady) return;
    el.dataset.carouselReady = "1";

    const track = el.querySelector(".post-carousel-track");
    const slides = Array.from(el.querySelectorAll(".post-carousel-slide"));
    if (!track || slides.length <= 1) return;

    const prevBtn = el.querySelector(".post-carousel-nav.prev");
    const nextBtn = el.querySelector(".post-carousel-nav.next");
    const dots = Array.from(el.querySelectorAll(".post-carousel-dot"));
    const counter = el.querySelector(".post-carousel-counter");

    function currentIndex() {
      const slideWidth = track.clientWidth || 1;
      return Math.round(track.scrollLeft / slideWidth);
    }

    function updateUI() {
      const idx = Math.min(slides.length - 1, Math.max(0, currentIndex()));
      dots.forEach((d, i) => d.classList.toggle("active", i === idx));
      if (counter) counter.textContent = (idx + 1) + " / " + slides.length;
      if (prevBtn) prevBtn.disabled = idx <= 0;
      if (nextBtn) nextBtn.disabled = idx >= slides.length - 1;
    }

    function goTo(index) {
      const clamped = Math.min(slides.length - 1, Math.max(0, index));
      track.scrollTo({ left: clamped * track.clientWidth, behavior: "smooth" });
    }

    if (prevBtn) {
      prevBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        goTo(currentIndex() - 1);
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        goTo(currentIndex() + 1);
      });
    }
    dots.forEach((dot, i) => {
      dot.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        goTo(i);
      });
    });

    let scrollRaf = null;
    track.addEventListener("scroll", () => {
      if (scrollRaf) return;
      scrollRaf = window.requestAnimationFrame(() => {
        updateUI();
        scrollRaf = null;
      });
    });

    // evita que arrastar o carrossel dispare a navegação pro post inteiro
    let downX = 0, downY = 0, wasDrag = false;
    track.addEventListener("pointerdown", (e) => {
      downX = e.clientX;
      downY = e.clientY;
      wasDrag = false;
    });
    track.addEventListener("pointermove", (e) => {
      if (Math.abs(e.clientX - downX) > 6 || Math.abs(e.clientY - downY) > 6) wasDrag = true;
    });
    track.addEventListener("click", (e) => {
      if (wasDrag) {
        e.preventDefault();
        e.stopPropagation();
      }
    });

    window.addEventListener("resize", () => goTo(currentIndex()));

    updateUI();
  }

  function setupCard(scope) {
    (scope || document).querySelectorAll(".post-carousel").forEach(setupCarousel);
  }

  window.driqyPostCarousel = { setupCard };

  document.addEventListener("DOMContentLoaded", () => setupCard(document));
})();
