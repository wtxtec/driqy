/* Fase 14 — página "Chamadas": histórico (GET /api/v1/calls via driqyCalls.history) + ligar de volta
 * (delegação de call-ui.js: qualquer elemento com data-call-user liga). */
(function () {
  "use strict";
  var list = document.getElementById("calls-history");
  var more = document.getElementById("calls-more");
  if (!list || !window.driqyCalls) return;
  var lastId = null, loading = false, first = true;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function dur(s) { s = Math.max(0, s | 0); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
  function when(iso) {
    if (!iso) return "";
    var d = new Date(iso), n = new Date();
    var hm = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    var y = new Date(n); y.setDate(n.getDate() - 1);
    if (d.toDateString() === n.toDateString()) return "Hoje, " + hm;
    if (d.toDateString() === y.toDateString()) return "Ontem, " + hm;
    return d.toLocaleDateString("pt-BR") + ", " + hm;
  }
  function status(c) {
    var out = c.direction === "outgoing", kind = c.media === "video" ? "vídeo" : "voz";
    switch (c.state) {
      case "ended": return ["Chamada de " + kind + " · " + dur(c.duration_s), false];
      case "declined": return [out ? "Recusada" : "Você recusou", false];
      case "missed": return [out ? "Sem resposta" : "Perdida", !out];
      case "busy": return [out ? "Ocupado" : "Perdida", !out];
      case "failed": return ["Falhou", false];
      case "ringing": case "accepted": return ["Em andamento", false];
      default: return ["", false];
    }
  }
  function row(c) {
    var p = c.partner || {}, st = status(c), out = c.direction === "outgoing";
    var li = el("div", "calls-row" + (st[1] ? " missed" : ""));
    var av = el("a", "calls-avatar"); av.href = "/mensagens/" + encodeURIComponent(p.username || "");
    if (p.avatar_url) { var im = document.createElement("img"); im.src = p.avatar_url; im.alt = ""; av.appendChild(im); }
    else av.textContent = ((p.display_name || p.username || "?")[0] || "?").toUpperCase();
    var mid = el("div", "calls-mid");
    mid.appendChild(el("strong", null, p.display_name || p.username || ""));
    mid.appendChild(el("span", "post-meta", (st[1] ? "↙ " : out ? "↗ " : "↙ ") + st[0] + " · " + when(c.created_at)));
    var b = el("button", "cw-call-back", c.media === "video" ? "📹 Ligar" : "📞 Ligar");
    b.type = "button"; b.setAttribute("aria-label", "Ligar de volta para " + (p.display_name || p.username));
    b.dataset.callUser = p.username || ""; b.dataset.callName = p.display_name || p.username || "";
    b.dataset.callAvatar = p.avatar_url || "";
    if (c.media === "video") b.dataset.callMedia = "video";
    li.append(av, mid, b);
    return li;
  }
  function load() {
    if (loading) return; loading = true;
    window.driqyCalls.history(30, lastId || undefined).then(function (d) {
      if (first) { list.textContent = ""; first = false; }
      (d.calls || []).forEach(function (c) { list.appendChild(row(c)); lastId = c.id; });
      if (!list.children.length) list.appendChild(el("p", "post-meta", "Nenhuma chamada ainda."));
      more.hidden = !d.has_more;
    }).catch(function () {
      if (first) { list.textContent = ""; list.appendChild(el("p", "post-meta", "Não foi possível carregar as chamadas.")); }
    }).then(function () { loading = false; });
  }
  more.addEventListener("click", load);
  load();
})();
