/* Curtir dentro da imagem (página de um item do Vortex): manda o sinal "like" e acende o coração. */
(function () {
  "use strict";
  var btn = document.querySelector(".vortex-item-like");
  if (!btn) return;
  btn.addEventListener("click", function () {
    if (btn.classList.contains("is-liked")) return;
    var id = parseInt(btn.getAttribute("data-item-id"), 10);
    if (!id) return;
    btn.classList.add("is-liked");
    btn.setAttribute("aria-pressed", "true");
    btn.setAttribute("aria-label", "Curtido");
    try {
      fetch("/api/pictures/interact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ kind: "like", item_id: id }),
        keepalive: true
      }).catch(function () {});
    } catch (e) {}
  });
})();
