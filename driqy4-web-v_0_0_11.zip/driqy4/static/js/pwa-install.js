/*
 * Convite de instalação do app (PWA). Não existe forma de instalar sem
 * nenhuma ação do usuário — isso é bloqueado pelo próprio navegador por
 * segurança. O que dá pra fazer:
 *  - Android/Chrome: capturamos o evento de instalação e mostramos nosso
 *    próprio botão, que dispara o prompt nativo com 1 toque.
 *  - iPhone/Safari: não existe API de instalação nenhuma; só resta guiar
 *    a pessoa pelo caminho manual (Compartilhar > Adicionar à Tela de Início).
 */
(function () {
  const DISMISS_KEY = "driqy-install-dismissed-at";
  const DISMISS_DAYS = 10;

  function alreadyInstalled() {
    return (
      window.matchMedia("(display-mode: standalone)").matches ||
      window.navigator.standalone === true
    );
  }

  function recentlyDismissed() {
    const raw = localStorage.getItem(DISMISS_KEY);
    if (!raw) return false;
    const elapsedDays = (Date.now() - Number(raw)) / (1000 * 60 * 60 * 24);
    return elapsedDays < DISMISS_DAYS;
  }

  function dismiss(banner) {
    try {
      localStorage.setItem(DISMISS_KEY, String(Date.now()));
    } catch (e) {}
    banner.classList.remove("visible");
    setTimeout(() => banner.remove(), 250);
  }

  function buildBanner({ title, subtitle, actionLabel, onAction }) {
    const banner = document.createElement("div");
    banner.className = "install-banner";
    banner.innerHTML = `
      <img class="install-banner-icon" src="/static/icons/android-icon-96x96.png" alt="">
      <div class="install-banner-text">
        <strong>${title}</strong>
        <span>${subtitle}</span>
      </div>
      <div class="install-banner-actions">
        ${actionLabel ? `<button type="button" class="install-banner-btn">${actionLabel}</button>` : ""}
        <button type="button" class="install-banner-close" aria-label="Fechar">✕</button>
      </div>
    `;
    document.body.appendChild(banner);
    requestAnimationFrame(() => banner.classList.add("visible"));

    banner.querySelector(".install-banner-close").addEventListener("click", () => dismiss(banner));
    if (actionLabel && onAction) {
      banner.querySelector(".install-banner-btn").addEventListener("click", () => onAction(banner));
    }
    return banner;
  }

  function isIOS() {
    return /iphone|ipad|ipod/i.test(window.navigator.userAgent);
  }

  document.addEventListener("DOMContentLoaded", () => {
    if (alreadyInstalled() || recentlyDismissed()) return;

    // --- Android / Chrome / Edge: prompt nativo com 1 toque ---
    if (!isIOS()) {
      let deferredPrompt = null;

      window.addEventListener("beforeinstallprompt", (event) => {
        event.preventDefault();
        deferredPrompt = event;

        const banner = buildBanner({
          title: "Instalar o Driqy",
          subtitle: "Acesso mais rápido, direto da tela inicial.",
          actionLabel: "Instalar",
          onAction: async (bannerEl) => {
            if (!deferredPrompt) return;
            deferredPrompt.prompt();
            await deferredPrompt.userChoice;
            deferredPrompt = null;
            dismiss(bannerEl);
          },
        });
      });

      window.addEventListener("appinstalled", () => {
        try {
          localStorage.setItem(DISMISS_KEY, String(Date.now()));
        } catch (e) {}
        document.querySelectorAll(".install-banner").forEach((b) => b.remove());
      });
      return;
    }

    // --- iPhone / Safari: sem API, só instrução manual ---
    buildBanner({
      title: "Instalar o Driqy",
      subtitle: "Toque em Compartilhar (□↑) e depois em “Adicionar à Tela de Início”.",
      actionLabel: null,
      onAction: null,
    });
  });
})();
