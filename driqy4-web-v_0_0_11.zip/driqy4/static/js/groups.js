/* Mensagens parte 4 — grupos na lista de conversas + painel "Novo grupo".
 *  - #ping-groups: seção "Grupos" acima das conversas (GET /api/v1/groups); atualiza ao vivo (evento SSE `group`).
 *  - #ping-group-new: painel aberto pelo item "Novo grupo" do menu lateral (a caneta foi removida):
 *    nome + pessoas (busca /api/buscar) → POST /api/v1/groups → abre /mensagens/grupo/<id>.
 * Tudo com textContent (nada de innerHTML com dados de usuário). */
(function () {
  const HDR = { "X-Requested-With": "fetch" };
  const JSON_HDR = { "Content-Type": "application/json", "X-Requested-With": "fetch" };

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function pad(n) { return n < 10 ? "0" + n : String(n); }
  function shortTime(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (isNaN(d)) return "";
    const now = new Date();
    if (d.toDateString() === now.toDateString()) return pad(d.getHours()) + ":" + pad(d.getMinutes());
    const y = new Date(now); y.setDate(now.getDate() - 1);
    if (d.toDateString() === y.toDateString()) return "Ontem";
    return pad(d.getDate()) + "/" + pad(d.getMonth() + 1);
  }
  function avatar(g, big) {
    const av = el("span", "avatar-dot" + (big ? " gw-av-big" : ""));
    if (g.avatar_url) {
      const im = el("img", "avatar-img"); im.src = g.avatar_url; im.alt = ""; av.appendChild(im);
    } else {
      av.textContent = (g.name || "?").charAt(0).toUpperCase();
      av.classList.add("gw-av");
    }
    return av;
  }
  window.driqyGroupAvatar = avatar;

  // ------------------------------------------------------------------ lista de grupos
  const section = document.getElementById("ping-groups");
  const listBox = document.getElementById("ping-groups-list");
  let groups = [];

  function norm(t) { return (t || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }

  function applyFilter() {
    if (!section) return;
    const input = document.getElementById("ping-search");
    const q = norm(input && input.value.trim());
    let shown = 0;
    listBox.querySelectorAll(".ping-group-row").forEach((row) => {
      const hit = !q || norm(row.textContent).indexOf(q) !== -1;
      row.hidden = !hit;
      if (hit) shown++;
    });
    section.hidden = groups.length === 0 || (q && shown === 0);
  }

  function row(g) {
    const active = String(g.id) === String(section.dataset.active || "");
    const a = el("a", "chat-inbox-row ping-group-row" + (g.unread > 0 ? " conv-unread" : "") + (g.prefs.pinned ? " conv-pinned" : "") +
      (g.prefs.muted ? " conv-muted" : "") + (active ? " is-active" : ""));
    a.href = section.dataset.base + g.id;
    a.dataset.groupId = g.id;
    const avWrap = el("span", "chat-inbox-av"); avWrap.appendChild(avatar(g));
    const main = el("span", "chat-inbox-main");
    main.appendChild(el("span", "user-list-name", g.name));
    const line = el("span", "conv-line");
    line.appendChild(el("span", "conv-preview", g.last_preview || (g.member_count + " pessoas")));
    main.appendChild(line);
    const side = el("span", "chat-inbox-side");
    side.appendChild(el("span", "conv-meta post-meta", shortTime(g.last_activity)));
    const flags = el("span", "conv-flags");
    if (g.prefs.muted) { const f = el("span", "conv-flag", "\uD83D\uDD07"); f.title = "Silenciado"; flags.appendChild(f); }
    if (g.prefs.pinned) { const f = el("span", "conv-flag", "\uD83D\uDCCC"); f.title = "Fixado"; flags.appendChild(f); }
    const badge = el("span", "notif-badge notif-badge-inline", g.unread > 99 ? "99+" : String(g.unread));
    badge.hidden = !(g.unread > 0);
    flags.appendChild(badge);
    side.appendChild(flags);
    a.append(avWrap, main, side);
    return a;
  }

  function render() {
    if (!section) return;
    listBox.replaceChildren.apply(listBox, groups.map(row));
    // no arquivo, o aviso "Nada arquivado" some se só há grupos arquivados
    const empty = document.getElementById("chat-inbox-empty-state");
    if (empty && groups.length) empty.hidden = true;
    applyFilter();
  }

  function refresh() {
    if (!section) return;
    const url = section.dataset.api + (section.dataset.archived === "1" ? "?arquivadas=1" : "");
    fetch(url, { credentials: "same-origin", headers: HDR })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { if (d && d.groups) { groups = d.groups; render(); } })
      .catch(() => {});
  }
  window.driqyGroups = { refresh: refresh };

  if (section) {
    refresh();
    const input = document.getElementById("ping-search");
    if (input) input.addEventListener("input", applyFilter);
    const live = window.driqyLive;
    let timer = null;
    if (live) live.on(["group", "ready", "resync"], () => { clearTimeout(timer); timer = setTimeout(refresh, 200); });
    // rede de segurança quando o tempo real não está conectado
    setInterval(() => { if (!live || !live.connected()) refresh(); }, 15000);
  }

  // ------------------------------------------------------------------ painel "Novo grupo"
  const openBtn = document.getElementById("ping-group-open");
  const panel = document.getElementById("ping-group-new");
  if (!openBtn || !panel) return;
  const nameIn = document.getElementById("ping-group-name");
  const q = document.getElementById("ping-group-q");
  const results = document.getElementById("ping-group-results");
  const chips = document.getElementById("ping-group-chips");
  const msg = document.getElementById("ping-group-msg");
  const createBtn = document.getElementById("ping-group-create");
  const picked = new Map(); // username -> {username, display_name}
  let timer2 = null, seq = 0, busy = false;

  function showMsg(t) { msg.textContent = t || ""; msg.hidden = !t; }
  function close() { panel.hidden = true; }
  function sync() { createBtn.disabled = busy || !nameIn.value.trim() || picked.size === 0; }

  function renderChips() {
    chips.replaceChildren();
    picked.forEach((u) => {
      const c = el("button", "ping-group-chip", u.display_name + " \u2715");
      c.type = "button";
      c.setAttribute("aria-label", "Remover " + u.display_name);
      c.addEventListener("click", () => { picked.delete(u.username); renderChips(); sync(); });
      chips.appendChild(c);
    });
    sync();
  }
  function renderResults(users) {
    results.replaceChildren();
    if (!users.length) {
      if (q.value.trim()) results.appendChild(el("p", "ping-search-empty", "Ninguém encontrado."));
      return;
    }
    users.forEach((u) => {
      const b = el("button", "ping-new-row"); b.type = "button";
      const av = el("span", "avatar-dot");
      if (u.avatar) { const im = el("img", "avatar-img"); im.src = u.avatar; im.alt = ""; av.appendChild(im); }
      else av.textContent = u.initial;
      b.append(av, el("span", null, u.display_name + " (@" + u.username + ")"));
      if (picked.has(u.username)) b.classList.add("is-picked");
      b.addEventListener("click", () => {
        if (picked.has(u.username)) picked.delete(u.username);
        else picked.set(u.username, { username: u.username, display_name: u.display_name });
        b.classList.toggle("is-picked");
        renderChips();
      });
      results.appendChild(b);
    });
  }
  q.addEventListener("input", () => {
    clearTimeout(timer2);
    const term = q.value.trim();
    if (!term) { renderResults([]); return; }
    timer2 = setTimeout(() => {
      const mine = ++seq;
      fetch(panel.dataset.searchUrl + "?q=" + encodeURIComponent(term), { credentials: "same-origin" })
        .then((r) => r.json())
        .then((d) => { if (mine === seq) renderResults(d.users || []); })
        .catch(() => {});
    }, 200);
  });
  nameIn.addEventListener("input", sync);

  openBtn.addEventListener("click", () => {
    if (window.pingShell) window.pingShell.closeDrawer(false);
    const np = document.getElementById("ping-new"); if (np) np.hidden = true;
    picked.clear(); renderChips(); showMsg("");
    nameIn.value = ""; q.value = ""; results.replaceChildren();
    panel.hidden = false;
    if (panel.scrollIntoView) panel.scrollIntoView({ block: "nearest" });
    nameIn.focus();
  });
  document.getElementById("ping-group-close").addEventListener("click", close);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !panel.hidden) close(); });

  createBtn.addEventListener("click", () => {
    if (busy) return;
    busy = true; sync(); showMsg("");
    fetch(panel.dataset.api, {
      method: "POST", credentials: "same-origin", headers: JSON_HDR,
      body: JSON.stringify({ name: nameIn.value.trim(), members: Array.from(picked.keys()) }),
    }).then((r) => r.json().then((j) => ({ ok: r.ok, j: j })))
      .then((res) => {
        if (!res.ok) { showMsg((res.j && res.j.error) || "Não foi possível criar o grupo."); return; }
        location.href = panel.dataset.base + res.j.group.id;
      })
      .catch(() => showMsg("Sem conexão. Tente de novo."))
      .finally(() => { busy = false; sync(); });
  });
})();
