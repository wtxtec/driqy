/* "Minha área": widgets que o próprio usuário cria (nota, tarefas, atalhos, contagem, contador).
   Cada um vira um item normal do seletor (id `custom:<n>`). Criar/apagar é feito pelo editor (lápis,
   rail-edit.js) através de window.DriqyMine. O servidor valida tudo; aqui só desenhamos.
   Texto do usuário entra só por textContent/value; links só http(s). */
(function () {
  "use strict";
  if (!window.DriqyRail) return;
  var cfg = window.__railCfg || { widgets: [] };
  var BASE = window.DriqyRail.config("widgets-url").replace(/\/$/, "") + "/custom";

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function button(text, cls, fn, label) {
    var b = el("button", cls, text);
    b.type = "button";
    if (label) b.setAttribute("aria-label", label);
    b.addEventListener("click", fn);
    return b;
  }
  function input(type, cls, ph, max) {
    var i = el("input", cls);
    i.type = type;
    if (ph) i.placeholder = ph;
    if (max) i.maxLength = max;
    return i;
  }

  function req(method, path, body) {
    var opts = { method: method, credentials: "same-origin", headers: { Accept: "application/json", "X-Requested-With": "fetch" } };
    if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    return fetch(BASE + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) throw new Error((j && j.error) || "Não foi possível salvar agora.");
        return j;
      });
    });
  }

  // Salva `get()` em PUT depois de uma pausa; um salvamento por vez; nunca perde a última edição.
  function saver(wid, get, status) {
    var timer = null, inflight = false, pending = false;
    function run() {
      if (inflight) return;
      pending = false; inflight = true;
      status.textContent = "Salvando…";
      req("PUT", "/" + wid, { data: get() }).then(function () {
        inflight = false;
        status.textContent = pending ? "…" : "Salvo";
        if (pending) run();
      }).catch(function (e) {
        inflight = false; pending = true;
        status.textContent = e.message + " Mexa de novo para tentar.";
      });
    }
    return {
      later: function (ms) { pending = true; clearTimeout(timer); status.textContent = "…"; timer = setTimeout(run, ms || 600); },
      now: function () { clearTimeout(timer); if (pending) run(); }
    };
  }

  function safeHref(u) { return /^https?:\/\//i.test(u) ? u : "#"; }

  /* ------------------------------------------------------------ tipos */
  function drawNote(host, w, status) {
    var data = w.data, s = saver(w.widget_id, function () { return data; }, status);
    var ta = el("textarea", "mine-note");
    ta.maxLength = 2000; ta.rows = 7; ta.placeholder = "Escreva algo…"; ta.value = data.text;
    ta.addEventListener("input", function () { data.text = ta.value; s.later(700); });
    ta.addEventListener("blur", function () { s.now(); });
    host.appendChild(ta);
  }

  function drawChecklist(host, w, status) {
    var data = w.data, s = saver(w.widget_id, function () { return data; }, status);
    var prog = el("p", "hint mine-prog"), ul = el("ul", "mine-list"), clear = el("div", "wx-foot");
    var add = input("text", "mine-input", "Novo item (Enter)", 120);
    function draw() {
      ul.textContent = "";
      var done = 0;
      data.items.forEach(function (it, i) {
        if (it.done) done++;
        var li = el("li", "mine-item" + (it.done ? " done" : ""));
        var lab = el("label", "mine-check");
        var cb = el("input"); cb.type = "checkbox"; cb.checked = !!it.done;
        cb.addEventListener("change", function () { it.done = cb.checked; draw(); s.later(300); });
        lab.appendChild(cb); lab.appendChild(el("span", null, it.text));
        li.appendChild(lab);
        li.appendChild(button("✕", "rail-ed-btn", function () { data.items.splice(i, 1); draw(); s.later(300); }, "Remover " + it.text));
        ul.appendChild(li);
      });
      prog.textContent = data.items.length ? done + " de " + data.items.length + " feitas" : "Nada por aqui. Adicione a primeira tarefa.";
      clear.textContent = "";
      if (done) clear.appendChild(button("Limpar feitas", "rail-ed-link", function () {
        data.items = data.items.filter(function (x) { return !x.done; }); draw(); s.later(300);
      }));
    }
    function addItem() {
      var t = add.value.trim();
      if (!t) return;
      if (data.items.length >= 50) { status.textContent = "Máximo de 50 itens."; return; }
      data.items.push({ text: t, done: false });
      add.value = ""; draw(); s.later(300);
    }
    add.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); addItem(); } });
    host.appendChild(add); host.appendChild(ul); host.appendChild(prog); host.appendChild(clear);
    draw();
  }

  function drawLinks(host, w, status) {
    var data = w.data, ul = el("ul", "mine-list");
    var url = input("text", "mine-input", "endereço (ex.: exemplo.com)", 500);
    var title = input("text", "mine-input", "nome (opcional)", 40);
    function send(links) {
      status.textContent = "Salvando…";
      return req("PUT", "/" + w.widget_id, { data: { links: links } }).then(function (j) {
        data = j.widget.data; status.textContent = "Salvo"; draw(); return true;
      }).catch(function (e) { status.textContent = e.message; return false; });
    }
    function draw() {
      ul.textContent = "";
      if (!data.links.length) ul.appendChild(el("li", "hint", "Nenhum atalho ainda."));
      data.links.forEach(function (l, i) {
        var li = el("li", "mine-item");
        var a = el("a", "mine-link", l.title);
        a.href = safeHref(l.url); a.target = "_blank"; a.rel = "noopener noreferrer";
        li.appendChild(a);
        li.appendChild(button("✕", "rail-ed-btn", function () {
          send(data.links.filter(function (_x, k) { return k !== i; }));
        }, "Remover " + l.title));
        ul.appendChild(li);
      });
    }
    function addLink() {
      if (!url.value.trim()) return;
      send(data.links.concat([{ title: title.value.trim(), url: url.value.trim() }])).then(function (ok) {
        if (ok) { url.value = ""; title.value = ""; }
      });
    }
    [url, title].forEach(function (i) { i.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); addLink(); } }); });
    var row = el("div", "mine-row");
    row.appendChild(url); row.appendChild(title);
    host.appendChild(ul); host.appendChild(row);
    host.appendChild(button("Adicionar atalho", "btn-outline wx-action", addLink));
    draw();
  }

  function daysUntil(iso) {
    var p = iso.split("-"), n = new Date();
    return Math.round((new Date(+p[0], p[1] - 1, +p[2]) - new Date(n.getFullYear(), n.getMonth(), n.getDate())) / 86400000);
  }
  function drawCountdown(host, w, status) {
    var data = w.data;
    function draw(editing) {
      host.textContent = "";
      if (!data.date || editing) {
        var label = input("text", "mine-input", "O que você espera? (ex.: Viagem)", 40);
        label.value = data.label;
        var date = input("date", "mine-input"); date.value = data.date;
        var save = button("Salvar", "btn wx-action", function () {
          if (!date.value) { status.textContent = "Escolha uma data."; return; }
          status.textContent = "Salvando…";
          req("PUT", "/" + w.widget_id, { data: { label: label.value, date: date.value } }).then(function (j) {
            data = j.widget.data; status.textContent = "Salvo"; draw(false);
          }).catch(function (e) { status.textContent = e.message; });
        });
        host.appendChild(label); host.appendChild(date); host.appendChild(save);
        if (data.date) host.appendChild(button("Cancelar", "rail-ed-link", function () { draw(false); }));
        return;
      }
      var d = daysUntil(data.date);
      var box = el("div", "mine-count");
      box.appendChild(el("div", "mine-count-n", d === 0 ? "Hoje!" : String(Math.abs(d))));
      box.appendChild(el("div", "mine-count-u", d === 0 ? "" : d > 0 ? (d === 1 ? "dia restante" : "dias restantes") : (d === -1 ? "dia atrás" : "dias atrás")));
      if (data.label) box.appendChild(el("strong", "mine-count-l", data.label));
      var p = data.date.split("-");
      box.appendChild(el("small", "hint", p[2] + "/" + p[1] + "/" + p[0]));
      host.appendChild(box);
      host.appendChild(button("Alterar", "rail-ed-link", function () { draw(true); }));
    }
    draw(false);
  }

  function drawCounter(host, w, status) {
    var data = w.data, s = saver(w.widget_id, function () { return data; }, status);
    function draw(editing) {
      host.textContent = "";
      if (editing) {
        var step = input("number", "mine-input", "passo"); step.min = 1; step.max = 1000; step.value = data.step;
        var goal = input("number", "mine-input", "meta (opcional)"); goal.min = 1; goal.value = data.goal == null ? "" : data.goal;
        var unit = input("text", "mine-input", "unidade (ex.: copos)", 12); unit.value = data.unit;
        host.appendChild(el("label", "hint", "Passo")); host.appendChild(step);
        host.appendChild(el("label", "hint", "Meta")); host.appendChild(goal);
        host.appendChild(el("label", "hint", "Unidade")); host.appendChild(unit);
        var row = el("div", "wx-foot");
        row.appendChild(button("Zerar", "rail-ed-link", function () { data.value = 0; s.later(100); draw(false); }));
        row.appendChild(button("Salvar", "btn wx-action", function () {
          data.step = Math.max(1, parseInt(step.value, 10) || 1);
          data.goal = goal.value === "" ? null : Math.max(1, parseInt(goal.value, 10) || 1);
          data.unit = unit.value.trim(); s.later(100); draw(false);
        }));
        host.appendChild(row);
        return;
      }
      var box = el("div", "mine-counter");
      box.appendChild(button("−", "mine-step", function () { data.value -= data.step; draw(false); s.later(400); }, "Diminuir"));
      var mid = el("div", "mine-counter-mid");
      mid.appendChild(el("div", "mine-count-n", Number(data.value).toLocaleString("pt-BR")));
      if (data.unit) mid.appendChild(el("div", "mine-count-u", data.unit));
      box.appendChild(mid);
      box.appendChild(button("+", "mine-step", function () { data.value += data.step; draw(false); s.later(400); }, "Aumentar"));
      host.appendChild(box);
      if (data.goal) {
        var bar = el("div", "wx-pomo-bar"), fill = el("span");
        fill.style.width = Math.max(0, Math.min(100, Math.round(data.value / data.goal * 100))) + "%";
        bar.appendChild(fill); host.appendChild(bar);
        host.appendChild(el("p", "hint", "Meta: " + Number(data.goal).toLocaleString("pt-BR") + (data.value >= data.goal ? " — atingida!" : "")));
      }
      host.appendChild(button("Ajustar", "rail-ed-link", function () { draw(true); }));
    }
    draw(false);
  }

  var DRAW = { note: drawNote, checklist: drawChecklist, links: drawLinks, countdown: drawCountdown, counter: drawCounter };

  /* ------------------------------------------------------------ renderização de um widget */
  function renameInline(foot, w, status) {
    foot.textContent = "";
    var t = input("text", "mine-input mine-rename", "Nome do widget", 40);
    t.value = w.title;
    var ok = button("OK", "btn wx-action", function () {
      req("PUT", "/" + w.widget_id, { title: t.value }).then(function (j) {
        w.title = j.widget.title;
        cfg.widgets.forEach(function (x) { if (x.id === w.id) x.title = w.title; });
        window.DriqyRail.rename(w.id, w.title);
        footer(foot, w, status);
      }).catch(function (e) { status.textContent = e.message; });
    });
    t.addEventListener("keydown", function (e) { if (e.key === "Enter") ok.click(); if (e.key === "Escape") footer(foot, w, status); });
    foot.appendChild(t); foot.appendChild(ok);
    t.focus();
  }
  function footer(foot, w, status) {
    foot.textContent = "";
    foot.appendChild(status);
    foot.appendChild(button("Renomear", "rail-ed-link", function () { renameInline(foot, w, status); }));
  }

  function renderMine(host, ctx, id, wid) {
    host.textContent = "";
    host.appendChild(el("p", "hint", "Carregando…"));
    req("GET", "/" + wid).then(function (j) {
      if (!ctx.isActive()) return;
      var w = j.widget;
      host.textContent = "";
      var body = el("div", "mine-body"), status = el("span", "mine-status"), foot = el("div", "mine-foot");
      host.appendChild(body); host.appendChild(foot);
      footer(foot, w, status);
      (DRAW[w.kind] || function (b) { b.appendChild(el("p", "hint", "Tipo de widget desconhecido.")); })(body, w, status);
    }).catch(function (e) {
      if (!ctx.isActive()) return;
      host.textContent = "";
      var box = el("div", "wx-msg");
      box.appendChild(el("p", "hint", e && /encontrado/.test(e.message) ? "Este widget não existe mais." : "Não consegui carregar agora."));
      box.appendChild(button("Tentar de novo", "btn-outline wx-action", function () { renderMine(host, ctx, id, wid); }));
      host.appendChild(box);
    });
  }

  function register(w) {
    window.DriqyRail.register({ id: w.id, title: w.title, render: function (body, ctx) { renderMine(body, ctx, w.id, w.widget_id); } });
  }

  function slim(w) {
    var o = {};
    Object.keys(w).forEach(function (k) { if (k !== "data") o[k] = w[k]; });
    return o;
  }

  window.DriqyMine = {
    // cria no servidor, entra no catálogo e no seletor; resolve com o widget (sem `data`)
    create: function (kind) {
      return req("POST", "", { kind: kind }).then(function (j) {
        var w = slim(j.widget);
        cfg.widgets.push(w);
        register(w);
        return w;
      });
    },
    // apaga de vez (servidor, catálogo, preferências e seletor)
    remove: function (id) {
      var n = parseInt(String(id).split(":")[1], 10);
      return req("DELETE", "/" + n).then(function () {
        var drop = function (x) { return x !== id; };
        for (var i = cfg.widgets.length - 1; i >= 0; i--) if (cfg.widgets[i].id === id) cfg.widgets.splice(i, 1);  // no lugar: o editor guarda a referência
        if (cfg.prefs) { cfg.prefs.order = (cfg.prefs.order || []).filter(drop); cfg.prefs.disabled = (cfg.prefs.disabled || []).filter(drop); }
        window.DriqyRail.unregister(id);
      });
    }
  };

  cfg.widgets.filter(function (w) { return w.custom; }).forEach(register);
})();
