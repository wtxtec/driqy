/*
 * Confirmação do tempo de duração antes de publicar um post TEMPORÁRIO
 * (a duração é opcional; post sem duração é permanente e não passa por
 * aqui). Mostra um modal com "esse post vai ficar no ar por X" e só deixa o
 * formulário seguir se a pessoa confirmar.
 */
(function () {
  function formatDuration(minutes) {
    const min = Math.max(1, Math.round(minutes || 0));
    if (min < 60) return min + (min === 1 ? " minuto" : " minutos");
    if (min < 1440) {
      const h = Math.round(min / 60);
      return h + (h === 1 ? " hora" : " horas");
    }
    if (min < 10080) {
      const d = Math.round(min / 1440);
      return d + (d === 1 ? " dia" : " dias");
    }
    if (min < 43200) {
      const w = Math.round(min / 10080);
      return w + (w === 1 ? " semana" : " semanas");
    }
    if (min < 525600) {
      const mo = Math.round(min / 43200);
      return mo + (mo === 1 ? " mês" : " meses");
    }
    const y = Math.round(min / 525600);
    return y + (y === 1 ? " ano" : " anos");
  }

  function confirmPublish(minutes, opts) {
    const options = opts || {};
    return new Promise((resolve) => {
      const modal = document.getElementById("publish-confirm-modal");
      if (!modal) {
        resolve(true); // sem modal no DOM (página sem esse bloco): não bloqueia
        return;
      }

      const msgEl = document.getElementById("publish-confirm-message");
      const okBtn = document.getElementById("publish-confirm-ok");
      const cancelBtn = document.getElementById("publish-confirm-cancel");
      const backdrop = modal.querySelector(".confirm-modal-backdrop");
      const closeBtn = modal.querySelector(".confirm-modal-close");

      const label = options.label || formatDuration(minutes);
      if (msgEl) {
        msgEl.textContent =
          "Esse post vai ficar visível por " + label + " e depois some sozinho (você também pode excluí-lo antes, quando quiser). Confirma a publicação?";
      }

      modal.setAttribute("aria-hidden", "false");
      document.body.classList.add("confirm-modal-open");
      if (okBtn) okBtn.focus();

      function cleanup(result) {
        modal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("confirm-modal-open");
        if (okBtn) okBtn.removeEventListener("click", onOk);
        if (cancelBtn) cancelBtn.removeEventListener("click", onCancel);
        if (backdrop) backdrop.removeEventListener("click", onCancel);
        if (closeBtn) closeBtn.removeEventListener("click", onCancel);
        document.removeEventListener("keydown", onKey);
        resolve(result);
      }
      function onOk() { cleanup(true); }
      function onCancel() { cleanup(false); }
      function onKey(e) { if (e.key === "Escape") cleanup(false); }

      if (okBtn) okBtn.addEventListener("click", onOk);
      if (cancelBtn) cancelBtn.addEventListener("click", onCancel);
      if (backdrop) backdrop.addEventListener("click", onCancel);
      if (closeBtn) closeBtn.addEventListener("click", onCancel);
      document.addEventListener("keydown", onKey);
    });
  }

  window.driqyPublishConfirm = { confirmPublish, formatDuration };
})();
