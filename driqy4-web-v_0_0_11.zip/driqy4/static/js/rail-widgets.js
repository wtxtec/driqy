/* Widgets do painel direito além do clima: Em alta, Notícias, Vortex e Quem está online.
   Cada um busca /api/v1/widgets/<nome> (mesma base do data-widgets-url do #rail). */
(function () {
  "use strict";
  if (!window.DriqyRail) return;

  var BASE = window.DriqyRail.config("widgets-url").replace(/\/$/, "");

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function note(host, text, retry) {
    host.innerHTML = "";
    var box = el("div", "wx-msg");
    box.appendChild(el("p", "hint", text));
    if (retry) {
      var b = el("button", "btn-outline wx-action", "Tentar de novo");
      b.type = "button";
      b.addEventListener("click", retry);
      box.appendChild(b);
    }
    host.appendChild(box);
  }

  function avatar(u, size) {
    var a = el("span", "rail-avatar" + (size === "sm" ? " rail-avatar-sm" : ""));
    if (u.avatar_url) {
      var img = el("img");
      img.src = u.avatar_url;
      img.alt = "";
      img.loading = "lazy";
      a.appendChild(img);
    } else {
      a.textContent = (u.username || "?").charAt(0).toUpperCase();
    }
    return a;
  }

  function load(host, ctx, name, draw, query) {
    note(host, "Carregando…");
    var redo = function () { load(host, ctx, name, draw, query); };
    fetch(BASE + "/" + name + (query ? query() : ""), { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error("http " + r.status)); })
      .then(function (d) {
        if (!ctx.isActive()) return;
        host.innerHTML = "";
        draw(host, d, redo);
      })
      .catch(function () {
        if (!ctx.isActive()) return;
        note(host, "Não consegui carregar agora.", redo);
      });
  }

  // Manchetes dispensadas: só neste aparelho/navegador (localStorage), as 60 mais recentes.
  var DISMISS_KEY = "driqy-news-dismissed";
  var NEWS_SHOW = 4;
  function dismissedIds() {
    try {
      var v = JSON.parse(localStorage.getItem(DISMISS_KEY) || "[]");
      return Array.isArray(v) ? v.filter(function (x) { return typeof x === "number"; }) : [];
    } catch (e) { return []; }
  }
  function saveDismissed(ids) {
    try { localStorage.setItem(DISMISS_KEY, JSON.stringify(ids.slice(-60))); } catch (e) { /* sem storage: só vale até recarregar */ }
  }
  function newsQuery() {
    return "?limit=" + Math.min(NEWS_SHOW + dismissedIds().length, 12);
  }

  function row(href, external) {
    var a = el("a", "rail-row");
    a.href = href;
    if (external) { a.target = "_blank"; a.rel = "noopener noreferrer"; }
    return a;
  }

  function drawTrending(host, d) {
    var posts = d.posts || [];
    if (!posts.length) { note(host, "Ainda não há posts em alta. Curta e comente para movimentar!"); return; }
    posts.forEach(function (p) {
      var a = row(p.url);
      a.appendChild(avatar(p.author, "sm"));
      var body = el("span", "rail-row-body");
      body.appendChild(el("strong", "rail-row-title", "@" + p.author.username));
      body.appendChild(el("span", "rail-row-text", p.snippet));
      body.appendChild(el("span", "rail-row-meta", "♥ " + p.likes + "  ·  💬 " + p.comments));
      a.appendChild(body);
      host.appendChild(a);
    });
  }

  function drawNews(host, d, redo) {
    var gone = dismissedIds();
    var all = d.articles || [];
    var arts = all.filter(function (n) { return gone.indexOf(n.id) < 0; }).slice(0, NEWS_SHOW);
    if (!arts.length) {
      note(host, gone.length ? "Você dispensou as manchetes de agora." : "Sem notícias por enquanto.");
    }
    arts.forEach(function (n) {
      var item = el("div", "rail-news-item");
      var a = row(n.url, true);
      if (n.image_url) {
        var img = el("img", "rail-thumb");
        img.src = n.image_url;
        img.alt = "";
        img.loading = "lazy";
        img.addEventListener("error", function () { img.remove(); });
        a.appendChild(img);
      }
      var body = el("span", "rail-row-body");
      body.appendChild(el("span", "rail-row-text rail-row-clamp", n.title));
      body.appendChild(el("span", "rail-row-meta", n.source));
      a.appendChild(body);
      item.appendChild(a);
      var x = el("button", "rail-dismiss", "×");
      x.type = "button";
      x.title = "Dispensar esta manchete";
      x.setAttribute("aria-label", "Dispensar esta manchete");
      x.addEventListener("click", function () {
        var ids = dismissedIds();
        if (ids.indexOf(n.id) < 0) ids.push(n.id);
        saveDismissed(ids);
        item.remove();
        // repõe: pede mais uma manchete ao servidor e redesenha
        if (redo) redo();
      });
      item.appendChild(x);
      host.appendChild(item);
    });
    if (gone.length) {
      var back = el("button", "rail-more rail-news-restore", "Mostrar as dispensadas (" + gone.length + ")");
      back.type = "button";
      back.addEventListener("click", function () {
        saveDismissed([]);
        if (redo) redo();
      });
      host.appendChild(back);
    }
  }

  function drawVortex(host, d) {
    var items = d.items || [];
    if (!items.length) { note(host, "O Vortex ainda não tem peças novas."); return; }
    var grid = el("div", "rail-vortex-grid");
    items.forEach(function (it) {
      var a = el("a", "rail-vortex-cell");
      a.href = it.url;
      a.title = it.title || "Vortex";
      var img = el("img");
      img.src = it.thumb_url;
      img.alt = it.title || "";
      img.loading = "lazy";
      img.referrerPolicy = "no-referrer";
      img.addEventListener("error", function () { a.remove(); });
      a.appendChild(img);
      grid.appendChild(a);
    });
    host.appendChild(grid);
    var more = el("a", "rail-more", "Abrir o Vortex");
    more.href = items[0].url;
    host.appendChild(more);
  }

  function drawOnline(host, d) {
    if (d.hidden) {
      note(host, "Você escondeu o seu “online”, então também não vê quem está online. Dá para mudar isso nas configurações de privacidade do chat.");
      return;
    }
    var n = d.count || 0;
    host.appendChild(el("p", "rail-online-count",
      n === 0 ? "Ninguém online agora." : n + (n === 1 ? " pessoa online agora" : " pessoas online agora")));
    if (n) {
      var wrap = el("div", "rail-online-row");
      (d.users || []).forEach(function (u) {
        var a = el("a", "rail-online-user");
        a.href = u.profile_url;
        a.title = "@" + u.username;
        a.appendChild(avatar(u));
        wrap.appendChild(a);
      });
      host.appendChild(wrap);
      if (n > (d.users || []).length) host.appendChild(el("p", "hint", "+" + (n - d.users.length) + " pessoas"));
    }
  }

  [
    { id: "trending", title: "Em alta", draw: drawTrending },
    { id: "news", title: "Notícias", draw: drawNews, query: newsQuery },
    { id: "vortex", title: "Vortex", draw: drawVortex },
    { id: "online", title: "Quem está online", draw: drawOnline }
  ].forEach(function (w) {
    window.DriqyRail.register({
      id: w.id,
      title: w.title,
      render: function (host, ctx) { load(host, ctx, w.id, w.draw, w.query); }
    });
  });
})();
