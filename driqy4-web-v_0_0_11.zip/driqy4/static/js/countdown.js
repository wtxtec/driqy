(function () {
  const RADIUS = 17;
  const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

  function formatRemaining(totalSeconds) {
    if (totalSeconds <= 0) return "0s";
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);

    if (days > 0) return `${days}d`;
    if (hours > 0) return `${hours}h`;
    if (minutes > 0) return `${minutes}m`;
    return `${seconds}s`;
  }

  function formatRemainingFull(totalSeconds) {
    if (totalSeconds <= 0) return "Expirado";
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);

    if (days > 0) return `Expira em ${days} dia${days !== 1 ? "s" : ""}`;
    if (hours > 0) return `Expira em ${hours} hora${hours !== 1 ? "s" : ""}`;
    if (minutes > 0) return `Expira em ${minutes} minuto${minutes !== 1 ? "s" : ""}`;
    return "Expira em instantes";
  }

  function formatElapsed(totalSeconds) {
    const seconds = Math.max(0, Math.floor(totalSeconds));
    if (seconds < 45) return "agora";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `há ${minutes} min`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `há ${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `há ${days}d`;
    const weeks = Math.floor(days / 7);
    return `há ${weeks} sem`;
  }

  function tickElapsedLabels() {
    document.querySelectorAll(".post-elapsed[data-created]").forEach((el) => {
      const created = new Date(el.dataset.created).getTime();
      if (Number.isNaN(created)) return;
      const elapsedSeconds = (Date.now() - created) / 1000;
      el.textContent = formatElapsed(elapsedSeconds);
    });
  }

  function tickCard(card) {
    const expiresAt = new Date(card.dataset.expires).getTime();
    const totalSeconds = parseFloat(card.dataset.duration);
    const now = Date.now();
    const remainingMs = expiresAt - now;
    const remainingSeconds = Math.max(0, remainingMs / 1000);

    const wrap = card.querySelector(".countdown-ring-wrap");
    const ring = card.querySelector(".countdown-ring-fg");
    const label = card.querySelector(".countdown-label");
    const footerLabel = card.querySelector(".post-expires-label");

    const fraction = totalSeconds > 0 ? Math.max(0, Math.min(1, remainingSeconds / totalSeconds)) : 0;

    if (ring) {
      const offset = CIRCUMFERENCE * (1 - fraction);
      ring.style.strokeDasharray = `${CIRCUMFERENCE}`;
      ring.style.strokeDashoffset = `${offset}`;
    }
    if (label) {
      label.textContent = formatRemaining(remainingSeconds);
    }
    if (footerLabel) {
      footerLabel.textContent = formatRemainingFull(remainingSeconds);
    }
    if (wrap) {
      wrap.classList.toggle("countdown-ring-urgent", fraction <= 0.1 && remainingSeconds > 0);
    }

    if (remainingSeconds <= 0) {
      card.classList.add("post-expiring");
      setTimeout(() => {
        card.style.transition = "opacity .6s ease, max-height .6s ease, margin .6s ease, padding .6s ease";
        card.style.opacity = "0";
        card.style.maxHeight = card.offsetHeight + "px";
        requestAnimationFrame(() => {
          card.style.maxHeight = "0px";
          card.style.margin = "0";
          card.style.padding = "0";
          card.style.overflow = "hidden";
        });
        setTimeout(() => card.remove(), 650);
      }, 400);
      return false; // para de atualizar este card
    }
    return true;
  }

  const active = new Set();
  let intervalStarted = false;

  function ensureInterval() {
    if (intervalStarted) return;
    intervalStarted = true;
    setInterval(() => {
      active.forEach((card) => {
        if (!document.body.contains(card)) {
          active.delete(card);
          return;
        }
        const stillActive = tickCard(card);
        if (!stillActive) active.delete(card);
      });
    }, 1000);
  }

  function registerCard(card) {
    // post permanente (sem data-expires) não tem contagem regressiva
    if (!card || !card.dataset.expires || active.has(card)) return;
    active.add(card);
    tickCard(card);
    ensureInterval();
  }

  function startCountdowns() {
    tickElapsedLabels();
    setInterval(tickElapsedLabels, 30000);

    document.querySelectorAll(".post-card[data-expires]").forEach(registerCard);
  }

  window.driqyCountdown = { registerCard, tickElapsedLabels };

  document.addEventListener("DOMContentLoaded", startCountdowns);

  // Os comentários NÃO ficam mais embutidos no feed: eles só existem na
  // página do post. Fora dela, tanto o botão de comentários quanto o clique
  // no corpo do post levam pra essa página; dentro dela, o botão só leva o
  // cursor até o campo de comentário.
  function isDetailCard(card) {
    return !!card && card.dataset.detail === "1";
  }

  function focusMainCommentInput(card) {
    const input = card && card.querySelector(".comment-form:not(.comment-reply-form) input[type=text]");
    if (input) {
      input.scrollIntoView({ block: "center", behavior: "smooth" });
      input.focus({ preventScroll: true });
    }
  }

  function openPostPage(href) {
    if (href) window.location.href = href;
  }

  document.addEventListener("DOMContentLoaded", () => {
    // Chegou pelo botão de comentários (…#comments-ID): já foca o campo.
    if (/^#comments-\d+$/.test(window.location.hash)) {
      const card = document.querySelector('.post-card[data-detail="1"]');
      if (card) focusMainCommentInput(card);
    }
  });

  document.addEventListener("click", (event) => {
    const openLink = event.target.closest(".post-open-link");
    if (openLink) {
      // Clicar no corpo do post (texto, área vazia etc.) abre a página do
      // post com os comentários. Não faz nada se o clique foi em algo
      // interativo dentro do post (menção @usuario, imagem/vídeo com sua
      // própria ação, seleção de texto etc.) — essas coisas já tratam o
      // próprio clique.
      const interactive = event.target.closest("a, button, video, input, textarea, .video-controls, .video-progress, .post-media-image");
      const isSelecting = window.getSelection && String(window.getSelection()).length > 0;
      if (!interactive && !isSelecting) {
        const card = openLink.closest(".post-card");
        if (!isDetailCard(card)) openPostPage(openLink.dataset.href);
      }
      return;
    }

    const commentBtn = event.target.closest(".comment-toggle");
    if (commentBtn) {
      const card = commentBtn.closest(".post-card");
      if (isDetailCard(card)) {
        focusMainCommentInput(card);
      } else {
        openPostPage(commentBtn.dataset.href);
      }
      return;
    }

    const replyBtn = event.target.closest(".comment-reply-toggle");
    if (replyBtn) {
      const target = document.getElementById(replyBtn.dataset.target);
      if (target) {
        target.hidden = !target.hidden;
        if (!target.hidden) {
          const input = target.querySelector("input[type=text]");
          if (input) {
            input.focus();
            const len = input.value.length;
            input.setSelectionRange(len, len);
          }
        }
      }
      return;
    }

    const shareBtn = event.target.closest(".share-btn");
    if (shareBtn) {
      const url = shareBtn.dataset.shareUrl;
      if (!url) return;

      const showFeedback = (text) => {
        shareBtn.classList.add("share-btn-done");
        shareBtn.setAttribute("data-feedback", text);
        shareBtn.setAttribute("title", text);
        clearTimeout(shareBtn._feedbackTimeout);
        shareBtn._feedbackTimeout = setTimeout(() => {
          shareBtn.classList.remove("share-btn-done");
          shareBtn.removeAttribute("data-feedback");
          shareBtn.setAttribute("title", "Copiar link deste post");
        }, 1800);
      };

      if (navigator.share) {
        navigator.share({ url, title: document.title })
          .then(() => showFeedback("✓ Compartilhado!"))
          .catch(() => {});
        return;
      }

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url)
          .then(() => showFeedback("✓ Link copiado!"))
          .catch(() => showFeedback("Não foi possível copiar"));
      } else {
        const helper = document.createElement("textarea");
        helper.value = url;
        helper.style.position = "fixed";
        helper.style.opacity = "0";
        document.body.appendChild(helper);
        helper.select();
        try {
          document.execCommand("copy");
          showFeedback("✓ Link copiado!");
        } catch (e) {
          showFeedback("Não foi possível copiar");
        }
        document.body.removeChild(helper);
      }
    }
  });

  // ---------- Curtir sem recarregar a página ----------
  function updateLikeButton(btn, liked, likesCount) {
    btn.classList.toggle("liked", liked);
    const heart = btn.querySelector(".heart");
    if (heart) heart.textContent = liked ? "♥" : "♡";
    const count = btn.querySelector(".like-count");
    if (count) count.textContent = likesCount;
  }

  // ---------- Comentar sem recarregar a página ----------
  function showCommentError(form, message) {
    let err = form.querySelector(".comment-error");
    if (!err) {
      err = document.createElement("div");
      err.className = "comment-error";
      form.appendChild(err);
    }
    err.textContent = message;
    clearTimeout(err._hideTimeout);
    err._hideTimeout = setTimeout(() => err.remove(), 4000);
  }

  function clearCommentError(form) {
    const err = form.querySelector(".comment-error");
    if (err) err.remove();
  }

  function insertNewComment(postId, parentId, html) {
    const wrapper = document.createElement("div");
    wrapper.innerHTML = html.trim();
    const newCommentEl = wrapper.firstElementChild;
    if (!newCommentEl) return;

    if (parentId) {
      const parentEl = document.getElementById(`comment-${parentId}`);
      if (!parentEl) return;
      let repliesWrap = parentEl.querySelector(":scope > .comment-replies");
      if (!repliesWrap) {
        repliesWrap = document.createElement("div");
        repliesWrap.className = "comment-replies";
        parentEl.appendChild(repliesWrap);
      }
      repliesWrap.appendChild(newCommentEl);
    } else {
      const section = document.getElementById(`comments-${postId}`);
      if (!section) return;
      const hint = section.querySelector(":scope > .hint");
      if (hint) hint.remove();
      const mainForm = section.querySelector(":scope > .comment-form:not(.comment-reply-form)");
      if (mainForm) {
        section.insertBefore(newCommentEl, mainForm);
      } else {
        section.appendChild(newCommentEl);
      }
    }
  }

  document.addEventListener("submit", (event) => {
    const likeForm = event.target.closest(".like-form");
    if (likeForm) {
      event.preventDefault();
      const btn = likeForm.querySelector(".like-btn");
      if (!btn || btn.disabled) return;
      btn.disabled = true;

      fetch(likeForm.action, {
        method: "POST",
        headers: { "X-Requested-With": "fetch" },
      })
        .then((res) => (res.ok ? res.json() : Promise.reject(res)))
        .then((data) => updateLikeButton(btn, data.liked, data.likes_count))
        .catch(() => {})
        .finally(() => {
          btn.disabled = false;
        });
      return;
    }

    const commentForm = event.target.closest(".comment-form");
    if (commentForm) {
      event.preventDefault();
      const input = commentForm.querySelector('input[name="content"]');
      if (!input || !input.value.trim()) {
        if (input) showCommentError(commentForm, "Escreva algo para comentar.");
        return;
      }

      const card = commentForm.closest(".post-card");
      if (!card) return;
      const postId = card.id.replace("post-", "");
      const submitBtn = commentForm.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.disabled = true;

      fetch(commentForm.action, {
        method: "POST",
        headers: { "X-Requested-With": "fetch" },
        body: new FormData(commentForm),
      })
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
          if (!ok || !data.ok) {
            showCommentError(commentForm, (data && data.error) || "Não foi possível enviar o comentário.");
            return;
          }
          clearCommentError(commentForm);
          insertNewComment(postId, data.parent_id, data.html);

          const countEl = card.querySelector(".comment-toggle .comment-count");
          if (countEl) countEl.textContent = data.comments_count;

          input.value = "";
          if (commentForm.classList.contains("comment-reply-form")) {
            commentForm.hidden = true;
          }
        })
        .catch(() => showCommentError(commentForm, "Não foi possível enviar o comentário. Tente de novo."))
        .finally(() => {
          if (submitBtn) submitBtn.disabled = false;
        });
    }
  });
})();
