/* 10 widgets novos do painel: Relógio mundial, Calendário, Fase da Lua, Cotações, Seu Driqy, Acabando,
   Frase do dia (dados do servidor) e Foco, Calculadora, Respirar (só no aparelho).
   Texto vindo do servidor entra só por textContent. */
(function () {
  "use strict";
  if (!window.DriqyRail) return;
  var BASE = window.DriqyRail.config("widgets-url").replace(/\/$/, "");

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function button(text, cls, fn, label) {
    var b = el("button", cls, text);
    b.type = "button";
    if (label) b.setAttribute("aria-label", label);
    b.addEventListener("click", fn);
    return b;
  }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  // fuso do navegador (nome IANA): o servidor usa para o "hoje", os horários da Lua/estações e os avisos
  function browserTz() {
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) { return ""; }
  }
  function tzQuery() { var z = browserTz(); return z ? "?tz=" + encodeURIComponent(z) : ""; }
  function tzWords(label) { return !label || label === "Brasília" ? "horário de Brasília" : "seu horário (" + label + ")"; }
  function dm(iso) { var p = String(iso).split("-"); return p[2] + "/" + p[1]; }
  function store(key, val) {
    try {
      if (val === undefined) return JSON.parse(localStorage.getItem(key));
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {}
    return null;
  }

  function note(host, text, retry) {
    host.textContent = "";
    var box = el("div", "wx-msg");
    box.appendChild(el("p", "hint", text));
    if (retry) box.appendChild(button("Tentar de novo", "btn-outline wx-action", retry));
    host.appendChild(box);
  }
  function api(path) {
    return fetch(BASE + path, { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error("http " + r.status)); });
  }
  function load(host, ctx, path, draw) {
    note(host, "Carregando…");
    api(path).then(function (d) {
      if (!ctx.isActive()) return;
      host.textContent = "";
      draw(host, d);
    }).catch(function () {
      if (!ctx.isActive()) return;
      note(host, "Não consegui carregar agora.", function () { load(host, ctx, path, draw); });
    });
  }
  function alive(host, ctx) { return ctx.isActive() && host.isConnected; }
  function every(host, ctx, ms, fn) {
    var t = setInterval(function () {
      if (!alive(host, ctx)) { clearInterval(t); return; }
      fn(t);
    }, ms);
    return t;
  }
  function avatar(u) {
    var a = el("span", "rail-avatar rail-avatar-sm");
    if (u.avatar_url) {
      var img = el("img"); img.src = u.avatar_url; img.alt = ""; img.loading = "lazy"; a.appendChild(img);
    } else a.textContent = (u.username || "?").charAt(0).toUpperCase();
    return a;
  }

  /* ------------------------------------------------------------ Relógio mundial */
  var ZKEY = "driqy-rail-clock-zones";
  function renderClock(host, ctx, picking) {
    var saved = store(ZKEY);
    var zones = Array.isArray(saved) && saved.length ? saved.slice(0, 6) : null;
    load(host, ctx, "/clock" + (zones ? "?zones=" + encodeURIComponent(zones.join(",")) : ""), function (h, d) {
      if (!d.ok) { note(h, "Relógio indisponível agora.", function () { renderClock(host, ctx); }); return; }
      var fetchedAt = Date.now();
      var box = el("div", "wx-clock");
      var rows = d.cities.map(function (c) {
        var r = el("div", "wx-clock-row");
        var left = el("span", "wx-clock-name");
        left.appendChild(el("strong", null, c.name));
        left.appendChild(el("small", null, c.utc_label + (c.day_offset === 1 ? " · amanhã" : c.day_offset === -1 ? " · ontem" : "")));
        var t = el("span", "wx-clock-time");
        r.appendChild(left); r.appendChild(t); box.appendChild(r);
        var m = c.local.match(/(\d+)-(\d+)-(\d+)T(\d+):(\d+):(\d+)/);
        return { t: t, ms: Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]) };
      });
      function paint() {
        var dt = Date.now() - fetchedAt;
        rows.forEach(function (r) {
          var x = new Date(r.ms + dt);
          r.t.textContent = pad(x.getUTCHours()) + ":" + pad(x.getUTCMinutes()) + ":" + pad(x.getUTCSeconds());
        });
        return dt;
      }
      paint();
      h.appendChild(box);
      var foot = el("div", "wx-foot");
      foot.appendChild(button(picking ? "Fechar" : "Cidades", "rail-ed-link", function () { renderClock(host, ctx, !picking); }));
      h.appendChild(foot);
      if (picking) {
        var sel = zones || d.cities.map(function (c) { return c.id; });
        var list = el("div", "wx-zones");
        d.available.forEach(function (z) {
          var lab = el("label", "wx-zone");
          var cb = el("input"); cb.type = "checkbox"; cb.checked = sel.indexOf(z.id) >= 0;
          cb.addEventListener("change", function () {
            var cur = (store(ZKEY) || sel).slice();
            var i = cur.indexOf(z.id);
            if (cb.checked && i < 0) cur.push(z.id);
            if (!cb.checked && i >= 0) cur.splice(i, 1);
            if (cb.checked && cur.length > 6) { cb.checked = false; return; }
            if (!cur.length) { cb.checked = true; return; }
            store(ZKEY, cur);
          });
          lab.appendChild(cb); lab.appendChild(el("span", null, z.name));
          list.appendChild(lab);
        });
        h.appendChild(list);
        h.appendChild(el("p", "hint", "Até 6 cidades. Toque em Fechar para atualizar."));
      }
      every(host, ctx, 1000, function (timer) {
        if (paint() > 30 * 60 * 1000) { clearInterval(timer); renderClock(host, ctx, picking); }  // horário de verão
      });
    });
  }

  /* ------------------------------------------------------------ Calendário */
  function renderCalendar(host, ctx, y, m) {
    // o "hoje" é o do fuso do navegador (funciona em qualquer lugar do mundo)
    var tz = "";
    try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) { tz = ""; }
    var CK = "driqy.cal.country", country = "";   // país dos feriados: escolha do usuário (vazio = automático pelo fuso)
    try { country = localStorage.getItem(CK) || ""; } catch (e) { country = ""; }
    var parts = [];
    if (y) parts.push("year=" + y, "month=" + m);
    if (tz) parts.push("tz=" + encodeURIComponent(tz));
    if (/^[A-Za-z]{2}$/.test(country)) parts.push("country=" + country);
    var qs = parts.join("&");
    load(host, ctx, "/calendar" + (qs ? "?" + qs : ""), function (h, d) {
      var tp = d.today.split("-");
      var isCurrent = +tp[0] === d.year && +tp[1] === d.month;
      function go(delta) {
        var mm = d.month + delta, yy = d.year;
        if (mm < 1) { mm = 12; yy--; }
        if (mm > 12) { mm = 1; yy++; }
        renderCalendar(host, ctx, yy, mm);
      }
      var head = el("div", "wx-cal-head");
      head.appendChild(button("‹", "rail-nav-btn", function () { go(-1); }, "Mês anterior"));
      head.appendChild(el("strong", "wx-cal-title", cap(d.month_name) + " " + d.year));
      head.appendChild(button("›", "rail-nav-btn", function () { go(1); }, "Próximo mês"));
      h.appendChild(head);
      var grid = el("div", "wx-cal-grid notranslate");
      grid.setAttribute("translate", "no");   // tradutor do navegador embaralhava os números dos dias
      // iniciais e primeiro dia da semana vêm da região (servidor antigo: domingo primeiro, em português)
      (d.weekdays && d.weekdays.length === 7 ? d.weekdays : ["D", "S", "T", "Q", "Q", "S", "S"]).forEach(function (w) { grid.appendChild(el("span", "wx-cal-wd", w)); });
      var blanks = d.first_offset != null ? d.first_offset : d.first_weekday;
      for (var b = 0; b < blanks; b++) grid.appendChild(el("span", "wx-cal-day wx-cal-blank"));
      var hol = {};
      d.holidays.forEach(function (x) { hol[x.day] = x; });
      for (var day = 1; day <= d.days_in_month; day++) {
        var cell = el("span", "wx-cal-day", String(day));
        if (isCurrent && day === +tp[2]) cell.classList.add("wx-cal-today");
        if (hol[day]) {
          cell.classList.add(hol[day].kind === "feriado" ? "wx-cal-hol" : "wx-cal-hol-soft");
          cell.title = hol[day].name;
        }
        grid.appendChild(cell);
      }
      h.appendChild(grid);
      if (d.holidays.length) {
        var ul = el("ul", "wx-cal-list");
        d.holidays.forEach(function (x) {
          ul.appendChild(el("li", null, pad(x.day) + " · " + x.name + (x.kind === "facultativo" ? " (facultativo)" : "")));
        });
        h.appendChild(ul);
      }
      if (d.countries && d.countries.length) {   // seletor do país dos feriados
        var cw = el("label", "wx-cal-country");
        cw.appendChild(el("span", "hint", "Feriados: "));
        var sel = el("select", "wx-cal-country-select");
        sel.setAttribute("aria-label", "País dos feriados");
        var auto = el("option", null, "Automático (" + d.country_name + ")");
        auto.value = "";
        sel.appendChild(auto);
        d.countries.forEach(function (c) { var o = el("option", null, c.name); o.value = c.code; sel.appendChild(o); });
        sel.value = d.country_chosen ? d.country : "";
        sel.addEventListener("change", function () {
          try { if (sel.value) localStorage.setItem(CK, sel.value); else localStorage.removeItem(CK); } catch (e) { /* sem storage: vale só agora */ }
          renderCalendar(host, ctx, y, m);
        });
        cw.appendChild(sel);
        h.appendChild(cw);
      }
      if (!isCurrent) {
        var foot = el("div", "wx-foot");
        foot.appendChild(button("Hoje", "rail-ed-link", function () { renderCalendar(host, ctx); }));
        h.appendChild(foot);
      }
    });
  }

  /* ------------------------------------------------------------ barra de progresso */
  function bar(pct, label) {
    var b = el("div", "wx-bar");
    b.setAttribute("role", "progressbar");
    b.setAttribute("aria-valuemin", "0");
    b.setAttribute("aria-valuemax", "100");
    b.setAttribute("aria-valuenow", String(Math.round(pct)));
    if (label) b.setAttribute("aria-label", label);
    var fill = el("span");
    fill.style.width = Math.max(0, Math.min(100, pct)) + "%";
    b.appendChild(fill);
    return b;
  }
  function fmt1(n) { return String(n).replace(".", ","); }
  function whenText(n) { return n <= 0 ? "hoje" : n === 1 ? "amanhã" : "em " + n + " dias"; }

  /* ------------------------------------------------------------ Fase da Lua */
  function renderMoon(host, ctx) {
    load(host, ctx, "/moon" + tzQuery(), function (h, d) {
      var box = el("div", "wx-moon");
      box.appendChild(el("div", "wx-moon-emoji", d.emoji));
      box.appendChild(el("strong", "wx-moon-name", d.phase));
      box.appendChild(el("span", "hint", d.illumination + "% iluminada · " + fmt1(d.age_days) + " dias"));
      if (d.trend) box.appendChild(el("span", "wx-moon-trend", (d.waxing ? "↗ " : "↘ ") + d.trend));
      h.appendChild(box);

      if (d.cycle_pct != null) {   // progresso da lunação (nova → nova)
        var cyc = el("div", "wx-moon-cycle");
        cyc.appendChild(bar(d.cycle_pct, "Progresso da lunação"));
        var lab = el("div", "wx-moon-cycle-labels");
        lab.appendChild(el("span", null, "🌑 nova"));
        lab.appendChild(el("span", null, Math.round(d.cycle_pct) + "% de " + fmt1(d.cycle_days) + " dias"));
        lab.appendChild(el("span", null, "nova 🌑"));
        cyc.appendChild(lab);
        h.appendChild(cyc);
      }
      if (d.distance_km) {
        var ul0 = el("ul", "wx-cal-list wx-moon-facts");
        ul0.appendChild(el("li", null, "📏 Distância: " + d.distance_km.toLocaleString("pt-BR") + " km · " + d.distance_label));
        h.appendChild(ul0);
      }
      if (d.rise_set) {            // nascer e pôr da Lua de hoje (no fuso do usuário; `tz_label` diz qual)
        var rs = d.rise_set, rsBox = el("div", "wx-moon-riseset");
        var rsRow = el("div", "wx-moon-riseset-row");
        rsRow.appendChild(el("span", null, "🌙↑ Nasce " + (rs.rise || "—")));
        rsRow.appendChild(el("span", null, "Se põe " + (rs.set || "—") + " ↓"));
        rsBox.appendChild(rsRow);
        var note = (rs.up_now ? "No céu agora" : "Abaixo do horizonte");
        if (rs.next) note += " · " + rs.next.label.toLowerCase() + (rs.next.today ? " hoje" : " amanhã") + " às " + rs.next.time;
        note += " · " + (rs.approximate ? "Brasília (defina sua cidade no perfil)" : rs.place) + " · " + tzWords(d.tz_label);
        rsBox.appendChild(el("small", "hint", note));
        h.appendChild(rsBox);
      }
      var ul = el("ul", d.events ? "wx-moon-events" : "wx-cal-list");
      if (d.events) {              // os 4 marcos do ciclo, do mais perto para o mais longe
        d.events.forEach(function (e, i) {
          var li = el("li", i === 0 ? "next" : null);
          li.appendChild(el("span", null, e.emoji + " " + e.name));
          li.appendChild(el("small", null, dm(e.date) + " · " + whenText(e.days)));
          ul.appendChild(li);
        });
      } else {                     // servidor antigo: só cheia e nova
        ul.appendChild(el("li", null, "🌕 Próxima cheia: " + dm(d.next_full) + " (" + whenText(d.days_to_full) + ")"));
        ul.appendChild(el("li", null, "🌑 Próxima nova: " + dm(d.next_new) + " (" + whenText(d.days_to_new) + ")"));
      }
      h.appendChild(ul);

      if (d.eclipses && d.eclipses.length) {   // próximos eclipses (o mais perto em destaque)
        h.appendChild(el("div", "wx-eclipse-title", "Próximos eclipses · " + tzWords(d.tz_label)));
        var ule = el("ul", "wx-moon-events wx-eclipses");
        d.eclipses.forEach(function (e, i) {
          var li = el("li", i === 0 ? "next" : null);
          li.appendChild(el("span", null, e.emoji + " " + e.name));
          li.appendChild(el("small", null, dm(e.date) + " · " + whenText(e.days)));
          ule.appendChild(li);
          var sub = "máximo às " + e.time + (e.visible_here === true ? " · visível daqui" : e.visible_here === false ? " · não visível daqui" : "");
          ule.appendChild(el("li", "wx-eclipse-sub", sub));
        });
        h.appendChild(ule);
      }
    });
  }

  /* ------------------------------------------------------------ Estações */
  function renderSeasons(host, ctx) {
    load(host, ctx, "/seasons" + tzQuery(), function (h, d) {
      var c = d.current;
      var now = el("div", "wx-season-now");
      now.appendChild(el("div", "wx-season-emoji", c.emoji));
      var info = el("div", "wx-season-info");
      info.appendChild(el("strong", null, c.name));
      info.appendChild(el("span", "hint", "Dia " + c.day_number + " de " + c.days + " · " + (c.days_left === 0 ? "vira hoje" : (c.days_left === 1 ? "falta 1 dia" : "faltam " + c.days_left + " dias"))));
      now.appendChild(info);
      h.appendChild(now);

      var big = el("div", "wx-season-big");
      big.appendChild(bar(c.progress, "Progresso da " + c.name));
      var meta = el("div", "wx-season-bar-meta");
      meta.appendChild(el("span", null, dm(c.start)));
      meta.appendChild(el("span", null, fmt1(c.progress) + "%"));
      meta.appendChild(el("span", null, dm(c.end)));
      big.appendChild(meta);
      h.appendChild(big);

      if (d.alert) h.appendChild(el("div", "wx-season-alert", d.next.emoji + " " + d.alert));

      var year = el("div", "wx-year-bar");   // o ano em 4 faixas: cheia = passou, parcial = estação atual
      d.cycle.forEach(function (s) {
        var seg = el("div", "wx-year-seg " + s.status);
        seg.title = s.name + " · " + dm(s.start) + " a " + dm(s.end);
        seg.appendChild(bar(s.progress, s.name));
        seg.appendChild(el("span", null, s.emoji + " " + s.name));
        year.appendChild(seg);
      });
      h.appendChild(year);

      h.appendChild(el("div", "wx-season-next",
        "Próxima: " + d.next.emoji + " " + d.next.name + " em " + dm(d.next.start) + " às " + d.next.start_label.slice(-5) + " (" + d.next.event + ")" + (d.tz_label && d.tz_label !== "Brasília" ? " · " + d.tz_label : "") + " · ano " + fmt1(d.year_progress) + "%"));
    });
  }

  /* ------------------------------------------------------------ Cotações */
  var BRL = typeof Intl !== "undefined" ? new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }) : null;
  function money(v) { return BRL ? BRL.format(v) : "R$ " + v.toFixed(2).replace(".", ","); }
  function drawQuotes(h, d) {
    h.textContent = "";
    var box = el("div", "wx-quotes");
    d.items.forEach(function (q) {
      var r = el("div", "wx-quote");
      var left = el("span", "wx-quote-name");
      left.appendChild(el("strong", null, q.name));
      if (q.high != null && q.low != null) left.appendChild(el("small", null, "mín " + money(q.low) + " · máx " + money(q.high)));
      var right = el("span", "wx-quote-val");
      right.appendChild(el("strong", null, money(q.value)));
      var c = q.change_pct || 0;
      right.appendChild(el("small", c > 0 ? "wx-up" : c < 0 ? "wx-down" : "", (c > 0 ? "▲ " : c < 0 ? "▼ " : "") + Math.abs(c).toFixed(2).replace(".", ",") + "%"));
      r.appendChild(left); r.appendChild(right); box.appendChild(r);
    });
    h.appendChild(box);
    var t = d.updated_at ? new Date(d.updated_at) : null;
    h.appendChild(el("p", "hint", (t && !isNaN(t) ? "Atualizado às " + pad(t.getHours()) + ":" + pad(t.getMinutes()) : "") +
      (d.stale ? " (dados antigos: sem conexão com a fonte)" : "")));
  }
  function renderQuotes(host, ctx) {
    note(host, "Carregando…");
    function fail(reason) {
      note(host, reason === "disabled" ? "Cotações desligadas pelo administrador." : "Cotações indisponíveis agora.",
        reason === "disabled" ? null : function () { renderQuotes(host, ctx); });
    }
    api("/quotes").then(function (d) {
      if (!ctx.isActive()) return;
      if (!d.ok) { fail(d.reason); return; }
      drawQuotes(host, d);
      every(host, ctx, 5 * 60 * 1000, function () {
        api("/quotes").then(function (n) { if (alive(host, ctx) && n.ok) drawQuotes(host, n); }).catch(function () {});
      });
    }).catch(function () { if (ctx.isActive()) fail("unavailable"); });
  }

  /* ------------------------------------------------------------ Seu Driqy */
  function renderStats(host, ctx) {
    load(host, ctx, "/stats", function (h, d) {
      var nf = function (n) { return Number(n || 0).toLocaleString("pt-BR"); };
      var grid = el("div", "wx-stats");
      [["Seguidores", d.followers], ["Seguindo", d.following], ["Posts no ar", d.posts_live],
       ["Visualizações", d.views], ["Curtidas", d.likes], ["Comentários", d.comments]].forEach(function (t) {
        var c = el("div", "wx-stat");
        c.appendChild(el("strong", null, nf(t[1])));
        c.appendChild(el("small", null, t[0]));
        grid.appendChild(c);
      });
      h.appendChild(grid);
      if (d.new_followers_7d > 0) {
        h.appendChild(el("p", "hint", "+" + nf(d.new_followers_7d) + (d.new_followers_7d === 1 ? " novo seguidor" : " novos seguidores") + " nos últimos 7 dias"));
      }
    });
  }

  /* ------------------------------------------------------------ Acabando */
  function left(sec) {
    if (sec < 60) return "menos de 1 min";
    var m = Math.floor(sec / 60), hh = Math.floor(m / 60);
    return hh ? hh + " h " + pad(m % 60) + " min" : m + " min";
  }
  function renderExpiring(host, ctx) {
    load(host, ctx, "/expiring", function (h, d) {
      var posts = d.posts || [];
      if (!posts.length) { note(h, "Nenhum post temporário some nas próximas 48 h."); return; }
      var t0 = Date.now(), items = [];
      posts.forEach(function (p) {
        var a = el("a", "rail-row"); a.href = p.url;
        a.appendChild(avatar(p.author));
        var b = el("span", "rail-row-body");
        b.appendChild(el("strong", "rail-row-title", (p.mine ? "Você" : "@" + p.author.username)));
        b.appendChild(el("span", "rail-row-text", p.snippet));
        var m = el("span", "rail-row-meta wx-urgent");
        b.appendChild(m); a.appendChild(b); h.appendChild(a);
        items.push({ m: m, sec: p.seconds_left });
      });
      function paint() {
        var dt = Math.floor((Date.now() - t0) / 1000);
        items.forEach(function (i) { i.m.textContent = "⏳ " + (i.sec - dt <= 0 ? "acabou" : "some em " + left(i.sec - dt)); });
      }
      paint();
      every(host, ctx, 30000, paint);
    });
  }

  /* ------------------------------------------------------------ Frase do dia */
  function renderPhrase(host, ctx) {
    load(host, ctx, "/phrase", function (h, d) {
      var q = el("blockquote", "wx-phrase");
      q.appendChild(el("p", null, "“" + d.text + "”"));
      if (d.author) q.appendChild(el("footer", null, "— " + d.author));
      h.appendChild(q);
    });
  }

  /* ------------------------------------------------------------ Foco (pomodoro) */
  var PKEY = "driqy-rail-pomo";
  var MODES = { focus: ["Foco", 25 * 60], short: ["Pausa", 5 * 60], long: ["Pausa longa", 15 * 60] };
  var pomoListeners = [], pomoTimer = null;
  function today() { var n = new Date(); return n.getFullYear() + "-" + pad(n.getMonth() + 1) + "-" + pad(n.getDate()); }
  function pomoState() {
    var s = store(PKEY);
    if (!s || !MODES[s.mode]) s = { mode: "focus", running: false, endAt: 0, left: MODES.focus[1] };
    if (!s.done || s.done.date !== today()) s.done = { date: today(), n: 0 };
    return s;
  }
  function beep() {
    try {
      var C = window.AudioContext || window.webkitAudioContext;
      if (!C) return;
      var ac = new C();
      [0, 0.25, 0.5].forEach(function (t, i) {
        var o = ac.createOscillator(), g = ac.createGain();
        o.frequency.value = i === 2 ? 880 : 660; g.gain.value = 0.08;
        o.connect(g); g.connect(ac.destination);
        o.start(ac.currentTime + t); o.stop(ac.currentTime + t + 0.18);
      });
      setTimeout(function () { if (ac.close) ac.close(); }, 1500);
    } catch (e) {}
  }
  function pomoTick() {
    var s = pomoState();
    if (s.running && Date.now() >= s.endAt) {
      var late = Date.now() - s.endAt;
      s.running = false;
      if (s.mode === "focus") { s.done.n++; s.mode = s.done.n % 4 === 0 ? "long" : "short"; } else s.mode = "focus";
      s.left = MODES[s.mode][1];
      store(PKEY, s);
      if (late < 5000) beep();
    }
    pomoListeners = pomoListeners.filter(function (l) { return l(s); });
    if (!s.running && pomoTimer) { clearInterval(pomoTimer); pomoTimer = null; }
  }
  function pomoEnsure() { if (!pomoTimer) pomoTimer = setInterval(pomoTick, 1000); }
  if (pomoState().running) pomoEnsure();  // toca o aviso mesmo com outro widget na tela

  function renderPomodoro(host, ctx) {
    var box = el("div", "wx-pomo");
    var tabs = el("div", "wx-pomo-tabs");
    var time = el("div", "wx-pomo-time");
    var bar = el("div", "wx-pomo-bar"), fill = el("span"); bar.appendChild(fill);
    var count = el("p", "hint wx-pomo-count");
    var ctl = el("div", "wx-pomo-ctl");
    var tabBtns = {};
    Object.keys(MODES).forEach(function (k) {
      tabBtns[k] = button(MODES[k][0], "wx-chip", function () {
        store(PKEY, { mode: k, running: false, endAt: 0, left: MODES[k][1], done: pomoState().done });
        paint(pomoState());
      });
      tabs.appendChild(tabBtns[k]);
    });
    var go = button("Iniciar", "btn wx-pomo-go", function () {
      var s = pomoState();
      if (s.running) { s.left = Math.max(1, Math.round((s.endAt - Date.now()) / 1000)); s.running = false; }
      else { s.running = true; s.endAt = Date.now() + s.left * 1000; }
      store(PKEY, s); if (s.running) pomoEnsure(); paint(s);
    });
    var reset = button("Reiniciar", "rail-ed-link", function () {
      var s = pomoState(); s.running = false; s.left = MODES[s.mode][1]; store(PKEY, s); paint(s);
    });
    ctl.appendChild(go); ctl.appendChild(reset);
    [tabs, time, bar, ctl, count].forEach(function (n) { box.appendChild(n); });
    host.appendChild(box);
    function paint(s) {
      if (!alive(host, ctx)) return false;
      var sec = s.running ? Math.max(0, Math.round((s.endAt - Date.now()) / 1000)) : s.left;
      time.textContent = pad(Math.floor(sec / 60)) + ":" + pad(sec % 60);
      fill.style.width = Math.round((1 - sec / MODES[s.mode][1]) * 100) + "%";
      go.textContent = s.running ? "Pausar" : (sec < MODES[s.mode][1] ? "Continuar" : "Iniciar");
      Object.keys(tabBtns).forEach(function (k) { tabBtns[k].classList.toggle("active", k === s.mode); });
      count.textContent = s.done.n ? "Hoje: " + s.done.n + (s.done.n === 1 ? " foco concluído" : " focos concluídos") : "25 min de foco, 5 de pausa.";
      return true;
    }
    paint(pomoState());
    pomoListeners.push(function (s) { return paint(s); });
    if (pomoState().running) pomoEnsure();
  }

  /* ------------------------------------------------------------ Calculadora */
  function renderCalc(host, ctx) {
    var st = { cur: "0", acc: null, op: null, fresh: true, err: false };
    var box = el("div", "wx-calc");
    box.tabIndex = 0;
    var disp = el("div", "wx-calc-disp"), hist = el("small", "wx-calc-hist");
    box.appendChild(hist); box.appendChild(disp);
    function fmt(n) {
      if (!isFinite(n)) return null;
      return String(parseFloat(n.toPrecision(12)));
    }
    function show() {
      hist.textContent = st.acc != null && st.op ? fmt(st.acc).replace(".", ",") + " " + st.op : "";
      disp.textContent = st.err ? "Erro" : st.cur.replace(".", ",");
    }
    function compute() {
      var a = st.acc, b = parseFloat(st.cur), r;
      if (st.op === "+") r = a + b; else if (st.op === "−") r = a - b; else if (st.op === "×") r = a * b;
      else r = b === 0 ? NaN : a / b;
      var f = fmt(r);
      if (f == null) { st.err = true; st.cur = "0"; st.acc = null; st.op = null; st.fresh = true; return; }
      st.cur = f;
    }
    function digit(d) {
      if (st.err) { st.err = false; st.cur = "0"; st.fresh = true; }
      if (st.fresh) { st.cur = d; st.fresh = false; }
      else if (st.cur.replace(/[-.]/g, "").length < 14) st.cur = st.cur === "0" ? d : st.cur + d;
      show();
    }
    function dot() {
      if (st.err) { st.err = false; st.cur = "0"; st.fresh = true; }
      if (st.fresh) { st.cur = "0."; st.fresh = false; }
      else if (st.cur.indexOf(".") < 0) st.cur += ".";
      show();
    }
    function operator(o) {
      if (st.err) return;
      if (st.op && !st.fresh) { compute(); if (st.err) { show(); return; } }
      st.acc = parseFloat(st.cur); st.op = o; st.fresh = true; show();
    }
    function equals() {
      if (st.err || !st.op) return;
      compute(); st.acc = null; st.op = null; st.fresh = true; show();
    }
    function clear() { st = { cur: "0", acc: null, op: null, fresh: true, err: false }; show(); }
    function back() {
      if (st.err) { clear(); return; }
      if (st.fresh) return;
      st.cur = st.cur.length > 1 && !(st.cur.length === 2 && st.cur[0] === "-") ? st.cur.slice(0, -1) : "0";
      if (st.cur === "0") st.fresh = true;
      show();
    }
    function percent() { if (!st.err) { st.cur = fmt(parseFloat(st.cur) / 100); st.fresh = true; show(); } }
    function neg() { if (!st.err && st.cur !== "0") { st.cur = st.cur[0] === "-" ? st.cur.slice(1) : "-" + st.cur; show(); } }
    var keys = [["C", clear, "fn"], ["⌫", back, "fn"], ["%", percent, "fn"], ["÷", function () { operator("÷"); }, "op"],
      ["7"], ["8"], ["9"], ["×", function () { operator("×"); }, "op"],
      ["4"], ["5"], ["6"], ["−", function () { operator("−"); }, "op"],
      ["1"], ["2"], ["3"], ["+", function () { operator("+"); }, "op"],
      ["±", neg, "fn"], ["0"], [",", dot, "fn"], ["=", equals, "eq"]];
    var pad_ = el("div", "wx-calc-keys");
    keys.forEach(function (k) {
      var fn = k[1] || function () { digit(k[0]); };
      pad_.appendChild(button(k[0], "wx-calc-key" + (k[2] ? " " + k[2] : ""), fn, k[0] === "⌫" ? "Apagar" : null));
    });
    box.appendChild(pad_);
    box.addEventListener("keydown", function (e) {
      var k = e.key;
      if (/^[0-9]$/.test(k)) digit(k);
      else if (k === "," || k === ".") dot();
      else if (k === "+") operator("+");
      else if (k === "-") operator("−");
      else if (k === "*" || k === "x") operator("×");
      else if (k === "/") operator("÷");
      else if (k === "Enter" || k === "=") equals();
      else if (k === "Backspace") back();
      else if (k === "Escape" || k === "Delete") clear();
      else if (k === "%") percent();
      else return;
      e.preventDefault();
    });
    host.appendChild(box);
    show();
  }

  /* ------------------------------------------------------------ Respirar */
  var PHASES = [["Inspire", 4000, 1], ["Segure", 4000, 1], ["Expire", 6000, 0.55]];
  var SESSION_MS = 60000;
  function renderBreathe(host, ctx) {
    var box = el("div", "wx-breathe");
    var ring = el("div", "wx-breathe-ring"), circle = el("div", "wx-breathe-circle");
    ring.appendChild(circle);
    var label = el("strong", "wx-breathe-label", "Respirar");
    var sub = el("p", "hint", "Um minuto: inspire 4 s, segure 4 s, expire 6 s.");
    var run = null;
    var go = button("Começar", "btn wx-pomo-go", function () { run ? stop("Parado.") : start(); });
    box.appendChild(ring); box.appendChild(label); box.appendChild(go); box.appendChild(sub);
    host.appendChild(box);
    function stop(msg) {
      if (run) clearTimeout(run.t);
      run = null;
      circle.style.transition = "transform 400ms ease-out"; circle.style.transform = "scale(0.55)";
      label.textContent = msg; go.textContent = "Começar";
    }
    function start() {
      run = { t: null, at: Date.now(), cycles: 0 };
      go.textContent = "Parar";
      circle.style.transition = "none"; circle.style.transform = "scale(0.55)";
      void circle.offsetWidth;
      step(0);
    }
    function step(i) {
      if (!run) return;
      if (!alive(host, ctx)) { stop(""); return; }
      if (i === 0 && Date.now() - run.at >= SESSION_MS) { stop("Pronto. Respire normalmente."); sub.textContent = run.cycles + " ciclos."; return; }
      var p = PHASES[i];
      label.textContent = p[0];
      circle.style.transition = "transform " + p[1] + "ms ease-in-out";
      circle.style.transform = "scale(" + p[2] + ")";
      run.t = setTimeout(function () { if (i === PHASES.length - 1 && run) run.cycles++; step((i + 1) % PHASES.length); }, p[1]);
    }
  }

  /* ------------------------------------------------------------ registro */
  [["clock", "Relógio mundial", renderClock], ["calendar", "Calendário", renderCalendar], ["moon", "Fase da Lua", renderMoon], ["seasons", "Estações", renderSeasons],
   ["quotes", "Cotações", renderQuotes], ["stats", "Seu Driqy", renderStats], ["expiring", "Acabando", renderExpiring],
   ["phrase", "Frase do dia", renderPhrase], ["pomodoro", "Foco", renderPomodoro], ["calc", "Calculadora", renderCalc],
   ["breathe", "Respirar", renderBreathe]].forEach(function (w) {
    window.DriqyRail.register({ id: w[0], title: w[1], render: function (body, ctx) { w[2](body, ctx); } });
  });
})();
