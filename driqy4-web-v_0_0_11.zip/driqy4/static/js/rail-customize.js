/* "Personalizar painel": o usuário esconde o painel direito inteiro, tira widgets, troca a ordem
   e escolhe se mostra/onde fica o cartão de sugestões. Salva no servidor (vale no site e no app).
   Textos vindos do servidor entram só via textContent. */
(function () {
  "use strict";
  var cfg = window.__railCfg;
  var url = window.__railPrefsUrl;
  if (!cfg || !url) return;

  var TITLES = { weather: "O clima hoje", trending: "Em alta", news: "Notícias", vortex: "Vortex", online: "Quem está online" };

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function titleOf(w) { return TITLES[w.id] || w.title; }

  function openDialog() {
    var titles = {};
    var customIds = {};
    cfg.widgets.forEach(function (w) { titles[w.id] = titleOf(w); if (w.custom) customIds[w.id] = true; });
    var p = cfg.prefs;
    var state = {
      rail_hidden: !!p.rail_hidden,
      order: p.order.slice(),
      disabled: p.disabled.slice(),
      suggest: !!p.suggest,
      suggest_first: !!p.suggest_first
    };

    var overlay = el("div", "rail-cz-overlay");
    var box = el("div", "rail-cz-box");
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-label", "Personalizar painel");
    overlay.appendChild(box);
    box.appendChild(el("h2", "rail-cz-title", "Personalizar painel"));

    function check(label, checked, onChange) {
      var row = el("label", "rail-cz-check");
      var input = el("input");
      input.type = "checkbox";
      input.checked = checked;
      input.addEventListener("change", function () { onChange(input.checked); });
      row.appendChild(input);
      row.appendChild(el("span", null, label));
      return row;
    }

    var body = el("div", "rail-cz-body");
    box.appendChild(body);

    function move(arr, i, d) {
      var j = i + d;
      if (j < 0 || j >= arr.length) return;
      var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }

    function arrow(label, text, disabled, fn) {
      var b = el("button", "rail-cz-arrow", text);
      b.type = "button";
      b.setAttribute("aria-label", label);
      b.disabled = disabled;
      b.addEventListener("click", fn);
      return b;
    }

    function render() {
      body.textContent = "";
      body.appendChild(check("Mostrar o painel da direita", !state.rail_hidden, function (v) { state.rail_hidden = !v; render(); }));
      if (state.rail_hidden) {
        body.appendChild(el("p", "hint", "O painel fica escondido. Para voltar, use “Personalizar painel” em Configurações."));
        return;
      }

      body.appendChild(el("h3", "rail-cz-sub", "Widgets"));
      var list = el("ul", "rail-cz-list");
      state.order.forEach(function (id, i) {
        var li = el("li", "rail-cz-item");
        var box1 = check(titles[id] || id, state.disabled.indexOf(id) < 0, function (v) {
          var k = state.disabled.indexOf(id);
          if (v && k >= 0) state.disabled.splice(k, 1);
          if (!v && k < 0) state.disabled.push(id);
        });
        if (customIds[id]) box1.appendChild(el("span", "rail-ed-tag", "seu")); // widget criado em "Minha área"
        li.appendChild(box1);
        li.appendChild(arrow("Subir " + (titles[id] || id), "▲", i === 0, function () { move(state.order, i, -1); render(); }));
        li.appendChild(arrow("Descer " + (titles[id] || id), "▼", i === state.order.length - 1, function () { move(state.order, i, 1); render(); }));
        list.appendChild(li);
      });
      body.appendChild(list);

      body.appendChild(el("h3", "rail-cz-sub", "Sugestões para você"));
      body.appendChild(check("Mostrar o cartão de sugestões", state.suggest, function (v) { state.suggest = v; render(); }));
      if (state.suggest) {
        body.appendChild(check("Colocar acima dos widgets", state.suggest_first, function (v) { state.suggest_first = v; }));
      }
    }
    render();

    var err = el("p", "rail-cz-err");
    box.appendChild(err);
    var actions = el("div", "rail-cz-actions");
    var reset = el("button", "btn-outline", "Restaurar padrão");
    var cancel = el("button", "btn-outline", "Cancelar");
    var save = el("button", "btn", "Salvar");
    [reset, cancel, save].forEach(function (b) { b.type = "button"; });
    actions.appendChild(reset); actions.appendChild(cancel); actions.appendChild(save);
    box.appendChild(actions);

    function close() { overlay.remove(); document.removeEventListener("keydown", onKey); }
    function onKey(e) { if (e.key === "Escape") close(); }
    document.addEventListener("keydown", onKey);
    overlay.addEventListener("mousedown", function (e) { if (e.target === overlay) close(); });
    cancel.addEventListener("click", close);
    reset.addEventListener("click", function () {
      state.rail_hidden = false; state.disabled = []; state.suggest = true; state.suggest_first = false;
      state.order = cfg.widgets.map(function (w) { return w.id; });
      render();
    });
    save.addEventListener("click", function () {
      save.disabled = true; save.textContent = "Salvando…";
      fetch(url, {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-Requested-With": "fetch", Accept: "application/json" },
        body: JSON.stringify(state)
      }).then(function (r) {
        if (!r.ok) throw new Error("http");
        window.location.reload();
      }).catch(function () {
        err.textContent = "Não foi possível salvar agora. Tente de novo.";
        save.disabled = false; save.textContent = "Salvar";
      });
    });

    document.body.appendChild(overlay);
    save.focus();
  }

  document.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest("[data-rail-customize]");
    if (!t) return;
    e.preventDefault();
    // se veio de dentro de Configurações, fecha o modal (restaura o scroll da página) antes de abrir este
    var sm = document.getElementById("settings-modal"), sc = document.getElementById("settings-close");
    if (sm && !sm.hidden && sc) sc.click();
    openDialog();
  });
})();
