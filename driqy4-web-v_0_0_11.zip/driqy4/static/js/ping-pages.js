/* Mensagens — fase 8: tela Contatos (busca no cliente). A tela de Configurações foi removida (agora é o menu lateral).
   Página inteira (não é fragmento da 6a): nenhum listener em document/window. */
(function () {
  function norm(t) {
    return (t || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }

  // ---- Contatos: filtra a lista renderizada pelo servidor (nome ou @) ----
  var q = document.getElementById("ping-contacts-q");
  var list = document.getElementById("ping-contact-list");
  if (q && list) {
    var empty = document.getElementById("ping-contacts-empty");
    q.addEventListener("input", function () {
      var term = norm(q.value.trim());
      var shown = 0;
      list.querySelectorAll(".ping-contact-row").forEach(function (row) {
        var hit = !term || norm(row.dataset.name).indexOf(term) !== -1 || norm(row.dataset.username).indexOf(term) !== -1;
        row.hidden = !hit;
        if (hit) shown++;
      });
      if (empty) empty.hidden = !(term && shown === 0);
    });
  }
})();
