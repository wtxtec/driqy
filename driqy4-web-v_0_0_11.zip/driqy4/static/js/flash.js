/* Flash — stories de 24h: bandeja no feed, anel nos avatares e visualizador em tela cheia. */
(function () {
  "use strict";
  var API = "/api/v1";
  var HDR = { "X-Requested-With": "fetch" };
  var DURATION = 5000;
  var $ = function (s, r) { return (r || document).querySelector(s); };

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function get(url) {
    return fetch(url, { headers: HDR, credentials: "same-origin" }).then(function (r) {
      if (!r.ok) throw new Error(r.status); return r.json();
    });
  }
  function send(method, url, body) {
    return fetch(url, { method: method, headers: HDR, body: body, credentials: "same-origin" })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, data: j }; }); });
  }
  function ago(iso) {
    var m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
    if (m < 1) return "agora";
    if (m < 60) return "há " + m + " min";
    return "há " + Math.floor(m / 60) + " h";
  }
  function avatarNode(u, cls) {
    if (u.avatar_url) { var i = el("img", cls); i.src = u.avatar_url; i.alt = ""; return i; }
    return el("span", cls + "-ph " + (cls || ""), (u.username || "?")[0].toUpperCase());
  }

  /* ---------------- visualizador ---------------- */
  var viewer = null;

  function openViewer(queue, startIndex, onClose) {
    closeViewer();
    var qi = startIndex || 0, fi = 0, group = null, timer = null, startAt = 0, elapsed = 0, paused = false;
    var root = el("div", "flash-viewer");
    var stage = el("div", "flash-stage");
    var bars = el("div", "flash-bars");
    var img = el("img", "flash-img");
    var head = el("div", "flash-head");
    var cap = el("div", "flash-caption");
    var prev = el("div", "flash-tap prev"), next = el("div", "flash-tap next");
    var views = el("button", "flash-btn flash-views"); views.hidden = true;
    stage.append(img, cap, bars, head, prev, next, views);
    root.appendChild(stage);
    document.body.appendChild(root);
    document.body.style.overflow = "hidden";
    viewer = { root: root, stop: stop, onClose: onClose };

    function stop() { if (timer) cancelAnimationFrame(timer); timer = null; }
    function finish() { closeViewer(); }

    function loadGroup(i) {
      qi = i;
      return get(API + "/users/" + encodeURIComponent(queue[qi]) + "/flashes").then(function (d) {
        group = d;
        if (!d.flashes.length) return nextGroup();
        var firstUnseen = d.flashes.findIndex(function (f) { return !f.seen; });
        fi = firstUnseen < 0 ? 0 : firstUnseen;  // retoma no primeiro não visto
        show();
      }).catch(finish);
    }
    function nextGroup() { if (qi + 1 < queue.length) loadGroup(qi + 1); else finish(); }
    function prevGroup() { if (qi > 0) loadGroup(qi - 1); else show(); }

    function show() {
      stop();
      var f = group.flashes[fi], u = group.user;
      bars.textContent = "";
      group.flashes.forEach(function (_, k) { var b = el("div", "flash-bar" + (k < fi ? " done" : "")); b.appendChild(el("i")); bars.appendChild(b); });
      head.textContent = "";
      head.appendChild(avatarNode(u, ""));
      var who = el("div"); who.append(el("b", "", u.display_name || u.username), document.createTextNode(" "), el("small", "", ago(f.created_at)));
      head.appendChild(who);
      head.appendChild(el("span", "flash-spacer"));
      var mine = f.views_count !== null && f.views_count !== undefined;
      if (mine) {
        var del = el("button", "flash-btn", "Excluir");
        del.onclick = function (e) {
          e.stopPropagation(); pause();
          if (!confirm("Excluir este Flash?")) { resume(); return; }
          send("DELETE", API + "/flashes/" + f.id).then(function () {
            group.flashes.splice(fi, 1);
            if (!group.flashes.length) { finish(); return; }
            fi = Math.min(fi, group.flashes.length - 1); show();
          });
        };
        head.appendChild(del);
      }
      var x = el("button", "flash-btn", "✕"); x.onclick = function (e) { e.stopPropagation(); finish(); }; head.appendChild(x);
      cap.textContent = f.caption || ""; cap.style.display = f.caption ? "" : "none";
      views.hidden = !mine;
      if (mine) {
        views.textContent = "👁 " + f.views_count;
        views.onclick = function (e) { e.stopPropagation(); showViewers(f); };
      }
      img.onload = function () { startTimer(); };
      img.onerror = function () { startTimer(); };
      img.src = f.image_url;
      if (!f.seen && !mine) { send("POST", API + "/flashes/" + f.id + "/view"); f.seen = true; }
    }

    function startTimer() {
      elapsed = 0; startAt = performance.now(); paused = false; tick();
    }
    function tick() {
      timer = requestAnimationFrame(function (now) {
        if (paused) { startAt = now - elapsed; return tick(); }
        elapsed = now - startAt;
        var bar = bars.children[fi]; if (bar) bar.firstChild.style.width = Math.min(100, elapsed / DURATION * 100) + "%";
        if (elapsed >= DURATION) return goNext();
        tick();
      });
    }
    function pause() { paused = true; }
    function resume() { paused = false; }
    function goNext() { if (fi + 1 < group.flashes.length) { fi++; show(); } else nextGroup(); }
    function goPrev() { if (fi > 0) { fi--; show(); } else prevGroup(); }

    function showViewers(f) {
      pause();
      get(API + "/flashes/" + f.id + "/viewers").then(function (d) {
        var m = el("div", "flash-modal"), box = el("div", "flash-modal-box");
        box.appendChild(el("b", "", d.viewers.length ? "Quem viu (" + d.viewers.length + ")" : "Ninguém viu ainda"));
        d.viewers.forEach(function (v) { box.appendChild(el("div", "", "@" + v.username + " · " + ago(v.viewed_at))); });
        var ok = el("button", "btn-outline", "Fechar"); ok.onclick = function () { m.remove(); resume(); };
        box.appendChild(ok); m.appendChild(box); document.body.appendChild(m);
      });
    }

    next.onclick = goNext; prev.onclick = goPrev;
    [prev, next].forEach(function (t) {
      t.addEventListener("pointerdown", pause);
      t.addEventListener("pointerup", resume);
      t.addEventListener("pointerleave", resume);
    });
    root.addEventListener("click", function (e) { if (e.target === root) finish(); });
    viewer.key = function (e) {
      if (e.key === "Escape") finish();
      else if (e.key === "ArrowRight") goNext();
      else if (e.key === "ArrowLeft") goPrev();
    };
    document.addEventListener("keydown", viewer.key);
    loadGroup(qi);
  }

  function closeViewer() {
    if (!viewer) return;
    viewer.stop();
    document.removeEventListener("keydown", viewer.key);
    viewer.root.remove();
    document.body.style.overflow = "";
    var cb = viewer.onClose; viewer = null;
    if (cb) cb();
  }

  /* ---------------- publicar ---------------- */
  function pickAndPublish(done) {
    var input = el("input"); input.type = "file"; input.accept = "image/png,image/jpeg,image/webp";
    input.onchange = function () {
      var file = input.files && input.files[0]; if (!file) return;
      var m = el("div", "flash-modal"), box = el("div", "flash-modal-box");
      var pv = el("img"); pv.src = URL.createObjectURL(file);
      var cap = el("input"); cap.type = "text"; cap.maxLength = 200; cap.placeholder = "Legenda (opcional)";
      var err = el("small", "", ""); err.style.color = "#e2536b";
      var acts = el("div", "flash-modal-actions");
      var cancel = el("button", "btn-outline", "Cancelar"), ok = el("button", "btn", "Publicar Flash (24h)");
      cancel.onclick = function () { m.remove(); };
      ok.onclick = function () {
        ok.disabled = true; ok.textContent = "Enviando…";
        var fd = new FormData(); fd.append("file", file); fd.append("caption", cap.value);
        send("POST", API + "/flashes", fd).then(function (r) {
          if (r.ok) { m.remove(); done && done(); }
          else { err.textContent = (r.data && r.data.error) || "Não foi possível publicar."; ok.disabled = false; ok.textContent = "Publicar Flash (24h)"; }
        });
      };
      acts.append(cancel, ok); box.append(pv, cap, err, acts); m.appendChild(box); document.body.appendChild(m);
    };
    input.click();
  }

  /* ---------------- bandeja do feed ---------------- */
  function renderTray() {
    var tray = $("#flash-tray"); if (!tray) return;
    get(API + "/flashes/tray").then(function (d) {
      tray.textContent = "";
      /* sem Flash de ninguém (nem meu): a bandeja some; ela aparece quando alguém publicar */
      if (!d.me.count && !d.items.length) return;
      var me = d.me, mineBtn = el("button", "flash-bubble " + (me.count ? "flash-bubble--seen" : "flash-bubble--none"));
      mineBtn.type = "button";
      var av = el("div", "flash-bubble-av"), im = avatarNode(me.user, "flash-bubble-img");
      av.appendChild(im);
      var plus = el("span", "flash-bubble-add", "+");
      plus.title = "Novo Flash";
      plus.onclick = function (e) { e.stopPropagation(); pickAndPublish(renderTray); };
      av.appendChild(plus);
      mineBtn.append(av, el("span", "flash-bubble-name", "Seu Flash"));
      mineBtn.onclick = function () { if (me.count) openViewer([me.user.username], 0, renderTray); else pickAndPublish(renderTray); };
      tray.appendChild(mineBtn);
      var queue = d.items.map(function (i) { return i.user.username; });
      d.items.forEach(function (it, idx) {
        var b = el("button", "flash-bubble " + (it.unseen ? "" : "flash-bubble--seen")); b.type = "button";
        var a = el("div", "flash-bubble-av"); a.appendChild(avatarNode(it.user, "flash-bubble-img"));
        b.append(a, el("span", "flash-bubble-name", it.user.display_name || it.user.username));
        b.onclick = function () { openViewer(queue, idx, renderTray); };
        tray.appendChild(b);
      });
    }).catch(function () {});
  }

  /* avatares com anel (post, perfil): toque abre o Flash em vez de ir ao perfil */
  document.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest("[data-flash-user].flash-ring");
    if (!t) return;
    /* avatar do autor no feed: vai direto ao perfil da pessoa (não abre o Flash) */
    if (t.classList.contains("post-author-avatar-link")) return;
    e.preventDefault(); e.stopImmediatePropagation();
    openViewer([t.getAttribute("data-flash-user")], 0, function () {
      document.querySelectorAll('[data-flash-user="' + t.getAttribute("data-flash-user") + '"].flash-ring--unseen')
        .forEach(function (n) { n.classList.replace("flash-ring--unseen", "flash-ring--seen"); });
    });
  }, true);

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", renderTray); else renderTray();
  window.DriqyFlash = { open: openViewer, publish: pickAndPublish };
})();
