/* Botão "voltar ao topo" no Vortex e nas Notícias: aparece depois de rolar um pouco. */
(function () {
  "use strict";
  if (!document.body.matches(".pictures-page, .news-page")) return;
  var btn = document.createElement("button");
  btn.type = "button";
  btn.className = "scroll-top-btn";
  btn.hidden = true;
  btn.setAttribute("aria-label", "Voltar ao topo");
  btn.title = "Voltar ao topo";
  btn.textContent = "↑";
  document.body.appendChild(btn);

  var SHOW_AFTER = 600;
  var ticking = false;
  function update() {
    ticking = false;
    btn.hidden = (window.pageYOffset || document.documentElement.scrollTop) < SHOW_AFTER;
  }
  window.addEventListener("scroll", function () {
    if (!ticking) { ticking = true; requestAnimationFrame(update); }
  }, { passive: true });
  btn.addEventListener("click", function () {
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" });
  });
  update();
})();
