/* Widget "Clima" do painel direito. Lê /api/v1/widgets/weather (cidade do perfil ou a região escolhida no widget). */
(function () {
  "use strict";
  if (!window.DriqyRail) return;

  var REFRESH_MS = 15 * 60 * 1000;
  var ICONS = {
    sun: '<circle cx="12" cy="12" r="5" fill="#f2a93b"/><g stroke="#f2a93b" stroke-width="2" stroke-linecap="round"><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1"/></g>',
    moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z" fill="#c9c3d8"/>',
    cloud: '<path d="M7 18a4.5 4.5 0 0 1-.4-9A6 6 0 0 1 18 10.5 3.8 3.8 0 0 1 17.5 18z" fill="#b8b2c6"/>',
    "sun-cloud": '<circle cx="9" cy="8.5" r="3.6" fill="#f2a93b"/><path d="M8 20a4 4 0 0 1-.3-8 5.3 5.3 0 0 1 10 1.6A3.4 3.4 0 0 1 17.5 20z" fill="#b8b2c6"/>',
    "moon-cloud": '<path d="M13.5 8A5 5 0 0 1 8 3.2a5 5 0 1 0 5.5 4.8z" fill="#c9c3d8"/><path d="M8 20a4 4 0 0 1-.3-8 5.3 5.3 0 0 1 10 1.6A3.4 3.4 0 0 1 17.5 20z" fill="#b8b2c6"/>',
    fog: '<g stroke="#b8b2c6" stroke-width="2.4" stroke-linecap="round"><path d="M4 9h16M6 13h14M4 17h12"/></g>',
    drizzle: '<path d="M7 14a4.2 4.2 0 0 1-.3-8.4A5.6 5.6 0 0 1 17.5 7 3.5 3.5 0 0 1 17 14z" fill="#b8b2c6"/><g stroke="#6aa9e9" stroke-width="2" stroke-linecap="round"><path d="M8 17v2M12 17v2M16 17v2"/></g>',
    rain: '<path d="M7 13.5a4.2 4.2 0 0 1-.3-8.4A5.6 5.6 0 0 1 17.5 6.5 3.5 3.5 0 0 1 17 13.5z" fill="#9d97ad"/><g stroke="#6aa9e9" stroke-width="2.2" stroke-linecap="round"><path d="M8 16.5l-1 3.5M12.5 16.5l-1 3.5M17 16.5l-1 3.5"/></g>',
    snow: '<path d="M7 13.5a4.2 4.2 0 0 1-.3-8.4A5.6 5.6 0 0 1 17.5 6.5 3.5 3.5 0 0 1 17 13.5z" fill="#b8b2c6"/><g fill="#e8eef7"><circle cx="8" cy="18" r="1.4"/><circle cx="12.5" cy="19.5" r="1.4"/><circle cx="17" cy="18" r="1.4"/></g>',
    storm: '<path d="M7 13a4.2 4.2 0 0 1-.3-8.4A5.6 5.6 0 0 1 17.5 6 3.5 3.5 0 0 1 17 13z" fill="#8a849b"/><path d="M12.5 12.5l-3 5h2.8l-1.3 4.5 4.6-6.2h-3z" fill="#f2a93b"/>'
  };

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function icon(key) {
    var wrap = el("span", "wx-icon");
    wrap.setAttribute("aria-hidden", "true");
    wrap.innerHTML = '<svg viewBox="0 0 24 24" width="52" height="52">' + (ICONS[key] || ICONS.cloud) + "</svg>";
    return wrap;
  }

  /* Região escolhida só para o widget (não muda o perfil). Fica neste navegador. */
  var REGION_KEY = "driqy-weather-region";
  function getRegion() {
    try {
      var r = JSON.parse(localStorage.getItem(REGION_KEY) || "null");
      if (r && isFinite(r.lat) && isFinite(r.lng) && r.name) return r;
    } catch (e) {}
    return null;
  }
  function setRegion(r) {
    try {
      if (r) localStorage.setItem(REGION_KEY, JSON.stringify(r)); else localStorage.removeItem(REGION_KEY);
    } catch (e) {}
  }

  /* Botão "Alterar região" + painel com busca de cidade e "Usar minha cidade". */
  function regionControls(host, ctx) {
    var box = el("div", "wx-region");
    var open = el("button", "wx-region-btn", "Alterar região");
    open.type = "button";
    box.appendChild(open);
    var panel = el("div", "wx-region-panel");
    panel.hidden = true;
    var field = el("div", "wx-region-field");
    var input = el("input");
    input.type = "text";
    input.maxLength = 60;
    input.placeholder = "Buscar cidade, estado ou país…";
    input.setAttribute("aria-label", "Buscar região");
    input.setAttribute("data-places-url", window.DriqyRail.config("places-url"));
    field.appendChild(input);
    panel.appendChild(field);
    box.appendChild(panel);
    open.addEventListener("click", function () {
      panel.hidden = !panel.hidden;
      if (!panel.hidden) input.focus();
    });
    if (window.DriqyPlacePicker) {
      window.DriqyPlacePicker.attach(input, {
        onSelect: function (p) {
          setRegion({ lat: p.latitude, lng: p.longitude, name: p.label });
          load(host, ctx);
        }
      });
    }
    return box;
  }

  function message(host, text, actionLabel, onAction, href) {
    host.innerHTML = "";
    var box = el("div", "wx-msg");
    box.appendChild(el("p", "hint", text));
    if (actionLabel) {
      var a = href ? el("a", "btn-outline wx-action", actionLabel) : el("button", "btn-outline wx-action", actionLabel);
      if (href) a.href = href;
      else { a.type = "button"; a.addEventListener("click", onAction); }
      box.appendChild(a);
    }
    host.appendChild(box);
  }

  function draw(host, d) {
    host.innerHTML = "";
    var main = el("div", "wx-main");
    main.appendChild(icon(d.icon));
    var temp = el("div", "wx-temp");
    temp.appendChild(el("span", "wx-deg", d.temperature == null ? "–" : d.temperature + "°C"));
    temp.appendChild(el("span", "wx-cond", d.condition || ""));
    main.appendChild(temp);
    host.appendChild(main);
    host.appendChild(el("p", "wx-place", d.location || ""));

    var rows = el("ul", "wx-facts");
    function fact(label, value, suffix) {
      if (value == null) return;
      var li = el("li");
      li.appendChild(el("span", "wx-fact-label", label));
      li.appendChild(el("strong", null, value + suffix));
      rows.appendChild(li);
    }
    fact("Máx.", d.temp_max, "°");
    fact("Mín.", d.temp_min, "°");
    fact("Sensação", d.feels_like, "°");
    fact("Chuva", d.rain_chance, "%");
    fact("Umidade", d.humidity, "%");
    fact("Vento", d.wind_kmh, " km/h");
    host.appendChild(rows);
  }

  function withRegion(host, ctx, drawFn) {
    drawFn();
    host.appendChild(regionControls(host, ctx));
  }

  var timer = null;

  function load(host, ctx) {
    var url = window.DriqyRail.config("weather-url");
    var editUrl = window.DriqyRail.config("edit-profile-url");
    var region = getRegion();
    if (region) {
      url += (url.indexOf("?") < 0 ? "?" : "&") + "lat=" + encodeURIComponent(region.lat) +
             "&lng=" + encodeURIComponent(region.lng) + "&name=" + encodeURIComponent(region.name);
    }
    message(host, "Carregando o clima…");
    fetch(url, { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then(function (r) { return r.ok ? r.json() : { ok: false, reason: "unavailable" }; })
      .catch(function () { return { ok: false, reason: "unavailable" }; })
      .then(function (d) {
        if (!ctx.isActive()) return;
        if (d.ok) { withRegion(host, ctx, function () { draw(host, d); }); return; }
        if (d.reason === "no_location") {
          withRegion(host, ctx, function () {
            message(host, "Escolha sua cidade no perfil (com as sugestões) para ver o clima de onde você está, ou escolha uma região aqui.", "Editar perfil", null, editUrl);
          });
        } else if (d.reason === "not_found") {
          withRegion(host, ctx, function () {
            message(host, "Não encontrei a cidade “" + (d.location || "") + "”. Escolha uma sugestão no perfil ou escolha uma região aqui.", "Editar perfil", null, editUrl);
          });
        } else if (d.reason === "disabled") {
          message(host, "O clima está desativado.");
        } else {
          withRegion(host, ctx, function () {
            message(host, "Não consegui buscar o clima agora.", "Tentar de novo", function () { load(host, ctx); });
          });
        }
      });
  }

  window.DriqyRail.register({
    id: "weather",
    title: "O clima hoje",
    render: function (host, ctx) {
      if (timer) { clearInterval(timer); timer = null; }
      load(host, ctx);
      timer = setInterval(function () {
        if (!ctx.isActive() || document.hidden || !document.body.contains(host)) return;
        load(host, ctx);
      }, REFRESH_MS);
    }
  });
})();
