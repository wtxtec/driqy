/* Chamadas — Fase 11: cliente REST da sinalização (a tela e o WebRTC estão em call-ui.js, Fase 12). Expõe `window.driqyCalls`. Usa a sessão do navegador (cookie) com o
 * header `X-Requested-With: fetch`. Eventos ao vivo (`call_incoming`, `call_signal`,
 * `call_state`) chegam por `window.driqyLive.on(...)` (chat-live.js).
 *
 *   driqyCalls.config()                       -> {enabled, ice_servers, turn_configured, ring_seconds, ping_seconds}
 *   driqyCalls.active()                       -> chamada viva ou null (chame ao carregar a página)
 *   driqyCalls.history(limit, beforeId)       -> {calls, has_more}
 *   driqyCalls.start(user, media, offerSdp, clientId)  -> chamada (rejeita com .status/.code: busy, already_in_call)
 *   driqyCalls.get(id) / answer(id, sdp) / decline(id) / end(id, reason?) / ice(id, candidate|null) / ping(id)
 * Depuração: no console, `await driqyCalls.config()`.
 */
(function () {
  "use strict";
  if (window.driqyCalls) return;
  var BASE = "/api/v1/calls";

  function req(method, path, body) {
    var opts = { method: method, credentials: "same-origin", headers: { "X-Requested-With": "fetch" } };
    if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    return fetch(BASE + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (!r.ok) {
          var err = new Error(data.error || ("Erro " + r.status));
          err.status = r.status;
          err.code = data.code || null;
          err.data = data;
          throw err;
        }
        return data;
      });
    });
  }

  function sdp(kind, text) { return { type: kind, sdp: text }; }

  window.driqyCalls = {
    config: function () { return req("GET", "/config"); },
    active: function () { return req("GET", "/active").then(function (d) { return d.call || null; }); },
    history: function (limit, beforeId) {
      var q = "?limit=" + (limit || 30) + (beforeId ? "&before_id=" + beforeId : "");
      return req("GET", q);
    },
    start: function (username, media, offerSdp, clientId) {
      var body = { media: media === "video" ? "video" : "voice", offer: sdp("offer", offerSdp) };
      if (clientId) body.client_id = clientId;
      return req("POST", "/" + encodeURIComponent(username), body);
    },
    get: function (id) { return req("GET", "/" + id); },
    answer: function (id, answerSdp) { return req("POST", "/" + id + "/answer", { answer: sdp("answer", answerSdp) }); },
    decline: function (id) { return req("POST", "/" + id + "/decline", {}); },
    end: function (id, reason) { return req("POST", "/" + id + "/end", reason ? { reason: reason } : {}); },
    ice: function (id, candidate) { return req("POST", "/" + id + "/ice", { candidate: candidate || null }); },
    ping: function (id) { return req("POST", "/" + id + "/ping", {}); }
  };
})();
