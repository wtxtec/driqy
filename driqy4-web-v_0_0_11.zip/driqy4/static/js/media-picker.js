/*
 * Seletor de múltiplos arquivos de mídia (fotos, vídeos ou GIFs), reutilizado
 * tanto na caixa de publicação rápida do feed quanto na página completa de
 * publicar. Mantém uma lista de arquivos escolhidos (até `maxItems`), gera
 * miniaturas com botão para remover cada uma individualmente, e mantém o
 * <input type="file"> real sincronizado (via DataTransfer) para o envio do
 * formulário.
 */
(function () {
  function attachMediaPicker({ fileInput, previewContainer, counterEl, maxItems = 10, onChange, onLimit }) {
    let files = [];
    let objectUrls = [];

    function revokeAll() {
      objectUrls.forEach((url) => URL.revokeObjectURL(url));
      objectUrls = [];
    }

    function syncInput() {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      fileInput.files = dt.files;
    }

    function isAudio(file) {
      // .webm e .ogg podem ser tanto vídeo quanto áudio — o mimetype (definido
      // pelo próprio navegador ao gravar) é o que desempata com confiança.
      return file.type.startsWith("audio/") || /\.(mp3|wav|m4a)$/i.test(file.name);
    }

    function isVideo(file) {
      if (isAudio(file)) return false;
      return file.type.startsWith("video/") || /\.(mp4|webm|mov)$/i.test(file.name);
    }

    function isGif(file) {
      return file.type === "image/gif" || /\.gif$/i.test(file.name);
    }

    function isCroppable(file) {
      // recorte só faz sentido pra fotos estáticas — em GIF perderia a
      // animação, e vídeo/áudio já tem sua própria prévia.
      return !isVideo(file) && !isAudio(file) && !isGif(file);
    }

    function moveItem(idx, dir) {
      const target = idx + dir;
      if (target < 0 || target >= files.length) return;
      const tmp = files[idx];
      files[idx] = files[target];
      files[target] = tmp;
      syncInput();
      render();
    }

    function render() {
      revokeAll();
      previewContainer.innerHTML = "";
      previewContainer.hidden = files.length === 0;

      files.forEach((file, idx) => {
        const url = URL.createObjectURL(file);
        objectUrls.push(url);

        const item = document.createElement("div");
        item.className = "media-picker-item";

        // Com 2+ itens, a ordem em que aparecem aqui é exatamente a ordem
        // em que vão ser publicados — o número deixa isso visível, e as
        // setinhas permitem corrigir a ordem na hora (o navegador nem
        // sempre entrega os arquivos escolhidos na mesma ordem do clique).
        if (files.length > 1) {
          const orderCtrl = document.createElement("div");
          orderCtrl.className = "media-picker-order";

          const moveLeft = document.createElement("button");
          moveLeft.type = "button";
          moveLeft.className = "media-picker-move";
          moveLeft.setAttribute("aria-label", "Mover para trás");
          moveLeft.textContent = "‹";
          moveLeft.disabled = idx === 0;
          moveLeft.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            moveItem(idx, -1);
          });

          const num = document.createElement("span");
          num.className = "media-picker-order-num";
          num.textContent = String(idx + 1);

          const moveRight = document.createElement("button");
          moveRight.type = "button";
          moveRight.className = "media-picker-move";
          moveRight.setAttribute("aria-label", "Mover para frente");
          moveRight.textContent = "›";
          moveRight.disabled = idx === files.length - 1;
          moveRight.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            moveItem(idx, 1);
          });

          orderCtrl.appendChild(moveLeft);
          orderCtrl.appendChild(num);
          orderCtrl.appendChild(moveRight);
          item.appendChild(orderCtrl);
        }

        if (isVideo(file)) {
          const video = document.createElement("video");
          video.src = url;
          video.muted = true;
          video.playsInline = true;
          item.appendChild(video);

          const badge = document.createElement("span");
          badge.className = "media-picker-video-badge";
          badge.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>';
          item.appendChild(badge);
        } else if (isAudio(file)) {
          item.classList.add("media-picker-item-audio");

          const icon = document.createElement("span");
          icon.className = "media-picker-audio-icon";
          icon.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11h-2z"/></svg>';
          item.appendChild(icon);

          const audio = document.createElement("audio");
          audio.src = url;
          audio.controls = true;
          item.appendChild(audio);
        } else {
          const img = document.createElement("img");
          img.src = url;
          img.alt = "Prévia da mídia " + (idx + 1);
          item.appendChild(img);
        }

        if (isCroppable(file)) {
          const editBtn = document.createElement("button");
          editBtn.type = "button";
          editBtn.className = "media-picker-edit";
          editBtn.setAttribute("aria-label", "Ajustar enquadramento desta foto");
          editBtn.title = "Ajustar enquadramento";
          editBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="currentColor" d="M6 2v4H2v2h4v9a1 1 0 0 0 1 1h9v4h2v-4h4v-2h-4V6a1 1 0 0 0-1-1H8V2H6zm2 6h8v8H8V8z"/></svg>';
          editBtn.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (!window.driqyOpenImageCropper) return;
            window.driqyOpenImageCropper(files[idx], {
              onApply: (newFile) => {
                files[idx] = newFile;
                syncInput();
                render();
                if (onChange) onChange(files.length);
              },
            });
          });
          item.appendChild(editBtn);
        }

        const removeBtn = document.createElement("button");
        removeBtn.type = "button";
        removeBtn.className = "media-picker-remove";
        removeBtn.setAttribute("aria-label", "Remover este item");
        removeBtn.textContent = "✕";
        removeBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          files.splice(idx, 1);
          syncInput();
          render();
          if (onChange) onChange(files.length);
        });
        item.appendChild(removeBtn);

        previewContainer.appendChild(item);
      });

      if (counterEl) {
        counterEl.hidden = files.length === 0;
        counterEl.textContent = files.length + "/" + maxItems;
      }
    }

    fileInput.addEventListener("change", () => {
      const picked = Array.from(fileInput.files || []);
      const room = maxItems - files.length;
      if (picked.length > room && onLimit) onLimit(maxItems);
      files = files.concat(picked.slice(0, Math.max(0, room)));
      syncInput();
      render();
      if (onChange) onChange(files.length);
    });

    return {
      clear() {
        files = [];
        syncInput();
        render();
        if (onChange) onChange(files.length);
      },
      count() {
        return files.length;
      },
    };
  }

  window.driqyAttachMediaPicker = attachMediaPicker;
})();
