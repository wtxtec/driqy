/*
 * Chat do site (desktop e celular) — Fases 2–5 do chat rico, no mesmo
 * contrato da API do app Flutter (/api/v1/messages/...), usando a sessão do
 * navegador. Requisições que alteram dados enviam X-Requested-With: fetch
 * (exigido pelo servidor no lugar de token CSRF).
 *
 * Recursos: balões agrupados, separadores de data, ticks, envio otimista com
 * reenvio, emojis (painel + 1–3 emojis grandes), reações (clique longo /
 * botão direito / botão ☺), imagens e GIFs (clipe, arrastar e soltar, colar),
 * pré-visualização com legenda e visualizador em tela cheia, áudio (gravar com
 * MediaRecorder, player com onda e velocidade 1x/1,5x/2x).
 * vídeo (Fase 6: escolher, miniatura gerada no navegador, player).
 * ações (Fase 7: responder, copiar, apagar para mim/para todos).
 * Fases seguintes encaixam: tempo real (9).
 */
(function () {
  "use strict";
  const root = document.getElementById("cw");
  if (!root) return;

  // Fase 6a: ciclo de vida. O Ping troca de conversa sem recarregar a página; antes de montar a
  // próxima, `window.__pingThreadDestroy()` desfaz tudo que esta instância registrou fora do #cw.
  let destroyed = false;
  const cleanups = [];
  const listenOn = (target, ev, fn, opts) => {
    target.addEventListener(ev, fn, opts);
    cleanups.push(() => target.removeEventListener(ev, fn, opts));
  };

  const API_ROOT = root.dataset.apiRoot;       // /api/v1/messages
  const THREAD_URL = root.dataset.threadUrl;   // /api/v1/messages/<user>
  const PIN_URL = root.dataset.pinUrl;         // /api/v1/messages/<user>/pin (fase 6b)
  const POLL_MS = 5000;
  const GROUP_MS = 5 * 60 * 1000;
  const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
  const MAX_VIDEO_BYTES = 55 * 1024 * 1024;
  const MAX_FILE_BYTES = 25 * 1024 * 1024;
  // Fase 15: documentos aceitos (o servidor confere a assinatura de novo)
  const FILE_EXTS = ["pdf", "txt", "csv", "json", "zip", "rtf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "heic", "heif"];
  const VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime"];
  const IMAGE_TYPES = ["image/png", "image/jpeg", "image/gif", "image/webp"];
  const QUICK = ["👍", "❤️", "😂", "😮", "😢", "🙏"];
  const HEADERS = { "X-Requested-With": "fetch" };
  const MIN_REC_MS = 800, MAX_REC_MS = 15 * 60 * 1000;
  const REC_TYPES = [
    ["audio/webm;codecs=opus", "webm"], ["audio/webm", "webm"],
    ["audio/ogg;codecs=opus", "ogg"], ["audio/mp4", "m4a"],
  ];
  const SPEEDS = [1, 1.5, 2];
  const SPEED_KEY = "driqy-chat-audio-speed";

  const $ = (id) => document.getElementById(id);
  const listEl = $("cw-list"), form = $("cw-form"), input = $("cw-input");
  const sendBtn = $("cw-send"), emojiBtn = $("cw-emoji-btn"), emojiPanel = $("cw-emoji-panel");
  const attachBtn = $("cw-attach-btn"), fileInput = $("cw-file");
  const jumpBtn = $("cw-jump"), jumpCount = $("cw-jump-count"), dropEl = $("cw-drop");
  const pinBar = $("cw-pinned"), pinTxt = $("cw-pinned-txt"), pinGo = $("cw-pinned-go"), pinX = $("cw-pinned-x");
  const previewModal = $("cw-preview"), previewImg = $("cw-preview-img"), previewCaption = $("cw-preview-caption");
  const toastEl = $("cw-toast"), previewVideo = $("cw-preview-video");
  const previewFileBox = $("cw-preview-file");
  const onceBtn = $("cw-once-btn");
  const micBtn = $("cw-mic"), recBar = $("cw-rec"), recTime = $("cw-rec-time"), recLevel = $("cw-rec-level");
  const fieldEl = root.querySelector(".cw-field");
  const replyBar = $("cw-replybar"), replyWho = $("cw-replybar-who"), replyTxt = $("cw-replybar-txt");
  const delModal = $("cw-delete"), delActions = $("cw-delete-actions"), delHint = $("cw-delete-hint");
  const PARTNER_NAME = root.dataset.partnerName || "Contato";
  const searchBar = $("cw-search"), searchInput = $("cw-search-input"), searchCount = $("cw-search-count");
  const fwdModal = $("cw-forward"), fwdList = $("cw-forward-list"), fwdFilter = $("cw-forward-filter");
  const fwdHint = $("cw-forward-hint"), fwdSend = $("cw-forward-send");
  const FORWARD_MAX = 5;
  const LIVE = window.driqyLive;   // Fase 9: eventos em tempo real (pode não existir)
  const PARTNER = root.dataset.partner;
  const subEl = $("cw-partner-sub");
  const subOriginal = subEl ? subEl.textContent : "";
  let subBase = subOriginal;     // texto "de repouso" do cabeçalho: @fulano, online ou visto por último (Fase 10)
  let partnerPresence = null;
  let typingTimer = null, lastTypingSent = 0, iAmTyping = false, pollTick = 0, liveTimer = null, recTypingTimer = null;
  let editing = null;         // {id, original} da mensagem em edição (Fase 8)
  let searchTerm = "";        // termo ativo (realça nos balões)
  let searchIds = [], searchPos = -1, searchCurrentId = null, searchTimer = null, searchSeq = 0;
  let replyTo = null;         // {id, sender_id, msg_type, preview} da resposta em edição

  let server = [];            // mensagens vindas da API
  let pending = [];           // locais: enviando / falhou
  let loaded = false, fetching = false;
  // Fase 6b: não lidas desta abertura (o servidor já as marcou como lidas ao montar a página)
  // e mensagens que chegaram enquanto eu estava longe do fim → contador do botão ↓.
  let firstUnread = parseInt(root.dataset.firstUnread, 10) || 0;
  let unreadTotal = parseInt(root.dataset.unreadCount, 10) || 0;
  const unseen = new Set();   // ids de mensagens do parceiro ainda fora da tela
  let jumpRaf = 0, unreadNode = null;
  let pinned = null;          // {id, preview} da mensagem fixada (só para mim)
  let pollTimer = null;
  const nodeCache = new Map(); // key -> {sig, node}
  const coarse = window.matchMedia && window.matchMedia("(pointer: coarse)").matches;

  // ---------- utilidades ----------
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function toast(msg) {
    toastEl.textContent = msg; toastEl.hidden = false;
    clearTimeout(toast._t); toast._t = setTimeout(() => (toastEl.hidden = true), 3500);
  }
  function newClientId() {
    return Date.now().toString(36) + "-" + Math.floor(Math.random() * 2 ** 31).toString(36);
  }
  function clock(iso) {
    return new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  }
  function sameDay(a, b) {
    return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  }
  function dayLabel(d) {
    const now = new Date(), y = new Date(); y.setDate(now.getDate() - 1);
    if (sameDay(d, now)) return "Hoje";
    if (sameDay(d, y)) return "Ontem";
    return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
  }
  const CLUSTER = "\\p{Extended_Pictographic}[\\uFE0F\\u{1F3FB}-\\u{1F3FF}]?(?:\\u200D\\p{Extended_Pictographic}[\\uFE0F\\u{1F3FB}-\\u{1F3FF}]?)*";
  let emojiOnlyRe = null, emojiClusterRe = null;
  try {
    emojiOnlyRe = new RegExp("^(?:" + CLUSTER + "\\s*)+$", "u");
    emojiClusterRe = new RegExp(CLUSTER, "gu");
  } catch (e) { /* navegador sem \p{}: só não aumenta emojis */ }
  function emojiOnlyCount(text) {
    const t = (text || "").trim();
    if (!t || !emojiOnlyRe || !emojiOnlyRe.test(t)) return null;
    const m = t.match(emojiClusterRe);
    return m ? m.length : null;
  }
  function appendLinkified(parent, text) {
    const re = /(https?:\/\/[^\s<]+)/g;
    let last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) parent.appendChild(document.createTextNode(text.slice(last, m.index)));
      let url = m[1], tail = "";
      const trail = url.match(/[.,;:!?)\]]+$/);
      if (trail) { tail = trail[0]; url = url.slice(0, -tail.length); }
      const a = el("a", "cw-link", url);
      a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer nofollow";
      parent.appendChild(a);
      if (tail) parent.appendChild(document.createTextNode(tail));
      last = m.index + m[0].length;
    }
    if (last < text.length) parent.appendChild(document.createTextNode(text.slice(last)));
  }

  // realce da busca (sem acento e sem diferenciar maiúsculas, igual ao servidor)
  function foldMap(text) {
    let out = "";
    const map = [];
    for (let i = 0; i < text.length; i++) {
      const n = text[i].normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
      for (let k = 0; k < n.length; k++) { out += n[k]; map.push(i); }
    }
    return { out: out, map: map };
  }
  function highlightIn(node, term) {
    const needle = foldMap(term).out;
    if (needle.length < 2) return;
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    const texts = [];
    while (walker.nextNode()) texts.push(walker.currentNode);
    texts.forEach((tn) => {
      const text = tn.nodeValue, f = foldMap(text);
      let from = 0, idx, last = 0;
      const frag = document.createDocumentFragment();
      let any = false;
      while ((idx = f.out.indexOf(needle, from)) !== -1) {
        const start = f.map[idx], end = f.map[idx + needle.length - 1] + 1;
        if (start < last) { from = idx + 1; continue; }
        if (start > last) frag.appendChild(document.createTextNode(text.slice(last, start)));
        frag.appendChild(el("mark", "cw-mark", text.slice(start, end)));
        last = end; from = idx + needle.length; any = true;
      }
      if (!any) return;
      if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
      tn.parentNode.replaceChild(frag, tn);
    });
  }
  function textBlock(text) {
    const c = el("div", "cw-text");
    appendLinkified(c, text);
    if (searchTerm) highlightIn(c, searchTerm);
    return c;
  }

  // ---------- rede ----------
  function fetchThread() {
    if (fetching) return Promise.resolve();
    fetching = true;
    return fetch(THREAD_URL, { headers: HEADERS, credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : Promise.reject(r.status)))
      .then((data) => {
        const incomingBefore = new Set(server.map((m) => m.id));
        const fresh = data.messages || [];
        const gotNew = loaded && fresh.filter((m) => !m.mine && !incomingBefore.has(m.id));
        server = fresh;
        if (data.partner && data.partner.presence) applyPresence(data.partner.presence);
        const first = !loaded;
        loaded = true;
        applyPinned(data.pinned_message);
        if (first) {
          if (!firstUnread && data.first_unread_id) { firstUnread = data.first_unread_id; unreadTotal = data.unread_count || 0; }
          if (firstUnread) server.forEach((m) => { if (!m.mine && m.id >= firstUnread) unseen.add(m.id); });
        }
        render({ forceBottom: first && !firstUnread, openAtUnread: first && !!firstUnread });
        if (gotNew && gotNew.length) {
          if (window.driqySettings && window.driqySettings.playMessageSound) window.driqySettings.playMessageSound();
          if (!nearBottom()) { gotNew.forEach((m) => unseen.add(m.id)); updateJump(); }
        }
      })
      .catch((status) => {
        if (!loaded) {
          listEl.innerHTML = "";
          const p = el("p", "hint cw-empty", status === 401
            ? "Sua sessão expirou. Entre de novo."
            : "Não foi possível carregar a conversa.");
          const b = el("button", "btn-outline", "Tentar de novo");
          b.type = "button"; b.addEventListener("click", () => { listEl.innerHTML = ""; listEl.appendChild(el("p", "hint cw-empty", "Carregando conversa…")); fetchThread(); });
          p.appendChild(document.createElement("br")); p.appendChild(b); listEl.appendChild(p);
        }
      })
      .finally(() => { fetching = false; });
  }

  function startPolling() {
    clearInterval(pollTimer);
    // com o stream vivo, o polling vira rede de segurança (a cada ~30 s)
    pollTimer = setInterval(() => {
      if (document.hidden) return;
      if (LIVE && LIVE.connected() && ++pollTick % 6 !== 0) return;
      fetchThread();
    }, POLL_MS);
  }

  // ---------- tempo real (Fase 9) ----------
  function setPartnerState(state) {
    if (!subEl) return;
    clearTimeout(typingTimer);
    if (state === "typing" || state === "recording") {
      subEl.textContent = state === "recording" ? "gravando áudio…" : "digitando…";
      subEl.classList.add("cw-typing");
      typingTimer = setTimeout(() => setPartnerState("stop"), 6000); // sumiu o aviso = parou
    } else {
      subEl.textContent = subBase;
      subEl.classList.remove("cw-typing");
    }
  }
  // ---------- presença (Fase 10): online / visto por último ----------
  function pad2(n) { return n < 10 ? "0" + n : String(n); }
  function presenceText(p) {
    if (!p || !p.visible) return subOriginal;            // escondido (por mim ou por ele): só o @
    if (p.online) return "online";
    if (!p.last_seen_at) return subOriginal;
    const d = new Date(p.last_seen_at);
    if (isNaN(d.getTime())) return subOriginal;
    const hm = pad2(d.getHours()) + ":" + pad2(d.getMinutes());
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const day = new Date(d); day.setHours(0, 0, 0, 0);
    const diff = Math.round((today - day) / 86400000);
    if (diff <= 0) return "visto por último hoje às " + hm;
    if (diff === 1) return "visto por último ontem às " + hm;
    return "visto por último em " + pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear();
  }
  function applyPresence(p) {
    partnerPresence = p || null;
    subBase = presenceText(partnerPresence);
    if (!subEl) return;
    subEl.classList.toggle("cw-online", !!(p && p.visible && p.online));
    if (!subEl.classList.contains("cw-typing")) subEl.textContent = subBase;   // "digitando…" tem prioridade
  }
  const presenceTimer = setInterval(() => { if (partnerPresence) applyPresence(partnerPresence); }, 60000);   // "há quanto tempo" envelhece
  function sendTyping(state, force) {
    const now = Date.now();
    if (state === "typing") {
      if (!force && now - lastTypingSent < 3000) return;
      lastTypingSent = now; iAmTyping = true;
    } else if (state === "stop") {
      if (!iAmTyping) return;
      iAmTyping = false; lastTypingSent = 0;
    }
    fetch(API_ROOT + "/" + encodeURIComponent(PARTNER) + "/typing", {
      method: "POST", credentials: "same-origin",
      headers: Object.assign({ "Content-Type": "application/json" }, HEADERS),
      body: JSON.stringify({ state: state }),
    }).catch(() => {});
  }
  if (LIVE) {
    LIVE.on(["message", "update", "read", "delivered", "ready", "resync"], (d, type) => {
      if (destroyed) return;
      if (d.partner && d.partner !== PARTNER) return;       // é de outra conversa
      if (type === "message" && d.partner) setPartnerState("stop");
      clearTimeout(liveTimer);
      liveTimer = setTimeout(fetchThread, 120);              // junta rajadas de eventos
    });
    LIVE.on("typing", (d) => { if (!destroyed && d.partner === PARTNER) setPartnerState(d.state); });
    LIVE.on("presence", (d) => {
      if (destroyed) return;
      if (d.partner === PARTNER) applyPresence({ visible: d.visible, online: d.online, last_seen_at: d.last_seen_at });
    });
    LIVE.on("prefs", (d) => { if (!destroyed && (!d.partner || d.partner === PARTNER)) fetchThread(); });  // minha privacidade mudou em outra aba
  }
  listenOn(document, "visibilitychange", () => { if (!destroyed && !document.hidden) fetchThread(); });

  // ---------- lista ----------
  function allItems() {
    const serverClientIds = new Set(server.filter((m) => m.client_id).map((m) => m.client_id));
    const locals = pending.filter((p) => !serverClientIds.has(p.client_id));
    return server.concat(locals);
  }
  function itemKey(m) { return m.client_id || "m" + m.id; }
  function itemSig(m, grouped) {
    const re = (m.reactions || []).map((r) => r.emoji + r.count + (r.mine ? "1" : "0")).join(",");
    return [m.id, m.read_at, m.delivered_at, m.deleted, m._state, grouped, re, m.edited_at, m.reply_to && m.reply_to.preview, m.forwarded, m.view_once_state, m.can_open_view_once, searchTerm, searchCurrentId === m.id, !!pinned && pinned.id === m.id].join("|");
  }
  function nearBottom() {
    return listEl.scrollHeight - listEl.scrollTop - listEl.clientHeight < 140;
  }
  function scrollBottom(smooth) {
    listEl.scrollTo({ top: listEl.scrollHeight, behavior: smooth ? "smooth" : "auto" });
    unseen.clear(); updateJump();
  }
  // fase 6b: mensagem do parceiro cuja base já passou pelo rodapé da lista = vista
  function pruneSeen() {
    if (!unseen.size) return;
    const limit = listEl.getBoundingClientRect().bottom + 2;
    unseen.forEach((id) => {
      const row = listEl.querySelector('[data-msg-id="' + id + '"]');
      if (!row || row.getBoundingClientRect().bottom <= limit) unseen.delete(id);   // sumiu ou já apareceu
    });
  }
  function updateJump() {
    const near = nearBottom();
    if (near) unseen.clear(); else pruneSeen();
    jumpBtn.hidden = near;
    jumpCount.hidden = unseen.size <= 0;
    jumpCount.textContent = unseen.size > 99 ? "99+" : String(unseen.size);
  }
  listEl.addEventListener("scroll", () => {
    if (jumpRaf) return;
    jumpRaf = requestAnimationFrame(() => { jumpRaf = 0; updateJump(); });
  }, { passive: true });
  jumpBtn.addEventListener("click", () => scrollBottom(true));

  function render(opts) {
    opts = opts || {};
    const stick = !opts.openAtUnread && (opts.forceBottom || nearBottom());
    const items = allItems();
    unreadNode = null;
    const nodes = [];
    const used = new Set();
    if (!items.length) {
      nodes.push(el("p", "hint cw-empty", "Nenhuma mensagem ainda. Diga oi! 👋"));
    }
    let prev = null;
    items.forEach((m) => {
      const d = new Date(m.created_at);
      const newDay = !prev || !sameDay(new Date(prev.created_at), d);
      if (newDay) {
        const sep = el("div", "cw-day"); sep.appendChild(el("span", null, dayLabel(d))); nodes.push(sep);
      }
      const mark = !!firstUnread && m.id === firstUnread && !m.mine;
      if (mark) {
        unreadNode = el("div", "cw-day cw-unread");
        unreadNode.appendChild(el("span", null, unreadTotal === 1 ? "1 mensagem não lida" : unreadTotal + " mensagens não lidas"));
        nodes.push(unreadNode);
      }
      const grouped = !!prev && !newDay && !mark && prev.mine === m.mine && (d - new Date(prev.created_at)) < GROUP_MS;
      const key = itemKey(m), sig = itemSig(m, grouped);
      let cached = nodeCache.get(key);
      if (!cached || cached.sig !== sig) {
        cached = { sig: sig, node: buildMessage(m, grouped) };
        nodeCache.set(key, cached);
      }
      used.add(key);
      nodes.push(cached.node);
      prev = m;
    });
    Array.from(nodeCache.keys()).forEach((k) => { if (!used.has(k)) nodeCache.delete(k); });
    listEl.replaceChildren.apply(listEl, nodes);
    pruneAudioWidgets();
    if (opts.openAtUnread && unreadNode) {
      // abre na 1ª mensagem não lida (como o Telegram); o ↓ mostra quantas faltam ver
      listEl.scrollTop += unreadNode.getBoundingClientRect().top - listEl.getBoundingClientRect().top - 8;
      updateJump();
    } else if (stick || opts.openAtUnread) scrollBottom(false); else updateJump();
  }

  // ---------- balão ----------
  function ticks(m) {
    const t = el("span", "cw-ticks");
    if (m._state === "sending") { t.textContent = "🕓"; t.title = "Enviando"; return t; }
    if (m._state === "failed") { t.textContent = "⚠️"; t.title = "Falhou"; return t; }
    const read = m.is_read || !!m.read_at;
    t.textContent = (read || m.delivered_at) ? "✓✓" : "✓";
    if (read) t.classList.add("is-read");
    t.title = read ? "Lida" : (m.delivered_at ? "Entregue" : "Enviada");
    return t;
  }
  function mediaSrc(m) { return m._objectUrl || m.media_url; }

  function buildMessage(m, grouped) {
    const row = el("div", "cw-row" + (m.mine ? " mine" : "") + (grouped ? " grouped" : ""));
    row.dataset.key = itemKey(m);
    if (m.id > 0) row.dataset.msgId = m.id;
    if (searchCurrentId && m.id === searchCurrentId) row.classList.add("cw-search-current");
    const canReact = m.id > 0 && !m._state && !m.deleted;

    const emojiCount = (!m.deleted && (m.msg_type || "text") === "text" && !m.reply_to) ? emojiOnlyCount(m.content) : null;
    const big = emojiCount && emojiCount <= 3;

    const bubble = el("div", "cw-bubble" + (big ? " cw-bubble-emoji size-" + emojiCount : ""));
    if (m.deleted) {
      bubble.classList.add("is-deleted");
      bubble.appendChild(el("span", "cw-deleted", "🚫 Mensagem apagada"));
    } else {
      if (m.forwarded) bubble.appendChild(el("div", "cw-fwd", "↪ Encaminhada"));
      if (m.reply_to) {
        const q = el("div", "cw-reply");
        q.appendChild(el("strong", "cw-reply-who", quoteAuthor(m.reply_to)));
        q.appendChild(el("span", "cw-reply-txt", m.reply_to.preview || ""));
        if (m.reply_to.id > 0) {
          q.tabIndex = 0; q.setAttribute("role", "button"); q.title = "Ir para a mensagem";
          q.addEventListener("click", (e) => { e.stopPropagation(); scrollToMessage(m.reply_to.id); });
        }
        bubble.appendChild(q);
      }
      if (m.view_once) {
        bubble.classList.add("has-once");
        bubble.appendChild(viewOnceBlock(m));
      } else if ((m.msg_type === "image") && mediaSrc(m)) {
        const wrap = el("button", "cw-img");
        wrap.type = "button"; wrap.setAttribute("aria-label", "Abrir imagem");
        const ratio = m.media_width && m.media_height ? m.media_width / m.media_height : 4 / 3;
        const rr = Math.min(2.2, Math.max(0.5, ratio));
        wrap.style.aspectRatio = String(rr);
        // a caixa acompanha a proporção da foto: em pé fica mais estreita (altura máx. ~380px)
        wrap.style.width = "min(320px, 68vw, " + Math.round(rr * 380) + "px)";
        const img = document.createElement("img");
        img.src = mediaSrc(m); img.alt = m.caption || "Imagem"; img.loading = "lazy"; img.decoding = "async";
        img.addEventListener("error", () => { wrap.classList.add("broken"); wrap.textContent = "Imagem indisponível"; });
        wrap.appendChild(img);
        wrap.addEventListener("click", () => openLightbox(itemKey(m)));
        bubble.classList.add("has-image");
        bubble.appendChild(wrap);
        if (m.caption) bubble.appendChild(textBlock(m.caption));
      } else if (m.msg_type === "audio" && mediaSrc(m)) {
        bubble.classList.add("has-audio");
        bubble.appendChild(audioWidget(m));
        if (m.caption) bubble.appendChild(textBlock(m.caption));
      } else if (m.msg_type === "video" && mediaSrc(m)) {
        bubble.classList.add("has-image", "has-video");
        bubble.appendChild(videoThumb(m));
        if (m.caption) bubble.appendChild(textBlock(m.caption));
      } else if (m.msg_type === "file" && (mediaSrc(m) || m._state)) {
        bubble.classList.add("has-file");
        bubble.appendChild(fileBlock(m));
        if (m.caption) bubble.appendChild(textBlock(m.caption));
      } else if (m.msg_type === "call") {
        bubble.classList.add("has-call");
        bubble.appendChild(callBlock(m));
      } else if (m.msg_type && m.msg_type !== "text") {
        // arquivo ainda sem visual próprio (Fase 15)
        bubble.appendChild(el("div", "cw-text", m.content || ""));
      } else {
        if (big) { const t = el("div", "cw-text"); t.textContent = (m.content || "").trim(); bubble.appendChild(t); }
        else bubble.appendChild(textBlock(m.content || ""));
      }
      const meta = el("div", "cw-meta");
      if (pinned && pinned.id === m.id) { const pi = el("span", "cw-pin-ico", "📌"); pi.title = "Mensagem fixada"; meta.appendChild(pi); }
      if (m.edited_at) meta.appendChild(el("span", null, "editada"));
      meta.appendChild(el("span", null, clock(m.created_at)));
      if (m.mine) meta.appendChild(ticks(m));
      bubble.appendChild(meta);
      // hora na mesma linha do fim do texto (estilo Telegram) quando a bolha é só texto/legenda
      const prevEl = meta.previousElementSibling;
      if (!big && prevEl && prevEl.classList.contains("cw-text") && !bubble.classList.contains("has-once")) bubble.classList.add("cw-inline-meta");
    }

    if (canReact) {
      const rbtn = el("button", "cw-react-btn", "☺");
      rbtn.type = "button"; rbtn.setAttribute("aria-label", "Reagir"); rbtn.title = "Reagir";
      rbtn.addEventListener("click", (e) => { e.stopPropagation(); openReactionPopover(m, bubble); });
      bubble.appendChild(rbtn);
      bubble.addEventListener("contextmenu", (e) => { e.preventDefault(); openReactionPopover(m, bubble); });
      attachLongPress(bubble, () => openReactionPopover(m, bubble));
      attachSwipeReply(bubble, m);
    }
    if (m._state === "failed") {
      bubble.classList.add("is-failed");
      bubble.addEventListener("click", () => retry(m));
    }

    const holder = el("div", "cw-holder");
    holder.appendChild(bubble);
    if (m.reactions && m.reactions.length && !m.deleted) {
      const rs = el("div", "cw-reactions");
      m.reactions.forEach((r) => {
        const chip = el("button", "cw-chip" + (r.mine ? " mine" : ""), r.count > 1 ? r.emoji + " " + r.count : r.emoji);
        chip.type = "button"; chip.title = r.mine ? "Remover minha reação" : "Reagir também";
        chip.addEventListener("click", () => react(m, r.emoji));
        rs.appendChild(chip);
      });
      holder.appendChild(rs);
    }
    if (m._state === "failed") holder.appendChild(el("div", "cw-failed", "Não enviada — toque para tentar de novo"));
    row.appendChild(holder);
    return row;
  }

  // ---------- visualização única ----------
  function viewOnceBlock(m) {
    const kind = m.msg_type === "video" ? "Vídeo" : (m.msg_type === "audio" ? "Áudio" : "Foto");
    const state = m.view_once_state || "unopened";
    const sending = m._state === "sending";
    const canOpen = !!m.can_open_view_once && !m.mine && !m._state;
    let sub, ico;
    if (sending) { sub = "Enviando…"; ico = "①"; }
    else if (state === "opened") { sub = "Aberta"; ico = "✓"; }
    else if (state === "expired") { sub = "Expirada"; ico = "⌛"; }
    else { sub = m.mine ? "Não aberta" : "Toque para abrir"; ico = "①"; }
    const box = el(canOpen ? "button" : "div", "cw-once" + (canOpen ? " is-open-able" : "") + (state !== "unopened" && !sending ? " is-done" : ""));
    if (canOpen) { box.type = "button"; box.setAttribute("aria-label", kind + " de visualização única. Abrir"); }
    const ring = el("span", "cw-once-ico", ico); ring.setAttribute("aria-hidden", "true");
    const txt = el("span", "cw-once-txt");
    txt.appendChild(el("strong", null, kind));
    txt.appendChild(el("small", null, sub));
    box.append(ring, txt);
    if (canOpen) box.addEventListener("click", () => openViewOnce(m));
    return box;
  }
  let onceBusy = false, onceView = null, onceId = null;
  function closeViewOnce() {
    if (!onceView) return;
    const media = onceView.querySelector("video, audio");
    if (media) { media.pause(); media.removeAttribute("src"); media.load(); }
    const img = onceView.querySelector("img"); if (img) img.removeAttribute("src");
    onceView.remove(); onceView = null; document.body.classList.remove("cw-lb-open");
    const id = onceId; onceId = null;
    if (id) {
      fetch(API_ROOT + "/" + id + "/view-once/close", { method: "POST", headers: HEADERS, credentials: "same-origin", keepalive: true })
        .catch(() => {}).then(() => { if (!destroyed) fetchThread(); });
    }
  }
  function openViewOnce(m) {
    if (onceBusy || onceView) return;
    onceBusy = true;
    fetch(API_ROOT + "/" + m.id + "/view-once", { method: "POST", headers: HEADERS, credentials: "same-origin" })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j: j })))
      .then((res) => {
        if (!res.ok) { toast((res.j && res.j.error) || "Não foi possível abrir."); fetchThread(); return; }
        const d = res.j;
        onceId = m.id;
        const v = el("div", "cw-lb cw-vp cw-once-view");
        v.setAttribute("role", "dialog"); v.setAttribute("aria-modal", "true"); v.setAttribute("aria-label", "Visualização única");
        let node;
        if (d.msg_type === "video") {
          node = document.createElement("video");
          node.className = "cw-vp-video"; node.controls = true; node.autoplay = true; node.playsInline = true;
          node.setAttribute("controlsList", "nodownload noplaybackrate"); node.disablePictureInPicture = true;
          node.addEventListener("error", () => toast("Não foi possível reproduzir o vídeo."));
        } else if (d.msg_type === "audio") {
          node = document.createElement("audio");
          node.className = "cw-once-audio"; node.controls = true; node.autoplay = true;
          node.setAttribute("controlsList", "nodownload noplaybackrate");
        } else {
          node = document.createElement("img");
          node.className = "cw-once-img"; node.alt = "Foto de visualização única"; node.draggable = false;
        }
        node.src = d.media_url;
        node.addEventListener("contextmenu", (e) => e.preventDefault());
        const close = el("button", "cw-lb-btn cw-lb-close", "✕"); close.type = "button"; close.setAttribute("aria-label", "Fechar");
        const cap = el("div", "cw-lb-cap", "Visualização única — some ao fechar. Não dá para reabrir nem encaminhar.");
        close.addEventListener("click", closeViewOnce);
        v.addEventListener("click", (e) => { if (e.target === v) closeViewOnce(); });
        v.append(node, close, cap);
        document.body.appendChild(v); document.body.classList.add("cw-lb-open");
        onceView = v; close.focus();
      })
      .catch(() => toast("Não foi possível abrir."))
      .then(() => { onceBusy = false; });
  }
  listenOn(window, "pagehide", closeViewOnce);

  // vídeo na bolha: miniatura (enviada pelo remetente) ou 1º quadro do próprio vídeo
  // ---------- Fase 15: documentos ----------
  function extOf(name) { const i = (name || "").lastIndexOf("."); return i > 0 ? name.slice(i + 1).toLowerCase() : ""; }
  function fmtBytes(n) {
    if (!n && n !== 0) return "";
    if (n < 1024) return n + " B";
    if (n < 1024 * 1024) return Math.round(n / 1024) + " KB";
    return (n / (1024 * 1024)).toFixed(n < 10 * 1024 * 1024 ? 1 : 0).replace(".", ",") + " MB";
  }
  function fileIcon(ext) {
    if (ext === "pdf") return ["PDF", "#d64545"];
    if (["doc", "docx", "rtf", "odt", "txt"].includes(ext)) return ["DOC", "#3b76d4"];
    if (["xls", "xlsx", "csv", "ods"].includes(ext)) return ["XLS", "#2e9e5b"];
    if (["ppt", "pptx", "odp"].includes(ext)) return ["PPT", "#e08a2c"];
    if (["zip"].includes(ext)) return ["ZIP", "#8a6bd6"];
    if (["heic", "heif"].includes(ext)) return ["IMG", "#c04a9a"];
    return [(ext || "ARQ").slice(0, 4).toUpperCase(), "#7a7a8c"];
  }
  function fileBlock(m) {
    const name = m.media_name || (m._file && m._file.name) || "arquivo";
    const ext = extOf(name), ic = fileIcon(ext);
    const href = m.media_url && m.id > 0 ? m.media_url : null;
    const box = el(href ? "a" : "div", "cw-file");
    if (href) { box.href = href; box.setAttribute("download", name); box.setAttribute("rel", "noopener"); }
    box.setAttribute("aria-label", (href ? "Baixar arquivo " : "Arquivo ") + name + (m.media_size ? ", " + fmtBytes(m.media_size) : ""));
    const ico = el("span", "cw-file-ico", ic[0]); ico.style.background = ic[1]; ico.setAttribute("aria-hidden", "true");
    const main = el("span", "cw-file-main");
    const nm = el("strong", null, name); nm.title = name;
    main.appendChild(nm);
    main.appendChild(el("small", null, [fmtBytes(m.media_size), ext ? ext.toUpperCase() : ""].filter(Boolean).join(" · ")));
    box.appendChild(ico); box.appendChild(main);
    if (href) { const dl = el("span", "cw-file-dl", "⬇"); dl.setAttribute("aria-hidden", "true"); box.appendChild(dl); }
    else if (m._state === "sending") box.appendChild(el("span", "cw-file-dl", "…"));
    return box;
  }

  function videoThumb(m) {
    const wrap = el("button", "cw-img cw-vid");
    wrap.type = "button"; wrap.setAttribute("aria-label", "Reproduzir vídeo");
    const ratio = m.media_width && m.media_height ? m.media_width / m.media_height : 16 / 9;
    wrap.style.aspectRatio = String(Math.min(2.2, Math.max(0.5, ratio)));
    const thumb = m._thumbUrl || m.media_thumb_url;
    if (thumb) {
      const img = document.createElement("img");
      img.src = thumb; img.alt = ""; img.loading = "lazy"; img.decoding = "async";
      wrap.appendChild(img);
    } else {
      const v = document.createElement("video");
      v.src = mediaSrc(m) + "#t=0.1"; v.preload = "metadata"; v.muted = true; v.playsInline = true; v.tabIndex = -1;
      wrap.appendChild(v);
    }
    wrap.appendChild(el("span", "cw-vid-play", "▶"));
    if (m.media_duration_ms) wrap.appendChild(el("span", "cw-vid-dur", fmtDur(m.media_duration_ms / 1000)));
    if (m._state === "sending") wrap.appendChild(el("span", "cw-vid-wait", "Enviando…"));
    wrap.addEventListener("click", () => { if (m._state !== "failed") openVideo(m); });
    return wrap;
  }

  function attachLongPress(node, cb) {
    let timer = null, sx = 0, sy = 0;
    node.addEventListener("touchstart", (e) => {
      const t = e.touches[0]; sx = t.clientX; sy = t.clientY;
      timer = setTimeout(() => { timer = null; cb(); if (navigator.vibrate) navigator.vibrate(10); }, 450);
    }, { passive: true });
    node.addEventListener("touchmove", (e) => {
      const t = e.touches[0];
      if (timer && (Math.abs(t.clientX - sx) > 8 || Math.abs(t.clientY - sy) > 8)) { clearTimeout(timer); timer = null; }
    }, { passive: true });
    ["touchend", "touchcancel"].forEach((ev) => node.addEventListener(ev, () => { clearTimeout(timer); timer = null; }));
  }

  // ---------- emojis ----------
  const EMOJI = {
    "😀": "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 😮‍💨 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 💩 🤡 👻 👽 🤖",
    "👍": "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 ✍️ 💪 🙌 👏 🤲 👐 🫶 🫡 🫰 🤌 🤏 ✊ 👊 🤛 🤜 🫵 👀 👁️ 👅 👄 🧠 🦾",
    "❤️": "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💌 💋 💯 💢 💥 💫 💦 💨 🔥 ✨ ⭐ 🌟 ⚡ 🎉 🎊",
    "🐶": "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🦀 🐠 🐬 🐳 🦈 🐘 🦒 🌸 🌹 🌻 🌲 🌴 🍀 🍁",
    "🍕": "🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🌽 🥕 🥔 🍞 🧀 🥚 🍳 🥓 🍔 🍟 🌭 🍕 🌮 🌯 🥗 🍝 🍜 🍣 🍤 🍦 🍩 🍪 🎂 🍰 🍫 🍬 🍿 ☕ 🍺 🍻 🥂 🍷 🥤 🧃",
    "⚽": "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🥊 🥋 🎯 🎮 🕹️ 🎲 🧩 🎨 🎬 🎤 🎧 🎸 🥁 🎹 🏆 🥇 🥈 🥉 🏅 🚴 🏊 🏃 🧘 ⛹️",
    "🚗": "🚗 🚕 🚌 🏎️ 🚓 🚑 🚒 🚚 🛵 🏍️ 🚲 ✈️ 🚀 🛸 🚁 ⛵ 🚢 🚂 🏠 🏢 🏖️ 🏝️ ⛰️ 🌋 🌅 🌃 🌈 ☀️ 🌙 ⭐ ☁️ ⛈️ ❄️ 🌊",
    "💡": "📱 💻 ⌨️ 🖥️ 📷 📹 🎥 📺 📻 ⏰ 💡 🔋 🔌 💰 💳 💎 🔧 🔨 🔑 🔒 📦 📚 📖 ✏️ 📝 📅 📌 📎 ✂️ 🎁 🎈 🛒 🧴 🕯️",
    "🔣": "✅ ❌ ❓ ❗ ‼️ ⚠️ 🚫 ⭕ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ ➕ ➖ ➡️ ⬅️ ⬆️ ⬇️ 🔁 🔔 🔕 ♻️ ✔️ ☑️ 🆗 🆕 🆒 🔝 🏳️‍🌈 🇧🇷",
  };
  const RECENT_KEY = "driqy-chat-recent-emoji";
  function recentEmojis() {
    try { return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]").slice(0, 16); } catch (e) { return []; }
  }
  function pushRecent(e) {
    try {
      const list = [e].concat(recentEmojis().filter((x) => x !== e)).slice(0, 16);
      localStorage.setItem(RECENT_KEY, JSON.stringify(list));
    } catch (err) { /* sem storage: ignora */ }
  }
  function buildEmojiPanel(onPick) {
    const panel = el("div", "cw-ep");
    const tabs = el("div", "cw-ep-tabs");
    const grid = el("div", "cw-ep-grid");
    const cats = [["🕘", () => recentEmojis()]].concat(Object.keys(EMOJI).map((k) => [k, () => EMOJI[k].split(" ")]));
    function show(i) {
      Array.from(tabs.children).forEach((b, j) => b.classList.toggle("on", i === j));
      grid.replaceChildren();
      const list = cats[i][1]();
      if (!list.length) grid.appendChild(el("p", "hint", "Os emojis que você usar aparecem aqui."));
      list.forEach((e) => {
        const b = el("button", "cw-ep-emoji", e); b.type = "button";
        b.addEventListener("click", () => { pushRecent(e); onPick(e); });
        grid.appendChild(b);
      });
      grid.scrollTop = 0;
    }
    cats.forEach((c, i) => {
      const t = el("button", "cw-ep-tab", c[0]); t.type = "button"; t.addEventListener("click", () => show(i)); tabs.appendChild(t);
    });
    panel.appendChild(tabs); panel.appendChild(grid);
    show(recentEmojis().length ? 0 : 1);
    return panel;
  }

  let emojiBuilt = false;
  function toggleEmojiPanel(force) {
    const open = force != null ? force : emojiPanel.hidden;
    if (open && !emojiBuilt) {
      emojiPanel.appendChild(window.DriqyEmojiPicker
        ? window.DriqyEmojiPicker.build({ onPick: insertEmoji, onBackspace: backspaceInput })
        : buildEmojiPanel(insertEmoji));
      emojiBuilt = true;
    }
    emojiPanel.hidden = !open;
    emojiBtn.classList.toggle("on", open);
    if (open && coarse) input.blur(); else if (!open) input.focus();
  }
  function insertEmoji(e) {
    const s = input.selectionStart == null ? input.value.length : input.selectionStart;
    const end = input.selectionEnd == null ? s : input.selectionEnd;
    input.value = input.value.slice(0, s) + e + input.value.slice(end);
    const pos = s + e.length;
    input.setSelectionRange(pos, pos);
    autoGrow(); updateSendState();
    if (!coarse) input.focus();
  }
  function backspaceInput() {
    const s = input.selectionStart == null ? input.value.length : input.selectionStart;
    const end = input.selectionEnd == null ? s : input.selectionEnd;
    if (s !== end) { input.value = input.value.slice(0, s) + input.value.slice(end); input.setSelectionRange(s, s); }
    else if (s > 0) {
      // apaga o último "caractere visível" (emoji composto inteiro)
      const before = Array.from(input.value.slice(0, s));
      let cut = before.pop() || "";
      while (before.length && /^[\u200d\ufe0f\u{1F3FB}-\u{1F3FF}]$/u.test(cut.slice(0, 1)) && cut.length <= 2) { cut = before.pop() + cut; }
      const start = s - cut.length;
      input.value = input.value.slice(0, start) + input.value.slice(s); input.setSelectionRange(start, start);
    }
    autoGrow(); updateSendState();
  }
  emojiBtn.addEventListener("click", (e) => { e.stopPropagation(); toggleEmojiPanel(); });
  // desktop: o painel flutua sobre o chat; clique fora fecha (como no Telegram Web)
  listenOn(document, "click", (e) => {
    if (emojiPanel.hidden || coarse) return;
    if (emojiPanel.contains(e.target) || emojiBtn.contains(e.target)) return;
    toggleEmojiPanel(false);
  });

  // ---------- reações ----------
  let popover = null;
  function closePopover() { if (popover) { popover.remove(); popover = null; } }
  function openReactionPopover(m, anchor) {
    closePopover();
    const pop = el("div", "cw-pop");
    const mine = (m.reactions || []).filter((r) => r.mine).map((r) => r.emoji);
    const bar = el("div", "cw-pop-bar");
    QUICK.forEach((e) => {
      const b = el("button", "cw-pop-emoji" + (mine.includes(e) ? " on" : ""), e); b.type = "button";
      b.addEventListener("click", () => { closePopover(); react(m, e); });
      bar.appendChild(b);
    });
    const more = el("button", "cw-pop-emoji", "＋"); more.type = "button"; more.setAttribute("aria-label", "Mais emojis");
    more.addEventListener("click", () => {
      more.remove();
      pop.appendChild(buildEmojiPanel((e) => { closePopover(); react(m, e); }));
      place();
    });
    bar.appendChild(more);
    pop.appendChild(bar);
    const acts = el("div", "cw-pop-actions");
    const act = (label, cls, fn) => {
      const b = el("button", "cw-pop-act" + (cls ? " " + cls : ""), label); b.type = "button";
      b.addEventListener("click", () => { closePopover(); fn(); });
      acts.appendChild(b);
    };
    act("↩  Responder", "", () => startReply(m));
    const copyable = m.view_once ? "" : copyableText(m);
    if (copyable) act("⧉  Copiar", "", () => copyText(copyable));
    if (m.can_edit) act("✎  Editar", "", () => startEdit(m));
    if (m.id > 0 && !m.deleted && !m._state && (m.msg_type || "text") !== "call" && !m.view_once) {
      const isPin = !!pinned && pinned.id === m.id;
      act(isPin ? "📌  Desafixar" : "📌  Fixar", "", () => (isPin ? unpinMessage() : pinMessage(m)));
    }
    if (!m.view_once) act("➦  Encaminhar", "", () => openForward(m));
    act("🗑  Apagar", "danger", () => openDelete(m));
    pop.appendChild(acts);
    document.body.appendChild(pop);
    popover = pop;
    function place() {
      const r = anchor.getBoundingClientRect(), pw = pop.offsetWidth, ph = pop.offsetHeight;
      let left = m.mine ? r.right - pw : r.left;
      left = Math.max(8, Math.min(left, window.innerWidth - pw - 8));
      let top = r.top - ph - 6;
      if (top < 8) top = Math.min(r.bottom + 6, window.innerHeight - ph - 8);
      pop.style.left = left + "px"; pop.style.top = Math.max(8, top) + "px";
    }
    place();
  }
  listenOn(document, "click", (e) => { if (popover && !popover.contains(e.target)) closePopover(); });
  listenOn(document, "keydown", (e) => { if (e.key === "Escape") { closePopover(); closeDelete(); closeForward(); closeLightbox(); closeVideo(); closeViewOnce(); closePreview(); if (recording) cancelRecording(); } });
  listEl.addEventListener("scroll", closePopover, { passive: true });

  function applyMine(list, emoji) {
    const out = [];
    (list || []).forEach((r) => {
      if (r.mine) { if (r.count > 1) out.push({ emoji: r.emoji, count: r.count - 1, mine: false }); } else out.push(r);
    });
    if (emoji) {
      const f = out.find((r) => r.emoji === emoji);
      if (f) { f.count += 1; f.mine = true; } else out.push({ emoji: emoji, count: 1, mine: true });
    }
    return out.sort((a, b) => b.count - a.count);
  }
  function setReactions(id, list) {
    server = server.map((x) => (x.id === id ? Object.assign({}, x, { reactions: list }) : x));
    render();
  }
  function react(m, emoji) {
    const already = (m.reactions || []).some((r) => r.mine && r.emoji === emoji);
    const before = m.reactions || [];
    setReactions(m.id, applyMine(before, already ? null : emoji));
    const opts = already
      ? { method: "DELETE", headers: HEADERS }
      : { method: "PUT", headers: Object.assign({ "Content-Type": "application/json" }, HEADERS), body: JSON.stringify({ emoji: emoji }) };
    fetch(API_ROOT + "/" + m.id + "/reaction", Object.assign({ credentials: "same-origin" }, opts))
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((data) => setReactions(m.id, data.reactions || []))
      .catch(() => { setReactions(m.id, before); toast("Não foi possível reagir."); });
  }

  // ---------- ações: responder, copiar, apagar (Fase 7) ----------
  function myId() { const m = server.find((x) => x.mine); return m ? m.sender_id : null; }
  function quoteAuthor(rt) { return rt.sender_id === myId() ? "Você" : PARTNER_NAME; }
  function copyableText(m) {
    const t = (m.msg_type || "text") === "text" ? m.content : m.caption;
    return t && t.trim() ? t : "";
  }
  function copyText(text) {
    const ok = () => toast("Copiado.");
    const fallback = () => {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy") ? ok() : toast("Não foi possível copiar."); } catch (e) { toast("Não foi possível copiar."); }
      ta.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok, fallback);
    else fallback();
  }

  function startReply(m) {
    if (!(m.id > 0) || m.deleted) return;
    if (editing) cancelEdit();
    replyTo = { id: m.id, sender_id: m.sender_id, msg_type: m.msg_type || "text", preview: (m.content || "").slice(0, 80) };
    replyWho.textContent = quoteAuthor(replyTo);
    replyTxt.textContent = replyTo.preview;
    replyBar.hidden = false;
    input.focus();
  }
  function clearReply() { replyTo = null; replyBar.hidden = true; replyBar.classList.remove("is-edit"); }
  $("cw-replybar-x").addEventListener("click", () => { if (editing) cancelEdit(); else clearReply(); });

  // ---------- editar (Fase 8) ----------
  function startEdit(m) {
    if (!m.can_edit || !(m.id > 0)) return;
    if (recording) return;
    clearReply();
    editing = { id: m.id, original: m.content || "" };
    replyWho.textContent = "Editando mensagem";
    replyTxt.textContent = editing.original.slice(0, 80);
    replyBar.classList.add("is-edit");
    replyBar.hidden = false;
    input.value = editing.original;
    autoGrow(); updateSendState();
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
  }
  function cancelEdit() {
    if (!editing) return;
    editing = null;
    input.value = ""; autoGrow(); updateSendState();
    clearReply();
  }
  function submitEdit(text) {
    const ed = editing;
    if (text === ed.original) { cancelEdit(); return; }       // nada mudou
    editing = null; input.value = ""; autoGrow(); updateSendState(); clearReply();
    fetch(API_ROOT + "/" + ed.id, {
      method: "PATCH", credentials: "same-origin",
      headers: Object.assign({ "Content-Type": "application/json" }, HEADERS),
      body: JSON.stringify({ content: text }),
    })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j: j })))
      .then((res) => {
        if (!res.ok) throw new Error((res.j && res.j.error) || "Não foi possível editar.");
        server = server.map((x) => (x.id === ed.id ? Object.assign({}, x, res.j) : x));
        render();
      })
      .catch((err) => {
        toast(err.message || "Não foi possível editar.");
        if (!input.value) { input.value = text; autoGrow(); updateSendState(); } // devolve o texto pra não perder
      });
  }

  // ---------- mensagem fixada (fase 6b) ----------
  function applyPinned(p) {
    pinned = p && p.id ? p : null;
    pinBar.hidden = !pinned;
    pinTxt.textContent = pinned ? (pinned.preview || "") : "";
  }
  function pinRequest(method, body) {
    const headers = body ? Object.assign({ "Content-Type": "application/json" }, HEADERS) : HEADERS;
    return fetch(PIN_URL, { method: method, credentials: "same-origin", headers: headers, body: body ? JSON.stringify(body) : undefined })
      .then((r) => r.json().catch(() => ({})).then((d) => (r.ok ? d : Promise.reject(new Error(d.error || "")))));
  }
  function pinMessage(m) {
    pinRequest("PUT", { message_id: m.id })
      .then((d) => { if (destroyed) return; applyPinned(d.pinned_message); render(); toast("Mensagem fixada."); })
      .catch((err) => toast(err.message || "Não foi possível fixar a mensagem."));
  }
  function unpinMessage() {
    pinRequest("DELETE")
      .then((d) => { if (destroyed) return; applyPinned(d.pinned_message); render(); toast("Mensagem desafixada."); })
      .catch((err) => toast(err.message || "Não foi possível desafixar."));
  }
  pinGo.addEventListener("click", () => { if (pinned) scrollToMessage(pinned.id); });
  pinX.addEventListener("click", unpinMessage);

  function scrollToMessage(id, fromSearch) {
    const row = listEl.querySelector('[data-msg-id="' + id + '"]');
    if (!row) { toast(fromSearch ? "Essa mensagem não está mais na conversa." : "A mensagem original não está mais aqui."); return; }
    row.scrollIntoView({ block: "center", behavior: "smooth" });
    row.classList.add("cw-flash");
    setTimeout(() => row.classList.remove("cw-flash"), 1400);
  }

  // arrastar a bolha para a direita (celular) responde, como no WhatsApp
  function attachSwipeReply(bubble, m) {
    let sx = 0, sy = 0, dx = 0, tracking = false, armed = false;
    bubble.addEventListener("touchstart", (e) => {
      const t = e.touches[0]; sx = t.clientX; sy = t.clientY; dx = 0; tracking = true; armed = false;
    }, { passive: true });
    bubble.addEventListener("touchmove", (e) => {
      if (!tracking) return;
      const t = e.touches[0]; dx = t.clientX - sx;
      if (Math.abs(t.clientY - sy) > 24 && dx < 20) { tracking = false; bubble.style.transform = ""; return; }
      if (dx > 8) {
        const k = Math.min(dx, 72);
        bubble.style.transition = "none"; bubble.style.transform = "translateX(" + k + "px)";
        if (k >= 56 && !armed) { armed = true; if (navigator.vibrate) navigator.vibrate(8); }
      }
    }, { passive: true });
    const end = () => {
      if (!tracking) return;
      tracking = false;
      bubble.style.transition = "transform .15s"; bubble.style.transform = "";
      if (armed) startReply(m);
    };
    bubble.addEventListener("touchend", end);
    bubble.addEventListener("touchcancel", () => { tracking = false; bubble.style.transition = "transform .15s"; bubble.style.transform = ""; });
  }

  function closeDelete() { delModal.hidden = true; delActions.replaceChildren(); }
  function openDelete(m) {
    delActions.replaceChildren();
    const add = (label, cls, fn) => {
      const b = el("button", "cw-del-btn " + cls, label); b.type = "button";
      b.addEventListener("click", fn); delActions.appendChild(b); return b;
    };
    delHint.textContent = m.can_delete_for_all
      ? "Para todos: a mensagem vira “Mensagem apagada” para você e para @" + root.dataset.partner + "."
      : "Apagar para mim remove a mensagem só para você — a outra pessoa continua vendo.";
    if (m.can_delete_for_all) add("Apagar para todos", "danger", () => doDelete(m, "all"));
    add("Apagar para mim", m.can_delete_for_all ? "" : "danger", () => doDelete(m, "me"));
    add("Cancelar", "ghost", closeDelete);
    delModal.hidden = false;
    delActions.querySelector("button").focus();
  }
  delModal.addEventListener("click", (e) => { if (e.target === delModal) closeDelete(); });

  function doDelete(m, scope) {
    closeDelete();
    fetch(API_ROOT + "/" + m.id + "?scope=" + scope, { method: "DELETE", headers: HEADERS, credentials: "same-origin" })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j: j })))
      .then((res) => {
        if (!res.ok) throw new Error((res.j && res.j.error) || "Não foi possível apagar.");
        if (scope === "me") server = server.filter((x) => x.id !== m.id);
        else server = server.map((x) => (x.id === m.id ? res.j.message : x));
        if (replyTo && replyTo.id === m.id) clearReply();
        if (editing && editing.id === m.id) cancelEdit();
        searchIds = searchIds.filter((i) => i !== m.id);
        render();
        fetchThread(); // atualiza citações que apontavam para ela
      })
      .catch((err) => toast(err.message || "Não foi possível apagar."));
  }

  // ---------- encaminhar (Fase 8) ----------
  let fwdMsg = null, fwdChoices = [], fwdAll = null, fwdSelected = new Set(), fwdBusy = false;
  function closeForward() { fwdModal.hidden = true; fwdMsg = null; fwdSelected = new Set(); fwdBusy = false; }
  function fwdRefreshState() {
    const n = fwdSelected.size;
    fwdSend.disabled = n === 0 || fwdBusy;
    fwdSend.textContent = n > 1 ? "Encaminhar (" + n + ")" : "Encaminhar";
    fwdHint.textContent = n >= FORWARD_MAX ? "Limite de " + FORWARD_MAX + " conversas por vez." : "";
  }
  function fwdRender() {
    const q = foldMap(fwdFilter.value.trim()).out;
    fwdList.replaceChildren();
    const rows = (fwdAll || []).filter((c) => !q
      || foldMap(c.partner.display_name || "").out.includes(q) || foldMap(c.partner.username).out.includes(q));
    if (!rows.length) {
      fwdList.appendChild(el("p", "hint", fwdAll ? "Nenhuma conversa encontrada." : "Carregando…"));
      return;
    }
    rows.forEach((c) => {
      const u = c.partner;
      const on = fwdSelected.has(u.username);
      const b = el("button", "cw-fwd-row" + (on ? " on" : ""));
      b.type = "button"; b.setAttribute("role", "option"); b.setAttribute("aria-selected", on ? "true" : "false");
      const av = u.avatar_url
        ? Object.assign(document.createElement("img"), { src: u.avatar_url, alt: "", className: "avatar-dot avatar-img" })
        : el("span", "avatar-dot", (u.username[0] || "?").toUpperCase());
      b.appendChild(av);
      const t = el("span", "cw-fwd-name");
      t.appendChild(el("strong", null, u.display_name || u.username));
      t.appendChild(el("span", "post-meta", "@" + u.username));
      b.appendChild(t);
      b.appendChild(el("span", "cw-fwd-check", on ? "✓" : ""));
      b.addEventListener("click", () => {
        if (fwdSelected.has(u.username)) fwdSelected.delete(u.username);
        else if (fwdSelected.size >= FORWARD_MAX) { fwdRefreshState(); return; }
        else fwdSelected.add(u.username);
        fwdRender(); fwdRefreshState();
      });
      fwdList.appendChild(b);
    });
  }
  function openForward(m) {
    if (!(m.id > 0) || m.deleted || m._state) return;
    fwdMsg = m; fwdSelected = new Set(); fwdAll = null; fwdFilter.value = "";
    fwdModal.hidden = false; fwdRender(); fwdRefreshState();
    fwdFilter.focus();
    fetch(API_ROOT + "?archived=all", { headers: HEADERS, credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => { fwdAll = d.conversations || []; if (fwdMsg === m) fwdRender(); })
      .catch(() => { fwdAll = []; fwdList.replaceChildren(el("p", "hint", "Não foi possível carregar as conversas.")); });
  }
  fwdFilter.addEventListener("input", fwdRender);
  fwdModal.addEventListener("click", (e) => { if (e.target === fwdModal) closeForward(); });
  $("cw-forward-cancel").addEventListener("click", closeForward);
  fwdSend.addEventListener("click", () => {
    if (!fwdMsg || !fwdSelected.size || fwdBusy) return;
    const m = fwdMsg, names = Array.from(fwdSelected);
    fwdBusy = true; fwdRefreshState();
    fetch(API_ROOT + "/" + m.id + "/forward", {
      method: "POST", credentials: "same-origin",
      headers: Object.assign({ "Content-Type": "application/json" }, HEADERS),
      body: JSON.stringify({ usernames: names, client_id: newClientId() }),
    })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j: j })))
      .then((res) => {
        if (!res.ok) throw new Error((res.j && res.j.error) || "Não foi possível encaminhar.");
        closeForward();
        toast(names.length > 1 ? "Encaminhada para " + names.length + " conversas." : "Mensagem encaminhada.");
        if (names.indexOf(root.dataset.partner) !== -1) fetchThread(); // caiu nesta conversa
      })
      .catch((err) => { fwdBusy = false; fwdRefreshState(); toast(err.message || "Não foi possível encaminhar."); });
  });

  // ---------- buscar na conversa (Fase 8) ----------
  function searchOpen() {
    searchBar.hidden = false;
    searchInput.focus(); searchInput.select();
  }
  function searchClose() {
    if (searchBar.hidden) return;
    searchBar.hidden = true;
    clearTimeout(searchTimer); searchSeq++;
    searchInput.value = ""; searchCount.textContent = "";
    const had = !!searchTerm || searchCurrentId;
    searchTerm = ""; searchIds = []; searchPos = -1; searchCurrentId = null;
    if (had) render();
  }
  function searchGo(pos) {
    if (!searchIds.length) return;
    searchPos = (pos + searchIds.length) % searchIds.length;
    searchCurrentId = searchIds[searchPos];
    searchCount.textContent = (searchPos + 1) + " de " + searchIds.length + (searchIds.length >= 100 ? "+" : "");
    render();
    scrollToMessage(searchCurrentId, true);
  }
  function runSearch() {
    const q = searchInput.value.trim();
    const seq = ++searchSeq;
    if (q.length < 2) {
      const had = !!searchTerm;
      searchTerm = ""; searchIds = []; searchPos = -1; searchCurrentId = null;
      searchCount.textContent = q.length ? "Digite 2+ letras" : "";
      if (had) render();
      return;
    }
    searchCount.textContent = "Buscando…";
    fetch(THREAD_URL + "/search?limit=100&q=" + encodeURIComponent(q), { headers: HEADERS, credentials: "same-origin" })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j: j })))
      .then((res) => {
        if (seq !== searchSeq) return; // resposta de uma digitação antiga
        if (!res.ok) throw new Error((res.j && res.j.error) || "Falha na busca.");
        searchTerm = q;
        searchIds = (res.j.results || []).map((m) => m.id);
        searchPos = -1; searchCurrentId = null;
        if (!searchIds.length) { searchCount.textContent = "Nada encontrado"; render(); return; }
        searchGo(0); // começa pela mais recente
      })
      .catch((err) => { if (seq === searchSeq) searchCount.textContent = (err && err.message) || "Falha na busca."; });
  }
  $("cw-search-btn").addEventListener("click", () => (searchBar.hidden ? searchOpen() : searchClose()));
  $("cw-search-x").addEventListener("click", searchClose);
  $("cw-search-up").addEventListener("click", () => searchGo(searchPos + 1));   // mais antigo
  $("cw-search-down").addEventListener("click", () => searchGo(searchPos - 1)); // mais novo
  searchInput.addEventListener("input", () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch, 300); });
  searchInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (searchPos === -1 || searchInput.value.trim() !== searchTerm) { clearTimeout(searchTimer); runSearch(); }
      else searchGo(searchPos + (e.shiftKey ? -1 : 1));
    } else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); searchClose(); }
  });
  listenOn(document, "keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && (e.key === "f" || e.key === "F") && !e.shiftKey && !e.altKey) {
      e.preventDefault(); searchOpen();
    }
  });

  // ---------- envio ----------
  function autoGrow() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 140) + "px";
  }
  function updateSendState() {
    const has = !!input.value.trim();
    sendBtn.disabled = !has;
    // sem texto e com microfone disponível: o botão de enviar dá lugar ao microfone
    const showMic = !has && !recording; // sem suporte (ex.: http fora de localhost) o toque explica o motivo
    micBtn.hidden = !showMic; onceBtn.hidden = !showMic;
    sendBtn.hidden = showMic || recording;
  }
  input.addEventListener("input", () => {
    autoGrow(); updateSendState();
    if (input.value.trim() && !editing) sendTyping("typing"); else sendTyping("stop");
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && editing) { cancelEdit(); return; }
    if (e.key === "Escape" && replyTo) { clearReply(); return; }
    if (e.key === "Enter" && !e.shiftKey && !coarse && !e.isComposing) { e.preventDefault(); form.requestSubmit(); }
  });
  // no celular o teclado ocupa o lugar do painel; no desktop o painel fica aberto
  input.addEventListener("focus", () => { if (coarse && !emojiPanel.hidden) toggleEmojiPanel(false); });
  input.addEventListener("paste", (e) => {
    const items = (e.clipboardData && e.clipboardData.items) || [];
    for (const it of items) {
      if (it.kind === "file" && it.type.startsWith("image/")) { e.preventDefault(); openPreview(it.getAsFile()); return; }
      if (it.kind === "file" && it.type === "application/pdf") { e.preventDefault(); openPreview(it.getAsFile()); return; }
    }
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    if (editing) { submitEdit(text); return; }
    input.value = ""; autoGrow(); updateSendState();
    sendTyping("stop");
    queueSend({ type: "text", content: text });
  });

  function queueSend(opts) {
    const rt = replyTo; clearReply();
    const p = {
      reply_to: rt, reply_to_id: rt ? rt.id : null,
      id: -Date.now() - Math.floor(Math.random() * 1000),
      client_id: newClientId(), mine: true, _state: "sending",
      msg_type: opts.type, content: opts.content || "", caption: (opts.type === "image" || opts.type === "video" || opts.type === "file") ? (opts.content || null) : null,
      created_at: new Date().toISOString(), reactions: [],
      media_width: opts.width || null, media_height: opts.height || null,
      media_name: opts.name || null, media_size: opts.size || null,
      media_duration_ms: opts.duration || null,
      _thumb: opts.thumb || null, _thumbUrl: opts.thumb ? URL.createObjectURL(opts.thumb) : null,
      media_url: null, _file: opts.file || null, _objectUrl: opts.file ? URL.createObjectURL(opts.file) : null,
    };
    if (opts.viewOnce) {  // sem miniatura/legenda/URL local: o balão só mostra o cadeado
      p.view_once = true; p.view_once_state = "unopened"; p.caption = null; p.content = "";
      p._thumb = null; p._thumbUrl = null; p.media_width = null; p.media_height = null;
    }
    pending.push(p);
    render({ forceBottom: true });
    deliver(p);
  }
  function deliver(p) {
    let req;
    if ((p.msg_type === "image" || p.msg_type === "audio" || p.msg_type === "video" || p.msg_type === "file") && p._file) {
      const fd = new FormData();
      fd.append("file", p._file, p._file.name || (p.msg_type === "audio" ? "audio.webm" : p.msg_type === "video" ? "video.mp4" : p.msg_type === "file" ? "arquivo" : "imagem"));
      if (p.view_once) fd.append("view_once", "1");
      if (p._thumb && !p.view_once) fd.append("thumb", p._thumb, "thumb.jpg");
      if (p.caption && !p.view_once) fd.append("content", p.caption);
      fd.append("client_id", p.client_id);
      if (p.reply_to_id) fd.append("reply_to_id", p.reply_to_id);
      if (p.media_width) fd.append("width", p.media_width);
      if (p.media_height) fd.append("height", p.media_height);
      if (p.media_duration_ms) fd.append("duration_ms", Math.round(p.media_duration_ms));
      req = fetch(THREAD_URL, { method: "POST", headers: HEADERS, body: fd, credentials: "same-origin" });
    } else {
      req = fetch(THREAD_URL, {
        method: "POST", credentials: "same-origin",
        headers: Object.assign({ "Content-Type": "application/json" }, HEADERS),
        body: JSON.stringify({ content: p.content, client_id: p.client_id, reply_to_id: p.reply_to_id || undefined }),
      });
    }
    req.then((r) => r.json().then((j) => ({ ok: r.ok, status: r.status, j: j })))
      .then((res) => {
        if (!res.ok) {
          const err = new Error((res.j && res.j.error) || "Falha ao enviar");
          err.fatal = res.status >= 400 && res.status < 500 && res.status !== 408 && res.status !== 429;
          throw err;
        }
        if (!server.some((m) => m.id === res.j.id)) server = server.concat([res.j]);
        pending = pending.filter((x) => x.client_id !== p.client_id);
        if (p._objectUrl) setTimeout(() => URL.revokeObjectURL(p._objectUrl), 30000);
        if (p._thumbUrl) setTimeout(() => URL.revokeObjectURL(p._thumbUrl), 30000);
        render({ forceBottom: true });
      })
      .catch((err) => {
        pending = pending.map((x) => (x.client_id === p.client_id ? Object.assign(x, { _state: "failed" }) : x));
        render();
        if (err && err.fatal) toast(err.message);
      });
  }
  function retry(m) {
    const p = pending.find((x) => x.client_id === m.client_id);
    if (!p) return;
    p._state = "sending"; render();
    deliver(p);
  }

  // ---------- imagens: escolher, pré-visualizar, enviar ----------
  const DOC_ACCEPT = fileInput.accept;
  const MEDIA_ACCEPT = "image/png,image/jpeg,image/gif,image/webp,video/mp4,video/webm,video/quicktime,.mov,.heic,.heif";
  let attachMenu = null;
  function closeAttachMenu() { if (attachMenu) { attachMenu.remove(); attachMenu = null; } }
  function pickFile(accept) { closeAttachMenu(); fileInput.accept = accept; fileInput.click(); }
  attachBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (editing) { toast("Termine ou cancele a edição primeiro."); return; }
    if (attachMenu) { closeAttachMenu(); return; }
    const menu = el("div", "cw-attach-menu"); menu.setAttribute("role", "menu");
    [["🖼️", "Foto ou vídeo", () => pickFile(MEDIA_ACCEPT)], ["📷", "Câmera", openCamera], ["📄", "Arquivo", () => pickFile(DOC_ACCEPT)]].forEach((it) => {
      const b = el("button", "cw-attach-item"); b.type = "button"; b.setAttribute("role", "menuitem");
      b.appendChild(el("span", "cw-attach-ico", it[0])); b.appendChild(el("span", null, it[1]));
      b.addEventListener("click", it[2]); menu.appendChild(b);
    });
    form.appendChild(menu); attachMenu = menu;
  });
  listenOn(document, "click", (e) => { if (attachMenu && !attachMenu.contains(e.target)) closeAttachMenu(); });
  fileInput.addEventListener("change", () => {
    const f = fileInput.files && fileInput.files[0];
    fileInput.value = ""; fileInput.accept = DOC_ACCEPT;
    if (f) openPreview(f);
  });

  // ---------- câmera ao vivo (foto e vídeo) ----------
  let camModal = null, camStream = null, camFacing = "user", camRec = null, camChunks = [], camTimer = null, camDiscard = false;
  function stopCamStream() { if (camStream) { camStream.getTracks().forEach((t) => t.stop()); camStream = null; } }
  function closeCamera() {
    clearTimeout(camTimer); camTimer = null;
    if (camRec && camRec.state !== "inactive") { camDiscard = true; try { camRec.stop(); } catch (e) {} }
    camRec = null; stopCamStream();
    if (camModal) { camModal.remove(); camModal = null; }
  }
  function startCamStream(video) {
    stopCamStream();
    const base = { video: { facingMode: camFacing, width: { ideal: 1280 } } };
    return navigator.mediaDevices.getUserMedia(Object.assign({ audio: true }, base))
      .catch(() => navigator.mediaDevices.getUserMedia(base)) // sem microfone: só foto/vídeo mudo
      .then((st) => { camStream = st; video.srcObject = st; return video.play().catch(() => {}); });
  }
  function openCamera() {
    closeAttachMenu();
    if (editing) { toast("Termine ou cancele a edição primeiro."); return; }
    if (!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) {
      toast(window.isSecureContext === false ? "A câmera exige HTTPS (ou localhost)." : "Seu navegador não permite usar a câmera."); return;
    }
    if (camModal) return;
    const modal = el("div", "cw-modal cw-cam"); modal.setAttribute("role", "dialog"); modal.setAttribute("aria-modal", "true"); modal.setAttribute("aria-label", "Câmera");
    const card = el("div", "cw-modal-card cw-cam-card");
    const video = document.createElement("video"); video.setAttribute("playsinline", ""); video.muted = true; video.autoplay = true;
    const bar = el("div", "cw-cam-bar");
    const mk = (cls, label, txt) => { const b = el("button", cls, txt); b.type = "button"; b.setAttribute("aria-label", label); b.title = label; return b; };
    const closeB = mk("cw-cam-btn", "Fechar", "✕"), flipB = mk("cw-cam-btn", "Trocar câmera", "🔄");
    const shut = mk("cw-cam-shutter", "Tirar foto", ""), recB = mk("cw-cam-btn cw-cam-rec", "Gravar vídeo", "⏺");
    const timeEl = el("span", "cw-cam-time", "");
    bar.append(closeB, flipB, shut, recB, timeEl);
    card.append(video, bar); modal.appendChild(card); document.body.appendChild(modal); camModal = modal;
    startCamStream(video).catch(() => { toast("Permita o uso da câmera no navegador."); closeCamera(); });
    closeB.addEventListener("click", closeCamera);
    flipB.addEventListener("click", () => {
      if (camRec) return;
      camFacing = camFacing === "user" ? "environment" : "user";
      startCamStream(video).catch(() => toast("Não foi possível trocar de câmera."));
    });
    shut.addEventListener("click", () => {
      if (camRec || !video.videoWidth) return;
      const c = document.createElement("canvas"); c.width = video.videoWidth; c.height = video.videoHeight;
      c.getContext("2d").drawImage(video, 0, 0);
      c.toBlob((b) => { if (!b) return; closeCamera(); openPreview(new File([b], "foto-" + Date.now() + ".jpg", { type: "image/jpeg" })); }, "image/jpeg", 0.92);
    });
    recB.addEventListener("click", () => {
      if (camRec) { camRec.stop(); return; }
      if (!camStream || !window.MediaRecorder) { toast("Seu navegador não permite gravar vídeo."); return; }
      let type = "";
      ["video/mp4", "video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"].some((t) => { try { if (MediaRecorder.isTypeSupported(t)) { type = t; return true; } } catch (e) {} return false; });
      camChunks = []; camDiscard = false;
      const rec = new MediaRecorder(camStream, type ? { mimeType: type } : undefined); camRec = rec;
      const t0 = Date.now();
      const tick = setInterval(() => { const sec = Math.floor((Date.now() - t0) / 1000); timeEl.textContent = Math.floor(sec / 60) + ":" + String(sec % 60).padStart(2, "0"); }, 500);
      rec.ondataavailable = (ev) => { if (ev.data && ev.data.size) camChunks.push(ev.data); };
      rec.onstop = () => {
        clearInterval(tick); clearTimeout(camTimer);
        const mime = rec.mimeType || type || "video/webm";
        const blob = new Blob(camChunks, { type: mime });
        const discard = camDiscard; camRec = null;
        if (discard || !blob.size) return;
        closeCamera();
        openPreview(new File([blob], "video-" + Date.now() + "." + (mime.indexOf("mp4") >= 0 ? "mp4" : "webm"), { type: mime.split(";")[0] }));
      };
      rec.start(); recB.classList.add("on"); recB.textContent = "⏹"; shut.disabled = true; flipB.disabled = true;
      camTimer = setTimeout(() => { if (camRec) camRec.stop(); }, 120000); // máx. 2 min (limite do servidor: 55 MB)
    });
  }
  listenOn(document, "keydown", (e) => { if (e.key === "Escape") { closeAttachMenu(); closeCamera(); } });

  const previewOnce = $("cw-preview-once"), previewOnceWrap = $("cw-preview-once-wrap");
  previewOnce.addEventListener("change", () => { previewCaption.disabled = previewOnce.checked; });
  let previewFile = null, previewDims = null, previewUrl = null, previewThumb = null, previewIsVideo = false, previewIsFile = false;
  function isVideoFile(f) {
    const t = (f.type || "").toLowerCase();
    return VIDEO_TYPES.includes(t) || (!t && /\.(mp4|mov|webm)$/i.test(f.name || ""));
  }
  function isDocFile(f) {
    const t = (f.type || "").toLowerCase();
    if (isVideoFile(f) || IMAGE_TYPES.includes(t)) return false;
    return FILE_EXTS.includes(extOf(f.name));
  }
  function validMedia(f) {
    if (f.size <= 0) { toast("Arquivo vazio."); return false; }
    if (isDocFile(f)) {
      if (f.size > MAX_FILE_BYTES) { toast("Arquivo grande demais (máx. 25 MB)."); return false; }
      return true;
    }
    if (isVideoFile(f)) {
      if (f.size > MAX_VIDEO_BYTES) { toast("Vídeo grande demais (máx. 55 MB)."); return false; }
      return true;
    }
    if (!IMAGE_TYPES.includes((f.type || "").toLowerCase())) { toast("Tipo não suportado. Use foto, vídeo, PDF, Office, TXT, CSV ou ZIP."); return false; }
    if (f.size > MAX_IMAGE_BYTES) { toast("Imagem grande demais (máx. 15 MB)."); return false; }
    return true;
  }
  // 1º quadro do vídeo como JPEG (miniatura leve enviada junto)
  function captureThumb(v) {
    try {
      const w = v.videoWidth, h = v.videoHeight;
      if (!w || !h) return;
      const k = Math.min(1, 480 / Math.max(w, h));
      const c = document.createElement("canvas");
      c.width = Math.round(w * k); c.height = Math.round(h * k);
      c.getContext("2d").drawImage(v, 0, 0, c.width, c.height);
      c.toBlob((b) => { if (b && b.size < 380 * 1024) previewThumb = b; }, "image/jpeg", 0.72);
    } catch (e) { /* sem miniatura: o destinatário vê o 1º quadro do vídeo */ }
  }
  function openPreview(f) {
    if (!validMedia(f)) return;
    closePreview();
    previewFile = f; previewDims = null; previewThumb = null;
    previewIsVideo = isVideoFile(f);
    previewIsFile = isDocFile(f);
    previewUrl = previewIsFile ? null : URL.createObjectURL(f);
    previewImg.hidden = previewIsVideo || previewIsFile; previewVideo.hidden = !previewIsVideo;
    previewFileBox.hidden = !previewIsFile;
    if (previewIsFile) {
      const ic = fileIcon(extOf(f.name));
      const ico = $("cw-preview-file-ico"); ico.textContent = ic[0]; ico.style.background = ic[1];
      $("cw-preview-file-name").textContent = f.name;
      $("cw-preview-file-meta").textContent = [fmtBytes(f.size), extOf(f.name).toUpperCase()].filter(Boolean).join(" · ");
    } else if (previewIsVideo) {
      previewVideo.onloadedmetadata = () => {
        previewDims = { w: previewVideo.videoWidth, h: previewVideo.videoHeight, d: previewVideo.duration * 1000 };
        try { previewVideo.currentTime = Math.min(0.1, (previewVideo.duration || 1) / 2); } catch (e) { /* ignora */ }
      };
      previewVideo.onseeked = () => { if (!previewThumb) captureThumb(previewVideo); };
      previewVideo.onerror = () => { toast("Não foi possível ler este vídeo."); closePreview(); };
      previewVideo.src = previewUrl;
    } else {
      previewImg.onload = () => { previewDims = { w: previewImg.naturalWidth, h: previewImg.naturalHeight }; };
      previewImg.src = previewUrl;
    }
    previewCaption.value = input.value.trim() ? input.value.trim().slice(0, 2000) : "";
    previewOnce.checked = false; previewOnceWrap.hidden = previewIsFile; previewCaption.disabled = false;
    previewModal.hidden = false;
    setTimeout(() => previewCaption.focus(), 50);
  }
  function closePreview() {
    if (previewModal.hidden && !previewUrl) return;
    previewModal.hidden = true;
    previewImg.removeAttribute("src");
    previewVideo.pause(); previewVideo.removeAttribute("src"); previewVideo.load();
    previewFileBox.hidden = true; previewIsFile = false;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = null; previewFile = null; previewThumb = null;
  }
  function confirmPreview() {
    if (!previewFile) return;
    const once = !!previewOnce.checked && !previewIsFile;
    const f = previewFile, caption = once ? "" : previewCaption.value.trim();
    const dims = previewDims, thumb = previewThumb, isVid = previewIsVideo, isDoc = previewIsFile;
    if (isVid && !dims) { toast("Aguarde o vídeo carregar."); return; }
    if (caption && input.value.trim() === caption) { input.value = ""; autoGrow(); updateSendState(); }
    // o objeto-URL do envio é separado do da pré-visualização (que é liberado aqui)
    closePreview();
    queueSend({
      type: isDoc ? "file" : (isVid ? "video" : "image"), content: caption, file: f,
      name: isDoc ? f.name : null, size: isDoc ? f.size : null,
      width: dims && dims.w, height: dims && dims.h,
      duration: isVid && dims ? dims.d : null, thumb: isVid ? thumb : null, viewOnce: once,
    });
  }
  $("cw-preview-cancel").addEventListener("click", closePreview);
  $("cw-preview-send").addEventListener("click", confirmPreview);
  previewCaption.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); confirmPreview(); } });
  previewModal.addEventListener("click", (e) => { if (e.target === previewModal) closePreview(); });

  // arrastar e soltar
  let dragDepth = 0;
  function hasFiles(e) { return e.dataTransfer && Array.from(e.dataTransfer.types || []).includes("Files"); }
  root.addEventListener("dragenter", (e) => { if (hasFiles(e)) { e.preventDefault(); dragDepth++; dropEl.hidden = false; } });
  root.addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
  root.addEventListener("dragleave", () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) dropEl.hidden = true; });
  root.addEventListener("drop", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault(); dragDepth = 0; dropEl.hidden = true;
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) openPreview(f);
  });

  // ---------- áudio: player ----------
  const audioWidgets = new Map(); // chave+src -> {node, audio}
  let playingAudio = null;
  // Fase 14: balão de chamada. `media_mime` = call/<voice|video>/<estado>; duração em media_duration_ms.
  function callBlock(m) {
    const p = (m.media_mime || "").split("/");
    const video = p[1] === "video", state = p[2] || "ended", mine = !!m.mine;
    const bad = state === "missed" || state === "busy" || state === "failed";
    const kind = video ? "vídeo" : "voz";
    let title, detail = "";
    if (state === "ended") { title = "Chamada de " + kind; detail = fmtDur((m.media_duration_ms || 0) / 1000); }
    else if (state === "declined") { title = mine ? "Chamada recusada" : "Você recusou a chamada"; }
    else if (state === "failed") title = "Chamada de " + kind + " falhou";
    else if (state === "busy") title = mine ? "Ocupado" : "Chamada de " + kind + " perdida";
    else title = mine ? "Sem resposta" : "Chamada de " + kind + " perdida";
    const box = el("div", "cw-call" + (bad && !mine ? " missed" : ""));
    box.setAttribute("role", "group"); box.setAttribute("aria-label", title + (detail ? ", " + detail : ""));
    box.appendChild(el("span", "cw-call-ico", video ? "📹" : "📞"));
    const txt = el("div", "cw-call-txt");
    txt.appendChild(el("strong", null, title));
    txt.appendChild(el("span", "cw-call-sub", (mine ? "↗ " : (bad ? "↙ " : "↙ ")) + (detail || (video ? "Vídeo" : "Voz"))));
    box.appendChild(txt);
    const src = document.getElementById("cw-call-btn");
    if (src && !m.deleted) {
      const back = el("button", "cw-call-back", "Ligar de volta");
      back.type = "button";
      back.dataset.callUser = PARTNER; back.dataset.callName = PARTNER_NAME;
      back.dataset.callAvatar = src.dataset.callAvatar || "";
      if (video) back.dataset.callMedia = "video";
      box.appendChild(back);
    }
    return box;
  }
  function fmtDur(sec) {
    sec = Math.max(0, Math.round(sec || 0));
    return Math.floor(sec / 60) + ":" + String(sec % 60).padStart(2, "0");
  }
  function savedSpeed() {
    try { const v = parseFloat(localStorage.getItem(SPEED_KEY)); return SPEEDS.includes(v) ? v : 1; } catch (e) { return 1; }
  }
  function saveSpeed(v) { try { localStorage.setItem(SPEED_KEY, String(v)); } catch (e) { /* ignora */ } }
  function seeded(str) { // PRNG determinístico: a mesma onda nos dois lados
    let h = 1779033703 ^ str.length;
    for (let i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
    return function () {
      h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909);
      return ((h ^= h >>> 16) >>> 0) / 4294967296;
    };
  }
  function pruneAudioWidgets() {
    audioWidgets.forEach((w, k) => { if (!w.node.isConnected && w !== playingAudio) audioWidgets.delete(k); });
  }
  function audioWidget(m) {
    const src = mediaSrc(m), wkey = itemKey(m) + "|" + src;
    const have = audioWidgets.get(wkey);
    if (have) return have.node; // o mesmo player sobrevive às re-renderizações (não corta o som)

    const node = el("div", "cw-audio");
    const play = el("button", "cw-audio-play"); play.type = "button"; play.setAttribute("aria-label", "Reproduzir áudio");
    const mid = el("div", "cw-audio-mid");
    const wave = el("div", "cw-audio-wave");
    wave.setAttribute("role", "slider"); wave.setAttribute("aria-label", "Posição do áudio");
    wave.setAttribute("aria-valuemin", "0"); wave.setAttribute("aria-valuemax", "100"); wave.setAttribute("aria-valuenow", "0"); wave.tabIndex = 0;
    const rnd = seeded(String(m.client_id || m.id));
    const BARS = 30, bars = [];
    for (let i = 0; i < BARS; i++) {
      const b = el("span", "cw-bar"); b.style.setProperty("--h", (22 + Math.round(rnd() * 78)) + "%");
      wave.appendChild(b); bars.push(b);
    }
    const time = el("span", "cw-audio-time");
    const speed = el("button", "cw-audio-speed"); speed.type = "button"; speed.title = "Velocidade";
    const row = el("div", "cw-audio-row"); row.append(time, speed);
    mid.append(wave, row);
    node.append(play, mid);

    const total0 = (m.media_duration_ms || 0) / 1000;
    const audio = new Audio(); audio.preload = "metadata"; audio.src = src;
    let rate = savedSpeed(), fixing = false;
    audio.playbackRate = rate;
    speed.textContent = (rate === 1.5 ? "1,5" : rate) + "×";
    const w = { node: node, audio: audio };
    audioWidgets.set(wkey, w);

    function total() { return total0 || (isFinite(audio.duration) ? audio.duration : 0); }
    function paint() {
      const t = total(), cur = audio.currentTime || 0;
      const ratio = t ? Math.min(1, cur / t) : 0;
      const on = Math.round(ratio * BARS);
      bars.forEach((b, i) => b.classList.toggle("on", i < on));
      wave.setAttribute("aria-valuenow", String(Math.round(ratio * 100)));
      time.textContent = (audio.paused && cur === 0) ? fmtDur(t) : fmtDur(cur);
    }
    function setIcon() {
      node.classList.toggle("playing", !audio.paused);
      play.setAttribute("aria-label", audio.paused ? "Reproduzir áudio" : "Pausar áudio");
    }
    paint(); setIcon();

    play.addEventListener("click", () => {
      if (audio.paused) {
        if (playingAudio && playingAudio !== w) playingAudio.audio.pause();
        playingAudio = w;
        audio.play().catch(() => toast("Não foi possível tocar o áudio."));
      } else audio.pause();
    });
    ["play", "pause", "ended"].forEach((ev) => audio.addEventListener(ev, setIcon));
    audio.addEventListener("ended", () => { audio.currentTime = 0; paint(); });
    audio.addEventListener("timeupdate", () => { if (!fixing) paint(); });
    audio.addEventListener("error", () => { node.classList.add("broken"); time.textContent = "Indisponível"; });
    // webm do MediaRecorder vem sem duração (Infinity): força o navegador a calculá-la
    audio.addEventListener("loadedmetadata", () => {
      if (audio.duration === Infinity) {
        fixing = true; audio.currentTime = 1e101;
        audio.addEventListener("timeupdate", function once() {
          audio.removeEventListener("timeupdate", once); audio.currentTime = 0; fixing = false; paint();
        });
      } else paint();
    });
    function seekTo(ratio) {
      const t = total(); if (!t) return;
      audio.currentTime = Math.max(0, Math.min(1, ratio)) * t; paint();
    }
    wave.addEventListener("click", (e) => { const r = wave.getBoundingClientRect(); seekTo((e.clientX - r.left) / r.width); });
    wave.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") { audio.currentTime = Math.min(total(), audio.currentTime + 5); e.preventDefault(); }
      else if (e.key === "ArrowLeft") { audio.currentTime = Math.max(0, audio.currentTime - 5); e.preventDefault(); }
      else if (e.key === " " || e.key === "Enter") { play.click(); e.preventDefault(); }
    });
    speed.addEventListener("click", () => {
      rate = SPEEDS[(SPEEDS.indexOf(rate) + 1) % SPEEDS.length];
      audio.playbackRate = rate; saveSpeed(rate);
      speed.textContent = (rate === 1.5 ? "1,5" : rate) + "×";
    });
    return node;
  }

  // ---------- áudio: gravar ----------
  const micSupported = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
  let recording = false, recorder = null, recStream = null, recChunks = [], recStart = 0, recTimer = null;
  let recExt = "webm", recMime = "audio/webm", recDiscard = false, recCtx = null, recRaf = 0;

  function pickRecType() {
    for (const t of REC_TYPES) {
      try { if (MediaRecorder.isTypeSupported(t[0])) return t; } catch (e) { /* tenta o próximo */ }
    }
    return ["", "webm"]; // deixa o navegador escolher
  }
  function setRecordingUi(on) {
    recording = on;
    recBar.hidden = !on; fieldEl.hidden = on;
    if (on) { micBtn.hidden = true; onceBtn.hidden = true; sendBtn.hidden = true; }
    updateSendState();
    if (!on) { recTime.textContent = "0:00"; recLevel.replaceChildren(); }
  }
  function startLevelMeter(stream) {
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      recCtx = new AC();
      const an = recCtx.createAnalyser(); an.fftSize = 256;
      recCtx.createMediaStreamSource(stream).connect(an);
      const data = new Uint8Array(an.frequencyBinCount), N = 24, hist = new Array(N).fill(4);
      recLevel.replaceChildren();
      const spans = []; for (let i = 0; i < N; i++) { const b = el("span"); recLevel.appendChild(b); spans.push(b); }
      let last = 0;
      (function tick(ts) {
        recRaf = requestAnimationFrame(tick);
        if (ts - last < 70) return; last = ts;
        an.getByteTimeDomainData(data);
        let peak = 0; for (let i = 0; i < data.length; i++) peak = Math.max(peak, Math.abs(data[i] - 128));
        hist.push(Math.max(4, Math.min(100, Math.round((peak / 128) * 160)))); hist.shift();
        spans.forEach((b, i) => { b.style.height = hist[i] + "%"; });
      })(0);
    } catch (e) { /* sem medidor: segue gravando */ }
  }
  function stopMeter() {
    cancelAnimationFrame(recRaf); recRaf = 0;
    if (recCtx) { try { recCtx.close(); } catch (e) { /* ok */ } recCtx = null; }
  }
  function releaseStream() {
    if (recStream) { recStream.getTracks().forEach((t) => t.stop()); recStream = null; }
    stopMeter(); clearInterval(recTimer); recTimer = null;
    if (recTypingTimer) { clearInterval(recTypingTimer); recTypingTimer = null; iAmTyping = true; sendTyping("stop"); }
  }
  function startRecording() {
    if (recording) return;
    if (!micSupported) { toast(window.isSecureContext === false ? "Gravar áudio exige HTTPS (ou localhost). Abra o site por um endereço seguro." : "Seu navegador não permite gravar áudio."); return; }
    // fecha o painel de emojis sem devolver o foco ao campo (no celular abriria o teclado)
    emojiPanel.hidden = true; emojiBtn.classList.remove("on");
    navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } })
      .then((stream) => {
        recStream = stream; recChunks = []; recDiscard = false;
        const type = pickRecType();
        try { recorder = type[0] ? new MediaRecorder(stream, { mimeType: type[0] }) : new MediaRecorder(stream); }
        catch (e) { releaseStream(); toast("Não foi possível iniciar a gravação."); return; }
        recMime = (recorder.mimeType || type[0] || "audio/webm").split(";")[0];
        recExt = recMime.indexOf("mp4") >= 0 ? "m4a" : recMime.indexOf("ogg") >= 0 ? "ogg" : "webm";
        recorder.addEventListener("dataavailable", (e) => { if (e.data && e.data.size) recChunks.push(e.data); });
        recorder.addEventListener("stop", onRecorderStop);
        recorder.start(250);
        recStart = Date.now();
        setRecordingUi(true);
        sendTyping("recording", true);
        clearInterval(recTypingTimer);
        recTypingTimer = setInterval(() => sendTyping("recording", true), 4000);
        startLevelMeter(stream);
        recTimer = setInterval(() => {
          const ms = Date.now() - recStart;
          recTime.textContent = fmtDur(ms / 1000);
          if (ms >= MAX_REC_MS) finishRecording(); // limite: envia o que gravou
        }, 250);
      })
      .catch((err) => {
        const denied = err && (err.name === "NotAllowedError" || err.name === "SecurityError");
        toast(denied ? "Permita o uso do microfone no navegador para gravar." : "Microfone não encontrado.");
      });
  }
  function onRecorderStop() {
    const ms = Date.now() - recStart, chunks = recChunks, discard = recDiscard;
    recChunks = []; recorder = null;
    releaseStream(); setRecordingUi(false);
    if (discard) return;
    if (ms < MIN_REC_MS) { toast("Gravação muito curta."); return; }
    const blob = new Blob(chunks, { type: recMime });
    if (!blob.size) { toast("Nada foi gravado."); return; }
    const file = new File([blob], "audio-" + Date.now() + "." + recExt, { type: recMime });
    const once = voiceOnce; setVoiceOnce(false);  // vale só para este áudio
    queueSend({ type: "audio", content: "", file: file, duration: ms, viewOnce: once });
  }
  function finishRecording() {
    if (!recorder || recorder.state === "inactive") return;
    recDiscard = false; recorder.stop();
  }
  function cancelRecording() {
    if (!recorder || recorder.state === "inactive") { releaseStream(); setRecordingUi(false); return; }
    recDiscard = true; recorder.stop();
  }
  let voiceOnce = false;
  function setVoiceOnce(on) {
    voiceOnce = !!on; onceBtn.classList.toggle("is-on", voiceOnce); onceBtn.setAttribute("aria-pressed", String(voiceOnce));
  }
  onceBtn.addEventListener("click", () => {
    setVoiceOnce(!voiceOnce);
    toast(voiceOnce ? "O próximo áudio vai como visualização única." : "Visualização única desligada.");
  });
  micBtn.addEventListener("click", startRecording);
  $("cw-rec-send").addEventListener("click", finishRecording);
  $("cw-rec-cancel").addEventListener("click", cancelRecording);
  listenOn(window, "pagehide", () => { if (recording) cancelRecording(); });

  // ---------- visualizador em tela cheia ----------
  let lb = null, lbItems = [], lbIndex = 0;
  function imageItems() {
    return allItems().filter((m) => !m.deleted && m.msg_type === "image" && mediaSrc(m));
  }
  function closeLightbox() {
    if (!lb) return;
    lb.remove(); lb = null; document.body.classList.remove("cw-lb-open");
  }
  function openLightbox(key) {
    lbItems = imageItems();
    lbIndex = Math.max(0, lbItems.findIndex((m) => itemKey(m) === key));
    if (!lbItems.length) return;
    closeLightbox();
    lb = el("div", "cw-lb");
    lb.setAttribute("role", "dialog"); lb.setAttribute("aria-modal", "true");
    const img = document.createElement("img"); img.className = "cw-lb-img"; img.alt = "";
    const close = el("button", "cw-lb-btn cw-lb-close", "✕"); close.type = "button"; close.setAttribute("aria-label", "Fechar");
    const prev = el("button", "cw-lb-btn cw-lb-nav cw-lb-prev", "‹"); prev.type = "button"; prev.setAttribute("aria-label", "Anterior");
    const next = el("button", "cw-lb-btn cw-lb-nav cw-lb-next", "›"); next.type = "button"; next.setAttribute("aria-label", "Próxima");
    const cap = el("div", "cw-lb-cap"); const cnt = el("div", "cw-lb-count");
    const dl = el("a", "cw-lb-btn cw-lb-dl", "⬇"); dl.setAttribute("aria-label", "Baixar"); dl.title = "Baixar";
    lb.append(img, close, prev, next, cap, cnt, dl);
    // zoom: pinça (2 dedos), roda do mouse e duplo clique/toque; arrastar quando ampliado
    let scale = 1, tx = 0, ty = 0, pinched = false;
    const ptrs = new Map();
    let pinchStart = 0, scaleStart = 1;
    function applyZoom() {
      img.style.transform = scale === 1 ? "" : "translate(" + tx + "px," + ty + "px) scale(" + scale + ")";
      img.style.cursor = scale > 1 ? "grab" : "";
    }
    function resetZoom() { scale = 1; tx = 0; ty = 0; applyZoom(); }
    function setScale(v) { scale = Math.max(1, Math.min(5, v)); if (scale === 1) { tx = 0; ty = 0; } applyZoom(); }
    img.style.touchAction = "none"; img.style.transition = "none";
    img.addEventListener("pointerdown", (e) => {
      img.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (ptrs.size === 2) {
        const [a, b] = Array.from(ptrs.values());
        pinchStart = Math.hypot(a.x - b.x, a.y - b.y) || 1; scaleStart = scale; pinched = true;
      }
    });
    img.addEventListener("pointermove", (e) => {
      const p0 = ptrs.get(e.pointerId); if (!p0) return;
      const dx = e.clientX - p0.x, dy = e.clientY - p0.y;
      p0.x = e.clientX; p0.y = e.clientY;
      if (ptrs.size === 2) {
        const [a, b] = Array.from(ptrs.values());
        setScale(scaleStart * (Math.hypot(a.x - b.x, a.y - b.y) / pinchStart));
      } else if (scale > 1) { tx += dx; ty += dy; applyZoom(); }
    });
    function endPtr(e) { ptrs.delete(e.pointerId); if (scale === 1) { tx = 0; ty = 0; applyZoom(); } }
    img.addEventListener("pointerup", endPtr); img.addEventListener("pointercancel", endPtr);
    img.addEventListener("dblclick", (e) => { e.preventDefault(); setScale(scale > 1 ? 1 : 2.5); });
    lb.addEventListener("wheel", (e) => { e.preventDefault(); setScale(scale * Math.exp(-e.deltaY * 0.002)); }, { passive: false });
    function show(i) {
      resetZoom();
      lbIndex = (i + lbItems.length) % lbItems.length;
      const m = lbItems[lbIndex];
      img.src = mediaSrc(m);
      cap.textContent = m.caption || ""; cap.hidden = !m.caption;
      cnt.textContent = lbItems.length > 1 ? (lbIndex + 1) + " / " + lbItems.length : "";
      dl.href = mediaSrc(m); dl.download = "driqy-" + (m.id > 0 ? m.id : "imagem");
      prev.hidden = next.hidden = lbItems.length < 2;
    }
    close.addEventListener("click", closeLightbox);
    prev.addEventListener("click", (e) => { e.stopPropagation(); show(lbIndex - 1); });
    next.addEventListener("click", (e) => { e.stopPropagation(); show(lbIndex + 1); });
    lb.addEventListener("click", (e) => { if (e.target === lb) closeLightbox(); });
    lb.addEventListener("keydown", (e) => {
      if (e.key === "ArrowLeft") show(lbIndex - 1); else if (e.key === "ArrowRight") show(lbIndex + 1);
    });
    let sx = null;
    lb.addEventListener("touchstart", (e) => {
      if (e.touches.length > 1) { sx = null; return; }
      pinched = false; sx = e.touches[0].clientX;
    }, { passive: true });
    lb.addEventListener("touchend", (e) => {
      if (sx == null || pinched || scale > 1) { sx = null; return; } // com zoom, arrastar move a imagem
      const dx = e.changedTouches[0].clientX - sx; sx = null;
      if (Math.abs(dx) > 60 && lbItems.length > 1) show(lbIndex + (dx < 0 ? 1 : -1));
    });
    document.body.appendChild(lb);
    document.body.classList.add("cw-lb-open");
    lb.tabIndex = -1; lb.focus();
    show(lbIndex);
  }

  // ---------- player de vídeo em tela cheia ----------
  let vp = null;
  function closeVideo() {
    if (!vp) return;
    const v = vp.querySelector("video"); if (v) { v.pause(); v.removeAttribute("src"); v.load(); }
    vp.remove(); vp = null; document.body.classList.remove("cw-lb-open");
  }
  function openVideo(m) {
    closeVideo(); closeLightbox();
    vp = el("div", "cw-lb cw-vp");
    vp.setAttribute("role", "dialog"); vp.setAttribute("aria-modal", "true");
    const v = document.createElement("video");
    v.className = "cw-vp-video"; v.controls = true; v.autoplay = true; v.playsInline = true;
    v.preload = "auto"; v.src = mediaSrc(m);
    v.addEventListener("error", () => toast("Não foi possível reproduzir o vídeo."));
    const close = el("button", "cw-lb-btn cw-lb-close", "✕"); close.type = "button"; close.setAttribute("aria-label", "Fechar");
    const dl = el("a", "cw-lb-btn cw-lb-dl", "⬇"); dl.href = mediaSrc(m); dl.download = "driqy-video-" + (m.id > 0 ? m.id : "novo");
    dl.setAttribute("aria-label", "Baixar"); dl.title = "Baixar";
    const cap = el("div", "cw-lb-cap", m.caption || ""); cap.hidden = !m.caption;
    close.addEventListener("click", closeVideo);
    vp.addEventListener("click", (e) => { if (e.target === vp) closeVideo(); });
    vp.append(v, close, dl, cap);
    document.body.appendChild(vp); document.body.classList.add("cw-lb-open");
    close.focus();
  }
  listenOn(window, "pagehide", closeVideo);

  // ---------- fim de vida (fase 6a) ----------
  window.__pingThreadDestroy = () => {
    if (destroyed) return;
    destroyed = true;
    clearInterval(pollTimer); clearInterval(presenceTimer);
    if (jumpRaf) cancelAnimationFrame(jumpRaf);
    clearTimeout(liveTimer); clearTimeout(typingTimer); clearTimeout(searchTimer);
    try { if (recording) cancelRecording(); } catch (e) {}
    try { closeVideo(); closeLightbox(); } catch (e) {}
    try { if (iAmTyping) sendTyping("stop", false); } catch (e) {}
    cleanups.forEach((fn) => { try { fn(); } catch (e) {} });
    if (popover) closePopover();
    try { closeAttachMenu(); closeCamera(); } catch (e) {}
    window.__pingThreadDestroy = null;
  };

  // ---------- início ----------
  updateSendState();
  fetchThread().then(() => { if (!destroyed) startPolling(); });
})();
