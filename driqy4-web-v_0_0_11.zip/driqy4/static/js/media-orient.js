/*
 * Classifica a mídia de cada post em paisagem / retrato / quadrada, com base
 * na proporção REAL do arquivo (largura x altura), tanto pra fotos quanto
 * pra vídeos. O CSS usa essa classe pra escolher uma de 3 caixas fixas
 * (padrão, .media-landscape, .media-square) — assim fotos/vídeos horizontais
 * aparecem numa caixa horizontal de verdade (não espremidos numa caixa
 * vertical), mas o número de formatos possíveis é pequeno, então os posts
 * continuam com tamanho parecido no feed.
 *
 * Vídeos verticais ou quadrados usam a mesma caixa 4:5 das fotos (em vez de
 * uma altura fixa com object-fit: contain), então o vídeo preenche a caixa
 * inteira sem sobrar tarja preta nas laterais — só corta um pouco as bordas
 * quando a proporção real não bate exatamente com 4:5.
 *
 * Antes esse script calculava uma aspect-ratio exata pra CADA foto (contínua,
 * de 0.55 até 1.9), o que fazia os posts variarem muito de altura entre si.
 * Agora só existem 3 moldes fixos, definidos no CSS.
 */
(function () {
  function classify(ratio) {
    if (ratio > 1.15) return "media-landscape";
    if (ratio < 0.9) return "media-portrait";
    return "media-square";
  }

  function applyClass(container, w, h) {
    if (!w || !h || container.dataset.orientSet) return;

    const raw = w / h;
    container.classList.remove("media-landscape", "media-square", "media-portrait");
    container.classList.add(classify(raw));
    container.dataset.orientSet = "1";
  }

  function watch(img, container) {
    if (!img || !container || container.dataset.orientSet) return;
    if (img.complete && img.naturalWidth) {
      applyClass(container, img.naturalWidth, img.naturalHeight);
    } else {
      img.addEventListener("load", () => applyClass(container, img.naturalWidth, img.naturalHeight), { once: true });
    }
  }

  function watchVideo(video, container) {
    if (!video || !container || container.dataset.orientSet) return;
    if (video.readyState >= 1 && video.videoWidth) {
      applyClass(container, video.videoWidth, video.videoHeight);
    } else {
      video.addEventListener("loadedmetadata", () => applyClass(container, video.videoWidth, video.videoHeight), { once: true });
    }
  }

  function setupCard(scope) {
    const root = scope || document;

    // post com uma única foto: classifica o wrapper .post-media
    root.querySelectorAll(".post-media").forEach((wrap) => {
      const img = wrap.querySelector(".post-media-image");
      if (img) watch(img, wrap);
    });

    // post com um único vídeo: classifica o wrapper .video-wrap
    root.querySelectorAll(".video-wrap").forEach((wrap) => {
      const video = wrap.querySelector(".feed-video");
      if (video) watchVideo(video, wrap);
    });

    // carrossel (várias fotos/vídeos): usa a proporção do primeiro item pra
    // classificar o carrossel inteiro, já que todos os slides precisam ter
    // a mesma altura pra rolagem funcionar direito.
    root.querySelectorAll(".post-carousel").forEach((carousel) => {
      const firstImg = carousel.querySelector(".post-carousel-slide img.post-media-image");
      if (firstImg) {
        watch(firstImg, carousel);
        return;
      }
      const firstVideo = carousel.querySelector(".post-carousel-slide video");
      if (firstVideo) watchVideo(firstVideo, carousel);
    });
  }

  window.driqyMediaOrient = { setupCard };

  document.addEventListener("DOMContentLoaded", () => setupCard(document));
})();
