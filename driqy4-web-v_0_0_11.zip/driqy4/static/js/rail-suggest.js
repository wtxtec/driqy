/* Cartão "Sugestões para você" (coluna direita): quem seguir, com botão Seguir.
   O clique em Seguir é tratado por follow.js (.btn-follow + data-follow-username).
   Aqui, depois que a pessoa passa a ser seguida, a linha mostra "Seguindo" + "Desfazer" por UNDO_MS;
   se ninguém desfizer, a linha é trocada por outra sugestão. */
(function () {
  "use strict";
  var list = document.getElementById("rail-suggest-list");
  var rail = document.getElementById("rail");
  if (!list || !rail || document.body.classList.contains("rail-off")) return;
  var url = (rail.getAttribute("data-widgets-url") || "").replace(/\/$/, "") + "/suggestions";
  var SHOW = 4;
  var UNDO_MS = 6000; // tempo para o "Desfazer" antes de repor a sugestão
  var shown = [];

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function note(text, retry) {
    list.innerHTML = "";
    var box = el("div", "wx-msg");
    box.appendChild(el("p", "hint", text));
    if (retry) {
      var b = el("button", "btn-outline wx-action", "Tentar de novo");
      b.type = "button";
      b.addEventListener("click", retry);
      box.appendChild(b);
    }
    list.appendChild(box);
  }

  function fetchUsers(limit) {
    var q = "?limit=" + limit + (shown.length ? "&exclude=" + encodeURIComponent(shown.join(",")) : "");
    return fetch(url + q, { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error("http " + r.status)); })
      .then(function (d) { return d.users || []; });
  }

  function makeRow(u) {
    shown.push(u.username);
    var row = el("div", "rail-suggest-row");
    var link = el("a", "rail-suggest-link");
    link.href = "/u/" + encodeURIComponent(u.username);
    var av = el("span", "rail-avatar");
    if (u.avatar_url) {
      var img = el("img");
      img.src = u.avatar_url;
      img.alt = "";
      img.loading = "lazy";
      av.appendChild(img);
    } else {
      av.textContent = u.username.charAt(0).toUpperCase();
    }
    link.appendChild(av);
    var txt = el("span", "rail-row-body");
    txt.appendChild(el("strong", "rail-row-title", u.display_name || u.username));
    txt.appendChild(el("span", "rail-row-meta", u.reason || "@" + u.username));
    link.appendChild(txt);
    row.appendChild(link);

    var btn = el("button", "btn-follow", "Seguir");
    btn.type = "button";
    btn.setAttribute("data-follow-username", u.username);
    btn.setAttribute("data-following", "false");

    var undo = el("button", "rail-suggest-undo", "Desfazer");
    undo.type = "button";
    undo.hidden = true;
    var timer = null;

    function stopTimer() {
      if (timer) { clearTimeout(timer); timer = null; }
    }

    function scheduleLeave() {
      stopTimer();
      timer = setTimeout(function () {
        timer = null;
        undo.hidden = true;
        row.classList.add("rail-suggest-leaving");
        setTimeout(function () { replace(row); }, 250);
      }, UNDO_MS);
    }

    // follow.js troca data-following ao concluir o pedido; observamos o atributo em vez de adivinhar o tempo
    new MutationObserver(function () {
      if (btn.getAttribute("data-following") === "true") {
        undo.hidden = false;
        undo.disabled = false;
        scheduleLeave();
      } else {
        // voltou a "Seguir" (pelo Desfazer ou clicando em "Seguindo"): cancela a reposição
        stopTimer();
        undo.hidden = true;
      }
    }).observe(btn, { attributes: true, attributeFilter: ["data-following"] });

    undo.addEventListener("click", function () {
      if (undo.disabled) return;
      stopTimer();
      undo.disabled = true;
      btn.disabled = true;
      fetch("/u/" + encodeURIComponent(u.username) + "/deixar-de-seguir", {
        method: "POST",
        headers: { "X-Requested-With": "fetch" },
      })
        .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error("http " + r.status)); })
        .then(function (d) {
          if (d.following) throw new Error("still following");
          btn.setAttribute("data-following", "false");
          btn.classList.remove("is-following");
          btn.textContent = "Seguir";
        })
        .catch(function () {
          // não deu para desfazer: continua seguindo, então reabre a janela do Desfazer
          undo.disabled = false;
          undo.hidden = false;
          scheduleLeave();
        })
        .finally(function () { btn.disabled = false; });
    });

    row.appendChild(undo);
    row.appendChild(btn);
    return row;
  }

  function replace(row) {
    fetchUsers(1).then(function (users) {
      if (users[0]) row.replaceWith(makeRow(users[0]));
      else row.remove();
      if (!list.querySelector(".rail-suggest-row")) note("Sem sugestões por enquanto.");
    }).catch(function () { row.remove(); });
  }

  function load() {
    shown = [];
    note("Carregando…");
    fetchUsers(SHOW).then(function (users) {
      if (!users.length) { note("Sem sugestões por enquanto. Você já segue quase todo mundo!"); return; }
      list.innerHTML = "";
      users.forEach(function (u) { list.appendChild(makeRow(u)); });
    }).catch(function () { note("Não consegui carregar as sugestões.", load); });
  }

  load();
})();
