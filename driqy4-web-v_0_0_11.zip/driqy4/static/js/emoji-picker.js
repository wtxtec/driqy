/* Seletor de emojis estilo Telegram (privado e grupo).
 * Uso: const p = DriqyEmojiPicker.build({ onPick(e), onBackspace() }); host.appendChild(p);
 * Abas no topo, busca "Buscar Emojis", seções com título, barra inferior com apagar. */
(function () {
  const RECENT_KEY = "driqy-chat-recent-emoji";
  const SECTIONS = [
    ["😀", "Smileys e Pessoas", "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 ☺️ 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 😮‍💨 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👹 👻 👽 🤖 🙈 🙉 🙊"],
    ["👍", "Gestos e Corpo", "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 ✍️ 💪 🙌 👏 🤲 👐 🫶 🫡 🫰 🤌 🤏 ✊ 👊 🤛 🤜 🫵 👀 👁️ 👅 👄 🧠 🦾"],
    ["❤️", "Corações e Emoções", "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💌 💋 💯 💢 💥 💫 💦 💨 🔥 ✨ ⭐ 🌟 ⚡ 🎉 🎊"],
    ["🐶", "Animais e Natureza", "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🦀 🐠 🐬 🐳 🦈 🐘 🦒 🌸 🌹 🌻 🌲 🌴 🍀 🍁"],
    ["🍕", "Comida e Bebida", "🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🌽 🥕 🥔 🍞 🧀 🥚 🍳 🥓 🍔 🍟 🌭 🍕 🌮 🌯 🥗 🍝 🍜 🍣 🍤 🍦 🍩 🍪 🎂 🍰 🍫 🍬 🍿 ☕ 🍺 🍻 🥂 🍷 🥤 🧃"],
    ["⚽", "Atividades", "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🥊 🥋 🎯 🎮 🕹️ 🎲 🧩 🎨 🎬 🎤 🎧 🎸 🥁 🎹 🏆 🥇 🥈 🥉 🏅 🚴 🏊 🏃 🧘 ⛹️"],
    ["🚗", "Viagens e Lugares", "🚗 🚕 🚌 🏎️ 🚓 🚑 🚒 🚚 🛵 🏍️ 🚲 ✈️ 🚀 🛸 🚁 ⛵ 🚢 🚂 🏠 🏢 🏖️ 🏝️ ⛰️ 🌋 🌅 🌃 🌈 ☀️ 🌙 ☁️ ⛈️ ❄️ 🌊"],
    ["💡", "Objetos", "📱 💻 ⌨️ 🖥️ 📷 📹 🎥 📺 📻 ⏰ 💡 🔋 🔌 💰 💳 💎 🔧 🔨 🔑 🔒 📦 📚 📖 ✏️ 📝 📅 📌 📎 ✂️ 🎁 🎈 🛒 🧴 🕯️"],
    ["🔣", "Símbolos", "✅ ❌ ❓ ❗ ‼️ ⚠️ 🚫 ⭕ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ ➕ ➖ ➡️ ⬅️ ⬆️ ⬇️ 🔁 🔔 🔕 ♻️ ✔️ ☑️ 🆗 🆕 🆒 🔝 🏳️‍🌈 🇧🇷"],
  ];
  // palavras de busca (pt-BR) — não cobre tudo; quem não está aqui ainda aparece pelo nome da seção
  const KEYS = {
    "😀": "sorriso feliz alegre", "😂": "rindo chorando risada kkk", "🤣": "rindo risada kkk", "😍": "apaixonado amor olhos coracao",
    "😘": "beijo", "😊": "feliz sorriso", "😭": "chorando triste choro", "😢": "triste lagrima", "😡": "bravo raiva", "😱": "susto medo",
    "😴": "sono dormindo", "😎": "legal oculos", "🤔": "pensando duvida", "🙄": "tedio", "😅": "suor nervoso", "🥰": "amor carinho",
    "😉": "piscada", "😜": "lingua brincadeira", "🥺": "pedindo carente", "😳": "vergonha", "🤯": "mente explodindo", "🥳": "festa",
    "👍": "joia positivo curtir ok", "👎": "negativo nao curti", "👏": "palmas aplauso", "🙏": "obrigado por favor reza", "💪": "forca musculo",
    "👋": "tchau oi ola", "🤝": "acordo aperto de mao", "👀": "olhos olhando", "🙌": "maos para cima", "👌": "ok perfeito",
    "❤️": "coracao amor vermelho", "💔": "coracao partido", "🔥": "fogo quente", "✨": "brilho", "⭐": "estrela", "🎉": "festa parabens",
    "💯": "cem perfeito", "💋": "beijo", "🐶": "cachorro cao", "🐱": "gato", "🐵": "macaco", "🙈": "macaco nao ver", "🦄": "unicornio",
    "🍕": "pizza", "🍔": "hamburguer", "🍟": "batata frita", "☕": "cafe", "🍺": "cerveja", "🎂": "bolo aniversario", "🍫": "chocolate",
    "⚽": "futebol bola", "🏆": "trofeu campeao", "🎮": "videogame jogo", "🎧": "fone musica", "🚗": "carro", "✈️": "aviao viagem",
    "🏠": "casa", "☀️": "sol", "🌙": "lua", "🌈": "arco iris", "📱": "celular telefone", "💻": "computador notebook", "💰": "dinheiro",
    "🎁": "presente", "✅": "certo ok", "❌": "errado nao", "❓": "pergunta duvida", "❗": "atencao exclamacao", "⚠️": "aviso alerta",
    "🇧🇷": "brasil bandeira", "💩": "coco", "👻": "fantasma", "🤡": "palhaco", "💀": "caveira morto", "🤖": "robo"
  };
  const QUICK = ["❤️", "👍", "👎", "🎉", "😀"];

  function el(tag, cls, text) { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function recent() { try { return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]").slice(0, 28); } catch (e) { return []; } }
  function pushRecent(e) {
    try { localStorage.setItem(RECENT_KEY, JSON.stringify([e].concat(recent().filter((x) => x !== e)).slice(0, 28))); } catch (err) { /* sem storage */ }
  }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }

  function build(opts) {
    const onPick = opts.onPick, onBackspace = opts.onBackspace;
    const root = el("div", "cw-ep cw-ep-tg");
    const tabs = el("div", "cw-ep-tabs");
    const searchRow = el("div", "cw-ep-search");
    const q = el("input"); q.type = "search"; q.placeholder = "Buscar Emojis"; q.setAttribute("aria-label", "Buscar Emojis"); q.autocomplete = "off";
    searchRow.appendChild(q);
    const quick = el("div", "cw-ep-quick");
    QUICK.forEach((e) => { const b = el("button", "cw-ep-qbtn", e); b.type = "button"; b.setAttribute("aria-label", "Buscar " + e); b.addEventListener("click", () => { q.value = e; render(); }); quick.appendChild(b); });
    searchRow.appendChild(quick);
    const scroll = el("div", "cw-ep-scroll");
    const bottom = el("div", "cw-ep-bottom");
    const emojiTab = el("button", "cw-ep-bbtn on"); emojiTab.type = "button"; emojiTab.setAttribute("aria-label", "Emojis");
    emojiTab.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8.5 14c.9 1.3 2 2 3.5 2s2.6-.7 3.5-2M9 9.5h.01M15 9.5h.01"/></svg>';
    const back = el("button", "cw-ep-bbtn cw-ep-back"); back.type = "button"; back.setAttribute("aria-label", "Apagar");
    back.innerHTML = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5h10a2 2 0 012 2v10a2 2 0 01-2 2H9l-6-7 6-7z"/><path d="M12.5 10l4 4M16.5 10l-4 4"/></svg>';
    back.addEventListener("click", () => { if (onBackspace) onBackspace(); });
    bottom.appendChild(emojiTab); bottom.appendChild(el("span", "cw-ep-spacer")); bottom.appendChild(back);

    const sections = [["🕘", "Frequentemente Usado", () => recent()]].concat(SECTIONS.map((s) => [s[0], s[1], () => s[2].split(" ")]));
    const secEls = [];
    sections.forEach((s, i) => {
      const t = el("button", "cw-ep-tab", s[0]); t.type = "button"; t.setAttribute("aria-label", s[1]);
      t.addEventListener("click", () => { q.value = ""; render(); const target = secEls[i]; if (target) scroll.scrollTop = target.offsetTop; });
      tabs.appendChild(t);
    });
    function emojiBtn(e) {
      const b = el("button", "cw-ep-emoji", e); b.type = "button";
      b.addEventListener("click", () => { pushRecent(e); onPick(e); });
      return b;
    }
    function render() {
      scroll.replaceChildren(); secEls.length = 0;
      const term = norm(q.value.trim());
      if (term) {
        const seen = new Set(), found = [];
        SECTIONS.forEach((s) => s[2].split(" ").forEach((e) => {
          if (seen.has(e)) return;
          if (e === q.value.trim() || norm(KEYS[e]).includes(term) || norm(s[1]).includes(term)) { seen.add(e); found.push(e); }
        }));
        const g = el("div", "cw-ep-grid");
        if (!found.length) g.appendChild(el("p", "hint", "Nenhum emoji encontrado."));
        found.forEach((e) => g.appendChild(emojiBtn(e)));
        scroll.appendChild(g); return;
      }
      sections.forEach((s, i) => {
        const list = s[2]();
        if (i === 0 && !list.length) { secEls.push(null); return; }
        const box = el("div", "cw-ep-sec");
        box.appendChild(el("h4", "cw-ep-title", s[1]));
        const g = el("div", "cw-ep-grid");
        list.forEach((e) => g.appendChild(emojiBtn(e)));
        box.appendChild(g); scroll.appendChild(box); secEls.push(box);
      });
    }
    q.addEventListener("input", render);
    root.appendChild(tabs); root.appendChild(searchRow); root.appendChild(scroll); root.appendChild(bottom);
    render();
    return root;
  }
  window.DriqyEmojiPicker = { build: build, SECTIONS: SECTIONS };
})();
