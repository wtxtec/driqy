/*
 * Grade do Vortex (fotos/gifs/vídeos):
 * - layout em colunas montado por JS (2 no celular, 4 no PC) — cada peça
 *   nova vai sempre no fim de uma coluna (round-robin), então as peças já
 *   colocadas NUNCA mudam de posição quando a rolagem infinita acrescenta
 *   mais (era esse reflow que bagunçava tudo com CSS column-count);
 * - rolagem infinita: busca a próxima página na URL de data-more-url
 *   (/api/pictures/mais com os filtros da página, ou a de "Mais como este")
 *   quando o usuário chega perto do fim da grade e injeta as novas peças;
 * - vídeos só carregam a mídia (data-src -> src) quando a peça está perto da
 *   tela, e descarregam de novo quando ficam bem longe da tela — evita
 *   segurar dezenas de vídeos carregados ao mesmo tempo numa sessão longa
 *   de scroll;
 * - no máximo 1 vídeo toca por vez: ao entrar bastante na tela ele toca
 *   mudo sozinho (como uma prévia), e qualquer outro vídeo tocando é
 *   pausado antes disso — nunca dois rodando juntos.
 */
(function () {
  const grid = document.getElementById("vortex-grid");
  const sentinel = document.getElementById("vortex-sentinel");
  if (!grid || !sentinel) return;

  const scriptTag = document.currentScript;
  const moreUrl = scriptTag && scriptTag.dataset.moreUrl;

  // ---- aviso de pausa (Parte 5): tempo contínuo no Vortex ----
  // O servidor manda {minutes, level, suggest_break}; `level` sobe a cada 30 min.
  // Só reexibimos quando o nível sobe além do que a pessoa já dispensou.
  function breakDismissedLevel() {
    try { return parseInt(sessionStorage.getItem("vortexBreakDismissed") || "0", 10) || 0; }
    catch (e) { return 0; }
  }
  function showBreakNotice(minutes, level) {
    if (!level || level <= breakDismissedLevel()) return;
    let box = document.getElementById("vortex-break-notice");
    if (!box) {
      box = document.createElement("div");
      box.id = "vortex-break-notice";
      box.className = "vortex-break-notice";
      box.setAttribute("role", "status");
      box.innerHTML =
        '<span class="vortex-break-text"></span>' +
        '<button type="button" class="vortex-break-btn">Continuar</button>';
      document.body.appendChild(box);
      box.querySelector("button").addEventListener("click", () => {
        try { sessionStorage.setItem("vortexBreakDismissed", box.dataset.level || "0"); } catch (e) {}
        box.hidden = true;
      });
    }
    box.dataset.level = String(level);
    box.querySelector(".vortex-break-text").textContent =
      "Você está no Vortex há " + minutes + " minutos seguidos. Que tal uma pausa rápida?";
    box.hidden = false;
  }
  if (scriptTag) {
    showBreakNotice(parseInt(scriptTag.dataset.breakMinutes || "0", 10),
                    parseInt(scriptTag.dataset.breakLevel || "0", 10));
  }

  const spinnerEl = sentinel.querySelector(".vortex-sentinel-spinner");
  const endEl = sentinel.querySelector(".vortex-sentinel-end");

  // ---------- colunas (2 no celular, 4 no PC) ----------
  const desktopQuery = window.matchMedia("(min-width: 960px)");
  let columns = [];
  let colCount = 0;
  const allTiles = []; // ordem original de todas as peças (iniciais + infinitas)

  function targetColumnCount() {
    return desktopQuery.matches ? 4 : 2;
  }

  function buildColumns(n) {
    grid.innerHTML = "";
    columns = [];
    for (let i = 0; i < n; i++) {
      const col = document.createElement("div");
      col.className = "vortex-col";
      grid.appendChild(col);
      columns.push(col);
    }
    colCount = n;
  }

  // redistribui tudo do zero — só chamado quando o nº de colunas muda
  // (ex: girar o celular), nunca por causa de peças novas
  function redistributeAll() {
    buildColumns(targetColumnCount());
    allTiles.forEach((el, i) => columns[i % colCount].appendChild(el));
  }

  // acrescenta peças novas SEM mexer nas que já estão nas colunas
  function appendTiles(elements) {
    elements.forEach((el) => {
      const idx = allTiles.length;
      allTiles.push(el);
      columns[idx % colCount].appendChild(el);
    });
  }

  desktopQuery.addEventListener("change", redistributeAll);

  // ---------- vídeo: no máximo 1 tocando por vez ----------
  let currentlyPlaying = null;

  function pauseVideo(video) {
    if (!video || video.paused) return;
    video.pause();
  }

  function playVideo(video) {
    if (currentlyPlaying && currentlyPlaying !== video) {
      pauseVideo(currentlyPlaying);
    }
    currentlyPlaying = video;
    const p = video.play();
    if (p && p.catch) p.catch(() => {});
  }

  // carrega a fonte só quando a peça está perto da tela (evita disparar
  // dezenas de downloads de vídeo de uma vez ao rolar rápido)
  const loadObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        const video = entry.target;
        if (entry.isIntersecting) {
          if (!video.src && video.dataset.src) {
            video.src = video.dataset.src;
          }
        } else {
          // saiu bastante da tela: descarrega pra liberar memória/decoder
          if (video.src && video !== currentlyPlaying) {
            video.removeAttribute("src");
            video.load();
          }
        }
      });
    },
    { rootMargin: "1000px 0px" }
  );

  // toca (mudo) quando bem visível, pausa quando sai — e garante que só um
  // vídeo do grid toca por vez
  const playObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        const video = entry.target;
        if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
          if (video.src) playVideo(video);
        } else {
          pauseVideo(video);
          if (currentlyPlaying === video) currentlyPlaying = null;
        }
      });
    },
    { threshold: [0, 0.6, 1] }
  );

  function setupVideoTile(video) {
    if (!video || video.dataset.vortexReady) return;
    video.dataset.vortexReady = "1";
    loadObserver.observe(video);
    playObserver.observe(video);
  }

  // Pinterest: proporção (largura/altura) limitada a 0,48–1,78; fora disso a peça é cortada (cover).
  const PIN_MIN = 0.48, PIN_MAX = 1.78;
  function clampRatio(tile) {
    const link = tile.querySelector(".picture-tile-link");
    const media = tile.querySelector(".picture-tile-img");
    if (!link || !media || link.style.getPropertyValue("--ar")) return;
    const apply = () => {
      const w = media.naturalWidth || media.videoWidth, h = media.naturalHeight || media.videoHeight;
      if (!w || !h) return;
      const r = w / h;
      if (r < PIN_MIN || r > PIN_MAX) link.style.setProperty("--ar", String(Math.min(PIN_MAX, Math.max(PIN_MIN, r)).toFixed(4)));
    };
    if (media.tagName === "VIDEO") media.addEventListener("loadedmetadata", apply, { once: true });
    else if (media.complete) apply();
    else media.addEventListener("load", apply, { once: true });
  }

  // ---------- "o que eu já vi não volta": avisa o servidor das peças VISTAS ----------
  // Uma peça conta como vista quando fica >= 50 % visível por 700 ms. Vai em
  // lote (sendBeacon) pro livro de vistos (/api/pictures/seen). Só um sinal:
  // se falhar, ninguém precisa saber.
  const SEEN_URL = "/api/pictures/seen";
  const seenReported = new Set();
  const seenPending = new Set();
  const seenTimers = new Map();
  let seenFlushTimer = null;

  function flushSeen() {
    if (seenFlushTimer) { clearTimeout(seenFlushTimer); seenFlushTimer = null; }
    if (!seenPending.size) return;
    const keys = Array.from(seenPending).slice(0, 200);
    keys.forEach((k) => seenPending.delete(k));
    try {
      const body = new Blob([JSON.stringify({ keys })], { type: "application/json" });
      if (!navigator.sendBeacon(SEEN_URL, body)) throw new Error("beacon");
    } catch (_) {
      fetch(SEEN_URL, {
        method: "POST", keepalive: true,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keys }),
      }).catch(() => {});
    }
    if (seenPending.size) seenFlushTimer = setTimeout(flushSeen, 300);
  }

  function queueSeen(key) {
    if (!key || seenReported.has(key)) return;
    seenReported.add(key);
    seenPending.add(key);
    if (seenPending.size >= 8) flushSeen();
    else if (!seenFlushTimer) seenFlushTimer = setTimeout(flushSeen, 4000);
  }

  const seenObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        const el = entry.target;
        const key = el.dataset.vkey;
        if (!key || seenReported.has(key)) { seenObserver.unobserve(el); return; }
        if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
          if (!seenTimers.has(el)) {
            seenTimers.set(el, setTimeout(() => {
              seenTimers.delete(el);
              queueSeen(key);
              seenObserver.unobserve(el);
            }, 700));
          }
        } else if (seenTimers.has(el)) {
          clearTimeout(seenTimers.get(el));
          seenTimers.delete(el);
        }
      });
    },
    { threshold: [0, 0.5, 1] }
  );
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flushSeen();
  });
  window.addEventListener("pagehide", flushSeen);

  function setupNewTiles(elements) {
    elements.forEach((el) => {
      if (el.dataset && el.dataset.vkey) seenObserver.observe(el);
      if (el.matches(".picture-tile")) clampRatio(el);
      el.querySelectorAll(".picture-tile-video").forEach(setupVideoTile);
      if (el.matches(".picture-tile-video")) setupVideoTile(el);
      el.querySelectorAll(".post-card[data-expires]").forEach((card) => {
        if (window.driqyCountdown) window.driqyCountdown.registerCard(card);
      });
      if (el.matches(".post-card[data-expires]") && window.driqyCountdown) {
        window.driqyCountdown.registerCard(el);
      }
    });
  }

  // ---------- gosto: avisa o servidor quando a pessoa abre um post de usuário ----------
  // (abrir uma peça do crawler já é registrado pela própria página de detalhe).
  // sendBeacon sobrevive à navegação pra outra página; é só um sinal, se falhar
  // ninguém precisa saber.
  grid.addEventListener("click", (event) => {
    const link = event.target.closest("[data-vortex-post-id]");
    if (!link) return;
    const postId = parseInt(link.dataset.vortexPostId, 10);
    if (!postId) return;
    try {
      const body = new Blob([JSON.stringify({ kind: "open", post_id: postId })], {
        type: "application/json",
      });
      navigator.sendBeacon("/api/pictures/interact", body);
    } catch (_) {}
  });

  // ---------- gosto: Curtir / "Menos disso" direto na grade ----------
  // Curtir marca o coração; "Menos disso" some com a peça na hora (o servidor
  // também para de entregá-la: livro de vistos, 120 dias). Falha de rede é
  // silenciosa — é só um sinal.
  function reactionBody(tile, kind) {
    const key = (tile.dataset && tile.dataset.vkey) || "";
    const id = parseInt(key.slice(1), 10);
    if (!id) return null;
    const body = { kind: kind };
    if (key[0] === "c") body.item_id = id;
    else if (key[0] === "p") body.post_id = id;
    else return null;
    return body;
  }

  grid.addEventListener("click", (event) => {
    const btn = event.target.closest(".picture-tile-act");
    if (!btn) return;
    event.preventDefault();
    event.stopPropagation();
    const tile = btn.closest(".picture-tile");
    if (!tile) return;
    const kind = btn.dataset.kind;
    if (kind === "like" && tile.classList.contains("is-liked")) return;
    const body = reactionBody(tile, kind);
    if (!body) return;
    try {
      fetch("/api/pictures/interact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify(body),
        keepalive: true,
      }).catch(() => {});
    } catch (_) {}
    if (kind === "like") {
      tile.classList.add("is-liked");
      btn.setAttribute("aria-pressed", "true");
    } else if (kind === "less") {
      tile.classList.add("is-dismissed");
      tile.hidden = true;
      showUndoToast(tile);
    }
  });

  // "Desfazer" do "Menos disso": aviso por ~6 s; tocar devolve a peça e manda `undo_less`
  // (o servidor apaga o sinal negativo e tira a peça da lista de rejeitadas).
  let undoToast = null, undoTimer = null;
  function hideUndoToast() {
    if (undoTimer) { clearTimeout(undoTimer); undoTimer = null; }
    if (undoToast) { undoToast.remove(); undoToast = null; }
  }
  function showUndoToast(tile) {
    hideUndoToast();
    const box = document.createElement("div");
    box.className = "vortex-undo-toast";
    box.setAttribute("role", "status");
    const msg = document.createElement("span");
    msg.textContent = "Vamos mostrar menos coisas assim.";
    const undo = document.createElement("button");
    undo.type = "button";
    undo.textContent = "Desfazer";
    undo.addEventListener("click", () => {
      const body = reactionBody(tile, "undo_less");
      if (body) {
        try {
          fetch("/api/pictures/interact", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "same-origin",
            body: JSON.stringify(body),
            keepalive: true,
          }).catch(() => {});
        } catch (_) {}
      }
      tile.classList.remove("is-dismissed");
      tile.hidden = false;
      hideUndoToast();
    });
    box.append(msg, undo);
    document.body.appendChild(box);
    undoToast = box;
    undoTimer = setTimeout(hideUndoToast, 6000);
  }

  // ---------- carregamento inicial: adota as peças que vieram do servidor ----------
  const initialTiles = Array.from(grid.children);
  buildColumns(targetColumnCount());
  appendTiles(initialTiles);
  setupNewTiles(initialTiles);

  // ---------- rolagem infinita ----------
  let loading = false;

  function showState(state) {
    if (spinnerEl) spinnerEl.hidden = state !== "loading";
    if (endEl) endEl.hidden = state !== "end";
  }

  function loadMore() {
    const cursor = sentinel.dataset.nextCursor;
    if (loading || !cursor || !moreUrl) return;
    loading = true;

    // só mostra o "Carregando mais…" se a busca demorar de verdade —
    // como agora ela dispara bem antes do usuário chegar no fim (rootMargin
    // grande), na maioria das vezes a resposta já chega antes desse prazo
    // e o usuário nunca vê o spinner.
    const spinnerTimer = setTimeout(() => showState("loading"), 400);

    // ancorado no id do último post já mostrado (não em número de página)
    // — imune a posts expirando entre uma leva e outra, então nunca repete
    // nem pula peças quando o feed muda embaixo do usuário.
    // data-more-url já pode trazer filtros (?q=, ?categoria=, ?tipo=)
    const nextUrl = new URL(moreUrl, window.location.href);
    nextUrl.searchParams.set("cursor", cursor);

    fetch(nextUrl.toString(), {
      headers: { "X-Requested-With": "fetch" },
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(res)))
      .then((data) => {
        const wrapper = document.createElement("div");
        wrapper.innerHTML = (data.tiles || []).join("");
        const newTiles = Array.from(wrapper.children);
        appendTiles(newTiles);
        setupNewTiles(newTiles);
        if (data.wellbeing && data.wellbeing.suggest_break) {
          showBreakNotice(data.wellbeing.minutes, data.wellbeing.level);
        }

        if (data.has_next && data.next_cursor) {
          sentinel.dataset.nextCursor = data.next_cursor;
          showState("idle");
        } else {
          sentinel.dataset.nextCursor = "";
          showState("end");
        }
      })
      .catch(() => {
        showState("idle");
      })
      .finally(() => {
        clearTimeout(spinnerTimer);
        loading = false;
      });
  }

  // dispara a busca da próxima página bem antes do sentinel entrar na tela
  // (bem mais de uma altura de viewport) — dá tempo do fetch voltar antes
  // do usuário realmente chegar no fim visível da grade.
  const scrollObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) loadMore();
      });
    },
    { rootMargin: "1500px 0px" }
  );
  scrollObserver.observe(sentinel);
})();
