/*
 * Feed de Notícias: rolagem infinita.
 *
 * O mosaico (cards de tamanhos variados) antes precisava de um cálculo
 * em JS pra encaixar os tiles numa grid densa sem sobrar espaço vazio
 * (ver histórico no CSS). Isso foi trocado por uma grid cuja altura de
 * linha vem do próprio conteúdo (grid-auto-rows: auto) — então não tem
 * mais nada pra medir/recalcular aqui, só a paginação.
 */
(function () {
  const grid = document.getElementById("news-grid");
  const sentinel = document.getElementById("news-sentinel");
  if (!grid || !sentinel) return;

  const scriptTag = document.currentScript;
  const moreUrl = scriptTag && scriptTag.dataset.moreUrl;
  const categoria = sentinel.dataset.categoria || "";

  const spinnerEl = sentinel.querySelector(".vortex-sentinel-spinner");
  const endEl = sentinel.querySelector(".vortex-sentinel-end");

  let loading = false;

  function showState(state) {
    if (spinnerEl) spinnerEl.hidden = state !== "loading";
    if (endEl) endEl.hidden = state !== "end";
  }

  function loadMore() {
    const offset = sentinel.dataset.nextOffset;
    if (loading || !offset || !moreUrl) return;
    loading = true;

    // manda os ids já renderizados na tela pro back-end excluir do
    // próximo lote — sem isso, se a pontuação de alguma notícia mudasse
    // entre uma chamada e outra (novo clique, nova notícia indexada), a
    // rolagem infinita repetia notícia já mostrada ou pulava outra
    const vistos = Array.from(grid.querySelectorAll(".news-tile[data-article-id]"))
      .map((el) => el.dataset.articleId)
      .join(",");

    const spinnerTimer = setTimeout(() => showState("loading"), 400);
    const params = new URLSearchParams({ offset, vistos });
    if (categoria) params.set("categoria", categoria);

    fetch(`${moreUrl}?${params.toString()}`, {
      headers: { "X-Requested-With": "fetch" },
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(res)))
      .then((data) => {
        const wrapper = document.createElement("div");
        wrapper.innerHTML = (data.articles || []).join("");
        Array.from(wrapper.children).forEach((el) => grid.appendChild(el));

        if (data.has_next && data.next_offset) {
          sentinel.dataset.nextOffset = data.next_offset;
          showState("idle");
        } else {
          sentinel.dataset.nextOffset = "";
          showState("end");
        }
      })
      .catch(() => showState("idle"))
      .finally(() => {
        clearTimeout(spinnerTimer);
        loading = false;
      });
  }

  const scrollObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) loadMore();
      });
    },
    // margem grande: começa a buscar a próxima leva bem antes do
    // sentinela entrar na tela de verdade, pra rolagem rápida (ou cards
    // grandes, que enchem a tela com menos itens) nunca alcançar o fim
    // do que já foi carregado e mostrar "chegou ao fim" por engano
    { rootMargin: "3000px 0px" }
  );
  scrollObserver.observe(sentinel);
})();
