"""Rotas dos widgets do painel lateral (site e app). Registradas em `api_bp` (/api/v1).

Usam `chat_login_required`: aceitam token Bearer (Flutter) e a sessão do navegador (site);
são só GET, então não exigem o header X-Requested-With.
"""
from flask import jsonify, request

from api import api_bp, chat_login_required, current_api_user, serialize_user
from suggestions import suggest_users
import widgets_custom
import widgets_extra
from widgets_data import news_headlines, online_now, trending_posts, vortex_preview
import widgets_weather
from widgets_weather import parse_coords, place_label, search_places, weather_for_user

# Widgets prontos que o seletor pode mostrar. `client: True` = roda só no aparelho (sem rota).
# Os widgets criados pelo usuário (\"Minha área\") entram depois, com id `custom:<n>`.
WIDGETS = [
    {"id": "weather", "title": "Clima", "desc": "Tempo na sua cidade"},
    {"id": "trending", "title": "Em alta", "desc": "Posts mais comentados"},
    {"id": "news", "title": "Notícias", "desc": "Manchetes para você"},
    {"id": "vortex", "title": "Vortex", "desc": "Últimas peças do Vortex"},
    {"id": "online", "title": "Quem está online", "desc": "Pessoas ativas agora"},
    {"id": "clock", "title": "Relógio mundial", "desc": "Hora em outras cidades"},
    {"id": "calendar", "title": "Calendário", "desc": "O mês com feriados"},
    {"id": "moon", "title": "Fase da Lua", "desc": "Fase, nascer e pôr da Lua, eclipses e próximos marcos"},
    {"id": "seasons", "title": "Estações", "desc": "Progresso das 4 estações e aviso da virada"},
    {"id": "quotes", "title": "Cotações", "desc": "Dólar, euro e bitcoin"},
    {"id": "stats", "title": "Seu Driqy", "desc": "Seus números", },
    {"id": "expiring", "title": "Acabando", "desc": "Posts temporários prestes a sumir"},
    {"id": "phrase", "title": "Frase do dia", "desc": "Uma frase por dia"},
    {"id": "pomodoro", "title": "Foco", "desc": "Temporizador pomodoro", "client": True},
    {"id": "calc", "title": "Calculadora", "desc": "Contas rápidas", "client": True},
    {"id": "breathe", "title": "Respirar", "desc": "Respiração guiada de 1 minuto", "client": True},
]


def widgets_for(user):
    """Widgets prontos + os que o usuário criou (na ordem de criação)."""
    import widgets_custom
    return WIDGETS + [{k: v for k, v in widgets_custom.serialize(w).items() if k != "data"}
                      for w in widgets_custom.list_for_user(user)]


def normalize_prefs(raw, extra_ids=()):
    """Preferências do painel direito, sempre válidas (ids desconhecidos somem, os novos entram no fim).

    - rail_hidden: esconde o painel inteiro
    - order: ordem dos widgets do cartão de widgets
    - disabled: widgets que o usuário tirou
    - suggest: mostra o cartão "Sugestões para você"
    - suggest_first: cartão de sugestões acima do cartão de widgets
    """
    import json
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = {}
    raw = raw if isinstance(raw, dict) else {}
    known = [w["id"] for w in WIDGETS] + [i for i in extra_ids if i not in {w["id"] for w in WIDGETS}]
    order = []
    for wid in raw.get("order") if isinstance(raw.get("order"), list) else []:
        if wid in known and wid not in order:
            order.append(wid)
    order += [wid for wid in known if wid not in order]
    disabled = []
    for wid in raw.get("disabled") if isinstance(raw.get("disabled"), list) else []:
        if wid in known and wid not in disabled:
            disabled.append(wid)
    return {
        "rail_hidden": bool(raw.get("rail_hidden", False)),
        "order": order,
        "disabled": disabled,
        "suggest": bool(raw.get("suggest", True)),
        "suggest_first": bool(raw.get("suggest_first", False)),
    }


def prefs_for_user(user):
    import widgets_custom
    return normalize_prefs(getattr(user, "rail_prefs", None), widgets_custom.ids_for_user(user))


@api_bp.route("/widgets")
@chat_login_required
def widgets_list():
    """Lista os widgets na ordem escolhida pelo usuário, sem os que ele removeu."""
    user = current_api_user()
    prefs = prefs_for_user(user)
    everything = widgets_for(user)
    by_id = {w["id"]: w for w in everything}
    shown = [by_id[i] for i in prefs["order"] if i not in prefs["disabled"]]
    return jsonify({"widgets": shown, "all_widgets": everything, "prefs": prefs})


@api_bp.route("/widgets/prefs", methods=["GET"])
@chat_login_required
def widgets_prefs_get():
    user = current_api_user()
    return jsonify({"prefs": prefs_for_user(user), "widgets": widgets_for(user)})


@api_bp.route("/widgets/prefs", methods=["POST", "PUT"])
@chat_login_required
def widgets_prefs_save():
    """Corpo JSON com qualquer parte das preferências; o que faltar volta ao padrão."""
    import json
    import widgets_custom
    from extensions import db
    user = current_api_user()
    prefs = normalize_prefs(request.get_json(silent=True) or {}, widgets_custom.ids_for_user(user))
    user.rail_prefs = json.dumps(prefs)
    db.session.commit()
    return jsonify({"prefs": prefs, "widgets": widgets_for(user)})


def rail_context(user):
    """Dados para o template: preferências + lista de widgets (usado em base.html)."""
    from flask import current_app
    return {"prefs": prefs_for_user(user), "widgets": widgets_for(user),
            "max_custom": current_app.config.get("MAX_USER_WIDGETS", 12)}


@api_bp.route("/widgets/weather")
@chat_login_required
def widgets_weather():
    """`?lat=&lng=&name=` troca a região só para esta consulta (widget); sem eles usa o perfil."""
    override = None
    coords = parse_coords(request.args.get("lat"), request.args.get("lng"))
    if coords:
        name = (request.args.get("name") or "").strip()[:80] or "Região escolhida"
        override = (coords[0], coords[1], name)
    return jsonify(weather_for_user(current_api_user(), override))


@api_bp.route("/places/search")
@chat_login_required
def places_search():
    """Sugestões de cidade/estado/país: `?q=gramado` -> {"places": [{label, name, admin1, country,
    latitude, longitude, ...}]}. Usado no perfil (site e app) e no seletor de região do clima."""
    q = (request.args.get("q") or "").strip()
    return jsonify({"places": search_places(q, request.args.get("limit", 8, type=int))})


@api_bp.route("/widgets/trending")
@chat_login_required
def widgets_trending():
    return jsonify({"posts": trending_posts(current_api_user())})


@api_bp.route("/widgets/news")
@chat_login_required
def widgets_news():
    # limit (1..12, padrão 4): o cliente pede mais manchetes para repor as que o usuário dispensou
    limit = max(1, min(request.args.get("limit", 4, type=int) or 4, 12))
    return jsonify({"articles": news_headlines(current_api_user(), limit=limit)})


@api_bp.route("/widgets/vortex")
@chat_login_required
def widgets_vortex():
    return jsonify({"items": vortex_preview(current_api_user())})


@api_bp.route("/widgets/online")
@chat_login_required
def widgets_online():
    return jsonify(online_now(current_api_user()))


@api_bp.route("/widgets/suggestions")
@chat_login_required
def widgets_suggestions():
    """`?limit=` (1–20, padrão 5) e `?exclude=a,b` (usernames já mostrados/dispensados)."""
    viewer = current_api_user()
    limit = request.args.get("limit", 5, type=int)
    exclude = [x.strip() for x in (request.args.get("exclude") or "").split(",") if x.strip()][:50]
    out = []
    for s in suggest_users(viewer, limit=limit, exclude=exclude):
        item = serialize_user(s["user"], viewer)
        item.update({"reason": s["reason"], "mutuals": s["mutuals"], "follows_you": s["follows_you"]})
        out.append(item)
    return jsonify({"users": out})


# ---------------------------------------------------------------- widgets novos (Parte 1 da "Minha área")
@api_bp.route("/widgets/clock")
@chat_login_required
def widgets_clock():
    """`?zones=Asia/Tokyo,Europe/Paris` (ids da lista `available`); sem isso, 5 cidades padrão."""
    zones = [z.strip() for z in (request.args.get("zones") or "").split(",") if z.strip()]
    return jsonify(widgets_extra.world_clock(zones or None))


@api_bp.route("/widgets/calendar")
@chat_login_required
def widgets_calendar():
    """`?year=2026&month=11` (padrão: mês de hoje no horário de Brasília)."""
    # `tz` (nome IANA, site) ou `tz_offset` (minutos, app): o "hoje" é o do usuário, onde ele estiver
    _request_tzinfo(current_api_user())
    return jsonify(widgets_extra.month_calendar(request.args.get("year", type=int), request.args.get("month", type=int),
                                                tz=request.args.get("tz"), tz_offset=request.args.get("tz_offset", type=int),
                                                country=request.args.get("country")))


def _request_tzinfo(user=None):
    """Fuso do usuário a partir de `?tz=` (nome IANA, site) ou `?tz_offset=` (minutos, app); sem nenhum, Brasília
    (None). Quando vem um nome IANA válido e diferente do guardado, lembra em `User.tz_name` (os avisos de estação
    usam). Nunca derruba a resposta por causa disso."""
    tz = request.args.get("tz")
    info = widgets_extra.user_tzinfo(tz, request.args.get("tz_offset", type=int))
    name = getattr(info, "key", None)
    if user is not None and name and name == tz and getattr(user, "tz_name", None) != name:
        try:
            from extensions import db
            user.tz_name = name
            db.session.commit()
        except Exception:  # noqa: BLE001
            db.session.rollback()
    return info


@api_bp.route("/widgets/moon")
@chat_login_required
def widgets_moon():
    """Fase + nascer/pôr + eclipses. O local vem do perfil (coordenadas salvas ou cidade); sem local, Brasília."""
    user = current_api_user()
    lat = lng = place = None
    saved = parse_coords(getattr(user, "location_lat", None), getattr(user, "location_lng", None))
    text = (getattr(user, "location", "") or "").strip()
    if saved and text:
        lat, lng, place = saved[0], saved[1], text
    elif text:
        found = widgets_weather.resolve_coords(text)
        if found:
            lat, lng, place = found
    return jsonify(widgets_extra.moon_phase(lat=lat, lng=lng, place=place, tzinfo=_request_tzinfo(user)))


@api_bp.route("/widgets/seasons")
@chat_login_required
def widgets_seasons():
    """Estação atual, progresso e as 4 estações do ano (hemisfério pela localização do perfil)."""
    user = current_api_user()
    return jsonify(widgets_extra.season_info(lat=getattr(user, "location_lat", None), tzinfo=_request_tzinfo(user)))


@api_bp.route("/widgets/quotes")
@chat_login_required
def widgets_quotes():
    return jsonify(widgets_extra.get_quotes())


@api_bp.route("/widgets/stats")
@chat_login_required
def widgets_stats():
    return jsonify(widgets_extra.my_stats(current_api_user()))


@api_bp.route("/widgets/expiring")
@chat_login_required
def widgets_expiring():
    return jsonify({"posts": widgets_extra.expiring_posts(current_api_user())})


@api_bp.route("/widgets/phrase")
@chat_login_required
def widgets_phrase():
    return jsonify(widgets_extra.phrase_of_the_day())


# ---------------------------------------------------------------- Minha área (widgets do usuário)
def _custom_json_body():
    body = request.get_json(silent=True)
    return body if isinstance(body, dict) else {}


@api_bp.route("/widgets/custom", methods=["GET"])
@chat_login_required
def custom_list():
    from flask import current_app
    user = current_api_user()
    return jsonify({"widgets": [widgets_custom.serialize(w) for w in widgets_custom.list_for_user(user)],
                    "kinds": [{"kind": k, "title": v["title"], "desc": v["desc"]} for k, v in widgets_custom.KINDS.items()],
                    "max": current_app.config.get("MAX_USER_WIDGETS", 12)})


@api_bp.route("/widgets/custom", methods=["POST"])
@chat_login_required
def custom_create():
    body = _custom_json_body()
    try:
        w = widgets_custom.create(current_api_user(), body.get("kind"), body.get("title"), body.get("data"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"widget": widgets_custom.serialize(w)}), 201


@api_bp.route("/widgets/custom/<int:wid>", methods=["GET"])
@chat_login_required
def custom_get(wid):
    w = widgets_custom.get_for_user(current_api_user(), wid)
    if not w:
        return jsonify({"error": "Widget não encontrado."}), 404
    return jsonify({"widget": widgets_custom.serialize(w)})


@api_bp.route("/widgets/custom/<int:wid>", methods=["PUT", "PATCH"])
@chat_login_required
def custom_update(wid):
    w = widgets_custom.get_for_user(current_api_user(), wid)
    if not w:
        return jsonify({"error": "Widget não encontrado."}), 404
    body = _custom_json_body()
    try:
        widgets_custom.update(w, title=body.get("title") if "title" in body else None,
                              data=body.get("data") if "data" in body else None)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"widget": widgets_custom.serialize(w)})


@api_bp.route("/widgets/custom/<int:wid>", methods=["DELETE"])
@chat_login_required
def custom_delete(wid):
    from extensions import db
    user = current_api_user()
    w = widgets_custom.get_for_user(user, wid)
    if not w:
        return jsonify({"error": "Widget não encontrado."}), 404
    db.session.delete(w)
    db.session.commit()
    return jsonify({"ok": True})
