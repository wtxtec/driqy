# PROGRESSO — ÍNDICE GERAL (leia este primeiro)

> Igual nos dois projetos (`driqy4/` e `flutter_app/`). Verificação geral feita em **10/11/2026**: cada `PROGRESSO_*.md` foi relido, as pontas soltas entre site e app foram juntadas e o que estava desatualizado foi marcado (**[RESOLVIDO]**, **[SUPERADO]** ou riscado) em vez de apagado. Ao terminar qualquer parte, atualize este índice e o arquivo da série.

## Regras vigentes (do usuário)
- Uma parte por vez; ao fim, devolver os **DOIS zips completos** (projeto inteiro): `driqy4-web-v_0_0_N.zip` e `driqy-flutter_v_0_0_N.zip` (N sobe a cada entrega; última: **v_0_0_10**). Os nomes antigos (`..._faseN_X7`, `..._ping_faseN`, `..._widgets_parteN`) citados nos arquivos antigos não valem mais.
- Português do Brasil, respostas curtas, edições cirúrgicas, riscos antes de implementar; mudanças valem para site (desktop + celular) E Flutter.
- Qualquer mudança em `static/` sobe o cache do `sw.js` (hoje `driqy-shell-v63`); os testes só exigem versão `>=`.
- Nada de "Fase/Parte a fazer" ficou aberto nas séries abaixo (o plano de Layout foi esvaziado a pedido do usuário).

## Os arquivos
| Arquivo | Assunto | Estado |
|---|---|---|
| `PROGRESSO_CHAT.md` | Chat estilo WhatsApp/Telegram, 15 fases (backend, site, Flutter, chamadas, documentos) + correções e Notícias | 15/15 feitas; só restam as pendências herdadas (abaixo) |
| `PROGRESSO_PING.md` | Layout estilo Telegram (10 fases + extras: visualização única, Notícias v2). **Histórico**: o Ping voltou a se chamar "Mensagens" | 10/10 + extras feitos |
| `PROGRESSO_MENSAGENS.md` | Continuação do Ping: Mensagens, configurações, grupos (4 partes) | 4/4 feitas (grupos só texto) |
| `PROGRESSO_VORTEX.md` | GIFs, crawler, busca estilo Pinterest, admin, Vortex por gosto, conceitos, tema, Partes 1–9 (+ plano de 8 partes) | Tudo feito; Parte 9 junta backend/site (9A) e Flutter (9B) |
| `PROGRESSO_LAYOUT.md` | Menu em caixa, painel de widgets, Minha área, Peq-1..3, Rotas-1, painel só na Home | Tudo feito; regra vigente no topo do arquivo |
| `LEIA-ME-PROXIMOS-PASSOS.md` (só Flutter) | Diário das sessões 1–14 | **Histórico** desatualizado (aviso no topo) |

Outros `.md` (não são de progresso, não mudaram): `README.md`, `INSTRUCOES.md` (rodar no Windows), `COTURN.md` (TURN para chamadas), `BACKEND_FCM_FLASK.md` (app) / `PUSH_NOTIFICATIONS.md` (site) (push FCM), `CONFIGURAR_FIREBASE.md`, `CALENDARIO_GLOBAL.md`, `ESTACOES_E_LUA.md`, `FLASH.md`, `VORTEX_CRAWLER.md`; `ALERTAS_CLIMA.md` é só uma **proposta** (não implementada, ninguém pediu).

## O que foi corrigido nesta verificação
1. `PROGRESSO_CHAT.md` e `PROGRESSO_VORTEX.md` tinham versões **diferentes** no site e no app (cada lado só tinha o seu final). Agora são idênticos e completos nos dois (Chat: aviso duplicado + selo de verificado + Notícias; Vortex: Parte 9 = 9A + 9B).
2. Afirmações velhas marcadas: Mensagens dizia que tema claro e som não existiam no Flutter (existem); Vortex dizia que não havia "desfazer" e que o tema claro era só do Vortex (já resolvido); Layout falava em painel "nunca na aba Vortex" e rotas "sempre em tela cheia" (superado) e em pendências pequenas já resolvidas; Chat citava `sw.js` v22 e zips `X7`.
3. **Testes do site (corrigidos de verdade):** 15 testes antigos fixavam uma versão exata do cache do `sw.js` (`v57`/`v63`) e 11 arquivos falhavam desde que o `sw.js` passou de v57 (o próprio `PROGRESSO_LAYOUT.md` já avisava); agora checam `>=`. E `tests/test_ping_phase11.py` falhava **desde antes (também no v_0_0_8)**: ele tratava todo o CSS depois da "fase 11" como CSS do Ping e o CSS do painel de widgets foi acrescentado no fim do arquivo; agora o bloco termina onde começa o CSS do painel.
4. **Resultado:** `pytest` do site rodado arquivo por arquivo (a suíte inteira numa tacada trava no sandbox): **836 passaram, 3 skipped, 0 falharam** (70 arquivos; inclui `test_rail_home_only.py`).

## O que realmente continua aberto (consolidado; nada disto foi feito por falta de ambiente/pedido)
**Transversal (maior risco):**
- **Flutter nunca foi compilado** em nenhuma sessão (sem SDK): rodar `flutter pub get`, `flutter analyze`, `flutter test` e corrigir o que o compilador achar (as séries Chat 2–15, Ping, Mensagens, Vortex 4–9 e Layout 5A–Rotas-1 dependem disso). Dependências nativas novas no Chat: `emoji_picker_flutter`, `record`, `just_audio`, `flutter_webrtc`, `file_picker`, `path_provider`, `open_filex` (iOS pode precisar de `pod install`).
- **Nada foi visto num navegador ou aparelho reais** (visual, tema claro, janela larga, chamadas). Chamadas 4G exigem TURN (`COTURN.md`).
- Rede real nunca testada pela IA: Open-Meteo (clima), feeds de notícias (+28 fontes novas), adaptadores do crawler do Vortex, Wikimedia/Openverse.
**Chat (Fase 15 e herdadas):** CallKit/VoIP no iOS; foreground service no Android; upgrade voz→vídeo (renegociação); aviso de câmera desligada (DataChannel); Redis para vários workers (SSE/presença); bloqueio de usuário; E2E não existe (não prometer na UI); `since_id` para não rebuscar a conversa a cada evento; antivírus nos anexos (ClamAV); seleção múltipla de fotos/arquivos e busca de GIFs/figurinhas; push de reação; job diário de limpeza de mídia órfã vem desligado; Flutter não gera miniatura de vídeo; sem pré-visualização/progresso de documentos.
**Mensagens/Ping:** grupos só com texto (sem mídia nem ligação); seleção múltipla de mensagens; proporção real de imagem sem `media_width/height` (hoje 4:3); `FLAG_SECURE` no Android; Notícias v2 sem teste com feeds reais (matéria sem pista fica em "geral"); ideia: painel admin do banco de notícias.
**Vortex:** vocabulário de conceitos e limiares sem teste com dados reais; "Relacionados" e busca ainda não consultam o livro de vistos; sem perfil-robô no Flutter; contraste do tema claro e bolinhas ♥/✕ no celular não vistos.
**Layout (limites da Rotas-1/painel só na Home):** redimensionar a janela atravessando 901 dp perde a pilha do miolo (e a rolagem do feed pode zerar se o reaproveitamento da `GlobalKey` falhar); toque em notificação push abre em tela cheia (sem a caixa do menu); o sino da topbar em tela larga empilha outra tela de Notificações; o item do menu não fica destacado com Notícias/Perfil/Widgets aberto; `WillPopScope` não intercepta com o "voltar preditivo" do Android 14+; pontos de risco de compilação: `HeroControllerScope.none`, `WillPopScope` dentro do `ContentColumn`, `ValueListenableBuilder` na rota inicial.
