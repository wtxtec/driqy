import os
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SITE_NAME = "Driqy"

    SECRET_KEY = os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao")

    # sessão fica logada pelo maior tempo possível (usuários costumam
    # esquecer a senha) — 1 ano, renovado a cada requisição enquanto o
    # usuário estiver ativo.
    PERMANENT_SESSION_LIFETIME = timedelta(days=365)
    SESSION_REFRESH_EACH_REQUEST = True
    REMEMBER_COOKIE_DURATION = timedelta(days=365)
    REMEMBER_COOKIE_REFRESH_EACH_REQUEST = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'driqy.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # SQLite trava o banco inteiro numa escrita; sem isso, uma requisição
    # web escrevendo ao mesmo tempo que o scheduler de notícias já era
    # suficiente pra disparar "database is locked". connect_args timeout
    # faz o SQLite ESPERAR até 30s por um lock (em vez de falhar na hora);
    # o journal_mode=WAL (ativado em extensions.py) permite leitura e
    # escrita simultâneas na maioria dos casos.
    SQLALCHEMY_ENGINE_OPTIONS = {
        "connect_args": {"timeout": 30},
    }

    UPLOAD_FOLDER = os.path.join(BASE_DIR, "instance", "uploads")
    MAX_CONTENT_LENGTH = 60 * 1024 * 1024  # 60 MB por upload

    ALLOWED_IMAGE_EXT = {"png", "jpg", "jpeg", "webp"}
    ALLOWED_GIF_EXT = {"gif"}
    ALLOWED_VIDEO_EXT = {"mp4", "webm", "mov"}
    ALLOWED_AUDIO_EXT = {"webm", "ogg", "mp3", "wav", "m4a"}

    # chat: limites por tipo de mídia (bytes) — MAX_CONTENT_LENGTH continua o teto geral
    CHAT_MAX_IMAGE_BYTES = 15 * 1024 * 1024
    CHAT_MAX_AUDIO_BYTES = 20 * 1024 * 1024
    CHAT_MAX_VIDEO_BYTES = 55 * 1024 * 1024
    # "apagar para todos": só o remetente, até N segundos depois do envio (48 h)
    CHAT_DELETE_WINDOW_SECONDS = 48 * 3600
    # editar texto: só o remetente, até N segundos depois do envio (24 h)
    CHAT_EDIT_WINDOW_SECONDS = 24 * 3600
    # tempo real (Fase 9): SSE em /api/v1/messages/stream. Desligar = só polling.
    CHAT_SSE_ENABLED = True
    CHAT_SSE_KEEPALIVE_SECONDS = 15   # "ping" pra manter a conexão e notar quem saiu
    CHAT_SSE_MAX_PER_USER = 8         # conexões simultâneas por usuário (a mais antiga cai)
    # encaminhar: máximo de conversas de destino por pedido
    CHAT_FORWARD_MAX_TARGETS = 5
    # Visualização única: tempo que a mídia fica baixável depois de aberta (Range de vídeo/áudio
    # precisa de várias requisições) e validade de uma mensagem que ninguém abriu.
    CHAT_VIEW_ONCE_WINDOW_SECONDS = 10 * 60
    CHAT_VIEW_ONCE_TTL_SECONDS = 14 * 24 * 3600
    CHAT_MAX_PINNED = 3               # Fase 10: conversas fixadas por usuário
    GROUP_MAX_MEMBERS = 200           # Mensagens parte 3: pessoas por grupo
    CHAT_PRESENCE_GRACE_SECONDS = 5   # Fase 10: espera antes de declarar "offline" (F5 não pisca)
    CHAT_MAX_FILE_BYTES = 25 * 1024 * 1024
    # chamadas de voz/vídeo (Fase 11) — só sinalização; a mídia vai por WebRTC (P2P ou via TURN)
    CALL_ENABLED = True
    CALL_RING_SECONDS = 45            # tocando além disso -> "perdida"
    CALL_SDP_MAX_BYTES = 16 * 1024    # offer/answer maiores que isso -> 413
    CALL_ICE_MAX_BYTES = 2 * 1024     # um candidato ICE
    CALL_ICE_MAX_PER_CALL = 150       # por usuário e por chamada (limite de taxa)
    CALL_PING_SECONDS = 20            # o cliente deve dar ping neste intervalo
    CALL_STALE_SECONDS = 90           # chamada aceita sem ping/ICE por isso -> encerrada ("stale")
    # STUN público basta para testar; em produção use TURN (ver COTURN.md). Variáveis de ambiente:
    #   CALL_STUN_URLS="stun:a:3478,stun:b:3478"   CALL_TURN_URLS="turn:meu.host:3478?transport=udp,turns:meu.host:5349?transport=tcp"
    #   CALL_TURN_SECRET="..."  (coturn `use-auth-secret`: credencial temporária por usuário, recomendado)
    #   ou CALL_TURN_USERNAME / CALL_TURN_CREDENTIAL (credencial fixa)
    CALL_STUN_URLS = [u.strip() for u in os.environ.get(
        "CALL_STUN_URLS", "stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302").split(",") if u.strip()]
    CALL_TURN_URLS = [u.strip() for u in os.environ.get("CALL_TURN_URLS", "").split(",") if u.strip()]
    CALL_TURN_SECRET = os.environ.get("CALL_TURN_SECRET", "")
    CALL_TURN_USERNAME = os.environ.get("CALL_TURN_USERNAME", "")
    CALL_TURN_CREDENTIAL = os.environ.get("CALL_TURN_CREDENTIAL", "")
    CALL_TURN_TTL_SECONDS = 6 * 3600
    CHAT_ALLOWED_FILE_EXT = {"pdf", "txt", "zip", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "csv",
                             "rtf", "odt", "ods", "odp", "json", "heic", "heif"}
    # Fase 15: limpeza de mídia órfã (arquivo em instance/uploads/chat sem mensagem). Desligada por
    # padrão; o script cleanup_chat_media.py roda à mão. Ligue com CHAT_ORPHAN_CLEANUP_ENABLED=1.
    CHAT_ORPHAN_CLEANUP_ENABLED = os.environ.get("CHAT_ORPHAN_CLEANUP_ENABLED", "0") == "1"
    CHAT_ORPHAN_MIN_AGE_SECONDS = 6 * 3600

    # quantidade máxima de fotos/vídeos que podem ser publicados em um único post
    MAX_MEDIA_ITEMS = 10

    # duração dos posts, em minutos
    MIN_DURATION_MINUTES = 1
    MAX_DURATION_MINUTES = 60 * 24 * 365  # 1 ano

    # duraçoes pré-definidas mostradas no formulário (em minutos)
    DURATION_PRESETS = [
        (1, "1 minuto"),
        (5, "5 minutos"),
        (30, "30 minutos"),
        (60, "1 hora"),
        (360, "6 horas"),
        (1440, "1 dia"),
        (4320, "3 dias"),
        (10080, "1 semana"),
        (43200, "1 mês"),
        (129600, "3 meses"),
        (259200, "6 meses"),
        (525600, "1 ano"),
    ]

    POSTS_PER_PAGE = 15
    USERS_PER_PAGE = 20
    NOTIFICATIONS_PER_PAGE = 20
    # intervalo (segundos) em que o scheduler varre posts expirados
    CLEANUP_INTERVAL_SECONDS = 20

    # opções de cor de destaque para personalização de perfil
    # essa cor é a "marca" do usuário: aparece no nome, avatar padrão e
    # na borda de todos os posts dele
    ACCENT_COLORS = [
        ("amber", "#f2a93b"),
        ("rose", "#e85d75"),
        ("violet", "#9b7bd8"),
        ("teal", "#4fb6a8"),
        ("blue", "#5b9bd8"),
        ("lime", "#a3c95a"),
        ("coral", "#f2765c"),
        ("fuchsia", "#d858b8"),
        ("gold", "#d8b354"),
        ("sky", "#5ec8e0"),
        ("mint", "#5fd6a0"),
        ("slate", "#8f9bbf"),
    ]
    DEFAULT_ACCENT = "amber"

    # temas visuais disponíveis para o site (apenas claro e escuro)
    THEMES = [
        ("dark", "Escuro"),
        ("light", "Claro"),
    ]
    DEFAULT_THEME = "dark"

    # pesos usados para calcular a pontuação de ranking
    RANK_WEIGHT_LIKES = 2
    RANK_WEIGHT_COMMENTS = 1
    RANK_WEIGHT_FOLLOWERS = 3

    MAX_COMMENT_LENGTH = 300

    # ---------- E-mail (recuperação de senha) ----------
    # Configurado por variáveis de ambiente — nunca coloque usuário/senha de
    # e-mail direto no código. Exemplo pra Gmail: use uma "senha de app"
    # (não a senha normal da conta) em MAIL_PASSWORD.
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", 587))
    MAIL_USE_TLS = os.environ.get("MAIL_USE_TLS", "1") == "1"
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER", "") or MAIL_USERNAME

    # por quanto tempo (minutos) o link de redefinição de senha é válido
    PASSWORD_RESET_EXPIRES_MINUTES = 60

    # ---------- Login com Google ----------
    # Crie as credenciais em https://console.cloud.google.com/apis/credentials
    # (tipo "ID do cliente OAuth", aplicativo Web) e defina como variáveis de
    # ambiente. Enquanto não forem definidas, o botão "Entrar com Google"
    # fica automaticamente escondido.
    GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
    GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")

    # ---------- Notícias ----------
    # categorias exibidas nos filtros e na tela de "meus interesses"
    NEWS_CATEGORIES = [
        ("geral", "Geral"),
        ("politica", "Política"),
        ("economia", "Economia"),
        ("esportes", "Esportes"),
        ("tecnologia", "Tecnologia"),
        ("entretenimento", "Entretenimento"),
        ("saude", "Saúde"),
        ("ciencia", "Ciência"),
        ("mundo", "Mundo"),
    ]

    # classificador local, sem depender de nenhuma API externa: cada
    # categoria tem uma lista de palavras/frases características, e o
    # artigo cai na categoria cujas palavras mais aparecem no
    # título+resumo (ver news_classifier.py). Frases (com espaço) pesam
    # mais que palavras soltas por serem mais específicas.
    # entradas podem ser "palavra" (peso automático: frase=2, palavra=1)
    # ou ("palavra", peso) pra ajustar manualmente — usado abaixo em
    # palavras comuns demais pra decidir a categoria sozinhas (ex.:
    # "aplicativo", "internet", "estudo") ver news_classifier.py.
    NEWS_CATEGORY_KEYWORDS = {
        "politica": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "lula", "bolsonaro", "ministério público", "tse", "pec", "reforma ministerial", "oposição", "bancada", "stf decide", "alexandre de moraes", "lei sancionada", "vereador", "prefeitura", "pesquisa eleitoral", "candidato", "campanha eleitoral", "pf investiga", "operação da polícia federal",
            "governo", "congresso", "senado",
            "câmara dos deputados", "eleição", "eleições", "stf", "supremo tribunal",
            "prefeito", "governador", "deputado", "senador", "partido",
            "planalto", "política", "projeto de lei", ("votação", 0.5),
            # "presidente" e "ministro" foram rebaixadas pra peso fraco:
            # sozinhas elas classificavam qualquer notícia que citasse um
            # "presidente de clube/empresa/entidade" ou um "ministro" de
            # outro contexto (religioso, esportivo) como política. Só
            # contam de verdade quando reforçadas por outra palavra da
            # categoria (ex.: "presidente" + "congresso").
            ("presidente", 0.5), ("ministro", 0.5),
            # v2: mais termos de política que caíam em "geral"
            "deputada", "senadora", "vereadora", "governadora", "prefeita", "urna", "tribunal superior eleitoral",
            "emenda parlamentar", "medida provisória", "cpi", "impeachment", "coligação", "base aliada",
            "líder do governo", "esplanada", "palácio do planalto", "mandato", "plenário", "relator", "lira", "pacheco",
            "pt", "pl", "psdb", "mdb", "psol", "centrão", "ministério da fazenda", "casa civil", "eleitoral",
        ],
        "economia": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "tarifa", "exportações", "importações", "balança comercial", "petrobras", "copom", "bitcoin", "ações", "b3", "fundo de investimento", "renda fixa", "tesouro direto", "inss", "fgts", "aposentadoria", "preço do combustível", "gasolina", "mercado de trabalho", "ipca", "orçamento", "déficit", "arrecadação", "lucro", "empresa anuncia", "receita federal", "imposto de renda",
            "inflação", "juros", "selic", "pib", "dólar", "bolsa de valores",
            "ibovespa", "mercado financeiro", "economia", "imposto", "reforma tributária",
            "banco central", "desemprego", "salário mínimo", ("investimento", 0.5),
            # v2
            "mercado de capitais", "ações da", "resultado do trimestre", "balanço", "fusão", "ipo", "commodities",
            "petróleo", "minério", "agronegócio", "safra", "pib do brasil", "taxa de juros", "cdi", "poupança",
            "consumidor", "varejo", "indústria", "emprego", "carteira assinada", "caged", "dívida pública", "fiscal",
            "arcabouço fiscal", "ministro da fazenda", "haddad", "copom", "real desvaloriza", "cotação", "fundos imobiliários",
        ],
        "esportes": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "gols", "rodada", "técnico do", "partida", "copa do brasil", "sul-americana", "champions league", "premier league", "la liga", "neymar", ("vasco", 0.5), ("botafogo", 0.5), ("santos", 0.5), ("cruzeiro", 0.5), "atlético-mg", "internacional vence", ("fluminense", 0.5), ("bahia", 0.5), ("fortaleza", 0.5), "nba", "tênis", "natação", "ufc", "mma", "jogos olímpicos", "paralimpíadas", "melhor do mundo", "transferência", "contratação", "escalação", "árbitro", "var",
            "futebol", "campeonato", "gol", "jogador", "seleção brasileira",
            "libertadores", "brasileirão", "copa do mundo", "olimpíada", "atleta",
            "vôlei", "basquete", "fórmula 1", "flamengo", "corinthians", "palmeiras",
            "são paulo fc", "grêmio",
            # "técnico" sozinha pegava "técnico de informática", "técnico
            # eleitoral" etc. e jogava a notícia pra esportes à toa.
            ("técnico", 0.5),
            # v2
            "brasileirão série a", "série b", "campeonato brasileiro", "copa libertadores", "estadual", "rebaixamento",
            "artilheiro", "zagueiro", "goleiro", "atacante", "meia", "lateral", "treinador", "estádio", "torcida",
            "pênalti", "cartão vermelho", "gp de", "grande prêmio", "lewis hamilton", "verstappen", "nba finals", "nfl",
            "wimbledon", "roland garros", "us open", "surfe", "judô", "atletismo", "ginástica", "jogos pan-americanos",
            "mundial de clubes", "jogo de ida", "jogo de volta", "classificação do", "tabela do campeonato", "ancelotti",
        ],
        "tecnologia": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "inteligência artificial", "ia generativa", "openai", "gemini", "claude", "nvidia", "samsung", "iphone", "android", "ios", "windows", "linux", "gadget", "notebook", "processador", "videogame", "playstation", "xbox", "nintendo", "cibersegurança", "vazamento de dados", "golpe digital", "pix golpe", "big tech", "redes sociais", "x (twitter)", "bluesky", "streaming de jogos", "software", "aplicativos", "bateria",
            # "meta" foi removida: é uma palavra comum do português
            # ("bater a meta", "meta do jogador") e estava classificando
            # como tecnologia qualquer notícia que citasse a palavra à
            # toa — inclusive notícias de crime/esporte sem nada a ver
            # com tecnologia.
            "inteligência artificial", "smartphone", "tecnologia",
            "startup", "hacker", "ciberataque", "google",
            "apple", "microsoft", "chatgpt", "criptomoeda", "whatsapp",
            "instagram", "facebook", "tiktok",
            ("aplicativo", 0.5), ("internet", 0.5), ("robô", 0.5), ("5g", 0.5),
            # v2
            "inteligência artificial", "machine learning", "modelo de linguagem", "gpt", "deepseek", "anthropic",
            "meta ai", "tesla", "spacex", "starlink", "chip", "semicondutor", "placa de vídeo", "gpu", "cpu",
            "atualização do", "lançamento do", "galaxy", "pixel", "macbook", "ipad", "app", "navegador", "chrome",
            "computação em nuvem", "data center", "phishing", "malware", "ransomware", "senha", "privacidade",
            "e-sports", "esports", "steam", "epic games", "gta 6", "drone", "realidade virtual", "carro elétrico",
        ],
        "entretenimento": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "estreia", "série da netflix", "disney+", "hbo max", "prime video", "show de", "turnê", "álbum", "clipe", "cantor", "banda", "rock in rio", "lollapalooza", "oscar", "grammy", "globo de ouro", "bbb 26", "a fazenda", "novela das nove", "elenco", "trailer", "bilheteria", "teatro", "livro", "artista", "famosos", "gshow", "sertanejo", "funk", "rapper",
            "filme", "novela", "cantor", "cantora", "música",
            "celebridade", "famoso", "netflix", "ator", "atriz", "festival",
            "bbb", "reality show", "cinema", ("show", 0.5),
            # "série" sozinha pegava "série de assaltos/crimes", "série
            # histórica de dados" etc. Só conta reforçada por outra palavra
            # da categoria (ex.: junto com "netflix", "temporada"...).
            ("série", 0.5),
            # v2
            "temporada", "episódio", "documentário", "diretor", "roteiro", "protagonista", "filmagens", "show no",
            "ingressos", "festival de", "lança single", "nova música", "podcast", "youtuber", "influenciador",
            "casamento de", "separação de", "affair", "paparazzi", "tapete vermelho", "cannes", "emmy", "bafta",
            "programa de tv", "apresentador", "jurado", "participante", "eliminado", "paredão", "marvel", "star wars",
        ],
        "saude": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "anvisa", "câncer", "diabetes", "hipertensão", "obesidade", "dengue", "gripe", "influenza", "sarampo", "vacinação", "sintomas", "nutrição", "dieta", "sono", "saúde mental", "depressão", "ansiedade", "cirurgia", "remédio", "medicamento", "ozempic", "tratamento contra", "exame", "pacientes", "ubs", "upa",
            "saúde", "vacina", "doença", "covid", "sus",
            "epidemia", "surto", "ministério da saúde", "unidade de saúde",
            "posto de saúde", "secretaria de saúde", ("tratamento", 0.5),
            # "hospital" e "médico" sozinhas classificavam como saúde
            # qualquer notícia (crime, acidente, política) que só mencionasse
            # de passagem que a vítima "foi levada ao hospital" ou que um
            # "médico legista" avaliou o caso — sem a matéria ser sobre
            # saúde de verdade.
            ("hospital", 0.5), ("médico", 0.5),
            # v2
            "vacinação", "campanha de vacinação", "internações", "sus", "plano de saúde", "anvisa aprova", "alzheimer",
            "avc", "infarto", "colesterol", "saúde pública", "nutricionista", "alimentação saudável", "emagrecimento",
            "tireoide", "antibiótico", "transplante", "uti", "leitos", "epidemiologia", "chikungunya", "zika", "febre amarela",
            "mpox", "hiv", "cuidados com", "sintoma", "diagnóstico", "fisioterapia", "saúde da mulher", "gravidez", "autismo",
        ],
        "ciencia": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "pesquisadores", "estudo publicado", "cientista", "descoberta científica", "espécie", "dinossauro", "fóssil", "telescópio", "james webb", "estação espacial", "foguete", "lua", "marte", "asteroide", "eclipse", "cometa", "genética", "dna", "fisica", "física", "química", "biologia", "oceano", "geleira", "extinção", "evolução", "inpe", "fapesp", "cnpq",
            "cientistas", "nasa", "meio ambiente",
            "mudança climática", "aquecimento global", "buraco negro",
            "sistema solar", "astronomia", "arqueologia", "biodiversidade",
            "desmatamento", ("pesquisa", 0.5), ("estudo", 0.5),
            ("descoberta", 0.5),
            # "universidade", "espaço", "clima" e "amazônia" sozinhas eram
            # a maior fonte de erro: "universidade" aparece em qualquer
            # notícia (inclusive de crime) que só cita o local; "espaço" e
            # "clima" são usadas o tempo todo em sentido figurado ("dar
            # espaço", "clima tenso", "clima de campanha"), sem relação
            # nenhuma com ciência; "amazônia" aparece tanto em notícia
            # ambiental quanto em política/economia sobre a região.
            ("universidade", 0.5), ("espaço", 0.5), ("clima", 0.5),
            ("amazônia", 0.5),
            # v2
            "astrônomos", "exoplaneta", "galáxia", "supernova", "nasa", "esa", "missão espacial", "paleontologia",
            "físicos", "neurociência", "cérebro", "fusão nuclear", "energia solar", "sustentabilidade", "ecossistema",
            "fauna", "flora", "coral", "geologia", "vulcão", "clima extremo", "el niño", "la niña", "emissões de carbono",
            "cop30", "cop 30", "revista nature", "revista science", "artigo científico", "laboratório", "experimento",
        ],
        "mundo": [
            # amplia a cobertura do classificador (mais notícias caem na
            # categoria certa em vez de "geral")
            "trump", "biden", "casa branca", "putin", "zelensky", "gaza", "hamas", "irã", "coreia do norte", "japão", "índia", "argentina", "milei", "venezuela", "maduro", "méxico", "canadá", "reino unido", "frança", "alemanha", "união europeia", "otan", "papa", "terremoto", "furacão", "tufão", "tsunami", "atentado", "cessar-fogo", "refugiados", "cúpula",
            "eua", "estados unidos", "china", "europa", "guerra", "rússia",
            "ucrânia", "onu", "israel", "oriente médio",
            # "internacional" sozinha pegava "voo internacional", o time de
            # futebol Internacional, "comércio internacional" etc.
            ("internacional", 0.5),
            # v2
            "kremlin", "parlamento europeu", "pequim", "xi jinping", "taiwan", "cisjordânia", "líbano", "síria", "iêmen",
            "londres", "paris", "washington", "nova york", "moscou", "kiev", "tel aviv", "buenos aires", "lisboa", "madri",
            "primeiro-ministro", "chanceler", "embaixada", "sanções", "fronteira", "imigrantes", "tarifaço", "otan", "brics", "g20",
            "eleições nos eua", "partido democrata", "partido republicano", "congresso americano", "reino unido", "vaticano", "papa leão",
        ],
    }

    # feeds RSS de veículos brasileiros indexados automaticamente. Pode
    # editar/adicionar sem tocar em código — a lista é só usada pra
    # popular a tabela news_sources na primeira vez que o app sobe
    # (ver news_indexer.seed_default_sources).
    NEWS_DEFAULT_SOURCES = [
        # ---- generalistas (sem categoria fixa: passam pelo classificador) ----
        ("G1", "https://g1.globo.com/rss/g1/", None),
        ("Folha de S.Paulo", "https://feeds.folha.uol.com.br/emcimadahora/rss091.xml", None),
        ("UOL Notícias", "https://rss.uol.com.br/feed/noticias.xml", None),
        ("CNN Brasil", "https://www.cnnbrasil.com.br/feed/", None),
        ("Agência Brasil", "https://agenciabrasil.ebc.com.br/rss.xml", None),
        ("Agência Brasil - Últimas", "https://agenciabrasil.ebc.com.br/rss/ultimasnoticias/feed.xml", None),
        ("Metrópoles", "https://www.metropoles.com/feed", None),
        ("G1 - Brasil", "https://g1.globo.com/rss/g1/brasil/", "geral"),
        ("Folha - Cotidiano", "https://feeds.folha.uol.com.br/cotidiano/rss091.xml", "geral"),
        ("O Globo", "https://oglobo.globo.com/rss.xml", None),
        ("Estadão", "https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/brasil/", None),
        ("Jovem Pan", "https://jovempan.com.br/feed", None),
        ("R7", "https://www.r7.com/arc/outboundfeeds/rss/?outputType=xml", None),
        ("Veja", "https://veja.abril.com.br/feed/", None),
        ("CartaCapital", "https://www.cartacapital.com.br/feed/", None),
        ("Gazeta do Povo", "https://www.gazetadopovo.com.br/feed/", None),
        ("Brasil de Fato", "https://www.brasildefato.com.br/rss2.xml", None),
        ("The Intercept Brasil", "https://www.intercept.com.br/feed/", None),
        # ---- política ----
        ("G1 - Política", "https://g1.globo.com/rss/g1/politica/", "politica"),
        ("Folha - Poder", "https://feeds.folha.uol.com.br/poder/rss091.xml", "politica"),
        ("CNN Brasil - Política", "https://www.cnnbrasil.com.br/politica/feed/", "politica"),
        ("Agência Brasil - Política", "https://agenciabrasil.ebc.com.br/rss/politica/feed.xml", "politica"),
        ("Poder360", "https://www.poder360.com.br/feed/", "politica"),
        ("Agência Câmara", "https://www.camara.leg.br/noticias/rss/ultimas-noticias", "politica"),
        ("Agência Senado", "https://www12.senado.leg.br/noticias/rss", "politica"),
        # ---- economia ----
        ("G1 - Economia", "https://g1.globo.com/rss/g1/economia/", "economia"),
        ("CNN Brasil - Economia", "https://www.cnnbrasil.com.br/economia/feed/", "economia"),
        ("Folha - Mercado", "https://feeds.folha.uol.com.br/mercado/rss091.xml", "economia"),
        ("UOL Economia", "https://rss.uol.com.br/feed/economia.xml", "economia"),
        ("Agência Brasil - Economia", "https://agenciabrasil.ebc.com.br/rss/economia/feed.xml", "economia"),
        ("InfoMoney", "https://www.infomoney.com.br/feed/", "economia"),
        ("Exame", "https://exame.com/feed/", "economia"),
        ("Valor Econômico", "https://pox.globo.com/rss/valor", "economia"),
        ("Money Times", "https://www.moneytimes.com.br/feed/", "economia"),
        ("Seu Dinheiro", "https://www.seudinheiro.com/feed/", "economia"),
        ("Brazil Journal", "https://braziljournal.com/feed/", "economia"),
        # ---- esportes ----
        ("CNN Brasil - Esportes", "https://www.cnnbrasil.com.br/esportes/feed/", "esportes"),
        ("ESPN Brasil", "https://www.espn.com.br/rss/futebol/news", "esportes"),
        ("ESPN Brasil - Geral", "https://www.espn.com.br/espn/rss/news", "esportes"),
        ("ge (Globo Esporte)", "https://ge.globo.com/rss/ge/", "esportes"),
        ("Folha - Esporte", "https://feeds.folha.uol.com.br/esporte/rss091.xml", "esportes"),
        ("UOL Esporte", "https://rss.uol.com.br/feed/esporte.xml", "esportes"),
        ("Agência Brasil - Esportes", "https://agenciabrasil.ebc.com.br/rss/esportes/feed.xml", "esportes"),
        ("Gazeta Esportiva", "https://www.gazetaesportiva.com/feed/", "esportes"),
        ("Trivela", "https://trivela.com.br/feed/", "esportes"),
        ("Placar", "https://placar.abril.com.br/feed/", "esportes"),
        # ---- tecnologia ----
        ("G1 - Tecnologia", "https://g1.globo.com/rss/g1/tecnologia/", "tecnologia"),
        ("CNN Brasil - Tecnologia", "https://www.cnnbrasil.com.br/tecnologia/feed/", "tecnologia"),
        ("Tecmundo", "https://www.tecmundo.com.br/rss", "tecnologia"),
        ("Canaltech", "https://canaltech.com.br/rss/", "tecnologia"),
        ("Olhar Digital", "https://olhardigital.com.br/feed/", "tecnologia"),
        ("Tecnoblog", "https://tecnoblog.net/feed/", "tecnologia"),
        ("Folha - Tec", "https://feeds.folha.uol.com.br/tec/rss091.xml", "tecnologia"),
        ("UOL Tecnologia", "https://rss.uol.com.br/feed/tecnologia.xml", "tecnologia"),
        ("Adrenaline", "https://adrenaline.com.br/feed/", "tecnologia"),
        ("Showmetech", "https://www.showmetech.com.br/feed/", "tecnologia"),
        ("Meio Bit", "https://meiobit.com/feed/", "tecnologia"),
        # ---- entretenimento ----
        ("CNN Brasil - Entretenimento", "https://www.cnnbrasil.com.br/entretenimento/feed/", "entretenimento"),
        ("G1 - Pop & Arte", "https://g1.globo.com/rss/g1/pop-arte/", "entretenimento"),
        ("Folha - Ilustrada", "https://feeds.folha.uol.com.br/ilustrada/rss091.xml", "entretenimento"),
        ("Omelete", "https://www.omelete.com.br/rss", "entretenimento"),
        ("Jovem Nerd", "https://jovemnerd.com.br/feed/", "entretenimento"),
        ("Rolling Stone Brasil", "https://rollingstone.uol.com.br/feed/", "entretenimento"),
        ("Papelpop", "https://www.papelpop.com/feed/", "entretenimento"),
        # ---- saúde ----
        # G1 Ciência e Saúde mistura os dois assuntos: padrão = saúde, mas
        # matérias de ciência são realocadas (ver NEWS_MIXED_SOURCE_CATEGORIES)
        ("G1 - Ciência e Saúde", "https://g1.globo.com/rss/g1/ciencia-e-saude/", "saude"),
        ("CNN Brasil - Saúde", "https://www.cnnbrasil.com.br/saude/feed/", "saude"),
        ("Folha - Saúde", "https://feeds.folha.uol.com.br/saude/rss091.xml", "saude"),
        ("Agência Brasil - Saúde", "https://agenciabrasil.ebc.com.br/rss/saude/feed.xml", "saude"),
        ("Drauzio Varella", "https://drauziovarella.uol.com.br/feed/", "saude"),
        ("Veja Saúde", "https://saude.abril.com.br/feed/", "saude"),
        # ---- ciência ----
        ("G1 - Natureza", "https://g1.globo.com/rss/g1/natureza/", "ciencia"),
        ("Folha - Ciência", "https://feeds.folha.uol.com.br/ciencia/rss091.xml", "ciencia"),
        ("Superinteressante", "https://super.abril.com.br/feed/", "ciencia"),
        ("Revista Pesquisa FAPESP", "https://revistapesquisa.fapesp.br/feed/", "ciencia"),
        ("Jornal da USP", "https://jornal.usp.br/feed/", "ciencia"),
        ("Ciência Hoje", "https://cienciahoje.org.br/feed/", "ciencia"),
        ("Space Today", "https://spacetoday.com.br/feed/", "ciencia"),
        # ---- mundo ----
        ("G1 - Mundo", "https://g1.globo.com/rss/g1/mundo/", "mundo"),
        ("Folha - Mundo", "https://feeds.folha.uol.com.br/mundo/rss091.xml", "mundo"),
        ("CNN Brasil - Internacional", "https://www.cnnbrasil.com.br/internacional/feed/", "mundo"),
        ("BBC News Brasil", "https://feeds.bbci.co.uk/portuguese/rss.xml", "mundo"),
        ("DW Brasil", "https://rss.dw.com/rdf/rss-br-all", "mundo"),
        ("Agência Brasil - Internacional", "https://agenciabrasil.ebc.com.br/rss/internacional/feed.xml", "mundo"),
        ("France 24 Português", "https://www.france24.com/pt/rss", "mundo"),
        ("RFI Brasil", "https://www.rfi.fr/br/rss", "mundo"),
        ("ONU News", "https://news.un.org/feed/subscribe/pt/news/all/rss.xml", "mundo"),
        # ---- mais fontes (Parte "mais fontes"): regionais G1, justiça, ciência/ambiente, etc. ----
        ("Nexo Jornal", "https://www.nexojornal.com.br/rss.xml", None),
        ("Congresso em Foco", "https://congressoemfoco.uol.com.br/feed/", "politica"),
        ("JOTA", "https://www.jota.info/feed", "politica"),
        ("Conjur", "https://www.conjur.com.br/rss.xml", "politica"),
        ("Estadão - Política", "https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/politica/", "politica"),
        ("Agência Brasil - Justiça", "https://agenciabrasil.ebc.com.br/rss/justica/feed.xml", "politica"),
        ("Agência Brasil - Geral", "https://agenciabrasil.ebc.com.br/rss/geral/feed.xml", "geral"),
        ("Agência Brasil - Educação", "https://agenciabrasil.ebc.com.br/rss/educacao/feed.xml", "geral"),
        ("Agência Brasil - Direitos Humanos", "https://agenciabrasil.ebc.com.br/rss/direitos-humanos/feed.xml", "geral"),
        ("Revista Fórum", "https://revistaforum.com.br/feed/", None),
        ("Mídia Ninja", "https://midianinja.org/feed/", None),
        ("O Antagonista", "https://oantagonista.com.br/feed/", None),
        ("Crusoé", "https://crusoe.com.br/feed/", None),
        ("IstoÉ", "https://istoe.com.br/feed/", None),
        ("Agência Pública", "https://apublica.org/feed/", None),
        ("piauí", "https://piaui.folha.uol.com.br/feed/", None),
        ("Aos Fatos", "https://www.aosfatos.org/noticias/feed/", None),
        ("G1 - São Paulo", "https://g1.globo.com/rss/g1/sp/sao-paulo/", "geral"),
        ("G1 - Rio de Janeiro", "https://g1.globo.com/rss/g1/rj/rio-de-janeiro/", "geral"),
        ("G1 - Minas Gerais", "https://g1.globo.com/rss/g1/mg/minas-gerais/", "geral"),
        ("G1 - Espírito Santo", "https://g1.globo.com/rss/g1/es/espirito-santo/", "geral"),
        ("G1 - Rio Grande do Sul", "https://g1.globo.com/rss/g1/rs/rio-grande-do-sul/", "geral"),
        ("G1 - Paraná", "https://g1.globo.com/rss/g1/pr/parana/", "geral"),
        ("G1 - Santa Catarina", "https://g1.globo.com/rss/g1/sc/santa-catarina/", "geral"),
        ("G1 - Bahia", "https://g1.globo.com/rss/g1/ba/bahia/", "geral"),
        ("G1 - Pernambuco", "https://g1.globo.com/rss/g1/pe/pernambuco/", "geral"),
        ("G1 - Ceará", "https://g1.globo.com/rss/g1/ce/ceara/", "geral"),
        ("G1 - Distrito Federal", "https://g1.globo.com/rss/g1/df/distrito-federal/", "geral"),
        ("G1 - Goiás", "https://g1.globo.com/rss/g1/go/goias/", "geral"),
        ("G1 - Pará", "https://g1.globo.com/rss/g1/pa/para/", "geral"),
        ("G1 - Amazonas", "https://g1.globo.com/rss/g1/am/amazonas/", "geral"),
        ("Estadão - Economia", "https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/economia/", "economia"),
        ("InvestNews", "https://investnews.com.br/feed/", "economia"),
        ("Suno Notícias", "https://www.suno.com.br/noticias/feed/", "economia"),
        ("Bloomberg Línea Brasil", "https://www.bloomberglinea.com.br/arc/outboundfeeds/rss/?outputType=xml", "economia"),
        ("Lance!", "https://www.lance.com.br/rss.xml", "esportes"),
        ("Torcedores", "https://www.torcedores.com/feed", "esportes"),
        ("Grande Prêmio", "https://grandepremio.uol.com.br/feed/", "esportes"),
        ("Estadão - Esportes", "https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/esportes/", "esportes"),
        ("TechTudo", "https://www.techtudo.com.br/rss/techtudo/", "tecnologia"),
        ("Gizmodo Brasil", "https://gizmodo.uol.com.br/feed/", "tecnologia"),
        ("MacMagazine", "https://macmagazine.com.br/feed/", "tecnologia"),
        ("The Hack", "https://thehack.com.br/feed/", "tecnologia"),
        ("Mundo Conectado", "https://mundoconectado.com.br/feed/", "tecnologia"),
        ("Startups", "https://startups.com.br/feed/", "tecnologia"),
        ("Quem", "https://revistaquem.globo.com/rss/quem/", "entretenimento"),
        ("Observatório da TV", "https://observatoriodatv.uol.com.br/feed", "entretenimento"),
        ("AdoroCinema", "https://www.adorocinema.com/rss/noticias.xml", "entretenimento"),
        ("Legião dos Heróis", "https://www.legiaodosherois.com.br/feed", "entretenimento"),
        ("IGN Brasil", "https://br.ign.com/feed.xml", "entretenimento"),
        ("Agência Brasil - Cultura", "https://agenciabrasil.ebc.com.br/rss/cultura/feed.xml", "entretenimento"),
        ("Agência Fiocruz", "https://agencia.fiocruz.br/rss.xml", "saude"),
        ("Estadão - Saúde", "https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/saude/", "saude"),
        ("Galileu", "https://revistagalileu.globo.com/rss/revista-galileu/", "ciencia"),
        ("Agência FAPESP", "https://agencia.fapesp.br/rss/", "ciencia"),
        ("Inovação Tecnológica", "https://www.inovacaotecnologica.com.br/boletim/rss.xml", "ciencia"),
        ("Agência Brasil - Pesquisa e Inovação", "https://agenciabrasil.ebc.com.br/rss/pesquisa-e-inovacao/feed.xml", "ciencia"),
        ("Observatório do Clima", "https://oc.eco.br/feed/", "ciencia"),
        ("((o))eco", "https://oeco.org.br/feed/", "ciencia"),
        ("Mongabay Brasil", "https://brasil.mongabay.com/feed/", "ciencia"),
        ("Euronews Português", "https://pt.euronews.com/rss", "mundo"),
        ("Opera Mundi", "https://operamundi.uol.com.br/feed/", "mundo"),
        ("RTP Notícias", "https://www.rtp.pt/noticias/rss", "mundo"),
        ("Estadão - Internacional", "https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/internacional/", "mundo"),
    ]

    # fontes "mistas": o veículo agrupa dois assuntos no mesmo feed, então a
    # categoria padrão da fonte só vale se o classificador não achar uma das
    # categorias extras listadas aqui (fonte -> categorias permitidas além
    # da padrão). Ex.: no feed "Ciência e Saúde" do G1 as matérias sobre
    # descobertas/espaço/clima vão pra "ciencia" e o resto fica em "saude".
    # Portais generalistas: o feed "de tecnologia/economia/..." deles traz matéria de
    # crime, política e cotidiano. Para essas fontes a categoria do feed (prior) NÃO é
    # confiável: a matéria só entra na categoria se o texto/URL/tags comprovarem.
    NEWS_STRICT_PRIOR_PREFIXES = (
        "G1", "UOL", "Folha", "CNN Brasil", "Olhar Digital", "Agência Brasil",
        "ESPN", "ge (", "Exame", "Metrópoles", "R7", "Veja", "O Globo", "Estadão",
    )

    NEWS_MIXED_SOURCE_CATEGORIES = {
        "G1 - Ciência e Saúde": ["ciencia"],
        "G1 - Natureza": ["ciencia"],
        "BBC News Brasil": ["politica", "economia", "esportes", "tecnologia", "entretenimento", "saude", "ciencia"],
        "DW Brasil": ["politica", "economia", "esportes", "tecnologia", "entretenimento", "saude", "ciencia"],
        "Exame": ["tecnologia", "politica"],
        "Poder360": ["economia", "mundo"],
    }

    # ---------- Vortex: crawler de imagens/GIFs/vídeos ----------
    # Itens do crawler NÃO são posts: vivem na tabela vortex_items e só
    # aparecem dentro do Vortex (nunca no feed, perfil, ranking, etc.).
    VORTEX_CRAWLER_ENABLED = os.environ.get("VORTEX_CRAWLER_ENABLED", "1") != "0"
    # (legado: o motor contínuo não usa mais um intervalo fixo de 30 min;
    # cada fonte se reagenda sozinha — ver VORTEX_SOURCE_MIN_DELAY & cia.)
    VORTEX_CRAWL_INTERVAL_SECONDS = int(os.environ.get("VORTEX_CRAWL_INTERVAL_SECONDS", "1800"))
    VORTEX_START_DELAY_SECONDS = 20     # espera ao subir o app antes do 1º disparo
    # ---- motor contínuo de indexação ----
    VORTEX_WORKERS = int(os.environ.get("VORTEX_WORKERS", "8"))                    # fontes em paralelo
    VORTEX_DOWNLOAD_WORKERS = int(os.environ.get("VORTEX_DOWNLOAD_WORKERS", "16")) # miniaturas em paralelo
    VORTEX_BATCH_SIZE = 25              # grava (commit) a cada N itens...
    VORTEX_FLUSH_SECONDS = 2.0          # ...ou a cada N segundos, o que vier primeiro
    VORTEX_SOURCE_MIN_DELAY = 2.0       # pausa entre rodadas de uma fonte que está rendendo
    VORTEX_ROTATE_DELAY = 5.0           # pausa após trocar de termo
    VORTEX_IDLE_DELAY = 900             # fontes sem paginação (rss/page): a cada 15 min
    VORTEX_UNAVAILABLE_DELAY = 6 * 3600 # sem chave de API / bloqueada por robots.txt
    VORTEX_MAX_BACKOFF = 3600           # teto da espera após erros seguidos
    VORTEX_EMPTY_STREAK_ROTATE = 3      # páginas seguidas sem nada novo => próximo termo
    VORTEX_THUMB_MAX_BYTES = 1_500_000  # quanto baixar da miniatura pra calcular o dHash
    VORTEX_PRUNE_EVERY_SECONDS = 1800
    # ---- descoberta de fontes (vortex_discovery.py): "fontes infinitas" ----
    # O motor segue links, feeds e sitemaps a partir das sementes abaixo; cada
    # site novo que aparece vira domínio (fila justa entre domínios, com teto
    # de itens por site pra manter a diversidade) e cada feed novo vira uma
    # fonte `rss` automática.
    VORTEX_DISCOVERY_ENABLED = os.environ.get("VORTEX_DISCOVERY_ENABLED", "1") != "0"
    VORTEX_DISCOVERY_WORKERS = int(os.environ.get("VORTEX_DISCOVERY_WORKERS", "4"))
    VORTEX_DISCOVERY_SEEDS = [
        "https://www.nasa.gov/", "https://www.si.edu/", "https://www.loc.gov/pictures/",
        "https://commons.wikimedia.org/wiki/Commons:Featured_pictures",
        "https://en.wikipedia.org/wiki/Wikipedia:Featured_pictures",
        "https://agenciabrasil.ebc.com.br/", "https://www.gov.br/",
        "https://www.nationalgeographic.com/", "https://www.esa.int/", "https://www.noaa.gov/",
    ]
    VORTEX_DISCOVERY_MAX_DEPTH = 3            # saltos a partir de uma semente/domínio novo
    VORTEX_DISCOVERY_PAGE_INTERVAL = 2.0      # s entre páginas do MESMO site (ou o Crawl-delay do robots.txt)
    VORTEX_DISCOVERY_PAGES_PER_DOMAIN_HOUR = 60
    VORTEX_DISCOVERY_MAX_ITEMS_PER_DOMAIN = 3000   # teto por site (diversidade)
    VORTEX_DISCOVERY_MAX_LINKS_PER_PAGE = 150
    VORTEX_DISCOVERY_MAX_IMAGES_PER_PAGE = 12
    VORTEX_DISCOVERY_NEW_DOMAINS_PER_PAGE = 8
    VORTEX_DISCOVERY_MAX_DOMAINS = 50000
    VORTEX_DISCOVERY_MAX_FRONTIER = int(os.environ.get("VORTEX_DISCOVERY_MAX_FRONTIER", "20000"))   # teto de páginas esperando
    VORTEX_DISCOVERY_MAX_AUTO_FEEDS = 3000
    # ---- fila progressiva (vortex_queue.py): a fronteira nunca vira um passivo de 200 mil ----
    VORTEX_FRONTIER_PER_HOST_MAX = 40          # páginas esperando por site
    VORTEX_FRONTIER_SAME_HOST_PER_PAGE = 10    # links do mesmo site que uma página pode enfileirar
    VORTEX_FRONTIER_SITEMAP_PER_PAGE = 40      # idem, para páginas que são sitemap
    VORTEX_FRONTIER_OTHER_PER_PAGE = 16        # sites de fora (no máximo 1 link por site)
    VORTEX_FRONTIER_TIGHT_RATIO = 0.6          # a partir de 60 % do teto a fila fica "apertada"
    VORTEX_FRONTIER_TIGHT_FACTOR = 0.4         # apertada: limites por página x0,4 e só links rasos
    VORTEX_FRONTIER_TIGHT_MAX_DEPTH = 1
    VORTEX_FRONTIER_TRIM_BATCH = 3000          # exclusões por passo de esvaziamento
    VORTEX_FRONTIER_TRIM_BUSY_SECONDS = 15     # pausa entre passos enquanto há excesso
    VORTEX_FRONTIER_TRIM_IDLE_SECONDS = 300    # pausa entre verificações com a fila em dia
    VORTEX_FRONTIER_PENDING_MAX_DAYS = 7       # pendente mais velha que isso é descartada
    VORTEX_FRONTIER_DONE_KEEP_DAYS = 30        # visitadas ficam registradas (a URL não volta)
    VORTEX_FRONTIER_PRUNE_BATCH = 5000
    VORTEX_DISCOVERY_FEEDS_PER_DOMAIN = 3
    VORTEX_DISCOVERY_MAX_ERRORS = 8           # erros seguidos: domínio vira "dead"
    VORTEX_DISCOVERY_HTML_BYTES = 400_000
    # 1 = só indexa páginas que declaram licença aberta (rel="license" CC/PD)
    VORTEX_DISCOVERY_ONLY_LICENSED = os.environ.get("VORTEX_DISCOVERY_ONLY_LICENSED", "0") == "1"
    # sites que o motor nunca visita (sufixo de host); some os que o admin bloquear
    VORTEX_DOMAIN_DENYLIST = {
        "facebook.com", "instagram.com", "twitter.com", "x.com", "tiktok.com", "linkedin.com",
        "pinterest.com", "google.com", "youtube.com", "bing.com", "doubleclick.net",
    }
    # termos que, na URL/host, tiram a página (além dos termos bloqueados do crawler)
    VORTEX_URL_BLOCK_TERMS = (
        "porn", "xxx", "sex", "nude", "nsfw", "erotic", "hentai", "escort", "casino", "bet365",
        "login", "signin", "signup", "register", "checkout", "cart", "account", "password",
    )
    # SEGURANÇA (SSRF): por padrão o motor só acessa hosts públicos (nada de
    # 127.0.0.1, rede interna, metadata de nuvem). Só ligue em testes/laboratório.
    VORTEX_ALLOW_PRIVATE_HOSTS = os.environ.get("VORTEX_ALLOW_PRIVATE_HOSTS", "0") == "1"

    # ---- análise visual (sugestões pelo CONTEÚDO da imagem; vortex_vision.py) ----
    # Item novo ganha a assinatura de aparência na hora; os antigos (e o CLIP,
    # se ligado) são preenchidos em segundo plano por uma thread própria.
    VORTEX_VISION_ENABLED = os.environ.get("VORTEX_VISION_ENABLED", "1") != "0"
    VORTEX_VISION_WORKERS = int(os.environ.get("VORTEX_VISION_WORKERS", "6"))
    VORTEX_VISION_BATCH = 48            # itens analisados por ciclo (1 commit por ciclo)
    VORTEX_VISION_IDLE_SECONDS = 30     # espera quando não há nada pendente
    # Modelo CLIP (opcional): reconhece O QUE a imagem mostra (cachoeira,
    # cachorro, pizza...) e gera tags + embedding semântico. Precisa de
    #   pip install sentence-transformers
    # e, por ex., VORTEX_CLIP_MODEL=clip-ViT-B-32  (baixa ~600 MB na 1ª vez).
    # Vazio = desligado (continua valendo a assinatura de aparência).
    VORTEX_CLIP_MODEL = os.environ.get("VORTEX_CLIP_MODEL", "")
    VORTEX_CLIP_MIN_PROB = 0.20         # conceito entra em visual_tags
    VORTEX_CLIP_TAG_MIN_PROB = 0.35     # conceito entra em tags (busca) / categoria
    # intervalo mínimo (s) entre requisições ao MESMO host. As APIs com chave
    # têm cotas bem baixas no plano grátis (Pexels ~200/h, Unsplash demo 50/h,
    # GIPHY beta ~100/h), por isso os intervalos longos — o motor também
    # respeita Retry-After quando a API responde 429.
    VORTEX_HOST_INTERVALS = {
        "commons.wikimedia.org": 0.35,
        "upload.wikimedia.org": 0.08,
        "api.openverse.org": 1.0,
        "api.pexels.com": 20.0,
        "pixabay.com": 0.7,
        "api.giphy.com": 40.0,
        "api.unsplash.com": 75.0,
        "images-api.nasa.gov": 0.3,
        "collectionapi.metmuseum.org": 0.05,
        "api.artic.edu": 0.3,
    }
    # máximo de itens novos gravados por fonte a cada rodada (uma página de
    # API traz de 15 a 50 candidatos; o teto só protege contra surpresas)
    VORTEX_MAX_ITEMS_PER_SOURCE_RUN = 100
    # ---- painel lateral (widgets_weather.py) ----
    ONLINE_WINDOW_SECONDS = 300         # "online agora" = visto nos últimos 5 min (widget Quem está online)
    WEATHER_ENABLED = True              # False desliga o widget de clima (devolve reason=disabled)
    QUOTES_ENABLED = True               # False desliga o widget de cotações (reason=disabled)
    MAX_USER_WIDGETS = 12               # widgets próprios por usuário ("Minha área")

    VORTEX_PAGE_SIZE = 30               # peças por página da grade
    VORTEX_SEARCH_MAX_RESULTS = 400     # teto de resultados de uma busca (paginados)
    VORTEX_RELATED_MAX_RESULTS = 150    # teto de "mais como este" por item
    VORTEX_RELATED_CANDIDATES = 300     # candidatos buscados por sinal (tags/phash/categoria)
    VORTEX_STATS_TTL_SECONDS = 60       # cache de /vortex/stats e /vortex/categories
    VORTEX_PHASH_RECHECK_SECONDS = 20   # de quanto em quanto tempo rever o índice de phash em memória
    VORTEX_MAX_ITEMS = 60000            # acima disso os mais antigos são podados
    VORTEX_MIN_DIMENSION = 200          # px; abaixo disso é ícone/thumb
    VORTEX_MAX_GIF_BYTES = 8 * 1024 * 1024
    # --- qualidade do Vortex: barra QR code, logo, imagem chapada e repetidas ---
    VORTEX_QUALITY_ENABLED = os.environ.get("VORTEX_QUALITY_ENABLED", "1") != "0"
    VORTEX_QUALITY_BATCH = 40           # itens antigos reanalisados por ciclo (backfill)
    VORTEX_QUALITY_IDLE_SECONDS = 45    # espera quando não há nada pendente
    VORTEX_DEDUPE_DISTANCE = 6          # Hamming (dHash) até o qual duas imagens são "a mesma"
    VORTEX_REPEAT_TEMPLATE_MIN = 6      # tantas cópias quase iguais = banner/logo do site: some tudo
    VORTEX_FEED_NEAR_DUP_DISTANCE = 9   # na grade, duas imagens a até isto não aparecem na mesma rolagem
    VORTEX_FEED_PER_SITE_WINDOW = 12    # numa janela de peças...
    VORTEX_FEED_PER_SITE_MAX = 3        # ...no máximo isto do mesmo site de origem
    VORTEX_PHASH_PER_RUN = 40           # (legado, sem uso: o motor calcula o dHash de todo item novo)
    # --- compreensão do conteúdo: título/tags/CLIP -> conceitos (ver vortex_understand.py) ---
    VORTEX_CONCEPTS_ENABLED = os.environ.get("VORTEX_CONCEPTS_ENABLED", "1") != "0"
    VORTEX_CONCEPTS_BATCH = 500         # itens reprocessados por ciclo (só texto, sem rede)
    VORTEX_CONCEPTS_IDLE_SECONDS = 60   # espera quando não há nada pendente
    # "outros" -> categoria do domínio só com evidência de título/tags/CLIP (0.6 ~ tag com 1 menção)
    VORTEX_CONCEPTS_RECLASSIFY_MIN_CONFIDENCE = 0.6
    VORTEX_REQUEST_TIMEOUT = 12
    VORTEX_USER_AGENT = os.environ.get(
        "VORTEX_USER_AGENT",
        "DriqyVortexBot/1.0 (+https://driqy.example/bot; contato: admin@driqy.example)",
    )
    # chaves opcionais — sem a chave a fonte correspondente fica desligada
    PEXELS_API_KEY = os.environ.get("PEXELS_API_KEY", "")
    PIXABAY_API_KEY = os.environ.get("PIXABAY_API_KEY", "")
    GIPHY_API_KEY = os.environ.get("GIPHY_API_KEY", "")
    UNSPLASH_ACCESS_KEY = os.environ.get("UNSPLASH_ACCESS_KEY", "")
    # Openverse sem credencial tem cota anônima baixa (é uma das causas de a
    # indexação "parar"); registre um app grátis em api.openverse.org e use:
    OPENVERSE_CLIENT_ID = os.environ.get("OPENVERSE_CLIENT_ID", "")
    OPENVERSE_CLIENT_SECRET = os.environ.get("OPENVERSE_CLIENT_SECRET", "")

    VORTEX_CATEGORIES = [
        ("natureza", "Natureza"),
        ("animais", "Animais"),
        ("viagens", "Viagens"),
        ("arquitetura", "Arquitetura"),
        ("arte", "Arte e design"),
        ("comida", "Comida"),
        ("tecnologia", "Tecnologia"),
        ("esportes", "Esportes"),
        ("carros", "Carros e motos"),
        ("moda", "Moda e beleza"),
        ("pessoas", "Pessoas"),
        ("humor", "Humor e memes"),
        ("games", "Games"),
        ("ciencia", "Ciência e espaço"),
        ("outros", "Outros"),
    ]

    # palavras-chave (pt + en, já que Commons/Openverse são majoritariamente
    # em inglês) usadas só quando a fonte não define categoria própria.
    # Mesmo formato de NEWS_CATEGORY_KEYWORDS (ver news_classifier.py).
    VORTEX_CATEGORY_KEYWORDS = {
        "natureza": ["landscape", "forest", "mountain", "waterfall", "beach", "sunset", "ocean",
                     "flower", "tree", "paisagem", "floresta", "montanha", "cachoeira", "praia",
                     "flor", "lake", "river", "sky", "garden"],
        "animais": ["animal", "cat", "dog", "bird", "wildlife", "horse", "fish", "insect",
                    "gato", "cachorro", "pássaro", "passaro", "butterfly", "puppy", "kitten"],
        "viagens": ["travel", "city", "street", "skyline", "tourism", "viagem", "cidade", "turismo",
                    "harbor", "village", "landmark"],
        "arquitetura": ["architecture", "building", "bridge", "interior", "church", "tower",
                        "arquitetura", "prédio", "predio", "ponte", "igreja", "house"],
        "arte": ["art", "painting", "sculpture", "illustration", "drawing", "design", "mural",
                 "arte", "pintura", "escultura", "ilustração", "ilustracao", "poster"],
        "comida": ["food", "dish", "meal", "cake", "coffee", "fruit", "pizza", "comida",
                   "prato", "bolo", "café", "fruta", "recipe", "dessert"],
        "tecnologia": ["technology", "computer", "robot", "circuit", "smartphone", "laptop",
                       "tecnologia", "computador", "robô", "robo", "software"],
        "esportes": ["sport", "football", "soccer", "basketball", "tennis", "surf", "race",
                     "esporte", "futebol", "corrida", "athlete", "olympic"],
        "carros": ["car", "motorcycle", "truck", "vehicle", "engine", "carro", "moto",
                   "automobile", "bike"],
        "moda": ["fashion", "makeup", "dress", "model", "hairstyle", "moda", "maquiagem",
                 "vestido", "beauty"],
        "pessoas": ["portrait", "people", "woman", "man", "child", "crowd", "retrato",
                    "pessoas", "mulher", "homem", "criança", "crianca"],
        "humor": ["meme", "funny", "lol", "reaction", "cartoon", "humor", "engraçado",
                  "engracado", "fail"],
        "games": ["game", "gaming", "videogame", "esports", "console", "minecraft", "jogo",
                  "pixel art"],
        "ciencia": ["space", "galaxy", "planet", "nebula", "telescope", "astronomy", "science",
                    "laboratory", "microscope", "espaço", "espaco", "ciência", "ciencia", "nasa"],
    }

    # perfis do Vortex (quem "publicou" os itens do crawler):
    # (handle, nome, bio, site de origem)
    VORTEX_DEFAULT_PROFILES = [
        ("commons", "Wikimedia Commons", "Imagens, GIFs e vídeos livres do acervo colaborativo da Wikimedia.", "commons.wikimedia.org"),
        ("openverse", "Openverse", "Imagens e GIFs com licença aberta de várias coleções.", "openverse.org"),
        ("pexels", "Pexels", "Fotos e vídeos gratuitos do Pexels.", "pexels.com"),
        ("pixabay", "Pixabay", "Fotos e vídeos gratuitos do Pixabay.", "pixabay.com"),
        ("giphy", "GIPHY", "GIFs do GIPHY.", "giphy.com"),
        ("web", "Descobertas da web", "Imagens e vídeos encontrados em feeds e páginas públicas.", None),
        ("nasa", "NASA Image Library", "Fotos do acervo público da NASA.", "images.nasa.gov"),
        ("met", "The Met", "Obras em domínio público do Metropolitan Museum of Art (CC0).", "metmuseum.org"),
        ("artic", "Art Institute of Chicago", "Obras em domínio público do Art Institute of Chicago.", "artic.edu"),
        ("unsplash", "Unsplash", "Fotos gratuitas do Unsplash.", "unsplash.com"),
    ]

    # fontes iniciais: (nome, tipo, perfil, categoria, consulta/URL, extra)
    # tipos: commons | openverse | pexels | pixabay | giphy | rss | page
    # `extra` (dict) aceita: media ("photo"|"gif"|"video")
    VORTEX_DEFAULT_SOURCES = [
        ("Commons • paisagens", "commons", "commons", "natureza", "landscape", {}),
        ("Commons • cachoeiras", "commons", "commons", "natureza", "waterfall", {}),
        ("Commons • animais", "commons", "commons", "animais", "wildlife animal", {}),
        ("Commons • cidades", "commons", "commons", "viagens", "city skyline", {}),
        ("Commons • arquitetura", "commons", "commons", "arquitetura", "architecture", {}),
        ("Commons • arte", "commons", "commons", "arte", "painting", {}),
        ("Commons • comida", "commons", "commons", "comida", "food dish", {}),
        ("Commons • espaço", "commons", "commons", "ciencia", "nebula galaxy", {}),
        ("Commons • esportes", "commons", "commons", "esportes", "sport action", {}),
        ("Commons • carros", "commons", "commons", "carros", "classic car", {}),
        ("Commons • vídeos de natureza", "commons", "commons", "natureza", "nature", {"media": "video"}),
        ("Commons • vídeos de animais", "commons", "commons", "animais", "animal", {"media": "video"}),
        ("Commons • GIFs de animais", "commons", "commons", "animais", "animal", {"media": "gif"}),
        ("Commons • GIFs de ciência", "commons", "commons", "ciencia", "space", {"media": "gif"}),
        ("Commons • GIFs animados", "commons", "commons", None, "animation", {"media": "gif"}),
        ("Openverse • natureza", "openverse", "openverse", "natureza", "nature", {}),
        ("Openverse • animais", "openverse", "openverse", "animais", "animals", {}),
        ("Openverse • viagens", "openverse", "openverse", "viagens", "travel", {}),
        ("Openverse • arte", "openverse", "openverse", "arte", "illustration", {}),
        ("Openverse • comida", "openverse", "openverse", "comida", "food", {}),
        ("Openverse • tecnologia", "openverse", "openverse", "tecnologia", "technology", {}),
        ("Openverse • GIFs", "openverse", "openverse", None, "animation", {"media": "gif"}),
        ("Pexels • natureza", "pexels", "pexels", "natureza", "nature", {}),
        ("Pexels • vídeos", "pexels", "pexels", None, "aerial", {"media": "video"}),
        ("Pixabay • fotos", "pixabay", "pixabay", None, "landscape", {}),
        ("Pixabay • vídeos", "pixabay", "pixabay", None, "nature", {"media": "video"}),
        ("GIPHY • trending", "giphy", "giphy", "humor", "funny", {"media": "gif"}),
        # fontes sem chave: acervos públicos (CC0 / domínio público)
        ("NASA • espaço", "nasa", "nasa", "ciencia", "galaxy", {}),
        ("NASA • Terra", "nasa", "nasa", "natureza", "earth", {}),
        ("NASA • tecnologia", "nasa", "nasa", "tecnologia", "rocket", {}),
        ("The Met • pinturas", "met", "met", "arte", "painting", {}),
        ("The Met • esculturas", "met", "met", "arte", "sculpture", {}),
        ("The Met • moda", "met", "met", "moda", "costume", {}),
        ("Art Institute • arte", "artic", "artic", "arte", "landscape", {}),
        ("Art Institute • arquitetura", "artic", "artic", "arquitetura", "architecture", {}),
        ("Art Institute • animais", "artic", "artic", "animais", "animal", {}),
        # com chave (ficam desligadas até a chave existir)
        ("Unsplash • natureza", "unsplash", "unsplash", "natureza", "nature", {}),
        ("Unsplash • viagens", "unsplash", "unsplash", "viagens", "travel", {}),
        ("Unsplash • pessoas", "unsplash", "unsplash", "pessoas", "portrait", {}),
        ("Pexels • viagens", "pexels", "pexels", "viagens", "travel", {}),
        ("Pexels • comida", "pexels", "pexels", "comida", "food", {}),
        ("Pexels • animais", "pexels", "pexels", "animais", "animals", {}),
        ("Pixabay • comida", "pixabay", "pixabay", "comida", "food", {}),
        ("Pixabay • animais", "pixabay", "pixabay", "animais", "animals", {}),
        ("GIPHY • animais", "giphy", "giphy", "animais", "cute animals", {"media": "gif"}),
        # feeds de mídia (respeitam robots.txt)
        ("NASA • imagem do dia", "rss", "web", "ciencia", "https://www.nasa.gov/feeds/iotd-feed/", {}),
    ]

    # Quando uma fonte esgota o termo (acabaram as páginas, a API cortou a
    # paginação ou só vieram duplicatas), o motor NÃO volta pra página 1 do
    # mesmo termo: passa pro próximo termo da lista da categoria da fonte
    # (ou de "geral"). É isso que mantém a indexação crescendo em vez de
    # parar quando as buscas iniciais acabam. Acrescente termos à vontade.
    VORTEX_EXPAND_TERMS = {
        "natureza": "mountain|forest|river|lake|beach|ocean wave|sunset|sunrise|desert|glacier|volcano|canyon|meadow|autumn leaves|snow|rainforest|island|cliff|fog|aurora|flower field|tree|rock formation|coral reef|storm clouds|valley|lagoon|savanna|waterfall|moss".split("|"),
        "animais": "dog|cat|bird|horse|elephant|lion|tiger|bear|fox|wolf|owl|eagle|parrot|butterfly|bee|fish|dolphin|whale|turtle|frog|snake|monkey|deer|rabbit|penguin|giraffe|zebra|squirrel|jaguar|toucan".split("|"),
        "viagens": "street market|old town|harbor|bridge|temple|castle|train station|lighthouse|tropical beach|mountain village|night city|palace|ruins|cathedral|lake town|cable car|boat|plaza|monument|island resort|road trip|airport|festival|waterfront|skyline night|alley|museum|ferry|tower|canal".split("|"),
        "arquitetura": "skyscraper|cathedral|bridge|modern house|interior design|staircase|dome|facade|glass building|museum|library|brutalist|gothic|art deco|mosque|pagoda|castle|loft|courtyard|window|arch|tower|stadium|railway station|villa|ceiling|spiral stairs|columns|rooftop|pavilion".split("|"),
        "arte": "oil painting|sculpture|watercolor|portrait painting|impressionism|mural|ceramics|illustration|engraving|still life|abstract art|mosaic|tapestry|drawing|poster|calligraphy|stained glass|woodcut|lithograph|textile|pottery|landscape painting|baroque|surrealism|folk art|street art|manuscript|miniature|icon|fresco|print".split("|"),
        "comida": "pizza|pasta|sushi|salad|dessert|cake|bread|fruit|vegetables|soup|burger|breakfast|coffee|cheese|chocolate|seafood|barbecue|street food|spices|tacos|ice cream|pastry|curry|rice dish|sandwich|smoothie|market stall|wine|tea|noodles".split("|"),
        "tecnologia": "computer|circuit board|robot|server room|smartphone|satellite|drone|3d printer|laptop|keyboard|microchip|electric car charging|solar panel|wind turbine|vr headset|telescope|antenna|data center|camera|cables|lab equipment|engine|battery|radio|machine|workshop|display|control room|processor|sensor|hologram".split("|"),
        "esportes": "soccer|basketball|tennis|surfing|cycling|swimming|marathon|skiing|climbing|volleyball|rugby|boxing|gymnastics|skateboard|rowing|golf|baseball|cricket|athletics|sailing|martial arts|snowboard|hockey|handball|fencing|diving|triathlon|yoga|stadium crowd|karate".split("|"),
        "carros": "sports car|vintage car|motorcycle|truck|race car|electric car|rally|classic motorcycle|bus|tractor|convertible|supercar|scooter|car interior|engine bay|pickup|van|formula|muscle car|off road|locomotive|bicycle|moped|jeep|limousine|garage|car show|tram|dragster|sidecar|kart".split("|"),
        "moda": "dress|costume|jewelry|shoes|hat|handbag|kimono|embroidery|fabric|runway|traditional clothing|vintage fashion|scarf|makeup|hairstyle|textile pattern|coat|uniform|mask|accessories|denim|fashion illustration|tailoring|lace|silk|boots|sunglasses|necklace|wedding dress|knitwear".split("|"),
        "pessoas": "portrait|crowd|dancers|musician|farmer|children playing|market vendor|festival people|craftsman|street portrait|elderly|athlete|family|student|worker|fisherman|artist|couple|chef|band|parade|workshop|singer|street performer|villagers|scientist|teacher|friends|protest|wedding".split("|"),
        "humor": "funny animal|meme|reaction|dance|fail|surprised|celebration|facepalm|cat funny|dog funny|cartoon|happy|clapping|laughing|shocked|thumbs up|eye roll|party|baby|wow|oops|high five|confused|excited|thinking|sleepy|crying laughing|victory|awkward|mic drop".split("|"),
        "games": "video game|arcade|board game|chess|console|joystick|pixel art|esports|retro game|cards|dice|puzzle|virtual reality|game controller|tabletop|poker|domino|toy|lego|fantasy game|game character|strategy game|gaming setup|slot|pinball|go board|tournament|miniature figures|retro computer|level design|speedrun".split("|"),
        "ciencia": "galaxy|nebula|planet|moon|mars|telescope|microscope|dna|molecule|laboratory|rocket launch|astronaut|solar system|supernova|comet|fossil|crystal|bacteria|brain scan|particle|lightning|volcano eruption|ocean floor|satellite earth|space station|black hole|eclipse|meteor|chemistry|physics experiment".split("|"),
        "geral": "landscape|city|people|animal|food|art|architecture|technology|sport|travel|nature|culture|history|vintage|night|aerial view|macro|black and white|colorful|texture|pattern|sky|water|light|shadow|street|market|festival|garden|mountain".split("|"),
    }

    # Vocabulário do CLIP (zero-shot): (descrição em inglês, rótulo em pt, categoria).
    # O CLIP escolhe, entre estes, o que mais combina com a imagem. Acrescente
    # conceitos à vontade — vale também pra reclassificar itens "outros".
    VORTEX_VISUAL_CONCEPTS = [
        ("a waterfall", "cachoeira", "natureza"), ("a mountain", "montanha", "natureza"),
        ("a forest", "floresta", "natureza"), ("a beach", "praia", "natureza"),
        ("ocean waves", "ondas do mar", "natureza"), ("a lake", "lago", "natureza"),
        ("a river", "rio", "natureza"), ("a desert", "deserto", "natureza"),
        ("a snowy landscape", "paisagem com neve", "natureza"), ("a sunset sky", "pôr do sol", "natureza"),
        ("flowers", "flores", "natureza"), ("a grass field", "campo", "natureza"),
        ("a volcano", "vulcão", "natureza"), ("a cave", "caverna", "natureza"),
        ("clouds in the sky", "nuvens", "natureza"), ("a rainbow", "arco-íris", "natureza"),
        ("a glacier", "geleira", "natureza"), ("autumn trees", "outono", "natureza"),
        ("a tropical island", "ilha tropical", "natureza"), ("a canyon", "cânion", "natureza"),
        ("a dog", "cachorro", "animais"), ("a cat", "gato", "animais"), ("a bird", "pássaro", "animais"),
        ("a horse", "cavalo", "animais"), ("an elephant", "elefante", "animais"),
        ("a lion", "leão", "animais"), ("a tiger", "tigre", "animais"), ("a bear", "urso", "animais"),
        ("a wolf", "lobo", "animais"), ("a fox", "raposa", "animais"), ("a monkey", "macaco", "animais"),
        ("a fish underwater", "peixe", "animais"), ("a dolphin", "golfinho", "animais"),
        ("a whale", "baleia", "animais"), ("a butterfly", "borboleta", "animais"),
        ("an insect", "inseto", "animais"), ("a snake", "cobra", "animais"),
        ("a turtle", "tartaruga", "animais"), ("a rabbit", "coelho", "animais"),
        ("a cow", "vaca", "animais"), ("a sheep", "ovelha", "animais"),
        ("a penguin", "pinguim", "animais"), ("an owl", "coruja", "animais"),
        ("a parrot", "papagaio", "animais"),
        ("a city skyline", "horizonte da cidade", "viagens"), ("a street in an old town", "rua histórica", "viagens"),
        ("a bridge", "ponte", "viagens"), ("a harbor with boats", "porto com barcos", "viagens"),
        ("a street market", "mercado de rua", "viagens"), ("an airplane", "avião", "viagens"),
        ("a train", "trem", "viagens"), ("a long road", "estrada", "viagens"),
        ("a hot air balloon", "balão", "viagens"), ("a castle", "castelo", "viagens"),
        ("a temple", "templo", "viagens"), ("a monument", "monumento", "viagens"),
        ("a skyscraper", "arranha-céu", "arquitetura"), ("a church interior", "interior de igreja", "arquitetura"),
        ("a modern house", "casa moderna", "arquitetura"), ("a staircase", "escada", "arquitetura"),
        ("a decorated living room", "sala decorada", "arquitetura"), ("ancient ruins", "ruínas", "arquitetura"),
        ("a tower", "torre", "arquitetura"), ("a dome", "cúpula", "arquitetura"),
        ("an oil painting", "pintura a óleo", "arte"), ("a sculpture", "escultura", "arte"),
        ("a pencil drawing", "desenho", "arte"), ("graffiti street art", "grafite", "arte"),
        ("abstract art", "arte abstrata", "arte"), ("a painted portrait", "retrato pintado", "arte"),
        ("pottery", "cerâmica", "arte"), ("stained glass", "vitral", "arte"),
        ("an illustration", "ilustração", "arte"), ("a poster", "cartaz", "arte"),
        ("a pizza", "pizza", "comida"), ("a burger", "hambúrguer", "comida"), ("sushi", "sushi", "comida"),
        ("a salad", "salada", "comida"), ("a cake", "bolo", "comida"), ("a dessert", "sobremesa", "comida"),
        ("fresh fruit", "frutas", "comida"), ("vegetables", "legumes", "comida"),
        ("a cup of coffee", "café", "comida"), ("bread", "pão", "comida"), ("pasta", "massa", "comida"),
        ("seafood", "frutos do mar", "comida"), ("grilled meat", "churrasco", "comida"),
        ("a bowl of soup", "sopa", "comida"), ("ice cream", "sorvete", "comida"),
        ("a breakfast table", "café da manhã", "comida"), ("cheese", "queijo", "comida"),
        ("chocolate", "chocolate", "comida"),
        ("a computer", "computador", "tecnologia"), ("a smartphone", "celular", "tecnologia"),
        ("a robot", "robô", "tecnologia"), ("a circuit board", "placa de circuito", "tecnologia"),
        ("a satellite", "satélite", "tecnologia"), ("a drone", "drone", "tecnologia"),
        ("a server room", "sala de servidores", "tecnologia"), ("a laptop", "notebook", "tecnologia"),
        ("a camera", "câmera", "tecnologia"), ("headphones", "fones de ouvido", "tecnologia"),
        ("a soccer match", "futebol", "esportes"), ("a basketball game", "basquete", "esportes"),
        ("a tennis player", "tênis", "esportes"), ("surfing", "surfe", "esportes"),
        ("swimming", "natação", "esportes"), ("a runner", "corrida", "esportes"),
        ("cycling", "ciclismo", "esportes"), ("skiing", "esqui", "esportes"),
        ("rock climbing", "escalada", "esportes"), ("boxing", "boxe", "esportes"),
        ("gymnastics", "ginástica", "esportes"), ("skateboarding", "skate", "esportes"),
        ("a stadium", "estádio", "esportes"), ("volleyball", "vôlei", "esportes"),
        ("a sports car", "carro esportivo", "carros"), ("a vintage car", "carro antigo", "carros"),
        ("a motorcycle", "moto", "carros"), ("a truck", "caminhão", "carros"),
        ("a race car", "carro de corrida", "carros"), ("a bus", "ônibus", "carros"),
        ("a bicycle", "bicicleta", "carros"), ("a tractor", "trator", "carros"),
        ("a dress", "vestido", "moda"), ("shoes", "sapatos", "moda"), ("jewelry", "joias", "moda"),
        ("a handbag", "bolsa", "moda"), ("a hat", "chapéu", "moda"), ("makeup", "maquiagem", "moda"),
        ("a traditional costume", "traje típico", "moda"), ("a fashion model", "modelo de moda", "moda"),
        ("a portrait of a person", "retrato", "pessoas"), ("a crowd of people", "multidão", "pessoas"),
        ("children playing", "crianças brincando", "pessoas"), ("a couple", "casal", "pessoas"),
        ("a family", "família", "pessoas"), ("a musician playing", "músico", "pessoas"),
        ("dancers", "dançarinos", "pessoas"), ("a worker", "trabalhador", "pessoas"),
        ("a wedding", "casamento", "pessoas"),
        ("a funny meme", "meme", "humor"), ("a cartoon character", "personagem de desenho", "humor"),
        ("a funny face", "careta", "humor"),
        ("a video game screenshot", "captura de jogo", "games"), ("a game controller", "controle de videogame", "games"),
        ("a chess board", "tabuleiro de xadrez", "games"), ("a board game", "jogo de tabuleiro", "games"),
        ("playing cards", "cartas de baralho", "games"), ("pixel art", "pixel art", "games"),
        ("a toy", "brinquedo", "games"),
        ("a galaxy", "galáxia", "ciencia"), ("a nebula", "nebulosa", "ciencia"), ("a planet", "planeta", "ciencia"),
        ("the moon", "lua", "ciencia"), ("an astronaut", "astronauta", "ciencia"),
        ("a rocket launch", "lançamento de foguete", "ciencia"), ("a microscope image", "microscopia", "ciencia"),
        ("a laboratory", "laboratório", "ciencia"), ("a DNA molecule", "DNA", "ciencia"),
        ("a fossil", "fóssil", "ciencia"), ("a telescope", "telescópio", "ciencia"),
        ("a space station", "estação espacial", "ciencia"),
    ]

    NEWS_PER_PAGE = 30
    # mantém uma notícia sem imagem no feed (com um card colorido da categoria
    # e pontuação reduzida) em vez de escondê-la — sem isso, categorias com
    # poucas fontes ficavam quase vazias. False volta ao comportamento antigo.
    # Flash (stories): foto que vive 24h e dá um anel colorido ao avatar
    FLASH_TTL_HOURS = 24
    FLASH_MAX_ACTIVE_PER_USER = 30
    FLASH_MAX_BYTES = 12 * 1024 * 1024
    FLASH_CAPTION_MAX = 200

    NEWS_ALLOW_NO_IMAGE = False   # card sem imagem fica feio: só mostra notícia com capa
    # largura mínima (px) que a capa deve ter pra ser considerada "boa"; abaixo
    # disso o indexador tenta uma versão maior (og:image da matéria)
    NEWS_MIN_GOOD_IMAGE_WIDTH = 600
    # intervalo (segundos) em que o scheduler busca notícias novas nos feeds
    NEWS_INDEX_INTERVAL_SECONDS = 600
    # notícias mais velhas que isso somem do feed (mas o link original continua valendo)
    NEWS_MAX_AGE_DAYS = 14

    # ---- banco de notícias TEMPORÁRIO (news_bank.py) ----
    # Cache de candidatos já analisados (categoria + secundárias, termos, grupo
    # do mesmo fato) que o recomendador consulta no lugar de recalcular tudo a
    # cada pedido. Cada item vence sozinho em NEWS_BANK_TTL_DAYS (3 dias) e o
    # que passou do prazo é apagado pelo agendador.
    NEWS_BANK_TTL_DAYS = 3
    NEWS_BANK_MAX_ITEMS = 6000          # teto de segurança (apaga os mais antigos)
    NEWS_BANK_MIN_ITEMS = 40            # abaixo disso o recomendador usa o caminho antigo
    NEWS_BANK_PURGE_MINUTES = 60

    # cor de destaque de cada categoria, usada no selo do card de notícia
    NEWS_CATEGORY_COLORS = {
        "geral": "#8f9bbf",
        "politica": "#5b9bd8",
        "economia": "#5fd6a0",
        "esportes": "#f2765c",
        "tecnologia": "#9b7bd8",
        "entretenimento": "#d858b8",
        "saude": "#4fb6a8",
        "ciencia": "#5ec8e0",
        "mundo": "#d8b354",
    }
