"""
Migra os uploads antigos (todos soltos em instance/uploads) para a estrutura:

    avatars/   covers/   posts/AAAA/MM/

Uso:
    python migrate_uploads.py            # SIMULAÇÃO: só mostra o que seria feito
    python migrate_uploads.py --apply    # executa de verdade

Segurança:
  * antes de aplicar, faz cópia do banco SQLite (driqy.db.bak-AAAAMMDD-HHMMSS);
  * primeiro COPIA os arquivos, depois atualiza o banco numa única transação
    e só então apaga os originais — se algo falhar, as cópias novas são
    removidas e nada muda;
  * arquivos citados no banco mas ausentes no disco são apenas listados;
  * pode rodar de novo sem problema (só mexe em nomes sem "/").
Pare o servidor antes de aplicar.
"""
import os
import shutil
import sys
from datetime import datetime

from app import create_app
from extensions import db
from models import User, Post, PostMedia


def main(apply):
    app = create_app()
    root = app.config["UPLOAD_FOLDER"]

    with app.app_context():
        # old_name -> new_rel (um arquivo pode ser citado em mais de um lugar)
        plan = {}

        def want(old, new):
            if old and "/" not in old and old not in plan:
                plan[old] = new

        for u in User.query.all():
            want(u.avatar_filename, f"avatars/{u.avatar_filename}")
            want(u.cover_filename, f"covers/{u.cover_filename}")

        for p in Post.query.all():
            folder = f"posts/{p.created_at.year:04d}/{p.created_at.month:02d}"
            want(p.media_filename, f"{folder}/{p.media_filename}")
            for m in p.media_items:
                want(m.filename, f"{folder}/{m.filename}")

        missing = [o for o in plan if not os.path.isfile(os.path.join(root, o))]
        todo = {o: n for o, n in plan.items() if o not in missing}
        print(f"Arquivos a migrar: {len(todo)} | ausentes no disco: {len(missing)}")
        for o in missing:
            print(f"  [ausente] {o}")
        if not apply:
            for o, n in list(todo.items())[:20]:
                print(f"  {o} -> {n}")
            if len(todo) > 20:
                print(f"  ... e mais {len(todo) - 20}")
            print("\nSimulação concluída. Use --apply para executar.")
            return

        if not todo:
            print("Nada a migrar.")
            return

        uri = app.config["SQLALCHEMY_DATABASE_URI"]
        if uri.startswith("sqlite:///"):
            dbfile = uri[len("sqlite:///"):]
            if os.path.isfile(dbfile):
                bak = f"{dbfile}.bak-{datetime.now():%Y%m%d-%H%M%S}"
                shutil.copy2(dbfile, bak)
                print(f"Backup do banco: {bak}")

        copied = []
        try:
            for o, n in todo.items():
                dst = os.path.join(root, *n.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(os.path.join(root, o), dst)
                copied.append(dst)

            for u in User.query.all():
                if u.avatar_filename in todo:
                    u.avatar_filename = todo[u.avatar_filename]
                if u.cover_filename in todo:
                    u.cover_filename = todo[u.cover_filename]
            for p in Post.query.all():
                if p.media_filename in todo:
                    p.media_filename = todo[p.media_filename]
            for m in PostMedia.query.all():
                if m.filename in todo:
                    m.filename = todo[m.filename]
            db.session.commit()
        except Exception as exc:
            db.session.rollback()
            for dst in copied:
                try:
                    os.remove(dst)
                except OSError:
                    pass
            print(f"ERRO: {exc}\nNada foi alterado (cópias novas removidas).")
            sys.exit(1)

        for o in todo:
            try:
                os.remove(os.path.join(root, o))
            except OSError:
                pass
        print(f"Migração concluída: {len(todo)} arquivo(s). Reinicie o servidor.")


if __name__ == "__main__":
    main("--apply" in sys.argv)
