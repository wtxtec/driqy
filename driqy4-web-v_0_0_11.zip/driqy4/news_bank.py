"""
Banco de notícias TEMPORÁRIO.

Problema: o recomendador montava o pool de candidatos a cada pedido direto da
tabela de notícias (até 14 dias, de todas as fontes), reanalisava títulos e
reagrupava "o mesmo fato" na hora. Quem alimenta isso (o indexador) só roda de
10 em 10 minutos e precisa da rede; entre uma coleta e outra o recomendador
dependia de um pool "cru" e magro.

Solução: toda notícia indexada ganha uma ficha (NewsBankItem) com o que já foi
calculado UMA vez — categoria + secundárias + confiança, termos importantes e
grupo do mesmo fato (story_id). O recomendador lê dessa base pronta:
  - tem muitas notícias à mão (3 dias de todas as categorias), sem coletar nada;
  - perfil e afinidade por assunto usam os mesmos termos normalizados;
  - cobertura/duplicatas vêm do story_id (sem reagrupar a cada pedido).

Ciclo de vida: cada ficha vence em NEWS_BANK_TTL_DAYS (3) e é apagada por
`purge_expired` (agendador, de hora em hora, e ao fim de cada indexação). Fichas
órfãs (notícia removida) e o excedente acima de NEWS_BANK_MAX_ITEMS também saem.
`backfill` recria fichas a partir de NewsArticle sem rede — é o que popula o
banco no primeiro uso e depois de um reinício limpo.
"""
import json
import re
from collections import Counter
from datetime import timedelta

from extensions import db
from models import NewsArticle, NewsBankItem, utcnow
from news_classifier import _norm, _stem, classify_article

_WORD_RE = re.compile(r"[A-Za-zÀ-ÿ0-9]{4,}")
_STOP_RAW = """
para como mais pela pelo pelos pelas sobre entre apos ainda depois antes contra desde sera foram esta estao
tem havia sido seus suas dele dela deles delas isso essa esse essas esses numa nesta neste aqui onde quando
porque quem qual quais cada todo toda todos todas muito muita outro outra outros outras mesmo mesma anos ano
dia dias vai vez veja saiba confira entenda diz dizem afirma revela anuncia aponta mostra fala segundo ser ter
fazer faz fez pode podem deve devem governo brasil brasileiro brasileira apos tambem agora hoje ontem pode
sobre novo nova novos novas veja ver uma dois tres quatro cinco mais menos ainda ja so nao sim
"""
STOPWORDS = frozenset(_stem(_norm(w)) for w in _STOP_RAW.split())

MAX_TERMS = 14
STORY_MIN_SHARED = 3
STORY_MIN_JACCARD = 0.45
STORY_LOOKBACK_HOURS = 48


# ---------------------------------------------------------------------------
# termos
# ---------------------------------------------------------------------------

def extract_terms(title, summary="", limit=MAX_TERMS):
    """Termos mais importantes: palavras do título (peso 2; +2 se é nome próprio
    no meio da frase) e do resumo (peso 1). Sem acento, no singular, sem stopwords."""
    weights = Counter()
    order = {}
    for idx, word in enumerate(_WORD_RE.findall(title or "")):
        key = _stem(_norm(word))
        if len(key) < 4 or key in STOPWORDS:
            continue
        w = 2 + (2 if (idx > 0 and word[0].isupper()) else 0)
        weights[key] += w
        order.setdefault(key, len(order))
    for word in _WORD_RE.findall(summary or ""):
        key = _stem(_norm(word))
        if len(key) < 4 or key in STOPWORDS:
            continue
        weights[key] += 1
        order.setdefault(key, len(order))
    ranked = sorted(weights, key=lambda k: (-weights[k], order[k]))
    return ranked[:limit]


def _loads(raw):
    try:
        return json.loads(raw or "[]")
    except ValueError:
        return []


# ---------------------------------------------------------------------------
# alimentar o banco
# ---------------------------------------------------------------------------

def _story_index(now):
    """termo -> [(story_id, set(termos))] das fichas recentes, para achar o mesmo fato."""
    since = now - timedelta(hours=STORY_LOOKBACK_HOURS)
    rows = (NewsBankItem.query
            .filter(NewsBankItem.created_at >= since, NewsBankItem.expires_at > now)
            .with_entities(NewsBankItem.story_id, NewsBankItem.terms).all())
    index, seen = {}, set()
    for story_id, raw in rows:
        terms = frozenset(_loads(raw))
        if (story_id, terms) in seen:
            continue
        seen.add((story_id, terms))
        entry = (story_id, terms)
        for t in terms:
            index.setdefault(t, []).append(entry)
    return index


def _match_story(terms, index):
    if len(terms) < STORY_MIN_SHARED:
        return None
    votes = Counter()
    ref = {}
    for t in terms:
        for story_id, tset in index.get(t, ()):
            key = (story_id, tset)
            votes[key] += 1
            ref[key] = (story_id, tset)
    for key, shared in votes.most_common(3):
        if shared < STORY_MIN_SHARED:
            break
        story_id, tset = ref[key]
        if shared / len(set(terms) | tset) >= STORY_MIN_JACCARD:
            return story_id
    return None


def add_articles(app, articles, extras=None):
    """Cria a ficha de cada NewsArticle (já gravada, com id) que ainda não tem uma.
    `extras`: {url_hash: {"tags": [...]}} — pistas do feed, só existem na indexação.
    Retorna quantas fichas foram criadas. Quem chama NÃO precisa dar commit."""
    extras = extras or {}
    now = utcnow()
    ttl = timedelta(days=app.config.get("NEWS_BANK_TTL_DAYS", 3))
    keywords = app.config["NEWS_CATEGORY_KEYWORDS"]
    ids = [a.id for a in articles if a.id]
    if not ids:
        return 0
    have = {r[0] for r in db.session.query(NewsBankItem.article_id)
            .filter(NewsBankItem.article_id.in_(ids)).all()}
    todo = [a for a in articles if a.id and a.id not in have]
    if not todo:
        return 0
    index = _story_index(now)
    created = 0
    for a in todo:
        # o prior da fonte NÃO entra: a categoria já foi decidida no indexador;
        # aqui só queremos as SECUNDÁRIAS e a confiança, pelo conteúdo
        info = classify_article(
            a.title, a.summary or "", keywords, url=a.url or "",
            tags=(extras.get(a.url_hash) or {}).get("tags", ()), prior=a.category,
        )
        terms = extract_terms(a.title, a.summary or "")
        story_id = _match_story(terms, index) or f"s{a.id}"  # 1ª notícia do fato dá nome ao grupo
        published = a.published_at or a.indexed_at or now
        # nasce da data da notícia: item antigo que só agora foi indexado vence junto
        expires = (a.indexed_at or now) + ttl
        if expires <= now:
            continue
        db.session.add(NewsBankItem(
            article_id=a.id, source_id=a.source_id, category=a.category,
            secondary=",".join(c for c in info.secondary if c != a.category),
            confidence=info.confidence if info.category == a.category else min(info.confidence, 0.3),
            terms=json.dumps(terms, ensure_ascii=False), story_id=story_id,
            published_at=published, created_at=now, expires_at=expires,
        ))
        entry = (story_id, frozenset(terms))
        for t in terms:
            index.setdefault(t, []).append(entry)
        created += 1
    db.session.flush()
    return created


def backfill(app, limit=1500):
    """Cria fichas para notícias recentes (dentro do TTL) que ainda não têm — sem
    rede. Popula o banco na primeira vez e repara depois de limpeza/reinício."""
    now = utcnow()
    ttl = timedelta(days=app.config.get("NEWS_BANK_TTL_DAYS", 3))
    since = now - ttl
    missing = (NewsArticle.query
               .outerjoin(NewsBankItem, NewsBankItem.article_id == NewsArticle.id)
               .filter(NewsBankItem.id.is_(None), NewsArticle.indexed_at >= since)
               .order_by(NewsArticle.indexed_at.asc()).limit(limit).all())
    created = add_articles(app, missing)
    db.session.commit()
    return created


def purge_expired(app):
    """Apaga fichas vencidas (3 dias), órfãs e o excedente acima do teto. Retorna quantas saíram."""
    now = utcnow()
    removed = NewsBankItem.query.filter(NewsBankItem.expires_at <= now).delete(synchronize_session=False)
    orphan_ids = [r[0] for r in db.session.query(NewsBankItem.id)
                  .outerjoin(NewsArticle, NewsArticle.id == NewsBankItem.article_id)
                  .filter(NewsArticle.id.is_(None)).all()]
    if orphan_ids:
        removed += NewsBankItem.query.filter(NewsBankItem.id.in_(orphan_ids)).delete(synchronize_session=False)
    cap = app.config.get("NEWS_BANK_MAX_ITEMS", 6000)
    total = NewsBankItem.query.count()
    if total > cap:
        old = [r[0] for r in db.session.query(NewsBankItem.id)
               .order_by(NewsBankItem.published_at.asc()).limit(total - cap).all()]
        removed += NewsBankItem.query.filter(NewsBankItem.id.in_(old)).delete(synchronize_session=False)
    db.session.commit()
    return removed


def maintain(app):
    """Rotina do agendador: apaga o vencido e recompleta o que faltar."""
    removed = purge_expired(app)
    created = backfill(app)
    return {"removed": removed, "created": created, "size": NewsBankItem.query.count()}


def stats():
    now = utcnow()
    live = NewsBankItem.query.filter(NewsBankItem.expires_at > now)
    by_cat = dict(db.session.query(NewsBankItem.category, db.func.count(NewsBankItem.id))
                  .filter(NewsBankItem.expires_at > now).group_by(NewsBankItem.category).all())
    oldest = db.session.query(db.func.min(NewsBankItem.created_at)).scalar()
    return {"items": live.count(), "by_category": by_cat, "oldest": oldest}


def size():
    return NewsBankItem.query.filter(NewsBankItem.expires_at > utcnow()).count()


# ---------------------------------------------------------------------------
# leitura (usada pelo recomendador)
# ---------------------------------------------------------------------------

def raw_pool(categories, category_filter, per_category, total_limit, allow_no_image):
    """Candidatos vivos do banco + cobertura/duplicatas pelo story_id.
    Devolve {"ids": [...mais recentes primeiro], "coverage": {id: n_veículos}, "duplicates": {ids}}."""
    now = utcnow()

    def base():
        q = (db.session.query(NewsBankItem.article_id, NewsBankItem.story_id,
                              NewsBankItem.source_id, NewsBankItem.published_at, NewsArticle.image_url)
             .join(NewsArticle, NewsArticle.id == NewsBankItem.article_id)
             .filter(NewsBankItem.expires_at > now))
        if not allow_no_image:
            q = q.filter(NewsArticle.image_url.isnot(None), NewsArticle.image_url != "")
        return q

    if category_filter:
        rows = (base().filter(NewsBankItem.category == category_filter)
                .order_by(NewsBankItem.published_at.desc()).limit(total_limit).all())
    else:
        rows, seen = [], set()
        for key, _label in categories:
            part = (base().filter(NewsBankItem.category == key)
                    .order_by(NewsBankItem.published_at.desc()).limit(per_category).all())
            for r in part:
                if r[0] not in seen:
                    seen.add(r[0])
                    rows.append(r)

    # agrupa por fato: melhor versão = com imagem, depois a mais recente
    groups = {}
    for r in rows:
        groups.setdefault(r[1], []).append(r)
    coverage, duplicates = {}, set()
    for members in groups.values():
        members.sort(key=lambda r: (bool(r[4]), r[3] or now), reverse=True)
        n_sources = len({m[2] for m in members})
        for pos, m in enumerate(members):
            coverage[m[0]] = n_sources
            if pos > 0:
                duplicates.add(m[0])
    ordered = sorted(rows, key=lambda r: r[3] or now, reverse=True)
    return {"ids": [r[0] for r in ordered], "coverage": coverage, "duplicates": duplicates}


def info_for(article_ids):
    """{article_id: {"terms": set, "secondary": tuple, "confidence": float}} das fichas vivas."""
    ids = list(article_ids)
    out = {}
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        for aid, terms, sec, conf in (db.session.query(
                NewsBankItem.article_id, NewsBankItem.terms, NewsBankItem.secondary, NewsBankItem.confidence)
                .filter(NewsBankItem.article_id.in_(chunk)).all()):
            out[aid] = {"terms": set(_loads(terms)),
                        "secondary": tuple(c for c in (sec or "").split(",") if c),
                        "confidence": conf}
    return out
