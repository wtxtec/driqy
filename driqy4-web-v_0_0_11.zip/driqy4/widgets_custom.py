"""\"Minha área\": widgets criados pelo próprio usuário (nota, tarefas, atalhos, contagem, contador).

Tudo que entra passa por `clean_data` — o servidor nunca confia no formato que o cliente manda.
Id público no seletor: `custom:<id>`.
"""
import json
import secrets
from datetime import date
from urllib.parse import urlparse

from flask import current_app

from extensions import db
from models import UserWidget

KINDS = {
    "note": {"title": "Nota", "desc": "Um bloco de texto livre"},
    "checklist": {"title": "Tarefas", "desc": "Lista com itens para marcar"},
    "links": {"title": "Atalhos", "desc": "Seus links favoritos"},
    "countdown": {"title": "Contagem", "desc": "Quantos dias faltam para uma data"},
    "counter": {"title": "Contador", "desc": "Some e subtraia, com meta opcional"},
}
MAX_TITLE = 40
MAX_NOTE = 2000
MAX_ITEMS = 50
MAX_ITEM_TEXT = 120
MAX_LINKS = 12
MAX_URL = 500
MAX_JSON = 12000
COUNTER_LIMIT = 999_999


def default_data(kind):
    return {
        "note": {"text": ""},
        "checklist": {"items": []},
        "links": {"links": []},
        "countdown": {"label": "", "date": ""},
        "counter": {"value": 0, "step": 1, "goal": None, "unit": ""},
    }[kind]


def _str(v, limit):
    return " ".join(str(v if v is not None else "").split())[:limit]


def _int(v, lo, hi, default=0):
    try:
        n = int(v)
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, n))


def clean_url(raw):
    u = str(raw or "").strip()
    if not u or len(u) > MAX_URL or any(c.isspace() for c in u):
        raise ValueError("Link inválido.")
    if "://" not in u:
        u = "https://" + u
    p = urlparse(u)
    if p.scheme not in ("http", "https") or not p.netloc or "." not in p.netloc.split("@")[-1]:
        raise ValueError("Use um link http ou https.")
    return u


def clean_data(kind, raw):
    """Devolve o `data` normalizado do tipo ou levanta ValueError com mensagem em português."""
    if kind not in KINDS:
        raise ValueError("Tipo de widget desconhecido.")
    raw = raw if isinstance(raw, dict) else {}
    if kind == "note":
        text = str(raw.get("text") or "").replace("\r\n", "\n")
        if len(text) > MAX_NOTE:
            raise ValueError(f"A nota passou de {MAX_NOTE} caracteres.")
        return {"text": text}
    if kind == "checklist":
        items, seen = [], set()
        src = raw.get("items") if isinstance(raw.get("items"), list) else []
        if len(src) > MAX_ITEMS:
            raise ValueError(f"No máximo {MAX_ITEMS} itens.")
        for it in src:
            it = it if isinstance(it, dict) else {}
            text = _str(it.get("text"), MAX_ITEM_TEXT)
            if not text:
                continue
            iid = str(it.get("id") or "")
            if not (iid.isalnum() and len(iid) <= 12) or iid in seen:
                iid = secrets.token_hex(4)
            seen.add(iid)
            items.append({"id": iid, "text": text, "done": bool(it.get("done"))})
        return {"items": items}
    if kind == "links":
        out = []
        src = raw.get("links") if isinstance(raw.get("links"), list) else []
        if len(src) > MAX_LINKS:
            raise ValueError(f"No máximo {MAX_LINKS} atalhos.")
        for it in src:
            it = it if isinstance(it, dict) else {}
            url = clean_url(it.get("url"))
            title = _str(it.get("title"), MAX_TITLE) or urlparse(url).netloc.replace("www.", "")
            out.append({"title": title, "url": url})
        return {"links": out}
    if kind == "countdown":
        label = _str(raw.get("label"), MAX_TITLE)
        d = str(raw.get("date") or "").strip()
        if d:
            try:
                date.fromisoformat(d)
            except ValueError:
                raise ValueError("Data inválida (use AAAA-MM-DD).")
        return {"label": label, "date": d}
    # counter
    goal = raw.get("goal")
    goal = None if goal in (None, "") else _int(goal, 1, COUNTER_LIMIT, None)
    return {"value": _int(raw.get("value"), -COUNTER_LIMIT, COUNTER_LIMIT, 0),
            "step": _int(raw.get("step"), 1, 1000, 1), "goal": goal, "unit": _str(raw.get("unit"), 12)}


def serialize(w):
    try:
        data = json.loads(w.data_json or "{}")
    except ValueError:
        data = {}
    try:
        data = clean_data(w.kind, data)
    except ValueError:
        data = default_data(w.kind)
    return {"id": f"custom:{w.id}", "widget_id": w.id, "kind": w.kind, "title": w.title or KINDS[w.kind]["title"],
            "custom": True, "desc": KINDS[w.kind]["desc"], "data": data,
            "updated_at": w.updated_at.isoformat() + "Z" if w.updated_at else None}


def list_for_user(user):
    return (UserWidget.query.filter_by(user_id=user.id).order_by(UserWidget.id.asc()).all())


def ids_for_user(user):
    return [f"custom:{r[0]}" for r in db.session.query(UserWidget.id)
            .filter_by(user_id=user.id).order_by(UserWidget.id.asc()).all()]


def get_for_user(user, wid):
    return UserWidget.query.filter_by(id=wid, user_id=user.id).first()


def create(user, kind, title, data):
    if kind not in KINDS:
        raise ValueError("Tipo de widget desconhecido.")
    limit = current_app.config.get("MAX_USER_WIDGETS", 12)
    if UserWidget.query.filter_by(user_id=user.id).count() >= limit:
        raise ValueError(f"Limite de {limit} widgets próprios atingido.")
    clean = clean_data(kind, data if data is not None else default_data(kind))
    if len(json.dumps(clean, ensure_ascii=False)) > MAX_JSON:
        raise ValueError("Conteúdo grande demais.")
    w = UserWidget(user_id=user.id, kind=kind, title=_str(title, MAX_TITLE) or KINDS[kind]["title"],
                   data_json=json.dumps(clean, ensure_ascii=False))
    db.session.add(w)
    db.session.commit()
    return w


def update(w, title=None, data=None):
    if title is not None:
        w.title = _str(title, MAX_TITLE) or KINDS[w.kind]["title"]
    if data is not None:
        clean = clean_data(w.kind, data)
        if len(json.dumps(clean, ensure_ascii=False)) > MAX_JSON:
            raise ValueError("Conteúdo grande demais.")
        w.data_json = json.dumps(clean, ensure_ascii=False)
    db.session.commit()
    return w
