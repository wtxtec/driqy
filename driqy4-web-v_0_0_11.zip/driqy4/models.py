from datetime import datetime, timedelta, timezone
import secrets

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db


def utcnow():
    """Data/hora atual em UTC, sem timezone (naive).

    `datetime.utcnow()` está depreciado a partir do Python 3.12+. O
    substituto oficial, `datetime.now(timezone.utc)`, retorna um objeto
    "aware" (com tzinfo) — mas todas as colunas DateTime deste projeto (e os
    dados já salvos no banco) são "naive". Comparar um datetime aware com um
    naive levanta TypeError, então removemos o tzinfo aqui pra manter o
    mesmo comportamento de antes, só sem o aviso de depreciação.
    """
    return datetime.now(timezone.utc).replace(tzinfo=None)


# Todo horário salvo no banco é UTC (naive). O Brasil não usa mais horário
# de verão desde 2019, então o horário de Brasília é sempre UTC-3 fixo —
# não precisa de biblioteca de timezone, só subtrair 3 horas na hora de
# exibir pro usuário.
BRASILIA_OFFSET = timedelta(hours=-3)

# Post permanente (sem expiração): em vez de tornar `expires_at` /
# `duration_minutes` nuláveis (exigiria recriar a tabela `posts` no SQLite),
# o post permanente guarda duration_minutes = 0 e expires_at = esta data
# distante. Assim todas as consultas `expires_at > agora` e o scheduler de
# limpeza continuam funcionando sem nenhuma alteração.
PERMANENT_EXPIRES_AT = datetime(9999, 12, 31, 23, 59, 59)


def to_brasilia(dt):
    """Converte um datetime UTC (naive) salvo no banco para o horário de
    Brasília, só para exibição — o banco continua guardando tudo em UTC."""
    if dt is None:
        return None
    return dt + BRASILIA_OFFSET


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)

    # preenchido quando a conta foi criada (ou vinculada) via "Entrar com
    # Google" — o "sub" (id único e permanente) da conta Google da pessoa
    google_id = db.Column(db.String(255), unique=True, nullable=True, index=True)

    # recuperação de senha por e-mail
    reset_token = db.Column(db.String(64), unique=True, nullable=True, index=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)

    # personalização de perfil
    display_name = db.Column(db.String(50), default="")
    bio = db.Column(db.String(280), default="")
    location = db.Column(db.String(80), default="")
    # coordenadas da cidade escolhida na sugestão (centro da cidade, não o endereço); servem
    # para o clima. Nulas quando o texto foi digitado à mão.
    location_lat = db.Column(db.Float, nullable=True)
    location_lng = db.Column(db.Float, nullable=True)
    # fuso do usuário (nome IANA, ex. "Asia/Tokyo"), guardado quando o site manda `tz` aos widgets; serve para os
    # avisos de estação saírem na hora local dele. Nulo = Brasília.
    tz_name = db.Column(db.String(64), nullable=True)
    # personalização do painel direito (JSON): ver `api_widgets.normalize_prefs`
    rail_prefs = db.Column(db.Text, nullable=True)
    accent_color = db.Column(db.String(20), default="amber")
    avatar_filename = db.Column(db.String(255), nullable=True)
    cover_filename = db.Column(db.String(255), nullable=True)

    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_moderator = db.Column(db.Boolean, default=False, nullable=False)
    is_banned = db.Column(db.Boolean, default=False, nullable=False)
    is_verified = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    # atualizado a cada requisição autenticada (ver app.py) — usado pra
    # saber quem está "online" agora no painel de administração
    last_seen_at = db.Column(db.DateTime, nullable=True)

    # Fase 10: privacidade do chat — False esconde "online"/"visto por último" (e,
    # como no WhatsApp, quem esconde o seu também não vê o dos outros)
    show_presence = db.Column(db.Boolean, default=True, nullable=False, server_default="1")

    # contadores permanentes usados no ranking (não somem quando os posts expiram)
    total_likes_received = db.Column(db.Integer, default=0, nullable=False)
    total_comments_received = db.Column(db.Integer, default=0, nullable=False)

    posts = db.relationship(
        "Post", backref="author", lazy="dynamic", cascade="all, delete-orphan"
    )
    comments = db.relationship(
        "Comment", backref="author", lazy="dynamic", cascade="all, delete-orphan"
    )
    likes = db.relationship(
        "Like", backref="user", lazy="dynamic", cascade="all, delete-orphan"
    )

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def set_unusable_password(self):
        """Usado em contas criadas via login com Google: gera um hash
        aleatório impossível de adivinhar, já que a pessoa não define uma
        senha própria. Ela pode criar uma depois pela tela "Esqueci senha"."""
        self.password_hash = generate_password_hash(secrets.token_urlsafe(32))

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def generate_reset_token(self, expires_minutes=60):
        """Gera um token aleatório e imprevisível pra redefinição de senha."""
        self.reset_token = secrets.token_urlsafe(32)
        self.reset_token_expires = utcnow() + timedelta(minutes=expires_minutes)
        return self.reset_token

    def verify_reset_token(self, token):
        return (
            bool(token)
            and self.reset_token
            and secrets.compare_digest(self.reset_token, token)
            and self.reset_token_expires is not None
            and self.reset_token_expires > utcnow()
        )

    def clear_reset_token(self):
        self.reset_token = None
        self.reset_token_expires = None

    @property
    def is_online(self):
        """Considerado 'online' se teve alguma requisição nos últimos 5 minutos."""
        if not self.last_seen_at:
            return False
        return (utcnow() - self.last_seen_at) <= timedelta(minutes=5)

    @property
    def display_label(self):
        return self.display_name.strip() if self.display_name and self.display_name.strip() else self.username

    @property
    def is_staff(self):
        """Admins e moderadores, juntos: quem tem poder de moderação."""
        return self.is_admin or self.is_moderator

    @property
    def badge_kind(self):
        """
        Define qual selo aparece ao lado do nome do usuário.
        Admins e moderadores recebem um selo especial (mais alto na hierarquia
        que o selo azul de verificação normal), mesmo que 'is_verified' seja falso.
        """
        if self.is_admin:
            return "admin"
        if self.is_moderator:
            return "mod"
        if self.is_verified:
            return "verified"
        return None

    # --- helpers de relacionamento (seguir / seguidores) ---
    def is_following(self, other_user):
        return Follow.query.filter_by(
            follower_id=self.id, followed_id=other_user.id
        ).first() is not None

    def follow(self, other_user):
        if other_user.id == self.id or self.is_following(other_user):
            return False
        db.session.add(Follow(follower_id=self.id, followed_id=other_user.id))
        return True

    def unfollow(self, other_user):
        link = Follow.query.filter_by(
            follower_id=self.id, followed_id=other_user.id
        ).first()
        if link:
            db.session.delete(link)
            return True
        return False

    def has_liked(self, post):
        return Like.query.filter_by(user_id=self.id, post_id=post.id).first() is not None

    @property
    def followers_count(self):
        return Follow.query.filter_by(followed_id=self.id).count()

    @property
    def following_count(self):
        return Follow.query.filter_by(follower_id=self.id).count()

    @property
    def active_posts_count(self):
        return self.posts.filter(Post.expires_at > utcnow()).count()

    @property
    def unread_notifications_count(self):
        return Notification.query.filter_by(recipient_id=self.id, is_read=False).count()

    @property
    def unread_messages_count(self):
        return Message.query.filter(
            Message.recipient_id == self.id, Message.is_read.is_(False), not_hidden_for(self.id)
        ).count()

    @property
    def ranking_score(self):
        from flask import current_app
        w_likes = current_app.config.get("RANK_WEIGHT_LIKES", 2)
        w_comments = current_app.config.get("RANK_WEIGHT_COMMENTS", 1)
        w_followers = current_app.config.get("RANK_WEIGHT_FOLLOWERS", 3)
        return (
            self.total_likes_received * w_likes
            + self.total_comments_received * w_comments
            + self.followers_count * w_followers
        )

    def get_id(self):
        # sobrescreve para permitir invalidar sessão de usuários banidos
        return str(self.id)

    @property
    def is_active(self):
        return not self.is_banned

    def __repr__(self):
        return f"<User {self.username}>"


class ApiToken(db.Model):
    """
    Token de acesso ("Bearer") usado pelo app Flutter para autenticar
    chamadas à API JSON (/api/v1/...), já que o app não guarda cookie de
    sessão como o navegador. Um usuário pode ter vários tokens (um por
    aparelho onde fez login); cada um pode ser revogado individualmente
    fazendo logout naquele aparelho.
    """
    __tablename__ = "api_tokens"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    token = db.Column(db.String(64), unique=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=utcnow)
    last_used_at = db.Column(db.DateTime, nullable=True)

    user = db.relationship("User", foreign_keys=[user_id])

    @staticmethod
    def generate_for(user):
        token = ApiToken(user_id=user.id, token=secrets.token_hex(32))
        db.session.add(token)
        return token

    def __repr__(self):
        return f"<ApiToken user={self.user_id}>"


class Follow(db.Model):
    __tablename__ = "follows"

    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    followed_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    follower = db.relationship("User", foreign_keys=[follower_id])
    followed = db.relationship("User", foreign_keys=[followed_id])

    __table_args__ = (
        db.UniqueConstraint("follower_id", "followed_id", name="uix_follow_pair"),
    )


class Post(db.Model):
    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    post_type = db.Column(db.String(10), nullable=False)  # text | photo | video | gif | audio
    text_content = db.Column(db.Text, nullable=True)
    media_filename = db.Column(db.String(255), nullable=True)

    duration_minutes = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    views_count = db.Column(db.Integer, default=0, nullable=False)
    # de onde o post foi publicado (iphone | android | web), usado para
    # mostrar o selo "Post via iPhone/Android" como no Twitter/X
    source_client = db.Column(db.String(20), nullable=True)

    comments = db.relationship(
        "Comment", backref="post", lazy="dynamic",
        cascade="all, delete-orphan", order_by="Comment.created_at.asc()",
    )
    post_likes = db.relationship(
        "Like", backref="post", lazy="dynamic", cascade="all, delete-orphan"
    )
    media_items = db.relationship(
        "PostMedia", backref="post", lazy="select",
        cascade="all, delete-orphan", order_by="PostMedia.position.asc()",
    )

    def __init__(self, **kwargs):
        if not kwargs.get("duration_minutes"):
            # sem duração = post permanente
            kwargs["duration_minutes"] = 0
            kwargs.setdefault("expires_at", PERMANENT_EXPIRES_AT)
        super().__init__(**kwargs)
        if not self.created_at:
            self.created_at = utcnow()
        if not self.expires_at and self.duration_minutes:
            self.expires_at = self.created_at + timedelta(minutes=self.duration_minutes)

    @property
    def is_temporary(self):
        """True se o autor escolheu uma duração; False = post permanente."""
        return bool(self.duration_minutes) and self.duration_minutes > 0

    @property
    def seconds_remaining(self):
        delta = (self.expires_at - utcnow()).total_seconds()
        return max(0, int(delta))

    _PT_MONTHS_ABBR = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]

    @property
    def expires_label(self):
        """Texto tipo 'Expira em 178 dias', mostrado no rodapé do post (ver
        countdown.js pra versão que se atualiza sozinha no navegador).
        Vazio para post permanente."""
        if not self.is_temporary:
            return ""
        seconds = self.seconds_remaining
        if seconds <= 0:
            return "Expirado"
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        minutes = (seconds % 3600) // 60
        if days > 0:
            return f"Expira em {days} dia{'s' if days != 1 else ''}"
        if hours > 0:
            return f"Expira em {hours} hora{'s' if hours != 1 else ''}"
        if minutes > 0:
            return f"Expira em {minutes} minuto{'s' if minutes != 1 else ''}"
        return "Expira em instantes"

    @property
    def published_label(self):
        """Texto tipo 'Publicado em 21 de Jul de 2025 às 22:42' (horário de Brasília)."""
        dt = to_brasilia(self.created_at)
        month = self._PT_MONTHS_ABBR[dt.month - 1]
        return f"Publicado em {dt.day} de {month} de {dt.year} às {dt.strftime('%H:%M')}"

    @property
    def is_expired(self):
        return utcnow() >= self.expires_at

    @property
    def likes_count(self):
        return self.post_likes.count()

    @property
    def comments_count(self):
        return self.comments.count()

    @property
    def display_media(self):
        """
        Lista de mídias do post, em ordem, pronta para os templates.
        Usa as linhas em `post_media` quando existirem (posts com múltiplos
        arquivos); se não houver nenhuma, cai para `media_filename`, o campo
        legado usado por posts criados antes do suporte a múltiplas mídias.
        Cada item é um dict com "filename" e "media_type".
        """
        if self.media_items:
            return [{"filename": m.filename, "media_type": m.media_type} for m in self.media_items]
        if self.media_filename:
            media_type = self.post_type if self.post_type in ("photo", "video", "gif", "audio") else "photo"
            return [{"filename": self.media_filename, "media_type": media_type}]
        return []

    @property
    def media_count(self):
        return len(self.media_items) if self.media_items else (1 if self.media_filename else 0)

    def all_media_filenames(self):
        """Todos os nomes de arquivo associados ao post (novos e legados), sem duplicatas."""
        names = {m.filename for m in self.media_items}
        if self.media_filename:
            names.add(self.media_filename)
        return names

    def __repr__(self):
        return f"<Post {self.id} by user {self.user_id} ({self.post_type})>"


class PostMedia(db.Model):
    """
    Um arquivo de mídia (foto, vídeo ou GIF) dentro de um post.
    Um post pode ter várias linhas aqui (até o limite configurado em
    MAX_MEDIA_ITEMS), permitindo publicar várias fotos e vídeos juntos,
    exibidos em grade e abertos num carrossel ao clicar.
    """
    __tablename__ = "post_media"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False, index=True)
    filename = db.Column(db.String(255), nullable=False)
    media_type = db.Column(db.String(10), nullable=False)  # photo | video | gif | audio
    position = db.Column(db.Integer, default=0, nullable=False)

    def __repr__(self):
        return f"<PostMedia {self.id} post={self.post_id} ({self.media_type})>"


class Like(db.Model):
    __tablename__ = "likes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    __table_args__ = (
        db.UniqueConstraint("user_id", "post_id", name="uix_like_pair"),
    )


class Comment(db.Model):
    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    parent_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=True, index=True)
    content = db.Column(db.String(300), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    replies = db.relationship(
        "Comment",
        backref=db.backref("parent", remote_side=[id]),
        order_by="Comment.created_at.asc()",
        lazy="dynamic",
    )

    def __repr__(self):
        return f"<Comment {self.id} on post {self.post_id}>"


class DeviceToken(db.Model):
    """
    Token do FCM (Firebase Cloud Messaging) de um aparelho onde o app
    Flutter está instalado e logado — é pra esse token que o backend
    manda o push (ver push.py). Um usuário pode ter vários (aparelhos
    diferentes); o token em si é único porque o mesmo aparelho, ao
    logar em outra conta, deve passar a apontar pro novo usuário (por
    isso `unique=True` e o registro faz upsert por token, não por
    usuário — ver api.py `register_device`).
    """
    __tablename__ = "device_tokens"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    token = db.Column(db.String(255), unique=True, nullable=False, index=True)
    platform = db.Column(db.String(10), nullable=True)  # "android" | "ios"
    created_at = db.Column(db.DateTime, default=utcnow)

    user = db.relationship("User", backref=db.backref("device_tokens", cascade="all, delete-orphan"))


class Notification(db.Model):
    """
    Notificação enviada a um usuário quando alguém curte um post dele,
    comenta em um post dele, ou passa a segui-lo.
    `post` e `comment` são opcionais e podem ficar "órfãos" (apontando para
    um id que não existe mais) se o post expirar e for removido depois da
    notificação ser criada — os templates tratam isso mostrando só o texto.
    """
    __tablename__ = "notifications"

    KIND_LIKE = "like"
    KIND_COMMENT = "comment"
    KIND_FOLLOW = "follow"
    KIND_REPLY = "reply"
    # Aviso do sistema (virada de estação). Não tem autor de verdade: `actor_id` aponta para o próprio
    # destinatário (a coluna é obrigatória) e quem desenha a notificação ignora o autor neste tipo.
    KIND_SEASON = "season"

    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    kind = db.Column(db.String(20), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True)
    comment_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=True)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, index=True)
    # Texto pronto, usado só pelos avisos do sistema (kind "season").
    text = db.Column(db.String(200), nullable=True)

    recipient = db.relationship(
        "User", foreign_keys=[recipient_id],
        backref=db.backref("notifications", lazy="dynamic", cascade="all, delete-orphan",
                            order_by="Notification.created_at.desc()"),
    )
    actor = db.relationship("User", foreign_keys=[actor_id])
    post = db.relationship("Post")
    comment = db.relationship("Comment")

    @property
    def verb(self):
        if self.kind == self.KIND_SEASON:
            return self.text or ""
        return {
            self.KIND_LIKE: "curtiu seu post",
            self.KIND_COMMENT: "comentou no seu post",
            self.KIND_FOLLOW: "começou a seguir você",
            self.KIND_REPLY: "respondeu seu comentário",
        }.get(self.kind, "")

    def __repr__(self):
        return f"<Notification {self.kind} -> {self.recipient_id}>"


class AdminActionLog(db.Model):
    """
    Registro de ações de moderação/administração (banir, verificar, excluir
    post, etc.) — só pra dar transparência de quem fez o quê e quando no
    painel admin. Não afeta nenhuma regra de negócio, é só um histórico.
    """
    __tablename__ = "admin_action_logs"

    id = db.Column(db.Integer, primary_key=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    action = db.Column(db.String(40), nullable=False)  # ex: "banir_usuario", "excluir_post"
    target_label = db.Column(db.String(120), nullable=False)  # ex: "@fulano", "post #123"
    created_at = db.Column(db.DateTime, default=utcnow, index=True)

    actor = db.relationship("User", foreign_keys=[actor_id])

    def __repr__(self):
        return f"<AdminActionLog {self.action} by {self.actor_id}>"


def log_admin_action(actor, action, target_label):
    db.session.add(AdminActionLog(actor_id=actor.id, action=action, target_label=target_label))


class Message(db.Model):
    """
    Mensagem direta trocada entre dois usuários (chat 1-para-1).
    Uma "conversa" não tem tabela própria: é simplesmente o conjunto de
    mensagens onde (sender, recipient) é um par de usuários, em qualquer
    ordem — ver as consultas em chat.py.
    """
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    # texto da mensagem OU legenda da mídia. Em mídia sem legenda guarda um
    # rótulo ("📷 Foto"), pra site e apps antigos mostrarem algo útil.
    content = db.Column(db.String(2000), nullable=False)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, index=True)

    # --- chat rico (Fase 1) — tudo opcional/com padrão, mensagens antigas
    # continuam valendo como texto ---
    # text | image | video | audio | file | call (a ligação entra na Fase 10)
    msg_type = db.Column(db.String(12), default="text", nullable=False, server_default="text")
    # caminho RELATIVO em UPLOAD_FOLDER (chat/AAAA/MM/...). Mídia de chat é
    # privada: NUNCA é servida por /uploads, só por /api/v1/messages/media/<id>
    media_path = db.Column(db.String(255), nullable=True)
    media_mime = db.Column(db.String(60), nullable=True)
    media_size = db.Column(db.Integer, nullable=True)
    media_duration_ms = db.Column(db.Integer, nullable=True)
    media_width = db.Column(db.Integer, nullable=True)
    media_height = db.Column(db.Integer, nullable=True)
    # Fase 15: nome ORIGINAL do arquivo enviado (msg_type=file), só para exibir/baixar
    media_name = db.Column(db.String(255), nullable=True)
    reply_to_id = db.Column(db.Integer, db.ForeignKey("messages.id"), nullable=True)
    # idempotência: o app gera o id antes de enviar; reenvio não duplica
    client_id = db.Column(db.String(40), nullable=True, index=True)
    delivered_at = db.Column(db.DateTime, nullable=True)
    read_at = db.Column(db.DateTime, nullable=True)
    edited_at = db.Column(db.DateTime, nullable=True)
    # "apagar para todos": a linha fica (mantém a ordem), o conteúdo é limpo
    deleted_at = db.Column(db.DateTime, nullable=True)
    # Fase 8: mensagem encaminhada (mostra o rótulo "Encaminhada")
    forwarded = db.Column(db.Boolean, default=False, nullable=False, server_default="0")
    # Visualização única (foto/vídeo/áudio): o destinatário abre UMA vez; ao fechar (ou passar a
    # janela) a mídia sai do disco e a linha fica como "Aberta". O remetente nunca reabre.
    view_once = db.Column(db.Boolean, default=False, nullable=False, server_default="0")
    view_once_opened_at = db.Column(db.DateTime, nullable=True)

    sender = db.relationship("User", foreign_keys=[sender_id])
    recipient = db.relationship("User", foreign_keys=[recipient_id])

    def __repr__(self):
        return f"<Message {self.id} {self.sender_id} -> {self.recipient_id}>"


class MessageHidden(db.Model):
    """"Apagar para mim": esconde a mensagem só para `user_id` (a linha e a
    mídia continuam para o outro participante). Quando os DOIS escondem, o
    servidor apaga a mídia do disco (ver api.py::_purge_message)."""
    __tablename__ = "message_hidden"
    __table_args__ = (db.UniqueConstraint("message_id", "user_id", name="uq_hidden_message_user"),)

    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.Integer, db.ForeignKey("messages.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=utcnow)


class ConversationPref(db.Model):
    """Fase 10: preferências de `user_id` sobre a conversa com `partner_id` — fixar,
    silenciar e arquivar. Só vale para quem configurou (o outro lado não é afetado)."""
    __tablename__ = "conversation_prefs"
    __table_args__ = (db.UniqueConstraint("user_id", "partner_id", name="uq_convpref_user_partner"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    partner_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    pinned_at = db.Column(db.DateTime, nullable=True)      # não nulo = fixada (mais nova no topo)
    muted = db.Column(db.Boolean, default=False, nullable=False)
    archived = db.Column(db.Boolean, default=False, nullable=False)
    # Ping fase 6b: mensagem fixada no topo da conversa (só para `user_id`; uma por conversa).
    # Sem FK de propósito: se a mensagem some, o servidor só deixa de mostrar a faixa.
    pinned_message_id = db.Column(db.Integer, nullable=True)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)


class Call(db.Model):
    """Fase 11: chamada de voz/vídeo 1-para-1 (só a SINALIZAÇÃO; o áudio/vídeo trafega
    direto entre os aparelhos por WebRTC). `state`: ringing | accepted | declined | missed |
    ended | failed | busy. `offer_sdp`/`answer_sdp` ficam aqui só enquanto a chamada está
    viva (para quem conecta atrasado) e são zerados ao terminar."""
    __tablename__ = "calls"

    id = db.Column(db.Integer, primary_key=True)
    caller_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    callee_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    media = db.Column(db.String(8), nullable=False, default="voice")   # voice | video
    state = db.Column(db.String(12), nullable=False, default="ringing", index=True)
    end_reason = db.Column(db.String(24), nullable=True)  # canceled|timeout|hangup|declined|busy|stale|error
    client_id = db.Column(db.String(64), nullable=True)
    offer_sdp = db.Column(db.Text, nullable=True)
    answer_sdp = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    answered_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    heartbeat_at = db.Column(db.DateTime, nullable=True)

    caller = db.relationship("User", foreign_keys=[caller_id])
    callee = db.relationship("User", foreign_keys=[callee_id])


def not_hidden_for(user_id):
    """Filtro SQLAlchemy: mensagens que `user_id` NÃO escondeu ("apagar para mim")."""
    hidden = db.session.query(MessageHidden.message_id).filter(MessageHidden.user_id == user_id)
    return ~Message.id.in_(hidden)


class MessageReaction(db.Model):
    """Reação (emoji) de um usuário a uma mensagem. Uma por usuário por
    mensagem (como no WhatsApp): reagir de novo troca o emoji."""
    __tablename__ = "message_reactions"
    __table_args__ = (db.UniqueConstraint("message_id", "user_id", name="uq_reaction_message_user"),)

    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.Integer, db.ForeignKey("messages.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    emoji = db.Column(db.String(16), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    def __repr__(self):
        return f"<MessageReaction {self.message_id} {self.user_id} {self.emoji}>"


class ChatGroup(db.Model):
    """Mensagens — parte 3: grupo de conversa. Tabelas à parte do chat 1-para-1 (`messages`
    não muda). Só texto por enquanto (mídia em grupo fica para depois)."""
    __tablename__ = "chat_groups"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60), nullable=False)
    description = db.Column(db.String(200), nullable=False, default="", server_default="")
    avatar_filename = db.Column(db.String(255), nullable=True)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    members = db.relationship("ChatGroupMember", backref="group", cascade="all, delete-orphan", lazy="dynamic")
    messages = db.relationship("ChatGroupMessage", backref="group", cascade="all, delete-orphan", lazy="dynamic",
                               foreign_keys="ChatGroupMessage.group_id")


class ChatGroupMember(db.Model):
    """Participante do grupo. `role`: owner | admin | member. `start_after_id`: o membro só vê mensagens
    com id MAIOR que isso (quem entra depois não vê o histórico). `last_read_id`: até onde já leu."""
    __tablename__ = "chat_group_members"
    __table_args__ = (db.UniqueConstraint("group_id", "user_id", name="uq_group_member"),)

    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey("chat_groups.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    role = db.Column(db.String(8), nullable=False, default="member", server_default="member")
    joined_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    start_after_id = db.Column(db.Integer, nullable=False, default=0, server_default="0")
    last_read_id = db.Column(db.Integer, nullable=False, default=0, server_default="0")
    pinned_at = db.Column(db.DateTime, nullable=True)
    muted = db.Column(db.Boolean, nullable=False, default=False, server_default="0")
    archived = db.Column(db.Boolean, nullable=False, default=False, server_default="0")

    user = db.relationship("User", foreign_keys=[user_id])


class ChatGroupMessage(db.Model):
    """Mensagem de grupo. `kind`: text | system (\"Ana criou o grupo\", entradas/saídas…).
    Apagar para todos limpa o conteúdo e mantém a linha (como no chat 1-para-1)."""
    __tablename__ = "chat_group_messages"

    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey("chat_groups.id"), nullable=False, index=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    kind = db.Column(db.String(8), nullable=False, default="text", server_default="text")
    content = db.Column(db.String(2000), nullable=False)
    reply_to_id = db.Column(db.Integer, db.ForeignKey("chat_group_messages.id"), nullable=True)
    client_id = db.Column(db.String(40), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False, index=True)
    edited_at = db.Column(db.DateTime, nullable=True)
    deleted_at = db.Column(db.DateTime, nullable=True)

    sender = db.relationship("User", foreign_keys=[sender_id])


class NewsSource(db.Model):
    """Um feed RSS de veículo de notícias que o indexador varre periodicamente."""
    __tablename__ = "news_sources"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    feed_url = db.Column(db.String(500), nullable=False, unique=True)
    # quando definida, essa é a categoria editorial da própria fonte (ex.:
    # feed "G1 - Tecnologia" já é só sobre tecnologia) e é usada
    # diretamente, sem passar pelo classificador por palavras-chave —
    # fontes genéricas (ex.: G1, Folha) deixam isso em branco e cada
    # artigo é classificado individualmente pelo conteúdo
    default_category = db.Column(db.String(30), nullable=True)
    active = db.Column(db.Boolean, default=True, nullable=False)
    last_indexed_at = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f"<NewsSource {self.name}>"


class NewsArticle(db.Model):
    """
    Uma notícia indexada a partir de um NewsSource. Guardamos só
    título/resumo/link/imagem (nunca o conteúdo completo do artigo) — o
    usuário sempre lê a matéria completa no site de origem.
    """
    __tablename__ = "news_articles"

    id = db.Column(db.Integer, primary_key=True)
    source_id = db.Column(db.Integer, db.ForeignKey("news_sources.id"), nullable=False, index=True)
    title = db.Column(db.String(300), nullable=False)
    summary = db.Column(db.String(500), default="")
    url = db.Column(db.String(700), nullable=False)
    # hash do link, usado pra checar duplicidade rápido (índice único menor
    # que indexar a URL inteira, que pode passar de 700 caracteres)
    url_hash = db.Column(db.String(64), nullable=False, unique=True, index=True)
    image_url = db.Column(db.String(700), nullable=True)
    category = db.Column(db.String(30), nullable=False, default="geral", index=True)
    published_at = db.Column(db.DateTime, nullable=True, index=True)
    indexed_at = db.Column(db.DateTime, default=utcnow, index=True)
    views_count = db.Column(db.Integer, default=0, nullable=False)
    clicks_count = db.Column(db.Integer, default=0, nullable=False)
    # quantas vezes o indexador já tentou (sem sucesso) buscar uma imagem
    # pra essa notícia depois da indexação inicial — usado pelo job de
    # retry (news_indexer.retry_missing_images) pra não ficar tentando pra
    # sempre um artigo cuja página de origem simplesmente não tem imagem
    image_fetch_attempts = db.Column(db.Integer, default=0, nullable=False)

    source = db.relationship("NewsSource", backref="articles")

    def __repr__(self):
        return f"<NewsArticle {self.title[:40]!r}>"


class NewsBankItem(db.Model):
    """
    BANCO DE NOTÍCIAS TEMPORÁRIO (ver news_bank.py). Cada notícia indexada ganha
    aqui uma "ficha" já analisada — categoria principal e secundárias, termos
    mais importantes, grupo do mesmo fato (story_id) — que o recomendador
    consulta no lugar de reanalisar tudo a cada pedido. Vence sozinha em
    `expires_at` (config NEWS_BANK_TTL_DAYS = 3 dias) e é apagada pelo
    agendador; a NewsArticle original continua existindo (14 dias).
    """
    __tablename__ = "news_bank"

    id = db.Column(db.Integer, primary_key=True)
    article_id = db.Column(db.Integer, db.ForeignKey("news_articles.id"), nullable=False, unique=True, index=True)
    source_id = db.Column(db.Integer, nullable=False, index=True)
    category = db.Column(db.String(30), nullable=False, index=True)
    # outras categorias que a matéria também toca ("politica,economia"), por força
    secondary = db.Column(db.String(80), nullable=False, default="")
    confidence = db.Column(db.Float, nullable=False, default=0.0)
    # JSON: termos mais importantes (já normalizados: sem acento, no singular)
    terms = db.Column(db.Text, nullable=False, default="[]")
    # mesma história publicada por veículos diferentes => mesmo story_id
    story_id = db.Column(db.String(16), nullable=False, index=True)
    published_at = db.Column(db.DateTime, nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)

    def __repr__(self):
        return f"<NewsBankItem article={self.article_id} {self.category}>"


class NewsInterest(db.Model):
    """Categoria de notícia que o usuário escolheu explicitamente (config. de interesses)."""
    __tablename__ = "news_interests"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    category = db.Column(db.String(30), nullable=False)

    __table_args__ = (
        db.UniqueConstraint("user_id", "category", name="uq_news_interest_user_category"),
    )


class NewsInteraction(db.Model):
    """
    Registro de que um usuário abriu uma notícia (clicou pra ler no site
    de origem). É o sinal implícito usado pelo recomendador pra aprender
    quais categorias a pessoa realmente lê, além das que ela marcou nas
    configurações. Só clique conta (não "visualização" no feed), porque
    passar o olho pelo card não indica interesse de verdade.
    """
    __tablename__ = "news_interactions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    article_id = db.Column(db.Integer, db.ForeignKey("news_articles.id"), nullable=False, index=True)
    # cópia da categoria da notícia no momento do clique — evita um join
    # extra com news_articles toda vez que o recomendador calcula afinidade
    category = db.Column(db.String(30), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, index=True)


# ---------------------------------------------------------------------------
# Vortex: conteúdo indexado pelo crawler
# ---------------------------------------------------------------------------
# IMPORTANTE: nada disso é Post. O feed, o perfil dos usuários, o ranking e
# as notificações só consultam `posts`, então os itens do crawler nunca
# aparecem lá — só dentro do Vortex.

class VortexProfile(db.Model):
    """O "perfil" que aparece como autor dos itens do crawler. Não é um User:
    não loga, não segue, não aparece na busca de pessoas nem no ranking."""
    __tablename__ = "vortex_profiles"

    id = db.Column(db.Integer, primary_key=True)
    handle = db.Column(db.String(40), nullable=False, unique=True, index=True)
    display_name = db.Column(db.String(80), nullable=False)
    bio = db.Column(db.String(300), default="")
    avatar_url = db.Column(db.String(700), nullable=True)
    source_site = db.Column(db.String(120), nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    def __repr__(self):
        return f"<VortexProfile @{self.handle}>"


class VortexCrawlSource(db.Model):
    """Uma fonte que o crawler varre (ex.: uma busca no Wikimedia Commons)."""
    __tablename__ = "vortex_crawl_sources"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    # commons | openverse | pexels | pixabay | giphy | rss | page
    kind = db.Column(db.String(20), nullable=False)
    profile_id = db.Column(db.Integer, db.ForeignKey("vortex_profiles.id"), nullable=False, index=True)
    # categoria fixa da fonte; vazio = classificar cada item pelo conteúdo
    category = db.Column(db.String(30), nullable=True)
    # termo de busca (APIs) ou URL (rss/page)
    term = db.Column(db.String(500), nullable=False)
    # photo | gif | video — o que esta fonte procura
    media = db.Column(db.String(10), nullable=False, default="photo")
    enabled = db.Column(db.Boolean, default=True, nullable=False)
    # próxima página da API a buscar (avança a cada rodada com resultados)
    next_page = db.Column(db.Integer, default=1, nullable=False)
    last_run_at = db.Column(db.DateTime, nullable=True)
    last_status = db.Column(db.String(300), nullable=True)
    items_added = db.Column(db.Integer, default=0, nullable=False)
    # --- motor contínuo (vortex_crawler.IngestEngine) ---
    # quando a fonte volta a ser varrida (vazio = já; o motor reagenda sozinho)
    next_run_at = db.Column(db.DateTime, nullable=True, index=True)
    # erros seguidos (backoff exponencial) e rodadas seguidas sem nada novo
    fail_count = db.Column(db.Integer, default=0, nullable=False)
    empty_streak = db.Column(db.Integer, default=0, nullable=False)
    # quantas vezes a fonte esgotou o termo e passou pro próximo da lista de
    # expansão (Config.VORTEX_EXPAND_TERMS); 0 = ainda no termo original
    rotation = db.Column(db.Integer, default=0, nullable=False)
    # manual (admin/config) | auto (feed descoberto pelo motor de descoberta)
    origin = db.Column(db.String(10), default="manual", nullable=False)

    profile = db.relationship("VortexProfile", backref="sources")

    __table_args__ = (
        db.UniqueConstraint("kind", "term", "media", name="uq_vortex_source_kind_term_media"),
    )


class VortexDomain(db.Model):
    """Um site descoberto (ou semeado) pelo motor de descoberta. Controla
    educação (intervalo entre páginas, orçamento por hora), diversidade (teto
    de itens por site) e bloqueio manual."""
    __tablename__ = "vortex_domains"

    id = db.Column(db.Integer, primary_key=True)
    host = db.Column(db.String(255), nullable=False, unique=True, index=True)
    # active | capped (atingiu o teto de itens) | blocked (admin) | dead (erros demais)
    status = db.Column(db.String(10), default="active", nullable=False, index=True)
    pages_fetched = db.Column(db.Integer, default=0, nullable=False)
    items_added = db.Column(db.Integer, default=0, nullable=False)
    feeds_found = db.Column(db.Integer, default=0, nullable=False)
    error_count = db.Column(db.Integer, default=0, nullable=False)
    hour_start = db.Column(db.DateTime, nullable=True)     # janela do orçamento por hora
    hour_pages = db.Column(db.Integer, default=0, nullable=False)
    next_fetch_at = db.Column(db.DateTime, nullable=True, index=True)
    discovered_from = db.Column(db.String(255), nullable=True)   # host que linkou pra cá
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    last_fetch_at = db.Column(db.DateTime, nullable=True)


class VortexFrontier(db.Model):
    """Fila persistente de URLs a visitar (a "fronteira" do crawler). Sobrevive
    a reinícios; páginas já visitadas ficam `done` pra não repetir."""
    __tablename__ = "vortex_frontier"

    id = db.Column(db.Integer, primary_key=True)
    url_hash = db.Column(db.String(64), nullable=False, unique=True)
    url = db.Column(db.String(600), nullable=False)
    host = db.Column(db.String(255), nullable=False)
    depth = db.Column(db.Integer, default=0, nullable=False)
    status = db.Column(db.String(8), default="pending", nullable=False)   # pending | done | failed
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    done_at = db.Column(db.DateTime, nullable=True)

    __table_args__ = (
        db.Index("ix_vortex_frontier_pick", "host", "status", "depth", "id"),
        db.Index("ix_vortex_frontier_status_done", "status", "done_at"),
    )


class VortexItem(db.Model):
    """Uma foto/GIF/vídeo indexado da internet. Guardamos só a URL (hotlink)
    + metadados + atribuição; o arquivo continua no site de origem."""
    __tablename__ = "vortex_items"

    id = db.Column(db.Integer, primary_key=True)
    profile_id = db.Column(db.Integer, db.ForeignKey("vortex_profiles.id"), nullable=False, index=True)
    source_id = db.Column(db.Integer, db.ForeignKey("vortex_crawl_sources.id"), nullable=True, index=True)
    media_type = db.Column(db.String(10), nullable=False, index=True)  # photo | gif | video
    media_url = db.Column(db.String(900), nullable=False)
    # miniatura/pôster (foto: versão reduzida; vídeo: imagem de capa)
    thumb_url = db.Column(db.String(900), nullable=True)
    width = db.Column(db.Integer, nullable=True)
    height = db.Column(db.Integer, nullable=True)
    duration_seconds = db.Column(db.Integer, nullable=True)
    title = db.Column(db.String(300), default="")
    description = db.Column(db.String(600), default="")
    # tags separadas por vírgula, minúsculas (usadas pela busca/similares)
    tags = db.Column(db.String(500), default="")
    category = db.Column(db.String(30), nullable=False, default="outros", index=True)
    source_url = db.Column(db.String(900), nullable=True)   # página original
    source_name = db.Column(db.String(120), nullable=True)
    license = db.Column(db.String(120), nullable=True)
    attribution = db.Column(db.String(300), nullable=True)  # autor/crédito
    # dHash 64 bits em hex (16 chars) — só fotos; usado nos "similares" e
    # pra descartar quase-duplicatas
    phash = db.Column(db.String(16), nullable=True, index=True)
    url_hash = db.Column(db.String(64), nullable=False, unique=True, index=True)
    created_at = db.Column(db.DateTime, default=utcnow, index=True)
    last_checked_at = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False, index=True)
    # --- assinatura visual (o que a IMAGEM mostra; ver vortex_vision.py) ---
    # vetor de aparência (cores, layout, luz, textura) em hex; NULL = ainda não
    # analisado (o motor preenche em segundo plano); "" = não deu pra analisar
    vfeat = db.Column(db.String(160), nullable=True)
    # tags de aparência (cores/luz/textura) e, com CLIP ligado, conceitos
    # reconhecidos na imagem ("cachoeira", "cachorro"...), separados por vírgula
    visual_tags = db.Column(db.String(300), nullable=True)
    # embedding CLIP (float16, base64); só existe com VORTEX_CLIP_MODEL
    clip_vec = db.Column(db.Text, nullable=True)
    vision_version = db.Column(db.Integer, nullable=True)
    # --- controle de qualidade (ver vortex_quality.py) ---
    # motivo pelo qual o item foi tirado do Vortex sozinho ("qrcode", "logo",
    # "blank", "text", "duplicate", "repeated"...). Item barrado também fica
    # com is_active=False, então nada no Vortex o enxerga. "manual_ok" = um
    # admin restaurou: o filtro automático nunca mais mexe nele.
    junk_reason = db.Column(db.String(24), nullable=True, index=True)
    # versão do filtro que já olhou este item (NULL = ainda não analisado)
    quality_version = db.Column(db.Integer, nullable=True)
    # --- compreensão do conteúdo (ver vortex_concepts.py / vortex_understand.py) ---
    # conceitos com peso, "carro_esportivo:1,estrada:0.84" (o 1º é o assunto principal);
    # "" = analisado e sem conceito claro (só a categoria); NULL = ainda não analisado
    concepts = db.Column(db.String(160), nullable=True)
    # conceitos + ancestrais entre espaços (" carro_esportivo carro veiculo_rodas veiculo "):
    # serve pra achar "tudo que é veículo de rodas" com LIKE '% veiculo_rodas %', sem join
    concept_tags = db.Column(db.String(300), nullable=True)
    # CONCEPTS_VERSION que gerou os campos acima (NULL/menor = reprocessar)
    concept_version = db.Column(db.Integer, nullable=True)

    profile = db.relationship("VortexProfile", backref="items")

    __table_args__ = (
        db.Index("ix_vortex_items_active_id", "is_active", "id"),
        db.Index("ix_vortex_items_cat_type", "category", "media_type"),
    )

    @property
    def tag_list(self):
        return [t for t in (self.tags or "").split(",") if t]

    @property
    def visual_tag_list(self):
        return [t for t in (self.visual_tags or "").split(",") if t]

    @property
    def concept_list(self):
        """[(id, peso)] gravados (vazio se ainda não analisado)."""
        from vortex_concepts import decode
        return decode(self.concepts)

    def __repr__(self):
        return f"<VortexItem {self.id} {self.media_type}>"


class VortexInteraction(db.Model):
    """Sinal de gosto de um usuário no Vortex (clique, tempo no detalhe,
    curtida, busca, \"menos disso\"). É a matéria-prima de vortex_taste.py,
    que monta o perfil de gosto e ordena a grade. Guarda uma CÓPIA dos
    atributos da peça (categoria, tipo, perfil, tags) pra o cálculo não
    depender de join e continuar valendo mesmo se o admin apagar a peça."""
    __tablename__ = "vortex_interactions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    # open | dwell | like | search | less
    kind = db.Column(db.String(12), nullable=False)
    weight = db.Column(db.Float, nullable=False, default=1.0)   # negativo = \"menos disso\"
    item_id = db.Column(db.Integer, nullable=True, index=True)  # peça do crawler
    post_id = db.Column(db.Integer, nullable=True, index=True)  # post de usuário
    category = db.Column(db.String(30), nullable=True)
    media_type = db.Column(db.String(10), nullable=True)
    profile_id = db.Column(db.Integer, nullable=True)           # perfil-robô do crawler
    author_id = db.Column(db.Integer, nullable=True)            # autor do post de usuário
    tags = db.Column(db.String(400), nullable=True)             # minúsculas, sem acento
    # conceitos da peça (vortex_concepts.encode: "carro:1,estrada:0.55"); Parte 5
    concepts = db.Column(db.String(160), nullable=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False, index=True)

    __table_args__ = (
        db.Index("ix_vortex_inter_user_time", "user_id", "created_at"),
    )


class UserWidget(db.Model):
    """Widget criado pelo próprio usuário (\"Minha área\" do painel direito).
    `kind`: note | checklist | links | countdown | counter. `data_json` guarda o conteúdo
    (validado em widgets_custom.py). Aparece no seletor como id `custom:<id>`."""
    __tablename__ = "user_widgets"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    kind = db.Column(db.String(12), nullable=False)
    title = db.Column(db.String(40), nullable=False, default="")
    data_json = db.Column(db.Text, nullable=False, default="{}")
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow, nullable=False)


class VortexSeen(db.Model):
    """O livro de vistos do Vortex: o que JÁ FOI MOSTRADO a cada usuário.

    Uma linha por (usuário, peça). `key` é 'c<id>' (item do crawler) ou 'p<id>'
    (post de usuário). Dois níveis de memória:
    - `served_*`: o servidor entregou a peça numa página (pode nem ter sido vista);
    - `viewed_*`: o app/site confirmou que a peça ficou visível na tela, ou a
      pessoa abriu/curtiu/marcou "menos disso".
    Persiste entre aberturas do app e reinícios (diferente da sessão em memória
    de vortex_taste). Ver vortex_seen.py."""
    __tablename__ = "vortex_seen"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    key = db.Column(db.String(16), nullable=False)
    served_count = db.Column(db.Integer, nullable=False, default=0)
    viewed_count = db.Column(db.Integer, nullable=False, default=0)
    first_seen_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    last_served_at = db.Column(db.DateTime, nullable=True)
    last_viewed_at = db.Column(db.DateTime, nullable=True)
    # "menos disso": a peça (e as quase iguais) não volta por muito mais tempo
    rejected = db.Column(db.Boolean, nullable=False, default=False)

    __table_args__ = (
        db.UniqueConstraint("user_id", "key", name="uq_vortex_seen_user_key"),
        db.Index("ix_vortex_seen_user_time", "user_id", "last_served_at"),
    )


class VortexControl(db.Model):
    """Painel de controle do motor de indexação (chave/valor). Fica no banco
    pra valer entre processos (o admin pode cair num worker e o motor rodar
    em outro) e sobreviver a reinícios. Chaves: `paused` ("0"/"1"), `speed`
    (fator, ex. "1.0") e `purge_seq` (sobe a cada exclusão em massa; o motor
    recarrega suas listas em memória quando muda). Ver vortex_control.py."""
    __tablename__ = "vortex_control"

    key = db.Column(db.String(40), primary_key=True)
    value = db.Column(db.String(200), nullable=False, default="")
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)


class VortexTombstone(db.Model):
    """URL que o admin apagou e que o motor NÃO deve indexar de novo."""
    __tablename__ = "vortex_tombstones"

    url_hash = db.Column(db.String(64), primary_key=True)
    category = db.Column(db.String(30), nullable=True)
    source_name = db.Column(db.String(120), nullable=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)


class SeasonAlert(db.Model):
    """Registra que o aviso de virada de estação `alert_key` (ex.: "2026-12-21:pre") já foi enviado ao
    usuário, para o agendador nunca repetir (nem depois de reiniciar o servidor)."""
    __tablename__ = "season_alerts"
    __table_args__ = (db.UniqueConstraint("user_id", "alert_key", name="uq_season_alert_user_key"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    alert_key = db.Column(db.String(40), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)


def create_notification(recipient, actor, kind, post=None, comment=None):
    """
    Cria uma notificação para `recipient` a partir da ação de `actor`.
    Não faz nada (e retorna None) se o próprio usuário for o alvo da ação
    (ex.: curtir/comentar no próprio post), já que ninguém precisa ser
    notificado sobre a própria atividade.
    """
    if recipient is None or actor is None or recipient.id == actor.id:
        return None
    notif = Notification(
        recipient_id=recipient.id,
        actor_id=actor.id,
        kind=kind,
        post_id=post.id if post is not None else None,
        comment_id=comment.id if comment is not None else None,
    )
    db.session.add(notif)

    # Import tardio (dentro da função, não no topo do módulo) só pra
    # evitar import circular: push.py importa DeviceToken/User daqui de
    # models.py, então models.py não pode importar push.py lá em cima.
    # Em tempo de chamada os dois módulos já estão totalmente
    # carregados, então isso funciona normalmente.
    from push import send_push_to_user

    body = notif.verb
    if comment is not None and kind in (Notification.KIND_COMMENT, Notification.KIND_REPLY):
        body = f"{notif.verb}: {comment.content[:80]}"
    send_push_to_user(
        recipient.id,
        title=actor.display_label,
        body=body,
        data={
            "type": "notification",
            "kind": kind,
            "username": actor.username,
            "post_id": post.id if post is not None else "",
        },
    )

    return notif



class Flash(db.Model):
    """Foto efêmera do perfil (estilo "stories"): some sozinha após FLASH_TTL_HOURS (24h).
    Enquanto houver um Flash ativo, o avatar da pessoa ganha o anel com a cor da rede."""
    __tablename__ = "flashes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    filename = db.Column(db.String(255), nullable=False)
    caption = db.Column(db.String(200), default="")
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    views_count = db.Column(db.Integer, default=0, nullable=False)

    user = db.relationship("User", backref=db.backref("flashes", lazy="dynamic", cascade="all, delete-orphan"))
    views = db.relationship("FlashView", backref="flash", cascade="all, delete-orphan", lazy="dynamic")


class FlashView(db.Model):
    """Quem já viu cada Flash (controla o anel cinza e a lista de visualizações do dono)."""
    __tablename__ = "flash_views"

    id = db.Column(db.Integer, primary_key=True)
    flash_id = db.Column(db.Integer, db.ForeignKey("flashes.id"), nullable=False, index=True)
    viewer_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    viewed_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    viewer = db.relationship("User")

    __table_args__ = (db.UniqueConstraint("flash_id", "viewer_id", name="uix_flash_view"),)
