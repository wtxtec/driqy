"""Chat em tempo real (Fase 9) — barramento de eventos em memória + formato SSE.

Cada aba/app conectado em `GET /api/v1/messages/stream` ganha uma fila; quem muda algo
(envio, leitura, edição, apagar, reação, digitando) chama `notify_*` e o evento chega
na hora. Os eventos NÃO carregam a mensagem: dizem "algo mudou na conversa com
@fulano" e o cliente rebusca (a verdade continua sendo a API REST — o polling lento
fica de rede de segurança).

LIMITE CONHECIDO: o barramento vive na memória de UM processo. Com `python app.py`
(servidor do Flask, com threads) funciona. Com vários workers (gunicorn -w 4) um
evento publicado num worker não chega a quem está conectado em outro — os clientes
caem no polling lento. Para escalar, trocar `ChatHub` por Redis pub/sub.
"""
import json
import queue
import threading
import time


class ChatHub:
    def __init__(self, max_per_user=8, queue_size=200):
        self.max_per_user = max_per_user
        self.queue_size = queue_size
        self._lock = threading.Lock()
        self._subs = {}        # user_id -> [Queue]
        self._typing_at = {}   # (de, para) -> monotonic do último "digitando"

    # ---- conexões ----
    def subscribe(self, user_id):
        q = queue.Queue(maxsize=self.queue_size)
        with self._lock:
            lst = self._subs.setdefault(user_id, [])
            lst.append(q)
            while len(lst) > self.max_per_user:  # derruba a conexão mais antiga
                old = lst.pop(0)
                self._put(old, None)
        return q

    def unsubscribe(self, user_id, q):
        """Remove a conexão. Devolve True só se ela ainda estava registrada (idempotente:
        quem chama usa isso pra não tratar a saída duas vezes)."""
        with self._lock:
            lst = self._subs.get(user_id)
            if not lst or q not in lst:
                return False
            lst.remove(q)
            if not lst:
                self._subs.pop(user_id, None)
            return True

    def is_online(self, user_id):
        with self._lock:
            return bool(self._subs.get(user_id))

    def connections(self, user_id=None):
        with self._lock:
            if user_id is not None:
                return len(self._subs.get(user_id, []))
            return sum(len(v) for v in self._subs.values())

    # ---- eventos ----
    @staticmethod
    def _put(q, item):
        try:
            q.put_nowait(item)
        except queue.Full:
            # cliente lento: joga fora o atraso e manda um "resync" (ele rebusca tudo)
            try:
                while True:
                    q.get_nowait()
            except queue.Empty:
                pass
            try:
                q.put_nowait(item if item is None else ("resync", {}))
            except queue.Full:
                pass

    def publish(self, user_id, event, data=None):
        with self._lock:
            targets = list(self._subs.get(user_id, ()))
        for q in targets:
            self._put(q, (event, data or {}))
        return len(targets)

    def typing_allowed(self, from_id, to_id, min_interval=1.5):
        """Anti-spam do 'digitando…': no máx. 1 aviso a cada `min_interval` s por par."""
        now = time.monotonic()
        key = (from_id, to_id)
        with self._lock:
            last = self._typing_at.get(key, 0.0)
            if now - last < min_interval:
                return False
            self._typing_at[key] = now
            if len(self._typing_at) > 5000:  # limpeza simples
                cutoff = now - 60
                self._typing_at = {k: v for k, v in self._typing_at.items() if v > cutoff}
            return True

    def reset(self):
        with self._lock:
            self._subs.clear()
            self._typing_at.clear()


hub = ChatHub()


def sse(event, data):
    """Um evento no formato Server-Sent Events."""
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def notify_one(user, partner, event, **extra):
    """Avisa `user` de algo na conversa com `partner` (`partner` = @ do outro lado)."""
    return hub.publish(user.id, event, {"partner": partner.username, **extra})


def notify_pair(user_a, user_b, event, **extra):
    """Avisa os dois lados (cada um recebe o @ do outro como `partner`)."""
    notify_one(user_a, user_b, event, **extra)
    notify_one(user_b, user_a, event, **extra)
