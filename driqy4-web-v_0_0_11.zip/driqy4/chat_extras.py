"""Chat — Fase 10: presença (online / visto por último), preferências da conversa
(fixar / silenciar / arquivar) e o texto do push.

Fica separado de api.py/chat.py porque os DOIS (API do app e site renderizado) usam.
Só importa models/extensions/chat_events (nada de api.py) pra não criar import circular.
"""
import threading
from datetime import timedelta

from extensions import db
from models import User, Message, ConversationPref, not_hidden_for, utcnow
from chat_events import hub

MEDIA_LABELS = {"image": "📷 Foto", "video": "🎥 Vídeo", "audio": "🎤 Áudio", "file": "📎 Arquivo"}


# ---------------------------------------------------------------------------
# Presença
# ---------------------------------------------------------------------------

def partner_ids(user_id):
    sent_to = db.session.query(Message.recipient_id).filter(Message.sender_id == user_id)
    received_from = db.session.query(Message.sender_id).filter(Message.recipient_id == user_id)
    ids = {row[0] for row in sent_to.union(received_from).all()}
    ids.discard(user_id)
    return ids


def presence_payload(partner, viewer, sse_enabled=True):
    """O que `viewer` pode saber sobre `partner`. Se QUALQUER um dos dois escondeu a
    presença, `visible` é falso e nada vaza (nem online, nem horário)."""
    hidden = {"visible": False, "online": False, "last_seen_at": None}
    if viewer is None or partner is None:
        return hidden
    if not partner.show_presence or not viewer.show_presence:
        return hidden
    online = hub.is_online(partner.id)
    seen = partner.last_seen_at
    if not online and not sse_enabled and seen and (utcnow() - seen).total_seconds() <= 90:
        online = True  # sem tempo real: última requisição recente ≈ online
    return {
        "visible": True,
        "online": bool(online),
        "last_seen_at": (seen.isoformat() + "Z") if seen else None,
    }


def announce_presence(user, sse_enabled=True):
    """Avisa (evento `presence`) cada contato CONECTADO de `user` como ele está agora."""
    for pid in partner_ids(user.id):
        if not hub.is_online(pid):
            continue
        other = db.session.get(User, pid)
        if other is None:
            continue
        hub.publish(pid, "presence", {
            "partner": user.username, **presence_payload(user, other, sse_enabled),
        })


def on_connect(user_id, sse_enabled=True):
    """Chamar depois de `hub.subscribe`: se esta é a PRIMEIRA conexão do usuário, ele ficou online."""
    if hub.connections(user_id) != 1:
        return
    user = db.session.get(User, user_id)
    if user is not None:
        announce_presence(user, sse_enabled)


def on_disconnect(app, user_id, grace=None):
    """Chamar depois de `hub.unsubscribe`. Se não sobrou conexão, espera `grace` s (um F5 desconecta
    e reconecta na hora — não pode piscar \"offline\"), grava `last_seen_at` = hora da saída e avisa."""
    if hub.connections(user_id) > 0:
        return
    if grace is None:
        grace = float(app.config.get("CHAT_PRESENCE_GRACE_SECONDS", 5))
    left_at = utcnow()

    def work():
        with app.app_context():
            if hub.connections(user_id) > 0:
                return
            user = db.session.get(User, user_id)
            if user is None:
                return
            try:
                user.last_seen_at = left_at
                db.session.commit()
                announce_presence(user, app.config.get("CHAT_SSE_ENABLED", True))
            except Exception:
                db.session.rollback()

    if grace <= 0:
        work()
    else:
        t = threading.Timer(grace, work)
        t.daemon = True
        t.start()


# ---------------------------------------------------------------------------
# Preferências da conversa: fixar / silenciar / arquivar
# ---------------------------------------------------------------------------

def prefs_map(user_id):
    """partner_id -> ConversationPref (só as que existem)."""
    return {p.partner_id: p for p in ConversationPref.query.filter_by(user_id=user_id).all()}


def serialize_prefs(pref):
    return {
        "pinned": bool(pref and pref.pinned_at),
        "muted": bool(pref and pref.muted),
        "archived": bool(pref and pref.archived),
    }


def is_muted(user_id, partner_id):
    p = ConversationPref.query.filter_by(user_id=user_id, partner_id=partner_id).first()
    return bool(p and p.muted)


def set_prefs(user, partner, max_pinned, pinned=None, muted=None, archived=None):
    """Aplica mudanças parciais. Arquivar desafixa; fixar desarquiva. Devolve (pref, erro)."""
    pref = ConversationPref.query.filter_by(user_id=user.id, partner_id=partner.id).first()
    if pref is None:
        pref = ConversationPref(user_id=user.id, partner_id=partner.id)
        db.session.add(pref)
    if muted is not None:
        pref.muted = bool(muted)
    if archived is not None:
        pref.archived = bool(archived)
        if pref.archived:
            pref.pinned_at = None
    if pinned is not None:
        if pinned:
            if pref.pinned_at is None:
                n = ConversationPref.query.filter(
                    ConversationPref.user_id == user.id, ConversationPref.pinned_at.isnot(None),
                    ConversationPref.partner_id != partner.id,
                ).count()
                if n >= max_pinned:
                    db.session.rollback()
                    return None, f"Você pode fixar até {max_pinned} conversas."
                pref.pinned_at = utcnow()
            pref.archived = False
        else:
            pref.pinned_at = None
    db.session.commit()
    return pref, None


def set_pinned_message(user, partner, message_id):
    """Ping fase 6b: fixa (`message_id`) ou desafixa (None) uma mensagem da conversa, só para
    `user`. Uma por conversa: fixar outra substitui. Devolve a ConversationPref."""
    pref = ConversationPref.query.filter_by(user_id=user.id, partner_id=partner.id).first()
    if pref is None:
        pref = ConversationPref(user_id=user.id, partner_id=partner.id)
        db.session.add(pref)
    pref.pinned_message_id = message_id
    db.session.commit()
    return pref


def unarchive_on_message(sender, recipient):
    """Mensagem nova tira a conversa do arquivo: sempre para quem enviou; para quem
    recebeu só se NÃO silenciou (conversa arquivada e silenciada fica quieta, como no WhatsApp).
    Devolve a lista de usuários cuja lista mudou (pra avisar `prefs` ao vivo)."""
    changed = []
    for owner, other, only_unmuted in ((sender, recipient, False), (recipient, sender, True)):
        pref = ConversationPref.query.filter_by(user_id=owner.id, partner_id=other.id).first()
        if pref and pref.archived and not (only_unmuted and pref.muted):
            pref.archived = False
            changed.append((owner, other))
    if changed:
        db.session.commit()
    return changed


def sort_conversations(items):
    """`items`: dicts com `_last` (datetime) e `_pinned_at` (datetime|None).
    Fixadas primeiro (a fixada mais recentemente em cima), depois mais recente primeiro."""
    pinned = sorted((i for i in items if i.get("_pinned_at")), key=lambda i: i["_pinned_at"], reverse=True)
    rest = sorted((i for i in items if not i.get("_pinned_at")), key=lambda i: i["_last"], reverse=True)
    return pinned + rest


# ---------------------------------------------------------------------------
# Push
# ---------------------------------------------------------------------------

def push_body(msg, forwarded=False):
    """Texto do push: ícone + legenda, ou rótulo (com a duração no áudio)."""
    mtype = msg.msg_type or "text"
    label = MEDIA_LABELS.get(mtype)
    if getattr(msg, "view_once", False) and label:
        return "🔒 " + {"image": "Foto", "video": "Vídeo", "audio": "Áudio"}.get(mtype, "Mídia") + " de visualização única"
    if not label:
        text = (msg.content or "")[:140]
    else:
        caption = msg.content if msg.content and msg.content != label else ""
        icon = label.split(" ")[0]
        if caption:
            text = f"{icon} {caption[:140]}"
        elif mtype == "file" and msg.media_name:
            text = f"{icon} {msg.media_name[:100]}"
        elif mtype == "audio" and msg.media_duration_ms:
            secs = int(msg.media_duration_ms // 1000)
            text = f"{label} ({secs // 60}:{secs % 60:02d})"
        else:
            text = label
    return ("↪ " + text) if forwarded else text


def unread_from(recipient_id, sender_id):
    return Message.query.filter(
        Message.sender_id == sender_id, Message.recipient_id == recipient_id,
        Message.is_read.is_(False), Message.deleted_at.is_(None), not_hidden_for(recipient_id),
    ).count()


def push_chat_message(msg, sender, recipient, forwarded=False):
    """Push de mensagem nova. Silenciada → não manda. Várias não lidas da mesma pessoa
    viram UMA notificação (mesma `tag` por conversa): \"Ana (3 mensagens)\" + texto da última."""
    from push import send_push_to_user
    if is_muted(recipient.id, sender.id):
        return False
    n = unread_from(recipient.id, sender.id)
    title = sender.display_label if n < 2 else f"{sender.display_label} ({n} mensagens)"
    send_push_to_user(
        recipient.id, title=title, body=push_body(msg, forwarded),
        data={
            "type": "message", "username": sender.username,
            "msg_type": msg.msg_type or "text", "unread_count": n,
        },
        count=n,
    )
    return True
