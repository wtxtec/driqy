"""Dados dos 10 widgets novos do painel (os que precisam do servidor): relógio mundial,
calendário com feriados, fase da Lua, cotações, \"Seu Driqy\" (números), \"Acabando\" (posts
temporários) e frase do dia. Foco, Calculadora e Respirar rodam só no aparelho.

Tudo é calculado aqui para o site e o app mostrarem exatamente o mesmo.
"""
import math
from datetime import date, datetime, timedelta, timezone

import requests
from flask import current_app, url_for

from cache import TTLCache
from extensions import db
from models import PERMANENT_EXPIRES_AT, Follow, Post, User, utcnow

BASE_TZ = "America/Sao_Paulo"

# ------------------------------------------------------------------ relógio mundial
CLOCK_ZONES = [
    ("America/Sao_Paulo", "Brasília"), ("America/New_York", "Nova York"), ("Europe/Lisbon", "Lisboa"),
    ("Europe/London", "Londres"), ("Europe/Paris", "Paris"), ("Asia/Dubai", "Dubai"),
    ("Asia/Tokyo", "Tóquio"), ("Australia/Sydney", "Sydney"), ("America/Los_Angeles", "Los Angeles"),
    ("America/Argentina/Buenos_Aires", "Buenos Aires"),
]
DEFAULT_CLOCK = ["America/Sao_Paulo", "America/New_York", "Europe/Lisbon", "Asia/Tokyo", "Australia/Sydney"]


def _zone(name):
    from zoneinfo import ZoneInfo
    return ZoneInfo(name)


def world_clock(zones=None, now=None):
    """`now` (UTC, com tzinfo) só existe para teste. Falha de base de fusos -> reason unavailable."""
    now = now or datetime.now(timezone.utc)
    names = dict(CLOCK_ZONES)
    wanted = [z for z in (zones or DEFAULT_CLOCK) if z in names]
    wanted = list(dict.fromkeys(wanted))[:10] or list(DEFAULT_CLOCK)
    try:
        base_date = now.astimezone(_zone(BASE_TZ)).date()
        cities = []
        for z in wanted:
            local = now.astimezone(_zone(z))
            off = int(local.utcoffset().total_seconds() // 60)
            sign = "+" if off >= 0 else "-"
            label = f"UTC{sign}{abs(off) // 60}" + (f":{abs(off) % 60:02d}" if abs(off) % 60 else "")
            cities.append({"id": z, "name": names[z], "offset_minutes": off, "utc_label": label,
                           "local": local.strftime("%Y-%m-%dT%H:%M:%S"),
                           "day_offset": (local.date() - base_date).days})
    except Exception:  # noqa: BLE001 — sem tzdata no sistema
        return {"ok": False, "reason": "unavailable"}
    return {"ok": True, "now_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "cities": cities,
            "available": [{"id": z, "name": n} for z, n in CLOCK_ZONES]}


# ------------------------------------------------------------------ calendário + feriados
_MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro",
           "outubro", "novembro", "dezembro"]
_FIXED = {(1, 1): "Confraternização Universal", (4, 21): "Tiradentes", (5, 1): "Dia do Trabalho",
          (9, 7): "Independência do Brasil", (10, 12): "Nossa Senhora Aparecida", (11, 2): "Finados",
          (11, 15): "Proclamação da República", (11, 20): "Consciência Negra", (12, 25): "Natal"}


def easter(year):
    """Domingo de Páscoa (algoritmo gregoriano anônimo)."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = (h + l - 7 * m + 114) % 31 + 1
    return date(year, month, day)


def holidays(year):
    """{date: (nome, tipo)} — tipo `feriado` (nacional), `facultativo` (Carnaval, Corpus Christi) ou `data` (Páscoa, só comemorativa)."""
    out = {date(year, m, d): (n, "feriado") for (m, d), n in _FIXED.items()}
    if year < 2024:
        out.pop(date(year, 11, 20), None)  # Consciência Negra só virou nacional em 2024
    e = easter(year)
    out[e - timedelta(days=48)] = ("Carnaval", "facultativo")
    out[e - timedelta(days=47)] = ("Carnaval", "facultativo")
    out[e - timedelta(days=2)] = ("Sexta-feira Santa", "feriado")
    out[e] = ("Páscoa", "data")
    out[e + timedelta(days=60)] = ("Corpus Christi", "facultativo")
    return out


def today_brt(now=None):
    now = now or datetime.now(timezone.utc)
    try:
        return now.astimezone(_zone(BASE_TZ)).date()
    except Exception:  # noqa: BLE001
        return (now - timedelta(hours=3)).date()


def user_tzinfo(tz=None, tz_offset=None):
    """Fuso do usuário para decidir qual é o "hoje" dele. `tz` = nome IANA (o site manda o do navegador);
    `tz_offset` = minutos em relação ao UTC (o app manda o do aparelho). Inválido ou ausente: Brasília."""
    import re
    if isinstance(tz, str) and re.fullmatch(r"[A-Za-z_]+(?:/[A-Za-z0-9_+\-]+){0,2}", tz):
        try:
            return _zone(tz)
        except Exception:  # noqa: BLE001  nome desconhecido / sem base de fusos
            pass
    try:
        off = int(tz_offset)
        if -14 * 60 <= off <= 14 * 60:
            return timezone(timedelta(minutes=off))
    except (TypeError, ValueError):
        pass
    return None


def tz_label(tzinfo=None, now=None):
    """Nome curto do fuso para mostrar ao lado dos horários: \"Brasília\" ou \"GMT-5\", \"GMT+5:30\"."""
    now = now or datetime.now(timezone.utc)
    if tzinfo is None or getattr(tzinfo, "key", None) == BASE_TZ:
        return "Brasília"
    off = now.astimezone(tzinfo).utcoffset() or timedelta(0)
    mins = int(off.total_seconds() // 60)
    sign = "+" if mins >= 0 else "-"
    h, m = divmod(abs(mins), 60)
    return f"GMT{sign}{h}" + (f":{m:02d}" if m else "")


def today_in(now=None, tzinfo=None):
    """Data de hoje no fuso [tzinfo] (None = Brasília)."""
    if tzinfo is None:
        return today_brt(now)
    return (now or datetime.now(timezone.utc)).astimezone(tzinfo).date()


def month_calendar(year=None, month=None, now=None, tz=None, tz_offset=None, country=None):
    """Mês do calendário. O "hoje" vem do fuso do usuário (`tz`/`tz_offset`); sem eles, Brasília.
    Feriados do país `country` (escolha do usuário) ou, sem escolha, do país do fuso `tz`; padrão Brasil."""
    import holidays_world
    today = today_in(now, user_tzinfo(tz, tz_offset))
    code, chosen = holidays_world.resolve_country(country, tz if user_tzinfo(tz) else None)
    year = year if year and 1900 <= year <= 2200 else today.year
    month = month if month and 1 <= month <= 12 else today.month
    first = date(year, month, 1)
    nxt = date(year + (month == 12), month % 12 + 1, 1)
    days = (nxt - first).days
    hol = holidays_world.holidays_for(code, year)
    reg = holidays_world.region_info(code)
    sunday_based = (first.weekday() + 1) % 7  # 0 = domingo
    return {"year": year, "month": month, "month_name": reg["month_names"][month - 1], "days_in_month": days,
            "country": code, "country_name": holidays_world.COUNTRIES[code][0], "country_chosen": chosen,
            "countries": holidays_world.country_options(),
            # nomes e semana da região (parte 3): `weekdays` já na ordem da grade; `first_offset` = casas em
            # branco antes do dia 1 nessa ordem. `first_weekday` (0 = domingo) continua para clientes antigos.
            "lang": reg["lang"], "week_start": reg["week_start"], "weekdays": reg["weekdays"],
            "first_offset": (sunday_based - reg["week_start"]) % 7,
            "first_weekday": sunday_based,
            "today": today.isoformat(),
            "holidays": [{"day": d.day, "name": n, "kind": k} for d, (n, k) in sorted(hol.items())
                         if d.year == year and d.month == month]}


# ------------------------------------------------------------------ fase da Lua
_SYNODIC = 29.530588853
_REF_NEW_MOON = datetime(2000, 1, 6, 18, 14, tzinfo=timezone.utc)
_PHASES = [("Lua nova", "🌑"), ("Lua crescente", "🌒"), ("Quarto crescente", "🌓"), ("Crescente gibosa", "🌔"),
           ("Lua cheia", "🌕"), ("Minguante gibosa", "🌖"), ("Quarto minguante", "🌗"), ("Lua minguante", "🌘")]


_QUARTERS = [(0.25, "Quarto crescente"), (0.5, "Lua cheia"), (0.75, "Quarto minguante"), (1.0, "Lua nova")]
_QUARTER_EMOJI = {"Quarto crescente": "🌓", "Lua cheia": "🌕", "Quarto minguante": "🌗", "Lua nova": "🌑"}


def _moon_distance_km(now):
    """Distância Terra–Lua aproximada (termo principal da anomalia média: erro de poucos milhares de km)."""
    t = ((now - datetime(2000, 1, 1, 12, tzinfo=timezone.utc)).total_seconds() / 86400.0) / 36525.0
    m = math.radians((134.9634 + 477198.8676 * t) % 360)
    return 385000.56 - 20905.355 * math.cos(m)


def moon_phase(now=None, lat=None, lng=None, place=None, tzinfo=None):
    """Fase aproximada pela lunação média (erro de até ~14 h nas datas; suficiente para o widget).

    Além da fase e da iluminação: crescendo/minguando, progresso da lunação, distância aproximada,
    o ciclo dos 4 marcos (nova, quarto crescente, cheia, quarto minguante) e quanto falta para cada um,
    nascer/pôr da Lua (em [lat]/[lng]; sem local, usa Brasília e marca `approximate`) e os próximos eclipses.
    Os horários e datas vêm no fuso `tzinfo` do usuário (sem ele, Brasília); `tz_label` diz qual.
    """
    now = now or datetime.now(timezone.utc)
    age = ((now - _REF_NEW_MOON).total_seconds() / 86400.0) % _SYNODIC
    frac = age / _SYNODIC
    idx = int(round(frac * 8)) % 8
    to_full = (0.5 * _SYNODIC - age) % _SYNODIC
    to_new = (_SYNODIC - age) % _SYNODIC
    day = lambda d: (today_in(now + timedelta(days=d), tzinfo)).isoformat()  # noqa: E731
    # próximos marcos, do mais perto para o mais longe (hoje conta como 0 dias)
    events = []
    for f, name in _QUARTERS:
        delta = (f * _SYNODIC - age) % _SYNODIC
        events.append({"name": name, "emoji": _QUARTER_EMOJI[name], "date": day(delta), "days": int(math.ceil(delta))})
    events.sort(key=lambda e: e["days"])
    dist = _moon_distance_km(now)
    if dist <= 367000:
        dist_label = "Perto da Terra (perigeu)"
    elif dist >= 404000:
        dist_label = "Longe da Terra (apogeu)"
    else:
        dist_label = "Distância média"
    return {"phase": _PHASES[idx][0], "emoji": _PHASES[idx][1], "index": idx, "age_days": round(age, 1),
            "illumination": round((1 - math.cos(2 * math.pi * frac)) / 2 * 100),
            "next_full": day(to_full), "next_new": day(to_new),
            "days_to_full": int(math.ceil(to_full)), "days_to_new": int(math.ceil(to_new)),
            # --- mais informações (campos novos; os de cima continuam iguais)
            "waxing": frac < 0.5,
            "trend": "Crescendo" if frac < 0.5 else "Minguando",
            "cycle_pct": round(frac * 100, 1),
            "cycle_days": round(_SYNODIC, 1),
            "distance_km": int(round(dist, -2)),
            "distance_label": dist_label,
            "events": events,
            # --- nascer/pôr da Lua e próximos eclipses
            "tz_label": tz_label(tzinfo, now),
            "rise_set": moon_rise_set_info(now, lat, lng, place, tzinfo),
            "eclipses": eclipse_list(now, lat, lng, tzinfo=tzinfo)}


_BRT_TZ = timezone(timedelta(hours=-3))
_DEFAULT_PLACE = (-15.78, -47.93, "Brasília")


def _hm(dt, tzinfo=None):
    return dt.astimezone(tzinfo or _BRT_TZ).strftime("%H:%M") if dt else None


def moon_rise_set_info(now, lat=None, lng=None, place=None, tzinfo=None):
    """Nascer e pôr da Lua de hoje (no fuso do usuário; sem ele, Brasília), se a Lua está no céu agora e o próximo evento."""
    import moon_astro
    approximate = lat is None or lng is None
    if approximate:
        lat, lng, place = _DEFAULT_PLACE
    today = today_in(now, tzinfo)
    days = [moon_astro.moon_rise_set(today + timedelta(days=i), lat, lng) for i in (0, 1)]
    upcoming = sorted(((dt, label) for i, d in enumerate(days) for label, dt in (("Nasce", d["rise"]), ("Se põe", d["set"]))
                       if dt and dt > now), key=lambda x: x[0])
    nxt = None
    if upcoming:
        dt, label = upcoming[0]
        nxt = {"label": label, "time": _hm(dt, tzinfo), "today": dt.astimezone(tzinfo or _BRT_TZ).date() == today}
    return {"place": place or "", "approximate": approximate, "rise": _hm(days[0]["rise"], tzinfo),
            "set": _hm(days[0]["set"], tzinfo),
            "up_now": moon_astro.moon_is_up(now, lat, lng), "next": nxt}


_ECLIPSE_NAMES = {"solar": "Eclipse solar", "lunar": "Eclipse lunar"}


def eclipse_list(now, lat=None, lng=None, count=3, tzinfo=None):
    """Próximos eclipses (solar/lunar), data e hora do máximo no fuso do usuário (sem ele, Brasília). Em eclipse lunar diz se a Lua
    estará acima do horizonte no máximo (`visible_here`; None sem local). Solar: depende da faixa, sem palpite."""
    import moon_astro
    today = today_in(now, tzinfo)
    out = []
    for ev in moon_astro.next_eclipses(now, count):
        local = ev["when"].astimezone(tzinfo or _BRT_TZ)
        item = {"kind": ev["kind"], "type": ev["type"], "emoji": "☀️" if ev["kind"] == "solar" else "🌕",
                "name": f"{_ECLIPSE_NAMES[ev['kind']]} {ev['type']}", "date": local.date().isoformat(),
                "time": local.strftime("%H:%M"), "days": (local.date() - today).days, "visible_here": None}
        if ev["kind"] == "lunar":
            item["magnitude"] = ev["magnitude"]
            if lat is not None and lng is not None:
                item["visible_here"] = moon_astro.moon_is_up(ev["when"], lat, lng)
        out.append(item)
    return out


# ------------------------------------------------------------------ estações do ano
# Equinócios e solstícios pelo método de Jean Meeus (Astronomical Algorithms, cap. 27): erro de
# poucos minutos, de sobra para o widget. Os instantes são os mesmos para o mundo todo; o que muda
# é o nome da estação (invertido entre os hemisférios).
_SEASON_EVENTS = [  # (k, JDE0 como polinômio em Y' = (ano-2000)/1000)
    (0, (2451623.80984, 365242.37404, 0.05169, -0.00411, -0.00057)),   # equinócio de março
    (1, (2451716.56767, 365241.62603, 0.00325, 0.00888, -0.00030)),    # solstício de junho
    (2, (2451810.21715, 365242.01767, -0.11575, 0.00337, 0.00078)),    # equinócio de setembro
    (3, (2451900.05952, 365242.74049, -0.06223, -0.00823, 0.00032)),   # solstício de dezembro
]
_SEASON_TERMS = [
    (485, 324.96, 1934.136), (203, 337.23, 32964.467), (199, 342.08, 20.186), (182, 27.85, 445267.112),
    (156, 73.14, 45036.886), (136, 171.52, 22518.443), (77, 222.54, 65928.934), (74, 296.72, 3034.906),
    (70, 243.58, 9037.513), (58, 119.81, 33718.147), (52, 297.17, 150.678), (50, 21.02, 2281.226),
    (45, 247.54, 29929.562), (44, 325.15, 31555.956), (29, 60.93, 4443.417), (18, 155.12, 67555.328),
    (17, 288.79, 4562.452), (16, 198.04, 62894.029), (14, 199.76, 31436.921), (12, 95.39, 14577.848),
    (12, 287.11, 31931.756), (12, 320.81, 34777.259), (9, 227.73, 1222.114), (8, 15.45, 16859.074),
]
_SEASON_NAMES = {  # k do evento -> estação que COMEÇA nele, por hemisfério
    "sul": {0: "Outono", 1: "Inverno", 2: "Primavera", 3: "Verão"},
    "norte": {0: "Primavera", 1: "Verão", 2: "Outono", 3: "Inverno"},
}
SEASON_EMOJI = {"Primavera": "🌸", "Verão": "☀️", "Outono": "🍂", "Inverno": "❄️"}
_EVENT_LABEL = {0: "Equinócio de março", 1: "Solstício de junho", 2: "Equinócio de setembro", 3: "Solstício de dezembro"}


def hemisphere_for(lat):
    """`sul` (padrão, o público é brasileiro) ou `norte` quando a localização do perfil é ao norte do Equador."""
    return "norte" if isinstance(lat, (int, float)) and lat > 0 else "sul"


def season_event(year, k):
    """Instante (UTC) do evento `k` (0 mar, 1 jun, 2 set, 3 dez) do `year`."""
    y = (year - 2000) / 1000.0
    a = _SEASON_EVENTS[k][1]
    jde0 = a[0] + a[1] * y + a[2] * y ** 2 + a[3] * y ** 3 + a[4] * y ** 4
    t = (jde0 - 2451545.0) / 36525.0
    w = math.radians(35999.373 * t - 2.47)
    dl = 1 + 0.0334 * math.cos(w) + 0.0007 * math.cos(2 * w)
    ssum = sum(c * math.cos(math.radians(b + d * t)) for c, b, d in _SEASON_TERMS)
    jde = jde0 + 0.00001 * ssum / dl
    jd = jde - 69.0 / 86400.0  # TD -> UT (ΔT ≈ 69 s hoje)
    return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(days=jd - 2440587.5)


def season_transitions(now=None):
    """Todos os eventos de ano-1 a ano+1, em ordem: [(instante UTC, k), ...]."""
    now = now or datetime.now(timezone.utc)
    out = [(season_event(y, k), k) for y in (now.year - 1, now.year, now.year + 1) for k in range(4)]
    return sorted(out)


def _brt(dt, tzinfo=None):
    """`dt` no fuso `tzinfo` do usuário (sem ele, Brasília)."""
    if tzinfo is not None:
        return dt.astimezone(tzinfo)
    try:
        return dt.astimezone(_zone(BASE_TZ))
    except Exception:  # noqa: BLE001
        return dt - timedelta(hours=3)


def season_info(now=None, lat=None, tzinfo=None):
    """Estação atual, progresso e as 4 estações do ciclo (de solstício de dezembro a solstício de dezembro).

    O hemisfério vem da localização do perfil (`lat`); sem localização, hemisfério sul.
    """
    now = now or datetime.now(timezone.utc)
    hemi = hemisphere_for(lat)
    names = _SEASON_NAMES[hemi]
    ev = season_transitions(now)
    i = max(j for j, (dt, _) in enumerate(ev) if dt <= now)
    today = today_in(now, tzinfo)

    def pack(j):
        start, k = ev[j]
        end = ev[j + 1][0]
        total = (end - start).total_seconds()
        done = min(max((now - start).total_seconds(), 0.0), total)
        pct = round(done / total * 100, 1)
        name = names[k]
        return {"key": name.lower(), "name": name, "emoji": SEASON_EMOJI[name],
                "start": _brt(start, tzinfo).date().isoformat(), "end": _brt(end, tzinfo).date().isoformat(),
                "start_label": _brt(start, tzinfo).strftime("%d/%m %H:%M"), "end_label": _brt(end, tzinfo).strftime("%d/%m %H:%M"),
                "event": _EVENT_LABEL[k], "days": (_brt(end, tzinfo).date() - _brt(start, tzinfo).date()).days,
                "progress": 100.0 if end <= now else (0.0 if start > now else pct),
                "status": "past" if end <= now else ("future" if start > now else "current")}

    cur = pack(i)
    cur["day_number"] = (today - _brt(ev[i][0], tzinfo).date()).days + 1
    cur["days_left"] = max((_brt(ev[i + 1][0], tzinfo).date() - today).days, 0)
    nxt = pack(i + 1)
    # as 4 estações do ciclo, ancoradas no último solstício de dezembro
    d = max(j for j, (dt, k) in enumerate(ev) if k == 3 and dt <= now)
    cycle = [pack(j) for j in range(d, d + 4)]
    year_total = (ev[d + 4][0] - ev[d][0]).total_seconds()
    year_pct = round((now - ev[d][0]).total_seconds() / year_total * 100, 1)
    return {"hemisphere": hemi, "today": today.isoformat(), "current": cur, "next": nxt,
            "days_to_next": cur["days_left"], "cycle": cycle, "year_progress": year_pct,
            "alert": season_alert_text(cur, nxt), "tz_label": tz_label(tzinfo, now)}


def season_alert_text(cur, nxt):
    """Aviso curto para quando a virada está a 3 dias ou menos (ou é hoje); None nos demais dias."""
    n = cur["days_left"]
    if n > 3:
        return None
    art = "a" if nxt["name"] == "Primavera" else "o"
    if n == 0:
        return f"Hoje começa {art} {nxt['name']}"
    when = "amanhã" if n == 1 else f"em {n} dias"
    return f"{nxt['name']} começa {when} ({nxt['start'][8:10]}/{nxt['start'][5:7]})"


# ------------------------------------------------------------------ cotações
_QUOTES_URL = "https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL,BTC-BRL"
_QUOTES_CACHE = TTLCache(ttl_seconds=300, max_entries=2)
_LAST_GOOD = {}
_QUOTE_META = [("USDBRL", "USD", "Dólar", "US$"), ("EURBRL", "EUR", "Euro", "€"), ("BTCBRL", "BTC", "Bitcoin", "₿")]


def _num(v):
    try:
        n = float(v)
    except (TypeError, ValueError):
        return None
    return n if math.isfinite(n) else None


def get_quotes():
    if not current_app.config.get("QUOTES_ENABLED", True):
        return {"ok": False, "reason": "disabled"}
    cached = _QUOTES_CACHE.get("q")
    if cached:
        return cached
    try:
        r = requests.get(_QUOTES_URL, timeout=6)
        r.raise_for_status()
        data = r.json() or {}
        items = []
        for key, code, name, symbol in _QUOTE_META:
            row = data.get(key) or {}
            bid = _num(row.get("bid"))
            if bid is None:
                continue
            items.append({"code": code, "name": name, "symbol": symbol, "value": bid,
                          "change_pct": _num(row.get("pctChange")) or 0.0,
                          "high": _num(row.get("high")), "low": _num(row.get("low"))})
        if not items:
            raise ValueError("resposta sem cotações")
        out = {"ok": True, "currency": "BRL", "items": items,
               "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "stale": False}
        _QUOTES_CACHE.set("q", out)
        _LAST_GOOD["q"] = out
        return out
    except Exception:  # noqa: BLE001 — rede fora, JSON estranho, etc.
        if _LAST_GOOD.get("q"):
            return {**_LAST_GOOD["q"], "stale": True}
        return {"ok": False, "reason": "unavailable"}


# ------------------------------------------------------------------ Seu Driqy (números)
def my_stats(user):
    now = utcnow()
    posts_live = Post.query.filter(Post.user_id == user.id, Post.expires_at > now).count()
    posts_total = Post.query.filter(Post.user_id == user.id).count()
    views = db.session.query(db.func.coalesce(db.func.sum(Post.views_count), 0)).filter(Post.user_id == user.id).scalar()
    return {"followers": Follow.query.filter_by(followed_id=user.id).count(),
            "following": Follow.query.filter_by(follower_id=user.id).count(),
            "new_followers_7d": Follow.query.filter(Follow.followed_id == user.id,
                                                    Follow.created_at > now - timedelta(days=7)).count(),
            "posts_live": posts_live, "posts_total": posts_total, "views": int(views or 0),
            "likes": user.total_likes_received or 0, "comments": user.total_comments_received or 0}


# ------------------------------------------------------------------ Acabando (posts temporários)
EXPIRING_WINDOW_HOURS = 48


def expiring_posts(viewer, limit=5):
    """Posts temporários (seus e de quem você segue) que somem nas próximas 48 h, o mais urgente primeiro."""
    now = utcnow()
    followed = [r[0] for r in db.session.query(Follow.followed_id).filter(Follow.follower_id == viewer.id)]
    ids = followed + [viewer.id]
    rows = (Post.query.join(User, User.id == Post.user_id)
            .filter(Post.user_id.in_(ids), User.is_banned.is_(False), Post.expires_at > now,
                    Post.expires_at < min(now + timedelta(hours=EXPIRING_WINDOW_HOURS), PERMANENT_EXPIRES_AT))
            .order_by(Post.expires_at.asc()).limit(limit).all())
    out = []
    for p in rows:
        text = " ".join((p.text_content or "").split())
        if len(text) > 90:
            text = text[:90].rstrip() + "…"
        out.append({"id": p.id, "url": url_for("main.post_detail", post_id=p.id), "mine": p.user_id == viewer.id,
                    "author": {"username": p.author.username, "display_name": p.author.display_label,
                               "avatar_url": url_for("serve_upload", filename=p.author.avatar_filename)
                               if p.author.avatar_filename else None},
                    "snippet": text or {"photo": "📷 Foto", "video": "🎬 Vídeo", "gif": "GIF",
                                        "audio": "🎧 Áudio"}.get(p.post_type, "Post"),
                    "expires_at": p.expires_at.isoformat() + "Z",
                    "seconds_left": max(0, int((p.expires_at - now).total_seconds()))})
    return out


# ------------------------------------------------------------------ frase do dia
PHRASES = [
    ("Devagar se vai ao longe.", "Provérbio"),
    ("Água mole em pedra dura, tanto bate até que fura.", "Provérbio"),
    ("Quem espera sempre alcança.", "Provérbio"),
    ("A pressa é inimiga da perfeição.", "Provérbio"),
    ("Mais vale um pássaro na mão do que dois voando.", "Provérbio"),
    ("Cada macaco no seu galho.", "Ditado popular"),
    ("De grão em grão a galinha enche o papo.", "Ditado popular"),
    ("Quem não arrisca não petisca.", "Ditado popular"),
    ("O que os olhos não veem, o coração não sente.", "Ditado popular"),
    ("Há males que vêm para bem.", "Provérbio"),
    ("Antes tarde do que nunca.", "Provérbio"),
    ("Em boca fechada não entra mosca.", "Provérbio"),
    ("Quem semeia vento colhe tempestade.", "Provérbio"),
    ("Cão que ladra não morde.", "Ditado popular"),
    ("Pau que nasce torto, tarde ou nunca se endireita.", "Ditado popular"),
    ("Dize-me com quem andas e dir-te-ei quem és.", "Provérbio"),
    ("Não deixe para amanhã o que você pode fazer hoje.", "Provérbio"),
    ("A união faz a força.", "Provérbio"),
    ("Quem canta seus males espanta.", "Provérbio"),
    ("Casa de ferreiro, espeto de pau.", "Ditado popular"),
    ("Uma andorinha só não faz verão.", "Provérbio"),
    ("Roma não foi feita num dia.", "Provérbio"),
    ("De pequenino é que se torce o pepino.", "Ditado popular"),
    ("Quem tem boca vai a Roma.", "Provérbio"),
    ("Depois da tempestade vem a bonança.", "Provérbio"),
    ("Aos poucos se chega lá.", None),
    ("Comece pequeno, mas comece hoje.", None),
    ("Um passo de cada vez ainda é caminhada.", None),
    ("Descansar também faz parte do trabalho.", None),
    ("Feito é melhor que perfeito.", None),
    ("O dia rende quando a primeira tarefa é a mais difícil.", None),
    ("Pergunte mais, presuma menos.", None),
    ("Gentileza não custa nada e vale muito.", None),
    ("Quem ensina aprende duas vezes.", "Ditado popular"),
    ("O combinado não sai caro.", "Ditado popular"),
    ("Cada dia traz a sua tarefa e a sua graça.", None),
    ("Respire fundo: quase tudo se resolve em partes.", None),
    ("Quem muito escolhe pouco acha.", "Ditado popular"),
    ("A esperança é a última que morre.", "Provérbio"),
    ("Na dúvida, escolha o caminho mais simples.", None),
]


def phrase_of_the_day(now=None):
    d = today_brt(now)
    text, author = PHRASES[d.toordinal() % len(PHRASES)]
    return {"text": text, "author": author, "date": d.isoformat()}
