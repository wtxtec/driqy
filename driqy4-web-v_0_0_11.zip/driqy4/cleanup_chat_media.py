"""Lista (padrão) ou apaga (--apply) mídia de chat órfã. Ver chat_cleanup.py."""
import sys

from app import create_app
from chat_cleanup import cleanup_orphan_chat_media

if __name__ == "__main__":
    apply = "--apply" in sys.argv
    app = create_app()
    r = cleanup_orphan_chat_media(app, apply=apply)
    print(f"{r['found']} órfão(s), {r['bytes'] / 1048576:.2f} MB"
          + (f", {r['deleted']} apagado(s)." if apply else " (simulação; use --apply para apagar)."))
