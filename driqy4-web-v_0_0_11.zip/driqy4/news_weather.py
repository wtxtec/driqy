"""
Filtro de "previsão do tempo de uma cidade específica" no feed de notícias.

Regra: notícia de previsão/tempo de UMA localidade específica (ex.: "Previsão do
tempo para Curitiba", "Frio em Campinas neste domingo") só aparece para quem mora
lá (campo `location` do perfil). Clima em geral (Brasil, regiões, estados, frente
fria, El Niño, onda de calor no país...) continua aparecendo para todos.

Tudo é calculado em cima de título (e só do título, pra não esconder matéria
séria que cita uma cidade de passagem), sem coluna nova no banco.
"""
import re
import unicodedata
from functools import lru_cache


def normalize(text):
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", text).strip().lower()


# título com cara de previsão/tempo do dia (e não de tragédia, política, etc.)
_DAY_WORDS = (
    r"hoje|amanh[ãa]|depois de amanh[ãa]|nesta|neste|nessa|nesse|esta|este|fim de semana|"
    r"final de semana|fds|semana|domingo|s[áa]bado|segunda|ter[çc]a|quarta|quinta|sexta|"
    r"feriado|madrugada|noite|tarde|manh[ãa]|pr[óo]ximos? dias"
)
_FORECAST_RE = re.compile(
    r"previs[ãa]o|"
    r"como (?:fica|estar[áa]|deve ficar|fica) (?:o )?(?:tempo|clima)|"
    r"\b(?:tempo|clima)\b.{0,25}\b(?:" + _DAY_WORDS + r")\b|"
    r"\b(?:m[áa]xima|m[ií]nima|temperaturas?)\b|\d+\s?°|"
    r"\b(?:chuva|chuvas|chuvisco|garoa|frio|calor|sol|geada|neblina|nevoeiro|vento|ventos|"
    r"nublado|tempo firme|c[ée]u)\b.{0,40}\b(?:" + _DAY_WORDS + r")\b",
    re.IGNORECASE,
)

# é mesmo assunto de tempo? (usado junto com a previsão pra não pegar "semana" solta)
_WEATHER_TERM_RE = re.compile(
    r"\b(?:tempo|clima|chuva|chuvas|chuvisco|garoa|frio|calor|sol|geada|neblina|nevoeiro|"
    r"vento|ventos|nublado|temperatura|temperaturas|m[áa]xima|m[ií]nima|temporal|tempestade|"
    r"previs[ãa]o)\b|\d+\s?°",
    re.IGNORECASE,
)

_CAP = r"[A-ZÁÉÍÓÚÂÊÔÃÕÇ][\wÀ-ÿ'’\-]*"
_NAME = _CAP + r"(?:\s+(?:(?:de|da|do|dos|das|e)\s+)?" + _CAP + r")*"
# "em Curitiba", "para Porto Alegre", "do Rio de Janeiro"
_PLACE_AFTER_PREP_RE = re.compile(r"\b(?:em|na|no|nas|nos|de|do|da|para|pra|por|entre|sobre)\s+(" + _NAME + r")")
# "Previsão do tempo: Curitiba tem..." / "Previsão - Recife"
_PLACE_AFTER_COLON_RE = re.compile(r"[:\-–—]\s*(" + _NAME + r")")
# "Curitiba terá frio...", "Campinas amanhece com..."
_PLACE_AT_START_RE = re.compile(
    r"^(" + _NAME + r")\s+(?:tem|ter[áa]|registra|registrou|amanhece|enfrenta|vive|fica|ficar[áa]|"
    r"deve|segue|recebe|ter[áa]|sofre|espera|entra|volta|ganha|abre|encerra|come[çc]a)\b"
)

# regiões/estados/países/continentes: amplos demais pra contar como "cidade específica"
_BROAD = {normalize(x) for x in """
brasil país pais mundo europa asia ásia africa áfrica oceania américa america américa do sul america do sul
américa do norte america do norte américa latina america latina antártida antartida ártico artico
sul sudeste norte nordeste centro-oeste centro oeste
sul do brasil sudeste do brasil norte do brasil nordeste do brasil
região sul região sudeste região norte região nordeste região centro-oeste
acre alagoas amapá amapa amazonas bahia ceará ceara distrito federal espírito santo espirito santo
goiás goias maranhão maranhao mato grosso mato grosso do sul minas gerais pará para paraíba paraiba
paraná parana pernambuco piauí piaui rio grande do norte rio grande do sul rondônia
rondonia roraima santa catarina sergipe tocantins
estados unidos eua argentina uruguai paraguai chile bolívia bolivia peru colômbia colombia venezuela
portugal espanha frança franca itália italia alemanha reino unido inglaterra china japão japao índia india
rússia russia canadá canada méxico mexico austrália australia
amazônia amazonia pantanal cerrado caatinga mata atlântica mata atlantica pampa
atlântico atlantico pacífico pacifico
""".split("\n") for x in [x.strip()] if x} | {
    normalize(w) for w in (
        "Brasil Sul Sudeste Norte Nordeste Europa Ásia África Amazônia Pantanal Cerrado Caatinga "
        "Acre Alagoas Amapá Amazonas Bahia Ceará Goiás Maranhão Pará Paraíba Paraná Pernambuco Piauí "
        "Rondônia Roraima Sergipe Tocantins Argentina Uruguai Paraguai Chile Bolívia Peru Colômbia "
        "Venezuela Portugal Espanha França Itália Alemanha Inglaterra China Japão Índia Rússia Canadá "
        "México Austrália Atlântico Pacífico"
    ).split()
}
# multi-palavra acima foi quebrado por linhas; garante as compostas
_BROAD |= {normalize(x) for x in (
    "Centro-Oeste", "Centro Oeste", "Espírito Santo", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais",
    "Rio Grande do Norte", "Rio Grande do Sul", "Santa Catarina",
    "Distrito Federal", "Estados Unidos", "Reino Unido", "América do Sul", "América do Norte",
    "América Latina", "Mata Atlântica", "Sul do Brasil", "Sudeste do Brasil", "Norte do Brasil",
    "Nordeste do Brasil", "Região Sul", "Região Sudeste", "Região Norte", "Região Nordeste",
    "Região Centro-Oeste",
)}

# palavras com inicial maiúscula que NÃO são lugar
_NOT_PLACE = {normalize(x) for x in (
    "Tempo", "Clima", "Previsão", "Hoje", "Amanhã", "Domingo", "Segunda", "Terça", "Quarta", "Quinta",
    "Sexta", "Sábado", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira",
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro",
    "Outubro", "Novembro", "Dezembro", "Natal", "Carnaval", "Páscoa", "Réveillon", "Ano Novo",
    "Halloween", "Black Friday", "Inverno", "Verão", "Outono", "Primavera", "Enem", "Inmet",
    "Climatempo", "MetSul", "Cemaden", "Defesa Civil", "Alerta", "El Niño", "La Niña", "Copa",
    "Olimpíadas", "Brasileirão", "Feriado", "Dia", "Semana", "Fim", "Final", "Frente Fria",
    "Onda de Calor", "Massa de Ar", "Ciclone", "Cheia", "Seca", "Governo", "Prefeitura", "Cidade",
    "Capital", "Capitais", "Estado", "Como", "Veja", "Saiba", "Confira", "Entenda", "Região", "Pais", "País", "Mundo", "Terra", "Lua", "Sol",
)}


@lru_cache(maxsize=4096)
def _candidate_places(title):
    """Localidades específicas citadas no título (normalizadas), ou () se não for
    previsão do tempo de lugar nenhum em particular."""
    title = (title or "").strip()
    if not title or not _FORECAST_RE.search(title) or not _WEATHER_TERM_RE.search(title):
        return ()
    found = []
    for rx in (_PLACE_AFTER_PREP_RE, _PLACE_AFTER_COLON_RE, _PLACE_AT_START_RE):
        for m in rx.finditer(title):
            name = normalize(m.group(1))
            if not name or name in _NOT_PLACE or name in _BROAD:
                continue
            # "Previsão Do Tempo" etc.: nome inteiro feito só de palavras que não são lugar
            words = [w for w in re.split(r"[\s\-]+", name) if w not in ("de", "da", "do", "dos", "das", "e")]
            if all(w in _NOT_PLACE for w in words):
                continue
            if name not in found:
                found.append(name)
    return tuple(found)


def local_forecast_places(title):
    """Público: tupla de localidades específicas (vazia = notícia de clima em geral)."""
    return _candidate_places(title)


def user_place_keys(location):
    """Pedaços normalizados do campo `location` do perfil: 'São Paulo, SP' ->
    {'sao paulo', 'sp'}."""
    loc = normalize(location)
    if not loc:
        return frozenset()
    parts = {p.strip() for p in re.split(r"[,/\-–—|;()]+", loc) if p.strip()}
    parts.add(loc)
    return frozenset(parts)


def _matches(place, keys):
    for k in keys:
        if place == k:
            return True
        if len(k) >= 4 and re.search(r"\b" + re.escape(k) + r"\b", place):
            return True
        if len(place) >= 4 and re.search(r"\b" + re.escape(place) + r"\b", k):
            return True
    return False


def hide_for_user(title, keys):
    """True se a notícia é previsão de cidade específica e NÃO é a cidade do usuário.
    `keys` = user_place_keys(user.location) (vazio para anônimo/sem cidade)."""
    places = _candidate_places(title)
    if not places:
        return False
    return not any(_matches(p, keys) for p in places)
