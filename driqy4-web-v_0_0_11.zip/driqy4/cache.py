"""
Cache simples em memória com expiração por tempo (TTL) — evita bater no
banco de novo com a mesma query pesada em requests próximos (ex.: o pool
de notícias do feed, que é recalculado — pontuado e diversificado — a
cada carregamento). Cada entrada expira sozinha depois de `ttl_seconds`:
não precisa de Redis/Memcached pra um app deste tamanho, e não precisa de
nenhuma limpeza manual — o valor velho simplesmente some (é substituído
ou ignorado) assim que o tempo passa.
"""
import time
import threading


class TTLCache:
    def __init__(self, ttl_seconds=60, max_entries=64):
        self._ttl = ttl_seconds
        self._max_entries = max_entries
        self._store = {}  # key -> (expira_em, valor)
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            entry = self._store.get(key)
            if not entry:
                return None
            expires_at, value = entry
            if expires_at < time.monotonic():
                # expirou: apaga e trata como cache miss
                del self._store[key]
                return None
            return value

    def set(self, key, value):
        with self._lock:
            if len(self._store) >= self._max_entries:
                now = time.monotonic()
                for k in [k for k, (exp, _v) in self._store.items() if exp < now]:
                    del self._store[k]
            self._store[key] = (time.monotonic() + self._ttl, value)

    def clear(self):
        with self._lock:
            self._store.clear()
