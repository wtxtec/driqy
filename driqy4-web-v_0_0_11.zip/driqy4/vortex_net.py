"""
Segurança de rede do crawler (anti-SSRF).

Como o motor de descoberta segue links de QUALQUER site, uma página
maliciosa poderia apontar pra http://127.0.0.1/..., pra rede interna ou pra
http://169.254.169.254/ (metadata de nuvem) e fazer o servidor buscar isso.
Por padrão só hosts com endereço público são acessados, inclusive nos
redirecionamentos (a checagem roda em cada requisição enviada pela sessão).

Limites conhecidos: a resolução de DNS é checada antes de enviar, mas o
`requests` resolve de novo ao conectar (janela de "DNS rebinding"). Para
isolamento forte, rode o crawler numa rede/container sem rota para a rede
interna.
"""
import ipaddress
import socket
import threading
import time
from urllib.parse import urlparse


class UnsafeHost(Exception):
    """URL recusada: esquema inválido, porta incomum ou host não público."""


_ALLOWED_PORTS = {None, 80, 443, 8080, 8443}
_TTL = 600
_CACHE = {}
_LOCK = threading.Lock()


def _address_ok(text):
    try:
        addr = ipaddress.ip_address(text.split("%")[0])
    except ValueError:
        return False
    return addr.is_global and not addr.is_multicast


def host_is_public(host, port=None):
    """True se TODOS os endereços do host são públicos (resultado em cache)."""
    host = (host or "").strip("[]").lower()
    if not host:
        return False
    try:
        ipaddress.ip_address(host)
        return _address_ok(host)
    except ValueError:
        pass
    now = time.monotonic()
    with _LOCK:
        hit = _CACHE.get(host)
        if hit and now - hit[1] < _TTL:
            return hit[0]
    try:
        infos = socket.getaddrinfo(host, port or 443, proto=socket.IPPROTO_TCP)
        ok = bool(infos) and all(_address_ok(i[4][0]) for i in infos)
    except OSError:
        ok = False
    with _LOCK:
        if len(_CACHE) > 20000:
            _CACHE.clear()
        _CACHE[host] = (ok, now)
    return ok


def check_url(url, allow_private=False):
    """Levanta UnsafeHost se a URL não puder ser buscada com segurança."""
    parts = urlparse(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise UnsafeHost(f"URL inválida: {url[:80]}")
    if allow_private:
        return
    try:
        port = parts.port
    except ValueError:
        raise UnsafeHost("porta inválida")
    if port not in _ALLOWED_PORTS:
        raise UnsafeHost(f"porta não permitida: {port}")
    if not host_is_public(parts.hostname, port):
        raise UnsafeHost(f"host não público: {parts.hostname}")
