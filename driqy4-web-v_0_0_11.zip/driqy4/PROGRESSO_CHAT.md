# PROGRESSO — Chat estilo WhatsApp/Telegram (15 fases)

> **Índice geral e o que ainda resta (verificado em 10/11/2026): `PROGRESSO_INDICE.md`.**
> **Histórico:** as seções "Riscos" e "Pendências conhecidas da Fase N" foram escritas na época; várias foram resolvidas em fases seguintes (ex.: apagar mensagem = Fase 7, tempo real = Fase 9). O que realmente continua aberto está em "Pendências conhecidas da Fase 15" e no índice.

> Passagem de bastão entre sessões/IAs. Igual nos dois projetos
> (`driqy4/` e `flutter_app/`). **Atualize ao fim de cada fase** e pare ao
> terminar a fase (regra do usuário: 1 fase por vez, pra não estourar tokens;
> entregar os dois zips completos e atualizados).

## Pedido original
Melhorar bastante a troca de mensagens, parecida com Telegram/WhatsApp, mas
mais elaborada: **emojis, áudios, vídeos, imagens, chamadas de voz e de
vídeo**. Agora em 15 fases.

## Regras do usuário (respeitar)
- Respostas curtas, em português do Brasil.
- Edições **cirúrgicas** (nada de reescrever arquivo inteiro sem necessidade).
- Entender os **riscos antes** de implementar (ver "Riscos" abaixo).
- **Toda mudança vale para os 4 alvos**: backend, **web desktop**, **web
  celular** (mesma página, CSS responsivo) e **app Flutter**. Não entregar
  fase só num deles.
- **Entregar sempre os dois zips COMPLETOS** (projeto inteiro, não só os
  arquivos tocados) com **`X7` no nome**, no padrão
  `driqy_flutter_chat_faseN_X7.zip` e `driqy4-noticias-api_chat_faseN_X7.zip`
  (N = fase concluída).
- Fazer **só a próxima fase** e parar.

## Status das fases

| # | Escopo (backend + web desktop/celular + Flutter) | Status |
|---|---|---|
| 1 | **Backend base**: colunas novas em `messages`, migração automática, envio multipart, mídia privada, resposta (reply), idempotência, `read_at`/`delivered_at` | ✅ feita |
| 2 | **Tela de conversa nova (Flutter)**: balões, separadores de data, ticks, compositor, caixa de entrada, prévia de mídia | ✅ feita (**Flutter não compilado**) |
| 3 | **Emojis + reações** (backend `message_reactions`; Flutter com painel e chips) | ✅ feita (Flutter não compilado). Web entrou na Fase 4 |
| 4 | **Imagens/GIF** em todos os alvos: MIME por assinatura, auth por sessão p/ o site, **chat da web reescrito** (balões, emojis, reações, imagem/GIF, pré-visualização, visualizador), Flutter com galeria/câmera, miniatura e visualizador | ✅ feita (testes do backend escritos mas **não rodados** aqui; Flutter não compilado) |
| 5 | **Áudio**: gravar (Flutter: segurar p/ gravar, deslizar p/ cancelar, subir p/ travar; web: `MediaRecorder`, clicar p/ gravar), onda, player 1x/1.5x/2x. **Junto**: caixa de entrada da web portada (dívida da Fase 2) e zoom por pinça no visualizador web | ✅ feita (backend: **222 testes passaram**; Flutter não compilado; web não vista num navegador) |
| 6 | **Vídeo**: escolher/gravar, miniatura, player com Range, limite de tamanho | ✅ feita (backend: **233 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador) |
| 7 | **Ações I**: responder (UI), copiar, apagar para mim / para todos (endpoint + limpeza da mídia e da miniatura no disco) | ✅ feita (backend: **249 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador) |
| 8 | **Ações II**: editar mensagem, encaminhar, buscar na conversa | ✅ feita (backend: **269 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador) |
| 9 | **Tempo real I**: SSE/WebSocket no lugar do polling, "digitando…", entregue/lido ao vivo | ✅ feita (backend: **291 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador) |
| 10 | **Presença e caixa de entrada**: online/visto por último, inbox ao vivo, fixar/silenciar/arquivar conversa, push melhor (mídia, agrupamento) | ✅ feita (backend: **313 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador) |
| 11 | **Chamadas — sinalização (backend)**: tabela `calls`, offer/answer/ICE/encerrar, push de chamada, config STUN/TURN | ✅ feita (backend: **339 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador; **sem UI de chamada ainda**) |
| 12 | **Chamada de voz** (WebRTC: `flutter_webrtc` + navegador) + permissões | ✅ feita (backend: **344 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador; **chamada real nunca testada entre dois aparelhos**) |
| 13 | **Chamada de vídeo** (câmera, alternar câmera, mudo, tela cheia/PiP) | ✅ feita (backend: **349 testes passaram, 3 skipped**; Flutter não compilado; web não vista num navegador; **vídeo real nunca testado entre dois aparelhos**) |
| 14 | **Chamada com app fechado** (full-screen intent / CallKit), chamada perdida, histórico de chamadas na conversa (`msg_type=call`) | ✅ feita (backend: **355 passam, 3 skipped**; Flutter não compilado; web não vista num navegador; **Android tela cheia nunca testada em aparelho; iOS CallKit NÃO feito**) |
| 15 | **Documentos/arquivos + polimento final**: envio de arquivo (`msg_type=file`), limpeza de mídia órfã, testes finais, acessibilidade, documentação | ✅ feita (backend: **374 passam, 3 skipped**; Flutter não compilado; web não vista num navegador). **PLANO DE 15 FASES CONCLUÍDO** |

## Riscos (conhecidos antes de começar)
1. **Chamadas exigem TURN.** Só STUN falha em ~10–20% das redes (4G/CGNAT).
   Fase 11/12 precisa de um servidor `coturn` (ou serviço pago). Sem isso, "liga
   mas não tem áudio".
2. **Tempo real × servidor atual.** O app roda com `run_forever.bat` e SQLite.
   WebSocket exige servidor assíncrono/threaded (gevent/eventlet) — **conferir
   como o servidor de produção sobe antes da Fase 9**. SQLite + muitas
   conexões longas aumenta risco de "database is locked" (já mitigado com WAL
   e timeout 30s). SSE é a alternativa mais leve.
3. **Chamada com app fechado**: Android precisa de notificação com
   *full-screen intent*; iOS exige CallKit + VoIP push (conta Apple Developer
   paga). Nada disso dá pra validar sem aparelho real.
4. **Permissões** (câmera/microfone/notificações) em `AndroidManifest.xml` e
   `Info.plist` — esquecer = app falha em silêncio.
5. **Armazenamento**: vídeo/áudio enchem o disco rápido. Limites por tipo em
   `config.py` (`CHAT_MAX_*_BYTES`); `MAX_CONTENT_LENGTH` = 60 MB é o teto
   geral. Falta política de limpeza (ideia: apagar mídia de mensagens
   apagadas — hoje "apagar" ainda não existe, é Fase 7).
6. **Privacidade**: mídia de chat é privada (ver contrato). **Não há
   criptografia ponta a ponta**; o servidor lê tudo. Não prometer E2E na UI.
7. **Compatibilidade**: o app Flutter antigo continua funcionando (campo
   `content` mantido). Não remover `content` nem mudar o formato de
   `created_at` (ISO com "Z").
8. Nada do Flutter foi compilado pela IA (sem SDK no ambiente). Sempre
   pedir `flutter pub get` + `flutter analyze` ao usuário.
9. **Auth do site na API.** O chat da web usa `/api/v1/messages/*` com o
   cookie de sessão (decorator `chat_login_required` em `api.py`). Como o site
   não tem token CSRF, **toda requisição que altera dados via cookie exige o
   header `X-Requested-With: fetch`** (senão 400). Token Bearer inválido NUNCA
   cai pra sessão. Novas rotas de chat devem usar esse decorator.
10. **Backend testável aqui**: na Fase 5 o `pip install -r requirements.txt pytest`
    funcionou e `python -m pytest tests -q` rodou: **222 passaram, 3 skipped**
    (inclui os testes da Fase 4, que nunca tinham rodado). O JS da web passa em
    `node --check`; os templates em parse do Jinja. **Nada foi visto num
    navegador** e **nada do Flutter foi compilado** (sem SDK).
11. **Build do `record`**: com `record: ^5.1.2` o `pub get` resolve `record_linux 0.7.2`, que quebra o `flutter build apk` (erro `startStream`). O `pubspec.yaml` tem `dependency_overrides: record_linux: ^1.2.1` (correção aplicada após o usuário reportar; **não compilada pela IA** — se ainda falhar, tentar `record: ^6.0.0`).
12. **Microfone na web exige HTTPS** (ou `localhost`). Em `http://IP-da-rede:5000`
    o navegador esconde `getUserMedia` e o botão de microfone nem aparece.
13. **`record` no Android exige minSdk 23**: `build.gradle.kts` agora usa
    `maxOf(23, flutter.minSdkVersion)`. `just_audio` com `headers` usa proxy local
    no Android → precisa de `usesCleartextTraffic` (já está `true` no manifest).

14. **Chamadas (Fase 11)**: eventos `call_*` e timers vivem na memória de **um processo** (igual ao SSE).
    Sem Redis/vários workers a chamada pode não tocar → o chamador vê "tocando" até expirar (45 s). TURN: ver `COTURN.md`.

15. **Chamada de voz (Fase 12) nunca foi exercitada de ponta a ponta.** Backend testado; o WebRTC (web e Flutter) foi só escrito/revisado.
    Testar primeiro **web ↔ web (duas abas/navegadores em HTTPS ou `localhost`)**, depois app ↔ web, depois app ↔ app. Rede real (4G/CGNAT) exige TURN (`COTURN.md`).
16. **Chamada com o app em segundo plano**: o Android pode cortar o microfone depois de alguns segundos sem *foreground service*; iOS só mantém o áudio
    por causa de `UIBackgroundModes: audio`. A solução de verdade (serviço em primeiro plano / CallKit) é a **Fase 14**.

17. **Chamada de vídeo (Fase 13) nunca foi exercitada de ponta a ponta.** Mesma ordem de teste da voz: **web ↔ web (duas abas/navegadores, HTTPS ou `localhost`)**, depois app ↔ web, depois app ↔ app.
    Vídeo gasta MUITO mais banda que voz e **depende ainda mais do TURN** (`COTURN.md`). Teto aplicado: 640×480 a 24 fps; na web `maxBitrate` ≈ 800 kbps; no Flutter só a restrição de captura (sem `setParameters`).
18. **Câmera** exige HTTPS na web (igual ao microfone) e a permissão `CAMERA` no Android (já no manifest). Se a câmera falhar/for negada, a chamada **segue só com áudio** e avisa (não derruba).

## Fase 1 — o que foi feito (backend, `driqy4/`)
**Arquivos tocados:** `models.py`, `app.py`, `api.py`, `chat.py`, `uploads.py`,
`config.py`, `tests/test_chat_phase1.py` (novo). O projeto Flutter **não muda**
nesta fase (só ganha este `.md`).

- `models.Message` ganhou (todas opcionais/com padrão): `msg_type`
  (`text|image|video|audio|file|call`), `media_path`, `media_mime`,
  `media_size`, `media_duration_ms`, `media_width`, `media_height`,
  `reply_to_id`, `client_id`, `delivered_at`, `read_at`, `edited_at`,
  `deleted_at`. **Já inclui as colunas das fases 7 e 8** pra evitar nova
  migração depois.
- `app.py::_ensure_schema_upgrades` faz `ALTER TABLE messages ADD COLUMN` nas
  colunas que faltarem (idempotente, testado com banco antigo).
- `content` continua `NOT NULL`: mídia sem legenda grava um rótulo
  ("📷 Foto", "🎥 Vídeo", "🎤 Áudio", "📎 Arquivo") — site e app antigo mostram
  algo útil. A API devolve `caption` (só quando o usuário escreveu legenda).
- **Mídia privada**: salva em `instance/uploads/chat/AAAA/MM/`. A rota pública
  `/uploads/<path>` devolve **404** para `chat/...`. Só
  `GET /api/v1/messages/media/<id>` serve (Bearer, só remetente/destinatário,
  aceita Range, `Cache-Control: private`).
- `uploads.save_upload(file, "chat", ext)` — novo tipo `chat`.
- Limites e extensões em `config.py`: `CHAT_MAX_IMAGE_BYTES` 15 MB,
  `CHAT_MAX_AUDIO_BYTES` 20 MB, `CHAT_MAX_VIDEO_BYTES` 55 MB,
  `CHAT_MAX_FILE_BYTES` 25 MB, `CHAT_ALLOWED_FILE_EXT`.
- Imagens têm a assinatura (magic bytes) conferida; vídeo/áudio/arquivo por
  extensão + mimetype (webm/ogg: mimetype `audio/*` desempata).
- `chat.py` (site) também grava `read_at`/`delivered_at` ao marcar como lida.

### Contrato da API (usar nas fases seguintes)
`POST /api/v1/messages/<username>`
- Texto: JSON `{"content": "...", "client_id"?, "reply_to_id"?}`.
- Mídia: `multipart/form-data` com `file` + opcionais `content` (legenda),
  `duration_ms`, `width`, `height`, `reply_to_id`, `client_id`.
- Erros: 400 (vazio/tipo inválido/reply inválido), 413 (grande demais).
- `client_id` repetido pelo mesmo remetente devolve a mesma mensagem (reenvio
  seguro; o app deve gerar um UUID por mensagem).

`serialize_message` devolve: `id, content, caption, msg_type, media_url,
media_mime, media_size, media_duration_ms, media_width, media_height,
reply_to {id, sender_id, msg_type, preview}, client_id, sender_id,
recipient_id, created_at, delivered_at, read_at, edited_at, deleted,
is_read, mine`.
- `media_url` é **relativa** (`/api/v1/messages/media/<id>`): o app monta com
  a base da API **e envia `Authorization: Bearer`** (`Image.network(headers:)`,
  `VideoPlayerController.networkUrl(httpHeaders:)`). Não dá pra usar
  `DriqyImage` direto sem passar header.
- `deleted: true` → conteúdo/mídia vêm vazios (a bolha mostra "Mensagem
  apagada"). Ainda não existe endpoint pra apagar (Fase 7).

### Pendências conhecidas da Fase 1
- Preview/`last_message` do inbox usa `content` (rótulo) — Flutter vai
  trocar por ícone + texto na Fase 2.
- Sem thumbnail de vídeo no servidor (Fase 6 decide: gerar no app e enviar).
- Mídia de chat não é apagada do disco em lugar nenhum ainda.
- `media_mime` vem do content-type enviado pelo cliente (não é conferido pela
  assinatura) — considerar derivar do conteúdo na Fase 4 (decidir GIF).
- Web (`messages_thread.html`/`chat.js`) ainda só mostrava texto/rótulo (resolvido na Fase 4).

## Como testar a Fase 1
```
cd driqy4
pip install -r requirements.txt pytest
python -m pytest tests/test_chat_phase1.py -q
python -m pytest tests -q                        # suíte toda
```
Manual: com um token Bearer,
`curl -H "Authorization: Bearer TOKEN" -F file=@foto.png -F content=oi http://localhost:5000/api/v1/messages/USUARIO`
e depois abrir o `media_url` devolvido (com o token do outro participante).

## Fase 2 — o que foi feito (Flutter, `flutter_app/`)
**Sem novas dependências. Backend sem mudanças.** Nada foi compilado/rodado
(sem SDK Flutter no ambiente da IA) — revisão só de leitura. Se `flutter
analyze` reclamar, corrigir antes de seguir.

- `lib/models/message.dart` — `DriqyMessage` agora tem todos os campos do
  contrato (caption, msgType, media*, replyTo, clientId, delivered/read/edited,
  deleted, isRead) **todos opcionais** (servidor antigo continua valendo).
  Novos: enums `MessageType` e `MessageLocalState` (sending/failed),
  `DriqyMessage.local(...)` (id negativo = ainda não está no servidor),
  `newClientId()`, `copyWith`, getters `type`, `isMedia`, `isRemoteRead`,
  `previewText` (rótulo "📷 Foto" + legenda; "Mensagem apagada").
- `lib/services/message_service.dart` — `sendMessage(username, content,
  {clientId, replyToId})`.
- **Novos widgets** em `lib/widgets/chat/`: `chat_format.dart` (Hoje/Ontem/
  data, hora da lista), `message_ticks.dart` (relógio/✓/✓✓/erro),
  `message_bubble.dart` (balão com gradiente da marca nas minhas, agrupamento,
  bloco de resposta, "editada", "Mensagem apagada", espaço reservado pra
  mídia), `date_separator.dart`, `chat_composer.dart` (campo em pílula +
  botão de enviar; **`leading`/`trailing` são os encaixes pra emoji, anexo,
  microfone e câmera** — quando vazios não aparece nada).
- `lib/screens/message_thread_screen.dart` — reescrita: AppBar com avatar +
  nome + selo + @, lista com separadores de data e agrupamento (mesmo
  remetente < 5 min), **envio otimista** (aparece na hora com relógio; se
  falhar, toque no balão reenvia com o mesmo `client_id`), botão "ir pro fim",
  rolagem automática só se o usuário já estava no fim, e **atualização
  periódica a cada 8 s** (`_pollTimer`, pausa com o app em segundo plano).
  O polling baixa a conversa inteira (`GET /messages/<user>`) — é provisório;
  **a Fase 9 deve removê-lo** (SSE/WebSocket ou endpoint `since_id`).
- `lib/screens/messages_inbox_screen.dart` — prévia usa `previewText`, ticks
  nas minhas últimas mensagens, horário curto (hora/Ontem/data), hora em âmbar
  quando há não lidas. (O "Você:" saiu: os ticks já indicam que a última é minha.)
- `test/chat_message_test.dart` — 4 testes de modelo/formatação (não rodados).

### Pendências conhecidas da Fase 2
- Mídia na bolha é só espaço reservado (emoji grande + rótulo/legenda).
- ✓✓ cinza ("entregue") só vira real na Fase 9: hoje o servidor grava
  `delivered_at` junto com `read_at`.
- Sem "digitando…", online/visto por último (Fases 9–10) nem toque longo/menu de
  ações (Fase 7).
- Tela de chat ainda não abre o perfil ao tocar no nome (não conferi o
  construtor de `ProfileScreen`).
- Layout do `ChatComposer` (campo sem borda dentro de container) precisa ser
  visto num aparelho — o `InputDecorationTheme` global pode interferir.

## Fase 3 — o que foi feito
### Backend (`driqy4/`)
- `models.MessageReaction` (`message_reactions`: message_id, user_id, emoji,
  único por message+user; tabela criada pelo `db.create_all()`, sem ALTER).
- `PUT /api/v1/messages/<id>/reaction` `{"emoji": "👍"}` (troca a reação
  anterior) e `DELETE /api/v1/messages/<id>/reaction`. Só participantes da
  conversa; mensagem apagada/inexistente → 404; emoji inválido (texto, vazio,
  > 16 chars) → 400. Resposta: `{message_id, reactions: [{emoji, count, mine}]}`.
- `serialize_message` ganhou `reactions` (mais usadas primeiro); `get_thread`
  carrega tudo numa consulta (`_reactions_by_message`, sem N+1). Envio devolve `[]`.
- `tests/test_chat_phase3.py` (9 testes).
- **Sem push de "reagiu a…"** (decisão de risco baixo; fácil de somar depois).

### Flutter (`flutter_app/`) — não compilado
- `pubspec.yaml`: **nova dependência `emoji_picker_flutter: ^3.1.0`** → rodar
  `flutter pub get`. `widgets/chat/emoji_panel.dart` foi escrito contra a API
  3.x (`Config`, `EmojiViewConfig`, `CategoryViewConfig`, `SearchViewConfig`);
  se o `pub get` resolver outra major e der erro de compilação, o ajuste é só
  nesse arquivo.
- `ApiClient.put` (novo). `MessageService.reactToMessage/removeReaction`.
- `models/message.dart`: `DriqyReaction`, `reactions` em `DriqyMessage`,
  `applyMyReaction` (atualização otimista).
- `chat_composer.dart` agora é Stateful: botão 😊 alterna teclado ↔ painel
  de emojis; tocar no campo ou botão voltar fecha o painel. Usa
  `WillPopScope` (compatível com várias versões; gera só aviso de deprecação).
- `message_bubble.dart`: mensagem de 1–3 emojis sem texto vira emoji grande
  sem balão (`emojiOnlyCount` em `chat_format.dart`, aproximação por code
  points); chips de reação sob o balão (toque alterna a minha); toque longo.
- `message_thread_screen.dart`: toque longo abre folha com 6 reações rápidas
  (👍❤️😂😮😢🙏) + "+" para o painel completo; reagir com o emoji que já é
  meu remove; otimista com desfazer em caso de erro; `_signature` inclui reações
  (o polling de 8 s traz reações dos outros).
- Testes Dart novos em `test/chat_message_test.dart` (emoji-only, reações).

### Pendências conhecidas da Fase 3
- Reação em mensagem local (enviando/falhou) é ignorada de propósito.
- A folha de reações não destaca visualmente a reação dos outros.
- Sem notificação push de reação.
- Sort de `applyMyReaction` pode reordenar empates diferente do servidor
  (some no próximo refresh).

## Fase 4 — o que foi feito
### Backend (`driqy4/`)
- `api.py`: `_image_mime_from_head()` — `media_mime` de imagem vem da
  **assinatura do arquivo** (png/jpeg/gif/webp), não do que o cliente diz;
  ler os 12 bytes **antes** do `save_upload` (o save consome o stream).
- `GET /messages/media/<id>` agora manda `X-Content-Type-Options: nosniff`.
- **`chat_login_required`**: aceita Bearer (app) **ou** sessão do navegador
  (site) — ver Risco 9. Aplicado em: inbox, unread-count, GET/POST thread,
  mídia, PUT/DELETE reação. O resto da API segue só com Bearer.
- `tests/test_chat_phase4.py` (não rodado aqui — Risco 10).
- `static/sw.js`: cache do shell subiu pra `v11` (CSS novo).

### Web — desktop e celular (`driqy4/`)
- **Reescrita da conversa do site** (antes só texto, polling de 4 s):
  `templates/messages_thread.html` (casca) + `static/js/chat-thread.js`
  (toda a lógica) + bloco "Chat do site" no fim de `static/css/style.css`.
  O `chat.js` antigo continua só pro selo de não lidas e a caixa de entrada
  (o bloco de thread dele não ativa mais: o id agora é `cw`, não `chat-thread`).
- Recursos: balões agrupados + separadores de data, ticks (✓ ✓✓ ✓✓ azul),
  envio otimista com reenvio (clique na bolha que falhou), 1–3 emojis grandes
  sem balão, **painel de emojis próprio** (sem CDN; recentes em `localStorage`),
  **reações** (botão ☺ no desktop, clique direito, pressão longa no celular,
  chips que alternam), **imagem/GIF** (clipe, arrastar-e-soltar, colar do
  clipboard), pré-visualização com legenda, miniatura com proporção, **visualizador**
  em tela cheia (setas/teclado/deslizar, baixar), "ir pro fim" com contador de
  novas, toast de erro, links clicáveis.
- Celular: tela cheia (barra de navegação inferior escondida na conversa),
  `100dvh`, respeita área segura; Enter quebra linha (no desktop envia;
  Shift+Enter quebra).
- Atualização: **polling de 5 s da conversa inteira** só com a aba visível
  (provisório — Fase 9 troca por SSE/WebSocket).
- As rotas antigas do site (`chat.send`, `chat.poll_new`) ficaram, sem uso.

### Flutter (`flutter_app/`) — não compilado
- **Sem dependências novas** (`image_picker` já existia).
- `ApiClient`: `authHeaders` e `postFile` (1 arquivo; reaproveitado por
  áudio/vídeo). `MessageService.sendImage` e `mediaHeaders`.
- `DriqyImage`/`AnimatedGif`/`GifBytesCache`/`MediaLightbox` aceitam `headers`
  (Bearer) e `mediaTypes`. Cache de GIF é por URL (ao trocar de conta no mesmo
  processo, os bytes antigos ficam até sair do LRU).
- `DriqyMessage`: `localPath`, `localImage(...)`, `isGif`; `copyWith` preserva.
- Novo `screens/chat_image_preview_screen.dart` (`ChatImageDraft`): tela cheia
  com legenda; mede largura/altura.
- `message_bubble.dart`: miniatura (proporção 0.55–2.0, máx. 300 px), spinner
  enquanto envia, selo GIF, legenda, toque abre o visualizador.
- `message_thread_screen.dart`: clipe 📎 (Galeria/Câmera), limite 15 MB,
  `_sendImage`, `_deliver` envia imagem ou texto, reenvio reaproveita o arquivo,
  `_openImage` (deslizar entre as imagens da conversa).
- `ios/Runner/Info.plist`: `NSCameraUsageDescription` e
  `NSPhotoLibraryUsageDescription`.
- Testes Dart novos (localImage, copyWith, isGif) em `chat_message_test.dart`.

### Pendências conhecidas da Fase 4
- Galeria envia **uma** imagem por vez (sem seleção múltipla/álbum).
- HEIC/HEIF do iPhone não é aceito pelo backend (o `image_picker` costuma
  converter pra JPEG; se aparecer erro, tratar na Fase 15).
- Sem zoom por pinça no visualizador web (só no Flutter).
- Sem busca de GIFs (Giphy/Tenor) nem figurinhas.
- O compositor do Flutter não tem botão de câmera rápida (só o clipe).

## Fase 5 — o que foi feito
### Backend (`driqy4/`)
- `api.py::_audio_mime_from_head` — `media_mime` de áudio vem da **assinatura**
  (OggS, EBML/webm, `ftyp`→`audio/mp4`, RIFF/WAVE, ID3/MPEG). Arquivo que não parece
  áudio → 400. webm só é áudio se o cliente mandou `audio/*` (ou ext `webm` sem
  MIME de vídeo); `v.webm` com `video/webm` continua vídeo.
- `_sniff_chat_media` confere a assinatura; `send_message` grava o MIME derivado.
- `tests/test_chat_phase5.py` (12 testes: 5 formatos, falso rejeitado, webm vídeo ≠ áudio,
  Range 206, caixa de entrada da web, página com microfone). `test_chat_phase1.py`
  passou a usar assinatura real de m4a (o teste antigo mandava bytes "x").
- **Bug antigo corrigido** em `chat.py::inbox_updates`: ordenava as conversas
  *depois* de montar a lista e fazia `zip`, podendo casar o HTML com o `partner_id`
  errado. Agora ordena primeiro.
- `static/sw.js`: cache do shell subiu para `v12`.

### Web — desktop e celular
- **Gravar**: botão de microfone aparece quando o campo está vazio (vira enviar
  quando há texto). Clique inicia; barra com lixeira (cancelar, ou Esc), bolinha
  piscando, tempo e medidor de volume (`AnalyserNode`), e botão enviar. Formatos:
  `audio/webm;codecs=opus` → `audio/ogg;codecs=opus` → `audio/mp4` (Safari → `.m4a`).
  Mín. 0,8 s; máx. 15 min (envia o que gravou). Duração medida por relógio e enviada
  em `duration_ms`. Permissão negada / sem HTTPS → toast.
- **Player** (`audioWidget` em `chat-thread.js`): play/pausa, onda de 30 barras (seed
  por `client_id`/`id`, igual dos dois lados), clique/setas para avançar, tempo,
  velocidade 1×/1,5×/2× (lembrada em `localStorage`), um áudio por vez. O mesmo
  `<audio>` sobrevive às re-renderizações do polling (não corta o som). Contorno do
  webm sem duração (`currentTime = 1e101`).
- **Caixa de entrada nova** (`_chat_inbox_row.html`, filtro `chat_short_time`,
  `chat.js`): prévia com ícone (📷 🎥 🎤 📎) + legenda ou duração (`🎤 1:05`),
  ticks na última mensagem (✓, ✓✓ cinza, ✓✓ azul), hora curta (hoje HH:MM / Ontem /
  dd/mm/aa), hora em âmbar quando há não lidas; atualização ao vivo troca só a linha
  que mudou (`data-sig`) e mantém a ordem do servidor.
- **Zoom no visualizador**: pinça (2 dedos), roda do mouse, duplo clique/toque, arrastar
  quando ampliado; com zoom, deslizar não troca de imagem.

### Flutter (`flutter_app/`) — não compilado
- **Dependências novas**: `record: ^5.1.2` (gravar) e `just_audio: ^0.9.40` (tocar,
  aceita `Authorization`) → `flutter pub get`. Se resolver outra major e quebrar,
  os ajustes ficam em `widgets/chat/voice_recorder.dart` (record) e
  `widgets/chat/audio_message.dart` (just_audio).
- Android: `RECORD_AUDIO` no manifest, `minSdk` ≥ 23. iOS: `NSMicrophoneUsageDescription`.
- `voice_recorder.dart` (AAC/m4a mono 64 kbps ≈ 0,5 MB/min, arquivo temporário).
- `chat_composer.dart`: com o campo vazio o enviar vira **microfone** — segurar grava,
  soltar envia, deslizar à esquerda cancela, **subir trava** (aí aparece lixeira + enviar);
  voltar durante a gravação cancela. Aviso se a permissão for negada ou a gravação
  for curta (<0,8 s). Parâmetros `onVoiceRecorded`/`onVoiceMessage`.
- `audio_message.dart`: bolha com play/pausa, onda (toque/arraste avança), tempo,
  velocidade 1×/1,5×/2× global, um áudio por vez; o `AudioPlayer` só nasce no 1º play.
  Mensagem local toca o arquivo do aparelho.
- `DriqyMessage.localAudio`, `MessageService.sendAudio`, `chatDuration`, `_sendVoice` e
  ramo de áudio em `_deliver` (reenvio com o mesmo `client_id` e o mesmo arquivo).
- `api_client.dart`: extensões `m4a/ogg/mp3/wav` e `Content-Type` de áudio.
- Testes Dart novos (`chatDuration`, `localAudio`) em `chat_message_test.dart`.

### Pendências conhecidas da Fase 5
- Onda é **decorativa** (seed), não o volume real do áudio (o servidor não decodifica).
- Sem pré-escuta antes de enviar; sem rascunho de áudio; sem pausar ao receber chamada.
- Web grava por clique (não por segurar); no Flutter é segurar/deslizar.
- Velocidade no Flutter volta a 1× ao fechar o app (só em memória).
- Arquivo temporário da gravação não é apagado após o envio (o player local pode estar
  usando); limpeza de órfãos fica pra Fase 15.
- Sem "ouvido ✓" (áudio reproduzido) — o ✓✓ azul continua sendo "lida".

## Fase 6 — o que foi feito
### Backend (`driqy4/`)
- `api.py::_video_mime_from_head` — `media_mime` de vídeo vem da **assinatura**: `ftyp` →
  `video/mp4` (ou `video/quicktime` se a marca é `qt  ` ou a extensão é `.mov`); EBML →
  `video/webm` (só com extensão `.webm` e **sem** `audio/*` do cliente). Arquivo que não
  parece vídeo → 400 (o `test_chat_phase1` mandava bytes falsos; foi ajustado).
- **Miniatura**: campo multipart opcional `thumb` (JPEG/PNG/WEBP, ≤ 400 KB, conferido pela
  assinatura; inválida é **ignorada**, não derruba o envio). Fica ao lado do vídeo, sem
  coluna nova: `<media_path>.thumb` (`_chat_thumb_path`). `serialize_message` ganhou
  `media_thumb_url` (só vídeo com miniatura) e a rota
  `GET /api/v1/messages/media/<id>/thumb` (mesma regra de acesso da mídia).
  **Fase 7: ao apagar mensagem de vídeo, apagar também o `.thumb`.**
- `width/height/duration_ms` já eram aceitos; Range já funcionava (teste 206).
- `tests/test_chat_phase6.py` (11 testes). `sw.js` → cache `v13`.
### Web — desktop e celular
- O clipe agora é **foto, GIF ou vídeo** (`accept` com mp4/webm/mov; arrastar, soltar e colar
  também). Pré-visualização com `<video controls>` + legenda; mede largura/altura/duração
  pelo navegador e **gera a miniatura (1º quadro, JPEG ≤ 480 px) num `<canvas>`**, enviada
  como `thumb`. Limite 55 MB com aviso. `.mov` sem MIME é reconhecido pela extensão.
- Bolha de vídeo (`videoThumb`): miniatura (ou 1º quadro via `<video preload=metadata>` se
  não houver), botão ▶, duração e "Enviando…". Clique abre **player em tela cheia**
  (`openVideo`: `controls`, autoplay, baixar, Esc/✕ fecha e para o som).
### Flutter — não compilado
- **Sem dependências novas** (`video_player` e `image_picker` já existiam).
- Clipe 📎 agora tem 4 opções: Galeria (foto/GIF), Câmera (foto), **Vídeo da galeria**,
  **Gravar vídeo** (máx. 5 min via `maxDuration`). Limite 55 MB.
- `screens/chat_video_preview_screen.dart` (`ChatVideoDraft`): toca o arquivo, mede
  duração/largura/altura pelo `VideoPlayerController`, legenda, enviar.
- `screens/chat_video_player_screen.dart`: tela cheia, local ou `networkUrl` com Bearer.
- `DriqyMessage`: `mediaThumbUrl`, `localThumbPath`, `localVideo(...)`; `MessageService.sendVideo`;
  `ApiClient.postFile(thumb:)` e Content-Type de vídeo; `message_bubble.dart` reaproveita o
  layout da imagem com ▶ + duração; `_deliver` ganhou o ramo de vídeo (reenvio igual).
- Testes Dart novos (`videoTests`) em `chat_message_test.dart` (não rodados).

### Pendências conhecidas da Fase 6
- **Flutter não gera miniatura** (evitei `video_thumbnail`, dependência nativa pesada): vídeo
  enviado pelo app aparece no destino como fundo escuro + ▶ (na web, com o 1º quadro via
  `<video>`). Se quiserem, adicionar `video_thumbnail` e passar `thumb:` em `_pickVideo`.
- **Sem compressão/transcodificação**: o limite de 55 MB só barra; vídeo grande de celular
  pode passar disso. (`video_compress` fica como ideia, risco de build.)
- `.mov` do iPhone (HEVC) pode não tocar no Chrome/Firefox (só Safari); o download funciona.
- Vídeo gravado pela câmera do Flutter vem do `image_picker` (pode ser grande); sem barra de
  progresso de upload (só "Enviando…"/relógio).
- Sem pausa automática do vídeo ao sair da tela/receber chamada.

## Fase 7 — o que foi feito
### Backend (`driqy4/`)
- **`DELETE /api/v1/messages/<id>?scope=me|all`** (padrão `me`; também aceita `scope` no JSON).
  - `all`: **só o remetente**, dentro de `CHAT_DELETE_WINDOW_SECONDS` (48 h, em `config.py`).
    Chama `_purge_message`: apaga a mídia **e a miniatura `.thumb`** do disco, zera `media_*`,
    `content=""`, grava `deleted_at` e remove as reações. A linha fica (mantém a ordem).
    Idempotente. Fora da janela → 403; não-remetente → 403; estranho → 404.
  - `me`: nova tabela **`message_hidden`** (`MessageHidden`, única por mensagem+usuário; criada
    pelo `db.create_all()`, sem migração). Quando os **dois** escondem, a mídia sai do disco.
- `models.not_hidden_for(user_id)` filtra "apagadas para mim" em: `GET /messages` (inbox: a
  última mensagem ignora as escondidas e a conversa **some** da lista se tudo foi escondido),
  `GET /messages/<user>`, `User.unread_messages_count`, e no site renderizado (`chat.py`:
  inbox, atualizações, thread, `poll_new`).
- `serialize_message` ganhou **`can_delete_for_all`** (o servidor decide se o botão aparece) e a
  citação (`reply_to.preview`) vira "Mensagem apagada" se a original foi apagada para todos
  ou escondida para quem vê. Não dá mais para **responder** a mensagem apagada/escondida (400).
- Responder já funcionava no envio (`reply_to_id` em JSON e multipart); agora há UI.
- `tests/test_chat_phase7.py` (16 testes). `sw.js` → cache `v14`.
### Web — desktop e celular
- Toque longo / botão direito / ☺ abre o menu: reações + **Responder**, **Copiar** (texto ou
  legenda; fallback `execCommand`) e **Apagar** (diálogo: "para todos" só se
  `can_delete_for_all`, "para mim", cancelar).
- **Barra "Respondendo a…"** acima do campo (Esc ou ✕ cancela); a resposta vai em texto, foto,
  vídeo e áudio. A citação na bolha mostra autor (Você/nome) e **rola até a original**
  (destaque âmbar). **Arrastar a bolha para a direita (touch)** também responde.
### Flutter — não compilado
- Folha do toque longo ganhou **Responder / Copiar / Apagar**; apagar abre outra folha
  (para todos só se `canDeleteForAll`). **Deslizar a bolha para a direita responde**
  (`Dismissible` com `confirmDismiss` falso). `_ReplyBar` acima do compositor.
- `DriqyMessage.canDeleteForAll`, `copyWith(replyTo:)`, `DriqyReplyRef.fromMessage`;
  `MessageService.deleteMessage(id, forAll:)`; `_deliver` repassa `replyToId` (reenvio incluso);
  bolha mostra autor da citação e toque rola até a original via `GlobalKey`.
- Testes Dart novos (`actionsTests`) — não rodados.

### Pendências conhecidas da Fase 7
- **Flutter: tocar na citação só rola se a original estiver montada** na lista; senão avisa
  "role para cima" (lista é `ListView.builder` com alturas variáveis). A web rola sempre.
- "Apagar para mim" não tem **desfazer**; não há "limpar conversa" nem apagar conversa inteira.
- Mensagem **apagada para todos** continua aparecendo como "🚫 Mensagem apagada" (não dá para
  escondê-la depois com "para mim" pela UI, embora o endpoint aceite).
- Mensagem que **falhou** ao enviar não tem "Descartar" (só tocar para reenviar).
- Quem apagou para todos **não é avisado por push**; o outro lado vê no próximo poll (5 s web,
  8 s Flutter) — tempo real é a Fase 9.
- ~~Editar mensagem~~ → feito na Fase 8 (ver abaixo).

## Fase 8 — o que foi feito
### Backend (`driqy4/`)
- **Editar** — `PATCH /api/v1/messages/<id>` `{"content": "..."}`. Só o **remetente**, só `msg_type == text`
  (legenda de mídia **não** edita), dentro de `CHAT_EDIT_WINDOW_SECONDS` (**24 h**, `config.py`). Grava `edited_at`.
  Texto igual ao atual **não** conta como edição. Vazio → 400 (use apagar). Apagada/escondida pelo remetente → 404;
  não-remetente → 403; fora da janela → 403. Resposta já traz as reações. A citação (`reply_to.preview`) reflete o
  texto novo sozinha (é lida na hora).
- **Encaminhar** — `POST /api/v1/messages/<id>/forward` `{"usernames": ["ana","beto"], "client_id"?}`. Até
  `CHAT_FORWARD_MAX_TARGETS` (**5**) destinos, sem repetição, nunca para si mesmo. **Valida tudo antes de criar**
  (um destino inválido → nada é encaminhado). A mensagem de origem precisa estar visível para quem encaminha (não
  apagada, não escondida). Cria uma mensagem nova por destino com a coluna nova **`messages.forwarded`**
  (Boolean, migração automática em `_ensure_schema_upgrades`, testada com banco antigo). **Mídia (e a miniatura do
  vídeo) é COPIADA no disco** (`_copy_chat_file`), não compartilhada: assim `_purge_message` continua seguro (apagar
  um lado nunca quebra o outro). Origem sem arquivo no disco → 410. Se a cópia falhar no meio, os arquivos já copiados
  são apagados e nada é gravado (500). `client_id` repetido por destino devolve a mesma mensagem (reenvio seguro).
  Push normal por destino. Resposta: `{"forwarded": [{"username", "message"}]}`.
- **Buscar** — `GET /api/v1/messages/<username>/search?q=&limit=&before_id=`. `q` ≥ 2 caracteres (senão 400).
  Casa **sem acento e sem diferenciar maiúsculas** (`_norm_search`: NFD + casefold, feito em Python — o `LIKE` do
  SQLite não trata `É`/`é`; `%` e `_` são literais). Procura em texto **e legendas**; o rótulo automático de mídia sem
  legenda ("📷 Foto") **não** casa. Respeita "apagar para mim" e "apagar para todos". Ordem: mais recentes primeiro;
  `limit` 50 (máx. 100); `before_id` pagina; devolve `total`, `has_more`, `results` (mensagens serializadas, com
  reações). Carrega as linhas da conversa inteira (id/content/type) e filtra em memória — ok para conversas normais.
- `serialize_message` ganhou **`can_edit`** (o servidor decide; mesmo papel do `can_delete_for_all`) e **`forwarded`**.
- `tests/test_chat_phase8.py` (20 testes). `sw.js` → cache `v15`.
### Web — desktop e celular (`chat-thread.js`, `messages_thread.html`, `style.css`)
- Menu da bolha (toque longo/botão direito/☺): novos **✎ Editar** (só se `can_edit`) e **➦ Encaminhar**.
- **Editar**: o campo recebe o texto, a barra acima do campo vira "Editando mensagem" (cor rosa; ✕ ou Esc cancela);
  enviar faz o `PATCH` e troca a bolha (rótulo "editada" aparece nos dois lados no próximo poll). Editar e responder
  são exclusivos; anexar durante a edição avisa e não faz nada. Se o `PATCH` falha, o texto volta ao campo.
- **Encaminhar**: modal com filtro (sem acento) e a lista das **conversas já existentes** (`GET /messages`), seleção
  múltipla até 5, botão "Encaminhar (n)". Mensagem encaminhada mostra "↪ Encaminhada".
- **Buscar**: lupa no cabeçalho (ou **Ctrl+F**) abre a barra; busca com 300 ms de espera, "n de N", ▲ (mais antigo)
  / ▼ (mais novo) / Enter / Shift+Enter, **realce `<mark>`** nos textos e legendas (mesma regra sem-acento) e borda
  âmbar na bolha atual; Esc ou ✕ fecha. Resposta de digitação antiga é descartada (`searchSeq`).
### Flutter (`flutter_app/`) — **não compilado**
- **Sem dependências novas.** `ApiClient.patch` (novo); `MessageService.editMessage / forwardMessage / searchThread`
  (+ `ChatSearchResult`); `DriqyMessage.canEdit` e `forwarded` (também no `copyWith`).
- `widgets/chat/chat_format.dart`: `foldSearch` / `findSearchMatches` (tabela de acentos própria, o tamanho do texto
  não muda; se mudar por algum caractere raro, **não realça** em vez de errar o índice). `message_bubble.dart`:
  `highlight`, `searchCurrent` (borda âmbar), rótulo "↪ Encaminhada".
- `screens/chat_forward_screen.dart` (novo): lista de conversas com filtro, até 5, faz o pedido e devolve os `@`.
- `message_thread_screen.dart`: folha do toque longo ganhou **Editar** e **Encaminhar**; modo edição (barra rosa,
  `_ReplyBar` ganhou `accent`/`tooltip`); lupa na AppBar → barra de busca (▲▼, contador, voltar fecha); `_jumpToMessage`
  **estima a posição pelo índice e refina por até 8 quadros** (resolve a pendência da Fase 7 só para a busca — a
  citação continua só rolando se a original estiver montada). `WillPopScope` fecha busca/edição antes de sair.
  `_signature` agora inclui `editedAt`, preview da citação e `canEdit`.
- Testes Dart novos (`phase8Tests`) — não rodados.

### Pendências conhecidas da Fase 8
- **Encaminhar só para conversas existentes** (não há busca de pessoas nova; não existe endpoint de busca de usuários
  na API). Fica para a Fase 10 (inbox) ou 15.
- Encaminhar **uma mensagem por vez** (sem seleção múltipla de mensagens).
- **Legenda de mídia não é editável**; mensagem encaminhada não guarda a origem (só o selo).
- "Editada" chega pelo polling (5 s web / 8 s Flutter) — tempo real é a Fase 9. Sem push de edição.
- Busca: janela de edição/limite de 100 resultados por consulta (há `before_id`, mas a UI não pagina: mostra "100+").
- Busca **não pesquisa nomes de arquivo/áudio** (não são texto). Inbox da lista de conversas não busca mensagens.
- Flutter: `_jumpToMessage` depende de a estimativa convergir (altura das bolhas varia); se não achar em 8 quadros, avisa.
- Ctrl+F da web **sequestra** a busca do navegador só nesta página (de propósito; fechar com Esc devolve).

## Pendências conhecidas das Fases 1–4 (revisão do usuário) — onde caem
- ✅ **Caixa de entrada da web** (prévia com ícone, ticks, hora curta) — feita na Fase 5.
- ✅ **Zoom por pinça no visualizador web** — feito na Fase 5.
- ✅ (Fase 9) **Entregue × lido** agora são separados. Antes: o servidor gravava `delivered_at` junto com
  `read_at`; corrigido na Fase 9 nos 4 alvos (ver "Fase 9").
- ✅ **Contador de não lidas por polling** (`chat.js`): agora ao vivo (Fase 9), com polling lento de reserva.
- ⏳ **Push de reação**: decisão da **Fase 3**/10 (hoje não existe em nenhum alvo).
- ✅ (Fase 15) **Rotas antigas** `chat.send` e `chat.poll_new` removidas.
- ✅ (Fase 15) HEIC/HEIF aceito (como documento). ⏳ Seleção múltipla de fotos e busca de GIFs: ficam como melhoria futura (fora das 15 fases).

## Fase 9 — o que foi feito
**Como o servidor sobe (Risco 2 conferido):** `run_forever.bat` → `python app.py` → `app.run(debug=True, threaded=True)`
(o `threaded=True` foi escrito de forma explícita). É **um processo só, com threads** → um barramento em memória funciona.
Cada conexão SSE ocupa 1 thread. **Com `gunicorn -w N` (vários processos) os eventos NÃO atravessam workers**: os clientes
simplesmente ficam no polling lento (nada quebra). Para escalar: trocar `ChatHub` por Redis pub/sub e usar workers
`gthread`/`gevent`. Atrás de nginx: já vai `X-Accel-Buffering: no`; ainda assim use `proxy_buffering off` e `proxy_read_timeout`>60s.
### Backend (`driqy4/`)
- `chat_events.py` (novo): `ChatHub` (fila por conexão, até `CHAT_SSE_MAX_PER_USER`=8 — a mais antiga cai; fila cheia →
  descarta o atraso e manda `resync`), `sse()`, `notify_one`, `notify_pair`, anti-spam do "digitando" (1 por 1,5 s por par).
- `GET /api/v1/messages/stream` (SSE; Bearer **ou** cookie da sessão). Manda `retry: 3000`, `ready`, e `: ping` a cada
  `CHAT_SSE_KEEPALIVE_SECONDS`=15. `CHAT_SSE_ENABLED=False` → 503 (clientes ficam no polling). Limpeza da conexão também
  via `call_on_close` (gerador que nunca começou não roda o `finally`).
- **Eventos** (todos com `partner` = @ do OUTRO lado, sem corpo de mensagem — o cliente rebusca pela API REST):
  `ready`, `message` (`id`), `update` (`id`, `kind`: edit|delete|hide|reaction), `read` (o outro leu), `read_self` (li em
  outra aba), `delivered`, `typing` (`state`: typing|recording|stop), `resync`. `message` vai aos DOIS lados (outras abas
  do remetente também). Quem não é da conversa nunca recebe (testado).
- `POST /api/v1/messages/<username>/typing` `{"state"}` (typing|recording|stop; `stop` nunca é barrado pelo anti-spam).
- **Entregue × lido**: `_mark_delivered(user)` marca `delivered_at` de tudo que estava pendente quando o destinatário
  **conecta o stream ou abre a caixa de entrada** (`GET /messages`) e avisa cada remetente (`delivered`). Mensagem nova
  para quem já está conectado nasce entregue (`_after_send`). Ler usa `COALESCE(delivered_at, agora)` — **não sobrescreve**
  mais a hora de entrega. Vale também em `chat.py` (site legado). Encaminhar, editar, apagar e reagir também notificam.
- `tests/test_chat_phase9.py` (22 testes: hub, stream, entregue, lido, update, typing, isolamento, páginas web). `sw.js` → `v16`.
### Web — desktop e celular
- `static/js/chat-live.js` (novo, carregado em toda página logada): **UMA conexão por navegador** (limite de ~6 conexões
  por site): as abas disputam um Web Lock; a líder abre o `EventSource` e repassa pelo `BroadcastChannel`; se ela
  fechar, outra assume. Sem Web Locks (navegador antigo) só as páginas do chat abrem a própria conexão.
  API: `window.driqyLive.on(tipos, fn)` e `.connected()`.
- `chat-thread.js`: eventos da conversa → `fetchThread()` (junta rajadas, 120 ms); **"digitando…" / "gravando áudio…"**
  no cabeçalho (some em 6 s sem novo aviso ou ao chegar mensagem); envia "digitando" a cada 3 s e `stop` ao apagar/enviar;
  grava áudio avisa `recording` a cada 4 s. Polling cai para ~30 s **só enquanto** o stream está vivo.
- `chat.js`: selo de não lidas e lista da caixa de entrada atualizam na hora; polling idem ~30 s.
### Flutter (`flutter_app/`) — **não compilado**
- `services/chat_live.dart` (novo, **sem dependência nova**: `http` com stream): conexão única por app com contagem de
  telas (`acquire`/`release`), reconecta com espera 1→30 s, vigia 45 s sem dados, fecha em segundo plano (o FCM cuida) e
  volta ao abrir; `AuthService.logout` chama `reset()`.
- `message_thread_screen.dart`: ouve eventos (só da conversa aberta), "digitando…"/"gravando áudio…" na AppBar (âmbar),
  envia "digitando" (3 s) e `stop`; polling ~32 s com stream vivo. `messages_inbox_screen.dart`: recarrega **sem piscar**
  (`_load(silent: true)`). `driqy_top_bar.dart`: selos ao vivo. `MessageService.sendTyping`. Testes Dart novos (não rodados).

### Pendências conhecidas da Fase 9
- **Vários workers/máquinas**: sem Redis os eventos não cruzam processos (ver acima). Polling lento cobre.
- Eventos **não carregam a mensagem**: cada evento causa um `GET` da conversa inteira (igual ao polling de antes, só que
  na hora certa). Otimizar com `since_id` + patch local fica para a Fase 15.
- Flutter **não envia** "gravando áudio…" (só mostra o que a web manda) — o `ChatComposer` não expõe o início da gravação.
- Entregue: considera "entregue" quem tem **stream aberto ou abriu a caixa de entrada**; aparelho só com push (app
  fechado) continua ✓ cinza-claro/"enviado" até abrir — comportamento igual ao WhatsApp, mas o push FCM não confirma entrega.
- Dev server do Flask com `debug=True`: o recarregador derruba os streams a cada salvamento (reconectam sozinhos).
- Ctrl+F e a janela de edição continuam como na Fase 8. Sem som/vibração novos.

## Fase 10 — o que foi feito
### Backend (`driqy4/`)
- **`chat_extras.py` (novo)** — presença, preferências e texto do push, usado pela API **e** pelo site (`chat.py`).
  Não importa `api.py` (evita import circular).
- **Presença**: `users.show_presence` (Boolean, padrão 1; migração em `_ensure_schema_upgrades`, usuário antigo continua
  visível). `presence_payload(partner, viewer)` → `{visible, online, last_seen_at}`. **Privacidade recíproca (WhatsApp):**
  se QUALQUER um dos dois escondeu, `visible=false` e nada vaza (nem online, nem horário). `online` = tem conexão SSE
  aberta (`hub.is_online`); só se `CHAT_SSE_ENABLED=False` cai no fallback "requisição nos últimos 90 s".
  - Evento SSE novo **`presence`** (`partner`, `visible`, `online`, `last_seen_at`) enviado só aos **contatos conectados**
    (quem já tem conversa; estranho nunca recebe — testado). Disparo: 1ª conexão do usuário (`on_connect`) e, ao cair a
    última, **após `CHAT_PRESENCE_GRACE_SECONDS` (5 s)** — F5 desconecta/reconecta e não pode piscar "offline".
    `last_seen_at` é gravado com a **hora da saída**. `hub.unsubscribe` agora devolve `True/False` (idempotente: a saída
    não é tratada duas vezes pelo `finally` + `call_on_close`).
  - `GET/PUT /api/v1/messages/privacy` `{"show_presence": bool}` (400 se não for booleano). Ao mudar, avisa os contatos
    (`presence`) e as minhas outras abas (`prefs` com `partner` vazio).
  - `GET /messages` e `GET /messages/<user>` trazem `partner.presence`; a conversa traz também `prefs`.
- **Fixar / silenciar / arquivar**: tabela **`conversation_prefs`** (`ConversationPref`; `db.create_all()`, sem ALTER; única por
  usuário+parceiro; só vale para quem configurou). `PUT /api/v1/messages/<user>/prefs` (parcial: `pinned`/`muted`/`archived`,
  precisam ser booleanos) e `GET`. Regras: **arquivar desafixa; fixar desarquiva**; máx. `CHAT_MAX_PINNED` = **3** fixadas
  (400 acima). Evento SSE **`prefs`** (`partner`) só para o próprio usuário (outras abas/aparelhos).
  - `GET /messages` ordena **fixadas primeiro (a fixada por último no topo), depois a mais recente**; arquivadas ficam de
    fora e vem `archived_count`; **`?archived=1`** lista só o arquivo; **`?archived=all`** traz tudo (usado pelo encaminhar —
    web e Flutter já usam). Cada item tem `prefs`.
  - **Mensagem nova desarquiva** (`_after_send`): sempre para quem enviou; para quem recebeu só se **não** silenciou
    (arquivada+silenciada fica quieta). Emite `prefs`.
- **Push melhor** (`chat_extras.push_chat_message`, usado em envio, encaminhar e no site legado): **silenciada → não manda
  push**; texto = ícone + legenda, ou rótulo (`🎤 Áudio (1:05)`; `↪` se encaminhada); várias não lidas da mesma pessoa viram
  **uma** notificação (mesma `tag` por conversa) com título `Ana (3 mensagens)`; `data` ganhou `msg_type` e `unread_count`;
  `push.send_push_to_user(..., count=)` põe `notification_count` (Android) e `thread_id` (iOS).
- `tests/test_chat_phase10.py` (22 testes). `tests/conftest.py`: `CHAT_PRESENCE_GRACE_SECONDS = 0`. `test_chat_phase9.py`:
  `_next_event` ignora `presence` (evento novo, coberto na fase 10). `sw.js` → cache `v17`.
### Web — desktop e celular
- **Cabeçalho da conversa** (`chat-thread.js`): "online" (verde) / "visto por último hoje às 14:32" / "ontem às…" /
  "em dd/mm/aaaa" / só o @ se escondido. "digitando…" tem prioridade e volta ao estado de presença. Atualiza por evento
  `presence`, pelo `GET` da conversa, e o texto "envelhece" a cada minuto.
- **Caixa de entrada** (`_chat_inbox_row.html`, `messages_inbox.html`, `chat.py`, `chat.js`): ponto verde de online no avatar,
  📌 / 🔕, badge cinza quando silenciada, **menu ⋯** (desktop: botão, clique direito; **celular: pressão longa**) com
  Fixar/Desafixar, Silenciar/Reativar, Arquivar/Desarquivar; link **"Arquivadas (n)"** → `/mensagens/?arquivadas=1`;
  **toggle "Mostrar online e visto por último"**. A lista ao vivo agora **remove** linhas que saíram (arquivou) e recarrega
  em `prefs`/`presence`. Toast de erro (ex.: limite de fixadas). `chat-live.js`: `EVENTS` ganhou `prefs` e `presence`.
### Flutter (`flutter_app/`) — **não compilado**, **sem dependências novas**
- `models/presence.dart` (novo): `DriqyPresence`, `DriqyChatPrefs`. `DriqyConversation` ganhou `presence`/`prefs`.
- `MessageService`: `getInboxPage({archived, all})` (+ `InboxPage`), `getInbox({all})` (compatível),
  `setConversationPrefs`, `getShowPresence`, `setShowPresence`; `MessageThread` ganhou `presence`/`prefs`.
- `chat_format.dart`: `presenceLabel(...)`. `ChatEvent`: `online`/`visible`/`lastSeenAt`.
- `message_thread_screen.dart`: subtítulo da AppBar mostra a presença (verde se online; âmbar/itálico "digitando…" tem
  prioridade), 🔕 ao lado do nome se silenciada, reage a `presence`/`prefs`, reenvelhece a cada minuto.
- `messages_inbox_screen.dart`: ponto verde no avatar, 📌/🔕, badge cinza quando silenciada, **toque longo** abre folha
  (Fixar/Silenciar/Arquivar), linha **"Arquivadas"** no topo (abre a mesma tela com `archivedView: true`), `SwitchListTile`
  de privacidade. `chat_forward_screen.dart` usa `getInbox(all: true)`.
- Testes Dart novos (`phase10Tests`) — não rodados.

### Pendências conhecidas da Fase 10
- **Vários workers**: sem Redis o `presence` (como todo SSE) não cruza processos; a presença só aparece para quem está no
  mesmo processo. O polling cobre mensagens, **mas "online" fica sempre falso** nesse cenário.
- **App Flutter em segundo plano** fecha o stream (Fase 9) → aparece **offline** mesmo com o app aberto na bandeja; "visto por
  último" = hora em que saiu do primeiro plano. Igual ao comportamento esperado, mas quem esperava "online" via push estranha.
- **Silenciar não é por tempo** (8 h / 1 semana / sempre): só liga/desliga. Silenciada **continua contando** no selo geral
  de não lidas (`unread_messages_count` não mudou) e o push é totalmente suprimido.
- **Fixar/silenciar/arquivar não existe dentro da conversa** (só na caixa de entrada); a conversa só mostra o 🔕.
- Sem push de **reação**/**edição**/**apagar** (decisão mantida). Sem imagem no push (mídia é privada; FCM exige URL pública).
- `<button>` dentro do `<a>` da linha (web) é HTML inválido pelo padrão, mas funciona (`preventDefault`). O menu ⋯ some no
  celular (`pointer: coarse`): lá é pressão longa.
- Rota `/api/v1/messages/privacy` e `/stream` colidem com usernames de mesmo nome (`/messages/<username>`): a rota fixa
  ganha. ✅ Fase 15: esses nomes (`privacy`, `stream`, `chamadas`, `api`) agora são recusados no cadastro e na troca de nome.
- Grace de 5 s roda num `threading.Timer` por saída (daemon); aceitável para um processo só.

## Fase 11 — o que foi feito
### Backend (`driqy4/`)
- **`models.Call`** (`calls`; criada pelo `db.create_all()`, sem ALTER): `caller_id, callee_id, media` (voice|video), `state`
  (`ringing|accepted|declined|missed|ended|failed|busy`), `end_reason` (`canceled|timeout|hangup|declined|busy|stale`),
  `client_id`, `offer_sdp`, `answer_sdp` (**só enquanto viva**; zerados ao terminar), `created_at, answered_at, ended_at, heartbeat_at`.
  (`failed` existe mas nada o grava ainda — reservado para a Fase 12, falha de mídia.)
- **`api_calls.py` (novo)**, importado no fim de `api.py` (usa `api_bp`/`chat_login_required`: Bearer **ou** cookie + `X-Requested-With: fetch`):
  - `GET /calls/config` → `{enabled, ice_servers, turn_configured, ring_seconds, ping_seconds}`. STUN padrão do Google; TURN por
    `CALL_TURN_URLS` + `CALL_TURN_SECRET` (coturn `use-auth-secret`: usuário `expira:id`, senha HMAC-SHA1, válida 6 h) ou usuário/senha fixos.
  - `POST /calls/<username>` `{media, offer:{type:"offer",sdp}, client_id?}` → **201** (200 se `client_id` repetido). 400 (próprio/media/SDP),
    404, 413 (SDP > 16 KB), 503 (`CALL_ENABLED=False`), **409** `code:"already_in_call"` (eu) ou `code:"busy"` (o outro; grava uma linha `busy`).
  - `GET /calls/active` (retomar), `GET /calls?limit&before_id` (histórico), `GET /calls/<id>` (traz `offer` p/ callee, `answer` p/ caller
    após aceitar, `ice` = candidatos já enviados pelo outro lado).
  - `POST /calls/<id>/answer` `{answer}` (só callee; `ringing→accepted`), `/decline` (só callee), `/end` (aceita→`ended/hangup`; tocando: chamador
    cancela→`missed/canceled`, destinatário→`declined`; idempotente), `/ice` `{candidate|null}` (≤ 2 KB; 150 por usuário/chamada → 429; chamada
    encerrada → 409), `/ping` (sinal de vida).
  - Estranho/não participante → **404** (nunca vaza). Transições são **atômicas** (`UPDATE ... WHERE state IN (...)`): duas ações simultâneas não passam as duas.
  - **Expiração preguiçosa** (vale mesmo se o Timer se perder num reinício): `ringing` > 45 s → `missed/timeout` (+ push "perdida"); `accepted` sem
    ping/ICE por 90 s → `ended/stale` (quem caiu não fica "ocupado" para sempre). Também há `threading.Timer` por chamada.
  - **Um usuário, uma chamada viva.** Silenciar conversa **não** silencia chamada (só mensagens).
- **Eventos SSE novos** (⚠️ diferente dos de mensagem, **carregam corpo**): `call_incoming` (callee: `call_id, partner, media, created_at,
  ring_seconds, offer`), `call_signal` (`kind: answer|ice`, `answer`/`candidate`), `call_state` (os dois lados: `state, reason, by`). `partner` = @ do outro.
  Minhas outras abas recebem `call_state` ao ligar/atender (param de tocar). Quem não participa nunca recebe (testado).
- **Push**: `push.py` — `type:"call"` usa canal **`driqy_calls`**, TTL 45 s, `apns-priority: 10` + expiração. `type:"call_missed"` ao perder.
  Push de chamada vai **sempre** (mesmo com stream aberto: o app em 2º plano fechou o stream; o cliente deve **deduplicar por `call_id`**).
- `config.py`: `CALL_ENABLED, CALL_RING_SECONDS, CALL_SDP_MAX_BYTES, CALL_ICE_MAX_BYTES, CALL_ICE_MAX_PER_CALL, CALL_PING_SECONDS,
  CALL_STALE_SECONDS, CALL_STUN_URLS, CALL_TURN_URLS, CALL_TURN_SECRET, CALL_TURN_USERNAME, CALL_TURN_CREDENTIAL, CALL_TURN_TTL_SECONDS`.
- **`COTURN.md` (novo)**: instalação do coturn + `turnserver.conf` + variáveis de ambiente. **Sem TURN, chamada muda em ~10–20 % das redes.**
- `tests/test_chat_phase11.py` (26 testes). `sw.js` → cache `v18`.
### Web — desktop e celular
- `static/js/calls-api.js` (novo; carregado em `base.html` logado): `window.driqyCalls` com `config/active/history/start/get/answer/decline/end/ice/ping`
  (erros com `.status` e `.code`). `chat-live.js`: `EVENTS` ganhou `call_incoming`, `call_signal`, `call_state`
  (use `window.driqyLive.on(["call_incoming"], fn)`). **Sem botões nem tela de chamada** (decisão: botão morto confunde; entram na Fase 12).
### Flutter (`flutter_app/`) — **não compilado**, **sem dependências novas**
- `models/call.dart` (`DriqyCall`, `CallMedia`, `CallState`, `DriqyIceServer`, `CallConfig`), `services/call_service.dart`
  (`getConfig/active/history/start/answer/decline/end/sendIce/ping`), `ChatEvent` ganhou `isCallEvent/callId/media/reason/by/offer/answer/candidate`,
  canal Android `driqy_calls` (importância máxima) em `push_notification_service.dart`. Testes Dart novos (3) — não rodados.

### Pendências conhecidas da Fase 11
- **Nenhuma UI** (web e Flutter): não dá para ligar de verdade ainda. Só dá para testar a sinalização por `curl`/console (`driqyCalls`).
- Push de chamada **em primeiro plano** no Flutter cai no canal `driqy_activity` (o handler só conhece mensagem/atividade): Fase 12 trata
  `data.type == "call"` abrindo a tela de chamada; tocar a notificação ainda não abre nada. Toque contínuo/tela cheia/CallKit: Fase 14.
- Chamada **perdida** só gera push; **não** vira mensagem na conversa (`msg_type=call`: Fase 14). `busy` não avisa o chamado.
- Sem renegociação (ligar a câmera no meio da chamada de voz) — Fase 13 decide (`/calls/<id>/renegotiate` ou nova offer).
- Sem bloqueio de usuário: qualquer um liga para qualquer um (igual ao chat). Considerar antes de produção.
- Vários workers: eventos/timers não cruzam processos (Risco 14). `heartbeat` e expiração preguiçosa mitigam estados presos.
- `Call.state = failed` ainda não é gravado por nenhum endpoint (Fase 12: `POST /calls/<id>/end {reason:"error"}` ou similar).

## Fase 12 — o que foi feito (chamada de VOZ)
### Backend (`driqy4/`)
- `POST /calls/<id>/end` aceita `{"reason": "error"}`: com a chamada **aceita** grava `state=failed`, `end_reason=error` (falha de mídia: o WebRTC não
  conectou). Sem `reason`, continua `ended/hangup`. Tocando: `reason` é ignorado (cancelar = `missed/canceled`). Idempotente.
- `tests/test_chat_phase12.py` (5 testes). `sw.js` → cache `v19` (testes das fases 10/11 que fixavam `v18` foram atualizados). **344 passam, 3 skipped.**
### Web — desktop e celular (`static/js/call-ui.js` novo, `base.html`, `messages_thread.html`, `style.css`, `calls-api.js`)
- **Botão de telefone** no cabeçalho da conversa (`#cw-call-btn`, `data-call-user/-name/-avatar`). Qualquer elemento com `data-call-user` liga (delegação no `document`).
- **Tela de chamada global** (overlay criado por JS, vale em QUALQUER página logada): chamando / chamada recebida (avatar pulsando) / conectando / em andamento
  (tempo, **mudo**, desligar) / encerrada (mensagem + duração por 1,8 s). Esc desliga. Toques gerados por WebAudio (sem arquivos): toque de recebida e de "chamando".
- **WebRTC** (`RTCPeerConnection` com `ice_servers` de `GET /calls/config`; só áudio, eco/ruído/ganho automáticos): chamador cria a offer → `POST /calls/<user>`;
  recebe `answer` e ICE por `call_signal` (**polling de `GET /calls/<id>` a cada 2,5 s como reserva**; com SSE vivo e chamada ativa só o `ping`); ICE gerado antes
  de existir o id fica em fila. Destinatário: `call_incoming` → tela → **Atender** (pede o microfone, `setRemoteDescription(offer)`, `answer`) / **Recusar**.
  `ping` a cada `ping_seconds`; `pagehide` manda `end` com `keepalive`; falha de conexão (12 s `disconnected` ou `failed`) → `end` com `reason:"error"`.
- **Várias abas**: o toque aparece em todas; quem atende vira dona (`localStorage driqy_call_owner`, renovada no ping); `call_state accepted` fecha o toque das
  outras. Ao abrir uma página: `GET /calls/active` retoma o toque (recebida) ou encerra chamada órfã (se nenhuma aba é dona).
- Pausa todo `<audio>/<video>` da página ao ligar/receber. `Notification` do navegador só aparece **se a permissão já foi concedida** (não pedimos ainda).
- Sem HTTPS/localhost: aviso "Chamadas exigem HTTPS" (Risco 12). Sem TURN: aviso de modo de teste na tela.
### Flutter (`flutter_app/`) — **não compilado**
- **Dependência nova: `flutter_webrtc: ^0.12.5`** → `flutter pub get`. Ela pede a permissão do microfone sozinha (por isso **não** entrou `permission_handler`).
  Se a versão resolvida quebrar o build, os ajustes ficam em `services/call_manager.dart` (único arquivo que importa o plugin).
- Android: permissões `MODIFY_AUDIO_SETTINGS`, `ACCESS_NETWORK_STATE`, `CHANGE_NETWORK_STATE`, `BLUETOOTH` (≤ API 30), `BLUETOOTH_CONNECT` no manifest (`RECORD_AUDIO` já existia).
  iOS: `UIBackgroundModes` ganhou `audio`; texto do microfone cobre chamadas. **iOS precisa de deployment target ≥ 13** no Xcode/Podfile (o `ios/` do zip não tem Podfile).
- `services/call_manager.dart` (novo, `CallManager.instance`, `ChangeNotifier`): `attach(client, navigatorKey)` no login (liga o `ChatLive` e escuta `call_*`),
  `detach()` no logout, `startCall/accept/decline/hangup/toggleMute/toggleSpeaker/checkActive`. Mesma lógica da web (ICE em fila, dedupe por `call_id`, polling de
  reserva, ping, `failed` com `end(error: true)`, retomada ao voltar do 2º plano, chamada órfã é encerrada). Toque de recebida = `SystemSound.alert` + vibração a cada 2,2 s.
- `screens/call_screen.dart` (nova): tela cheia (avatar pulsando, status/tempo, Atender/Recusar, Mudo/Alto-falante/Desligar). Voltar **não** desliga. Abre por cima de
  qualquer tela via `navigatorKey` e é removida pelo gerenciador.
- `main.dart`: `attach/detach` na troca de login; push `type=call` toque → `checkActive()`; `type=call_missed` toque → abre a conversa.
  `push_notification_service.dart`: `onCallPush` — push `type=call` em **primeiro plano** não desenha popup (a tela é o aviso).
- `message_thread_screen.dart`: **ícone de telefone** na AppBar. `ApiException.code` (lê `code` do JSON: `busy`, `already_in_call`). `CallService.end(error:)`.
  `AudioMessage.pauseAll()` pausa os áudios do chat ao ligar/receber.
- Testes Dart novos (`phase12Tests`: tempo, mensagem de fim, `ApiException.code`) — não rodados.

### Pendências conhecidas da Fase 12
- **Só voz.** Chamada recebida com `media=video` toca e atende só com áudio (aviso na tela). Vídeo é a Fase 13 (renegociação ainda não existe no backend).
- **App fechado/segundo plano**: sem tela cheia/CallKit/serviço em primeiro plano; o toque depende do app aberto ou do push (Fase 14).
- Flutter: **quem liga não ouve "chamando"** (só texto); toque de recebida usa o som de alerta do sistema (sem arquivo próprio).
- Web: não pede permissão de `Notification` nem escolhe dispositivo de saída/entrada de áudio; sem botão de alto-falante (o navegador decide).
- Chamada **perdida/recusada/encerrada não vira mensagem na conversa** (Fase 14). Sem histórico de chamadas na UI.
- Sem bloqueio de usuário (qualquer um liga para qualquer um) e sem som de "desligou" nem de "ocupado".
- Vários workers/máquinas: eventos `call_*` não cruzam processos (Risco 14); o polling de reserva cobre answer/ICE/estado, mas o **toque** de quem recebe pode não chegar.
- Android: `flutter_webrtc` exige `minSdk` 23+ (já é) e Java 11; se o build reclamar de `compileSdk`, subir `compileSdk` no `build.gradle.kts`.

## Fase 13 — o que foi feito (chamada de VÍDEO)
**Decisão de escopo (sem renegociação):** vídeo vale para chamadas que **começam** como vídeo (a offer já traz a m-line de vídeo). **Não** dá para
"ligar a câmera" no meio de uma chamada de voz — isso exigiria `POST /calls/<id>/renegotiate` (nova offer/answer) e não dá para validar sem aparelhos.
Dentro de uma chamada de vídeo dá para **desligar/ligar a câmera** (`track.enabled`, sem renegociação) e **alternar câmeras**.
### Backend (`driqy4/`)
- **Nenhuma mudança de protocolo**: `media:"video"` já existia desde a Fase 11 (offer, `call_incoming.media`, histórico). `tests/test_chat_phase13.py` (5 testes)
  garante vídeo atravessando criar → evento → consultar → atender → encerrar → histórico, `media` inválida → 400, botão de vídeo na página e assets servidos.
  `sw.js` → cache `v20` (testes das fases 10/11 que fixavam `v19` foram atualizados). **349 passam, 3 skipped.**
### Web — desktop e celular (`call-ui.js`, `style.css`, `messages_thread.html`)
- **Botão de vídeo** (`#cw-video-btn`, `data-call-media="video"`) ao lado do telefone no cabeçalho da conversa. Qualquer elemento com `data-call-user` + `data-call-media="video"`
  liga em vídeo; `driqyCallUI.start(user, nome, avatar, "video")`.
- `getMedia(wantVideo)`: `getUserMedia` com áudio + vídeo **640×480 @ 24 fps** (`facingMode: user`); **se a câmera falhar, degrada para só áudio** (aviso âmbar) e a chamada continua
  (o lado de vídeo vira `recvonly`: ainda vê o outro). Chamador usa `offerToReceiveVideo`; quem atende responde com vídeo se `media=video`.
- Tela: vídeo remoto em tela cheia (`.cl-remote`), **miniatura da própria câmera** no canto (`.cl-local`, espelhada; 88–104 px). Enquanto não chega vídeo remoto (chamando/conectando),
  a própria câmera ocupa a tela esmaecida. Toque no vídeo esconde/mostra os controles. Botões: **Mudo, Câmera (liga/desliga), Virar (alterna câmera), Tela cheia (Fullscreen API), Desligar**.
  **Virar** cicla `enumerateDevices()` por `deviceId` (celular: frontal/traseira; desktop: próxima webcam) e usa `RTCRtpSender.replaceTrack` (sem renegociar). Uma câmera só → aviso.
- `limitVideo`: `maxBitrate` 800 kbps ao conectar. **Wake Lock** (`navigator.wakeLock`) mantém a tela acesa durante o vídeo. Chamada recebida mostra "Chamada de vídeo recebida" (e a Notification diz "vídeo").
- Layout responsivo (`.cl-video`): `100%` da viewport, respeita área segura; áudio continua pelo `<audio>` (o `<video>` remoto é mudo para não duplicar o som).
### Flutter (`flutter_app/`) — **não compilado**, **sem dependências novas** (`flutter_webrtc` já cobre vídeo)
- `services/call_manager.dart`: `startCall(..., {media})`; `_getMedia` (áudio+vídeo 640×480@24, **degrada para só áudio** com aviso); `RTCVideoRenderer` local/remoto **lazy**; `onTrack`
  liga o remoto; `toggleCamera`, `switchCamera` (`Helper.switchCamera`), getters `isVideo/camOff/frontCam/remoteVideo/hasLocalVideo`; viva-voz **ligado por padrão** em vídeo;
  todas as trilhas (incl. vídeo) vão para o `PeerConnection`; limpeza dos renderizadores ao encerrar.
- `screens/call_screen.dart`: `_VideoCall` (remoto em tela cheia + miniatura 104×148 + câmera própria esmaecida enquanto chama + controles Mudo/Câmera/Virar/Som/Desligar). Chamada recebida de vídeo
  usa o layout do toque, com botão **Atender** em ícone de câmera.
- `message_thread_screen.dart`: ícone **videocam** na AppBar (ao lado do telefone). `AndroidManifest.xml`: `CAMERA` + `uses-feature camera` (required=false). `Info.plist`: texto da câmera cobre vídeo.
- Testes Dart novos (`phase13Tests`) — não rodados.

### Pendências conhecidas da Fase 13
- **Sem upgrade voz → vídeo** no meio da chamada (decisão acima). Chamada de voz não tem botão de câmera.
- **Câmera desligada não avisa o outro lado**: o remoto vê quadro preto/congelado (a trilha continua enviando preto). Avisar exigiria DataChannel ou evento de sinalização (ideia: Fase 15).
- **Flutter**: sem `setParameters` de bitrate; sem PiP do sistema (Android/iOS) ao sair do app; sem rotação travada/otimizada (o `RTCVideoView` acompanha o aparelho); sem alternar quem é "grande"
  (remoto × local). **Web**: sem Picture-in-Picture do navegador; sem escolher câmera/microfone por lista; sem desfoque de fundo.
- `Virar` na web assume que `enumerateDevices` lista as câmeras (alguns navegadores só listam depois da permissão — já concedida no vídeo). Em desktop com uma webcam mostra aviso.
- Chamada de vídeo **com app fechado/2º plano** continua dependendo da Fase 14 (o Android pode cortar câmera e microfone sem *foreground service*; o iOS exige CallKit para tocar bloqueado).
- Câmera/WebRTC em rede 4G/CGNAT **sem TURN** vai falhar com frequência (Riscos 1 e 17).
- Sem som de "desligou/ocupado"; chamada perdida/recusada ainda **não vira mensagem** na conversa (Fase 14).

## Fase 14 — o que foi feito (chamada perdida/histórico na conversa + chamada com app fechado)
### Backend (`driqy4/`)
- `api_calls.log_call_message(call)`: quando a chamada termina (`ended`, `missed`, `declined`, `failed`) ou dá `busy`, grava **uma** `Message` `msg_type=call`
  (remetente = quem ligou; `client_id = "call:<id>"` garante idempotência). **Sem coluna nova:** `media_mime = "call/<voice|video>/<estado>"`,
  `media_duration_ms` = duração, `content` = rótulo neutro (`📞 Chamada de voz · 3:12`, `… perdida`, `… recusada`, `… · ocupado`, `… falhou`). Só `missed` fica **não lida**.
  Entra na conversa/inbox/SSE pelo mesmo `_after_send`. Não é editável, **não é encaminhável** (já barrado), **fora da busca** (`api.py`), "apagar para mim/todos" funcionam.
- `push.py`: push `type=call` agora é **data-only no Android** (sem bloco `notification`; `title`/`body` vão em `data`) para o app acordar e desenhar a tela cheia; no iOS o alerta fica no `aps`.
- `tests/test_chat_phase14.py` (6 testes). `sw.js` → cache `v21`. **355 passam, 3 skipped.**
### Web — desktop e celular
- `chat-thread.js`: `callBlock(m)` — balão de chamada (ícone, título por direção/estado, duração, **Ligar de volta** via `data-call-user`/`data-call-media`, delegação do `call-ui.js`).
- Página **Chamadas** (`/mensagens/chamadas`, `calls_history.html` + `static/js/calls-history.js`, usa `driqyCalls.history`, paginada, ligar de volta). Link "📞 Chamadas" na caixa de entrada. CSS `.cw-call*` e `.calls-*`.
### Flutter (`flutter_app/`) — **não compilado**, **sem dependências novas**
- `message_bubble.dart`: `_buildCall` + `onCallBack` ("Ligar de volta"); `message_thread_screen.dart` liga o callback (voz/vídeo conforme o `media_mime`).
- `screens/calls_history_screen.dart` (novo) + botão de telefone no cabeçalho da caixa de entrada (`messages_inbox_screen.dart`).
- **App fechado (Android)**: `firebaseMessagingBackgroundHandler` chama `PushNotificationService.showIncomingCall` → notificação **full-screen intent** (canal `driqy_calls`, categoria `call`,
  `ongoing`, expira em 45 s, botões **Recusar/Atender**). `onDidReceiveNotificationResponse` repassa `_action`; `main.dart` → `CallManager.handleNotificationAction` (recusar = REST sem abrir a tela;
  atender = mostra o toque e chama `accept()`). Também lê `getNotificationAppLaunchDetails` (app aberto pela notificação). Manifest: `USE_FULL_SCREEN_INTENT`, `showWhenLocked`, `turnScreenOn`.
- Teste Dart `phase14Tests` — não rodado.

### Pendências conhecidas da Fase 14
- **iOS: CallKit/VoIP push NÃO foi feito** (exige conta Apple Developer paga + certificado PushKit + pacote como `flutter_callkit_incoming`). No iOS a chamada com app fechado é só um alerta comum.
- **Sem foreground service** durante a chamada: o Android pode cortar mic/câmera com o app em 2º plano. Exigiria plugin/nativo (`flutter_foreground_task` ou serviço próprio com tipos `microphone|camera`).
- **Android 14+**: `USE_FULL_SCREEN_INTENT` pode precisar ser concedida em *Configurações → Apps → Acesso especial*; sem ela vira notificação comum (heads-up). Nada disso foi testado em aparelho.
- Atender pelo botão com o app morto depende de login/SSE subirem (espera até ~8 s). Se o servidor mandar o push com o app **aberto**, só a tela de chamada aparece (sem popup).
- Notificação de tela cheia não some sozinha quando o outro lado desiste antes dos 45 s com o app fechado (o push de "perdida" é normal); expira pelo `timeoutAfter`.
- Mensagem de chamada usa `media_mime` como estado (convenção, não coluna) — se o app antigo ler, mostra só o rótulo (`content`).
- Web: sem bloqueio de usuário/ocupado/som de desligar; histórico sem filtro (só perdidas).

## Fase 15 — o que foi feito (documentos + polimento final)
### Backend (`driqy4/`)
- **Documentos (`msg_type=file`)**: `models.Message.media_name` (VARCHAR 255, migração automática em `_ensure_schema_upgrades`) guarda o **nome original** (só para exibir/baixar;
  o arquivo no disco continua com nome aleatório). `api._clean_display_name` mantém acentos, tira pasta/caracteres de controle e `<>:"|?*`, limita a 120 chars preservando a extensão.
- **Assinatura conferida** (`api._file_mime_from_head`, lê 4 KB): pdf (`%PDF-`), docx/xlsx/pptx/zip/odt/ods/odp (`PK`), doc/xls/ppt (OLE `D0CF11E0…`), rtf (`{\rtf`), txt/csv/json (sem byte nulo),
  heic/heif (`ftyp` + marca heic/heix/hevc/mif1…). Arquivo cujo conteúdo não bate com a extensão → **400**. `config.CHAT_ALLOWED_FILE_EXT` ganhou `rtf, odt, ods, odp, json, heic, heif`
  (já tinha pdf, txt, zip, doc(x), xls(x), ppt(x), csv). Limite `CHAT_MAX_FILE_BYTES` = 25 MB. `media_mime` vem da tabela por extensão (não do cliente).
- **HEIC/HEIF** não vira imagem (navegador não mostra): chega como **documento** (`image/heic`), baixável. O `image_picker` do Flutter costuma converter para JPEG antes.
- **Download**: `GET /messages/media/<id>` com `msg_type=file` sai **sempre como `attachment`** (`Content-Disposition` com o nome original, UTF-8) + `nosniff`; `?download=1` força o mesmo para qualquer mídia.
  Mesma regra de acesso de antes (só remetente/destinatário; estranho → 404; Bearer **ou** sessão do site).
- `serialize_message` ganhou **`media_name`** (só em arquivo; `null` nos demais e em apagada). Apagar para todos zera `media_name` e remove o arquivo; **encaminhar copia** `media_name`.
  Citação (`reply_to.preview`), push (`chat_extras.push_body`) e prévia da caixa de entrada do site mostram `📎 nome.pdf` quando não há legenda. **Busca na conversa acha pelo nome do arquivo.**
- **Limpeza de mídia órfã**: `chat_cleanup.py` (`find_orphans`, `cleanup_orphan_chat_media`) + script **`python cleanup_chat_media.py`** (só lista) / **`--apply`** (apaga). Órfão = arquivo em
  `instance/uploads/chat/**` que nenhuma `Message.media_path` referencia (miniatura `.thumb` vale pelo vídeo dono), **mais velho que `CHAT_ORPHAN_MIN_AGE_SECONDS` (6 h)**; só mexe em `chat/`;
  remove pastas vazias. Job diário opcional no `scheduler.py` **desligado por padrão** (`CHAT_ORPHAN_CLEANUP_ENABLED=1` liga). **Rode primeiro sem `--apply` e confira a lista.**
- **Removidas** as rotas antigas do site `POST /mensagens/<user>/enviar` e `GET /mensagens/api/<user>/novas` (sem uso desde a Fase 4).
- **Usernames reservados** (`auth.RESERVED_USERNAMES` = `privacy, stream, chamadas, api`): `USERNAME_RE` virou um wrapper que recusa esses nomes (cadastro web/API, trocar nome, login Google gera outro).
  Contas que já tinham esses nomes continuam funcionando.
- `tests/test_chat_phase15.py` (**19 testes**). `sw.js` → cache **`v22`** (testes das fases 10/11/13/14 atualizados). **Total: 374 passam, 3 skipped.**
### Web — desktop e celular (`chat-thread.js`, `messages_thread.html`, `style.css`)
- O **clipe** agora anexa **foto, GIF, vídeo ou documento** (`accept` ampliado; arrastar-e-soltar e colar PDF também). Documento abre o modal com **cartão do arquivo** (ícone por tipo, nome, tamanho) + legenda.
  Limite 25 MB com aviso; tipo não suportado → aviso.
- **Bolha de arquivo** (`fileBlock`): ícone colorido (PDF/DOC/XLS/PPT/ZIP/IMG), nome, tamanho · EXT, botão ⬇; clicar baixa (`<a download>`). Enquanto envia mostra "…" e não é clicável. Reenvio por clique, como as outras mídias.
- **Acessibilidade**: rótulos em português nos botões novos (`Anexar foto, vídeo ou arquivo`, cartão `Baixar arquivo <nome>, <tamanho>`), `:focus-visible` com contorno âmbar nos botões/lista do chat, `prefers-reduced-motion`
  desliga animações/transições do chat e da tela de chamada. (`role="log"`/`aria-live` da lista já existiam.)
### Flutter (`flutter_app/`) — **não compilado**
- **Dependências novas (rodar `flutter pub get`)**: `file_picker: ^8.1.2` (escolher), `path_provider: ^2.1.4` (pasta temporária), `open_filex: ^4.5.0` (abrir no app do sistema).
  Se alguma resolver outra major e quebrar, os ajustes ficam em `message_thread_screen.dart` (`_pickFile`/`_openFile`) e `message_service.dart` (`downloadFile`).
- `DriqyMessage.mediaName` + `DriqyMessage.localFile(...)`; `previewText` mostra `📎 nome` (caixa de entrada, citação, encaminhar). `ApiClient.postFile(filename:)` e extensões de documento em `_knownExts`.
  `MessageService.sendFile` e `downloadFile` (baixa com Bearer para `<temp>/driqy_files/<id>/<nome original>`).
- `widgets/chat/file_message.dart` (novo): `FileMessage` (cartão com ícone/nome/tamanho/progresso, `Semantics`), `fileExt`, `fileSizeLabel`, `fileIconFor`. `message_bubble.dart`: ramo de arquivo (`onOpenFile`, `fileBusy`).
- `message_thread_screen.dart`: item **"Documento"** no clipe 📎 → `FilePicker` (extensões da lista, 25 MB) → diálogo com legenda → envio otimista com reenvio (`_deliver` ganhou o ramo de arquivo);
  tocar no documento baixa e abre (`OpenFilex`), com avisos se não houver app ou se falhar. **Gravação de voz temporária é apagada do disco depois de enviada** (pendência da Fase 5).
- Testes Dart novos (`phase15Tests`: JSON, prévia, `localFile`, extensão/tamanho/ícone) — não rodados.

### Pendências conhecidas da Fase 15
- **Flutter nunca compilado** (nem as Fases 2–14): rodar `flutter pub get` + `flutter analyze` + `flutter test` e corrigir o que aparecer antes de publicar. `file_picker`/`open_filex` mexem em Android/iOS nativo;
  no iOS pode precisar de `pod install`; no Android, abrir arquivo depende de haver app compatível (a mensagem avisa).
- **Documento é baixado inteiro** antes de abrir (sem pré-visualização de PDF dentro do app/site). Sem barra de progresso de upload/download (só spinner). Um arquivo por vez.
- Assinatura só confere o **tipo**, não varre vírus/macros. `.docx`/`.zip` com macro ou conteúdo malicioso passam se forem ZIP válido — o download sempre é `attachment`, mas **não abra arquivos de desconhecidos**. Considerar antivírus (ClamAV) em produção.
- Os arquivos baixados ficam na pasta temporária do app (o sistema limpa); não há "salvar em Downloads" explícito no Flutter.
- Limpeza de órfãos: não olha mensagens "escondidas pelos dois" (o servidor já apaga a mídia nessa hora) nem faz backup; o job diário está **desligado** por padrão.
- Web: HEIC/HEIF vira documento (não dá para ver no navegador exceto Safari). Sem seleção múltipla de arquivos/fotos, sem busca de GIFs/figurinhas.
- Nomes reservados só bloqueiam **novos** cadastros/trocas de nome.
- Continuam abertas (herdadas, fora do escopo das 15 fases): aviso de câmera desligada (DataChannel), upgrade voz→vídeo (renegociação), foreground service no Android, **CallKit/iOS**, Redis para vários workers,
  bloqueio de usuário, E2E (não existe — não prometer na UI), `since_id` para não rebuscar a conversa inteira a cada evento.

## O que testar primeiro (checklist final, nada disto foi visto em aparelho/navegador)
1. `cd driqy4 && python -m pytest tests -q` → **374 passam, 3 skipped**.
2. Site (HTTPS ou `localhost`): enviar texto, foto, GIF, vídeo, áudio, PDF/DOCX/ZIP, responder, editar, encaminhar, buscar; abrir em duas contas/abas e conferir tempo real, "digitando…", ✓✓.
3. Chamada de voz e vídeo **web ↔ web** primeiro, depois app ↔ web, depois app ↔ app; rede 4G exige TURN (`COTURN.md`).
4. Flutter: `flutter pub get && flutter analyze && flutter test`, depois rodar num Android real (anexos, gravação, chamada, tela cheia).
5. `python cleanup_chat_media.py` (simulação) antes de qualquer `--apply`.

## Instruções para quem continuar (as 15 fases acabaram)
0. Regras do topo deste arquivo continuam valendo (4 alvos, zips completos [nome atual: ver item 3], edições cirúrgicas, riscos antes de implementar).
1. Não há "Fase 16" definida. Se o usuário pedir mais, escolha entre as pendências herdadas acima e registre uma tabela de fases nova neste arquivo.
2. Qualquer mudança em `static/` deve subir o cache do `sw.js` (valor atual: ver `static/sw.js`; em 10/11/2026 é `driqy-shell-v63`) e ajustar os testes que o fixam (`tests/test_chat_phase10/11/13/14/15.py`).
3. Entregue sempre os DOIS zips completos. **Nome atual (substitui o padrão `X7`/`faseN` antigo):** `driqy-flutter_v_0_0_N.zip` e `driqy4-web-v_0_0_N.zip` (N sobe a cada entrega).

## Correção pós-fase 16 — aviso duplicado de mensagem
- Causa: `onUnreadCounts` (topbar) desenhava um aviso local genérico "Você recebeu uma nova mensagem"
  ao ver o contador subir, além do push FCM com nome + texto.
- Agora o aviso local é só *fallback*: só com o app na frente, espera 7 s, e é descartado se um push FCM
  chegou, se a mensagem já foi lida (contador voltou) ou se o app foi pro segundo plano (ao voltar, os
  contadores são rebaseados). Arquivo: `lib/services/push_notification_service.dart`.

## Correção pós-fase 16 — selo de verificado no cabeçalho da conversa (site)
- Causa: `.cw-partner-text` é coluna flex e o selo era item próprio (ficava abaixo do nome). Agora nome +
  selo ficam numa linha (`.cw-partner-name`) em `templates/messages_thread.html` + `static/css/style.css`.
- `static/sw.js`: `CACHE_NAME` v22 → v23 (força o CSS novo no PWA).
- Servidor manda um único push por mensagem (`chat_extras.push_chat_message`); o duplicado era só do app.

## Notícias no site sem bordas (igual ao app)
- `.news-grid` com `gap: 0` em todas as larguras; `.news-tile` sem raio, sem sombra e sem "levantar" no hover.
- `static/sw.js`: `CACHE_NAME` v24.

## Notícias no site: título menor (só web)
- `.news-tile-overlay` mais baixo e gradiente mais leve; título 0.98rem em 2 linhas; categoria e meta menores; resumo escondido. `sw.js` v25.

## Notícias: previsão do tempo de cidade + mais fontes
- Novo `news_weather.py`: notícia de previsão do tempo de UMA cidade (detectada só pelo título) some do feed
  (site e app, mesma função `recommended_articles`) para quem não mora lá; compara com `User.location`
  ("Curitiba, PR" → "curitiba", "pr"). Clima geral (Brasil, regiões, estados, frente fria, El Niño...) segue
  aparecendo. São Paulo e Rio de Janeiro contam como cidade. Anônimo/sem cidade no perfil = não vê previsão de cidade.
- Sem coluna nova: o filtro roda por usuário depois do pool cacheado em `news_recommender.py`.
- `config.NEWS_DEFAULT_SOURCES`: +28 fontes (O Globo, Estadão, Jovem Pan, R7, Veja, CartaCapital, Gazeta do Povo,
  Brasil de Fato, Intercept, Agência Câmara/Senado, Valor, Money Times, Seu Dinheiro, Brazil Journal, Trivela,
  Placar, Adrenaline, Showmetech, Meio Bit, Jovem Nerd, Rolling Stone, Papelpop, Veja Saúde, Jornal da USP,
  Ciência Hoje, Space Today, France 24, RFI, ONU News). `seed_default_sources` cria só as que faltam no boot.
  URLs NÃO testadas pela IA (sem acesso de rede): feed que não responde só indexa 0 matérias; conferir em /admin.
- Teste novo `tests/test_news_weather.py`; `test_chat_phase10` agora aceita qualquer versão do cache do SW.
