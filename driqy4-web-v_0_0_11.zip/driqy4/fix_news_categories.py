"""
Script de correção: reclassifica as notícias JÁ SALVAS no banco com o
classificador v2 (news_classifier.classify_article: texto + seção da URL +
prior da fonte). Depois recria as fichas do banco temporário de notícias.

Sem esse script, o fix em news_indexer.py só vale para notícias novas —
as que já foram indexadas antes continuam com a categoria antiga (errada).

Como rodar (na raiz do projeto, com o venv ativado):
    python fix_news_categories.py
"""
from app import create_app
from extensions import db
from models import NewsArticle, NewsSource
from news_classifier import classify_article
from news_indexer import _upgrade_image_url, _strip_html, _trust_prior


def main():
    app = create_app()
    with app.app_context():
        keywords_by_category = app.config["NEWS_CATEGORY_KEYWORDS"]
        mixed_sources = app.config.get("NEWS_MIXED_SOURCE_CATEGORIES", {})
        changed = 0
        images_upgraded = 0
        checked = 0
        entities_fixed = 0

        for source in NewsSource.query.all():
            extras = mixed_sources.get(source.name)
            for article in NewsArticle.query.filter_by(source_id=source.id).all():
                checked += 1
                clean_title = _strip_html(article.title)[:300]
                clean_summary = _strip_html(article.summary or "")[:500]
                if clean_title != article.title or clean_summary != (article.summary or ""):
                    article.title, article.summary = clean_title, clean_summary
                    entities_fixed += 1
                info = classify_article(
                    article.title, article.summary or "", keywords_by_category,
                    url=article.url or "", prior=source.default_category,
                    allowed=set(extras) if extras else None,
                    default_category=source.default_category or "geral",
                    trust_prior=_trust_prior(source.name, app.config),
                )
                if info.category != article.category:
                    article.category = info.category
                    changed += 1
                if article.image_url:
                    better = _upgrade_image_url(article.image_url)
                    if better != article.image_url:
                        article.image_url = better[:700]
                        article.image_fetch_attempts = 0
                        images_upgraded += 1
        db.session.commit()

        # as fichas do banco temporário guardam categoria/secundárias: refaz
        import news_bank
        from models import NewsBankItem
        NewsBankItem.query.delete()
        db.session.commit()
        created = news_bank.backfill(app, limit=100000)
        print(f"{checked} notícia(s) verificada(s); {changed} mudaram de categoria; "
              f"{images_upgraded} imagem(ns) melhorada(s); {entities_fixed} texto(s) com entidade HTML corrigido(s); {created} ficha(s) no banco temporário.")


if __name__ == "__main__":
    main()
