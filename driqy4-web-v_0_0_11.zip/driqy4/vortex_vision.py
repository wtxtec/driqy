"""
Análise visual dos itens do Vortex: sugestões pelo CONTEÚDO da imagem, não
só pelo texto que a fonte escreveu (título/tags/categoria).

Dois níveis, que se somam:

1) Assinatura de aparência (só Pillow, sempre ligada)
   Vetor de 69 números (0-255) tirado dos pixels de uma miniatura 64x64:
     - grade 4x4 com a cor média de cada célula  -> layout da cena
       (céu em cima, chão embaixo, fundo escuro com foco claro...)
     - histograma de matiz (12 faixas, ponderado por saturação*brilho)
     - fração sem cor, saturação média, brilho médio, contraste
     - densidade de bordas (total e por quadrante) -> detalhe/textura
   Serve pra achar imagens PARECIDAS (cores, luz, composição) e gera
   `visual_tags` de aparência ("azul", "escuro", "tons frios", "minimalista").
   Honestidade: isso descreve COMO a imagem parece, não O QUE ela é. Uma
   parede azul e um céu azul ficam parecidos.

2) CLIP (opcional, VORTEX_CLIP_MODEL)
   Embedding semântico + conceitos reconhecidos num vocabulário fechado
   (Config.VORTEX_VISUAL_CONCEPTS): "cachoeira", "cachorro", "pizza"...
   Aí sim a sugestão vem do que a imagem representa. Fora do vocabulário o
   CLIP escolhe o conceito "menos errado", por isso há limiares de confiança.

Nada aqui acessa o banco; vortex_crawler.py (preenchimento) e
vortex_search.py (ranking) usam estas funções.
"""
import base64
import logging
import math
from io import BytesIO

try:  # Pillow é opcional no projeto; sem ele a análise visual fica desligada
    from PIL import Image, ImageFilter
except Exception:  # pragma: no cover
    Image = ImageFilter = None

try:  # numpy: índice em memória e CLIP; sem ele só as tags de aparência funcionam
    import numpy as np
except Exception:  # pragma: no cover
    np = None

log = logging.getLogger("vortex_vision")

VISION_VERSION = 1

GRID = 4
HUE_BINS = 12
_N_GRID = GRID * GRID * 3
_N_STAT = 4          # fração sem cor, saturação média, brilho médio, contraste
_N_EDGE = 5          # total + 4 quadrantes
FEAT_DIM = _N_GRID + HUE_BINS + _N_STAT + _N_EDGE        # 69
# peso de cada bloco na distância (matiz/estatísticas/bordas são poucas
# dimensões e dizem muito; a grade tem muitas e diz menos por dimensão)
WEIGHTS = [1.0] * _N_GRID + [2.5] * HUE_BINS + [2.0] * _N_STAT + [2.0] * _N_EDGE
_W_SUM = sum(WEIGHTS)
# distância normalizada (0-1) a partir da qual a similaridade vira 0
DIST_SCALE = 0.30

# matiz (faixas de 30°) -> nome da cor; faixas vizinhas do mesmo nome somam
_HUE_NAMES = ["vermelho", "laranja", "amarelo", "verde", "verde", "turquesa",
              "ciano", "azul", "azul", "roxo", "rosa", "vermelho"]


# ---------------------------------------------------------------------------
# assinatura de aparência
# ---------------------------------------------------------------------------

def _open_small(data):
    img = Image.open(BytesIO(data))
    try:
        img.draft("RGB", (160, 160))   # JPEG: decodifica já reduzido (bem mais rápido)
    except Exception:
        pass
    try:
        img.seek(0)                    # GIF: primeiro quadro
    except Exception:
        pass
    return img.convert("RGB").resize((64, 64), Image.Resampling.BOX)


def describe_image(data):
    """Devolve {'vec': bytes(69), 'hex': str, 'tags': [str]} ou None se não
    der pra ler a imagem."""
    if Image is None or not data:
        return None
    try:
        img = _open_small(data)
        px = img.tobytes()
        hsv = img.convert("HSV").tobytes()
        edges = img.convert("L").filter(ImageFilter.FIND_EDGES).tobytes()
    except Exception:
        return None

    n, cell = 64 * 64, 16
    sums = [0] * _N_GRID
    for y in range(64):
        row, base = (y // cell) * GRID, y * 64 * 3
        for x in range(64):
            idx, o = (row + x // cell) * 3, base + x * 3
            sums[idx] += px[o]
            sums[idx + 1] += px[o + 1]
            sums[idx + 2] += px[o + 2]
    grid = [s / (cell * cell * 255.0) for s in sums]

    hue = [0.0] * HUE_BINS
    low = s_sum = v_sum = v_sq = 0
    for i in range(0, len(hsv), 3):
        h, s, v = hsv[i], hsv[i + 1], hsv[i + 2]
        s_sum += s
        v_sum += v
        v_sq += v * v
        if s < 40 or v < 40:
            low += 1
        else:
            hue[h * HUE_BINS // 256] += (s * v) / 65025.0
    mean_v = v_sum / n
    contrast = math.sqrt(max(0.0, v_sq / n - mean_v * mean_v)) / 255.0 * 2.0
    stats = [low / n, s_sum / (n * 255.0), mean_v / 255.0, contrast]

    quad, total = [0, 0, 0, 0], 0
    for y in range(64):
        for x in range(64):
            if edges[y * 64 + x] > 24:
                total += 1
                quad[(y // 32) * 2 + x // 32] += 1
    edge_feats = [total / n] + [q / 1024.0 for q in quad]

    floats = grid + [h / n for h in hue] + stats + edge_feats
    vec = bytes(int(round(min(1.0, max(0.0, f)) * 255)) for f in floats)
    return {"vec": vec, "hex": vec.hex(), "tags": tags_from_vec(vec)}


def vec_from_hex(value):
    """bytes(69) a partir do hex salvo, ou None se vazio/inválido."""
    if not value or len(value) != FEAT_DIM * 2:
        return None
    try:
        return bytes.fromhex(value)
    except ValueError:
        return None


def tags_from_vec(vec, limit=6):
    """Tags de APARÊNCIA (pt) derivadas do vetor: cores, luz, contraste,
    detalhe. Não afirmam o que a imagem é."""
    f = [b / 255.0 for b in vec]
    hue = f[_N_GRID:_N_GRID + HUE_BINS]
    lowfrac, mean_s, mean_v, contrast = f[_N_GRID + HUE_BINS:_N_GRID + HUE_BINS + _N_STAT]
    edge = f[-_N_EDGE]
    tags = []
    if mean_s < 0.06 and 0.1 < mean_v < 0.9:
        tags.append("preto e branco")
    elif lowfrac > 0.8:
        tags.append("tons neutros")
    elif mean_s > 0.5 and lowfrac < 0.3:
        tags.append("colorido")
    if mean_v < 0.25:
        tags.append("escuro")
    elif mean_v > 0.78:
        tags.append("claro")
    if lowfrac <= 0.8 and mean_s >= 0.06:
        shares = {}
        for i, share in enumerate(hue):
            shares[_HUE_NAMES[i]] = shares.get(_HUE_NAMES[i], 0.0) + share
        for name, share in sorted(shares.items(), key=lambda kv: -kv[1])[:2]:
            if share >= 0.15:
                tags.append(name)
        warm = hue[11] + hue[0] + hue[1] + hue[2]
        cool = sum(hue[5:9])
        total = sum(hue) or 1.0
        if warm / total > 0.6:
            tags.append("tons quentes")
        elif cool / total > 0.6:
            tags.append("tons frios")
    if edge < 0.04:
        tags.append("minimalista")
    elif edge > 0.28:
        tags.append("detalhado")
    if contrast > 0.6:
        tags.append("alto contraste")
    return tags[:limit]


def distance(a, b):
    """Distância normalizada (0 = idêntica) entre duas assinaturas."""
    total = 0.0
    for w, x, y in zip(WEIGHTS, a, b):
        total += w * abs(x - y)
    return total / (255.0 * _W_SUM)


def similarity(a, b):
    """0..1 (1 = mesma aparência)."""
    return max(0.0, 1.0 - distance(a, b) / DIST_SCALE)


def weights_array():
    return np.asarray(WEIGHTS, dtype=np.float32) if np is not None else None


# ---------------------------------------------------------------------------
# CLIP (opcional)
# ---------------------------------------------------------------------------

def clip_pack(vec):
    """Embedding (numpy) -> texto base64 (float16) pra guardar no banco."""
    return base64.b64encode(np.asarray(vec, dtype=np.float16).tobytes()).decode("ascii")


def clip_unpack(text):
    """Texto base64 -> embedding float32 (ou None se vazio/sem numpy)."""
    if not text or np is None:
        return None
    try:
        return np.frombuffer(base64.b64decode(text), dtype=np.float16).astype(np.float32)
    except Exception:
        return None


class SentenceTransformerEncoder:
    """Encoder CLIP via sentence-transformers (ex.: 'clip-ViT-B-32')."""

    def __init__(self, model_name):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def encode_images(self, images):
        return self.model.encode(list(images), batch_size=16, convert_to_numpy=True,
                                 normalize_embeddings=True, show_progress_bar=False)

    def encode_texts(self, texts):
        return self.model.encode(list(texts), batch_size=64, convert_to_numpy=True,
                                 normalize_embeddings=True, show_progress_bar=False)


class ClipVision:
    """Embedding + conceitos (zero-shot) sobre um vocabulário fechado.
    O `encoder` precisa de encode_images(imagens) e encode_texts(textos),
    ambos devolvendo matriz numpy normalizada (L2)."""

    def __init__(self, encoder, concepts):
        self.encoder = encoder
        self.concepts = list(concepts)
        prompts = [f"a photo of {en}" for en, _pt, _cat in self.concepts]
        self._text = np.asarray(encoder.encode_texts(prompts), dtype=np.float32)

    def encode_images(self, images):
        return np.asarray(self.encoder.encode_images(images), dtype=np.float32)

    def concepts_for(self, vec, top=3):
        """[(rótulo_pt, categoria, probabilidade)] dos conceitos que mais
        combinam com a imagem (softmax sobre o vocabulário todo)."""
        logits = 100.0 * (self._text @ np.asarray(vec, dtype=np.float32))
        logits -= logits.max()
        probs = np.exp(logits)
        probs /= probs.sum()
        order = np.argsort(-probs)[:top]
        return [(self.concepts[i][1], self.concepts[i][2], float(probs[i])) for i in order]


def build_clip(cfg):
    """ClipVision pronto, ou None (desligado ou dependências ausentes)."""
    model = (cfg.get("VORTEX_CLIP_MODEL") or "").strip()
    if not model:
        return None
    if np is None or Image is None:
        log.warning("[vortex] CLIP pedido (%s), mas numpy/Pillow não estão instalados.", model)
        return None
    try:
        return ClipVision(SentenceTransformerEncoder(model), cfg["VORTEX_VISUAL_CONCEPTS"])
    except Exception as exc:
        log.warning("[vortex] CLIP '%s' indisponível (%s); seguindo só com a assinatura de aparência.",
                    model, exc)
        return None
