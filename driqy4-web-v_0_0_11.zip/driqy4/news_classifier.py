"""
Classificador de categoria das notícias (100% local, sem API de IA nem ML).

v2 — o que mudou e por quê (notícias caíam em categorias erradas):

1. EVIDÊNCIAS EM VEZ DE UMA ÚNICA PISTA. A categoria sai da soma de várias
   pistas, cada uma com um peso:
     - palavras-chave no título/resumo (título pesa 1,5x);
     - SEÇÃO DA URL (g1.globo.com/economia/..., /esportes/..., ge.globo.com):
       é a pista mais confiável que existe, e antes era ignorada;
     - TAGS/categorias que o próprio feed RSS informa (entry.tags);
     - o "palpite" da fonte (NewsSource.default_category), que agora é só
       um PRIOR (peso 2): antes valia 100% — um feed "Poder360 = política"
       com matéria de mercado, ou "ESPN Geral" com matéria de F1/NBA/política,
       ficava na categoria da fonte mesmo com evidência clara em contrário;
       e feeds marcados "geral" (G1 - Brasil, Folha - Cotidiano) nunca eram
       classificados e viravam um balaio.
2. TEXTO NORMALIZADO: sem acento ("politica" = "política"), plural/singular
   ("pesquisadores"/"pesquisador", "gols"/"gol") e frases por palavra inteira
   (antes "lua" casava dentro de "evolua" só em frases; agora tudo é por token).
3. CONFIANÇA e categorias SECUNDÁRIAS (classify_article devolve ambas): o
   banco de notícias e o recomendador usam isso — uma matéria de "reforma
   tributária" é economia E política, e conta um pouco para quem gosta de
   política.

`classify()` continua existindo com a mesma assinatura/semântica (o crawler
do Vortex e os testes antigos usam), agora com o texto normalizado.

Entradas de NEWS_CATEGORY_KEYWORDS: "palavra" (frase com espaço = peso 2,
palavra solta = 1) ou ("palavra", peso) para ambíguas (ex.: ("santos", 0.5)).
Uma categoria só entra na disputa com pontuação >= 1.
"""
import re
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from urllib.parse import urlparse

_WORD_RE = re.compile(r"[a-z0-9]+")

# pontuação mínima pra uma categoria entrar na disputa
_MIN_SCORE = 1
# o título resume a matéria: palavra-chave nele vale mais que no resumo
_TITLE_BONUS = 1.5

# pesos das evidências (ver docstring)
URL_WEIGHT = 4.0
TAG_WEIGHT = 3.0
PRIOR_WEIGHT = 2.0
# quanto uma categoria diferente do prior precisa superá-lo pra tomar o lugar
OVERRIDE_MARGIN = 0.5

# seção da URL -> categoria (só os 2 primeiros segmentos do caminho contam)
URL_SECTION_HINTS = {
    "politica": "politica", "poder": "politica", "eleicoes": "politica", "congresso": "politica",
    "economia": "economia", "mercado": "economia", "mercados": "economia", "negocios": "economia",
    "financas": "economia", "dinheiro": "economia", "investimentos": "economia",
    "esporte": "esportes", "esportes": "esportes", "futebol": "esportes", "basquete": "esportes",
    "volei": "esportes", "formula-1": "esportes", "olimpiadas": "esportes", "ufc": "esportes",
    "tecnologia": "tecnologia", "tec": "tecnologia", "games": "tecnologia", "gadgets": "tecnologia",
    "celulares": "tecnologia",
    "entretenimento": "entretenimento", "pop-arte": "entretenimento", "ilustrada": "entretenimento",
    "cultura": "entretenimento", "celebridades": "entretenimento", "musica": "entretenimento",
    "cinema": "entretenimento", "televisao": "entretenimento", "famosos": "entretenimento",
    "series": "entretenimento", "gente": "entretenimento",
    "saude": "saude", "bem-estar": "saude", "bemestar": "saude",
    "ciencia": "ciencia", "natureza": "ciencia", "espaco": "ciencia", "meio-ambiente": "ciencia",
    "ambiente": "ciencia", "astronomia": "ciencia",
    "mundo": "mundo", "internacional": "mundo", "exterior": "mundo", "america-latina": "mundo",
    "europa": "mundo", "oriente-medio": "mundo",
}
# hosts que já dizem o assunto
URL_HOST_HINTS = {
    "ge.globo.com": "esportes", "gshow.globo.com": "entretenimento",
    "valor.globo.com": "economia", "cbn.globo.com": None,
}


def _norm(text):
    """minúsculas, sem acento."""
    text = unicodedata.normalize("NFKD", (text or "").lower())
    return "".join(c for c in text if not unicodedata.combining(c))


def _stem(t):
    """singular grosseiro: 'gols'->'gol', 'pesquisadores'->'pesquisador', 'eleições'->'eleicao'."""
    if len(t) > 4:
        if t.endswith("oes") or t.endswith("aes"):
            return t[:-3] + "ao"
        if t.endswith("ais"):
            return t[:-3] + "al"
        if t.endswith("s") and not t.endswith("ss"):
            return t[:-1]
    return t


def tokens_of(text):
    """tokens normalizados e em forma singular."""
    return [_stem(t) for t in _WORD_RE.findall(_norm(text))]


def _keyword_and_weight(entry):
    if isinstance(entry, tuple):
        kw, weight = entry
        return kw, weight
    return entry, (2 if " " in entry else 1)


_COMPILED = {}


def _compile(keywords_by_category):
    """(token_kws, phrase_kws) por categoria, já normalizados. Cacheado."""
    hit = _COMPILED.get(id(keywords_by_category))
    if hit is not None and hit[0] is keywords_by_category:
        return hit[1]
    compiled = {}
    for category, entries in keywords_by_category.items():
        singles, phrases = {}, {}
        for entry in entries:
            kw, weight = _keyword_and_weight(entry)
            toks = tokens_of(kw)
            if not toks:
                continue
            if len(toks) == 1:
                singles[toks[0]] = max(weight, singles.get(toks[0], 0))
            else:
                phrase = " ".join(toks)
                phrases[phrase] = max(weight, phrases.get(phrase, 0))
        compiled[category] = (singles, phrases)
    _COMPILED[id(keywords_by_category)] = (keywords_by_category, compiled)
    return compiled


def _score_tokens(tokens, singles, phrases):
    if not tokens:
        return 0.0
    counts = Counter(tokens)
    score = 0.0
    for kw, weight in singles.items():
        c = counts.get(kw)
        if c:
            score += c * weight
    if phrases:
        padded = " " + " ".join(tokens) + " "
        for phrase, weight in phrases.items():
            c = padded.count(" " + phrase + " ")
            if c:
                score += c * weight
    return score


def _text_scores(title, summary, keywords_by_category, allowed=None):
    """({cat: pontuação ponderada}, {cat: pontos só do título}) — só categorias >= _MIN_SCORE."""
    t_tokens, s_tokens = tokens_of(title), tokens_of(summary)
    scores, title_scores = {}, {}
    for category, (singles, phrases) in _compile(keywords_by_category).items():
        if allowed is not None and category not in allowed:
            continue
        t = _score_tokens(t_tokens, singles, phrases)
        s = _score_tokens(s_tokens, singles, phrases)
        score = t * _TITLE_BONUS + s
        if score >= _MIN_SCORE:
            scores[category] = score
            title_scores[category] = t
    return scores, title_scores


def classify(title, summary, keywords_by_category, default_category="geral", allowed=None):
    """Compatível com a v1: (categoria, pontuações) só pelo texto. `allowed`
    restringe a disputa (fontes mistas). Empate no topo -> desempata pelo
    título; ainda empatado -> `default_category`."""
    scores, title_scores = _text_scores(title, summary, keywords_by_category, allowed)
    if not scores:
        return default_category, scores
    best = max(scores.values())
    top = [c for c, s in scores.items() if s == best]
    if len(top) > 1:
        best_title = max(title_scores[c] for c in top)
        top = [c for c in top if title_scores[c] == best_title]
        if len(top) > 1:
            return default_category, scores
    return top[0], scores


# ---------------------------------------------------------------------------
# v2: várias evidências
# ---------------------------------------------------------------------------

@dataclass
class Classification:
    category: str
    confidence: float                      # 0..1 (margem sobre a 2ª e força da evidência)
    scores: dict = field(default_factory=dict)
    secondary: list = field(default_factory=list)   # até 2 categorias também relevantes
    reasons: list = field(default_factory=list)     # p/ depuração: ["url:economia", "tag:...", ...]


def category_from_url(url):
    """Categoria sugerida pela URL (seção do caminho ou host), ou None."""
    if not url:
        return None
    try:
        p = urlparse(url)
    except ValueError:
        return None
    host = (p.hostname or "").lower()
    if host in URL_HOST_HINTS and URL_HOST_HINTS[host]:
        return URL_HOST_HINTS[host]
    segs = [s for s in _norm(p.path).split("/") if s][:2]
    for seg in segs:
        seg = seg.strip()
        if seg in URL_SECTION_HINTS:
            return URL_SECTION_HINTS[seg]
    return None


def _category_from_tag(tag, keywords_by_category):
    t = _norm(tag).strip().replace(" ", "-")
    if t in URL_SECTION_HINTS:
        return URL_SECTION_HINTS[t]
    scores, _ = _text_scores(tag, "", keywords_by_category)
    if scores:
        best = max(scores.values())
        top = [c for c, s in scores.items() if s == best]
        if len(top) == 1:
            return top[0]
    return None


def classify_article(title, summary, keywords_by_category, *, url="", tags=(), prior=None,
                     allowed=None, default_category="geral", trust_prior=True):
    """Classifica combinando texto + seção da URL + tags do feed + prior da fonte.

    prior: categoria "palpite" da fonte (NewsSource.default_category). "geral"
    (ou None) não carrega informação nenhuma. `allowed` (fontes mistas)
    restringe só a evidência de TEXTO; URL e tags valem para qualquer categoria.

    trust_prior=False (portais generalistas: G1/UOL/Folha/CNN com feed "de tecnologia"
    que na prática traz crime, política, cotidiano...): o prior NÃO soma pontos nem
    serve de fallback. A matéria só entra na categoria se o TEXTO, a URL ou as tags
    comprovarem; sem nenhuma evidência vira "geral" em vez de herdar a categoria do feed.
    """
    text_scores, title_scores = _text_scores(title, summary, keywords_by_category,
                                             None if allowed is None else set(allowed) | ({prior} if prior else set()))
    evidence = defaultdict(float)
    reasons = []
    for c, s in text_scores.items():
        evidence[c] += s
    u = category_from_url(url)
    if u:
        evidence[u] += URL_WEIGHT
        reasons.append(f"url:{u}")
    seen_tag_cats = set()
    for tag in tags or ():
        c = _category_from_tag(tag, keywords_by_category)
        if c and c not in seen_tag_cats:
            seen_tag_cats.add(c)
            evidence[c] += TAG_WEIGHT
            reasons.append(f"tag:{c}")
    has_prior = bool(prior) and prior != default_category and prior != "geral"
    if not trust_prior:
        has_prior = False
        default_category = "geral"
    if has_prior:
        evidence[prior] += PRIOR_WEIGHT
        reasons.append(f"prior:{prior}")

    ev = {c: v for c, v in evidence.items() if v >= _MIN_SCORE}
    if not ev:
        return Classification(prior if has_prior else default_category, 0.0, {}, [], reasons)

    ranked = sorted(ev.items(), key=lambda kv: (kv[1], title_scores.get(kv[0], 0)), reverse=True)
    best_cat, best_val = ranked[0]
    if len(ranked) > 1 and ranked[1][1] == best_val:
        tied = [c for c, v in ranked if v == best_val]
        if has_prior and prior in tied:
            best_cat = prior
        else:
            tt = max(title_scores.get(c, 0) for c in tied)
            top = [c for c in tied if title_scores.get(c, 0) == tt]
            best_cat = top[0] if len(top) == 1 else (prior if has_prior else default_category)
    if has_prior and best_cat != prior and prior in ev and ev[best_cat] - ev[prior] < OVERRIDE_MARGIN:
        best_cat = prior  # não derruba o prior por diferença mínima

    best_val = ev.get(best_cat, 0.0)
    others = sorted((v for c, v in ev.items() if c != best_cat), reverse=True)
    second = others[0] if others else 0.0
    margin = (best_val - second) / best_val if best_val else 0.0
    confidence = round(max(0.0, min(1.0, margin * min(1.0, best_val / 4.0))), 3)
    secondary = [c for c, v in sorted(ev.items(), key=lambda kv: kv[1], reverse=True)
                 if c != best_cat and v >= max(_MIN_SCORE, 0.5 * best_val)][:2]
    return Classification(best_cat, confidence, dict(ev), secondary, reasons)
