"""
Controle de qualidade do Vortex: tira QR codes, logos, banners, imagens
chapadas/em branco e repetidas ANTES de chegarem na grade.

Três camadas, da mais barata pra mais cara:

1) TEXTO (`check_text`) — URL, título, tags e página de origem. Pega o óbvio
   ("qr-code.png", "logo-empresa.jpg", "banner", "placeholder"...). Sem rede.
   Também roda na hora de montar a grade (peça antiga ainda não analisada).

2) PIXELS (`inspect_bytes`) — olha a miniatura (Pillow + numpy):
   - QR code: procura os 3 "olhos" (padrão 1:1:3:1:1) em linhas E colunas e
     confere se formam um L. Só isso já distingue QR de foto com folga.
   - logo / arte chapada: poucas cores, fundo uniforme, quase nenhum gradiente.
     Foto de verdade tem ruído e degradê; logo não.
   - transparência: PNG recortado (logo/figurinha) tem canal alfa.
   - em branco: uma cor só.
   Regra de ouro: na dúvida, DEIXA PASSAR. Cada regra é conservadora (vários
   sinais ao mesmo tempo) e o admin pode restaurar o que foi barrado por engano
   (`junk_reason = "manual_ok"` = o filtro nunca mais mexe).

3) REPETIDAS (`dedupe_existing`) — agrupa quase-duplicatas pelo dHash. Fica a
   melhor cópia (maior resolução) e as outras somem ("duplicate"). Se uma
   mesma imagem aparece N vezes (>= VORTEX_REPEAT_TEMPLATE_MIN) ela é banner/
   marca d'água de site, não conteúdo: some tudo ("repeated").

Item barrado fica com `is_active=False` + `junk_reason`, então busca,
similares, estatísticas e gosto o ignoram sem precisar saber disso.
"""
import logging
import re
from collections import defaultdict
from io import BytesIO

try:  # Pillow/numpy são opcionais: sem eles só a camada de texto funciona
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None
try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

log = logging.getLogger("vortex_quality")

# sobe quando as regras mudam: itens analisados com versão menor são revistos
QUALITY_VERSION = 1

REASONS = {
    "qrcode": "QR code",
    "logo": "Logo / arte chapada",
    "blank": "Imagem em branco / cor única",
    "transparent": "Recorte transparente (logo/figurinha)",
    "text": "Nome indica logo/banner/ícone",
    "duplicate": "Repetida",
    "repeated": "Aparece em excesso (banner/marca d'água)",
    "manual_ok": "Liberado por um admin",
}

# ---------------------------------------------------------------------------
# 1) texto
# ---------------------------------------------------------------------------
# palavras inteiras. FORTES valem em qualquer lugar (URL, título, tags): quase
# nunca descrevem uma foto de verdade. FRACAS só valem no caminho da URL, onde
# são nome de arquivo ("banner-home.jpg"); em título seriam falso positivo
# ("Bruce Banner", "belly button", "police badge").
_STRONG_WORDS = (
    r"qr", r"qrcode", r"qr[-_ ]?code", r"barcode", r"codigo[-_ ]de[-_ ]barras",
    r"logo", r"logos", r"logotipo", r"logotype", r"wordmark", r"favicon",
    r"sprite", r"placeholder", r"no[-_ ]?image", r"image[-_ ]?not[-_ ]?found", r"sem[-_ ]?foto",
    r"watermark",
)
_WEAK_WORDS = (
    r"brasao", r"marca[-_ ]?d.agua", r"banner", r"popup", r"badge", r"button", r"botao",
    r"app[-_ ]?store", r"google[-_ ]?play", r"download[-_ ]?app", r"newsletter",
    r"assine", r"subscribe", r"cookie", r"advert", r"publicidade", r"anuncio",
    r"default[-_ ]?(?:image|img|thumb|thumbnail|avatar|og|share)", r"og[-_ ]?default",
    r"social[-_ ]?share", r"share[-_ ]?image",
)
_B = r"(?<![a-z0-9])(?:%s)(?![a-z0-9])"
_STRONG_RE = re.compile(_B % "|".join(_STRONG_WORDS), re.IGNORECASE)
_WEAK_RE = re.compile(_B % "|".join(_STRONG_WORDS + _WEAK_WORDS), re.IGNORECASE)
# pedaços de caminho típicos de imagem de tema/modelo do site
_JUNK_PATH_RE = re.compile(
    r"/(?:themes?|templates?|skins?|assets/(?:img|images)/(?:ui|icons?|brand)|"
    r"wp-content/themes|static/(?:img|images)/(?:ui|brand|icons?))/", re.IGNORECASE)


def check_text(url="", title="", tags="", source_url=""):
    """Motivo (str) se só o TEXTO já mostra que é lixo; senão None."""
    try:
        path = re.sub(r"https?://[^/]+", "", (url or ""))  # o domínio não conta ("logo.com")
        path = path.split("?")[0]
        if _WEAK_RE.search(path.replace("/", " ")) or _JUNK_PATH_RE.search(path):
            return "text"
        if _STRONG_RE.search(" ".join((title or "", tags or ""))):
            return "text"
    except Exception:  # nunca derruba o motor
        return None
    return None


# ---------------------------------------------------------------------------
# 2) pixels
# ---------------------------------------------------------------------------
_ANALYSIS_SIDE = 256     # a análise roda numa miniatura de até 256 px
_QR_SIDE = 320           # o detector de QR usa uma versão de até 320 px


def _load(data, side):
    """(rgba_array uint8 HxWx4, tinha_alfa) numa miniatura; None se ilegível."""
    if Image is None or np is None or not data:
        return None
    try:
        img = Image.open(BytesIO(data))
        try:
            img.seek(0)  # GIF: primeiro quadro
        except Exception:
            pass
        has_alpha = img.mode in ("RGBA", "LA", "PA") or "transparency" in img.info
        img = img.convert("RGBA")
        img.thumbnail((side, side), Image.Resampling.BOX)
        return np.asarray(img, dtype=np.uint8), has_alpha
    except Exception:
        return None


def _otsu(gray):
    hist = np.bincount(gray.ravel(), minlength=256).astype(np.float64)
    total = hist.sum()
    if total <= 0:
        return 128
    sum_all = float(np.dot(np.arange(256), hist))
    w_b = sum_b = 0.0
    best, thr = -1.0, 128
    for t in range(256):
        w_b += hist[t]
        if w_b == 0:
            continue
        w_f = total - w_b
        if w_f == 0:
            break
        sum_b += t * hist[t]
        m_b, m_f = sum_b / w_b, (sum_all - sum_b) / w_f
        var = w_b * w_f * (m_b - m_f) ** 2
        if var > best:
            best, thr = var, t
    return thr


def _runs(line):
    """[(valor, inicio, tamanho)] das corridas de uma linha binária."""
    idx = np.flatnonzero(np.diff(line.astype(np.int8))) + 1
    starts = np.concatenate(([0], idx))
    ends = np.concatenate((idx, [len(line)]))
    return [(int(line[s]), int(s), int(e - s)) for s, e in zip(starts, ends)]


def _is_finder(runs5):
    """5 corridas escuro,claro,escuro(3x),claro,escuro na proporção 1:1:3:1:1."""
    total = sum(r[2] for r in runs5)
    if total < 7:
        return None
    unit = total / 7.0
    tol = unit * 0.55
    sizes = [r[2] for r in runs5]
    if (abs(sizes[0] - unit) <= tol and abs(sizes[1] - unit) <= tol
            and abs(sizes[2] - 3 * unit) <= 3 * tol and abs(sizes[3] - unit) <= tol
            and abs(sizes[4] - unit) <= tol):
        return unit
    return None


def _finder_candidates(binary):
    """Centros (x, y, módulo) de padrões 1:1:3:1:1 confirmados nas duas direções."""
    h, w = binary.shape
    found = []
    for y in range(h):
        runs = _runs(binary[y])
        for i in range(len(runs) - 4):
            if runs[i][0] != 0:   # 0 = escuro
                continue
            unit = _is_finder(runs[i:i + 5])
            if unit is None:
                continue
            start = runs[i][1]
            cx = start + sum(r[2] for r in runs[i:i + 5]) / 2.0
            col = binary[:, int(cx)]
            cruns = _runs(col)
            for j in range(len(cruns) - 4):
                if cruns[j][0] != 0:
                    continue
                cstart = cruns[j][1]
                cend = cstart + sum(r[2] for r in cruns[j:j + 5])
                if cstart <= y < cend and _is_finder(cruns[j:j + 5]) is not None:
                    cy = cstart + (cend - cstart) / 2.0
                    found.append((cx, cy, unit))
                    break
    return found


def _cluster(points, radius_factor=2.5):
    clusters = []
    for x, y, u in points:
        for c in clusters:
            if abs(c["x"] - x) <= c["u"] * radius_factor and abs(c["y"] - y) <= c["u"] * radius_factor:
                c["pts"].append((x, y, u))
                n = len(c["pts"])
                c["x"] = sum(p[0] for p in c["pts"]) / n
                c["y"] = sum(p[1] for p in c["pts"]) / n
                c["u"] = sum(p[2] for p in c["pts"]) / n
                break
        else:
            clusters.append({"x": x, "y": y, "u": u, "pts": [(x, y, u)]})
    return clusters


def detect_qr(rgba):
    """Dict {'found': bool, 'area': fração da imagem coberta pelos olhos}.

    QR tem 3 olhos (cantos sup. esq., sup. dir. e inf. esq.): três padrões
    1:1:3:1:1, do mesmo tamanho, num triângulo retângulo. Foto não faz isso."""
    h, w = rgba.shape[:2]
    gray = (0.299 * rgba[..., 0] + 0.587 * rgba[..., 1] + 0.114 * rgba[..., 2]).astype(np.uint8)
    # transparente conta como claro (fundo de QR em PNG)
    gray = np.where(rgba[..., 3] < 128, 255, gray).astype(np.uint8)
    binary = (gray > _otsu(gray)).astype(np.uint8)   # 1 = claro, 0 = escuro
    # vários módulos pequenos demais: sem resolução pra achar os olhos
    clusters = _cluster(_finder_candidates(binary))
    clusters = [c for c in clusters if len(c["pts"]) >= 2]   # confirma em >= 2 linhas
    if len(clusters) < 3:
        return {"found": False, "area": 0.0}
    for a in range(len(clusters)):
        for b in range(a + 1, len(clusters)):
            for c in range(b + 1, len(clusters)):
                trio = (clusters[a], clusters[b], clusters[c])
                units = [t["u"] for t in trio]
                if max(units) > 1.6 * min(units):
                    continue
                # o vértice do L é o que está a distâncias parecidas dos outros dois
                pts = [(t["x"], t["y"]) for t in trio]
                for k in range(3):
                    p, q, r = pts[k], pts[(k + 1) % 3], pts[(k + 2) % 3]
                    d1 = ((q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2) ** 0.5
                    d2 = ((r[0] - p[0]) ** 2 + (r[1] - p[1]) ** 2) ** 0.5
                    if d1 < 4 * min(units) or d2 < 4 * min(units):
                        continue
                    if max(d1, d2) > 1.35 * min(d1, d2):
                        continue
                    dot = (q[0] - p[0]) * (r[0] - p[0]) + (q[1] - p[1]) * (r[1] - p[1])
                    if abs(dot) / (d1 * d2) > 0.35:   # ~ ângulo reto (cos < 0,35)
                        continue
                    xs = [t["x"] for t in trio]
                    ys = [t["y"] for t in trio]
                    span_x = (max(xs) - min(xs)) + 7 * min(units)
                    span_y = (max(ys) - min(ys)) + 7 * min(units)
                    return {"found": True, "area": min(1.0, span_x * span_y / float(w * h))}
    return {"found": False, "area": 0.0}


def metrics(rgba):
    """Números simples da miniatura usados pelas regras."""
    h, w = rgba.shape[:2]
    n = h * w
    alpha = rgba[..., 3]
    transparent = float((alpha < 128).sum()) / n
    rgb = rgba[..., :3].astype(np.int16)
    # cores quantizadas (4 bits por canal): foto tem centenas, logo tem poucas
    q = ((rgb[..., 0] >> 4) << 8) | ((rgb[..., 1] >> 4) << 4) | (rgb[..., 2] >> 4)
    counts = np.bincount(q.ravel(), minlength=4096)
    order = np.argsort(counts)[::-1]
    shares = counts[order] / n
    sig_bins = int((shares >= 0.005).sum())
    # primeiro plano (tudo que não é a cor de fundo dominante): em logo são 1-3
    # cores chapadas; em foto de objeto sobre fundo branco espalha por muitas faixas
    fg = counts.copy()
    fg[order[0]] = 0
    fg_total = int(fg.sum())
    fg_sig = int((fg >= 0.02 * fg_total).sum()) if fg_total else 0
    # contraste entre as 3 cores dominantes (centro de cada faixa de 4 bits):
    # logo = fundo claro x cor da marca; noite/foto escura = tudo parecido
    centers = [(((b >> 8) & 15) * 16 + 8, ((b >> 4) & 15) * 16 + 8, (b & 15) * 16 + 8)
               for b in order[:3]]
    spread = max((sum((x - y) ** 2 for x, y in zip(centers[i], centers[j])) ** 0.5
                  for i in range(len(centers)) for j in range(i + 1, len(centers))), default=0.0)
    top3 = float(shares[:3].sum())   # quão concentrada é a paleta (degradê espalha, logo concentra)
    # fração de pixels "planos" (vizinhos praticamente iguais) = sem textura/ruído
    gray = (0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2])
    dx = np.abs(np.diff(gray, axis=1))[:-1, :]
    dy = np.abs(np.diff(gray, axis=0))[:, :-1]
    flat = float(((dx < 3) & (dy < 3)).sum()) / max(1, dx.size)
    lum = gray.ravel()
    extremes = float(((lum < 60) | (lum > 195)).sum()) / n
    return {
        "transparent": transparent, "top1": float(shares[0]),
        "top2": float(shares[0] + shares[1]) if len(shares) > 1 else float(shares[0]),
        "sig_bins": sig_bins, "top3": top3, "spread": float(spread), "fg_sig": fg_sig,
        "flat": flat,
        "extremes": extremes,
    }


def classify_pixels(m, qr, media_type="photo"):
    """Motivo (str) ou None, a partir das métricas. Conservador de propósito."""
    if m["top1"] >= 0.97:
        return "blank"
    if qr["found"] and (m["extremes"] >= 0.85 or qr["area"] >= 0.12):
        return "qrcode"
    if m["transparent"] >= 0.20:
        return "transparent"
    if media_type == "photo":
        # arte chapada: pouquíssimas cores, concentradas, E quase nenhum
        # degradê/ruído. (Céu em degradê é liso e tem poucas faixas, mas a
        # paleta é espalhada: top3 baixo — por isso não entra aqui.)
        if (m["flat"] >= 0.80 and m["sig_bins"] <= 24 and m["top3"] >= 0.80
                and m["spread"] >= 90 and m["fg_sig"] <= 8):
            return "logo"
        if (m["top1"] >= 0.55 and m["sig_bins"] <= 12 and m["flat"] >= 0.65
                and m["spread"] >= 90 and m["fg_sig"] <= 8):
            return "logo"
        # preto-e-branco puro com muito detalhe fino (código de barras/texto)
        if m["extremes"] >= 0.97 and m["sig_bins"] <= 8 and m["spread"] >= 90:
            return "logo"
    return None


def inspect_bytes(data, media_type="photo"):
    """(motivo|None, métricas|None). Imagem ilegível ou sem Pillow/numpy:
    (None, None) — na dúvida, deixa passar."""
    loaded = _load(data, _QR_SIDE)
    if loaded is None:
        return None, None
    big, _has_alpha = loaded
    try:
        small = _downscale(big, _ANALYSIS_SIDE)
        m = metrics(small)
        qr = detect_qr(big) if _qr_worth_checking(m) else {"found": False, "area": 0.0}
        return classify_pixels(m, qr, media_type), dict(m, qr=qr["found"], qr_area=qr["area"])
    except Exception:
        log.debug("[vortex] análise de qualidade falhou", exc_info=True)
        return None, None


def _downscale(arr, side):
    h, w = arr.shape[:2]
    if max(h, w) <= side:
        return arr
    step = max(1, int(round(max(h, w) / side)))
    return arr[::step, ::step]


def _qr_worth_checking(m):
    """QR tem poucas cores e muitos pixels extremos; foto colorida não precisa
    pagar o varredor de linhas."""
    return m["sig_bins"] <= 40 and m["extremes"] >= 0.70


def judge(url="", title="", tags="", source_url="", data=None, media_type="photo"):
    """Atalho: texto primeiro (barato); depois pixels, se houver bytes."""
    reason = check_text(url, title, tags, source_url)
    if reason:
        return reason
    if data:
        reason, _m = inspect_bytes(data, media_type)
        return reason
    return None


# ---------------------------------------------------------------------------
# 3) repetidas (itens já gravados)
# ---------------------------------------------------------------------------
def _popcount(x):
    return bin(x).count("1")


def _chunk_masks(distance):
    """Pigeonhole: com distância <= d, ao menos 1 de (d+1) pedaços é idêntico."""
    parts = distance + 1
    base, extra = divmod(64, parts)
    sizes = [base + (1 if i < extra else 0) for i in range(parts)]
    out, shift = [], 0
    for sz in sizes:
        out.append((shift, (1 << sz) - 1))
        shift += sz
    return out


def find_clusters(rows, distance):
    """rows: [(id, phash_int)]. Devolve listas de ids (>= 2) ligadas por
    distância de Hamming <= `distance` (componentes conexos)."""
    parent = {}

    def find(a):
        while parent.setdefault(a, a) != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    hashes = dict(rows)
    for shift, mask in _chunk_masks(distance):
        buckets = defaultdict(list)
        for item_id, value in rows:
            buckets[(value >> shift) & mask].append(item_id)
        for ids in buckets.values():
            if len(ids) < 2:
                continue
            if len(ids) > 3000:   # balde absurdo (ex.: hash 0): confere só contra os vizinhos próximos
                ids = ids[:3000]
            if np is not None and len(ids) > 40:
                vals = np.array([hashes[i] for i in ids], dtype=np.uint64)
                for pos, item_id in enumerate(ids):
                    x = vals[pos + 1:] ^ vals[pos]
                    # popcount de uint64 em numpy
                    bits = np.unpackbits(x.view(np.uint8).reshape(-1, 8), axis=1).sum(axis=1)
                    for hit in np.flatnonzero(bits <= distance):
                        union(item_id, ids[pos + 1 + int(hit)])
            else:
                for a in range(len(ids)):
                    for b in range(a + 1, len(ids)):
                        if _popcount(hashes[ids[a]] ^ hashes[ids[b]]) <= distance:
                            union(ids[a], ids[b])
    groups = defaultdict(list)
    for item_id in hashes:
        groups[find(item_id)].append(item_id)
    return [g for g in groups.values() if len(g) >= 2]


def dedupe_existing(app, database=None, dry_run=False):
    """Marca repetidas entre os itens ativos. Devolve {'duplicate': n, 'repeated': n}.

    Ordem de preferência de quem FICA: maior resolução, depois o mais antigo
    (id menor). Itens liberados por admin (`manual_ok`) nunca são tocados."""
    from extensions import db as _db
    from models import VortexItem
    database = database or _db
    cfg = app.config
    distance = cfg.get("VORTEX_DEDUPE_DISTANCE", 6)
    template_min = cfg.get("VORTEX_REPEAT_TEMPLATE_MIN", 6)
    out = {"duplicate": 0, "repeated": 0}
    with app.app_context():
        rows = (
            database.session.query(VortexItem.id, VortexItem.phash, VortexItem.width,
                                   VortexItem.height, VortexItem.junk_reason)
            .filter(VortexItem.is_active.is_(True), VortexItem.phash.isnot(None),
                    VortexItem.media_type.in_(("photo", "gif"))).all()
        )
        info, hashes = {}, []
        for item_id, ph, w, h, reason in rows:
            try:
                value = int(ph, 16)
            except (TypeError, ValueError):
                continue
            info[item_id] = ((w or 0) * (h or 0), reason)
            hashes.append((item_id, value))
        to_mark = {}
        for cluster in find_clusters(hashes, distance):
            locked = [i for i in cluster if info[i][1] == "manual_ok"]
            free = [i for i in cluster if info[i][1] != "manual_ok"]
            if not free:
                continue
            if len(cluster) >= template_min and not locked:
                for i in free:
                    to_mark[i] = "repeated"
                continue
            keep = locked[0] if locked else max(free, key=lambda i: (info[i][0], -i))
            for i in free:
                if i != keep:
                    to_mark[i] = "duplicate"
        for reason in out:
            out[reason] = sum(1 for r in to_mark.values() if r == reason)
        if to_mark and not dry_run:
            _apply_marks(database, to_mark)
    return out


def _apply_marks(database, marks):
    from models import VortexItem
    by_reason = defaultdict(list)
    for item_id, reason in marks.items():
        by_reason[reason].append(item_id)
    for reason, ids in by_reason.items():
        for start in range(0, len(ids), 500):
            chunk = ids[start:start + 500]
            (VortexItem.query.filter(VortexItem.id.in_(chunk), VortexItem.junk_reason.is_(None))
             .update({"is_active": False, "junk_reason": reason}, synchronize_session=False))
    database.session.commit()


# ---------------------------------------------------------------------------
# varredura de itens já gravados (backfill) — usada pelo motor e pela linha de comando
# ---------------------------------------------------------------------------
def pending_count(database=None):
    from extensions import db as _db
    from models import VortexItem
    database = database or _db
    return (database.session.query(database.func.count(VortexItem.id))
            .filter(VortexItem.is_active.is_(True),
                    database.or_(VortexItem.quality_version.is_(None),
                                 VortexItem.quality_version < QUALITY_VERSION)).scalar())


def text_sweep(app, database=None):
    """Passa a camada de TEXTO em todos os itens ativos (sem rede, rápido).
    Devolve quantos foram barrados."""
    from extensions import db as _db
    from models import VortexItem
    database = database or _db
    marks = {}
    with app.app_context():
        q = (database.session.query(VortexItem.id, VortexItem.media_url, VortexItem.title,
                                    VortexItem.tags, VortexItem.source_url, VortexItem.junk_reason)
             .filter(VortexItem.is_active.is_(True)))
        for row in q.yield_per(2000):
            if row.junk_reason == "manual_ok":
                continue
            if check_text(row.media_url, row.title, row.tags, row.source_url):
                marks[row.id] = "text"
        if marks:
            _apply_marks(database, marks)
    return len(marks)


def scan_rows(rows, fetch, media_types=None):
    """Analisa `rows` (objetos com id, media_type, thumb_url, media_url) usando
    `fetch(url) -> bytes|None`. Devolve {id: motivo|None}. Quem não conseguiu
    baixar entra com None (na dúvida passa): se ficasse pendente, a mesma
    leva de links mortos travaria o começo da fila pra sempre."""
    out = {}
    for r in rows:
        url = r.thumb_url or (r.media_url if r.media_type == "photo" else None)
        if not url:
            out[r.id] = None   # vídeo sem capa: nada a olhar
            continue
        data = fetch(url)
        if not data:
            out[r.id] = None
            continue
        reason, _m = inspect_bytes(data, r.media_type)
        out[r.id] = reason
    return out


def apply_scan(database, results):
    """Grava o resultado de `scan_rows`: carimba a versão e barra o lixo."""
    from models import VortexItem
    ids = list(results)
    for start in range(0, len(ids), 300):
        chunk = ids[start:start + 300]
        VortexItem.query.filter(VortexItem.id.in_(chunk)).update(
            {"quality_version": QUALITY_VERSION}, synchronize_session=False)
    junk = defaultdict(list)
    for item_id, reason in results.items():
        if reason:
            junk[reason].append(item_id)
    barred = 0
    for reason, id_list in junk.items():
        for start in range(0, len(id_list), 300):
            chunk = id_list[start:start + 300]
            barred += (VortexItem.query
                       .filter(VortexItem.id.in_(chunk), VortexItem.junk_reason.is_(None))
                       .update({"is_active": False, "junk_reason": reason},
                               synchronize_session=False))
    database.session.commit()
    return barred


def restore(item):
    """Admin restaurou: libera de vez (o filtro automático não mexe mais)."""
    item.is_active = True
    item.junk_reason = "manual_ok"
    item.quality_version = QUALITY_VERSION


# ---------------------------------------------------------------------------
# linha de comando: python vortex_quality.py --rescan | --dedupe | --text
# ---------------------------------------------------------------------------
def _main():  # pragma: no cover - uso manual
    import argparse
    import time

    from app import create_app
    from extensions import db
    from models import VortexItem

    ap = argparse.ArgumentParser(description="Limpa o Vortex de QR codes, logos e repetidas.")
    ap.add_argument("--text", action="store_true", help="só a camada de texto (rápida, sem rede)")
    ap.add_argument("--dedupe", action="store_true", help="agrupa e remove repetidas")
    ap.add_argument("--rescan", action="store_true", help="baixa as miniaturas e olha os pixels")
    ap.add_argument("--dry-run", action="store_true", help="com --dedupe: só conta")
    ap.add_argument("--limit", type=int, default=0, help="com --rescan: máximo de itens")
    args = ap.parse_args()
    app = create_app()
    if not (args.text or args.dedupe or args.rescan):
        args.text = args.dedupe = args.rescan = True
    if args.text:
        print("texto: barrados", text_sweep(app, db))
    if args.rescan:
        import requests
        from vortex_crawler import _download_head
        http = requests.Session()
        http.headers["User-Agent"] = app.config["VORTEX_USER_AGENT"]
        done = barred = 0
        with app.app_context():
            while True:
                rows = (VortexItem.query.filter(
                    VortexItem.is_active.is_(True),
                    db.or_(VortexItem.quality_version.is_(None),
                           VortexItem.quality_version < QUALITY_VERSION))
                        .order_by(VortexItem.id.desc()).limit(app.config["VORTEX_QUALITY_BATCH"]).all())
                if not rows or (args.limit and done >= args.limit):
                    break
                res = scan_rows(rows, lambda u: _download_head(
                    http, u, app.config["VORTEX_REQUEST_TIMEOUT"], max_bytes=1_500_000))
                if not res:   # nada baixou neste lote: evita laço infinito
                    time.sleep(2)
                    break
                barred += apply_scan(db, res)
                done += len(res)
                print(f"  analisados {done}, barrados {barred}", end="\r")
        print(f"\nrescan: analisados {done}, barrados {barred}")
    if args.dedupe:
        print("repetidas:", dedupe_existing(app, db, dry_run=args.dry_run))


if __name__ == "__main__":  # pragma: no cover
    _main()
