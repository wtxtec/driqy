"""
Compreensão de conteúdo do Vortex — ligação com o banco (Parte 3B).

`vortex_concepts.py` (3A) é o cérebro PURO: texto -> conceitos. Este módulo
guarda o resultado em cada `VortexItem` e mantém tudo em dia:

  concepts         "carro_esportivo:1,estrada:0.84"  (o 1º é o assunto principal)
  concept_tags     " carro_esportivo carro veiculo_rodas veiculo "  (conceito + ancestrais)
  concept_version  versão do vocabulário que gerou os dois campos acima

Convenções dos campos
---------------------
* NULL em `concept_version`  = nunca analisado (entra na fila de reprocessamento).
* `concepts == ""`           = analisado, mas nada no texto casou com o vocabulário.
  `concept_tags` guarda só o DOMÍNIO da categoria (" veiculo ") ou "" se nem isso.
* `concept_version <` atual  = vocabulário mudou (`CONCEPTS_VERSION` subiu): reprocessar.

Quando roda
-----------
1) Item NOVO: `vortex_crawler.enrich` chama `build_fields` e já grava (item nasce entendido).
2) Acervo ANTIGO: laço `IngestEngine._concepts_loop` (só texto, sem rede, lotes de 500, o mais
   novo primeiro). Pelo terminal: `python vortex_concepts.py --reprocess`.
3) Quando o CLIP termina de olhar a imagem e preenche `visual_tags`, `IngestEngine._apply_clip`
   recalcula (a imagem pode dizer "cachoeira" quando o título diz só "IMG_2031").

Categoria "outros"
-------------------
Item sem categoria definida pela fonte e que a lista de palavras-chave não resolveu ficava em
"outros". Se o texto/CLIP aponta um domínio com confiança (`suggest_category`), a categoria passa
a ser a do domínio (carro -> "carros", cachoeira -> "natureza"...). NUNCA mexe em categoria que
a fonte definiu, e o UPDATE só vale se a linha ainda estiver em "outros" (não atropela o CLIP).

Concorrência
------------
O gravador do motor insere; a visão/CLIP atualiza visual_tags/tags; este módulo atualiza só as 3
colunas de conceito (e `category` quando era "outros"). O UPDATE em lote só grava se a linha ainda
estiver desatualizada (`concept_version IS NULL OR < versão`): se o CLIP recalculou no meio do
caminho, o resultado dele (mais novo) não é sobrescrito por um cálculo velho.

Ajustar o vocabulário: ver `vortex_concepts.py` (docstring do topo). Para saber O QUE falta:
`python vortex_concepts.py --report` lista os conceitos mais comuns, os itens sem conceito e as
palavras mais frequentes nos títulos desses itens.
"""
import logging
import re
import threading
import time
from collections import Counter

import vortex_concepts as vc

log = logging.getLogger("vortex_understand")

CONCEPTS_COLUMN = 160
TAGS_COLUMN = 300
RECLASSIFY_MIN_CONFIDENCE = 0.6

# domínio da taxonomia -> slug de categoria do Vortex (inverso de CATEGORY_ROOT)
DOMAIN_TO_CATEGORY = {domain: cat for cat, domain in vc.CATEGORY_ROOT.items()}

# palavras que sozinhas não dizem nada (relatório de vocabulário que falta)
_STOP = frozenset("""
the and for with from that this into over under near after before about para com sem sobre entre
uma uns umas dos das nos nas por pelo pela como mais menos muito very photo image picture foto
imagem file jpg jpeg png gif webp mp4 webm img dsc dscn dscf pxl photograph stock free royalty
view views vista copy original
""".split())
_WORD = re.compile(r"[a-z]{4,}")


# ---------------------------------------------------------------------------
# cálculo (puro; usado pelo crawler, pelo laço do motor e pelo CLI)
# ---------------------------------------------------------------------------

def fit_tags(text, limit=TAGS_COLUMN):
    """Corta `concept_tags` em palavras inteiras (nunca no meio de um id) para caber na coluna."""
    if len(text) <= limit:
        return text
    tokens = text.split()
    while tokens and len(" " + " ".join(tokens) + " ") > limit:
        tokens.pop()
    return (" " + " ".join(tokens) + " ") if tokens else ""


def _fit_concepts(encoded, limit=CONCEPTS_COLUMN):
    if len(encoded) <= limit:
        return encoded
    return encoded[:limit].rsplit(",", 1)[0]


def build_fields(title="", tags="", description="", visual_tags="", category=None):
    """Entende o item. Devolve (campos_para_gravar, Understanding)."""
    u = vc.extract(title=title or "", tags=tags or "", description=description or "",
                   visual_tags=visual_tags or "", category=category)
    fields = {
        "concepts": _fit_concepts(vc.encode(u)),
        "concept_tags": fit_tags(vc.concept_tags(u)),
        "concept_version": vc.CONCEPTS_VERSION,
    }
    return fields, u


def suggest_category(u, current, valid_categories, min_confidence=RECLASSIFY_MIN_CONFIDENCE):
    """Categoria nova para um item que está em "outros", ou None (não mexer)."""
    if current != "outros" or u.source != "text" or u.confidence < min_confidence:
        return None
    cat = DOMAIN_TO_CATEGORY.get(u.domain)
    if cat and cat != "outros" and (not valid_categories or cat in valid_categories):
        return cat
    return None


# ---------------------------------------------------------------------------
# fila de reprocessamento
# ---------------------------------------------------------------------------

def _columns():
    from models import VortexItem as V
    return (V.id, V.title, V.tags, V.description, V.visual_tags, V.category, V.vfeat, V.clip_vec)


def pending_count(database=None, with_old=True):
    """Itens ativos sem análise (NULL) + os de versão antiga (`with_old`: varre a tabela)."""
    from extensions import db as _db
    from models import VortexItem as V
    database = database or _db
    q = database.session.query(database.func.count(V.id))
    n = q.filter(V.is_active.is_(True), V.concept_version.is_(None)).scalar() or 0
    if with_old:
        n += q.filter(V.is_active.is_(True), V.concept_version < vc.CONCEPTS_VERSION).scalar() or 0
    return n


def fetch_pending(database, limit, state=None):
    """Próximos itens a analisar (mais novos primeiro). `state["old_done"]` evita varrer a
    tabela atrás de versões antigas a cada ciclo quando já se sabe que não há mais."""
    from models import VortexItem as V
    state = state if state is not None else {}
    cols = _columns()
    rows = (database.session.query(*cols)
            .filter(V.is_active.is_(True), V.concept_version.is_(None))
            .order_by(V.id.desc()).limit(limit).all())
    if len(rows) < limit and not state.get("old_done"):
        want = limit - len(rows)
        old = (database.session.query(*cols)
               .filter(V.is_active.is_(True), V.concept_version < vc.CONCEPTS_VERSION)
               .order_by(V.id.desc()).limit(want).all())
        if len(old) < want:
            state["old_done"] = True
        rows += old
    return rows


def process_rows(rows, valid_categories=None, min_confidence=RECLASSIFY_MIN_CONFIDENCE,
                 clip_enabled=False):
    """rows -> (mappings p/ gravar, {id: categoria_nova}, quantos tiveram conceito).

    `clip_enabled`: item que ainda vai passar pelo CLIP (assinatura legível e sem embedding)
    NÃO é reclassificado só pelo texto: o CLIP enxerga a imagem e decide melhor. Sem isso os
    dois laços correm um contra o outro e a categoria final dependia de quem chegava primeiro."""
    mappings, reclass, with_concept = [], {}, 0
    for r in rows:
        fields, u = build_fields(r.title, r.tags, r.description, r.visual_tags, r.category)
        mappings.append({"b_id": r.id, "v_concepts": fields["concepts"],
                         "v_tags": fields["concept_tags"], "v_version": fields["concept_version"]})
        if u.concepts:
            with_concept += 1
        awaiting_clip = (clip_enabled and getattr(r, "vfeat", "") != ""
                         and getattr(r, "clip_vec", "x") is None)
        new_cat = None if awaiting_clip else suggest_category(
            u, r.category, valid_categories, min_confidence)
        if new_cat:
            reclass[r.id] = new_cat
    return mappings, reclass, with_concept


def save(database, mappings, reclass, guard=True):
    """Grava num commit só. `guard`: só atualiza linha ainda desatualizada (ver docstring).
    Devolve quantas linhas mudaram (`categoria` incluída em `reclass`)."""
    from sqlalchemy import bindparam, or_, update
    from sqlalchemy.exc import OperationalError
    from models import VortexItem
    t = VortexItem.__table__
    stmt = update(t).where(t.c.id == bindparam("b_id"))
    if guard:
        stmt = stmt.where(or_(t.c.concept_version.is_(None), t.c.concept_version < vc.CONCEPTS_VERSION))
    stmt = stmt.values(concepts=bindparam("v_concepts"), concept_tags=bindparam("v_tags"),
                       concept_version=bindparam("v_version"))
    session = database.session
    for attempt in range(5):
        try:
            if mappings:
                session.execute(stmt, mappings)
            moved = 0
            by_cat = {}
            for item_id, cat in reclass.items():
                by_cat.setdefault(cat, []).append(item_id)
            for cat, ids in by_cat.items():
                for start in range(0, len(ids), 300):
                    res = session.execute(
                        update(t).where(t.c.id.in_(ids[start:start + 300]), t.c.category == "outros")
                        .values(category=cat))
                    moved += max(res.rowcount or 0, 0)
            session.commit()
            return moved
        except OperationalError:   # banco ocupado: espera e tenta de novo
            session.rollback()
            time.sleep(0.5 * (attempt + 1))
        except Exception:
            session.rollback()
            raise
    raise RuntimeError("banco ocupado: lote de conceitos não gravado (será refeito)")


def process_batch(app, database, batch_size=500, valid_categories=None,
                  min_confidence=RECLASSIFY_MIN_CONFIDENCE, state=None, clip_enabled=False):
    """Um ciclo: pega pendentes, entende, grava. Devolve {done, with_concept, reclassified}."""
    with app.app_context():
        rows = fetch_pending(database, batch_size, state)
        if not rows:
            return {"done": 0, "with_concept": 0, "reclassified": 0}
        mappings, reclass, with_concept = process_rows(rows, valid_categories, min_confidence,
                                                       clip_enabled)
        moved = save(database, mappings, reclass)
    if moved:
        clear_caches(app)
    return {"done": len(rows), "with_concept": with_concept, "reclassified": moved}


def reprocess_all(app, database, limit=0, force=False, batch_size=500, progress=None):
    """Reprocessa o acervo (CLI). `force=True` refaz TODOS os ativos, mesmo os já na versão
    atual (útil depois de mexer no vocabulário sem subir a versão). Devolve o resumo."""
    from models import VortexItem as V
    valid = {slug for slug, _ in app.config["VORTEX_CATEGORIES"]}
    min_conf = app.config.get("VORTEX_CONCEPTS_RECLASSIFY_MIN_CONFIDENCE", RECLASSIFY_MIN_CONFIDENCE)
    total = with_concept = reclassified = 0
    state, last_id = {}, None
    with app.app_context():
        while True:
            want = batch_size if not limit else min(batch_size, limit - total)
            if want <= 0:
                break
            if force:
                q = database.session.query(*_columns()).filter(V.is_active.is_(True))
                if last_id is not None:
                    q = q.filter(V.id < last_id)
                rows = q.order_by(V.id.desc()).limit(want).all()
            else:
                rows = fetch_pending(database, want, state)
            if not rows:
                break
            mappings, reclass, wc = process_rows(rows, valid, min_conf)
            reclassified += save(database, mappings, reclass, guard=not force)
            total += len(rows)
            with_concept += wc
            last_id = rows[-1].id
            if progress:
                progress(total, with_concept, reclassified)
    clear_caches(app)
    return {"processed": total, "with_concept": with_concept, "reclassified": reclassified}


# ---------------------------------------------------------------------------
# cobertura (painel admin / relatório)
# ---------------------------------------------------------------------------

_cov_lock = threading.Lock()
_cov_cache = {"at": 0.0, "data": None}


def clear_caches(app=None):
    with _cov_lock:
        _cov_cache["at"], _cov_cache["data"] = 0.0, None
    try:
        from vortex_search import clear_stats_cache
        if app is not None:
            clear_stats_cache(app)
    except Exception:
        pass


def _title_words(titles, top):
    counts = Counter()
    for (text,) in titles:
        for w in set(_WORD.findall(vc.normalize(text or ""))):
            if w not in _STOP:
                counts[w] += 1
    return [{"word": w, "count": n} for w, n in counts.most_common(top) if n >= 2]


def coverage(app, ttl=30.0, top=25, samples=12):
    """Quanto do acervo já foi entendido + distribuição (para o admin e o relatório)."""
    now = time.monotonic()
    with _cov_lock:
        if ttl and _cov_cache["data"] is not None and now - _cov_cache["at"] < ttl:
            return _cov_cache["data"]
    data = _build_coverage(app, top, samples)
    with _cov_lock:
        _cov_cache["at"], _cov_cache["data"] = now, data
    return data


def _build_coverage(app, top, samples):
    from extensions import db
    from models import VortexItem as V
    from sqlalchemy import func
    cur = vc.CONCEPTS_VERSION
    with app.app_context():
        S = db.session
        active = V.is_active.is_(True)

        def count(*conds):
            return S.query(func.count(V.id)).filter(active, *conds).scalar() or 0

        total = count()
        pending = count(V.concept_version.is_(None))
        stale = count(V.concept_version < cur)
        understood = count(V.concept_version == cur, V.concepts != "")
        category_only = count(V.concept_version == cur, V.concepts == "", V.concept_tags != "")
        nothing = count(V.concept_version == cur, V.concepts == "", V.concept_tags == "")

        concept_rows, domain_counts = [], Counter()
        try:    # SQLite (é o banco do projeto): conceito principal = texto antes do 1º ":"
            main = func.substr(V.concepts, 1, func.instr(V.concepts, ":") - 1)
            rows = (S.query(main, func.count(V.id))
                    .filter(active, V.concepts.isnot(None), V.concepts != "")
                    .group_by(main).order_by(func.count(V.id).desc()).all())
            for cid, n in rows:
                if cid in vc.TAXONOMY:
                    concept_rows.append({"id": cid, "label": vc.label_of(cid), "count": n})
                    domain_counts[vc.TAXONOMY[cid].root] += n
        except Exception:
            S.rollback()
        domains = [{"id": d, "label": vc.label_of(d), "count": n} for d, n in domain_counts.most_common()]

        without = (S.query(V.id, V.title, V.category)
                   .filter(active, V.concept_version == cur, V.concepts == "")
                   .order_by(V.id.desc()).limit(samples).all())
        titles = (S.query(V.title).filter(active, V.concept_version == cur, V.concepts == "")
                  .order_by(V.id.desc()).limit(3000).all())
    return {
        "version": cur, "total": total, "understood": understood, "category_only": category_only,
        "nothing": nothing, "pending": pending, "stale": stale,
        "percent": round(100.0 * understood / total, 1) if total else 0.0,
        "top_concepts": concept_rows[:top], "concepts_distinct": len(concept_rows),
        "domains": domains,
        "without_samples": [{"id": i, "title": (t or "")[:90], "category": c} for i, t, c in without],
        "missing_words": _title_words(titles, 30),
    }


# ---------------------------------------------------------------------------
# linha de comando (chamada por `python vortex_concepts.py --reprocess|--report`)
# ---------------------------------------------------------------------------

def cli(argv):  # pragma: no cover - uso manual
    import argparse

    from app import create_app
    from extensions import db

    ap = argparse.ArgumentParser(prog="vortex_concepts.py",
                                 description="Entende o acervo do Vortex (conceitos por item).")
    ap.add_argument("--reprocess", action="store_true", help="analisa os itens pendentes / de versão antiga")
    ap.add_argument("--force", action="store_true", help="com --reprocess: refaz TODOS os itens ativos")
    ap.add_argument("--limit", type=int, default=0, help="com --reprocess: máximo de itens")
    ap.add_argument("--report", action="store_true", help="mostra cobertura, conceitos e o que falta")
    args = ap.parse_args(argv)
    app = create_app()
    if args.reprocess:
        t0 = time.monotonic()

        def show(n, wc, moved):
            print(f"  {n} itens, {wc} com conceito, {moved} reclassificados de 'outros'", end="\r")

        out = reprocess_all(app, db, limit=args.limit, force=args.force, progress=show)
        print(f"\nreprocessados {out['processed']} itens em {time.monotonic() - t0:.1f}s: "
              f"{out['with_concept']} com conceito, {out['reclassified']} saíram de 'outros'")
    if args.report or not args.reprocess:
        cov = coverage(app, ttl=0, top=30)
        print(f"\nitens ativos: {cov['total']} | entendidos: {cov['understood']} ({cov['percent']}%) | "
              f"só categoria: {cov['category_only']} | sem nada: {cov['nothing']} | "
              f"pendentes: {cov['pending']} | versão antiga: {cov['stale']}")
        print("\nconceito principal mais comum:")
        for r in cov["top_concepts"]:
            print(f"  {r['count']:>7}  {r['label']} ({r['id']})")
        print("\npor domínio:", ", ".join(f"{d['label']} {d['count']}" for d in cov["domains"]))
        print("\nexemplos SEM conceito (acrescente termos em vortex_concepts._RAW):")
        for r in cov["without_samples"]:
            print(f"  #{r['id']} [{r['category']}] {r['title']}")
        print("\npalavras mais frequentes nos títulos sem conceito:")
        print("  " + ", ".join(f"{w['word']} ({w['count']})" for w in cov["missing_words"]))
    return 0
