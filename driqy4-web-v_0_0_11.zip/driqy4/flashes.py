"""
Flash — fotos de 24h estilo "stories".

Quem publica um Flash ganha, enquanto ele durar, um ANEL colorido (gradiente âmbar→rosa
da rede) em volta do avatar — no feed, no perfil e na bandeja do topo. Tocar no avatar abre o
visualizador. O anel fica cinza quando o espectador já viu todos os Flashes da pessoa.

Rotas (aceitam token Bearer do app OU a sessão do site com X-Requested-With: fetch):
    POST   /api/v1/flashes                      publica (multipart: file, caption?)
    GET    /api/v1/flashes/tray                 bandeja: eu + quem sigo, com Flashes ativos
    GET    /api/v1/users/<username>/flashes     Flashes ativos de uma pessoa
    POST   /api/v1/flashes/<id>/view            marca como visto
    GET    /api/v1/flashes/<id>/viewers         (só o dono) quem viu
    DELETE /api/v1/flashes/<id>                 (só o dono) apaga antes das 24h
"""
from datetime import timedelta

from flask import current_app, g, jsonify, request

from api import api_bp, chat_login_required, current_api_user, _upload_url
from extensions import db
from models import Flash, FlashView, Follow, User, utcnow
from uploads import delete_upload, save_upload

_MAGIC = (
    (b"\xff\xd8\xff", "jpg"),
    (b"\x89PNG\r\n\x1a\n", "png"),
)


def _sniff_image(head):
    """Confere o conteúdo (não só a extensão). Devolve a extensão real ou None."""
    for magic, ext in _MAGIC:
        if head.startswith(magic):
            return ext
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    return None


def _active(query):
    return query.filter(Flash.expires_at > utcnow())


def ring_state(user_id, viewer_id):
    """{"has_flash": bool, "flash_unseen": bool} — usado em serialize_user."""
    active = _active(Flash.query.filter(Flash.user_id == user_id))
    total = active.count()
    if not total:
        return {"has_flash": False, "flash_unseen": False}
    if viewer_id is None:
        return {"has_flash": True, "flash_unseen": True}
    if viewer_id == user_id:
        return {"has_flash": True, "flash_unseen": False}  # os meus: anel "visto" (cinza)
    seen = (db.session.query(FlashView.id)
            .join(Flash, Flash.id == FlashView.flash_id)
            .filter(Flash.user_id == user_id, Flash.expires_at > utcnow(),
                    FlashView.viewer_id == viewer_id).count())
    return {"has_flash": True, "flash_unseen": seen < total}


def serialize_flash(fl, viewer=None, seen_ids=frozenset()):
    me = bool(viewer and viewer.id == fl.user_id)
    return {
        "id": fl.id,
        "image_url": _upload_url(fl.filename),
        "caption": fl.caption or "",
        "created_at": fl.created_at.isoformat() + "Z",
        "expires_at": fl.expires_at.isoformat() + "Z",
        "seen": me or fl.id in seen_ids,
        "views_count": fl.views_count if me else None,
    }


def _seen_ids(viewer, flash_ids):
    if not viewer or not flash_ids:
        return frozenset()
    rows = (db.session.query(FlashView.flash_id)
            .filter(FlashView.viewer_id == viewer.id, FlashView.flash_id.in_(list(flash_ids))).all())
    return frozenset(r[0] for r in rows)


def _owner_brief(user):
    return {
        "id": user.id, "username": user.username, "display_name": user.display_label,
        "avatar_url": _upload_url(user.avatar_filename),
        "accent_color": user.accent_color or current_app.config["DEFAULT_ACCENT"],
    }


@api_bp.route("/flashes", methods=["POST"])
@chat_login_required
def flash_create():
    user = current_api_user()
    cfg = current_app.config
    upload = request.files.get("file")
    if not (upload and upload.filename):
        return jsonify({"error": "Escolha uma imagem para o Flash."}), 400
    head = upload.stream.read(16)
    upload.stream.seek(0, 2)
    size = upload.stream.tell()
    upload.stream.seek(0)
    ext = _sniff_image(head)
    if ext is None:
        return jsonify({"error": "Formato inválido. Use JPG, PNG ou WebP."}), 400
    if size > cfg["FLASH_MAX_BYTES"]:
        return jsonify({"error": "Imagem muito grande (máx. 12 MB)."}), 413
    active = _active(Flash.query.filter_by(user_id=user.id)).count()
    if active >= cfg["FLASH_MAX_ACTIVE_PER_USER"]:
        return jsonify({"error": "Você atingiu o limite de Flashes ativos."}), 429

    caption = (request.form.get("caption") or "").strip()[:cfg["FLASH_CAPTION_MAX"]]
    now = utcnow()
    rel = save_upload(upload, "flash", ext)
    fl = Flash(user_id=user.id, filename=rel, caption=caption, created_at=now,
               expires_at=now + timedelta(hours=cfg["FLASH_TTL_HOURS"]))
    db.session.add(fl)
    db.session.commit()
    return jsonify({"flash": serialize_flash(fl, user)}), 201


@api_bp.route("/flashes/tray", methods=["GET"])
@chat_login_required
def flash_tray():
    """Bandeja do topo: eu primeiro (se tiver Flash ou pra criar), depois quem sigo —
    não vistos antes dos vistos, e dentro de cada grupo o mais recente primeiro."""
    me = current_api_user()
    followed = [r[0] for r in db.session.query(Follow.followed_id).filter(Follow.follower_id == me.id).all()]
    ids = list({*followed, me.id})
    rows = (_active(db.session.query(Flash.user_id, db.func.max(Flash.created_at), db.func.count(Flash.id)))
            .filter(Flash.user_id.in_(ids)).group_by(Flash.user_id).all())
    latest = {uid: (ts, n) for uid, ts, n in rows}
    flash_ids_by_user = {}
    for fid, uid in (_active(db.session.query(Flash.id, Flash.user_id))
                     .filter(Flash.user_id.in_(list(latest))).all()):
        flash_ids_by_user.setdefault(uid, []).append(fid)
    seen = _seen_ids(me, [f for fl in flash_ids_by_user.values() for f in fl])

    users = {u.id: u for u in User.query.filter(User.id.in_(list(latest) + [me.id])).all()}
    items = []
    for uid, (ts, n) in latest.items():
        if uid == me.id:
            continue
        unseen = any(f not in seen for f in flash_ids_by_user[uid])
        items.append({"user": _owner_brief(users[uid]), "count": n, "unseen": unseen,
                      "latest_at": ts.isoformat() + "Z"})
    items.sort(key=lambda i: i["latest_at"], reverse=True)   # mais recente primeiro
    items.sort(key=lambda i: not i["unseen"])                # estável: não vistos na frente
    mine = latest.get(me.id)
    return jsonify({
        "me": {"user": _owner_brief(me), "count": mine[1] if mine else 0,
               "latest_at": mine[0].isoformat() + "Z" if mine else None},
        "items": items,
    })


@api_bp.route("/users/<username>/flashes", methods=["GET"])
@chat_login_required
def flash_of_user(username):
    me = current_api_user()
    user = User.query.filter(User.username.ilike(username)).first()
    if user is None:
        return jsonify({"error": "Usuário não encontrado."}), 404
    flashes = (_active(Flash.query.filter_by(user_id=user.id)).order_by(Flash.created_at.asc()).all())
    seen = _seen_ids(me, [f.id for f in flashes])
    return jsonify({"user": _owner_brief(user),
                    "flashes": [serialize_flash(f, me, seen) for f in flashes]})


@api_bp.route("/flashes/<int:flash_id>/view", methods=["POST"])
@chat_login_required
def flash_mark_viewed(flash_id):
    me = current_api_user()
    fl = _active(Flash.query.filter_by(id=flash_id)).first()
    if fl is None:
        return jsonify({"error": "Flash não encontrado ou expirado."}), 404
    if fl.user_id != me.id and not FlashView.query.filter_by(flash_id=fl.id, viewer_id=me.id).first():
        db.session.add(FlashView(flash_id=fl.id, viewer_id=me.id))
        fl.views_count = (fl.views_count or 0) + 1
        db.session.commit()
    return jsonify({"ok": True})


@api_bp.route("/flashes/<int:flash_id>/viewers", methods=["GET"])
@chat_login_required
def flash_viewers(flash_id):
    me = current_api_user()
    fl = Flash.query.get_or_404(flash_id)
    if fl.user_id != me.id:
        return jsonify({"error": "Sem permissão."}), 403
    rows = (FlashView.query.filter_by(flash_id=fl.id).order_by(FlashView.viewed_at.desc()).limit(200).all())
    return jsonify({"viewers": [{**_owner_brief(r.viewer), "viewed_at": r.viewed_at.isoformat() + "Z"}
                                for r in rows]})


@api_bp.route("/flashes/<int:flash_id>", methods=["DELETE"])
@chat_login_required
def flash_delete(flash_id):
    me = current_api_user()
    fl = Flash.query.get_or_404(flash_id)
    if fl.user_id != me.id:
        return jsonify({"error": "Sem permissão."}), 403
    delete_upload(fl.filename)
    db.session.delete(fl)
    db.session.commit()
    return jsonify({"ok": True})


def ring_map():
    """{user_id: "unseen" | "seen"} de todo mundo com Flash ativo — uma consulta por requisição
    (cacheada em flask.g), usada pelos templates do site pra desenhar o anel nos avatares."""
    cached = getattr(g, "_flash_ring_map", None)
    if cached is not None:
        return cached
    from flask_login import current_user
    viewer_id = current_user.id if getattr(current_user, "is_authenticated", False) else None
    now = utcnow()
    rows = db.session.query(Flash.id, Flash.user_id).filter(Flash.expires_at > now).all()
    seen = set()
    if viewer_id and rows:
        seen = {r[0] for r in db.session.query(FlashView.flash_id)
                .filter(FlashView.viewer_id == viewer_id).all()}
    out = {}
    for fid, uid in rows:
        unseen = (uid != viewer_id) and (fid not in seen)
        out[uid] = "unseen" if (out.get(uid) == "unseen" or unseen) else "seen"
    g._flash_ring_map = out
    return out


def ring_class(user_id):
    """Classe CSS do anel ('' se a pessoa não tem Flash ativo)."""
    st = ring_map().get(user_id)
    return f"flash-ring flash-ring--{st}" if st else ""
