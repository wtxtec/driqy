"""
Algoritmo de recomendação de notícias, no espírito do Google Notícias:
mistura interesse explícito (categorias escolhidas nas configurações),
afinidade implícita (categorias, veículos e ASSUNTOS que o usuário mais
clica pra ler), novidade, cobertura (quantos veículos publicaram o mesmo
fato) e um passo de diversificação — sem nenhuma dependência de ML externa.

Pontuação de cada notícia = soma pesada de:
  - interesse explícito (peso alto: o usuário escolheu de propósito);
  - afinidade implícita por categoria (cliques dos últimos 30 dias, com
    os cliques recentes valendo mais que os antigos);
  - afinidade implícita por veículo/fonte (peso baixo);
  - afinidade por ASSUNTO: palavras dos títulos que o usuário clicou
    (perfil de termos com decaimento de 7 dias) comparadas ao título da
    notícia — pega quem lê tudo de "Copa" ou "dólar" dentro de uma mesma
    categoria, coisa que a afinidade por categoria não enxerga;
  - novidade (decaimento exponencial; o meio-tempo depende da categoria);
  - cobertura: notícia que vários veículos diferentes publicaram (agrupadas
    por similaridade de título) é um fato mais importante que um furo
    isolado — sobe na lista;
  - popularidade (cliques na plataforma, escala logarítmica).

Penalidades (reordenam, nunca escondem — esconder encolhia o feed):
  - já lida pelo usuário nas últimas READ_COOLDOWN_HOURS horas;
  - repetição do mesmo fato: só a melhor versão (com imagem, mais recente)
    de cada grupo de títulos parecidos fica no topo; as demais descem;
  - sem imagem (quando NEWS_ALLOW_NO_IMAGE): o card colorido da categoria
    aparece, mas depois das notícias com foto.

O pool de candidatos é montado POR CATEGORIA (as mais recentes de cada
uma) e unido no feed "Para você". Antes era só "as 300 mais recentes do
site inteiro", e categorias de pouco volume (política, ciência...) eram
engolidas por quem publica mais — o feed ficava sem elas.

Depois de pontuado, o pool passa por uma diversificação (mesmo espírito do
MMR): evita empilhar vários artigos seguidos da mesma fonte ou categoria.

Usuário sem interesses/cliques (cold start) recebe basicamente um feed
por novidade+cobertura+popularidade, que vai ficando personalizado.
"""
import math
import random
import re
from collections import Counter
from datetime import timedelta

from cache import TTLCache
from flask import current_app
from extensions import db
from models import NewsArticle, NewsInteraction, NewsInterest, utcnow
import news_bank
from news_weather import hide_for_user, user_place_keys
from sqlalchemy.orm import joinedload

# cache do pool "cru" (as POOL_SIZE notícias mais recentes de uma
# categoria, antes de excluir lidas/já renderizadas e pontuar) — é a
# parte cara (consulta ao banco) e é a MESMA pra todo mundo que está
# olhando a mesma categoria ao mesmo tempo, então cachear evita repetir a
# query a cada scroll/refresh. TTL curto (não "esconde" notícia nova por
# muito tempo) e some sozinho depois de expirar, sem faxina manual.
_POOL_CACHE_TTL_SECONDS = 90
_pool_cache = TTLCache(ttl_seconds=_POOL_CACHE_TTL_SECONDS, max_entries=32)

# candidatos por categoria no feed "Para você" (ver docstring do módulo)
PER_CATEGORY_POOL = 70

# artigo já aberto pelo usuário some do feed só por um tempo (não pra
# sempre) — antes, uma vez lido, o artigo nunca mais voltava a aparecer;
# num banco com um número finito de notícias por categoria isso ia
# encolhendo o pool disponível pra sempre a cada clique, até o feed
# secar (rolar por poucos segundos e já bater "fim") pra quem usa bastante
# o site. Um artigo lido há mais de READ_COOLDOWN_HOURS volta a poder
# aparecer normalmente.
READ_COOLDOWN_HOURS = 36

RECENCY_HALF_LIFE_HOURS = 18
# categorias "quentes" (o fato em si perde relevância rápido: resultado de
# jogo, manchete do dia) decaem mais rápido que categorias mais atemporais
# (uma matéria de ciência/saúde continua interessante por mais tempo). Sem
# isso, uma notícia de esporte de 2 dias atrás competia de igual pra igual
# com uma nova só por ter engajamento parecido — o meio-tempo único (18h)
# era um meio-termo que não servia bem nenhum dos dois extremos.
CATEGORY_HALF_LIFE_HOURS = {
    "esportes": 10,
    "geral": 14,
    "politica": 16,
    "economia": 20,
    "mundo": 20,
    "tecnologia": 24,
    "entretenimento": 24,
    "saude": 30,
    "ciencia": 36,
}
WEIGHT_EXPLICIT = 3.0
WEIGHT_IMPLICIT = 2.0
WEIGHT_SOURCE_IMPLICIT = 1.0
WEIGHT_RECENCY = 2.5
WEIGHT_POPULARITY = 1.0
WEIGHT_TOPIC = 1.6          # afinidade por assunto (termos dos títulos clicados)
WEIGHT_COVERAGE = 1.2       # fato coberto por vários veículos
WEIGHT_SECONDARY = 0.8      # categoria SECUNDÁRIA da matéria bate com o gosto do usuário
SECONDARY_SHARE = 0.3       # quanto um clique conta para as categorias secundárias da matéria
PENALTY_READ = 4.0          # subtraído da pontuação de notícia já lida
PENALTY_NO_IMAGE = 2.0      # subtraído quando a notícia não tem capa
DUPLICATE_FACTOR = 0.4      # multiplica a pontuação das repetições de um mesmo fato
IMPLICIT_HALF_LIFE_DAYS = 7  # cliques velhos valem metade a cada N dias
CLUSTER_MIN_SHARED = 3      # termos em comum mínimos pra dois títulos serem "o mesmo fato"
CLUSTER_MIN_JACCARD = 0.45
IMPLICIT_WINDOW_DAYS = 30
POOL_SIZE = 300

# pequena variação aleatória somada à pontuação de cada notícia, recalculada
# a cada request — sem isso a ordenação é 100% determinística (mesmo
# pool + mesmo score = mesma ordem sempre), então recarregar a página
# mostrava exatamente as mesmas notícias na mesma posição, sempre. O
# jitter é pequeno o bastante pra não bagunçar a relevância (não bota
# uma notícia irrelevante lá em cima), só reordena um pouco quem já teria
# pontuação parecida — a cada reload o feed parece "vivo" mesmo sem
# nenhuma notícia nova ter sido indexada nesse meio tempo.
WEIGHT_JITTER = 0.5

# diversificação: o quanto a pontuação de um artigo é penalizada (multiplicada)
# se uma mesma fonte/categoria já apareceu recentemente na ordenação final
DIVERSITY_SOURCE_WINDOW = 4       # não repetir a mesma fonte nas últimas N posições
DIVERSITY_SOURCE_PENALTY = 0.45
DIVERSITY_CATEGORY_WINDOW = 3     # não repetir a mesma categoria nas últimas N posições
DIVERSITY_CATEGORY_PENALTY = 0.7


_STOPWORDS = frozenset("""
para como mais pela pelo pelos pelas sobre entre apos após ainda depois antes
contra desde sera será foram esta está estao estão tem têm havia sido seus suas
dele dela deles delas isso essa esse essas esses numa numa nesta neste aqui onde
quando porque que quem qual quais cada todo toda todos todas muito muita outro
outra outros outras mesmo mesma anos ano dia dias vai vão vez veja saiba
confira entenda diz dizem afirma revela anuncia aponta mostra fala segundo
ser ter fazer faz fez pode podem deve devem apos governo brasil brasileiro
""".split())
_TERM_RE = re.compile(r"[a-zà-úA-ZÀ-Ú0-9]{4,}", re.UNICODE)


def _title_terms(title):
    """Conjunto de termos significativos do título (sem stopwords/curtas)."""
    return {t for t in _TERM_RE.findall((title or "").lower()) if t not in _STOPWORDS}


def _click_weight(created_at, now):
    """Clique recente vale mais: decai pela metade a cada IMPLICIT_HALF_LIFE_DAYS."""
    if not created_at:
        return 0.5
    age_days = max((now - created_at).total_seconds() / 86400.0, 0)
    return math.pow(0.5, age_days / IMPLICIT_HALF_LIFE_DAYS)


def _recent_clicks(user_id):
    """(categoria, source_id, título, criado_em, article_id) dos cliques da janela."""
    since = utcnow() - timedelta(days=IMPLICIT_WINDOW_DAYS)
    return (
        db.session.query(
            NewsInteraction.category, NewsArticle.source_id,
            NewsArticle.title, NewsInteraction.created_at, NewsArticle.id,
        )
        .join(NewsArticle, NewsInteraction.article_id == NewsArticle.id)
        .filter(NewsInteraction.user_id == user_id, NewsInteraction.created_at >= since)
        .all()
    )


def _build_profile(user_id):
    """Perfil implícito do usuário a partir dos cliques recentes, tudo
    normalizado de 0 a 1: (por_categoria, por_fonte, por_termo).
    Os termos são os NORMALIZADOS do banco (news_bank.extract_terms: sem
    acento, singular, nomes próprios em destaque) — os mesmos usados para
    pontuar as notícias candidatas. Categorias secundárias do clique contam
    um pouco (30%): quem lê "reforma tributária" gosta de economia E política."""
    rows = _recent_clicks(user_id)
    if not rows:
        return {}, {}, {}
    now = utcnow()
    bank = news_bank.info_for([r[4] for r in rows])
    by_cat, by_source, by_term = Counter(), Counter(), Counter()
    for category, source_id, title, created_at, article_id in rows:
        w = _click_weight(created_at, now)
        by_cat[category] += w
        by_source[source_id] += w
        info = bank.get(article_id)
        for sec in (info["secondary"] if info else ()):
            by_cat[sec] += w * SECONDARY_SHARE
        for term in (info["terms"] if info else news_bank.extract_terms(title)):
            by_term[term] += w

    def norm(counter, min_value=0.0):
        top = max(counter.values()) if counter else 0
        if not top:
            return {}
        return {k: v / top for k, v in counter.items() if v >= min_value}

    # termo que só apareceu num clique velho é ruído — exige peso mínimo
    return norm(by_cat), norm(by_source), norm(by_term, min_value=0.35)


def _recency_score(published_at, category):
    if not published_at:
        return 0.3
    half_life = CATEGORY_HALF_LIFE_HOURS.get(category, RECENCY_HALF_LIFE_HOURS)
    age_hours = max((utcnow() - published_at).total_seconds() / 3600.0, 0)
    return math.pow(0.5, age_hours / half_life)


def _topic_score_terms(terms, term_affinity):
    """Igual a _topic_score, mas com os termos normalizados já prontos (banco)."""
    if not term_affinity or not terms:
        return 0.0
    hits = sorted((term_affinity.get(t, 0.0) for t in terms), reverse=True)[:3]
    return sum(hits) / 3.0


def _topic_score(title, term_affinity):
    """Média das 3 maiores afinidades de termo do título (0 a 1). Usar só
    os melhores termos evita que títulos longos pontuem à toa."""
    if not term_affinity:
        return 0.0
    hits = sorted((term_affinity.get(t, 0.0) for t in _title_terms(title)), reverse=True)[:3]
    return sum(hits) / 3.0


def _cluster_same_story(articles):
    """Agrupa notícias que contam o MESMO fato (títulos com muitos termos
    em comum), mesmo vindas de veículos diferentes. Usa índice invertido
    termo -> grupos, então não compara todos contra todos.

    Retorna (coverage, duplicate_ids):
      coverage[id]  = nº de veículos distintos no grupo da notícia;
      duplicate_ids = ids que NÃO são a melhor versão do seu grupo (a
                      melhor é a que tem imagem e, depois, a mais recente).
    """
    ordered = sorted(
        articles,
        key=lambda a: (bool(a.image_url), a.published_at or utcnow()),
        reverse=True,
    )
    clusters = []        # cada grupo: {"terms": set, "members": [articles]}
    index = {}           # termo -> {índices de grupos}
    for art in ordered:
        terms = _title_terms(art.title)
        placed = None
        if len(terms) >= CLUSTER_MIN_SHARED:
            votes = Counter()
            for t in terms:
                for ci in index.get(t, ()):
                    votes[ci] += 1
            for ci, shared in votes.most_common(3):
                if shared < CLUSTER_MIN_SHARED:
                    break
                union = len(terms | clusters[ci]["terms"])
                if shared / union >= CLUSTER_MIN_JACCARD:
                    placed = ci
                    break
        if placed is None:
            clusters.append({"terms": set(terms), "members": [art]})
            ci = len(clusters) - 1
        else:
            clusters[placed]["members"].append(art)
            clusters[placed]["terms"] |= terms
            ci = placed
        for t in terms:
            index.setdefault(t, set()).add(ci)

    coverage, duplicates = {}, set()
    for cluster in clusters:
        members = cluster["members"]
        n_sources = len({m.source_id for m in members})
        for pos, m in enumerate(members):
            coverage[m.id] = n_sources
            if pos > 0:
                duplicates.add(m.id)
    return coverage, duplicates


def _score(article, ctx):
    score = 0.0
    is_read = article.id in ctx["read_ids"]
    # notícia já lida não ganha bônus de interesse: o próprio clique nela
    # aumenta a afinidade com a categoria/fonte/assunto e isso anulava a
    # penalidade de "já li" (a lida continuava no topo)
    if not is_read:
        if article.category in ctx["explicit"]:
            score += WEIGHT_EXPLICIT
        score += WEIGHT_IMPLICIT * ctx["by_category"].get(article.category, 0.0)
        score += WEIGHT_SOURCE_IMPLICIT * ctx["by_source"].get(article.source_id, 0.0)
        info = ctx["info"].get(article.id)
        if info is not None:
            score += WEIGHT_TOPIC * _topic_score_terms(info["terms"], ctx["by_term"])
            for sec in info["secondary"]:
                if sec in ctx["explicit"]:
                    score += WEIGHT_SECONDARY * 0.6
                score += WEIGHT_SECONDARY * ctx["by_category"].get(sec, 0.0) * 0.5
        else:
            score += WEIGHT_TOPIC * _topic_score_terms(
                set(news_bank.extract_terms(article.title)), ctx["by_term"])
    score += WEIGHT_RECENCY * _recency_score(article.published_at, article.category)
    if ctx["popularity_log_max"]:
        score += WEIGHT_POPULARITY * (math.log1p(article.clicks_count) / ctx["popularity_log_max"])
    # cobertura: 1 veículo = 0; 2 = 0.43; 3 = 0.68; 5+ = 1.0 (satura)
    n_sources = ctx["coverage"].get(article.id, 1)
    if n_sources > 1:
        score += WEIGHT_COVERAGE * min(math.log2(n_sources) / math.log2(5), 1.0)
    if not article.image_url:
        score -= PENALTY_NO_IMAGE
    if is_read:
        score -= PENALTY_READ
    score += random.uniform(0, WEIGHT_JITTER)
    if article.id in ctx["duplicates"]:
        score = score * DUPLICATE_FACTOR if score > 0 else score
    return score


def _diversify(scored_articles):
    """Reordena por pontuação, mas evita empilhar vários artigos seguidos
    da mesma fonte/categoria: a cada posição escolhe o melhor artigo
    restante já penalizando (não descartando) quem se repete demais perto
    das últimas escolhas. A penalidade só se aplica a pontuação positiva
    (multiplicar uma nota negativa por <1 a MELHORARIA)."""
    remaining = list(scored_articles)
    picked = []
    recent_sources = []
    recent_categories = []

    while remaining:
        best_idx = 0
        best_adjusted = -math.inf
        for idx, (article, score) in enumerate(remaining):
            adjusted = score
            if adjusted > 0:
                if article.source_id in recent_sources:
                    adjusted *= DIVERSITY_SOURCE_PENALTY
                if article.category in recent_categories:
                    adjusted *= DIVERSITY_CATEGORY_PENALTY
            if adjusted > best_adjusted:
                best_adjusted = adjusted
                best_idx = idx

        article, _s = remaining.pop(best_idx)
        picked.append(article)

        recent_sources.append(article.source_id)
        if len(recent_sources) > DIVERSITY_SOURCE_WINDOW:
            recent_sources.pop(0)
        recent_categories.append(article.category)
        if len(recent_categories) > DIVERSITY_CATEGORY_WINDOW:
            recent_categories.pop(0)

    return picked


def _build_raw_pool(category_filter):
    """Pool de candidatos. Caminho principal: o BANCO TEMPORÁRIO (news_bank) —
    notícias dos últimos 3 dias já analisadas, com o grupo do mesmo fato pronto.
    Reserva (banco vazio/pequeno, ex.: primeira subida): consulta direta à
    tabela de notícias e agrupa na hora. Devolve só ids e dicts simples — nunca
    objetos do SQLAlchemy (a sessão fecha no fim da request)."""
    cfg = current_app.config
    allow_no_image = cfg.get("NEWS_ALLOW_NO_IMAGE", True)
    try:
        if news_bank.size() < cfg.get("NEWS_BANK_MIN_ITEMS", 40):
            # banco vazio (1º uso/reinício): recria as fichas só com o que já está no banco de dados
            news_bank.backfill(current_app._get_current_object())
        if news_bank.size() >= cfg.get("NEWS_BANK_MIN_ITEMS", 40):
            pool = news_bank.raw_pool(
                cfg["NEWS_CATEGORIES"], category_filter, PER_CATEGORY_POOL, POOL_SIZE, allow_no_image)
            if pool["ids"]:
                pool["from_bank"] = True
                return pool
    except Exception as exc:  # o banco nunca pode derrubar o feed
        db.session.rollback()
        current_app.logger.warning(f"[news_recommender] banco indisponível, usando consulta direta: {exc}")

    def base_query():
        q = NewsArticle.query.options(joinedload(NewsArticle.source))
        if not allow_no_image:
            q = q.filter(NewsArticle.image_url.isnot(None), NewsArticle.image_url != "")
        return q

    if category_filter:
        raw = (
            base_query().filter(NewsArticle.category == category_filter)
            .order_by(NewsArticle.published_at.desc())
            .limit(POOL_SIZE).all()
        )
    else:
        # um bloco por categoria: nenhuma é engolida pelas de maior volume
        seen, raw = set(), []
        for key, _label in cfg["NEWS_CATEGORIES"]:
            rows = (
                base_query().filter(NewsArticle.category == key)
                .order_by(NewsArticle.published_at.desc())
                .limit(PER_CATEGORY_POOL).all()
            )
            for a in rows:
                if a.id not in seen:
                    seen.add(a.id)
                    raw.append(a)

    coverage, duplicates = _cluster_same_story(raw)
    return {
        "ids": [a.id for a in sorted(raw, key=lambda a: a.published_at or utcnow(), reverse=True)],
        "coverage": coverage,
        "duplicates": duplicates,
    }


def recommended_articles(user, limit=20, category_filter=None, exclude_ids=None):
    """
    Retorna (artigos_da_página, has_next). A ordenação é recalculada a
    partir de um "pool" de candidatos recentes (ver _build_raw_pool) — não
    dá pra paginar por cursor de id, já que a ordem é por pontuação.

    `exclude_ids` tira artigos específicos do pool antes de pontuar/
    paginar: o front-end manda os ids já renderizados ao pedir mais
    (rolagem infinita), pra paginação não duplicar nem pular notícia se a
    pontuação mudar entre uma chamada e outra.

    Notícias já lidas NÃO são mais excluídas: descem pro fim (PENALTY_READ).
    Excluir encolhia o pool de quem lê bastante até o feed secar.
    """
    authenticated = user is not None and getattr(user, "is_authenticated", False)
    excluded = set(exclude_ids or ())

    read_ids = set()
    if authenticated:
        read_cutoff = utcnow() - timedelta(hours=READ_COOLDOWN_HOURS)
        read_ids = {
            row[0] for row in
            db.session.query(NewsInteraction.article_id)
            .filter(NewsInteraction.user_id == user.id, NewsInteraction.created_at >= read_cutoff)
            .all()
        }

    # o pool "cru" é cacheado por categoria (mesma consulta pra todos). O
    # cache guarda só IDS e dicts simples, nunca NewsArticle: a sessão do
    # SQLAlchemy fecha no fim de cada request e um objeto reaproveitado
    # fica "solto" (DetachedInstanceError) ao ler article.source.
    cache_key = category_filter or "_todas"
    cached_pool = _pool_cache.get(cache_key)
    if cached_pool is None:
        cached_pool = _build_raw_pool(category_filter)
        _pool_cache.set(cache_key, cached_pool)

    wanted_ids = [i for i in cached_pool["ids"] if i not in excluded] if excluded else cached_pool["ids"]
    if not wanted_ids:
        return [], False

    by_id = {
        a.id: a for a in
        NewsArticle.query.options(joinedload(NewsArticle.source))
        .filter(NewsArticle.id.in_(wanted_ids))
        .all()
    }
    pool = [by_id[i] for i in wanted_ids if i in by_id]
    # previsão do tempo de uma cidade específica só aparece pra quem mora nela
    # (clima em geral continua pra todos); ver news_weather.py
    place_keys = user_place_keys(getattr(user, "location", "")) if authenticated else frozenset()
    pool = [a for a in pool if not hide_for_user(a.title, place_keys)]
    if not pool:
        return [], False

    explicit, by_category, by_source, by_term = set(), {}, {}, {}
    if authenticated:
        explicit = {i.category for i in NewsInterest.query.filter_by(user_id=user.id).all()}
        by_category, by_source, by_term = _build_profile(user.id)

    ctx = {
        "explicit": explicit,
        "by_category": by_category,
        "by_source": by_source,
        "by_term": by_term,
        "coverage": cached_pool["coverage"],
        "duplicates": cached_pool["duplicates"],
        "info": news_bank.info_for([a.id for a in pool]) if cached_pool.get("from_bank") else {},
        "read_ids": read_ids,
        "popularity_log_max": max((math.log1p(a.clicks_count) for a in pool), default=0.0),
    }
    scored = sorted(((a, _score(a, ctx)) for a in pool), key=lambda pair: pair[1], reverse=True)
    ranked = _diversify(scored)

    page = ranked[:limit]
    has_next = limit < len(ranked)
    return page, has_next
