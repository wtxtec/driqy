import os
from datetime import datetime

from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix

from config import Config
from extensions import db, login_manager, oauth


def _ensure_schema_upgrades(db):
    """
    Adiciona colunas novas em bancos já existentes (criados antes desta versão),
    sem precisar de uma ferramenta de migração completa. Seguro para rodar toda
    vez que o app sobe: só faz algo se a coluna ainda não existir.
    """
    from sqlalchemy import inspect, text

    inspector = inspect(db.engine)
    if "users" not in inspector.get_table_names():
        return
    existing_columns = {col["name"] for col in inspector.get_columns("users")}
    if "cover_filename" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN cover_filename VARCHAR(255)"))
    if "reset_token" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN reset_token VARCHAR(64)"))
    if "reset_token_expires" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN reset_token_expires DATETIME"))
    if "google_id" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN google_id VARCHAR(255)"))
            conn.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS ix_users_google_id ON users (google_id)"))
    if "last_seen_at" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN last_seen_at DATETIME"))
    if "location_lat" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN location_lat FLOAT"))
    if "location_lng" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN location_lng FLOAT"))
    if "rail_prefs" not in existing_columns:
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN rail_prefs TEXT"))
    if "tz_name" not in existing_columns:  # calendário global, parte 3
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN tz_name VARCHAR(64)"))
    if "show_presence" not in existing_columns:  # Fase 10
        with db.engine.begin() as conn:
            conn.execute(text("ALTER TABLE users ADD COLUMN show_presence BOOLEAN NOT NULL DEFAULT 1"))

    if "posts" in inspector.get_table_names():
        post_columns = {col["name"] for col in inspector.get_columns("posts")}
        if "views_count" not in post_columns:
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE posts ADD COLUMN views_count INTEGER NOT NULL DEFAULT 0"))
        if "source_client" not in post_columns:
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE posts ADD COLUMN source_client VARCHAR(20)"))

    if "vortex_crawl_sources" in inspector.get_table_names():
        src_columns = {col["name"] for col in inspector.get_columns("vortex_crawl_sources")}
        for col, ddl in (
            ("next_run_at", "DATETIME"),
            ("fail_count", "INTEGER NOT NULL DEFAULT 0"),
            ("empty_streak", "INTEGER NOT NULL DEFAULT 0"),
            ("rotation", "INTEGER NOT NULL DEFAULT 0"),
        ):
            if col not in src_columns:
                with db.engine.begin() as conn:
                    conn.execute(text(f"ALTER TABLE vortex_crawl_sources ADD COLUMN {col} {ddl}"))
        if "origin" not in src_columns:
            with db.engine.begin() as conn:
                conn.execute(text(
                    "ALTER TABLE vortex_crawl_sources ADD COLUMN origin VARCHAR(10) NOT NULL DEFAULT 'manual'"))
        with db.engine.begin() as conn:
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_vortex_crawl_sources_next_run_at "
                "ON vortex_crawl_sources (next_run_at)"
            ))

    if "vortex_items" in inspector.get_table_names():
        item_columns = {col["name"] for col in inspector.get_columns("vortex_items")}
        for col, ddl in (
            ("vfeat", "VARCHAR(160)"),
            ("visual_tags", "VARCHAR(300)"),
            ("clip_vec", "TEXT"),
            ("vision_version", "INTEGER"),
            ("junk_reason", "VARCHAR(24)"),
            ("quality_version", "INTEGER"),
            ("concepts", "VARCHAR(160)"),
            ("concept_tags", "VARCHAR(300)"),
            ("concept_version", "INTEGER"),
        ):
            if col not in item_columns:
                with db.engine.begin() as conn:
                    conn.execute(text(f"ALTER TABLE vortex_items ADD COLUMN {col} {ddl}"))
        # índice parcial: achar rápido o que ainda falta analisar (backfill)
        with db.engine.begin() as conn:
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_vortex_items_vision_pending "
                "ON vortex_items (id) WHERE vfeat IS NULL AND is_active = 1"
            ))
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_vortex_items_junk_reason ON vortex_items (junk_reason)"
            ))
            # itens que o filtro de qualidade ainda não olhou (backfill)
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_vortex_items_quality_pending "
                "ON vortex_items (id) WHERE quality_version IS NULL AND is_active = 1"
            ))
            # itens que ainda não passaram pela compreensão de conteúdo (backfill)
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_vortex_items_concept_pending "
                "ON vortex_items (id) WHERE concept_version IS NULL AND is_active = 1"
            ))

    if "vortex_interactions" in inspector.get_table_names():
        inter_columns = {col["name"] for col in inspector.get_columns("vortex_interactions")}
        if "concepts" not in inter_columns:   # Parte 5: perfil de interesse por conceito
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE vortex_interactions ADD COLUMN concepts VARCHAR(160)"))

    if "news_articles" in inspector.get_table_names():
        news_columns = {col["name"] for col in inspector.get_columns("news_articles")}
        if "image_fetch_attempts" not in news_columns:
            with db.engine.begin() as conn:
                conn.execute(text(
                    "ALTER TABLE news_articles ADD COLUMN image_fetch_attempts INTEGER NOT NULL DEFAULT 0"
                ))

    if "messages" in inspector.get_table_names():
        msg_columns = {col["name"] for col in inspector.get_columns("messages")}
        for col, ddl in (
            ("msg_type", "VARCHAR(12) NOT NULL DEFAULT 'text'"),
            ("media_path", "VARCHAR(255)"),
            ("media_mime", "VARCHAR(60)"),
            ("media_size", "INTEGER"),
            ("media_duration_ms", "INTEGER"),
            ("media_width", "INTEGER"),
            ("media_height", "INTEGER"),
            ("media_name", "VARCHAR(255)"),
            ("reply_to_id", "INTEGER"),
            ("client_id", "VARCHAR(40)"),
            ("delivered_at", "DATETIME"),
            ("read_at", "DATETIME"),
            ("edited_at", "DATETIME"),
            ("deleted_at", "DATETIME"),
            ("forwarded", "BOOLEAN NOT NULL DEFAULT 0"),
            ("view_once", "BOOLEAN NOT NULL DEFAULT 0"),
            ("view_once_opened_at", "DATETIME"),
        ):
            if col not in msg_columns:
                with db.engine.begin() as conn:
                    conn.execute(text(f"ALTER TABLE messages ADD COLUMN {col} {ddl}"))

    # Avisos de virada de estação: texto pronto da notificação do sistema
    if "notifications" in inspector.get_table_names():
        notif_columns = {col["name"] for col in inspector.get_columns("notifications")}
        if "text" not in notif_columns:
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE notifications ADD COLUMN text VARCHAR(200)"))

    # Ping fase 6b: mensagem fixada por conversa
    if "conversation_prefs" in inspector.get_table_names():
        pref_columns = {col["name"] for col in inspector.get_columns("conversation_prefs")}
        if "pinned_message_id" not in pref_columns:
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE conversation_prefs ADD COLUMN pinned_message_id INTEGER"))


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    os.makedirs(os.path.join(os.path.dirname(__file__), "instance"), exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    oauth.init_app(app)

    if app.config.get("GOOGLE_CLIENT_ID") and app.config.get("GOOGLE_CLIENT_SECRET"):
        oauth.register(
            name="google",
            client_id=app.config["GOOGLE_CLIENT_ID"],
            client_secret=app.config["GOOGLE_CLIENT_SECRET"],
            server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
            client_kwargs={"scope": "openid email profile"},
        )
        app.config["GOOGLE_LOGIN_ENABLED"] = True
    else:
        app.config["GOOGLE_LOGIN_ENABLED"] = False

    from models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    from auth import auth_bp
    from main import main_bp
    from admin import admin_bp
    from chat import chat_bp
    from api import api_bp
    import flashes  # noqa: F401  (registra as rotas /api/v1/flashes* em api_bp)
    import chat_groups  # noqa: F401  (registra as rotas /api/v1/groups* em api_bp)
    from news import news_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(news_bp)

    from models import utcnow
    from flask_login import current_user as _current_user

    # muda a cada vez que o app sobe — usado como "?v=" nos links de favicon
    # pra forçar o navegador a buscar de novo em vez de usar o cache antigo
    asset_version = str(int(utcnow().timestamp()))

    @app.before_request
    def _stamp_last_seen():
        # marca "visto por último" pra saber quem está online agora (usado
        # no mapa de online do painel admin) — só grava no banco a cada
        # ~60s por usuário, pra não gerar um UPDATE em toda requisição
        if not _current_user.is_authenticated:
            return
        now = utcnow()
        last = _current_user.last_seen_at
        if last is None or (now - last).total_seconds() > 60:
            _current_user.last_seen_at = now
            try:
                db.session.commit()
            except Exception:
                # "visto por último" é só estatística: se o banco estiver
                # ocupado, ignora e tenta de novo daqui a 60s, em vez de
                # devolver erro 500 pra uma página que nem depende disso
                db.session.rollback()

    @app.context_processor
    def inject_rail():
        # personalização do painel direito (api_widgets.py): vai para o template e para o JS
        if not _current_user.is_authenticated:
            return {}
        try:
            from api_widgets import rail_context
            return {"rail_ctx": rail_context(_current_user)}
        except Exception:
            return {}

    @app.context_processor
    def inject_now():
        return {
            "now": utcnow(),
            "site_name": app.config["SITE_NAME"],
            "themes": app.config["THEMES"],
            "default_theme": app.config["DEFAULT_THEME"],
            "asset_version": asset_version,
            "google_login_enabled": app.config["GOOGLE_LOGIN_ENABLED"],
        }

    @app.template_global("flash_ring")
    def flash_ring_global(user_id):
        from flashes import ring_class
        try:
            return ring_class(user_id)
        except Exception:
            return ""

    @app.template_filter("mentions")
    def mentions_filter(text):
        from mentions import linkify_mentions
        return linkify_mentions(text)

    @app.template_filter("accent_hex")
    def accent_hex_filter(color_key):
        mapping = dict(app.config["ACCENT_COLORS"])
        return mapping.get(color_key, mapping.get(app.config["DEFAULT_ACCENT"]))

    @app.template_filter("news_category_label")
    def news_category_label_filter(category_key):
        mapping = dict(app.config["NEWS_CATEGORIES"])
        return mapping.get(category_key, category_key)

    @app.template_filter("news_category_color")
    def news_category_color_filter(category_key):
        mapping = app.config["NEWS_CATEGORY_COLORS"]
        return mapping.get(category_key, mapping.get("geral"))

    @app.template_filter("domain")
    def domain_filter(url):
        # extrai só o domínio (ex.: "g1.globo.com") pra mostrar o favicon
        # do veículo e um texto mais curto que a URL inteira
        from urllib.parse import urlparse
        try:
            netloc = urlparse(url).netloc
        except ValueError:
            return ""
        return netloc[4:] if netloc.startswith("www.") else netloc

    @app.template_filter("time_ago")
    def time_ago_filter(dt):
        # tempo relativo ("há 3 min", "há 2h", "há 5 dias") — mais fácil de
        # ler de relance num feed de notícias do que uma data/hora completa
        from models import utcnow
        if dt is None:
            return ""
        seconds = (utcnow() - dt).total_seconds()
        if seconds < 60:
            return "agora mesmo"
        minutes = int(seconds // 60)
        if minutes < 60:
            return f"há {minutes} min"
        hours = int(minutes // 60)
        if hours < 24:
            return f"há {hours}h"
        days = int(hours // 24)
        if days < 7:
            return f"há {days} dia{'s' if days > 1 else ''}"
        weeks = int(days // 7)
        if weeks < 5:
            return f"há {weeks} semana{'s' if weeks > 1 else ''}"
        months = int(days // 30)
        return f"há {months} mês{'es' if months > 1 else ''}" if months >= 1 else "há 1 mês"

    @app.template_filter("brtime")
    def brtime_filter(dt, fmt="%d/%m/%Y %H:%M"):
        # Datas no banco são salvas em UTC; esse filtro converte pro
        # horário de Brasília (UTC-3) só na hora de mostrar pro usuário.
        from models import to_brasilia
        if dt is None:
            return ""
        return to_brasilia(dt).strftime(fmt)

    @app.template_filter("chat_short_time")
    def chat_short_time_filter(dt):
        """Hora curta da caixa de entrada: HH:MM hoje, 'Ontem' ou dd/mm."""
        from models import to_brasilia, utcnow
        if dt is None:
            return ""
        d = to_brasilia(dt)
        today = to_brasilia(utcnow()).date()
        if d.date() == today:
            return d.strftime("%H:%M")
        if (today - d.date()).days == 1:
            return "Ontem"
        return d.strftime("%d/%m/%y")

    @app.errorhandler(403)
    def forbidden(e):
        return ("Acesso negado: você não tem permissão para ver esta página.", 403)

    @app.errorhandler(404)
    def not_found(e):
        return ("Página não encontrada.", 404)

    @app.route("/favicon.ico")
    def favicon_root():
        # Vários navegadores pedem /favicon.ico direto na raiz, ignorando as
        # tags <link> do <head> — isso garante que ele sempre seja encontrado.
        from flask import send_from_directory
        return send_from_directory(
            os.path.join(app.static_folder, "icons"), "favicon.ico"
        )

    @app.route("/sw.js")
    def service_worker():
        # Precisa ser servido na raiz do site (não em /static/) pra valer
        # pro site inteiro; navegadores limitam o "escopo" do service worker
        # à pasta de onde o arquivo é servido.
        from flask import send_from_directory, make_response
        response = make_response(
            send_from_directory(app.static_folder, "sw.js")
        )
        response.headers["Content-Type"] = "application/javascript; charset=utf-8"
        response.headers["Cache-Control"] = "no-cache"
        response.headers["Service-Worker-Allowed"] = "/"
        return response

    @app.route("/offline")
    def offline():
        from flask import render_template
        return render_template("offline.html")

    @app.route("/uploads/<path:filename>")
    def serve_upload(filename):
        # Arquivos de mídia enviados pelos usuários agora ficam em
        # instance/uploads (fora de static/), que o Flask não expõe
        # automaticamente — por isso essa rota serve esses arquivos.
        from flask import abort, send_from_directory
        # mídia de chat é privada: só /api/v1/messages/media/<id> serve
        if filename.replace("\\", "/").lstrip("/").startswith("chat/"):
            abort(404)
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

    with app.app_context():
        db.create_all()
        _ensure_schema_upgrades(db)

        from news_indexer import seed_default_sources
        seed_default_sources(app, db)

        # perfis e fontes padrão do crawler do Vortex (idempotente)
        from vortex_crawler import seed_vortex_defaults
        seed_vortex_defaults(app, db)

        # índice de busca (FTS5) dos itens do Vortex; reindexa sozinho se
        # estiver fora de sincronia. Sem FTS5 no SQLite, a busca usa LIKE.
        from vortex_search import ensure_search_index
        ensure_search_index(app, db)

        # tira do Vortex o que já tem cara de logo/QR/banner pelo NOME (barato,
        # sem rede); a análise dos pixels roda em segundo plano no motor
        if app.config.get("VORTEX_QUALITY_ENABLED", True):
            try:
                import vortex_quality
                vortex_quality.text_sweep(app, db)
            except Exception:
                app.logger.exception("[vortex] varredura de qualidade (texto) falhou")

    # inicia os agendadores (posts expirados + indexador de notícias).
    #
    # IMPORTANTE: com debug=True, o Flask sobe o reloader, que executa
    # create_app() em DOIS processos (o processo "pai" que só monitora
    # arquivos, e o processo filho que efetivamente serve as requisições).
    # Sem essa checagem, cada processo iniciava seu próprio scheduler, e as
    # duas instâncias tentavam escrever no mesmo driqy.db ao mesmo tempo —
    # é exatamente isso que causava os erros "database is locked" no log.
    # WERKZEUG_RUN_MAIN só existe (com valor "true") no processo filho, que
    # é o único que deve rodar os jobs agendados.
    is_reloader_parent = (
        app.debug and os.environ.get("WERKZEUG_RUN_MAIN") != "true"
    )
    if not app.config.get("TESTING") and not is_reloader_parent:
        from models import Post
        from scheduler import start_scheduler
        start_scheduler(app, db, Post)

        # inicia o agendador que busca notícias novas nos feeds RSS,
        # reaproveitando o mesmo BackgroundScheduler (ver scheduler.py)
        from news_indexer import index_all_sources
        from apscheduler.schedulers.background import BackgroundScheduler
        news_scheduler = BackgroundScheduler(daemon=True)
        news_scheduler.add_job(
            func=lambda: index_all_sources(app, db),
            trigger="interval",
            seconds=app.config.get("NEWS_INDEX_INTERVAL_SECONDS", 600),
            id="index_news_sources",
            replace_existing=True,
            next_run_time=datetime.now(),  # roda uma vez logo na subida do app
        )
        news_scheduler.start()

        # crawler do Vortex (imagens/GIFs/vídeos da internet): motor contínuo,
        # várias fontes em paralelo, gravando em lotes pequenos o tempo todo
        # (ver vortex_crawler.IngestEngine). Desligue com VORTEX_CRAWLER_ENABLED=0.
        if app.config.get("VORTEX_CRAWLER_ENABLED", True):
            from vortex_crawler import start_engine
            start_engine(app, db, initial_delay=app.config.get("VORTEX_START_DELAY_SECONDS", 20))

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="0.0.0.0", port=5000, threaded=True)  # threaded: o chat usa SSE (1 thread por conexão)
