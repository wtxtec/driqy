# PROGRESSO — Mensagens (antigo "Ping"): menu lateral, configurações e grupos (4 partes)

> **Índice geral e o que ainda resta (verificado em 10/11/2026): `PROGRESSO_INDICE.md`.**

> Passagem de bastão entre sessões/IAs. Igual nos dois projetos (`driqy4/` e `flutter_app/`).
> Continua o `PROGRESSO_PING.md` (layout estilo Telegram já pronto). **Atualize ao fim de cada parte e pare.**

## Pedido do usuário (resumo)
1. Trocar o nome **Ping → Mensagens** (visível; rotas/ids/classes `ping-*` NÃO mudaram).
2. Colocar funções dentro de Mensagens: **trocar tema, privacidade, sons de notificação** e afins.
3. **Remover a caneta** (FAB) e criar a opção **Criar grupo**.
4. Clicar na própria foto abria umas configurações sem saída → **remover** e **distribuir no menu lateral** (☰), que quase só tinha "Chamadas". Seguir o jeito do Telegram.
5. Fazer em **4 partes**, sempre devolvendo os **2 zips completos**.

## Regras do usuário (respeitar)
Respostas curtas em português do Brasil; edições **cirúrgicas**; entender os **riscos antes**; mudança vale para **site (desktop + celular) E Flutter**; **zips completos** (projeto inteiro); **uma parte por vez**.

## Plano
| # | Escopo | Status |
|---|---|---|
| 1 | Renomear para Mensagens + sem caneta + sem avatar/tela de Configurações + menu lateral (☰) com Nova conversa, Contatos, Chamadas, Arquivadas, privacidade, som e tema | ✅ feita |
| 2 | Configurações dentro de Mensagens (estilo Telegram): painel com Notificações e sons (escolher som + volume), Privacidade, Aparência (tema; Flutter hoje só tem escuro) | ✅ feita (tema claro no Flutter e som por conversa ficaram de fora — ver abaixo) |
| 3 | Grupos — backend: modelos (grupo, membros, papéis), mensagens de grupo, API REST, tempo real, push | ✅ feita (só texto; sem mídia/ligações em grupo) |
| 4 | Grupos — telas site + Flutter (usar a API da parte 3): **Novo grupo** (substitui a caneta; item no menu lateral/botão da lista), conversa de grupo, membros, sair | ✅ feita (só texto) — **as 4 partes estão concluídas** |

## Mais fontes de notícias + Vortex estilo Pinterest (pós-parte 4)
**Fontes**: +64 feeds em `Config.NEWS_DEFAULT_SOURCES` (agora 150, sem URL repetida): 13 feeds **regionais do G1 por estado** (úteis pro mapa do Terrakia/geolocalização), Agência Brasil por editoria, Congresso em Foco/JOTA/Conjur, Estadão por seção, Nexo, Pública, piauí, Aos Fatos, ciência/ambiente (Galileu, FAPESP, ((o))eco, Mongabay…), tecnologia, esportes, entretenimento, saúde e mundo. `seed_default_sources` já é idempotente (por URL): ao subir o app as novas entram sozinhas. **Os feeds NÃO foram testados contra a internet** (ambiente sem rede): feed que não existir só rende 0 artigos (erro tratado em `index_source`); pode desativar no admin.
**Vortex** (site e Flutter): fundo **preto** (inclusive no tema claro), peças com **cantos de 16px** e 8px de respiro, proporção (largura/altura) limitada a **0,48 (1:2,1) – 1,78 (16:9)** como no Pinterest; fora disso corta (cover), nunca estica. Site: `--ar` por peça (template pra crawler; `vortex.js::clampRatio` pras peças de usuário), CSS no fim do `style.css` sob `body.pictures-page`. Flutter (NÃO compilado): `PinFrame`/`pinRatio` em `vortex_tile_card.dart`, usados em `VortexTileCard` e `_VortexTile`; telas Vortex/busca/detalhe com `backgroundColor: Colors.black`. `sw.js` v46.

## Anexo estilo Telegram + câmera ao vivo + servidor configurável (pós-parte 4)
Pedido: botão de áudio quando o campo está vazio; ao anexar foto/vídeo abrir popup com galeria + câmera em tempo real (como o print do Telegram); corrigir o erro vermelho do login.
**Erro vermelho**: não era bug de código — o app usava `http://192.168.15.84:5000` fixo e o celular estava em 4G (IP local inalcançável) / Flask sem `host=0.0.0.0` / firewall. Agora `kApiBaseUrl` é variável salva no aparelho (`loadApiBaseUrl` no `main`, `saveApiBaseUrl`), a tela de login mostra o servidor com **Alterar**, o login tem timeout de 15 s e a mensagem explica as causas.
**Flutter** (NÃO compilado: `flutter pub get`, `analyze`, `test`): `widgets/chat/attach_sheet.dart` (novo; `photo_manager` + `camera`): grade 3 colunas, 1º quadrado = câmera ao vivo (toque = foto), miniaturas de fotos/GIFs/vídeos (toque escolhe), abas Galeria/Arquivo/Vídeo; sem permissão ainda dá câmera e arquivo. `message_thread_screen.dart`: `_attach` usa a folha; `_pickImage/_imageFromFile/_videoFromFile` separados. Manifest: `READ_MEDIA_IMAGES/VIDEO`. `pubspec`: `photo_manager ^3.6.4`, `camera ^0.11.0+2`.
**Site**: clipe abre menu (Foto ou vídeo / Câmera / Arquivo); **Câmera** = modal com vídeo ao vivo, foto, gravar vídeo (máx. 2 min), trocar câmera; vai para a mesma prévia (com "visualização única"). Microfone agora aparece sempre com o campo vazio; sem suporte do navegador (http fora de localhost) o toque explica que precisa de HTTPS. `sw.js` v45.
**Limites**: o site não lista a galeria do PC/celular (limite do navegador): usa o seletor do sistema. Câmera/microfone no navegador só funcionam em HTTPS ou localhost. Grupo segue só texto.

## Ajuste de layout (pós-parte 4) — mensagens estilo Telegram (privado e grupo)
Pedido: bolhas, tamanho, hora, campo de digitar e emojis iguais aos prints do Telegram Web, no site (desktop + celular) e no Flutter, em conversa privada E em grupo.
**Site** (`driqy4/`): novo `static/js/emoji-picker.js` (`DriqyEmojiPicker.build`): abas no topo, busca "Buscar Emojis" (palavras pt-BR), seções com título ("Frequentemente Usado"…), barra inferior com apagar. No desktop o painel **flutua** sobre o chat, à direita do campo (fecha clicando fora); no celular fica no lugar do teclado. Privado (`chat-thread.js`) e grupo (`group-thread.js`, agora com botão de emoji) usam o mesmo seletor; botão de emoji virou ícone de linha (não troca mais para ⌨️). Hora/ticks **dentro da bolha, na linha do fim do texto** (classe `cw-inline-meta`; se não couber, desce); largura máx. 480px; fonte 1rem; campo em pílula (placeholder "Mensagem") + botão redondo 48px. CSS no fim do `style.css` (tudo sob `.ping-mode`). `sw.js` **v44**; testes `v43→v44` e novo `tests/test_mensagens_layout.py`. Suíte completa passou.
**Flutter** (`flutter_app/`) — **NÃO compilado**: rodar `flutter pub get`, `flutter analyze`, `flutter test`. `message_bubble.dart`: texto puro com a hora dentro da última linha (Stack + espaço reservado `WidgetSpan`; `_metaRow`/`_metaWidth`), largura máx. min(80%, 480), fonte 16. `group_thread_screen.dart`: campo trocado pelo mesmo `ChatComposer` do privado (pílula, emojis, botão redondo), hora na linha do texto, digitando via listener do controller. `emoji_panel.dart`: cores do Ping, 8 colunas, "Buscar Emojis", barra inferior.
**Limites**: sem abas Figurinhas/GIF do print (não existem no Driqy); grupo segue só texto (sem clipe/áudio); o seletor do Flutter usa o pacote `emoji_picker_flutter` — se `pub get` resolver outra major, conferir `BottomActionBarConfig`/`SearchViewConfig.hintText`; sem título de seção no Flutter (o pacote não oferece).

## Parte 4 — o que foi feito (telas de grupo; site + Flutter)
**Site** (`driqy4/`)
- **Novo grupo** (substitui a caneta): item `#ping-group-open` no menu lateral (☰, logo depois de Nova conversa) → painel `#ping-group-new` na coluna da lista (`_ping_list.html`; nome + busca de pessoas + chips) → `POST /api/v1/groups` → abre `/mensagens/grupo/<id>`. Lógica em `static/js/groups.js`.
- **Seção "Grupos"** (`#ping-groups`) no topo da lista, em todas as páginas de Mensagens e na visão Arquivadas; atualiza ao vivo (evento SSE `group`, com polling de 15 s de reserva). Silenciado/fixado/não lidas aparecem como nas conversas.
- **Conversa de grupo**: rota `chat.group_thread` (`/mensagens/grupo/<id>`, 404 para quem não é membro) + `messages_group.html` + `static/js/group-thread.js`: bolhas com nome do remetente, mensagens de sistema, responder, editar, apagar (autor ou admin), copiar, enviar otimista com reenvio, "digitando…", carregar anteriores, marcar como lida, tempo real.
- **Dados do grupo** (painel estilo Telegram, abre pelo cabeçalho): foto (trocar/remover), nome/descrição, silenciar/fixar/arquivar, participantes (adicionar, remover, tornar/tirar admin), sair do grupo, apagar grupo (dono).
- `chat-live.js` agora escuta `group`; `ping-shell.js` ignora `/mensagens/grupo/…` na navegação sem recarregar (antes tratava "grupo" como @usuário) e exporta `window.pingShell.closeDrawer`; CSS no fim do `style.css` (tudo sob `.ping-mode`, exigência do teste da fase 11); `sw.js` **v43**.
- Testes: `tests/test_mensagens_part4.py` (novo); testes antigos ajustados de `v42` → `v43`.

**Flutter** (`flutter_app/`) — **NÃO compilado** (sem SDK): rodar `flutter pub get`, `flutter analyze` e `flutter test`.
- Novos: `models/chat_group.dart`, `services/group_service.dart`, `widgets/group_avatar.dart`, `screens/new_group_screen.dart` (também serve de "adicionar participantes"), `screens/group_thread_screen.dart`, `screens/group_info_screen.dart`, `test/chat_group_test.dart`.
- `messages_inbox_screen.dart`: item **Novo grupo** no menu lateral; seção **GRUPOS** no topo da lista (toque abre; toque longo fixa/silencia/arquiva); em tela larga abre no painel direito; não lidas de grupo entram no selo da pílula e no som de mensagem nova; falha ao carregar grupos não derruba a lista de conversas.
- Push: `main.dart` trata `group_message` (abre o grupo); `push_notification_service.dart` usa o canal de mensagens também para `group_message`.

**Limites (dizer ao usuário)**
- Grupos continuam **só texto** (sem foto/áudio/vídeo/arquivo, sem chamadas em grupo, sem "lido por", sem link de convite).
- Tema claro do Flutter e som por conversa seguem de fora (parte 2).
- Flutter não foi compilado aqui; o site passou na suíte de testes.

## Parte 3 — o que foi feito (backend de grupos; site/Flutter NÃO mudaram)
- Tabelas novas (criadas pelo `db.create_all`, nada de ALTER; `messages` do chat 1-para-1 **não mudou**): `chat_groups`, `chat_group_members` (papel owner|admin|member, `start_after_id` = quem entra depois não vê o histórico, `last_read_id`, fixar/silenciar/arquivar por pessoa), `chat_group_messages` (kind text|system, resposta, `client_id` idempotente, editar/apagar para todos).
- API em `chat_groups.py` (rotas em `api_bp`, `/api/v1/groups…`; Bearer do app OU sessão do site com `X-Requested-With: fetch`; quem não é membro recebe 404): criar `{name, description?, members:[@]}`; listar (`?arquivadas=1`; devolve `groups` + `archived_count`, já com `unread`, `last_message`, `last_preview`, `prefs`, `my_role`, fixados primeiro); detalhes+membros; editar nome/descrição (admin); apagar (dono); foto `POST/DELETE /avatar` (admin); `POST /members {usernames}` (admin); `DELETE /members/<user>` (dono remove qualquer um, admin só membro); `PUT /members/<user> {role}` (dono); `POST /leave` (dono que sai passa o grupo ao admin/membro mais antigo; o último a sair apaga o grupo); mensagens `GET ?before=&limit= | ?after=`, `POST {content, reply_to_id?, client_id?}`, `PUT/DELETE /messages/<id>` (editar: autor na janela; apagar: autor na janela ou admin); `POST /read {up_to_id?}`; `PUT /prefs {pinned,muted,archived}` (fixar até `CHAT_MAX_PINNED`=3 **grupos**, contado à parte das conversas); `POST /typing {state}`.
- Mensagens de sistema (kind=system, texto pronto em português): criou o grupo, adicionou, removeu, saiu, mudou nome/foto, tornou administrador.
- **Tempo real**: evento SSE novo `group` no mesmo `/api/v1/messages/stream`, com `group_id` e `kind` = message | update (`sub`: edit|delete) | members | info | prefs | read | removed | typing; sem corpo, o cliente rebusca. O `chat-live.js` do site só escuta uma lista fixa de eventos: **na parte 4, incluir `group`** (o Flutter já recebe tudo como `ChatEvent` de tipo `group`, `partner` nulo).
- **Push**: `data.type = "group_message"` (+ `group_id`, `unread_count`), título = nome do grupo, corpo = "Fulano: texto"; mesmo canal `driqy_messages`; tag por grupo (`push.py`). Silenciado não recebe. **Parte 4 (Flutter): tratar o toque na notificação `group_message` (abrir o grupo).**
- Config nova: `GROUP_MAX_MEMBERS = 200`. `grupo` e `grupos` entraram em `RESERVED_USERNAMES` (a página do grupo será `/mensagens/grupo/<id>`).
- Testes: `tests/test_mensagens_part3.py` (22). Suíte completa passou.
- **Decisões/limites**: só texto (sem foto/áudio/vídeo/arquivo em grupo); sem "lido por" por mensagem (só contagem de não lidas por pessoa); sem chamadas em grupo; qualquer usuário não banido pode ser adicionado (sem convite/aprovação); sem link de convite.

## Parte 2 — o que foi feito
**Site** (`driqy4/`)
- Painel **Configurações** (`templates/_ping_settings.html`), incluído em `ping_base.html` dentro da coluna da lista: no desktop cobre só a coluna da lista (como no Telegram Web); no celular ocupa a tela. Abre pelo item **Configurações** do menu lateral (`#ping-settings-open`) ou por `/mensagens/#configuracoes` (a rota antiga `/mensagens/configuracoes` agora redireciona para lá). Seta ← volta (subtela → início → fecha); Esc também.
- Início: foto grande, nome, "online", @usuário (leva a Editar perfil), linhas **Notificações e sons**, **Privacidade e segurança**, **Aparência**, Voltar para o Driqy, Sair da conta.
- **Notificações e sons**: interruptor `#setting-sound`, som da mensagem (**Padrão** = `message.mp3`, **Ding**, **Pop**; toca prévia ao escolher) e **volume** (`#setting-volume`). Guardado no navegador (`driqy-msg-sound-choice`, `driqy-msg-volume`); `settings.js` (`driqySettings.messageChoice/messageVolume/previewMessageSound/_playChoice/_playDing`) usa isso em `playMessageSound`.
- **Privacidade e segurança**: `#chat-privacy-toggle` (continua tratado pelo `chat.js`, PUT na API). **Aparência**: botões `.theme-option` (tratados pelo `settings.js`).
- O menu lateral perdeu o bloco de configurações rápidas (ficou só atalhos + item Configurações). CSS novo no fim do `style.css` (`.ping-settings`, `.ping-set-*`); regras mortas do menu removidas. `sw.js` `v42`.
- Testes: `tests/test_mensagens_part2.py` (novo); ajustados `test_ping_phase8.py` (redirect) e os que citavam `v41`. Suíte completa passou (≈533).

**Flutter** (`flutter_app/`) — **NÃO compilado** (sem SDK): rodar `flutter pub get`, `flutter analyze` e `flutter test`.
- `screens/messages_settings_screen.dart` (novo): tela estilo Telegram (foto, nome, @, Notificações e sons, Privacidade e segurança). Menu lateral agora tem **Configurações** (saiu o switch solto e "Editar perfil", que foi para dentro da tela).
- `services/messages_prefs.dart` (novo, `ChangeNotifier` + `SharedPreferences`): som ligado/desligado (**começa desligado**, como no site), som escolhido e volume; toca com `just_audio`. Assets novos em `assets/sounds/` (`message.mp3`, `ding.wav`, `pop.wav`; `pubspec.yaml` ganhou a pasta).
- Som de mensagem nova: `messages_inbox_screen.dart` (`_load`) toca quando o total de não lidas (sem silenciadas/arquivadas) sobe numa atualização ao vivo — mesma ideia do site. Só toca com a lista de Mensagens aberta.
- Teste novo: `test/messages_prefs_test.dart`.

**Limites desta parte (dizer ao usuário)**
- **[RESOLVIDO depois: tema claro no app inteiro entrou na Parte 9B do `PROGRESSO_VORTEX.md`; o interruptor fica em Mensagens › Notificações e sons › Aparência — Flutter ainda sem compilar]** ~~Tema no Flutter não foi feito~~: o app só tem `ThemeData` escuro (`AppTheme.dark`, cores `AppColors` fixas). Tema claro/escuro exige criar `AppTheme.light` e trocar `AppColors` fixas por cores de tema no app inteiro — decidir se vale fazer.
- **Som por conversa**: já existe **Silenciar** por conversa (fase 10); escolher um som diferente por conversa não foi feito. No Android, o som com o app fechado é do canal de notificação do sistema.
- **"Novo grupo"** continua para as partes 3 e 4 (backend primeiro).

## Parte 1 — o que foi feito
**Site** (`driqy4/`)
- Nome: "Ping" → "Mensagens" em cabeçalho, títulos de aba, `aria-label`s, item da sidebar e barra inferior do Driqy (`base.html`), `apple-mobile-web-app-title`. URL segue `/mensagens`.
- **Caneta removida** (`.ping-fab`). O painel de busca de pessoas (`#ping-new`) agora abre pelo item **Nova conversa** do menu lateral (`#ping-new-open`).
- **Foto de perfil** (`.ping-me`) removida da barra de busca. **Tela de Configurações removida** (`ping_settings.html` apagado); `/mensagens/configuracoes` só **redireciona** para `/mensagens/` (links antigos; segue em `RESERVED_USERNAMES`).
- **Menu lateral** novo `templates/_ping_drawer.html`, incluído em `ping_base.html` **fora** do `.ping-shell` (no celular a coluna da lista some em Contatos/Chamadas). Abre pelo ☰ da busca (agora igual no desktop e celular) e pela aba **Menu** da pílula. Itens: perfil no topo, Nova conversa, Contatos, Chamadas, Arquivadas (n); Configurações rápidas: privacidade (`#chat-privacy-toggle`, tratado pelo `chat.js`), som (`#setting-sound`) e tema (`.theme-option`, tratados pelo `settings.js`); Editar perfil, Voltar para o Driqy, Sair. Ids `chat-*` preservados (o `chat.js` atualiza contagem de arquivadas/privacidade).
- Pílula do celular: **Chats, Contatos, Chamadas, Menu** (saíram Configurações e Perfil). Chamadas ganhou `ping-tabpage`/`ping_tab="calls"`.
- JS: `ping-shell.js` (abrir/fechar menu, Esc, toque fora, foco), `ping-pages.js` (removido o bloco de configurações). CSS: bloco novo no fim do `style.css`; regras do FAB/avatar/menu antigo removidas. `sw.js` `v41`.
- Testes: `tests/test_mensagens_part1.py` (novo); testes antigos das fases do Ping ajustados (v41, pílula, FAB, avatar). Suíte completa: **523 passaram, 3 skipped**.

**Flutter** (`flutter_app/`) — **NÃO compilado** (sem SDK): rodar `flutter analyze` e `flutter test`.
- Rótulos "Mensagens" (`ping_app_bar.dart`, `home_shell.dart`, `driqy_top_bar.dart`; canal Android renomeado, **id `driqy_messages` igual**).
- `messages_inbox_screen.dart`: sem FAB e sem `_meAvatar`; ☰ ao lado da busca abre `Drawer` (`_buildDrawer`) com perfil, Nova conversa, Contatos, Chamadas, Arquivadas, switch de "Mostrar online e visto por último", Editar perfil, Voltar para o Driqy.
- `ping_tab_bar.dart`: abas Chats, Contatos, Chamadas, Menu (`PingTab { chats, contacts, calls }`; callbacks `onCalls`/`onMenu`). `ping_nav.dart`: `PingMenuSignal` (aba Menu em Contatos volta para a lista e abre o menu). `ping_settings_screen.dart` **apagado**. Testes `ping_tab_bar_test.dart`/`ping_polish_test.dart` ajustados.

**Decisões / limites (dizer ao usuário)**
- Sem a caneta, **começar conversa** = "Nova conversa" no menu lateral, Contatos ou botão "Mensagem" do perfil. **"Novo grupo" só entra na parte 3/4** (precisa de backend; não deixei botão morto).
- Flutter: **[resolvido: som na Parte 2, tema claro na Parte 9B do Vortex]** ~~tema e som ainda não existem no app~~ (só tema escuro, sem opção de som) → entram na parte 2. **Sair da conta** não foi colocado no menu do Flutter (a pilha de rotas do Mensagens ficaria por cima do login); o site tem.
- Pendências herdadas: o `PROGRESSO_PING.md` ainda cita "Ping"/tela de Configurações nas fases antigas (histórico; vale o que está aqui).
