"""
Armazenamento organizado dos arquivos enviados pelos usuários.

Estrutura dentro de UPLOAD_FOLDER (instance/uploads):

    avatars/                 fotos de perfil
    covers/                  capas de perfil
    flashes/AAAA/MM/         Flashes (stories de 24h)
    posts/AAAA/MM/           mídia dos posts, por mês de publicação
    chat/AAAA/MM/            mídia de mensagens diretas (PRIVADA — ver api.py)

O banco guarda o caminho RELATIVO com barras "/" (ex.: "posts/2026/10/ab12.jpg").
Arquivos antigos, guardados só pelo nome (sem "/"), continuam na raiz de
UPLOAD_FOLDER e seguem funcionando — `delete_upload` e a rota /uploads/<path>
tratam os dois formatos.
"""
import os
import uuid

from flask import current_app

from models import utcnow


def _subdir(kind):
    if kind == "avatar":
        return "avatars"
    if kind == "cover":
        return "covers"
    now = utcnow()
    if kind == "flash":
        return f"flashes/{now.year:04d}/{now.month:02d}"
    if kind == "chat":
        return f"chat/{now.year:04d}/{now.month:02d}"
    return f"posts/{now.year:04d}/{now.month:02d}"


def save_upload(file, kind, ext, prefix=None):
    """Salva `file` na subpasta do tipo (avatar | cover | post) e devolve o
    caminho relativo (com "/") para gravar no banco."""
    name = f"{prefix + '_' if prefix else ''}{uuid.uuid4().hex}.{ext}"
    rel = f"{_subdir(kind)}/{name}"
    full = os.path.join(current_app.config["UPLOAD_FOLDER"], *rel.split("/"))
    os.makedirs(os.path.dirname(full), exist_ok=True)
    file.save(full)
    return rel


def delete_upload(rel):
    """Apaga um arquivo enviado (formato novo ou antigo). Nunca sai de
    UPLOAD_FOLDER e ignora erros de disco. Remove a subpasta se ficar vazia."""
    if not rel:
        return
    root = os.path.realpath(current_app.config["UPLOAD_FOLDER"])
    full = os.path.realpath(os.path.join(root, *rel.split("/")))
    if not full.startswith(root + os.sep):
        return
    try:
        if os.path.isfile(full):
            os.remove(full)
    except OSError:
        return
    folder = os.path.dirname(full)
    while folder != root and folder.startswith(root + os.sep):
        try:
            os.rmdir(folder)  # só funciona se estiver vazia
        except OSError:
            break
        folder = os.path.dirname(folder)
