"""Sugestões de quem seguir (Parte 2 do layout).

Pontuação por candidato (tudo calculado com poucas consultas):
  +4 já segue você (seguir de volta) · +3 por conta que você segue e que o segue (máx. 4 contas)
  +2 mesma cidade · +1 verificado · +1 ativo nos últimos 7 dias · +1 tem posts no ar
  + pequeno desempate por popularidade (log dos seguidores) e um embaralhado estável por
  dia/usuário (as sugestões giram sem ficar trocando a cada recarga).
Nunca sugere: você mesmo, quem você já segue, banidos.
"""
import math
import random
from datetime import timedelta

from extensions import db
from models import Follow, Post, User, utcnow

POOL = 250


def _reason(follows_me, mutuals, same_city, verified):
    if follows_me:
        return "Segue você"
    if mutuals:
        return f"Seguido por {mutuals} conta{'s' if mutuals != 1 else ''} que você segue"
    if same_city:
        return "Da sua cidade"
    if verified:
        return "Em destaque"
    return "Sugestão para você"


def suggest_users(viewer, limit=5, exclude=()):
    limit = max(1, min(int(limit or 5), 20))
    following_ids = {r[0] for r in db.session.query(Follow.followed_id).filter(Follow.follower_id == viewer.id)}
    skip = set(following_ids) | {viewer.id}
    if exclude:
        skip |= {u.id for u in User.query.filter(User.username.in_(list(exclude))).all()}

    now = utcnow()
    week_ago = now - timedelta(days=7)
    pool = (User.query.filter(User.is_banned.is_(False), ~User.id.in_(skip))
            .order_by(User.last_seen_at.is_(None), User.last_seen_at.desc(), User.id.desc())
            .limit(POOL).all())
    if not pool:
        return []
    ids = [u.id for u in pool]

    follows_me = {r[0] for r in db.session.query(Follow.follower_id)
                  .filter(Follow.followed_id == viewer.id, Follow.follower_id.in_(ids))}
    mutual = {}
    if following_ids:
        rows = (db.session.query(Follow.followed_id, db.func.count(Follow.id))
                .filter(Follow.follower_id.in_(following_ids), Follow.followed_id.in_(ids))
                .group_by(Follow.followed_id).all())
        mutual = {uid: n for uid, n in rows}
    fcount = dict(db.session.query(Follow.followed_id, db.func.count(Follow.id))
                  .filter(Follow.followed_id.in_(ids)).group_by(Follow.followed_id).all())
    with_posts = {r[0] for r in db.session.query(Post.user_id)
                  .filter(Post.user_id.in_(ids), Post.expires_at > now).distinct()}

    my_city = (viewer.location or "").strip().lower()
    rng = random.Random(f"{viewer.id}:{now.date().isoformat()}")
    scored = []
    for u in pool:
        m = mutual.get(u.id, 0)
        same_city = bool(my_city) and (u.location or "").strip().lower() == my_city
        recent = bool(u.last_seen_at and u.last_seen_at > week_ago)
        score = (4 if u.id in follows_me else 0) + 3 * min(m, 4) + (2 if same_city else 0) \
            + (1 if u.is_verified else 0) + (1 if recent else 0) + (1 if u.id in with_posts else 0) \
            + math.log1p(fcount.get(u.id, 0)) * 0.3 + rng.random() * 0.8
        scored.append((score, u, m, same_city))
    scored.sort(key=lambda t: t[0], reverse=True)
    return [{"user": u, "mutuals": m, "follows_you": u.id in follows_me,
             "reason": _reason(u.id in follows_me, m, sc, u.is_verified)}
            for _s, u, m, sc in scored[:limit]]
