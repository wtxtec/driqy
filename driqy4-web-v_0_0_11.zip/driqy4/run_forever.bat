@echo off
REM ============================================================
REM  Driqy - watchdog de reinicio automatico
REM  Mantem o app.py rodando para sempre, reiniciando sozinho
REM  toda vez que ele cair/travar/for fechado por erro.
REM ============================================================

setlocal enabledelayedexpansion

REM --- AJUSTE AQUI: caminho da pasta do projeto Driqy ---
set "PROJECT_DIR=C:\Users\Wandrew\Downloads\driqy4"

REM --- Se voce usa venv, deixe assim (ele ativa sozinho se existir) ---
set "VENV_ACTIVATE=%PROJECT_DIR%\venv\Scripts\activate.bat"

set "LOG_DIR=%PROJECT_DIR%\logs"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

cd /d "%PROJECT_DIR%"

if exist "%VENV_ACTIVATE%" (
    call "%VENV_ACTIVATE%"
)

:loop
echo [%date% %time%] Iniciando Driqy... >> "%LOG_DIR%\watchdog.log"

python app.py >> "%LOG_DIR%\app.log" 2>&1

echo [%date% %time%] Driqy parou (codigo %errorlevel%). Reiniciando em 5s... >> "%LOG_DIR%\watchdog.log"

timeout /t 5 /nobreak >nul
goto loop
