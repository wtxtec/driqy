"""Widget de clima (Parte 2 do layout). Usa o Open-Meteo (grátis, sem chave).

A cidade vem do campo `location` do perfil: primeiro tenta a lista local de cidades
(`geo_lookup.resolve`), depois a geocodificação do Open-Meteo. Resultados ficam em cache
em memória (coordenadas por 7 dias, previsão por WEATHER_CACHE_SECONDS). Falha de rede
nunca derruba a página: devolve `ok: False` com um `reason`.

reason: no_location | not_found | unavailable | disabled
"""
import requests
from flask import current_app

import geo_lookup
from cache import TTLCache

_GEO_CACHE = TTLCache(ttl_seconds=7 * 24 * 3600, max_entries=512)
_WX_CACHE = TTLCache(ttl_seconds=900, max_entries=512)
_GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
_TIMEOUT = 6

# código WMO -> (rótulo em português, chave de ícone para site/app)
_WMO = {
    0: ("Ensolarado", "sun"), 1: ("Poucas nuvens", "sun-cloud"), 2: ("Parcialmente nublado", "sun-cloud"),
    3: ("Nublado", "cloud"), 45: ("Neblina", "fog"), 48: ("Neblina", "fog"),
    51: ("Garoa fraca", "drizzle"), 53: ("Garoa", "drizzle"), 55: ("Garoa forte", "drizzle"),
    56: ("Garoa gelada", "drizzle"), 57: ("Garoa gelada", "drizzle"),
    61: ("Chuva fraca", "rain"), 63: ("Chuva", "rain"), 65: ("Chuva forte", "rain"),
    66: ("Chuva gelada", "rain"), 67: ("Chuva gelada", "rain"),
    71: ("Neve fraca", "snow"), 73: ("Neve", "snow"), 75: ("Neve forte", "snow"), 77: ("Granizo fino", "snow"),
    80: ("Pancadas de chuva", "rain"), 81: ("Pancadas de chuva", "rain"), 82: ("Pancadas fortes", "rain"),
    85: ("Pancadas de neve", "snow"), 86: ("Pancadas de neve", "snow"),
    95: ("Tempestade", "storm"), 96: ("Tempestade com granizo", "storm"), 99: ("Tempestade com granizo", "storm"),
}


def describe_code(code, is_day=True):
    label, icon = _WMO.get(int(code), ("Tempo instável", "cloud"))
    if not is_day and icon == "sun":
        label, icon = "Céu limpo", "moon"
    elif not is_day and icon == "sun-cloud":
        icon = "moon-cloud"
    return label, icon


def _norm_key(text):
    return geo_lookup._normalize(text)


def _local_city(location_text):
    """Casa só por NOME de cidade (aliases com 3+ letras). `geo_lookup.resolve` também casa
    siglas de estado ("RS", "SP"), o que serve ao mapa do admin, mas aqui faria "Gramado, RS"
    mostrar o clima de Porto Alegre. Vence o alias mais longo."""
    norm = f" {_norm_key(location_text)} "
    best = None
    for aliases, lat, lng, label in geo_lookup._KNOWN_PLACES:
        for alias in aliases:
            if len(alias) > 2 and f" {alias} " in norm and (best is None or len(alias) > best[0]):
                best = (len(alias), (lat, lng, label))
    return best[1] if best else None


def resolve_coords(location_text):
    """(lat, lng, rótulo) ou None. Lista local primeiro; depois geocodificação (com cache)."""
    known = _local_city(location_text)
    if known:
        return known
    key = _norm_key(location_text)
    if len(key) < 3:
        return None
    cached = _GEO_CACHE.get(key)
    if cached is not None:
        return cached or None  # () = já tentamos e não achou
    # só o nome da cidade (antes de vírgula/hífen), em português
    name = (location_text or "").replace("-", ",").split(",")[0].strip() or location_text
    try:
        r = requests.get(_GEOCODE_URL, params={"name": name, "count": 1, "language": "pt", "format": "json"},
                         timeout=_TIMEOUT)
        r.raise_for_status()
        results = (r.json() or {}).get("results") or []
    except Exception:
        return None  # falha de rede: não guarda no cache, tenta de novo depois
    if not results:
        _GEO_CACHE.set(key, ())
        return None
    top = results[0]
    label = ", ".join(x for x in (top.get("name"), top.get("admin1")) if x)
    found = (float(top["latitude"]), float(top["longitude"]), label or name)
    _GEO_CACHE.set(key, found)
    return found


_PLACES_CACHE = TTLCache(ttl_seconds=24 * 3600, max_entries=512)


def parse_coords(lat, lng):
    """(lat, lng) como floats válidos ou None."""
    try:
        la, lo = float(lat), float(lng)
    except (TypeError, ValueError):
        return None
    if not (-90 <= la <= 90 and -180 <= lo <= 180) or la != la or lo != lo:
        return None
    return la, lo


def apply_profile_location(user, text, lat, lng):
    """Grava a localização do perfil. Coordenadas só valem junto de um texto e vêm da sugestão escolhida;
    se o texto mudou sem coordenadas novas (digitado à mão), as antigas são descartadas."""
    text = (text or "").strip()[:80]
    coords = parse_coords(lat, lng) if text else None
    changed = text != (user.location or "")
    user.location = text
    if coords:
        user.location_lat, user.location_lng = coords
    elif changed or not text:
        user.location_lat = user.location_lng = None


def place_label(name, admin1=None, country=None, max_len=80):
    """"Gramado, Rio Grande do Sul, Brasil" (sem repetir partes iguais), cabendo em `User.location`."""
    parts = []
    for x in (name, admin1, country):
        x = (x or "").strip()
        if x and x.lower() not in [p.lower() for p in parts]:
            parts.append(x)
    label = ", ".join(parts)
    if len(label) > max_len:  # tira o país, depois o estado, para caber
        label = ", ".join(parts[:2])
    return label[:max_len]


def _fallback_places(query, limit):
    """Sem rede: sugere cidades da lista local (nome começa/contém o que foi digitado)."""
    q = _norm_key(query)
    out = []
    for aliases, lat, lng, label in geo_lookup._KNOWN_PLACES:
        if any(q and q in a for a in aliases if len(a) > 2):
            name, _, uf = label.partition(", ")
            out.append({"id": f"local:{label}", "name": name, "admin1": uf, "country": "Brasil", "country_code": "BR",
                        "latitude": lat, "longitude": lng, "label": place_label(name, uf, "Brasil")})
        if len(out) >= limit:
            break
    return out


def search_places(query, limit=8):
    """Sugestões de cidade para o que o usuário digita. Aceita "Gramado, RS" ou "Gramado, Brasil":
    busca pelo primeiro trecho e usa o resto (estado/país) para ordenar. Falha de rede cai na lista local."""
    query = " ".join((query or "").split())[:80]
    if len(_norm_key(query)) < 2:
        return []
    limit = max(1, min(int(limit or 8), 10))
    ckey = (_norm_key(query), limit)
    cached = _PLACES_CACHE.get(ckey)
    if cached is not None:
        return cached
    head, *rest = [p.strip() for p in query.replace(" - ", ",").split(",")]
    hint = _norm_key(" ".join(rest))
    try:
        r = requests.get(_GEOCODE_URL, params={"name": head or query, "count": 20, "language": "pt", "format": "json"},
                         timeout=_TIMEOUT)
        r.raise_for_status()
        results = (r.json() or {}).get("results") or []
    except Exception:
        return _fallback_places(head or query, limit)  # não guarda no cache

    def rank(item):
        # país/estado que casam com o texto digitado sobem; depois as cidades maiores
        hay = _norm_key(" ".join(str(item.get(k) or "") for k in ("admin1", "country", "country_code")))
        hits = sum(1 for w in hint.split() if w and (w in hay.split() or (len(w) > 2 and w in hay)))
        return (-hits, -(item.get("population") or 0))

    results.sort(key=rank)
    out, seen = [], set()
    for it in results:
        coords = parse_coords(it.get("latitude"), it.get("longitude"))
        if not coords or not it.get("name"):
            continue
        label = place_label(it.get("name"), it.get("admin1"), it.get("country"))
        if label in seen:
            continue
        seen.add(label)
        out.append({"id": str(it.get("id") or label), "name": it["name"], "admin1": it.get("admin1") or "",
                    "country": it.get("country") or "", "country_code": it.get("country_code") or "",
                    "latitude": coords[0], "longitude": coords[1], "label": label})
        if len(out) >= limit:
            break
    _PLACES_CACHE.set(ckey, out)
    return out


def fetch_weather(lat, lng):
    key = (round(lat, 2), round(lng, 2))
    cached = _WX_CACHE.get(key)
    if cached:
        return cached
    r = requests.get(_FORECAST_URL, params={
        "latitude": lat, "longitude": lng, "timezone": "auto", "forecast_days": 1,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
    }, timeout=_TIMEOUT)
    r.raise_for_status()
    data = r.json() or {}
    cur = data.get("current") or {}
    daily = data.get("daily") or {}

    def first(name):
        v = daily.get(name) or []
        return v[0] if v else None

    is_day = bool(cur.get("is_day", 1))
    label, icon = describe_code(cur.get("weather_code", 3), is_day)
    out = {
        "temperature": _round(cur.get("temperature_2m")),
        "feels_like": _round(cur.get("apparent_temperature")),
        "humidity": _round(cur.get("relative_humidity_2m")),
        "wind_kmh": _round(cur.get("wind_speed_10m")),
        "condition": label, "icon": icon, "is_day": is_day,
        "temp_max": _round(first("temperature_2m_max")),
        "temp_min": _round(first("temperature_2m_min")),
        "rain_chance": _round(first("precipitation_probability_max")),
    }
    _WX_CACHE.set(key, out)
    return out


def _round(v):
    return None if v is None else int(round(v))


def weather_for_user(user, override=None):
    """[override] = (lat, lng, rótulo) escolhido no widget ("trocar a região"); vence a cidade do perfil.
    Sem override: coordenadas salvas no perfil (escolhidas nas sugestões) e, por último, o texto."""
    if not current_app.config.get("WEATHER_ENABLED", True):
        return {"ok": False, "reason": "disabled"}
    if override:
        lat, lng, label = override
    else:
        text = (user.location or "").strip()
        saved = parse_coords(getattr(user, "location_lat", None), getattr(user, "location_lng", None))
        if saved and text:
            lat, lng, label = saved[0], saved[1], text
        elif not text:
            return {"ok": False, "reason": "no_location"}
        else:
            coords = resolve_coords(text)
            if not coords:
                return {"ok": False, "reason": "not_found", "location": text}
            lat, lng, label = coords
    try:
        data = fetch_weather(lat, lng)
    except Exception:
        return {"ok": False, "reason": "unavailable", "location": label}
    return {"ok": True, "location": label, "custom": bool(override), **data}
