from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, abort
from flask_login import login_required, current_user
from sqlalchemy import or_, and_, func

from extensions import db
from models import ChatGroup, ChatGroupMember, User, Message, Follow, to_brasilia, utcnow, not_hidden_for
from push import send_push_to_user
from chat_events import notify_one
import chat_extras as cx
from flask import current_app

chat_bp = Blueprint("chat", __name__, url_prefix="/mensagens")


def _partner_ids_for(user_id):
    """IDs de todo mundo com quem `user_id` já trocou pelo menos uma mensagem."""
    sent_to = db.session.query(Message.recipient_id).filter(Message.sender_id == user_id)
    received_from = db.session.query(Message.sender_id).filter(Message.recipient_id == user_id)
    ids = {row[0] for row in sent_to.union(received_from).all()}
    ids.discard(user_id)
    return ids


def _conversation_query(user_a_id, user_b_id, viewer_id=None):
    """Conversa entre dois usuários. Com `viewer_id`, tira o que ele apagou \"para mim\"."""
    q = Message.query.filter(
        or_(
            and_(Message.sender_id == user_a_id, Message.recipient_id == user_b_id),
            and_(Message.sender_id == user_b_id, Message.recipient_id == user_a_id),
        )
    )
    return q.filter(not_hidden_for(viewer_id)) if viewer_id else q


def _build_conversations(viewer, archived):
    """Conversas do site (Fase 10: com fixar/silenciar/arquivar e presença).
    Devolve (lista ordenada, quantidade de arquivadas)."""
    prefs = cx.prefs_map(viewer.id)
    sse_on = current_app.config.get("CHAT_SSE_ENABLED", True)
    items, archived_count = [], 0
    ids = _partner_ids_for(viewer.id)
    if ids:
        for partner in User.query.filter(User.id.in_(ids)).all():
            last_msg = (
                _conversation_query(viewer.id, partner.id, viewer.id)
                .order_by(Message.created_at.desc())
                .first()
            )
            if last_msg is None:
                continue
            pref = prefs.get(partner.id)
            if pref is not None and pref.archived:
                archived_count += 1
            if bool(pref and pref.archived) != archived:
                continue
            unread = _conversation_query(partner.id, viewer.id, viewer.id).filter(
                Message.sender_id == partner.id, Message.is_read.is_(False)
            ).count()
            items.append({
                "partner": partner,
                "last_message": last_msg,
                "unread": unread,
                "prefs": cx.serialize_prefs(pref),
                "presence": cx.presence_payload(partner, viewer, sse_on),
                "_last": last_msg.created_at,
                "_pinned_at": pref.pinned_at if pref is not None else None,
            })
    return cx.sort_conversations(items), archived_count


@chat_bp.route("/")
@login_required
def inbox():
    """Lista de conversas: fixadas primeiro, depois a mais recente. `?arquivadas=1` mostra o arquivo."""
    archived = request.args.get("arquivadas") in ("1", "true")
    conversations, archived_count = _build_conversations(current_user, archived)
    return render_template(
        "messages_inbox.html", conversations=conversations,
        archived_view=archived, archived_count=archived_count,
    )


def _ping_list_ctx():
    """Contexto da coluna de conversas do Ping (fase 3): thread e chamadas também a mostram
    (desktop: lista à esquerda + painel à direita). Custo: monta a lista a cada abertura —
    a fase 6 (abrir conversa sem recarregar) elimina isso."""
    conversations, archived_count = _build_conversations(current_user, False)
    return {"conversations": conversations, "archived_view": False, "archived_count": archived_count}


def _ping_contacts(viewer, tab):
    """Fase 8: quem eu sigo (`seguindo`) ou quem me segue (`seguidores`), sem banidos, A→Z."""
    if tab == "seguidores":
        q = User.query.join(Follow, Follow.follower_id == User.id).filter(Follow.followed_id == viewer.id)
    else:
        q = User.query.join(Follow, Follow.followed_id == User.id).filter(Follow.follower_id == viewer.id)
    return q.filter(User.is_banned.is_(False)).order_by(User.username.asc()).limit(300).all()


@chat_bp.route("/contatos")
@login_required
def contacts():
    """Fase 8: tela Contatos do Ping (seguindo / seguidores → abrir conversa)."""
    tab = "seguidores" if request.args.get("aba") == "seguidores" else "seguindo"
    return render_template(
        "ping_contacts.html", ping_tab="contacts", tab=tab, users=_ping_contacts(current_user, tab),
        following_count=current_user.following_count, followers_count=current_user.followers_count,
        **_ping_list_ctx(),
    )


@chat_bp.route("/configuracoes")
@login_required
def settings():
    """As configurações agora são um painel dentro de Mensagens (menu ☰ → Configurações).
    Esta rota só leva para a lista com o painel aberto (#configuracoes), p/ não quebrar links antigos."""
    return redirect(url_for("chat.inbox") + "#configuracoes")


@chat_bp.route("/chamadas")
@login_required
def calls_history():
    """Fase 14: histórico de chamadas (a lista vem de `GET /api/v1/calls`, via JS)."""
    return render_template("calls_history.html", ping_tab="calls", **_ping_list_ctx())


@chat_bp.route("/grupo/<int:group_id>")
@login_required
def group_thread(group_id):
    """Parte 4: conversa de grupo. Os dados vêm de /api/v1/groups/<id> (group-thread.js).
    Quem não é membro recebe 404 (igual a grupo inexistente)."""
    me = ChatGroupMember.query.filter_by(group_id=group_id, user_id=current_user.id).first_or_404()
    group = db.session.get(ChatGroup, group_id)
    if group is None:
        abort(404)
    return render_template("messages_group.html", group=group, my_role=me.role,
                           active_group_id=group.id, **_ping_list_ctx())


@chat_bp.route("/<username>")
@login_required
def thread(username):
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == current_user.id:
        flash("Você não pode enviar mensagens para si mesmo.", "info")
        return redirect(url_for("chat.inbox"))

    messages = (
        _conversation_query(current_user.id, partner.id, current_user.id)
        .order_by(Message.created_at.asc())
        .all()
    )

    # marca como lidas as mensagens que o parceiro enviou para mim
    unread_ids = [m.id for m in messages if m.recipient_id == current_user.id and not m.is_read]
    # Ping 6b: o JS abre na 1ª não lida e mostra o contador no botão ↓ (já estarão lidas quando ele buscar)
    first_unread_id = unread_ids[0] if unread_ids else 0
    unread_count = len(unread_ids)
    if unread_ids:
        _now = utcnow()
        Message.query.filter(Message.id.in_(unread_ids)).update(
            {"is_read": True, "read_at": _now, "delivered_at": db.func.coalesce(Message.delivered_at, _now)},
            synchronize_session=False,
        )
        db.session.commit()
        notify_one(partner, current_user, "read")        # ✓✓ azul ao vivo para quem enviou
        notify_one(current_user, partner, "read_self")   # selo de não lidas nas minhas outras abas

    last_id = messages[-1].id if messages else 0
    if request.headers.get("X-Ping-Fragment"):
        # Fase 6a: só o miolo da conversa (a lista da esquerda já está na tela → não monta de novo)
        return render_template("_ping_thread_main.html", partner=partner, messages=messages, last_id=last_id,
                               first_unread_id=first_unread_id, unread_count=unread_count)
    return render_template(
        "messages_thread.html", partner=partner, messages=messages, last_id=last_id,
        first_unread_id=first_unread_id, unread_count=unread_count,
        **_ping_list_ctx(),  # depois do commit acima: contadores de não lidas já atualizados
    )


@chat_bp.route("/api/contagem")
@login_required
def unread_count():
    """Usado pelo ícone de mensagens no topo, igual ao sino de notificações."""
    return jsonify({"unread": current_user.unread_messages_count})


@chat_bp.route("/api/atualizacoes")
@login_required
def inbox_updates():
    """Usado pela caixa de entrada para atualizar prévias/contadores sem recarregar.
    `?arquivadas=1` atualiza a lista do arquivo."""
    archived = request.args.get("arquivadas") in ("1", "true")
    # já vem ordenada (fixadas primeiro): o html de cada linha casa com o seu partner_id
    conversations, archived_count = _build_conversations(current_user, archived)
    data = []
    for conv in conversations:
        last_msg = conv["last_message"]
        data.append({
            "partner_id": conv["partner"].id,
            "last_content": last_msg.content,
            "last_created_at": to_brasilia(last_msg.created_at).strftime("%d/%m/%Y %H:%M"),
            "last_sender_id": last_msg.sender_id,
            "unread": conv["unread"],
            "pinned": conv["prefs"]["pinned"],
            "muted": conv["prefs"]["muted"],
            "html": render_template("_chat_inbox_row_fragment.html", conv=conv),
        })

    return jsonify({
        "conversations": data,
        "total_unread": current_user.unread_messages_count,
        "archived_count": archived_count,
    })
