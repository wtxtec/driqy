# Backend Flask — push notifications (FCM)

Toda a implementação já está pronta no backend (`push.py`, tabela
`DeviceToken` em `models.py`, rotas `/api/v1/devices/register` e
`/api/v1/devices/unregister` em `api.py`, disparo automático nas
curtidas/comentários/seguidas em `models.py` e nas mensagens em
`api.py`/`chat.py`). **Só falta uma coisa pra push funcionar de
verdade: a chave de serviço do Firebase.**

## 1. Instalar o Admin SDK do Firebase

Já está em `requirements.txt` (`firebase-admin==6.5.0`). Se o
ambiente já estava instalado antes dessa mudança, rode:

```bash
pip install -r requirements.txt
```

## 2. Baixar a chave de serviço (Service Account)

No Firebase Console → engrenagem (⚙) → **Configurações do projeto** →
aba **Contas de serviço** → **Gerar nova chave privada**. Isso baixa um
`.json`.

Salve esse arquivo em:

```
instance/firebase-service-account.json
```

(já está no `.gitignore`, não vai parar no controle de versão por
engano). Se preferir outro caminho, defina a variável de ambiente
`FIREBASE_SERVICE_ACCOUNT` apontando pro arquivo.

## Como funciona sem a chave

Sem o arquivo, o backend continua funcionando 100% normal — curtidas,
comentários, seguidas e mensagens continuam sendo salvos e aparecendo
na aba Notificações/Mensagens do app (via polling). Só o *push* (o
alerta que aparece na bandeja do celular, mesmo com o app fechado)
fica desativado, e o servidor imprime um aviso no log na primeira
tentativa, sem quebrar nada.

## Como testar depois de colocar a chave

1. Reinicie o Flask.
2. No app Flutter, faça login (isso já registra o token do aparelho
   automaticamente via `PushNotificationService.registerDeviceToken`,
   chamado no `main.dart`).
3. Peça pra outra conta seguir/curtir/comentar/mandar mensagem pra essa
   conta, ou faça isso pelo site.
4. A notificação deve aparecer na bandeja do celular — inclusive com
   o app minimizado ou fechado.

Se não aparecer, confira o log do Flask por uma linha começando com
`[push]` — ela explica o motivo (chave ausente, token inválido,
pacote não instalado etc.).
