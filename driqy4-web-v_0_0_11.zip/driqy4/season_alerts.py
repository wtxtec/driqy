"""Avisos de virada de estação: 3 dias antes (e nos dias seguintes, se o servidor estava parado) e no dia.

- Chega como notificação (sino do site e lista do app, tipo "season") e como push no celular.
- Cada aviso é enviado uma única vez por usuário (tabela `season_alerts`), mesmo se o servidor reiniciar.
- O nome da estação respeita o hemisfério do usuário (localização do perfil; sem ela, hemisfério sul).
- Roda de hora em hora (ver `scheduler.py`). O aviso sai a partir das 8h NO FUSO DO USUÁRIO (`User.tz_name`, guardado
  quando o site abre os widgets; sem ele, Brasília), então um aviso nunca acorda ninguém.
"""
from datetime import datetime, timezone

import widgets_extra

ALERT_FROM_HOUR = 8     # hora (Brasília) em que os avisos do dia podem sair
DAYS_BEFORE = 3         # "faltam 3 dias"


def _tzinfo_for(name):
    return widgets_extra.user_tzinfo(name) if name else None


def pending_events(now=None, tzinfo=None):
    """Viradas que merecem aviso agora: [(chave, tipo, dias, k, data_local)].

    `tipo` é "pre" (de 1 a 3 dias antes; um só aviso por virada) ou "day" (a virada é hoje, no fuso `tzinfo`;
    sem ele, Brasília). A chave usa SEMPRE a data da virada em Brasília + o tipo, igual para todos os fusos (e
    igual à que já está salva no banco); `data_local` é a data no fuso do usuário, para o texto do aviso.
    """
    now = now or datetime.now(timezone.utc)
    today = widgets_extra.today_in(now, tzinfo)
    out = []
    for dt, k in widgets_extra.season_transitions(now):
        day = widgets_extra._brt(dt, tzinfo).date()
        key_day = widgets_extra._brt(dt).date()
        n = (day - today).days
        if n == 0:
            out.append((f"{key_day.isoformat()}:day", "day", 0, k, day))
        elif 1 <= n <= DAYS_BEFORE:
            out.append((f"{key_day.isoformat()}:pre", "pre", n, k, day))
    return out


def alert_text(kind, days, k, day, hemisphere):
    """(título do push, texto da notificação)."""
    name = widgets_extra._SEASON_NAMES[hemisphere][k]
    emoji = widgets_extra.SEASON_EMOJI[name]
    art = "a" if name == "Primavera" else "o"
    if kind == "day":
        return f"{emoji} {name}", f"{emoji} Hoje começa {art} {name}! Veja o progresso no widget Estações."
    when = "amanhã" if days == 1 else f"em {days} dias"
    return f"{emoji} {name} chegando", f"{emoji} {name} começa {when} ({day.strftime('%d/%m')}). Veja o progresso no widget Estações."


def run_season_alerts(app, now=None, force=False):
    """Cria as notificações pendentes. Devolve quantas foram criadas. `force` ignora a hora mínima (testes)."""
    from extensions import db
    from models import Notification, SeasonAlert, User

    now = now or datetime.now(timezone.utc)
    created, pushes = 0, []
    with app.app_context():
        try:
            # um grupo por fuso guardado (sem fuso = Brasília): hora mínima e viradas são calculadas por grupo
            groups = {}
            names = {n for (n,) in db.session.query(User.tz_name).distinct().all()} | {None}
            for name in names:
                info = _tzinfo_for(name)
                key = getattr(info, "key", None) if info is not None else None
                if key in groups:
                    continue
                if not force and widgets_extra._brt(now, info).hour < ALERT_FROM_HOUR:
                    groups[key] = (info, [])
                else:
                    groups[key] = (info, pending_events(now, info))
            keys = sorted({e[0] for _, evs in groups.values() for e in evs})
            if not keys:
                return 0
            done = {(r.user_id, r.alert_key) for r in SeasonAlert.query.filter(SeasonAlert.alert_key.in_(keys)).all()}
            for user in User.query.yield_per(500):
                info = _tzinfo_for(getattr(user, "tz_name", None))
                events = groups.get(getattr(info, "key", None) if info is not None else None, (None, []))[1]
                hemi = widgets_extra.hemisphere_for(getattr(user, "location_lat", None))
                for key, kind, days, k, day in events:
                    if (user.id, key) in done:
                        continue
                    done.add((user.id, key))
                    title, text = alert_text(kind, days, k, day, hemi)
                    db.session.add(SeasonAlert(user_id=user.id, alert_key=key))
                    db.session.add(Notification(recipient_id=user.id, actor_id=user.id,
                                                kind=Notification.KIND_SEASON, text=text))
                    pushes.append((user.id, title, text))
                    created += 1
            db.session.commit()
        except Exception as exc:  # noqa: BLE001
            db.session.rollback()
            app.logger.warning(f"[estações] falha ao criar avisos: {exc}")
            return 0
        # push só depois de salvar; nunca derruba o agendador (send_push_to_user já engole os erros)
        from push import send_push_to_user
        for uid, title, text in pushes:
            send_push_to_user(uid, title, text, data={"type": "season"})
        if created:
            app.logger.info(f"[estações] {created} aviso(s) de virada de estação enviados.")
    return created
