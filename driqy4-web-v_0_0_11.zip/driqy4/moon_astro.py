"""Astronomia da Lua (Python puro, sem dependências): nascer/pôr da Lua e próximos eclipses.

- Posição da Lua: série abreviada de Jean Meeus (Astronomical Algorithms, cap. 47), erro de alguns
  minutos de arco: de sobra para horários de nascer/pôr (erro típico de 1 a 3 minutos).
- Eclipses: método do cap. 54 do mesmo livro (instante do máximo com erro de ~1 min; tipo pela
  geometria da sombra). Nada de rede: tudo calculado.
"""
import math
from datetime import datetime, timedelta, timezone

_DELTA_T = 69.0  # TD - UT em segundos (2026); muda ~1 s por ano, irrelevante aqui

# (D, M, M', F, soma_l [1e-6 °], soma_r [1e-3 km]) — termos principais da longitude e da distância
_LR = [
    (0, 0, 1, 0, 6288774, -20905355), (2, 0, -1, 0, 1274027, -3699111), (2, 0, 0, 0, 658314, -2955968),
    (0, 0, 2, 0, 213618, -569925), (0, 1, 0, 0, -185116, 48888), (0, 0, 0, 2, -114332, -3149),
    (2, 0, -2, 0, 58793, 246158), (2, -1, -1, 0, 57066, -152138), (2, 0, 1, 0, 53322, -170733),
    (2, -1, 0, 0, 45758, -204586), (0, 1, -1, 0, -40923, -129620), (1, 0, 0, 0, -34720, 108743),
    (0, 1, 1, 0, -30383, 104755), (2, 0, 0, -2, 15327, 10321), (0, 0, 1, 2, -12528, 0),
    (0, 0, 1, -2, 10980, 79661), (4, 0, -1, 0, 10675, -34782), (0, 0, 3, 0, 10034, -23210),
    (4, 0, -2, 0, 8548, -21636), (2, 1, -1, 0, -7888, 24208), (2, 1, 0, 0, -6766, 30824),
    (1, 0, -1, 0, -5163, -8379), (1, 1, 0, 0, 4987, -16675), (2, -1, 1, 0, 4036, -12831),
    (2, 0, 2, 0, 3994, -10445), (4, 0, 0, 0, 3861, -11650), (2, 0, -3, 0, 3665, 14403),
    (0, 1, -2, 0, -2689, -7003), (2, 0, -1, 2, -2602, 0), (2, -1, -2, 0, 2390, 10056),
    (1, 0, 1, 0, -2348, 6322), (2, -2, 0, 0, 2236, -9884),
]
# (D, M, M', F, soma_b [1e-6 °])
_B = [
    (0, 0, 0, 1, 5128122), (0, 0, 1, 1, 280602), (0, 0, 1, -1, 277693), (2, 0, 0, -1, 173237),
    (2, 0, -1, 1, 55413), (2, 0, -1, -1, 46271), (2, 0, 0, 1, 32573), (0, 0, 2, 1, 17198),
    (2, 0, 1, -1, 9266), (0, 0, 2, -1, 8822), (2, -1, 0, -1, 8216), (2, 0, -2, -1, 4324),
    (2, 0, 1, 1, 4200), (2, 1, 0, -1, -3359),
]


def _jd(dt):
    """Dia juliano (UT) de um datetime com fuso."""
    return dt.astimezone(timezone.utc).timestamp() / 86400.0 + 2440587.5


def _from_jd(jd):
    return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(days=jd - 2440587.5)


def moon_position(jd):
    """(longitude eclíptica °, latitude °, distância km) da Lua; [jd] em UT."""
    t = (jd + _DELTA_T / 86400.0 - 2451545.0) / 36525.0
    lp = 218.3164477 + 481267.88123421 * t
    d = math.radians((297.8501921 + 445267.1114034 * t) % 360)
    m = math.radians((357.5291092 + 35999.0502909 * t) % 360)
    mp = math.radians((134.9633964 + 477198.8675055 * t) % 360)
    f = math.radians((93.2720950 + 483202.0175233 * t) % 360)
    e = 1 - 0.002516 * t - 0.0000074 * t * t
    sl = sr = sb = 0.0
    for dd, mm, mmp, ff, cl, cr in _LR:
        arg = dd * d + mm * m + mmp * mp + ff * f
        k = e ** abs(mm)
        sl += cl * k * math.sin(arg)
        sr += cr * k * math.cos(arg)
    for dd, mm, mmp, ff, cb in _B:
        arg = dd * d + mm * m + mmp * mp + ff * f
        sb += cb * (e ** abs(mm)) * math.sin(arg)
    return (lp + sl / 1e6) % 360, sb / 1e6, 385000.56 + sr / 1e3


def moon_altitude(jd, lat, lng):
    """Altura geométrica do centro da Lua (graus) e a altura que conta como nascer/pôr."""
    lon, b, dist = moon_position(jd)
    t = (jd - 2451545.0) / 36525.0
    eps = math.radians(23.4392911 - 0.0130042 * t)
    lam, bet = math.radians(lon), math.radians(b)
    ra = math.atan2(math.sin(lam) * math.cos(eps) - math.tan(bet) * math.sin(eps), math.cos(lam))
    dec = math.asin(math.sin(bet) * math.cos(eps) + math.cos(bet) * math.sin(eps) * math.sin(lam))
    gst = (280.46061837 + 360.98564736629 * (jd - 2451545.0)) % 360
    h_angle = math.radians(gst + lng) - ra
    phi = math.radians(lat)
    alt = math.degrees(math.asin(math.sin(phi) * math.sin(dec) + math.cos(phi) * math.cos(dec) * math.cos(h_angle)))
    par = math.degrees(math.asin(6378.14 / dist))     # paralaxe horizontal
    return alt, 0.7275 * par - 0.5667                 # borda superior, com refração


def moon_rise_set(day, lat, lng, utc_offset_hours=-3):
    """Nascer e pôr da Lua no dia local [day] (date). Devolve {"rise": datetime|None, "set": datetime|None}
    no fuso `utc_offset_hours`. Sem nascer (ou pôr) naquele dia (acontece: a Lua atrasa ~50 min por dia): None."""
    tz = timezone(timedelta(hours=utc_offset_hours))
    start = datetime(day.year, day.month, day.day, tzinfo=tz)
    step = 10 * 60
    prev_t, (alt, h0) = start, moon_altitude(_jd(start), lat, lng)
    prev_v = alt - h0
    out = {"rise": None, "set": None}
    for i in range(1, 24 * 6 + 1):
        t = start + timedelta(seconds=step * i)
        alt, h0 = moon_altitude(_jd(t), lat, lng)
        v = alt - h0
        if prev_v < 0 <= v and out["rise"] is None:
            out["rise"] = prev_t + timedelta(seconds=step * (-prev_v) / (v - prev_v))
        elif prev_v >= 0 > v and out["set"] is None:
            out["set"] = prev_t + timedelta(seconds=step * prev_v / (prev_v - v))
        prev_t, prev_v = t, v
    return out


def moon_is_up(when, lat, lng):
    alt, h0 = moon_altitude(_jd(when), lat, lng)
    return alt >= h0


# ---------------------------------------------------------------- eclipses (Meeus, cap. 54)
def _sin(x): return math.sin(math.radians(x))
def _cos(x): return math.cos(math.radians(x))


def _eclipse_candidate(k):
    """Eclipse da lunação [k] (inteiro = Lua nova/solar, k+0.5 = Lua cheia/lunar) ou None."""
    t = k / 1236.85
    jde = 2451550.09766 + 29.530588861 * k + 0.00015437 * t**2 - 0.00000015 * t**3 + 0.00000000073 * t**4
    e = 1 - 0.002516 * t - 0.0000074 * t**2
    m = 2.5534 + 29.10535670 * k - 0.0000014 * t**2 - 0.00000011 * t**3
    mp = 201.5643 + 385.81693528 * k + 0.0107582 * t**2 + 0.00001238 * t**3 - 0.000000058 * t**4
    f = 160.7108 + 390.67050284 * k - 0.0016118 * t**2 - 0.00000227 * t**3 + 0.000000011 * t**4
    om = 124.7746 - 1.56375588 * k + 0.0020672 * t**2 + 0.00000215 * t**3
    a1 = 299.77 + 0.107408 * k - 0.009173 * t**2
    if abs(_sin(f)) > 0.36:
        return None
    f1 = f - 0.02665 * _sin(om)
    solar = float(k).is_integer()
    c1, c2 = (-0.4075, 0.1721) if solar else (-0.4065, 0.1727)
    corr = (c1 * _sin(mp) + c2 * e * _sin(m) + 0.0161 * _sin(2 * mp) - 0.0097 * _sin(2 * f1)
            + 0.0073 * e * _sin(mp - m) - 0.0050 * e * _sin(mp + m) - 0.0023 * _sin(mp - 2 * f1)
            + 0.0021 * e * _sin(2 * m) + 0.0012 * _sin(mp + 2 * f1) + 0.0006 * e * _sin(2 * mp + m)
            - 0.0004 * _sin(3 * mp) - 0.0003 * e * _sin(m + 2 * f1) + 0.0003 * _sin(a1)
            - 0.0002 * e * _sin(m - 2 * f1) - 0.0002 * e * _sin(2 * mp - m) - 0.0002 * _sin(om))
    p = (0.2070 * e * _sin(m) + 0.0024 * e * _sin(2 * m) - 0.0392 * _sin(mp) + 0.0116 * _sin(2 * mp)
         - 0.0073 * e * _sin(mp + m) + 0.0067 * e * _sin(mp - m) + 0.0118 * _sin(2 * f1))
    q = (5.2207 - 0.0048 * e * _cos(m) + 0.0020 * e * _cos(2 * m) - 0.3299 * _cos(mp)
         - 0.0060 * e * _cos(mp + m) + 0.0041 * e * _cos(mp - m))
    w = abs(_cos(f1))
    gamma = (p * _cos(f1) + q * _sin(f1)) * (1 - 0.0048 * w)
    u = (0.0059 + 0.0046 * e * _cos(m) - 0.0182 * _cos(mp) + 0.0004 * _cos(2 * mp) - 0.0005 * _cos(m + mp))
    g = abs(gamma)
    when = _from_jd(jde + corr - _DELTA_T / 86400.0)   # TD -> UT
    if solar:
        if g > 1.5433 + u:
            return None
        if g < 0.9972:
            if u < 0:
                typ = "total"
            elif u > 0.0047:
                typ = "anular"
            else:
                typ = "total" if u < 0.00464 * math.sqrt(max(0.0, 1 - g * g)) else "anular"
                if typ == "total":
                    typ = "híbrido"
        else:
            typ = "parcial"
        return {"kind": "solar", "type": typ, "when": when, "gamma": round(gamma, 3)}
    if g >= 1.5573 + u:
        return None
    pen_mag = (1.5573 + u - g) / 0.5450
    umb_mag = (1.0128 - u - g) / 0.5450
    typ = "total" if g < 0.4678 - u else ("parcial" if umb_mag > 0 else "penumbral")
    return {"kind": "lunar", "type": typ, "when": when, "gamma": round(gamma, 3),
            "magnitude": round(umb_mag if umb_mag > 0 else pen_mag, 2)}


def next_eclipses(now=None, count=3):
    """Os próximos [count] eclipses (solares e lunares) depois de [now], em ordem de data."""
    now = now or datetime.now(timezone.utc)
    k0 = math.floor((now.year + (now.timetuple().tm_yday - 1) / 365.25 - 2000) * 12.3685) - 2
    found = []
    k = k0
    while len(found) < count and k < k0 + 400:
        for kk in (k, k + 0.5):
            ev = _eclipse_candidate(kk)
            if ev and ev["when"] > now:
                found.append(ev)
        k += 1
    found.sort(key=lambda ev: ev["when"])
    return found[:count]
