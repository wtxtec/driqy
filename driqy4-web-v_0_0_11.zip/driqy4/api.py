"""
API JSON (/api/v1/...) consumida pelo app Flutter (driqy-flutter).

O site principal (main.py, auth.py, chat.py) usa sessão de navegador
(cookies, via Flask-Login) — o app não guarda cookies como um navegador,
então aqui a autenticação é feita por token Bearer (ApiToken), enviado no
header `Authorization: Bearer <token>` em toda chamada que exige login.

Este módulo reaproveita os mesmos modelos e regras de negócio do site
(models.py) e algumas funções auxiliares de main.py (validação de
arquivos, tipo de mídia, etc.), só trocando a saída de HTML para JSON.
"""
import os
import uuid
from datetime import timedelta
from functools import wraps

from flask import Blueprint, Response, request, jsonify, current_app, url_for, g
from werkzeug.utils import secure_filename

from extensions import db
from models import (
    User, Post, PostMedia, Follow, Like, Comment, Notification, Message, MessageReaction,
    MessageHidden, ConversationPref, not_hidden_for,
    ApiToken, NewsArticle, NewsInterest, NewsInteraction, DeviceToken,
    VortexItem, VortexProfile, create_notification, utcnow,
)
from auth import USERNAME_RE
from uploads import save_upload, delete_upload
from news import _build_tiles
from news_recommender import recommended_articles
from push import send_push_to_user
from chat_events import hub, sse, notify_one, notify_pair
import chat_extras as cx
from cache import TTLCache
import vortex_search as vsearch
import vortex_seen as vseen
import vortex_taste as vtaste

api_bp = Blueprint("api_v1", __name__, url_prefix="/api/v1")


# ---------------------------------------------------------------------------
# Autenticação por token
# ---------------------------------------------------------------------------

def _get_token_user():
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None
    token_value = auth_header[7:].strip()
    if not token_value:
        return None
    api_token = ApiToken.query.filter_by(token=token_value).first()
    if api_token is None:
        return None
    api_token.last_used_at = utcnow()
    db.session.commit()
    return api_token.user


def api_login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = _get_token_user()
        if user is None:
            return jsonify({"error": "Não autenticado. Faça login novamente."}), 401
        if user.is_banned:
            return jsonify({"error": "Esta conta foi banida. Contate um administrador."}), 403
        g.api_user = user
        return f(*args, **kwargs)
    return wrapper


def chat_login_required(f):
    """Igual a `api_login_required`, mas também aceita a sessão do navegador
    (cookie do Flask-Login) — é o que o chat do SITE usa. Por não existir
    token CSRF no site, requisições que alteram dados via cookie precisam do
    header `X-Requested-With: fetch` (um site de terceiros não consegue
    enviá-lo sem passar pelo CORS)."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = _get_token_user()
        if user is None and not request.headers.get("Authorization"):
            from flask_login import current_user
            if current_user.is_authenticated:
                unsafe = request.method not in ("GET", "HEAD", "OPTIONS")
                if unsafe and request.headers.get("X-Requested-With") != "fetch":
                    return jsonify({"error": "Requisição inválida."}), 400
                user = current_user._get_current_object()
        if user is None:
            return jsonify({"error": "Não autenticado. Faça login novamente."}), 401
        if user.is_banned:
            return jsonify({"error": "Esta conta foi banida. Contate um administrador."}), 403
        g.api_user = user
        return f(*args, **kwargs)
    return wrapper


def current_api_user():
    """Usuário autenticado da requisição atual, ou None (rotas públicas
    usam isso para personalizar a resposta — ex: is_following/liked_by_me —
    sem exigir login)."""
    return getattr(g, "api_user", None)


# ---------------------------------------------------------------------------
# Serialização
# ---------------------------------------------------------------------------

def _upload_url(filename):
    if not filename:
        return None
    return url_for("serve_upload", filename=filename)


def serialize_user(user, viewer=None):
    return {
        "id": user.id,
        "username": user.username,
        "display_name": user.display_label,
        "bio": user.bio or "",
        "location": user.location or "",
        # coordenadas só para o próprio dono (pré-seleção no editar perfil do app)
        **({"location_lat": user.location_lat, "location_lng": user.location_lng}
           if viewer and viewer.id == user.id else {}),
        "accent_color": user.accent_color or current_app.config["DEFAULT_ACCENT"],
        "avatar_url": _upload_url(user.avatar_filename),
        "cover_url": _upload_url(user.cover_filename),
        "badge_kind": user.badge_kind,
        "created_at": user.created_at.isoformat() + "Z",
        "active_posts_count": user.active_posts_count,
        "is_staff": user.is_staff,
        "followers_count": user.followers_count,
        "following_count": user.following_count,
        "is_following": bool(viewer and viewer.id != user.id and viewer.is_following(user)),
        "is_me": bool(viewer and viewer.id == user.id),
        **_flash_ring(user, viewer),
    }


def _flash_ring(user, viewer):
    """has_flash / flash_unseen: o app e o site desenham o anel colorido no avatar."""
    from flashes import ring_state
    return ring_state(user.id, viewer.id if viewer else None)


def serialize_ranking_entry(user, rank):
    data = serialize_user(user)
    data.update({
        "rank": rank,
        "score": user.ranking_score,
        "total_likes_received": user.total_likes_received,
        "total_comments_received": user.total_comments_received,
    })
    return data


def serialize_post(post, viewer=None):
    media = [
        {"url": _upload_url(m["filename"]), "media_type": m["media_type"]}
        for m in post.display_media
    ]
    return {
        "id": post.id,
        "author": serialize_user(post.author, viewer),
        "post_type": post.post_type,
        "text_content": post.text_content or "",
        "media": media,
        "created_at": post.created_at.isoformat() + "Z",
        "is_temporary": post.is_temporary,
        "expires_at": post.expires_at.isoformat() + "Z" if post.is_temporary else None,
        "seconds_remaining": post.seconds_remaining if post.is_temporary else None,
        "expires_label": post.expires_label,
        "views_count": post.views_count,
        "likes_count": post.likes_count,
        "comments_count": post.comments_count,
        "liked_by_me": bool(viewer and viewer.has_liked(post)),
    }


def serialize_comment(comment):
    return {
        "id": comment.id,
        "author": serialize_user(comment.author),
        "content": comment.content,
        "created_at": comment.created_at.isoformat() + "Z",
        "parent_id": comment.parent_id,
    }


def _url_domain(url):
    # mesma lógica do filtro `domain` do site (app.py), usada aqui pro
    # favicon e pro nome curto do veículo quando não há article.source.name
    from urllib.parse import urlparse
    try:
        netloc = urlparse(url).netloc
    except ValueError:
        return ""
    return netloc[4:] if netloc.startswith("www.") else netloc


def serialize_news_article(article, tile_size="normal"):
    cfg = current_app.config
    domain = _url_domain(article.url)
    return {
        "id": article.id,
        "title": article.title,
        "summary": article.summary or "",
        "category": article.category,
        "category_label": dict(cfg["NEWS_CATEGORIES"]).get(article.category, article.category),
        "category_color": cfg["NEWS_CATEGORY_COLORS"].get(
            article.category, cfg["NEWS_CATEGORY_COLORS"].get("geral")
        ),
        # imagem passa pelo proxy do servidor (ver news.py) — vem relativa,
        # o app resolve com resolveMediaUrl() igual às outras mídias
        "image_url": url_for("news.article_image", article_id=article.id) if article.image_url else None,
        "favicon_url": f"https://www.google.com/s2/favicons?sz=64&domain={domain}" if domain else None,
        "source_name": article.source.name if article.source else domain,
        "domain": domain,
        "article_url": article.url,
        "published_at": article.published_at.isoformat() + "Z" if article.published_at else None,
        "tile_size": tile_size,
    }


CHAT_MEDIA_LABELS = {
    "image": "📷 Foto",
    "video": "🎥 Vídeo",
    "audio": "🎤 Áudio",
    "file": "📎 Arquivo",
}


def _reaction_summary(rows, viewer_id):
    """[{emoji, count, mine}] — mais usadas primeiro (empate: a mais antiga)."""
    groups = {}
    for r in sorted(rows, key=lambda r: (r.created_at or utcnow(), r.id)):
        g = groups.setdefault(r.emoji, {"emoji": r.emoji, "count": 0, "mine": False})
        g["count"] += 1
        g["mine"] = g["mine"] or r.user_id == viewer_id
    return sorted(groups.values(), key=lambda g: -g["count"])


def _reactions_by_message(message_ids, viewer_id):
    """Carrega as reações de várias mensagens numa consulta só (sem N+1)."""
    if not message_ids:
        return {}
    rows = MessageReaction.query.filter(MessageReaction.message_id.in_(message_ids)).all()
    by_msg = {}
    for r in rows:
        by_msg.setdefault(r.message_id, []).append(r)
    return {mid: _reaction_summary(rs, viewer_id) for mid, rs in by_msg.items()}


def _message_preview(message):
    """Texto curto pra prévia de resposta/inbox/push."""
    if message.deleted_at:
        return "Mensagem apagada"
    if message.view_once:
        return "🔒 Visualização única"
    if message.msg_type == "file" and message.media_name and message.content == CHAT_MEDIA_LABELS["file"]:
        return ("📎 " + message.media_name)[:80]  # Fase 15: cita o arquivo pelo nome
    return (message.content or "")[:80]


def _within_delete_window(message):
    """True enquanto ainda dá para \"apagar para todos\" (CHAT_DELETE_WINDOW_SECONDS)."""
    window = current_app.config.get("CHAT_DELETE_WINDOW_SECONDS", 48 * 3600)
    return message.created_at is not None and utcnow() - message.created_at <= timedelta(seconds=window)


def _within_edit_window(message):
    """True enquanto ainda dá para editar o texto (CHAT_EDIT_WINDOW_SECONDS)."""
    window = current_app.config.get("CHAT_EDIT_WINDOW_SECONDS", 24 * 3600)
    return message.created_at is not None and utcnow() - message.created_at <= timedelta(seconds=window)


def _mark_delivered(recipient, only_partner=None):
    """Marca como ENTREGUE (✓✓ cinza) o que chegou para `recipient` e ainda não tinha
    `delivered_at` — chamado quando o aparelho dele conecta/abre a caixa de entrada.
    Avisa cada remetente ao vivo (`delivered`)."""
    q = Message.query.filter(
        Message.recipient_id == recipient.id, Message.delivered_at.is_(None),
        Message.deleted_at.is_(None),
    )
    senders = {row[0] for row in q.with_entities(Message.sender_id).distinct().all()}
    if not senders:
        return
    q.update({"delivered_at": utcnow()}, synchronize_session=False)
    db.session.commit()
    for sid in senders:
        sender = db.session.get(User, sid)
        if sender is not None:
            notify_one(sender, recipient, "delivered")


def view_once_state(message):
    """None (não é visualização única) | "unopened" | "opened" | "expired"."""
    if not getattr(message, "view_once", False):
        return None
    if message.view_once_opened_at is not None:
        return "opened"
    ttl = current_app.config.get("CHAT_VIEW_ONCE_TTL_SECONDS", 14 * 86400)
    if message.media_path is None or (
            message.created_at is not None and utcnow() - message.created_at > timedelta(seconds=ttl)):
        return "expired"
    return "unopened"


def consume_view_once(message):
    """Tira a mídia do disco (e a miniatura) e limpa os campos de mídia. A linha FICA, com
    `view_once=True`, para o chat mostrar \"Aberta\"/\"Expirada\". Quem chama dá o commit."""
    if message.media_path:
        delete_upload(_chat_thumb_path(message.media_path))
        delete_upload(message.media_path)
    message.media_path = message.media_mime = None
    message.media_size = message.media_width = message.media_height = None
    MessageReaction.query.filter_by(message_id=message.id).delete()


def _after_send(msg, sender, recipient):
    """Depois de gravar uma mensagem nova: se o destinatário está conectado, ela já foi
    ENTREGUE; avisa os dois lados (o remetente também, pras outras abas/aparelhos)."""
    if hub.is_online(recipient.id):
        msg.delivered_at = utcnow()
        db.session.commit()
    notify_pair(sender, recipient, "message", id=msg.id)
    # Fase 10: mensagem nova desarquiva (ver chat_extras.unarchive_on_message)
    for owner, other in cx.unarchive_on_message(sender, recipient):
        notify_one(owner, other, "prefs")


def serialize_message(message, viewer, reactions=None):
    deleted = message.deleted_at is not None
    mtype = message.msg_type or "text"
    label = CHAT_MEDIA_LABELS.get(mtype)
    has_caption = bool(label) and message.content and message.content != label
    vo = not deleted and bool(message.view_once)
    vo_state = view_once_state(message) if vo else None
    reply = None
    if message.reply_to_id:
        ref = db.session.get(Message, message.reply_to_id)
        if ref is not None:
            gone = ref.deleted_at is not None or MessageHidden.query.filter_by(
                message_id=ref.id, user_id=viewer.id).first() is not None
            reply = {
                "id": ref.id,
                "sender_id": ref.sender_id,
                "msg_type": "text" if gone else (ref.msg_type or "text"),
                "preview": "Mensagem apagada" if gone else _message_preview(ref),
            }
    return {
        "id": message.id,
        # `content` segue existindo igual a antes (apps antigos só leem ele)
        "content": "" if deleted else message.content,
        "caption": message.content if (has_caption and not deleted and not vo) else None,
        "msg_type": "text" if deleted else mtype,
        # visualização única: a URL da mídia NUNCA vai na lista (só a rota de abrir devolve)
        "media_url": None if (deleted or vo or not message.media_path)
        else url_for("api_v1.message_media", message_id=message.id),
        "media_mime": None if (deleted or vo) else message.media_mime,
        "media_thumb_url": url_for("api_v1.message_media_thumb", message_id=message.id)
        if (not deleted and not vo and mtype == "video" and message.media_path
            and _chat_thumb_exists(message.media_path)) else None,
        "media_size": None if (deleted or vo) else message.media_size,
        "media_duration_ms": None if deleted else message.media_duration_ms,
        "media_width": None if (deleted or vo) else message.media_width,
        "media_height": None if (deleted or vo) else message.media_height,
        "view_once": vo,
        "view_once_state": vo_state,
        # o servidor decide: só o DESTINATÁRIO, só enquanto não aberta
        "can_open_view_once": bool(vo and vo_state == "unopened" and message.recipient_id == viewer.id),
        "media_name": None if (deleted or (mtype != "file")) else message.media_name,
        "reply_to": reply,
        "client_id": message.client_id,
        "sender_id": message.sender_id,
        "recipient_id": message.recipient_id,
        "created_at": message.created_at.isoformat() + "Z",
        "delivered_at": message.delivered_at.isoformat() + "Z" if message.delivered_at else None,
        "read_at": message.read_at.isoformat() + "Z" if message.read_at else None,
        "edited_at": message.edited_at.isoformat() + "Z" if message.edited_at else None,
        "deleted": deleted,
        "forwarded": bool(message.forwarded) and not deleted,
        # só texto, só o remetente, dentro da janela (o servidor decide; o app só mostra o botão)
        "can_edit": (
            message.sender_id == viewer.id and not deleted and mtype == "text"
            and _within_edit_window(message)
        ),
        "can_delete_for_all": (
            message.sender_id == viewer.id and not deleted and _within_delete_window(message)
        ),
        "reactions": [] if deleted else (reactions or []),
        "is_read": bool(message.is_read),
        "mine": message.sender_id == viewer.id,
    }


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

@api_bp.route("/auth/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not USERNAME_RE.match(username):
        return jsonify({"error": "Nome de usuário deve ter 3-20 caracteres: letras, números ou _."}), 400
    if not email or "@" not in email:
        return jsonify({"error": "E-mail inválido."}), 400
    if len(password) < 6:
        return jsonify({"error": "A senha deve ter pelo menos 6 caracteres."}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({"error": "Esse nome de usuário já está em uso."}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Esse e-mail já está cadastrado."}), 400

    user = User(username=username, email=email)
    user.set_password(password)
    if User.query.count() == 0:
        user.is_admin = True
    db.session.add(user)
    db.session.flush()

    token = ApiToken.generate_for(user)
    db.session.commit()

    return jsonify({"token": token.token, "user": serialize_user(user, user)})


@api_bp.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    identifier = (data.get("username") or "").strip().lower()
    password = data.get("password") or ""

    user = User.query.filter(
        (User.username == identifier) | (User.email == identifier)
    ).first()

    if user is None or not user.check_password(password):
        return jsonify({"error": "Usuário/e-mail ou senha incorretos."}), 401
    if user.is_banned:
        return jsonify({"error": "Esta conta foi banida. Contate um administrador."}), 403

    token = ApiToken.generate_for(user)
    db.session.commit()

    return jsonify({"token": token.token, "user": serialize_user(user, user)})


@api_bp.route("/me", methods=["GET"])
@api_login_required
def me():
    user = current_api_user()
    return jsonify(serialize_user(user, user))


def _replace_user_image(user, field_name, upload, prefix):
    """Mesma lógica de main._replace_user_image, mas devolve um código de
    erro em vez de fazer redirect."""
    if not (upload and upload.filename):
        return None
    cfg = current_app.config
    ext = upload.filename.rsplit(".", 1)[-1].lower() if "." in upload.filename else ""
    if ext not in cfg["ALLOWED_IMAGE_EXT"]:
        return "invalid"

    old_filename = getattr(user, field_name)
    new_filename = save_upload(upload, "cover" if prefix == "cover" else "avatar", ext, prefix)
    setattr(user, field_name, new_filename)

    delete_upload(old_filename)
    return None


@api_bp.route("/me", methods=["POST"])
@api_login_required
def update_me():
    user = current_api_user()
    cfg = current_app.config
    valid_accents = {key for key, _ in cfg["ACCENT_COLORS"]}

    new_username = (request.form.get("username") or "").strip()
    display_name = (request.form.get("display_name") or "").strip()[:50]
    bio = (request.form.get("bio") or "").strip()[:280]
    location = (request.form.get("location") or "").strip()[:80]
    accent_color = request.form.get("accent_color", cfg["DEFAULT_ACCENT"])
    if accent_color not in valid_accents:
        accent_color = cfg["DEFAULT_ACCENT"]

    if new_username and new_username != user.username:
        if not USERNAME_RE.match(new_username):
            return jsonify({"error": "Nome de usuário deve ter 3-20 caracteres: letras, números ou _."}), 400
        existing = User.query.filter(
            User.username.ilike(new_username), User.id != user.id
        ).first()
        if existing:
            return jsonify({"error": "Esse @ já está em uso por outra conta."}), 400
        user.username = new_username

    user.display_name = display_name
    user.bio = bio
    from widgets_weather import apply_profile_location
    apply_profile_location(user, location, request.form.get("location_lat"), request.form.get("location_lng"))
    user.accent_color = accent_color

    avatar_file = request.files.get("avatar_file")
    cover_file = request.files.get("cover_file")

    if _replace_user_image(user, "avatar_filename", avatar_file, "avatar") == "invalid":
        return jsonify({"error": "Formato de imagem não permitido para o avatar."}), 400
    if _replace_user_image(user, "cover_filename", cover_file, "cover") == "invalid":
        return jsonify({"error": "Formato de imagem não permitido para a capa."}), 400

    def _maybe_remove(field_name, sent_file, remove_flag_name):
        if sent_file and sent_file.filename:
            return
        if request.form.get(remove_flag_name) != "1":
            return
        old_filename = getattr(user, field_name)
        if not old_filename:
            return
        delete_upload(old_filename)
        setattr(user, field_name, None)

    _maybe_remove("avatar_filename", avatar_file, "remove_avatar")
    _maybe_remove("cover_filename", cover_file, "remove_cover")

    db.session.commit()
    return jsonify(serialize_user(user, user))


@api_bp.route("/accent-colors", methods=["GET"])
def accent_colors():
    colors = [{"key": key, "hex": hex_value} for key, hex_value in current_app.config["ACCENT_COLORS"]]
    return jsonify({"colors": colors})


# ---------------------------------------------------------------------------
# Feed / posts
# ---------------------------------------------------------------------------

@api_bp.route("/feed", methods=["GET"])
@api_login_required
def feed():
    viewer = current_api_user()
    page = request.args.get("page", 1, type=int)
    pagination = (
        Post.query.filter(Post.expires_at > utcnow())
        .order_by(Post.created_at.desc())
        .paginate(page=page, per_page=current_app.config["POSTS_PER_PAGE"], error_out=False)
    )
    return jsonify({
        "posts": [serialize_post(p, viewer) for p in pagination.items],
        "has_next": pagination.has_next,
    })


def _allowed_file(filename, post_type):
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    cfg = current_app.config
    if post_type == "photo":
        return ext in cfg["ALLOWED_IMAGE_EXT"]
    if post_type == "gif":
        return ext in cfg["ALLOWED_GIF_EXT"]
    if post_type == "video":
        return ext in cfg["ALLOWED_VIDEO_EXT"]
    return False


def _detect_media_type(file):
    filename = getattr(file, "filename", file)
    mimetype = (getattr(file, "mimetype", "") or "").lower()
    if not filename or "." not in filename:
        return None
    ext = filename.rsplit(".", 1)[1].lower()
    cfg = current_app.config
    if mimetype.startswith("audio/") and ext in cfg["ALLOWED_AUDIO_EXT"]:
        return "audio"
    if ext in cfg["ALLOWED_IMAGE_EXT"]:
        return "photo"
    if ext in cfg["ALLOWED_GIF_EXT"]:
        return "gif"
    if ext in cfg["ALLOWED_VIDEO_EXT"]:
        return "video"
    if ext in cfg["ALLOWED_AUDIO_EXT"]:
        return "audio"
    return None


def _detect_source_client():
    ua = (request.user_agent.string or "").lower()
    if "iphone" in ua or "ipad" in ua or "ipod" in ua:
        return "iphone"
    if "android" in ua:
        return "android"
    return "web"


@api_bp.route("/posts", methods=["POST"])
@api_login_required
def create_post():
    user = current_api_user()
    cfg = current_app.config

    # Aceita tanto JSON (post de texto) quanto multipart/form-data (post
    # com mídia) — o app Flutter usa um ou outro dependendo do tipo.
    if request.content_type and "application/json" in request.content_type:
        payload = request.get_json(silent=True) or {}
    else:
        payload = request.form

    post_type = payload.get("post_type")
    text_content = (payload.get("text_content") or "").strip()
    duration_minutes = payload.get("duration_minutes")
    # duração é opcional: ausente/vazia/0 = post permanente (sem expiração)
    try:
        duration_minutes = int(duration_minutes) if duration_minutes not in (None, "") else None
    except (TypeError, ValueError):
        return jsonify({"error": "Duração inválida."}), 400
    if not duration_minutes:
        duration_minutes = None

    if post_type not in ("text", "photo", "video", "gif", "audio", "media"):
        return jsonify({"error": "Tipo de post inválido."}), 400

    if duration_minutes is not None and not (
        cfg["MIN_DURATION_MINUTES"] <= duration_minutes <= cfg["MAX_DURATION_MINUTES"]
    ):
        return jsonify({
            "error": f"A duração deve estar entre {cfg['MIN_DURATION_MINUTES']} minuto "
                     f"e {cfg['MAX_DURATION_MINUTES']} minutos (1 ano)."
        }), 400

    saved_media = []
    if post_type == "text":
        if not text_content:
            return jsonify({"error": "Escreva algo para publicar um post de texto."}), 400
    else:
        files = [f for f in request.files.getlist("media_files") if f and f.filename]
        if not files:
            return jsonify({"error": "Selecione ao menos um arquivo para enviar."}), 400

        max_items = cfg.get("MAX_MEDIA_ITEMS", 10)
        if len(files) > max_items:
            return jsonify({"error": f"Você pode enviar no máximo {max_items} fotos/vídeos por post."}), 400

        for file in files:
            media_type = _detect_media_type(file)
            if media_type is None:
                return jsonify({"error": f"Formato de arquivo não permitido: {file.filename}"}), 400
            ext = secure_filename(file.filename).rsplit(".", 1)[1].lower()
            fname = save_upload(file, "post", ext)
            saved_media.append((fname, media_type))

    if saved_media:
        types_present = {t for _, t in saved_media}
        stored_post_type = types_present.pop() if len(types_present) == 1 else "media"
    else:
        stored_post_type = "text"

    post = Post(
        user_id=user.id,
        post_type=stored_post_type,
        text_content=text_content or None,
        media_filename=saved_media[0][0] if saved_media else None,
        duration_minutes=duration_minutes,
        source_client=_detect_source_client(),
    )
    db.session.add(post)
    db.session.flush()

    for position, (fname, media_type) in enumerate(saved_media):
        db.session.add(PostMedia(post_id=post.id, filename=fname, media_type=media_type, position=position))

    db.session.commit()
    return jsonify(serialize_post(post, user))


@api_bp.route("/posts/<int:post_id>", methods=["GET"])
@api_login_required
def get_post(post_id):
    viewer = current_api_user()
    post = Post.query.get_or_404(post_id)
    if post.is_expired:
        return jsonify({"error": "Este post expirou."}), 404
    post.views_count += 1
    db.session.commit()
    return jsonify(serialize_post(post, viewer))


@api_bp.route("/posts/<int:post_id>/like", methods=["POST"])
@api_login_required
def toggle_like(post_id):
    user = current_api_user()
    post = Post.query.get_or_404(post_id)
    if post.is_expired:
        return jsonify({"error": "Este post expirou."}), 404

    existing = Like.query.filter_by(user_id=user.id, post_id=post.id).first()
    if existing:
        db.session.delete(existing)
        post.author.total_likes_received = max(0, post.author.total_likes_received - 1)
        liked_now = False
    else:
        db.session.add(Like(user_id=user.id, post_id=post.id))
        post.author.total_likes_received += 1
        create_notification(recipient=post.author, actor=user, kind=Notification.KIND_LIKE, post=post)
        liked_now = True

    db.session.commit()
    return jsonify({"liked": liked_now, "likes_count": post.likes_count})


@api_bp.route("/posts/<int:post_id>/comments", methods=["GET"])
@api_login_required
def get_comments(post_id):
    post = Post.query.get_or_404(post_id)
    comments = post.comments.order_by(Comment.created_at.asc()).all()
    return jsonify({"comments": [serialize_comment(c) for c in comments]})


@api_bp.route("/posts/<int:post_id>/comments", methods=["POST"])
@api_login_required
def add_comment(post_id):
    user = current_api_user()
    post = Post.query.get_or_404(post_id)
    if post.is_expired:
        return jsonify({"error": "Este post expirou."}), 404

    data = request.get_json(silent=True) or {}
    content = (data.get("content") or "").strip()
    parent_id = data.get("parent_id")
    max_len = current_app.config["MAX_COMMENT_LENGTH"]

    parent = None
    if parent_id:
        parent = Comment.query.filter_by(id=parent_id, post_id=post.id).first()
        if parent is None:
            return jsonify({"error": "Esse comentário não existe mais."}), 400

    if not content:
        return jsonify({"error": "Escreva algo para comentar."}), 400
    if len(content) > max_len:
        return jsonify({"error": f"O comentário pode ter no máximo {max_len} caracteres."}), 400

    comment = Comment(
        post_id=post.id, user_id=user.id, content=content,
        parent_id=parent.id if parent else None,
    )
    db.session.add(comment)
    post.author.total_comments_received += 1
    db.session.flush()

    if parent is not None:
        create_notification(recipient=parent.author, actor=user, kind=Notification.KIND_REPLY, post=post, comment=comment)
    else:
        create_notification(recipient=post.author, actor=user, kind=Notification.KIND_COMMENT, post=post, comment=comment)

    db.session.commit()
    return jsonify(serialize_comment(comment))


# ---------------------------------------------------------------------------
# Usuários / perfil / seguir
# ---------------------------------------------------------------------------

@api_bp.route("/users/<username>", methods=["GET"])
@api_login_required
def get_user(username):
    viewer = current_api_user()
    user = User.query.filter_by(username=username).first_or_404()
    return jsonify(serialize_user(user, viewer))


@api_bp.route("/posts/<int:post_id>", methods=["DELETE"])
@api_login_required
def delete_post(post_id):
    """O autor apaga o próprio post quando quiser (permanente ou temporário)."""
    user = current_api_user()
    post = Post.query.get_or_404(post_id)
    if post.user_id != user.id:
        return jsonify({"error": "Você só pode excluir os seus próprios posts."}), 403

    for fname in post.all_media_filenames():
        delete_upload(fname)
    db.session.delete(post)
    db.session.commit()
    return jsonify({"ok": True})


@api_bp.route("/users/<username>/posts", methods=["GET"])
@api_login_required
def get_user_posts(username):
    viewer = current_api_user()
    user = User.query.filter_by(username=username).first_or_404()
    page = request.args.get("page", 1, type=int)
    pagination = (
        user.posts.filter(Post.expires_at > utcnow())
        .order_by(Post.created_at.desc())
        .paginate(page=page, per_page=current_app.config["POSTS_PER_PAGE"], error_out=False)
    )
    return jsonify({
        "posts": [serialize_post(p, viewer) for p in pagination.items],
        "has_next": pagination.has_next,
    })


@api_bp.route("/users/<username>/follow", methods=["POST"])
@api_login_required
def follow_user(username):
    viewer = current_api_user()
    user = User.query.filter_by(username=username).first_or_404()
    if viewer.follow(user):
        create_notification(recipient=user, actor=viewer, kind=Notification.KIND_FOLLOW)
    db.session.commit()
    return jsonify({"is_following": True, "followers_count": user.followers_count})


@api_bp.route("/users/<username>/unfollow", methods=["POST"])
@api_login_required
def unfollow_user(username):
    viewer = current_api_user()
    user = User.query.filter_by(username=username).first_or_404()
    viewer.unfollow(user)
    db.session.commit()
    return jsonify({"is_following": False, "followers_count": user.followers_count})


@api_bp.route("/contacts")
@api_login_required
def contacts():
    """Ping fase 8 — Contatos. `?tab=following|followers` (padrão following), `?q=` filtra por @/nome,
    `?page=` (50 por página). Sem banidos, A→Z. `{users:[serialize_user], has_next, counts:{following, followers}}`."""
    viewer = current_api_user()
    tab = "followers" if request.args.get("tab") == "followers" else "following"
    page = max(request.args.get("page", 1, type=int) or 1, 1)
    if tab == "followers":
        q = User.query.join(Follow, Follow.follower_id == User.id).filter(Follow.followed_id == viewer.id)
    else:
        q = User.query.join(Follow, Follow.followed_id == User.id).filter(Follow.follower_id == viewer.id)
    q = q.filter(User.is_banned.is_(False))
    term = (request.args.get("q") or "").strip()
    if term:
        like = "%" + term.replace("%", "").replace("_", "") + "%"
        q = q.filter(db.or_(User.username.ilike(like), User.display_name.ilike(like)))
    pagination = q.order_by(User.username.asc()).paginate(page=page, per_page=50, error_out=False)
    return jsonify({
        "users": [serialize_user(u, viewer) for u in pagination.items],
        "has_next": pagination.has_next,
        "counts": {"following": viewer.following_count, "followers": viewer.followers_count},
    })


# ---------------------------------------------------------------------------
# Notificações
# ---------------------------------------------------------------------------

@api_bp.route("/notifications", methods=["GET"])
@api_login_required
def notifications():
    user = current_api_user()
    page = request.args.get("page", 1, type=int)
    pagination = (
        Notification.query.filter_by(recipient_id=user.id)
        .order_by(Notification.created_at.desc())
        .paginate(page=page, per_page=current_app.config["NOTIFICATIONS_PER_PAGE"], error_out=False)
    )

    unread_ids = [n.id for n in pagination.items if not n.is_read]
    # Guardado ANTES de marcar como lidas: o app usa isso pra destacar o que
    # é novo (depois do commit, todas voltariam como lidas).
    was_unread = set(unread_ids)
    if unread_ids:
        Notification.query.filter(Notification.id.in_(unread_ids)).update(
            {"is_read": True}, synchronize_session=False
        )
        db.session.commit()

    def serialize_notif(n):
        snippet = None
        if n.kind in (Notification.KIND_COMMENT, Notification.KIND_REPLY) and n.comment:
            snippet = n.comment.content[:80]
        return {
            "id": n.id,
            "kind": n.kind,
            "verb": n.verb,
            "actor": serialize_user(n.actor, user),
            "post_id": n.post_id,
            "comment_id": n.comment_id,
            "snippet": snippet,
            "is_read": n.id not in was_unread,
            "created_at": n.created_at.isoformat() + "Z",
        }

    return jsonify({
        "notifications": [serialize_notif(n) for n in pagination.items],
        "has_next": pagination.has_next,
    })


@api_bp.route("/notifications/unread-count", methods=["GET"])
@api_login_required
def notifications_unread_count():
    user = current_api_user()
    return jsonify({"unread": user.unread_notifications_count})


# ---------------------------------------------------------------------------
# Mensagens
# ---------------------------------------------------------------------------

def _partner_ids_for(user_id):
    sent_to = db.session.query(Message.recipient_id).filter(Message.sender_id == user_id)
    received_from = db.session.query(Message.sender_id).filter(Message.recipient_id == user_id)
    ids = {row[0] for row in sent_to.union(received_from).all()}
    ids.discard(user_id)
    return ids


def _conversation_query(user_a_id, user_b_id):
    return Message.query.filter(
        db.or_(
            db.and_(Message.sender_id == user_a_id, Message.recipient_id == user_b_id),
            db.and_(Message.sender_id == user_b_id, Message.recipient_id == user_a_id),
        )
    )


def _visible_conversation_query(viewer_id, partner_id):
    """Conversa sem as mensagens que `viewer_id` apagou \"para mim\"."""
    return _conversation_query(viewer_id, partner_id).filter(not_hidden_for(viewer_id))


def _pinned_message_for(user, partner):
    """Ping fase 6b: mensagem que `user` fixou na conversa com `partner` (ou None). Se ela foi
    apagada para todos, ou escondida só para mim, a faixa some sozinha."""
    pref = ConversationPref.query.filter_by(user_id=user.id, partner_id=partner.id).first()
    if pref is None or not pref.pinned_message_id:
        return None
    msg = _visible_conversation_query(user.id, partner.id).filter(
        Message.id == pref.pinned_message_id).first()
    if msg is None or msg.deleted_at is not None:
        return None
    return msg


def _serialize_pinned(msg, viewer):
    if msg is None:
        return None
    return {
        "id": msg.id,
        "msg_type": msg.msg_type or "text",
        "preview": _message_preview(msg),
        "sender_id": msg.sender_id,
        "mine": msg.sender_id == viewer.id,
        "created_at": msg.created_at.isoformat() + "Z",
    }


@api_bp.route("/messages", methods=["GET"])
@chat_login_required
def inbox():
    """Lista de conversas. Fase 10: fixadas primeiro; `?archived=1` lista só as arquivadas
    (sem o parâmetro, as arquivadas ficam de fora e vem `archived_count`; `?archived=all` traz
    todas, pra tela de encaminhar). Cada item traz
    `prefs` {pinned, muted, archived} e `partner.presence` {visible, online, last_seen_at}."""
    user = current_api_user()
    _mark_delivered(user)  # abrir o app/a caixa de entrada = as mensagens chegaram
    mode = (request.args.get("archived") or "").lower()
    include_all = mode == "all"   # encaminhar: tem que listar também as arquivadas
    want_archived = mode in ("1", "true", "yes")
    sse_on = current_app.config.get("CHAT_SSE_ENABLED", True)
    partner_ids = _partner_ids_for(user.id)
    prefs = cx.prefs_map(user.id)
    conversations = []
    archived_count = 0

    if partner_ids:
        partners = User.query.filter(User.id.in_(partner_ids)).all()
        for partner in partners:
            last_msg = (
                _visible_conversation_query(user.id, partner.id)
                .order_by(Message.created_at.desc())
                .first()
            )
            if last_msg is None:
                continue  # tudo apagado para mim: some da lista até chegar mensagem nova
            pref = prefs.get(partner.id)
            if pref is not None and pref.archived:
                archived_count += 1
            if not include_all and bool(pref and pref.archived) != want_archived:
                continue
            unread = _visible_conversation_query(user.id, partner.id).filter(
                Message.sender_id == partner.id, Message.is_read.is_(False)
            ).count()
            pdata = serialize_user(partner, user)
            pdata["presence"] = cx.presence_payload(partner, user, sse_on)
            conversations.append({
                "partner": pdata,
                "last_message": serialize_message(last_msg, user) if last_msg else None,
                "unread": unread,
                "prefs": cx.serialize_prefs(pref),
                "_last": last_msg.created_at if last_msg else utcnow(),
                "_pinned_at": pref.pinned_at if pref is not None else None,
            })
        conversations = cx.sort_conversations(conversations)
        for c in conversations:
            c.pop("_last", None)
            c.pop("_pinned_at", None)

    return jsonify({"conversations": conversations, "archived_count": archived_count})


@api_bp.route("/messages/unread-count", methods=["GET"])
@chat_login_required
def messages_unread_count():
    user = current_api_user()
    return jsonify({"unread": user.unread_messages_count})


@api_bp.route("/messages/<username>", methods=["GET"])
@chat_login_required
def get_thread(username):
    user = current_api_user()
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == user.id:
        return jsonify({"error": "Você não pode enviar mensagens para si mesmo."}), 400

    messages = (
        _visible_conversation_query(user.id, partner.id)
        .order_by(Message.created_at.asc())
        .all()
    )

    unread_ids = [m.id for m in messages if m.recipient_id == user.id and not m.is_read]
    first_unread_id = unread_ids[0] if unread_ids else None   # Ping 6b: "não lidas" desta abertura
    unread_count = len(unread_ids)
    if unread_ids:
        _now = utcnow()
        Message.query.filter(Message.id.in_(unread_ids)).update(
            {"is_read": True, "read_at": _now, "delivered_at": db.func.coalesce(Message.delivered_at, _now)},
            synchronize_session=False,
        )
        db.session.commit()
        notify_one(partner, user, "read")        # ✓✓ azul ao vivo para quem enviou
        notify_one(user, partner, "read_self")   # selo de não lidas nas minhas outras abas

    reactions = _reactions_by_message([m.id for m in messages], user.id)
    pdata = serialize_user(partner, user)
    pdata["presence"] = cx.presence_payload(partner, user, current_app.config.get("CHAT_SSE_ENABLED", True))
    return jsonify({
        "partner": pdata,
        "prefs": cx.serialize_prefs(cx.prefs_map(user.id).get(partner.id)),
        "pinned_message": _serialize_pinned(_pinned_message_for(user, partner), user),
        "first_unread_id": first_unread_id,
        "unread_count": unread_count,
        "messages": [serialize_message(m, user, reactions.get(m.id)) for m in messages],
    })


def _image_mime_from_head(head):
    """MIME real da imagem pelos primeiros bytes (não confia no cliente)."""
    if head.startswith(b"\x89PNG"):
        return "image/png"
    if head[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if head[:4] == b"GIF8":
        return "image/gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "image/webp"
    return None


def _audio_mime_from_head(head, ext, client_mime=""):
    """MIME de áudio pela assinatura do arquivo (ogg, webm, mp4/m4a, mp3, wav).
    Devolve None se não parecer áudio. webm/ogg/mp4 podem ser vídeo: o MIME
    enviado pelo cliente (audio/...) desempata."""
    client_mime = (client_mime or "").lower()
    audio_hint = client_mime.startswith("audio/")
    if head[:4] == b"OggS":
        return "audio/ogg"
    if head[:4] == b"\x1a\x45\xdf\xa3":  # EBML (webm/mkv)
        return "audio/webm" if (audio_hint or ext == "webm") else None
    if head[4:8] == b"ftyp":
        return "audio/mp4"
    if head[:4] == b"RIFF" and head[8:12] == b"WAVE":
        return "audio/wav"
    if head[:3] == b"ID3" or (len(head) > 1 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0):
        return "audio/mpeg"
    return None


def _video_mime_from_head(head, ext, client_mime=""):
    """MIME de vídeo pela assinatura (mp4/mov via `ftyp`, webm via EBML).
    None se não parecer vídeo. webm com `audio/*` do cliente é áudio, não vídeo."""
    client_mime = (client_mime or "").lower()
    if head[:4] == b"\x1a\x45\xdf\xa3":  # EBML (webm/mkv)
        if client_mime.startswith("audio/"):
            return None
        return "video/webm" if ext == "webm" else None
    if head[4:8] == b"ftyp":
        if head[8:12] == b"qt  " or ext == "mov":
            return "video/quicktime"
        return "video/mp4"
    return None


def _jpeg_thumb_ok(data):
    """Miniatura de vídeo: só JPEG/PNG/WEBP pequeno (<= 400 KB)."""
    if not data or len(data) > 400 * 1024:
        return False
    return _image_mime_from_head(data[:12]) in ("image/jpeg", "image/png", "image/webp")


def _chat_thumb_path(media_path):
    """Caminho relativo da miniatura de um vídeo (ao lado do arquivo)."""
    return f"{media_path}.thumb"


def _chat_thumb_exists(media_path):
    if not media_path:
        return False
    root = current_app.config["UPLOAD_FOLDER"]
    return os.path.isfile(os.path.join(root, *_chat_thumb_path(media_path).split("/")))


_OLE_SIG = bytes.fromhex("D0CF11E0A1B11AE1")
_FILE_MIME_BY_EXT = {
    "pdf": "application/pdf", "txt": "text/plain", "csv": "text/csv", "json": "application/json",
    "zip": "application/zip", "rtf": "application/rtf",
    "doc": "application/msword", "xls": "application/vnd.ms-excel", "ppt": "application/vnd.ms-powerpoint",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "odt": "application/vnd.oasis.opendocument.text", "ods": "application/vnd.oasis.opendocument.spreadsheet",
    "odp": "application/vnd.oasis.opendocument.presentation",
    "heic": "image/heic", "heif": "image/heif",
}
_HEIC_BRANDS = (b"heic", b"heix", b"hevc", b"hevx", b"heim", b"heis", b"mif1", b"msf1")


def _file_mime_from_head(head, ext):
    """Fase 15: confere a ASSINATURA de documentos (não confia só na extensão).
    Devolve o MIME ou None se o conteúdo não bate com a extensão."""
    mime = _FILE_MIME_BY_EXT.get(ext)
    if mime is None or not head:
        return None
    if ext == "pdf":
        ok = b"%PDF-" in head[:1024]
    elif ext in ("docx", "xlsx", "pptx", "zip", "odt", "ods", "odp"):
        ok = head[:4] in (b"PK\x03\x04", b"PK\x05\x06")
    elif ext in ("doc", "xls", "ppt"):
        ok = head[:8] == _OLE_SIG
    elif ext == "rtf":
        ok = head[:5] == b"{\\rtf"
    elif ext in ("heic", "heif"):
        ok = head[4:8] == b"ftyp" and head[8:12] in _HEIC_BRANDS
    else:  # txt / csv / json: texto puro (sem byte nulo)
        ok = b"\x00" not in head
    return mime if ok else None


def _clean_display_name(filename):
    """Nome original para EXIBIR (mantém acentos): sem pasta, sem caracteres de controle,
    até 120 caracteres preservando a extensão. O arquivo no disco usa nome aleatório."""
    name = (filename or "").replace("\\", "/").rsplit("/", 1)[-1]
    name = "".join(ch for ch in name if ch.isprintable() and ch not in '<>:"|?*').strip(" .")
    if len(name) > 120:
        stem, dot, ext = name.rpartition(".")
        name = (stem[: 120 - len(ext) - 1] + "." + ext) if dot and len(ext) <= 10 else name[:120]
    return name or "arquivo"


def _sniff_chat_media(file, ext):
    """Tipo da mídia de chat (image|video|audio|file) ou None se inválida.
    Imagens têm a assinatura (magic bytes) conferida; o resto vai por extensão."""
    cfg = current_app.config
    mimetype = (getattr(file, "mimetype", "") or "").lower()
    if ext in cfg["ALLOWED_IMAGE_EXT"] | cfg["ALLOWED_GIF_EXT"]:
        head = file.stream.read(12)
        file.stream.seek(0)
        return "image" if _image_mime_from_head(head) else None
    # webm/ogg existem como áudio e vídeo: o mimetype desempata
    if ext in cfg["ALLOWED_AUDIO_EXT"] and (
        mimetype.startswith("audio/") or ext not in cfg["ALLOWED_VIDEO_EXT"]
    ):
        head = file.stream.read(16)
        file.stream.seek(0)
        return "audio" if _audio_mime_from_head(head, ext, mimetype) else None
    if ext in cfg["ALLOWED_VIDEO_EXT"]:
        head = file.stream.read(16)
        file.stream.seek(0)
        return "video" if _video_mime_from_head(head, ext, mimetype) else None
    if ext in cfg["CHAT_ALLOWED_FILE_EXT"]:
        head = file.stream.read(4096)
        file.stream.seek(0)
        return "file" if _file_mime_from_head(head, ext) else None
    return None


def _clamp_int(value, lo, hi):
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None
    return max(lo, min(hi, n))


@api_bp.route("/messages/<username>", methods=["POST"])
@chat_login_required
def send_message(username):
    """Envia texto (JSON, como sempre) ou mídia (multipart: campo `file` +
    `content` opcional como legenda, `duration_ms`, `width`, `height`,
    `reply_to_id`, `client_id`)."""
    user = current_api_user()
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == user.id:
        return jsonify({"error": "Você não pode enviar mensagens para si mesmo."}), 400

    is_multipart = (request.mimetype or "").startswith("multipart/")
    data = request.form if is_multipart else (request.get_json(silent=True) or {})
    content = (data.get("content") or "").strip()[:2000]
    client_id = (data.get("client_id") or "").strip()[:40] or None
    upload = request.files.get("file") if is_multipart else None

    # reenvio do mesmo client_id (rede ruim) devolve a mensagem já criada
    if client_id:
        dup = Message.query.filter_by(
            sender_id=user.id, recipient_id=partner.id, client_id=client_id
        ).first()
        if dup is not None:
            return jsonify(serialize_message(dup, user))

    reply_to_id = _clamp_int(data.get("reply_to_id"), 1, 2**31 - 1)
    if reply_to_id:
        ref = db.session.get(Message, reply_to_id)
        in_conv = ref is not None and {ref.sender_id, ref.recipient_id} == {user.id, partner.id}
        if not in_conv or ref.deleted_at is not None or MessageHidden.query.filter_by(
                message_id=ref.id, user_id=user.id).first() is not None:
            return jsonify({"error": "Mensagem respondida não encontrada."}), 400

    msg = Message(
        sender_id=user.id, recipient_id=partner.id, content=content,
        reply_to_id=reply_to_id, client_id=client_id,
    )
    view_once = str(data.get("view_once") or "").strip().lower() in ("1", "true", "yes", "on")
    if view_once and not (upload is not None and upload.filename):
        return jsonify({"error": "Visualização única vale só para foto, vídeo ou áudio."}), 400

    if upload is not None and upload.filename:
        cfg = current_app.config
        if "." not in upload.filename:
            return jsonify({"error": "Arquivo sem extensão."}), 400
        ext = secure_filename(upload.filename).rsplit(".", 1)[-1].lower()
        kind = _sniff_chat_media(upload, ext)
        if kind is None:
            return jsonify({"error": "Tipo de arquivo não permitido."}), 400
        upload.stream.seek(0, os.SEEK_END)
        size = upload.stream.tell()
        upload.stream.seek(0)
        limit = {
            "image": cfg["CHAT_MAX_IMAGE_BYTES"], "audio": cfg["CHAT_MAX_AUDIO_BYTES"],
            "video": cfg["CHAT_MAX_VIDEO_BYTES"], "file": cfg["CHAT_MAX_FILE_BYTES"],
        }[kind]
        if size <= 0:
            return jsonify({"error": "Arquivo vazio."}), 400
        if size > limit:
            return jsonify({"error": f"Arquivo grande demais (máx. {limit // (1024 * 1024)} MB)."}), 413

        if view_once and kind not in ("image", "video", "audio"):
            return jsonify({"error": "Visualização única vale só para foto, vídeo ou áudio."}), 400
        msg.msg_type = kind
        # imagem: o MIME vem da assinatura do arquivo (decide GIF com segurança);
        # ler antes de salvar, porque o save consome o stream
        sniffed_mime = None
        if kind == "image":
            sniffed_mime = _image_mime_from_head(upload.stream.read(12))
            upload.stream.seek(0)
        elif kind == "audio":
            sniffed_mime = _audio_mime_from_head(
                upload.stream.read(16), ext, upload.mimetype
            )
            upload.stream.seek(0)
        elif kind == "video":
            sniffed_mime = _video_mime_from_head(
                upload.stream.read(16), ext, upload.mimetype
            )
            upload.stream.seek(0)
        elif kind == "file":
            sniffed_mime = _file_mime_from_head(upload.stream.read(4096), ext)
            upload.stream.seek(0)
            msg.media_name = _clean_display_name(upload.filename)
        thumb_bytes = None
        if kind == "video" and not view_once:  # visualização única não guarda miniatura
            thumb_file = request.files.get("thumb")
            if thumb_file is not None:
                thumb_bytes = thumb_file.stream.read(400 * 1024 + 1)
                if not _jpeg_thumb_ok(thumb_bytes):
                    thumb_bytes = None  # miniatura é opcional: ignora se inválida
        msg.media_path = save_upload(upload, "chat", ext)
        if thumb_bytes:
            tfull = os.path.join(
                current_app.config["UPLOAD_FOLDER"], *_chat_thumb_path(msg.media_path).split("/")
            )
            with open(tfull, "wb") as fh:
                fh.write(thumb_bytes)
        msg.media_mime = sniffed_mime or (upload.mimetype or "")[:60] or None
        msg.media_size = size
        msg.media_duration_ms = _clamp_int(data.get("duration_ms"), 0, 6 * 3600 * 1000)
        msg.media_width = _clamp_int(data.get("width"), 1, 20000)
        msg.media_height = _clamp_int(data.get("height"), 1, 20000)
        if view_once:
            msg.view_once = True
            msg.content = CHAT_MEDIA_LABELS[kind]  # sem legenda: não vaza nada pela lista/push
        elif not msg.content:
            msg.content = CHAT_MEDIA_LABELS[kind]
    elif not content:
        return jsonify({"error": "Escreva algo antes de enviar."}), 400

    db.session.add(msg)
    db.session.commit()
    _after_send(msg, user, partner)

    cx.push_chat_message(msg, user, partner)

    return jsonify(serialize_message(msg, user))


@api_bp.route("/messages/media/<int:message_id>", methods=["GET"])
@chat_login_required
def message_media(message_id):
    """Serve a mídia de uma mensagem — só pra quem participa da conversa.
    Aceita Range (necessário pra vídeo/áudio no player do Flutter)."""
    from flask import send_from_directory
    user = current_api_user()
    msg = db.session.get(Message, message_id)
    if (
        msg is None or not msg.media_path or msg.deleted_at is not None
        or user.id not in (msg.sender_id, msg.recipient_id)
    ):
        return jsonify({"error": "Mídia não encontrada."}), 404
    if msg.view_once:
        # só o destinatário, só depois de abrir (POST /view-once) e só dentro da janela
        win = timedelta(seconds=current_app.config.get("CHAT_VIEW_ONCE_WINDOW_SECONDS", 600))
        opened = msg.view_once_opened_at
        if user.id != msg.recipient_id or opened is None or request.args.get("download"):
            return jsonify({"error": "Mídia não encontrada."}), 404
        if utcnow() - opened > win:
            consume_view_once(msg)
            db.session.commit()
            return jsonify({"error": "Esta mensagem não está mais disponível."}), 410
    # Fase 15: documentos SEMPRE como download (nunca renderiza no site); `?download=1` força o
    # mesmo para qualquer mídia. O nome original vai no Content-Disposition.
    as_file = (msg.msg_type == "file") or request.args.get("download") in ("1", "true")
    resp = send_from_directory(
        current_app.config["UPLOAD_FOLDER"], msg.media_path,
        mimetype=msg.media_mime or None, conditional=True,
        as_attachment=as_file,
        download_name=(msg.media_name or os.path.basename(msg.media_path)) if as_file else None,
    )
    resp.headers["Cache-Control"] = "no-store" if msg.view_once else "private, max-age=86400"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


@api_bp.route("/messages/media/<int:message_id>/thumb", methods=["GET"])
@chat_login_required
def message_media_thumb(message_id):
    """Miniatura (1º quadro) de um vídeo — mesma regra de acesso da mídia."""
    from flask import send_from_directory
    user = current_api_user()
    msg = db.session.get(Message, message_id)
    if (
        msg is None or msg.msg_type != "video" or not msg.media_path or msg.view_once
        or msg.deleted_at is not None or user.id not in (msg.sender_id, msg.recipient_id)
        or not _chat_thumb_exists(msg.media_path)
    ):
        return jsonify({"error": "Miniatura não encontrada."}), 404
    thumb = _chat_thumb_path(msg.media_path)
    mime = _image_mime_from_head(open(os.path.join(
        current_app.config["UPLOAD_FOLDER"], *thumb.split("/")), "rb").read(12)) or "image/jpeg"
    resp = send_from_directory(
        current_app.config["UPLOAD_FOLDER"], thumb, mimetype=mime, conditional=True,
    )
    resp.headers["Cache-Control"] = "private, max-age=86400"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


@api_bp.route("/messages/<int:message_id>/view-once", methods=["POST"])
@chat_login_required
def open_view_once(message_id):
    """Abre UMA vez uma mensagem de visualização única (só o destinatário). Marca como aberta e
    devolve a URL da mídia, que só serve até CHAT_VIEW_ONCE_WINDOW_SECONDS depois. Segunda
    chamada = 410. O app chama `/view-once/close` ao fechar o visualizador para apagar na hora."""
    user = current_api_user()
    msg = _own_visible_message(message_id, user)
    if msg is None or not msg.view_once:
        return jsonify({"error": "Mensagem não encontrada."}), 404
    if msg.recipient_id != user.id:
        return jsonify({"error": "Só quem recebeu pode abrir."}), 403
    state = view_once_state(msg)
    gone = jsonify({"error": "Esta mensagem não está mais disponível."}), 410
    if state != "unopened":
        # "opened": segue valendo a janela / o fechar do visualizador (não apaga no meio da reprodução)
        if state == "expired" and msg.media_path:
            consume_view_once(msg)
            db.session.commit()
        return gone
    if not os.path.isfile(os.path.join(current_app.config["UPLOAD_FOLDER"], *msg.media_path.split("/"))):
        consume_view_once(msg)
        db.session.commit()
        return gone
    msg.view_once_opened_at = utcnow()
    if not msg.is_read:
        msg.is_read = True
        msg.read_at = msg.read_at or utcnow()
    db.session.commit()
    sender = db.session.get(User, msg.sender_id)
    notify_pair(sender, user, "update", id=msg.id, kind="view_once")
    return jsonify({
        "id": msg.id,
        "msg_type": msg.msg_type,
        "media_url": url_for("api_v1.message_media", message_id=msg.id),
        "media_mime": msg.media_mime,
        "media_width": msg.media_width,
        "media_height": msg.media_height,
        "media_duration_ms": msg.media_duration_ms,
        "expires_in": current_app.config.get("CHAT_VIEW_ONCE_WINDOW_SECONDS", 600),
    })


@api_bp.route("/messages/<int:message_id>/view-once/close", methods=["POST"])
@chat_login_required
def close_view_once(message_id):
    """O destinatário fechou o visualizador: apaga a mídia do disco agora. Idempotente."""
    user = current_api_user()
    msg = db.session.get(Message, message_id)
    if msg is None or not msg.view_once or msg.recipient_id != user.id:
        return jsonify({"error": "Mensagem não encontrada."}), 404
    if msg.view_once_opened_at is not None and msg.media_path:
        consume_view_once(msg)
        db.session.commit()
        sender = db.session.get(User, msg.sender_id)
        notify_pair(sender, user, "update", id=msg.id, kind="view_once")
    return jsonify({"message": serialize_message(msg, user)})


def _purge_message(msg):
    """Apaga a mídia (e a miniatura) do disco e transforma a linha em \"apagada\"
    (a linha fica: mantém a ordem da conversa). Também limpa as reações."""
    if msg.media_path:
        delete_upload(_chat_thumb_path(msg.media_path))
        delete_upload(msg.media_path)
    msg.media_path = msg.media_mime = msg.media_name = None
    msg.media_size = msg.media_duration_ms = msg.media_width = msg.media_height = None
    msg.content = ""
    msg.deleted_at = msg.deleted_at or utcnow()
    MessageReaction.query.filter_by(message_id=msg.id).delete()


@api_bp.route("/messages/<int:message_id>", methods=["DELETE"])
@chat_login_required
def delete_message(message_id):
    """Apaga uma mensagem. `?scope=me` (padrão): some só para quem pediu.
    `?scope=all`: só o remetente, dentro de CHAT_DELETE_WINDOW_SECONDS — a mensagem
    vira "Mensagem apagada" para os dois e a mídia sai do disco."""
    user = current_api_user()
    msg = db.session.get(Message, message_id)
    if msg is None or user.id not in (msg.sender_id, msg.recipient_id):
        return jsonify({"error": "Mensagem não encontrada."}), 404
    scope = (request.args.get("scope") or (request.get_json(silent=True) or {}).get("scope") or "me").lower()
    if scope not in ("me", "all"):
        return jsonify({"error": "scope deve ser 'me' ou 'all'."}), 400

    if scope == "all":
        if msg.sender_id != user.id:
            return jsonify({"error": "Só quem enviou pode apagar para todos."}), 403
        if msg.deleted_at is None:
            if not _within_delete_window(msg):
                hours = current_app.config.get("CHAT_DELETE_WINDOW_SECONDS", 48 * 3600) // 3600
                return jsonify({"error": f"Só dá para apagar para todos até {hours} h depois do envio."}), 403
            _purge_message(msg)
            db.session.commit()
            other = db.session.get(User, msg.recipient_id)
            notify_pair(user, other, "update", id=msg.id, kind="delete")
        return jsonify({"scope": "all", "message": serialize_message(msg, user)})

    if MessageHidden.query.filter_by(message_id=msg.id, user_id=user.id).first() is None:
        db.session.add(MessageHidden(message_id=msg.id, user_id=user.id))
        db.session.flush()
        other = msg.recipient_id if user.id == msg.sender_id else msg.sender_id
        # os dois esconderam: ninguém mais vê, então a mídia pode sair do disco
        if MessageHidden.query.filter_by(message_id=msg.id, user_id=other).first() is not None:
            _purge_message(msg)
        db.session.commit()
        notify_one(user, db.session.get(User, other), "update", id=msg.id, kind="hide")
    return jsonify({"scope": "me", "id": msg.id})


def _reactable_message(message_id, user):
    """Mensagem existente, não apagada e da conversa do usuário — ou None."""
    msg = db.session.get(Message, message_id)
    if msg is None or msg.deleted_at is not None or user.id not in (msg.sender_id, msg.recipient_id):
        return None
    return msg


def _valid_emoji(value):
    value = (value or "").strip()
    if not value or len(value) > 16:
        return None
    # rejeita texto comum: emoji não tem letra/número ASCII nem espaço
    if any(c.isspace() or (c.isascii() and c.isalnum()) for c in value):
        return None
    return value


def _notify_reaction(msg, user):
    other = db.session.get(User, msg.recipient_id if msg.sender_id == user.id else msg.sender_id)
    if other is not None:
        notify_pair(user, other, "update", id=msg.id, kind="reaction")


def _reactions_response(msg, user):
    rows = MessageReaction.query.filter_by(message_id=msg.id).all()
    return jsonify({"message_id": msg.id, "reactions": _reaction_summary(rows, user.id)})


@api_bp.route("/messages/<int:message_id>/reaction", methods=["PUT"])
@chat_login_required
def react_to_message(message_id):
    user = current_api_user()
    msg = _reactable_message(message_id, user)
    if msg is None:
        return jsonify({"error": "Mensagem não encontrada."}), 404
    emoji = _valid_emoji((request.get_json(silent=True) or {}).get("emoji"))
    if emoji is None:
        return jsonify({"error": "Emoji inválido."}), 400
    existing = MessageReaction.query.filter_by(message_id=msg.id, user_id=user.id).first()
    if existing is None:
        db.session.add(MessageReaction(message_id=msg.id, user_id=user.id, emoji=emoji))
    else:
        existing.emoji = emoji
    db.session.commit()
    _notify_reaction(msg, user)
    return _reactions_response(msg, user)


@api_bp.route("/messages/<int:message_id>/reaction", methods=["DELETE"])
@chat_login_required
def unreact_to_message(message_id):
    user = current_api_user()
    msg = _reactable_message(message_id, user)
    if msg is None:
        return jsonify({"error": "Mensagem não encontrada."}), 404
    MessageReaction.query.filter_by(message_id=msg.id, user_id=user.id).delete()
    db.session.commit()
    _notify_reaction(msg, user)
    return _reactions_response(msg, user)


# ---------------------------------------------------------------------------
# Fase 8: editar, encaminhar, buscar na conversa
# ---------------------------------------------------------------------------

def _norm_search(text):
    """Minúsculas e sem acento ("ação" casa com "acao"), pra busca amigável em português."""
    import unicodedata
    decomposed = unicodedata.normalize("NFD", (text or "").casefold())
    return "".join(c for c in decomposed if not unicodedata.combining(c))


def _own_visible_message(message_id, user):
    """Mensagem da conversa do usuário, não apagada e não escondida por ele — ou None."""
    msg = db.session.get(Message, message_id)
    if msg is None or msg.deleted_at is not None or user.id not in (msg.sender_id, msg.recipient_id):
        return None
    if MessageHidden.query.filter_by(message_id=msg.id, user_id=user.id).first() is not None:
        return None
    return msg


@api_bp.route("/messages/<int:message_id>", methods=["PATCH"])
@chat_login_required
def edit_message(message_id):
    """Edita o texto de uma mensagem. Só o remetente, só `msg_type == text`, dentro de
    CHAT_EDIT_WINDOW_SECONDS. Grava `edited_at` (o rótulo "editada" aparece nos dois lados).
    Texto igual ao atual não conta como edição."""
    user = current_api_user()
    msg = _own_visible_message(message_id, user)
    if msg is None:
        return jsonify({"error": "Mensagem não encontrada."}), 404
    if msg.sender_id != user.id:
        return jsonify({"error": "Só quem enviou pode editar."}), 403
    if (msg.msg_type or "text") != "text":
        return jsonify({"error": "Só mensagens de texto podem ser editadas."}), 400
    if not _within_edit_window(msg):
        hours = current_app.config.get("CHAT_EDIT_WINDOW_SECONDS", 24 * 3600) // 3600
        return jsonify({"error": f"Só dá para editar até {hours} h depois do envio."}), 403
    content = ((request.get_json(silent=True) or {}).get("content") or "").strip()[:2000]
    if not content:
        return jsonify({"error": "A mensagem não pode ficar vazia (use apagar)."}), 400
    if content != msg.content:
        msg.content = content
        msg.edited_at = utcnow()
        db.session.commit()
        other = db.session.get(User, msg.recipient_id if msg.sender_id == user.id else msg.sender_id)
        notify_pair(user, other, "update", id=msg.id, kind="edit")
    reactions = _reactions_by_message([msg.id], user.id)
    return jsonify(serialize_message(msg, user, reactions.get(msg.id)))


def _copy_chat_file(rel):
    """Copia um arquivo de `chat/` para um caminho novo (mesma extensão). Devolve o caminho
    relativo novo ou None se a origem não existe. Copiar (em vez de compartilhar o arquivo)
    mantém `_purge_message` seguro: apagar um lado nunca quebra o outro."""
    import shutil
    root = os.path.realpath(current_app.config["UPLOAD_FOLDER"])
    src = os.path.realpath(os.path.join(root, *rel.split("/")))
    if not src.startswith(root + os.sep) or not os.path.isfile(src):
        return None
    ext = rel.rsplit(".", 1)[-1].lower() if "." in rel.rsplit("/", 1)[-1] else "bin"
    new_rel = f"{_chat_subdir()}/{uuid.uuid4().hex}.{ext}"
    dst = os.path.join(root, *new_rel.split("/"))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)
    return new_rel


def _chat_subdir():
    now = utcnow()
    return f"chat/{now.year:04d}/{now.month:02d}"


@api_bp.route("/messages/<int:message_id>/forward", methods=["POST"])
@chat_login_required
def forward_message(message_id):
    """Encaminha uma mensagem (texto ou mídia) para até CHAT_FORWARD_MAX_TARGETS conversas.
    JSON: `{"usernames": ["ana", "beto"], "client_id"?}`. A mídia é copiada no servidor
    (o app não reenvia o arquivo). Validação antes de criar qualquer coisa: se um destino
    for inválido, nada é encaminhado. `client_id` repetido não duplica."""
    user = current_api_user()
    src = _own_visible_message(message_id, user)
    if src is None:
        return jsonify({"error": "Mensagem não encontrada."}), 404
    data = request.get_json(silent=True) or {}
    raw = data.get("usernames")
    if not isinstance(raw, list) or not raw:
        return jsonify({"error": "Escolha pelo menos uma conversa."}), 400
    names = []
    for n in raw:
        n = str(n or "").strip()
        if n and n not in names:
            names.append(n)
    limit = current_app.config.get("CHAT_FORWARD_MAX_TARGETS", 5)
    if not names:
        return jsonify({"error": "Escolha pelo menos uma conversa."}), 400
    if len(names) > limit:
        return jsonify({"error": f"Escolha no máximo {limit} conversas."}), 400
    targets = []
    for n in names:
        t = User.query.filter_by(username=n).first()
        if t is None:
            return jsonify({"error": f"Usuário @{n} não encontrado."}), 404
        if t.id == user.id:
            return jsonify({"error": "Você não pode encaminhar para si mesmo."}), 400
        targets.append(t)
    mtype = src.msg_type or "text"
    if src.view_once:
        return jsonify({"error": "Mensagem de visualização única não pode ser encaminhada."}), 400
    if mtype not in ("text", "image", "video", "audio", "file"):
        return jsonify({"error": "Este tipo de mensagem não pode ser encaminhado."}), 400
    if src.media_path and not os.path.isfile(os.path.join(
            current_app.config["UPLOAD_FOLDER"], *src.media_path.split("/"))):
        return jsonify({"error": "O arquivo original não está mais disponível."}), 410
    client_id = (data.get("client_id") or "").strip()[:40] or None

    out = []
    created = []
    copied = []
    try:
        for t in targets:
            if client_id:
                dup = Message.query.filter_by(
                    sender_id=user.id, recipient_id=t.id, client_id=client_id).first()
                if dup is not None:
                    out.append({"username": t.username, "message": serialize_message(dup, user)})
                    continue
            m = Message(
                sender_id=user.id, recipient_id=t.id, content=src.content or "",
                msg_type=mtype, forwarded=True, client_id=client_id,
            )
            if src.media_path:
                new_path = _copy_chat_file(src.media_path)
                if new_path is None:
                    raise FileNotFoundError(src.media_path)
                copied.append(new_path)
                m.media_path = new_path
                m.media_mime, m.media_size = src.media_mime, src.media_size
                m.media_duration_ms = src.media_duration_ms
                m.media_width, m.media_height = src.media_width, src.media_height
                m.media_name = src.media_name
                if mtype == "video" and _chat_thumb_exists(src.media_path):
                    t_new = _chat_thumb_path(new_path)
                    t_old = _chat_thumb_path(src.media_path)
                    root = current_app.config["UPLOAD_FOLDER"]
                    import shutil
                    shutil.copyfile(os.path.join(root, *t_old.split("/")), os.path.join(root, *t_new.split("/")))
                    copied.append(t_new)
            db.session.add(m)
            created.append((t, m))
        db.session.commit()
    except Exception:
        db.session.rollback()
        for rel in copied:
            delete_upload(rel)
        return jsonify({"error": "Não foi possível encaminhar. Tente de novo."}), 500

    for t, m in created:
        _after_send(m, user, t)
        out.append({"username": t.username, "message": serialize_message(m, user)})
        cx.push_chat_message(m, user, t, forwarded=True)
    return jsonify({"forwarded": out})


@api_bp.route("/messages/<username>/search", methods=["GET"])
@chat_login_required
def search_thread(username):
    """Busca texto/legendas na conversa (sem acento, sem diferenciar maiúsculas), respeitando
    "apagar para mim" e mensagens apagadas. `?q=` (mín. 2 caracteres), `?limit=` (50, máx. 100),
    `?before_id=` pra paginar. Resposta: mais recentes primeiro, com `total` de resultados."""
    user = current_api_user()
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == user.id:
        return jsonify({"error": "Você não pode enviar mensagens para si mesmo."}), 400
    q = (request.args.get("q") or "").strip()[:100]
    if len(q) < 2:
        return jsonify({"error": "Digite ao menos 2 caracteres."}), 400
    limit = _clamp_int(request.args.get("limit"), 1, 100) or 50
    before_id = _clamp_int(request.args.get("before_id"), 1, 2**31 - 1)
    needle = _norm_search(q)

    rows = (
        _visible_conversation_query(user.id, partner.id)
        .filter(Message.deleted_at.is_(None))
        .with_entities(Message.id, Message.content, Message.msg_type, Message.media_name)
        .order_by(Message.created_at.desc(), Message.id.desc())
        .all()
    )
    hit_ids = []
    for mid, content, mtype, mname in rows:
        if mtype == "file" and mname and needle in _norm_search(mname):
            hit_ids.append(mid)  # Fase 15: busca também pelo nome do arquivo
            continue
        if mtype == "call":
            continue  # Fase 14: o rótulo da chamada não é texto do usuário
        label = CHAT_MEDIA_LABELS.get(mtype or "text")
        if label and content == label:
            continue  # mídia sem legenda: o rótulo ("📷 Foto") não é texto do usuário
        if needle in _norm_search(content):
            hit_ids.append(mid)
    total = len(hit_ids)
    if before_id:
        hit_ids = [i for i in hit_ids if i < before_id]
    page_ids = hit_ids[:limit]
    msgs = Message.query.filter(Message.id.in_(page_ids)).all() if page_ids else []
    order = {mid: i for i, mid in enumerate(page_ids)}
    msgs.sort(key=lambda m: order[m.id])
    reactions = _reactions_by_message(page_ids, user.id)
    return jsonify({
        "query": q,
        "total": total,
        "results": [serialize_message(m, user, reactions.get(m.id)) for m in msgs],
        "has_more": len(hit_ids) > limit,
    })


# ---------------------------------------------------------------------------
# Fase 9: tempo real (SSE) e "digitando…"
# ---------------------------------------------------------------------------

@api_bp.route("/messages/stream", methods=["GET"])
@chat_login_required
def message_stream():
    """Fluxo de eventos (Server-Sent Events) do chat do usuário. Eventos (`event:`):
    `ready` (conectou — o cliente rebusca o que perdeu), `message`, `update`
    (`kind`: edit|delete|hide|reaction), `read` (o outro leu), `read_self` (li em outra aba),
    `delivered`, `typing` (`state`: typing|recording|stop) e `resync` (fila estourou: rebuscar tudo).
    Todos trazem `partner` = @ do outro lado da conversa. Sem corpo de mensagem: o cliente
    rebusca pela API REST. Se o servidor não suportar (SSE desligado/vários workers), os
    clientes continuam no polling."""
    import queue as _queue
    cfg = current_app.config
    if not cfg.get("CHAT_SSE_ENABLED", True):
        return jsonify({"error": "Tempo real desativado neste servidor."}), 503
    user = current_api_user()
    uid = user.id
    _mark_delivered(user)  # conectar = "entregue" para tudo que estava esperando
    keepalive = float(cfg.get("CHAT_SSE_KEEPALIVE_SECONDS", 15))
    hub.max_per_user = int(cfg.get("CHAT_SSE_MAX_PER_USER", 8))
    app = current_app._get_current_object()
    q = hub.subscribe(uid)
    cx.on_connect(uid, True)  # Fase 10: primeira conexão = ficou online (avisa os contatos conectados)

    def _left():
        if hub.unsubscribe(uid, q):
            cx.on_disconnect(app, uid)

    def gen():
        try:
            yield "retry: 3000\n\n"
            yield sse("ready", {"user_id": uid})
            while True:
                try:
                    item = q.get(timeout=keepalive)
                except _queue.Empty:
                    yield ": ping\n\n"
                    continue
                if item is None:  # conexão derrubada (limite por usuário)
                    return
                yield sse(item[0], item[1])
        finally:
            _left()

    resp = Response(gen(), mimetype="text/event-stream")
    resp.headers["Cache-Control"] = "no-cache, no-transform"
    resp.headers["X-Accel-Buffering"] = "no"  # nginx: não segurar o fluxo
    # gerador que nunca começou não roda o `finally`: garante a limpeza ao fechar a resposta
    resp.call_on_close(_left)
    return resp


@api_bp.route("/messages/<username>/typing", methods=["POST"])
@chat_login_required
def message_typing(username):
    """Avisa o outro lado que estou digitando/gravando. JSON `{"state": "typing"|"recording"|"stop"}`.
    Não grava nada; limitado a ~1 aviso a cada 1,5 s por conversa (o excesso é ignorado)."""
    user = current_api_user()
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == user.id:
        return jsonify({"error": "Você não pode enviar mensagens para si mesmo."}), 400
    state = ((request.get_json(silent=True) or {}).get("state") or "typing").lower()
    if state not in ("typing", "recording", "stop"):
        return jsonify({"error": "state inválido."}), 400
    sent = False
    if state == "stop" or hub.typing_allowed(user.id, partner.id):
        sent = notify_one(partner, user, "typing", state=state) > 0
    return jsonify({"ok": True, "delivered": sent})


# ---------------------------------------------------------------------------
# Fase 10: presença, privacidade e preferências da conversa
# ---------------------------------------------------------------------------

@api_bp.route("/messages/privacy", methods=["GET", "PUT"])
@chat_login_required
def chat_privacy():
    """`{"show_presence": bool}` — mostrar online/visto por último. Quem esconde o seu também
    não vê o dos outros. Ao mudar, os contatos conectados são avisados (evento `presence`)."""
    user = current_api_user()
    if request.method == "PUT":
        data = request.get_json(silent=True) or {}
        if not isinstance(data.get("show_presence"), bool):
            return jsonify({"error": "Envie show_presence true ou false."}), 400
        if user.show_presence != data["show_presence"]:
            user.show_presence = data["show_presence"]
            db.session.commit()
            cx.announce_presence(user, current_app.config.get("CHAT_SSE_ENABLED", True))
            hub.publish(user.id, "prefs", {"partner": ""})  # minhas outras abas/aparelhos recarregam
    return jsonify({"show_presence": bool(user.show_presence)})


@api_bp.route("/messages/<username>/prefs", methods=["GET", "PUT"])
@chat_login_required
def conversation_prefs(username):
    """Fixar / silenciar / arquivar a conversa (só para mim). PUT parcial:
    `{"pinned"?: bool, "muted"?: bool, "archived"?: bool}`. Arquivar desafixa; fixar desarquiva;
    no máximo `CHAT_MAX_PINNED` fixadas (400 acima disso)."""
    user = current_api_user()
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == user.id:
        return jsonify({"error": "Você não pode enviar mensagens para si mesmo."}), 400
    if request.method == "PUT":
        data = request.get_json(silent=True) or {}
        fields = {}
        for k in ("pinned", "muted", "archived"):
            if k in data:
                if not isinstance(data[k], bool):
                    return jsonify({"error": f"{k} precisa ser true ou false."}), 400
                fields[k] = data[k]
        if not fields:
            return jsonify({"error": "Nada para alterar."}), 400
        pref, err = cx.set_prefs(user, partner, current_app.config.get("CHAT_MAX_PINNED", 3), **fields)
        if err:
            return jsonify({"error": err}), 400
        notify_one(user, partner, "prefs")  # minhas outras abas/aparelhos
        return jsonify(cx.serialize_prefs(pref))
    return jsonify(cx.serialize_prefs(cx.prefs_map(user.id).get(partner.id)))


@api_bp.route("/messages/<username>/pin", methods=["GET", "PUT", "DELETE"])
@chat_login_required
def conversation_pin(username):
    """Ping fase 6b — mensagem fixada no topo da conversa (só para mim; uma por conversa).
    `PUT {"message_id": int}` fixa (substitui a anterior), `DELETE` desafixa, `GET` consulta.
    Sempre responde `{"pinned_message": {...}|null}`."""
    user = current_api_user()
    partner = User.query.filter_by(username=username).first_or_404()
    if partner.id == user.id:
        return jsonify({"error": "Você não pode enviar mensagens para si mesmo."}), 400
    if request.method == "PUT":
        mid = (request.get_json(silent=True) or {}).get("message_id")
        if isinstance(mid, bool) or not isinstance(mid, int):
            return jsonify({"error": "message_id precisa ser um número."}), 400
        msg = _visible_conversation_query(user.id, partner.id).filter(Message.id == mid).first()
        if msg is None:
            return jsonify({"error": "Mensagem não encontrada."}), 404
        if msg.deleted_at is not None or (msg.msg_type or "text") == "call" or msg.view_once:
            return jsonify({"error": "Essa mensagem não pode ser fixada."}), 400
        cx.set_pinned_message(user, partner, msg.id)
    elif request.method == "DELETE":
        cx.set_pinned_message(user, partner, None)
    if request.method != "GET":
        notify_one(user, partner, "prefs")  # minhas outras abas/aparelhos
    return jsonify({"pinned_message": _serialize_pinned(_pinned_message_for(user, partner), user)})


# ---------------------------------------------------------------------------
# Aparelhos (tokens do FCM, pra push notification)
# ---------------------------------------------------------------------------

@api_bp.route("/devices/register", methods=["POST"])
@api_login_required
def register_device():
    user = current_api_user()
    data = request.get_json(silent=True) or {}
    token = (data.get("token") or "").strip()
    platform = (data.get("platform") or "").strip()[:10] or None
    if not token:
        return jsonify({"error": "token obrigatório"}), 400

    # upsert por token (não por usuário): o mesmo aparelho pode logar em
    # outra conta depois, e nesse caso o token precisa passar a apontar
    # pro novo usuário, não duplicar linha
    existing = DeviceToken.query.filter_by(token=token).first()
    if existing:
        existing.user_id = user.id
        existing.platform = platform
    else:
        db.session.add(DeviceToken(user_id=user.id, token=token, platform=platform))
    db.session.commit()
    return jsonify({"ok": True})


@api_bp.route("/devices/unregister", methods=["POST"])
@api_login_required
def unregister_device():
    data = request.get_json(silent=True) or {}
    token = (data.get("token") or "").strip()
    if token:
        DeviceToken.query.filter_by(token=token).delete()
        db.session.commit()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Vortex (fotos/vídeos em grade)
# ---------------------------------------------------------------------------

# Sessão do /pictures legado: o app antigo pagina com um número inteiro, não
# com o cursor opaco; guardamos a semente da rolagem por usuário.
_pictures_seeds = TTLCache(ttl_seconds=1800, max_entries=512)


@api_bp.route("/pictures", methods=["GET"])
@api_login_required
def pictures():
    """Grade só com posts de usuários (apps antigos). Agora ordenada pelo
    GOSTO de quem está vendo (vortex_taste), não pelo mais novo primeiro.
    `cursor` = deslocamento inteiro na lista ranqueada daquela rolagem."""
    viewer = current_api_user()
    offset = request.args.get("cursor", type=int)
    if offset:
        seed = _pictures_seeds.get(viewer.id) or viewer.id
    else:
        seed = vtaste.new_seed()
        _pictures_seeds.set(viewer.id, seed)
        offset = 0

    per_page = current_app.config["POSTS_PER_PAGE"]
    page = vtaste.ranked_page(
        current_app._get_current_object(), viewer.id,
        cursor=vtaste.format_cursor(seed, offset), include_items=False, page_size=per_page,
    )
    objs = vtaste.load_objects(page["keys"])
    tiles = [t for t in (
        _user_tile(objs[k], viewer) for k in page["keys"] if k in objs
    ) if t is not None]
    next_cursor = (offset + per_page) if page["has_next"] else None
    legacy = [{
        "key": t["key"], "post_id": t["post_id"], "media_url": t["media_url"],
        "media_type": t["media_type"], "author": t["author"], "created_at": t["created_at"],
        "is_temporary": t["is_temporary"], "expires_at": t["expires_at"],
        "seconds_remaining": t["seconds_remaining"],
    } for t in tiles]
    return jsonify({"tiles": legacy, "has_next": page["has_next"], "next_cursor": next_cursor})


# ---------------------------------------------------------------------------
# Vortex v2: posts de usuários + itens indexados pelo crawler
# ---------------------------------------------------------------------------
# `/pictures` (acima) continua igual, só com posts de usuários, pra manter
# apps antigos funcionando. `/vortex` é o endpoint novo: mistura os dois
# tipos de peça. Itens do crawler (tabela vortex_items) NUNCA aparecem no
# feed — só aqui.

_VORTEX_TYPES = ("photo", "gif", "video")


def serialize_vortex_profile(profile):
    return {
        "id": profile.id,
        "handle": profile.handle,
        "display_name": profile.display_name,
        "bio": profile.bio or "",
        "avatar_url": profile.avatar_url,
        "source_site": profile.source_site,
        "is_bot": True,
    }


def serialize_vortex_item(item, detail=False):
    """Peça do Vortex vinda do crawler. Mesmos campos-base de uma peça de
    usuário (key, media_url, media_type, created_at...) + os próprios."""
    data = {
        "key": f"c{item.id}",
        "source": "crawler",
        "item_id": item.id,
        "post_id": None,
        "media_url": item.media_url,
        "thumb_url": item.thumb_url,
        "media_type": item.media_type,
        "width": item.width,
        "height": item.height,
        "duration_seconds": item.duration_seconds,
        "title": item.title or "",
        "category": item.category,
        "profile": serialize_vortex_profile(item.profile),
        "author": None,
        "created_at": item.created_at.isoformat() + "Z",
        "is_temporary": False,
        "expires_at": None,
        "seconds_remaining": None,
    }
    if detail:
        data.update({
            "description": item.description or "",
            "tags": item.tag_list,
            # aparência (cores/luz) e, com CLIP, o que a imagem mostra
            "visual_tags": item.visual_tag_list,
            "source_url": item.source_url,
            "source_name": item.source_name,
            "license": item.license,
            "attribution": item.attribution,
        })
    return data


def _vortex_page_size():
    return current_app.config.get("VORTEX_PAGE_SIZE", 30)


# cursor composto da grade, consulta base e busca/similares/estatísticas
# vivem em vortex_search.py (a versão web do Vortex usa as mesmas funções)
_parse_vortex_cursor = vsearch.parse_grid_cursor
_format_vortex_cursor = vsearch.format_grid_cursor
_vortex_item_query = vsearch.item_query


def _user_tile(post, viewer, media_type=None):
    """Peça (dict da API) de um post de usuário; None se não tiver mídia visual."""
    types = (media_type,) if media_type else _VORTEX_TYPES
    media = next((m for m in post.display_media if m["media_type"] in types), None)
    if media is None:
        return None
    return {
        "key": f"{post.id}-0",
        "source": "user",
        "item_id": None,
        "post_id": post.id,
        "media_url": _upload_url(media["filename"]),
        "thumb_url": None,
        "media_type": media["media_type"],
        "width": None, "height": None, "duration_seconds": None,
        "title": "", "category": None,
        "profile": None,
        "author": serialize_user(post.author, viewer),
        "created_at": post.created_at.isoformat() + "Z",
        "is_temporary": post.is_temporary,
        "expires_at": post.expires_at.isoformat() + "Z" if post.is_temporary else None,
        "seconds_remaining": post.seconds_remaining if post.is_temporary else None,
    }


def _vortex_user_tiles(viewer, post_cursor, limit, media_type):
    """Peças de posts de usuários ainda ativos, mais novas primeiro. Só o
    caminho CRONOLÓGICO antigo usa isto (cursor legado `p..|c..`); a grade
    normal é ordenada por gosto em vortex_taste."""
    types = (media_type,) if media_type else _VORTEX_TYPES
    has_visual_media = Post.id.in_(
        db.session.query(PostMedia.post_id).filter(PostMedia.media_type.in_(types))
    )
    query = Post.query.filter(Post.expires_at > utcnow()).filter(
        db.or_(Post.post_type.in_(types), has_visual_media)
    )
    if post_cursor:
        query = query.filter(Post.id < post_cursor)
    posts = query.order_by(Post.id.desc()).limit(limit + 1).all()
    has_more = len(posts) > limit
    posts = posts[:limit]
    tiles = [t for t in (_user_tile(p, viewer, media_type) for p in posts) if t is not None]
    return tiles, has_more, (posts[-1].id if posts else None)


@api_bp.route("/vortex", methods=["GET"])
@api_login_required
def vortex():
    """Grade do Vortex ORDENADA POR GOSTO de quem vê (vortex_taste): itens do
    crawler e posts de usuários competem pela mesma nota — ninguém tem cota
    nem prioridade fixa. O app aprende com o que a pessoa abre/curte/busca e
    acompanha mudança de interesse; ~1 a cada 5 peças é exploração.
    Filtros: ?category=<slug> ?type=photo|gif|video (com `category`, só itens
    do crawler: posts de usuários não têm categoria). Rolagem infinita por
    `cursor` opaco (devolva `next_cursor` como veio). Cursor antigo
    (`p..|c..`, de apps que já estavam no meio da rolagem) continua no
    caminho cronológico antigo."""
    viewer = current_api_user()
    category = (request.args.get("category") or "").strip() or None
    media_type = (request.args.get("type") or "").strip() or None
    if media_type and media_type not in _VORTEX_TYPES:
        return jsonify({"error": "Tipo inválido. Use photo, gif ou video."}), 400
    valid_categories = {slug for slug, _ in current_app.config["VORTEX_CATEGORIES"]}
    if category and category not in valid_categories:
        return jsonify({"error": "Categoria inválida."}), 400

    raw_cursor = request.args.get("cursor")
    if raw_cursor and vtaste.parse_cursor(raw_cursor) is None:
        return _vortex_chronological(viewer, category, media_type, raw_cursor)

    page = vtaste.ranked_page(
        current_app._get_current_object(), viewer.id, cursor=raw_cursor,
        category=category, media_type=media_type, include_users=True,
    )
    objs = vtaste.load_objects(page["keys"])
    tiles = []
    for key in page["keys"]:
        obj = objs.get(key)
        if obj is None:
            continue
        if key.startswith("c"):
            tiles.append(serialize_vortex_item(obj))
        else:
            tile = _user_tile(obj, viewer, media_type)
            if tile is not None:
                tiles.append(tile)
    return jsonify({
        "tiles": tiles,
        "has_next": page["has_next"],
        "next_cursor": page["next_cursor"],
        # tempo contínuo no Vortex + sugestão de pausa (Parte 5; o app mostra o aviso)
        "wellbeing": vtaste.wellbeing(viewer.id, app=current_app),
    })


def _vortex_chronological(viewer, category, media_type, raw_cursor):
    """Caminho ANTIGO (cursor `p..|c..`): ~30 % posts de usuários + itens por
    id decrescente. Só existe pra não quebrar rolagens já em andamento."""
    import random

    post_cursor, item_cursor = _parse_vortex_cursor(raw_cursor)
    page_size = _vortex_page_size()

    user_tiles, user_has_more, last_post = [], False, None
    if not category:
        user_limit = max(1, round(page_size * 0.3))
        user_tiles, user_has_more, last_post = _vortex_user_tiles(
            viewer, post_cursor, user_limit, media_type
        )

    item_limit = max(1, page_size - len(user_tiles))
    query = _vortex_item_query(category, media_type)
    if item_cursor:
        query = query.filter(VortexItem.id < item_cursor)
    items = query.order_by(VortexItem.id.desc()).limit(item_limit + 1).all()
    item_has_more = len(items) > item_limit
    items = items[:item_limit]

    tiles = user_tiles + [serialize_vortex_item(i) for i in items]
    random.shuffle(tiles)

    next_post = last_post if last_post is not None else post_cursor
    next_item = items[-1].id if items else item_cursor
    has_next = user_has_more or item_has_more
    return jsonify({
        "tiles": tiles,
        "has_next": has_next,
        "next_cursor": _format_vortex_cursor(next_post, next_item) if has_next else None,
    })


@api_bp.route("/vortex/interact", methods=["POST"])
@api_login_required
def vortex_interact():
    """O app avisa o que a pessoa fez, pra o Vortex aprender o gosto dela.
    Corpo JSON: {"kind": "open|dwell|like|less", "item_id": 12} ou
    {"kind": ..., "post_id": 7}. Abrir o detalhe de uma peça do crawler
    (`GET /vortex/item/<id>`) já conta como `open` sozinho; use esta rota
    para posts de usuários, para `dwell` (tempo olhando), `like` e `less`
    ("menos disso" — derruba a afinidade)."""
    viewer = current_api_user()
    data = request.get_json(silent=True) or {}
    kind = (data.get("kind") or "").strip()
    undo = kind == "undo_less"     # desfaz o "menos disso"
    if (kind not in vtaste.VALID_KINDS and not undo) or kind == "search":
        return jsonify({"error": "kind inválido. Use open, dwell, like, less ou undo_less."}), 400
    item_id, post_id = data.get("item_id"), data.get("post_id")
    if isinstance(item_id, int):
        item = VortexItem.query.get(item_id)
        if item is None:
            return jsonify({"error": "Peça não encontrada."}), 404
        recorded = (vtaste.undo_less(viewer.id, item=item) if undo
                    else vtaste.record(viewer.id, kind, item=item))
    elif isinstance(post_id, int):
        post = Post.query.get(post_id)
        if post is None:
            return jsonify({"error": "Post não encontrado."}), 404
        recorded = (vtaste.undo_less(viewer.id, post=post) if undo
                    else vtaste.record(viewer.id, kind, post=post))
    else:
        return jsonify({"error": "Informe item_id ou post_id."}), 400
    return jsonify({"ok": True, "recorded": bool(recorded)})


@api_bp.route("/vortex/seen", methods=["POST"])
@api_login_required
def vortex_seen():
    """O app avisa quais peças ficaram VISÍVEIS na tela (>= ~0,6 s), em lote,
    pra o Vortex não mostrá-las de novo (livro de vistos, vortex_seen.py).
    Corpo: {"keys": ["c12", "p7", ...]} (até 200; o formato é o de `PictureTile`:
    "c<item_id>" no crawler e "p<post_id>" em post de usuário). Fire-and-forget."""
    data = request.get_json(silent=True) or {}
    keys = data.get("keys")
    if not isinstance(keys, list):
        return jsonify({"error": "Envie {\"keys\": [...]}."}), 400
    n = vseen.mark_viewed(current_api_user().id, keys)
    return jsonify({"ok": True, "recorded": n})


@api_bp.route("/vortex/recent", methods=["GET"])
@api_login_required
def vortex_recent():
    """Peças do Vortex que ESTA pessoa abriu/curtiu há pouco, a mais recente
    primeiro e sem repetir (faixa \"Vistos recentemente\"). `?limit=` (1-40,
    padrão 20) e `?type=photo|gif|video`. Mesmo formato de peça de /vortex."""
    media_type = (request.args.get("type") or "").strip() or None
    if media_type and media_type not in _VORTEX_TYPES:
        return jsonify({"error": "Tipo inválido. Use photo, gif ou video."}), 400
    limit = max(1, min(40, request.args.get("limit", 20, type=int) or 20))
    items = vtaste.recent_items(current_api_user().id, limit=limit, media_type=media_type)
    return jsonify({"tiles": [serialize_vortex_item(i) for i in items]})


@api_bp.route("/vortex/item/<int:item_id>", methods=["GET"])
@api_login_required
def vortex_item(item_id):
    item = VortexItem.query.get_or_404(item_id)
    if not item.is_active or not item.profile.is_active:
        return jsonify({"error": "Este item não está mais disponível."}), 404
    # abrir o detalhe É o clique: alimenta o gosto do usuário
    vtaste.record(current_api_user().id, "open", item=item)
    data = {"item": serialize_vortex_item(item, detail=True)}
    if request.args.get("related", "1") != "0":
        data["related"] = _related_payload(item, 0)
    return jsonify(data)


def _related_payload(item, offset):
    result = vsearch.related_items(current_app._get_current_object(), item, offset=offset)
    return {
        "tiles": [serialize_vortex_item(i) for i in result["items"]],
        "has_next": result["has_next"],
        "next_cursor": result["next_cursor"],
    }


@api_bp.route("/vortex/item/<int:item_id>/related", methods=["GET"])
@api_login_required
def vortex_item_related(item_id):
    """\"Mais como este\": peças parecidas (tags, imagem, título, categoria).
    Rolagem infinita por `cursor` opaco (\"o30\")."""
    item = VortexItem.query.get_or_404(item_id)
    if not item.is_active or not item.profile.is_active:
        return jsonify({"error": "Este item não está mais disponível."}), 404
    offset = vsearch.parse_offset_cursor(request.args.get("cursor"))
    return jsonify(_related_payload(item, offset))


def _vortex_filters():
    """Lê e valida ?category= e ?type=. Devolve (category, media_type, erro_response)."""
    category = (request.args.get("category") or "").strip() or None
    media_type = (request.args.get("type") or "").strip() or None
    if media_type and media_type not in _VORTEX_TYPES:
        return None, None, (jsonify({"error": "Tipo inválido. Use photo, gif ou video."}), 400)
    valid = {slug for slug, _ in current_app.config["VORTEX_CATEGORIES"]}
    if category and category not in valid:
        return None, None, (jsonify({"error": "Categoria inválida."}), 400)
    return category, media_type, None


@api_bp.route("/vortex/search", methods=["GET"])
@api_login_required
def vortex_search_endpoint():
    """Busca por texto nos itens do Vortex (título, tags, descrição, categoria).
    ?q= (obrigatório) &category= &type= &cursor=. Posts de usuários não entram
    (não têm texto indexável). `mode`: fts|like; `relaxed`: true quando nenhuma
    peça tinha TODAS as palavras e foram mostradas as que têm ALGUMA."""
    q = (request.args.get("q") or "").strip()
    category, media_type, error = _vortex_filters()
    if error:
        return error
    if not vsearch.tokenize_query(q):
        return jsonify({"error": "Digite pelo menos 2 letras para buscar."}), 400
    offset = vsearch.parse_offset_cursor(request.args.get("cursor"))
    result = vsearch.search_items(
        current_app._get_current_object(), q, category=category, media_type=media_type, offset=offset
    )
    if offset == 0 and result["total"]:
        # o que a pessoa procura também é gosto (as palavras viram interesse em tags)
        vtaste.record(current_api_user().id, "search", query=q)
    return jsonify({
        "query": q,
        "tiles": [serialize_vortex_item(i) for i in result["items"]],
        "total": result["total"],
        "total_capped": result["capped"],
        "has_next": result["has_next"],
        "next_cursor": result["next_cursor"],
        "mode": result["mode"],
        "relaxed": result["relaxed"],
    })


@api_bp.route("/vortex/stats", methods=["GET"])
@api_login_required
def vortex_stats_endpoint():
    """Números do Vortex: quantas fotos/GIFs/vídeos (crawler + posts de
    usuários), quantos perfis e a contagem por categoria (só crawler)."""
    return jsonify(vsearch.vortex_stats(current_app._get_current_object()))


@api_bp.route("/vortex/categories", methods=["GET"])
@api_login_required
def vortex_categories_endpoint():
    """Categorias com contagem (total e por tipo), da maior pra menor. Só as
    que têm itens; `?all=1` inclui as vazias. `?category=<slug>` faz o bloco
    `types` valer só pra essa categoria."""
    category = (request.args.get("category") or "").strip() or None
    valid = {slug for slug, _ in current_app.config["VORTEX_CATEGORIES"]}
    if category and category not in valid:
        return jsonify({"error": "Categoria inválida."}), 400
    include_empty = request.args.get("all") == "1"
    return jsonify(vsearch.vortex_categories(
        current_app._get_current_object(), category=category, include_empty=include_empty
    ))


@api_bp.route("/vortex/profile/<handle>", methods=["GET"])
@api_login_required
def vortex_profile(handle):
    profile = VortexProfile.query.filter_by(handle=handle.lower(), is_active=True).first_or_404()
    media_type = (request.args.get("type") or "").strip() or None
    category = (request.args.get("category") or "").strip() or None
    if media_type and media_type not in _VORTEX_TYPES:
        return jsonify({"error": "Tipo inválido. Use photo, gif ou video."}), 400
    cursor = request.args.get("cursor", type=int)
    page_size = _vortex_page_size()

    query = _vortex_item_query(category, media_type).filter(VortexItem.profile_id == profile.id)
    if cursor:
        query = query.filter(VortexItem.id < cursor)
    items = query.order_by(VortexItem.id.desc()).limit(page_size + 1).all()
    has_next = len(items) > page_size
    items = items[:page_size]

    counts = dict(
        db.session.query(VortexItem.media_type, db.func.count(VortexItem.id))
        .filter(VortexItem.profile_id == profile.id, VortexItem.is_active.is_(True))
        .group_by(VortexItem.media_type).all()
    )
    data = {
        "profile": serialize_vortex_profile(profile),
        "counts": {
            "photos": counts.get("photo", 0),
            "gifs": counts.get("gif", 0),
            "videos": counts.get("video", 0),
            "total": sum(counts.values()),
        },
        "tiles": [serialize_vortex_item(i) for i in items],
        "has_next": has_next,
        "next_cursor": items[-1].id if (items and has_next) else None,
    }
    return jsonify(data)


# ---------------------------------------------------------------------------
# Notícias
# ---------------------------------------------------------------------------
# Mesma fonte de dados e mesmo algoritmo de recomendação da versão web
# (news.py / news_recommender.py) — só a saída que troca de HTML pra
# JSON. O "mosaico" (tiles grande/largo/alto/normal) é decidido aqui no
# servidor (campo tile_size de cada artigo), pra manter os apps e o site
# sempre com o mesmo ritmo de layout.

@api_bp.route("/news", methods=["GET"])
@api_login_required
def news_feed():
    user = current_api_user()
    cfg = current_app.config
    page_size = cfg["NEWS_PER_PAGE"]

    category_filter = request.args.get("categoria") or None
    valid_categories = {key for key, _ in cfg["NEWS_CATEGORIES"]}
    if category_filter not in valid_categories:
        category_filter = None

    offset = request.args.get("offset", 0, type=int)
    # ids já recebidos pelo app nesta sessão de rolagem — mesma função que
    # tem no site (evita repetir/pular notícia se a pontuação mudar entre
    # uma chamada e outra da rolagem infinita)
    vistos_raw = request.args.get("vistos", "")
    exclude_ids = {int(v) for v in vistos_raw.split(",") if v.strip().isdigit()}

    articles, has_next = recommended_articles(
        user, limit=page_size, category_filter=category_filter, exclude_ids=exclude_ids,
    )
    tiles = _build_tiles(articles, start_index=offset)

    user_interests = [
        i.category for i in NewsInterest.query.filter_by(user_id=user.id).all()
    ]

    return jsonify({
        "articles": [serialize_news_article(a, size) for a, size in tiles],
        "has_next": has_next,
        "next_offset": offset + page_size,
        "categories": [{"key": k, "label": l} for k, l in cfg["NEWS_CATEGORIES"]],
        "user_interests": user_interests,
    })


@api_bp.route("/news/interests", methods=["GET"])
@api_login_required
def get_news_interests():
    cfg = current_app.config
    user = current_api_user()
    current_categories = {
        i.category for i in NewsInterest.query.filter_by(user_id=user.id).all()
    }
    return jsonify({
        "categories": [{"key": k, "label": l} for k, l in cfg["NEWS_CATEGORIES"]],
        "selected": sorted(current_categories),
    })


@api_bp.route("/news/interests", methods=["POST"])
@api_login_required
def update_news_interests():
    cfg = current_app.config
    user = current_api_user()
    valid_categories = {key for key, _ in cfg["NEWS_CATEGORIES"]}

    data = request.get_json(silent=True) or {}
    selected = {c for c in (data.get("categories") or []) if c in valid_categories}

    NewsInterest.query.filter_by(user_id=user.id).delete()
    for key in selected:
        db.session.add(NewsInterest(user_id=user.id, category=key))
    db.session.commit()

    return jsonify({"selected": sorted(selected)})


@api_bp.route("/news/<int:article_id>/abrir", methods=["POST"])
@api_login_required
def open_news_article(article_id):
    """Registra o clique (mesmo sinal usado pelo recomendador) e devolve a
    URL de origem — o app é quem abre no navegador do aparelho, já que
    (diferente do site) não faz sentido um redirect HTTP aqui."""
    user = current_api_user()
    article = NewsArticle.query.get_or_404(article_id)
    article.clicks_count += 1
    db.session.add(NewsInteraction(
        user_id=user.id,
        article_id=article.id,
        category=article.category,
        created_at=utcnow(),
    ))
    db.session.commit()
    return jsonify({"url": article.url})


# ---------------------------------------------------------------------------
# Ranking
# ---------------------------------------------------------------------------

@api_bp.route("/ranking", methods=["GET"])
@api_login_required
def ranking():
    limit = request.args.get("limit", 50, type=int)
    limit = max(1, min(limit, 200))

    users = sorted(
        User.query.filter_by(is_banned=False).all(),
        key=lambda u: u.ranking_score, reverse=True,
    )[:limit]

    return jsonify({
        "users": [serialize_ranking_entry(u, rank) for rank, u in enumerate(users, start=1)]
    })


# ---------------------------------------------------------------------------
# Busca
# ---------------------------------------------------------------------------

@api_bp.route("/search", methods=["GET"])
@api_login_required
def search():
    viewer = current_api_user()
    q = (request.args.get("q") or "").strip()
    users = []
    if q:
        like = f"%{q}%"
        users = (
            User.query.filter(
                User.is_banned.is_(False),
                db.or_(User.username.ilike(like), User.display_name.ilike(like), User.bio.ilike(like)),
            )
            .order_by(User.username.asc())
            .limit(50)
            .all()
        )
    return jsonify({"users": [serialize_user(u, viewer) for u in users]})


# Fase 11: rotas de chamadas (sinalização). Fica no fim: precisa de `api_bp` e dos decorators acima.
import api_calls  # noqa: E402,F401
import api_widgets  # noqa: E402,F401  (painel lateral: clima e sugestões)
