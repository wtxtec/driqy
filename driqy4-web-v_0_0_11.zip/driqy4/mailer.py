"""
Envio de e-mail via SMTP (recuperação de senha, e outros avisos futuros).

Usa só a biblioteca padrão do Python (smtplib) — não adiciona nenhuma
dependência nova ao projeto. As credenciais vêm de variáveis de ambiente
(veja MAIL_* em config.py), nunca ficam hardcoded.

Se o SMTP não estiver configurado (ambiente de desenvolvimento, por
exemplo), o e-mail não é enviado de verdade: o conteúdo é só impresso no
console, pra dar pra testar o fluxo de "esqueci minha senha" sem precisar
configurar um servidor de e-mail.
"""
import smtplib
import ssl
from email.message import EmailMessage

from flask import current_app


def is_mail_configured():
    cfg = current_app.config
    return bool(cfg.get("MAIL_SERVER") and cfg.get("MAIL_USERNAME") and cfg.get("MAIL_PASSWORD"))


def send_email(to_addr, subject, text_body, html_body=None):
    """
    Envia um e-mail simples (texto + HTML opcional). Retorna True se
    enviou (ou simulou o envio em modo dev), False se houve erro real.
    """
    cfg = current_app.config

    if not is_mail_configured():
        # Modo desenvolvimento: sem SMTP configurado, só mostra no console
        # pra não travar o fluxo durante os testes locais.
        print("\n----- E-MAIL (modo dev, SMTP não configurado) -----")
        print(f"Para: {to_addr}")
        print(f"Assunto: {subject}")
        print(text_body)
        print("----------------------------------------------------\n")
        return True

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = cfg["MAIL_DEFAULT_SENDER"]
    msg["To"] = to_addr
    msg.set_content(text_body)
    if html_body:
        msg.add_alternative(html_body, subtype="html")

    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(cfg["MAIL_SERVER"], cfg["MAIL_PORT"], timeout=15) as server:
            if cfg.get("MAIL_USE_TLS"):
                server.starttls(context=context)
            server.login(cfg["MAIL_USERNAME"], cfg["MAIL_PASSWORD"])
            server.send_message(msg)
        return True
    except Exception as e:
        current_app.logger.error(f"Falha ao enviar e-mail para {to_addr}: {e}")
        return False


def send_password_reset_email(user, reset_url):
    site_name = current_app.config["SITE_NAME"]
    expires = current_app.config["PASSWORD_RESET_EXPIRES_MINUTES"]

    text_body = (
        f"Olá, {user.username}!\n\n"
        f"Recebemos um pedido para redefinir a senha da sua conta no {site_name}.\n"
        f"Se foi você, clique no link abaixo para escolher uma nova senha "
        f"(válido por {expires} minutos):\n\n"
        f"{reset_url}\n\n"
        f"Se você não pediu isso, pode ignorar este e-mail — sua senha continua a mesma.\n"
    )
    html_body = f"""
      <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto; color:#1a1420;">
        <h2 style="margin-bottom: 4px;">{site_name}</h2>
        <p>Olá, <strong>{user.username}</strong>!</p>
        <p>Recebemos um pedido para redefinir a senha da sua conta.
           Se foi você, clique no botão abaixo para escolher uma nova senha
           (o link vale por {expires} minutos):</p>
        <p style="text-align:center; margin: 28px 0;">
          <a href="{reset_url}"
             style="background:#e85d75; color:#fff; text-decoration:none; padding:12px 24px;
                    border-radius:999px; font-weight:bold; display:inline-block;">
            Redefinir senha
          </a>
        </p>
        <p style="font-size: 0.85em; color:#666;">
          Se o botão não funcionar, copie e cole este link no navegador:<br>
          <a href="{reset_url}">{reset_url}</a>
        </p>
        <p style="font-size: 0.85em; color:#666;">
          Se você não pediu isso, pode ignorar este e-mail — sua senha continua a mesma.
        </p>
      </div>
    """
    return send_email(user.email, f"Redefinir sua senha — {site_name}", text_body, html_body)
