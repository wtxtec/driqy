import hashlib
import os
import threading

import requests
from flask import (
    Blueprint, render_template, redirect, url_for, flash, request,
    current_app, jsonify, send_file, abort
)
from flask_login import login_required, current_user

from extensions import db
from models import NewsArticle, NewsInterest, NewsInteraction, utcnow
from news_recommender import recommended_articles

news_bp = Blueprint("news", __name__, url_prefix="/noticias")

# Muitos veículos bloqueiam "hotlink" (carregar a imagem deles direto de
# outro site) checando o cabeçalho Referer/User-Agent do navegador — é a
# causa mais comum de card sem imagem mesmo com image_url salvo no banco
# (a foto existe, o navegador do usuário que não consegue baixar ela
# direto do CDN do veículo). Por isso as imagens de notícia passam por
# essa rota: o SERVIDOR busca a imagem (com um User-Agent normal e o
# Referer sendo a própria matéria de origem, que qualquer proteção de
# hotlink aceita) e guarda em cache em disco, servindo os pedidos
# seguintes direto do cache — sem repetir a requisição externa toda vez.
_IMG_PROXY_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)
_IMG_PROXY_TIMEOUT = 6
_IMG_PROXY_MAX_BYTES = 8 * 1024 * 1024  # 8MB, generoso pra foto de capa


def _img_cache_dir():
    path = os.path.join(current_app.instance_path, "news_img_cache")
    os.makedirs(path, exist_ok=True)
    return path


def _img_cache_paths(image_url):
    key = hashlib.sha256(image_url.encode("utf-8")).hexdigest()
    base = os.path.join(_img_cache_dir(), key)
    return base + ".bin", base + ".ct"


def _fetch_and_cache_image(image_url, source_page_url):
    """Baixa a imagem original pro cache em disco. Retorna (caminho_bin,
    content_type) ou None se não deu pra baixar (tipo inválido, erro de
    rede, arquivo grande demais etc.)."""
    bin_path, ct_path = _img_cache_paths(image_url)
    try:
        resp = requests.get(
            image_url,
            headers={
                "User-Agent": _IMG_PROXY_USER_AGENT,
                "Referer": source_page_url or image_url,
                "Accept": "image/avif,image/webp,image/*,*/*;q=0.8",
            },
            timeout=_IMG_PROXY_TIMEOUT,
            stream=True,
        )
        resp.raise_for_status()
        content_type = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        # aceita qualquer "image/*" reportado pelo servidor de origem — não
        # existe uma lista fixa de subtipos porque isso rejeitaria formato
        # válido mas incomum (ex.: image/avif, image/svg+xml) sem necessidade;
        # o filtro real é só "não é imagem" (ex.: página de erro HTML)
        if not content_type.startswith("image/"):
            return None
        total = 0
        with open(bin_path, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=65536):
                total += len(chunk)
                if total > _IMG_PROXY_MAX_BYTES:
                    fh.close()
                    os.remove(bin_path)
                    return None
                fh.write(chunk)
        with open(ct_path, "w") as fh:
            fh.write(content_type)
        return bin_path, content_type
    except Exception:
        return None
    finally:
        try:
            resp.close()
        except Exception:
            pass

# Layout em lista (3 colunas no desktop, 1 no celular): todos os cards têm
# o MESMO tamanho. O mosaico antigo (large/wide/tall) foi desligado — o campo
# tile_size continua existindo na API e no template só por compatibilidade
# com apps antigos, mas agora é sempre "normal".
_TILE_PATTERN = ["normal"]


def _tile_size(global_index):
    return _TILE_PATTERN[global_index % len(_TILE_PATTERN)]


def _build_tiles(articles, start_index):
    return [(article, _tile_size(start_index + i)) for i, article in enumerate(articles)]


@news_bp.route("/")
def feed():
    page_size = current_app.config["NEWS_PER_PAGE"]
    category_filter = request.args.get("categoria") or None
    valid_categories = {key for key, _ in current_app.config["NEWS_CATEGORIES"]}
    if category_filter not in valid_categories:
        category_filter = None

    articles, has_next = recommended_articles(
        current_user, limit=page_size, category_filter=category_filter
    )

    user_interests = set()
    if current_user.is_authenticated:
        user_interests = {
            i.category for i in NewsInterest.query.filter_by(user_id=current_user.id).all()
        }

    return render_template(
        "news_feed.html",
        tiles=_build_tiles(articles, start_index=0),
        has_next=has_next,
        next_offset=page_size,
        categories=current_app.config["NEWS_CATEGORIES"],
        category_filter=category_filter,
        user_interests=user_interests,
    )


@news_bp.route("/api/mais")
def more():
    page_size = current_app.config["NEWS_PER_PAGE"]
    offset = request.args.get("offset", 0, type=int)
    category_filter = request.args.get("categoria") or None
    valid_categories = {key for key, _ in current_app.config["NEWS_CATEGORIES"]}
    if category_filter not in valid_categories:
        category_filter = None

    # ids já renderizados na página (mandados pelo front-end) — evita
    # duplicar/pular notícia se a pontuação mudar entre uma chamada e
    # outra da rolagem infinita (ver docstring de recommended_articles)
    vistos_raw = request.args.get("vistos", "")
    exclude_ids = {int(v) for v in vistos_raw.split(",") if v.strip().isdigit()}

    articles, has_next = recommended_articles(
        current_user, limit=page_size,
        category_filter=category_filter, exclude_ids=exclude_ids,
    )
    html = [
        render_template("_news_card.html", article=article, size=size)
        for article, size in _build_tiles(articles, start_index=offset)
    ]
    return jsonify({
        "articles": html,
        "has_next": has_next,
        "next_offset": offset + page_size,
    })


# larguras que o proxy serve (evita gerar infinitas variantes em cache).
# 480 = celular, 800 = card do desktop, 1200 = telas retina/capa grande.
_IMG_ALLOWED_WIDTHS = (480, 800, 1200)
_IMG_DEFAULT_WIDTH = 1200
# abaixo disso (bytes) uma imagem que já cabe na largura pedida é servida
# como veio, sem recodificar (recodificar pequena só perde qualidade)
_IMG_KEEP_ORIGINAL_BYTES = 350 * 1024


def _pick_width(requested):
    """Menor largura permitida que atende o pedido (ou a maior possível)."""
    if not requested:
        return _IMG_DEFAULT_WIDTH
    for w in _IMG_ALLOWED_WIDTHS:
        if requested <= w:
            return w
    return _IMG_ALLOWED_WIDTHS[-1]


def _resized_variant(image_url, bin_path, content_type, width):
    """Versão redimensionada (WebP, LANCZOS, qualidade 84) da imagem em
    cache, ou None pra servir o original. Antes o card baixava a foto
    original inteira (até 8MB) e o navegador a encolhia — lento no
    celular e, em fotos pequenas esticadas, borrado; aqui a gente entrega
    o tamanho certo e nítido. Nunca amplia (ampliar só borra)."""
    if content_type in ("image/svg+xml", "image/gif"):
        return None
    base, _ = _img_cache_paths(image_url)
    base = base[:-len(".bin")]
    variant_path = f"{base}_{width}.webp"
    if os.path.exists(variant_path):
        return variant_path, "image/webp"
    try:
        from PIL import Image, ImageOps
        with Image.open(bin_path) as im:
            im = ImageOps.exif_transpose(im)
            fits = im.width <= width
            if fits and os.path.getsize(bin_path) <= _IMG_KEEP_ORIGINAL_BYTES:
                return None
            if not fits:
                new_h = max(1, round(im.height * width / im.width))
                im = im.resize((width, new_h), Image.LANCZOS)
            if im.mode not in ("RGB", "RGBA"):
                im = im.convert("RGB")
            tmp_path = f"{variant_path}.{os.getpid()}.{threading.get_ident()}.tmp"
            im.save(tmp_path, "WEBP", quality=84, method=4)
        os.replace(tmp_path, variant_path)
        return variant_path, "image/webp"
    except Exception:
        # formato que o Pillow não abre (ex.: AVIF sem plugin), arquivo
        # truncado etc. — serve o original e deixa o navegador decidir
        return None


def _heal_image_url(article):
    """Se a URL de capa salva não baixa mais (foto trocada, miniatura
    removida, versão "promovida" que o CDN não tem), tenta achar a capa
    de novo na própria matéria. Limitado por image_fetch_attempts pra não
    repetir isso pra sempre numa imagem que nunca vai existir."""
    from news_indexer import _fetch_og_image
    if article.image_fetch_attempts >= 3:
        return None
    article.image_fetch_attempts += 1
    new_url = _fetch_og_image(article.url)
    if new_url and new_url != article.image_url:
        article.image_url = new_url[:700]
        db.session.commit()
        return _fetch_and_cache_image(article.image_url, article.url)
    db.session.commit()
    return None


@news_bp.route("/<int:article_id>/imagem")
def article_image(article_id):
    """Serve a imagem de capa da notícia através do nosso servidor (ver
    comentário acima do blueprint), com cache em disco e no tamanho
    pedido (?w=480|800|1200, padrão 1200). Se não tiver imagem ou o
    download falhar, devolve 404 — o <img> do card cai no tile de cor
    sólida da categoria."""
    article = NewsArticle.query.get_or_404(article_id)
    if not article.image_url:
        abort(404)
    width = _pick_width(request.args.get("w", type=int))

    bin_path, ct_path = _img_cache_paths(article.image_url)
    if os.path.exists(bin_path) and os.path.exists(ct_path):
        with open(ct_path) as fh:
            content_type = fh.read().strip()
    else:
        result = _fetch_and_cache_image(article.image_url, article.url)
        if not result:
            result = _heal_image_url(article)
        if not result:
            abort(404)
        bin_path, content_type = result

    served_path, served_type = bin_path, content_type
    variant = _resized_variant(article.image_url, bin_path, content_type, width)
    if variant:
        served_path, served_type = variant

    response = send_file(served_path, mimetype=served_type, conditional=True)
    response.headers["Cache-Control"] = "public, max-age=604800, immutable"
    return response


@news_bp.route("/<int:article_id>/abrir")
def open_article(article_id):
    """Registra o clique (sinal usado pelo recomendador) e manda pro site
    de origem — o conteúdo completo da notícia nunca é servido por aqui."""
    article = NewsArticle.query.get_or_404(article_id)
    article.clicks_count += 1
    if current_user.is_authenticated:
        db.session.add(NewsInteraction(
            user_id=current_user.id,
            article_id=article.id,
            category=article.category,
            created_at=utcnow(),
        ))
    db.session.commit()
    return redirect(article.url)


@news_bp.route("/interesses", methods=["GET", "POST"])
@login_required
def interests():
    categories = current_app.config["NEWS_CATEGORIES"]

    if request.method == "POST":
        selected = set(request.form.getlist("categorias"))
        NewsInterest.query.filter_by(user_id=current_user.id).delete()
        for key, _label in categories:
            if key in selected:
                db.session.add(NewsInterest(user_id=current_user.id, category=key))
        db.session.commit()
        flash("Seus interesses foram atualizados.", "success")
        return redirect(url_for("news.interests"))

    current_categories = {
        i.category for i in NewsInterest.query.filter_by(user_id=current_user.id).all()
    }
    return render_template(
        "news_interests.html", categories=categories, current_categories=current_categories
    )
