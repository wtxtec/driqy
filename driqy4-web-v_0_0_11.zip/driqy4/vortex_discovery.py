"""
Descoberta de fontes do Vortex: o motor vasculha a web sozinho e cada site
novo que aparece vira fonte — sem depender de uma lista fixa.

Como funciona
-------------
  sementes    Config.VORTEX_DISCOVERY_SEEDS + feeds das fontes de notícias +
              URLs que o admin cadastrar (`add_seeds`).
  fronteira   tabela `vortex_frontier`: URLs a visitar (persistente: reiniciar
              o app não perde a fila). Páginas visitadas ficam `done`.
  domínios    tabela `vortex_domains`: cada site tem intervalo próprio (o
              Crawl-delay do robots.txt, ou VORTEX_DISCOVERY_PAGE_INTERVAL),
              orçamento de páginas por hora e teto de itens
              (VORTEX_DISCOVERY_MAX_ITEMS_PER_DOMAIN). A escolha da próxima
              página é ROUND-ROBIN entre domínios: um site gigante não engole
              a fila, e é isso que dá diversidade.
  cada página  -> imagens/vídeos viram candidatos e passam pelo MESMO pipeline
                  das demais fontes (filtros, dHash, assinatura visual, gravador);
               -> `<link rel="alternate">` de feed vira uma fonte `rss`
                  automática (origem "auto"), reexaminada pelo motor depois;
               -> links do mesmo site entram na fronteira (profundidade+1);
               -> links pra outros sites criam domínios novos (profundidade 0).
  sitemaps    URLs do `Sitemap:` do robots.txt entram na fronteira; as tags
              <image:loc> viram candidatos direto.

Regras de boa conduta e segurança
---------------------------------
  - robots.txt respeitado (e <meta robots noindex/noimageindex>, X-Robots-Tag);
  - páginas marcadas como adultas (RTA / meta rating) e termos bloqueados saem;
  - só hosts públicos (anti-SSRF, ver vortex_net.py), redirecionamentos
    conferidos um a um, tamanho máximo por página, tipos de conteúdo filtrados;
  - denylist de domínios + bloqueio pelo admin (esconde os itens do site).
  - guardamos só a URL (hotlink) + o host de origem; licença só quando a
    página a declara (rel="license"). Veja VORTEX_DISCOVERY_ONLY_LICENSED.
"""
import hashlib
import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from datetime import timedelta
from html import unescape
from html.parser import HTMLParser
from types import SimpleNamespace
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

from sqlalchemy.exc import IntegrityError, OperationalError

from models import (
    NewsSource, VortexCrawlSource, VortexDomain, VortexFrontier, VortexItem,
    VortexProfile, utcnow,
)
import vortex_queue as vq
from vortex_net import UnsafeHost, check_url

log = logging.getLogger("vortex_discovery")

_SKIP_EXT = {
    "pdf", "zip", "rar", "7z", "gz", "tar", "exe", "dmg", "apk", "iso", "mp3", "wav", "ogg",
    "flac", "avi", "mov", "mkv", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "css", "js",
    "json", "woff", "woff2", "ttf", "eot", "ico", "svg", "xml_",
}
_IMG_EXT = {"jpg", "jpeg", "png", "webp", "gif"}
_TRACKING_PARAMS = {"fbclid", "gclid", "msclkid", "mc_cid", "mc_eid", "igshid", "ref", "ref_src"}
_TOKEN_RE = re.compile(r"[a-z0-9]+")
_LOC_RE = re.compile(r"<(?:\w+:)?loc>\s*(?:<!\[CDATA\[)?\s*([^<\]\s][^<\]]*?)\s*(?:\]\]>)?\s*</(?:\w+:)?loc>",
                     re.IGNORECASE)
_IMAGE_BLOCK_RE = re.compile(r"<image:image>(.*?)</image:image>", re.IGNORECASE | re.DOTALL)
_IMAGE_TITLE_RE = re.compile(r"<image:title>\s*(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?\s*</image:title>",
                             re.IGNORECASE | re.DOTALL)
_SRCSET_RE = re.compile(r"\s*([^\s,]+)(?:\s+(\d+)w)?\s*(?:,|$)")


# ---------------------------------------------------------------------------
# URLs
# ---------------------------------------------------------------------------

def normalize_url(url, base=None, max_len=500):
    """URL canônica (sem fragmento, sem parâmetros de rastreio, porta padrão
    removida) ou None se não for http(s) válida."""
    try:
        full = urljoin(base, url.strip()) if base else url.strip()
        parts = urlparse(full)
    except ValueError:
        return None
    if parts.scheme not in ("http", "https") or not parts.hostname:
        return None
    host = parts.hostname.lower()
    try:
        port = parts.port
    except ValueError:
        return None
    if port and not ((parts.scheme == "http" and port == 80) or (parts.scheme == "https" and port == 443)):
        host = f"{host}:{port}"
    query = urlencode([(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
                       if not k.lower().startswith("utm_") and k.lower() not in _TRACKING_PARAMS])
    out = urlunparse((parts.scheme, host, parts.path or "/", "", query, ""))
    return out if len(out) <= max_len else None


def host_key(url):
    """Chave do domínio: host (+ porta se não padrão), minúsculo, sem 'www.'."""
    netloc = urlparse(url).netloc.lower()
    return netloc[4:] if netloc.startswith("www.") else netloc


def is_denied_host(host, denylist):
    bare = host.split(":")[0]
    return any(bare == d or bare.endswith("." + d) for d in denylist)


def url_has_blocked_terms(url, terms):
    tokens = set(_TOKEN_RE.findall(url.lower()))
    return bool(tokens & set(terms))


def should_follow(url, cfg):
    """Vale a pena colocar este link na fronteira?"""
    ext = urlparse(url).path.rsplit(".", 1)[-1].lower() if "." in urlparse(url).path.rsplit("/", 1)[-1] else ""
    if ext in _SKIP_EXT or ext in _IMG_EXT:
        return False
    host = host_key(url)
    if is_denied_host(host, cfg.get("VORTEX_DOMAIN_DENYLIST", ())):
        return False
    return not url_has_blocked_terms(url, cfg.get("VORTEX_URL_BLOCK_TERMS", ()))


# ---------------------------------------------------------------------------
# parser de páginas (stdlib: HTMLParser tolera HTML quebrado)
# ---------------------------------------------------------------------------

class _Collector(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.metas, self.links, self.anchors, self.imgs, self.videos = [], [], [], [], []
        self.title, self._in_title = "", False

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "meta":
            self.metas.append(a)
        elif tag == "link":
            self.links.append(a)
        elif tag == "a" and a.get("href"):
            self.anchors.append(a["href"])
        elif tag == "img":
            self.imgs.append(a)
        elif tag in ("video", "source") and (a.get("src") or a.get("poster")):
            self.videos.append(dict(a, _tag=tag))
        elif tag == "title":
            self._in_title = True

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title and len(self.title) < 300:
            self.title += data


def _largest_srcset(value):
    best, best_w = None, -1
    for url, width in _SRCSET_RE.findall(value or ""):
        w = int(width) if width else 0
        if url and w >= best_w:
            best, best_w = url, w
    return best


def _dim(value):
    return int(value) if value and value.isdigit() else None


def _bad_media_url(url, bad_hints):
    low = url.lower()
    return low.startswith("data:") or low.split("?")[0].endswith(".svg") or any(h in low for h in bad_hints)


def parse_page(html, base_url, cfg, bad_hints=()):
    """Extrai de uma página: título, flags de robots, licença, feeds, links e
    candidatos de mídia. Devolve SimpleNamespace."""
    col = _Collector()
    try:
        col.feed(html)
    except Exception:  # HTML muito quebrado: usa o que deu pra ler
        pass
    meta = {}
    robots_flags, adult = set(), False
    for m in col.metas:
        key = (m.get("property") or m.get("name") or m.get("itemprop") or "").lower()
        content = m.get("content", "")
        if not key or not content:
            continue
        meta.setdefault(key, []).append(content)
        if key in ("robots", "googlebot", "driqyvortexbot"):
            robots_flags.update(x.strip().lower() for x in content.split(","))
        if key == "rating" and (content.lower() in ("adult", "mature", "18+") or "rta-5042" in content.lower()):
            adult = True
    first = lambda k: (meta.get(k) or [""])[0]
    title = unescape(first("og:title") or col.title or "").strip()[:300]
    description = unescape(first("og:description") or first("description")).strip()[:600]
    tags = []
    for key in ("keywords", "news_keywords"):
        for content in meta.get(key, []):
            tags += [t.strip() for t in content.split(",") if t.strip()]
    tags += [t for t in meta.get("article:tag", []) if t.strip()]
    tags = tags[:12]

    license_url = None
    feeds = []
    for ln in col.links:
        rel = ln.get("rel", "").lower().split()
        href = ln.get("href", "")
        if "license" in rel and href and not license_url:
            lic = normalize_url(href, base_url)
            if lic and ("creativecommons.org" in lic or "publicdomain" in lic):
                license_url = lic
        if "alternate" in rel and ln.get("type", "").lower() in ("application/rss+xml", "application/atom+xml") and href:
            feed = normalize_url(href, base_url)
            if feed and feed not in feeds:
                feeds.append(feed)

    site = host_key(base_url)
    block_terms = cfg.get("VORTEX_URL_BLOCK_TERMS", ())
    max_images = cfg.get("VORTEX_DISCOVERY_MAX_IMAGES_PER_PAGE", 12)
    seen, media = set(), []

    def add(url, kind, title_text, width=None, height=None, thumb=None):
        absolute = normalize_url(url, base_url, max_len=900)
        if (not absolute or absolute in seen or _bad_media_url(absolute, bad_hints)
                or url_has_blocked_terms(absolute, block_terms)):
            return
        if width and height and min(width, height) < 300:
            return
        seen.add(absolute)
        media.append({
            "media_type": kind, "media_url": absolute, "thumb_url": thumb,
            "width": width, "height": height, "title": (title_text or title)[:300],
            "description": description, "tags": list(tags), "source_url": base_url,
            "license": license_url, "attribution": site, "needs_probe": True, "discovered": True,
        })

    og_w, og_h = _dim(first("og:image:width")), _dim(first("og:image:height"))
    for key in ("og:image", "og:image:secure_url", "og:image:url", "twitter:image", "twitter:image:src"):
        if meta.get(key):
            add(meta[key][0], "photo", title, og_w, og_h)
    for key in ("og:video", "og:video:secure_url", "og:video:url"):
        for url in meta.get(key, [])[:1]:
            if urlparse(url).path.lower().endswith((".mp4", ".webm")):
                add(url, "video", title, thumb=normalize_url(first("og:image"), base_url, 900) if first("og:image") else None)
    for img in col.imgs:
        if len(media) >= max_images:
            break
        src = (img.get("data-src") or img.get("data-lazy-src") or _largest_srcset(img.get("srcset"))
               or _largest_srcset(img.get("data-srcset")) or img.get("src"))
        if not src:
            continue
        alt = unescape(img.get("alt", "")).strip()
        add(src, "photo", alt if len(alt) >= 8 else title, _dim(img.get("width")), _dim(img.get("height")))
    for v in col.videos:
        if len(media) >= max_images:
            break
        src = v.get("src", "")
        if src and urlparse(src).path.lower().endswith((".mp4", ".webm")):
            add(src, "video", title, thumb=normalize_url(v["poster"], base_url, 900) if v.get("poster") else None)

    links = []
    for href in col.anchors:
        url = normalize_url(href, base_url)
        if url and url not in links and should_follow(url, cfg):
            links.append(url)
        if len(links) >= cfg.get("VORTEX_DISCOVERY_MAX_LINKS_PER_PAGE", 150):
            break
    return SimpleNamespace(
        title=title, description=description, tags=tags, license=license_url, feeds=feeds,
        links=links, media=media[:max_images], adult=adult,
        noindex=bool({"noindex", "none"} & robots_flags),
        noimageindex=bool({"noimageindex", "none"} & robots_flags),
        nofollow=bool({"nofollow", "none"} & robots_flags),
    )


def parse_sitemap(text, base_url, cfg, bad_hints=()):
    """(urls_de_paginas, sub_sitemaps, candidatos_de_imagem) de um sitemap.
    Usa regex (nada de parser XML: sem XXE/'billion laughs')."""
    text = text[:2_000_000]
    pages, subs, images = [], [], []
    if "<sitemapindex" in text[:2000].lower():
        for loc in _LOC_RE.findall(text)[:50]:
            url = normalize_url(unescape(loc), base_url)
            if url:
                subs.append(url)
        return pages, subs, images
    block_terms = cfg.get("VORTEX_URL_BLOCK_TERMS", ())
    for url_block in re.findall(r"<url>(.*?)</url>", text, re.IGNORECASE | re.DOTALL)[:500]:
        locs = _LOC_RE.findall(url_block)
        page_loc = normalize_url(unescape(locs[0]), base_url) if locs else None
        if page_loc and should_follow(page_loc, cfg):
            pages.append(page_loc)
        for img_block in _IMAGE_BLOCK_RE.findall(url_block)[:5]:
            img_locs = _LOC_RE.findall(img_block)
            img = normalize_url(unescape(img_locs[0]), base_url, 900) if img_locs else None
            if not img or _bad_media_url(img, bad_hints) or url_has_blocked_terms(img, block_terms):
                continue
            t = _IMAGE_TITLE_RE.search(img_block)
            images.append({
                "media_type": "photo", "media_url": img, "thumb_url": None,
                "title": unescape(t.group(1)).strip()[:300] if t else "", "description": "", "tags": [],
                "source_url": page_loc, "license": None, "attribution": host_key(base_url),
                "needs_probe": True, "discovered": True,
            })
    return pages, subs, images


# ---------------------------------------------------------------------------
# busca segura
# ---------------------------------------------------------------------------

_HTML_TYPES = ("text/html", "application/xhtml")
_XML_TYPES = ("xml", "rss", "atom")


def safe_fetch(http, url, cfg, max_bytes=400_000, timeout=10, hops=3):
    """GET com redirecionamento manual (cada salto conferido), tamanho máximo
    e só tipos de texto. Devolve SimpleNamespace(url, status, ctype, body,
    x_robots) ou levanta UnsafeHost / RateLimited / erro de rede."""
    from vortex_crawler import RateLimited, _retry_after
    allow_private = bool(cfg.get("VORTEX_ALLOW_PRIVATE_HOSTS"))
    for _ in range(hops + 1):
        check_url(url, allow_private=allow_private)
        resp = http.get(url, stream=True, timeout=timeout, allow_redirects=False)
        try:
            if resp.status_code in (301, 302, 303, 307, 308):
                nxt = normalize_url(resp.headers.get("Location", ""), url)
                if not nxt:
                    raise ValueError("redirecionamento inválido")
                url = nxt
                continue
            if resp.status_code == 429:
                raise RateLimited(_retry_after(resp))
            ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if resp.status_code != 200:
                return SimpleNamespace(url=url, status=resp.status_code, ctype=ctype, body="", x_robots="")
            if not (ctype.startswith(_HTML_TYPES) or any(t in ctype for t in _XML_TYPES) or ctype == "text/plain"):
                return SimpleNamespace(url=url, status=200, ctype=ctype, body="", x_robots="")
            buf = bytearray()
            for chunk in resp.iter_content(32768):
                buf.extend(chunk)
                if len(buf) >= max_bytes:
                    break
            charset = "utf-8"
            m = re.search(r"charset=([\w-]+)", resp.headers.get("Content-Type") or "", re.IGNORECASE)
            if m:
                charset = m.group(1)
            try:
                body = bytes(buf).decode(charset, "replace")
            except LookupError:
                body = bytes(buf).decode("utf-8", "replace")
            return SimpleNamespace(url=url, status=200, ctype=ctype, body=body,
                                   x_robots=(resp.headers.get("X-Robots-Tag") or "").lower())
        finally:
            resp.close()
    raise ValueError("redirecionamentos demais")


# ---------------------------------------------------------------------------
# administração (usável sem o motor ligado)
# ---------------------------------------------------------------------------

def _hash(url):
    return hashlib.sha256(url.encode("utf-8")).hexdigest()


def enqueue_urls(db, cfg, entries, from_host=None, new_domain_limit=None):
    """Coloca URLs na fronteira e cria os domínios novos. `entries` é uma
    lista de (url, depth). Devolve (urls_novas, dominios_novos)."""
    max_domains = cfg.get("VORTEX_DISCOVERY_MAX_DOMAINS", 50000)
    clean = {}
    for url, depth in entries:
        url = normalize_url(url)
        if url and should_follow(url, cfg) and url not in clean:
            clean[url] = depth
    if not clean:
        return 0, 0
    session = db.session
    hosts = {host_key(u) for u in clean}
    known = {d.host: d for d in VortexDomain.query.filter(VortexDomain.host.in_(list(hosts))).all()}
    domains_total = None
    new_domains = 0
    for host in hosts:
        if host in known:
            continue
        if new_domain_limit is not None and new_domains >= new_domain_limit:
            continue
        if domains_total is None:
            domains_total = VortexDomain.query.count()
        if domains_total + new_domains >= max_domains:
            continue
        dom = VortexDomain(host=host, status="active", discovered_from=from_host)
        session.add(dom)
        known[host] = dom
        new_domains += 1
    allowed = {u: d for u, d in clean.items()
               if host_key(u) in known and known[host_key(u)].status in ("active", "capped")}
    allowed = vq.limit_per_host(db, cfg, allowed)      # orçamento de páginas esperando por site
    hashes = {_hash(u): u for u in allowed}
    existing = {r[0] for r in session.query(VortexFrontier.url_hash)
                .filter(VortexFrontier.url_hash.in_(list(hashes))).all()} if hashes else set()
    added = 0
    for h, u in hashes.items():
        if h in existing:
            continue
        session.add(VortexFrontier(url_hash=h, url=u, host=host_key(u), depth=allowed[u]))
        added += 1
    try:
        session.commit()
    except IntegrityError:           # corrida com outro processo: refaz um a um
        session.rollback()
        added = new_domains = 0
        for host in hosts:
            if not VortexDomain.query.filter_by(host=host).first() and (new_domain_limit is None or new_domains < new_domain_limit):
                try:
                    with session.begin_nested():
                        session.add(VortexDomain(host=host, status="active", discovered_from=from_host))
                    new_domains += 1
                except IntegrityError:
                    pass
        for h, u in hashes.items():
            try:
                with session.begin_nested():
                    session.add(VortexFrontier(url_hash=h, url=u, host=host_key(u), depth=allowed[u]))
                added += 1
            except IntegrityError:
                pass
        session.commit()
    return added, new_domains


def add_seeds(db, cfg, urls):
    """Cadastra sementes (admin ou config). Devolve quantas URLs entraram."""
    added, _ = enqueue_urls(db, cfg, [(u, 0) for u in urls])
    return added


def block_domain(db, host, blocked=True):
    """Bloqueia (ou libera) um site: para de visitá-lo, esconde os itens dele
    e desliga as fontes automáticas dele."""
    dom = VortexDomain.query.filter_by(host=host).first()
    if dom is None:
        dom = VortexDomain(host=host, status="active")
        db.session.add(dom)
    if blocked:
        dom.status = "blocked"
        VortexFrontier.query.filter_by(host=host, status="pending").delete(synchronize_session=False)
        VortexItem.query.filter(VortexItem.source_name == host).update(
            {"is_active": False}, synchronize_session=False)
        for src in VortexCrawlSource.query.filter_by(origin="auto").all():
            if host_key(src.term) == host:
                src.enabled = False
    else:
        dom.status, dom.error_count = "active", 0
        VortexItem.query.filter(VortexItem.source_name == host).update(
            {"is_active": True}, synchronize_session=False)
    db.session.commit()
    return dom


# ---------------------------------------------------------------------------
# o descobridor
# ---------------------------------------------------------------------------

class DiscoveryCrawler:
    """Roda dentro do IngestEngine: escolhe páginas (fila justa entre
    domínios), baixa/analisa em threads e persiste o que achou."""

    def __init__(self, engine):
        self.e = engine
        self.app, self.db, self.cfg = engine.app, engine.db, engine.cfg
        from vortex_crawler import HostLimiter
        self.limiter = HostLimiter({}, default=self.cfg.get("VORTEX_DISCOVERY_PAGE_INTERVAL", 2.0))
        self._tl = threading.local()
        self._stop = threading.Event()
        self._thread = self._pool = None
        self._lock = threading.Lock()
        self._feeds = set()               # URLs de feed já conhecidas/tentadas
        self._web_profile_id = None
        self.pages = self.feeds_created = self.items_queued = self.errors = self.new_domains = 0
        self.trimmed = 0                  # páginas pendentes descartadas pelo orçamento da fila
        self._counts = {"at": 0.0, "domains": None, "frontier": None}

    # -- ciclo de vida -----------------------------------------------------
    def start(self, initial_delay=0):
        # até 4x o configurado: o controle de velocidade do admin escolhe quantos usar
        self._pool = ThreadPoolExecutor(max_workers=max(1, self.cfg["VORTEX_DISCOVERY_WORKERS"] * 4),
                                        thread_name_prefix="vortex-disc")
        self._thread = threading.Thread(target=self._loop, args=(initial_delay,),
                                        name="vortex-discovery", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(10)
        if self._pool:
            self._pool.shutdown(wait=False, cancel_futures=True)

    def stats(self):
        now = time.monotonic()
        if now - self._counts["at"] > 30:
            try:
                with self.app.app_context():
                    self._counts["domains"] = VortexDomain.query.count()
                    self._counts["frontier"] = VortexFrontier.query.filter_by(status="pending").count()
                self._counts["at"] = now
            except Exception:
                pass
        return {
            "running": bool(self._thread and self._thread.is_alive()),
            "paused": bool(self._control()["paused"]),
            "pages_fetched": self.pages, "feeds_created": self.feeds_created,
            "items_queued": self.items_queued, "errors": self.errors,
            "new_domains": self.new_domains, "domains": self._counts["domains"],
            "frontier_pending": self._counts["frontier"],
            "frontier_level": self._counts.get("level", "open"),
            "frontier_cap": vq.opt(self.cfg, "VORTEX_DISCOVERY_MAX_FRONTIER"),
            "frontier_trimmed": self.trimmed,
        }

    def _http(self):
        from vortex_crawler import make_http
        session = getattr(self._tl, "http", None)
        if session is None:
            session = self._tl.http = make_http(self.cfg, self.limiter)
        return session

    # -- sementes ----------------------------------------------------------
    def seed(self):
        with self.app.app_context():
            prof = VortexProfile.query.filter_by(handle="web").first()
            self._web_profile_id = prof.id if prof else None
            urls = list(self.cfg.get("VORTEX_DISCOVERY_SEEDS", ()))
            urls += [n.feed_url for n in NewsSource.query.filter_by(active=True).all()]
            for src in VortexCrawlSource.query.filter(VortexCrawlSource.kind.in_(("rss", "page"))).all():
                if src.term.startswith("http"):
                    urls.append(src.term)
                    if src.kind == "rss":
                        self._feeds.add(normalize_url(src.term) or src.term)
            added = add_seeds(self.db, self.cfg, urls)
            if added:
                log.info("[vortex] descoberta: %d sementes novas na fronteira", added)

    # -- laço principal ----------------------------------------------------
    def _loop(self, initial_delay):
        if initial_delay and self._stop.wait(initial_delay):
            return
        try:
            self.seed()
        except Exception:
            log.exception("[vortex] descoberta: falha ao semear")
        inflight, last_prune = set(), time.monotonic()
        next_trim = 0.0                  # esvazia o passivo já na subida
        base_workers = self.cfg["VORTEX_DISCOVERY_WORKERS"]
        while not self._stop.is_set():
            try:
                ctl = self._control()
                workers = max(1, min(round(base_workers * ctl["speed"]), base_workers * 4))
                done = {f for f in inflight if f.done()}
                for fut in done:
                    inflight.discard(fut)
                    try:
                        self._persist(fut.result())
                    except Exception:
                        log.exception("[vortex] descoberta: falha ao persistir")
                # pausado pelo admin: não escolhe páginas novas (as em andamento terminam)
                tasks = (self._pick(workers - len(inflight))
                         if not ctl["paused"] and len(inflight) < workers else [])
                for task in tasks:
                    inflight.add(self._pool.submit(self._fetch_task, task))
                if time.monotonic() >= next_trim:      # lotes pequenos: a indexação não para
                    busy = self._trim()
                    next_trim = time.monotonic() + (
                        vq.opt(self.cfg, "VORTEX_FRONTIER_TRIM_BUSY_SECONDS") if busy
                        else vq.opt(self.cfg, "VORTEX_FRONTIER_TRIM_IDLE_SECONDS"))
                if time.monotonic() - last_prune > 600:
                    last_prune = time.monotonic()
                    self._prune()
            except Exception:
                log.exception("[vortex] descoberta: falha no laço")
            if inflight:
                wait(inflight, timeout=0.5, return_when=FIRST_COMPLETED)
            else:
                self._stop.wait(1.0)

    # -- escolha da próxima página (round-robin entre domínios) ------------
    def _control(self):
        fn = getattr(self.e, "control", None)
        return fn() if fn else {"paused": False, "speed": 1.0}

    def _page_interval(self, host):
        # o modo lento do admin estica o intervalo; o rápido nunca o encurta
        return (self.limiter._intervals.get(host, self.cfg.get("VORTEX_DISCOVERY_PAGE_INTERVAL", 2.0))
                * self.limiter.scale)

    def _pick(self, n):
        if n <= 0:
            return []
        cap_items = self.cfg["VORTEX_DISCOVERY_MAX_ITEMS_PER_DOMAIN"]
        per_hour = self.cfg["VORTEX_DISCOVERY_PAGES_PER_DOMAIN_HOUR"]
        tasks = []
        with self.app.app_context():
            db, now = self.db, utcnow()
            pending = db.session.query(VortexFrontier.id).filter(
                VortexFrontier.host == VortexDomain.host, VortexFrontier.status == "pending").exists()
            domains = (VortexDomain.query
                       .filter(VortexDomain.status == "active",
                               db.or_(VortexDomain.next_fetch_at.is_(None), VortexDomain.next_fetch_at <= now),
                               pending)
                       .order_by(VortexDomain.last_fetch_at.asc().nullsfirst(),
                                 VortexDomain.next_fetch_at.asc().nullsfirst(), VortexDomain.id)
                       .limit(n * 3).all())
            for dom in domains:
                if len(tasks) >= n:
                    break
                if dom.items_added >= cap_items:
                    dom.status = "capped"      # teto por site: abre espaço pros outros
                    continue
                if dom.hour_start is None or now - dom.hour_start >= timedelta(hours=1):
                    dom.hour_start, dom.hour_pages = now, 0
                if dom.hour_pages >= per_hour:
                    dom.next_fetch_at = dom.hour_start + timedelta(hours=1)
                    continue
                row = (VortexFrontier.query.filter_by(host=dom.host, status="pending")
                       .order_by(VortexFrontier.depth, VortexFrontier.id).first())
                if row is None:
                    continue
                row.status, row.done_at = "done", now
                dom.hour_pages += 1
                dom.pages_fetched += 1
                dom.last_fetch_at = now
                dom.next_fetch_at = now + timedelta(seconds=self._page_interval(dom.host))
                tasks.append(SimpleNamespace(frontier_id=row.id, url=row.url, host=dom.host,
                                             depth=row.depth, feeds_found=dom.feeds_found))
            self._commit()
        return tasks

    def _commit(self):
        for attempt in range(4):
            try:
                self.db.session.commit()
                return
            except OperationalError:
                self.db.session.rollback()
                time.sleep(0.5 * (attempt + 1))

    # -- rede e análise (thread do pool; não toca no banco) ----------------
    def _fetch_task(self, task):
        from vortex_crawler import (
            RateLimited, _hash_url, _looks_like_bad_url, _BAD_URL_HINTS, robots_allows, robots_extras,
        )
        res = SimpleNamespace(task=task, error=None, blocked=False, retry_after=None, links=[],
                              feeds=[], queued=0, sitemaps=[], from_sitemap=False)
        cfg, http = self.cfg, self._http()
        ua = cfg["VORTEX_USER_AGENT"]
        try:
            if not robots_allows(http, task.url, ua):
                res.blocked = True
                return res
            if task.depth == 0 and task.frontier_id is not None:
                delay, maps = robots_extras(http, task.url, ua)
                if delay:
                    self.limiter._intervals[task.url.split("/")[2].lower()] = min(float(delay), 30.0)
                res.sitemaps = maps[:3]
            page = safe_fetch(http, task.url, cfg, max_bytes=cfg["VORTEX_DISCOVERY_HTML_BYTES"])
            if page.status != 200 or not page.body:
                res.error = f"HTTP {page.status}" if page.status != 200 else "tipo de conteúdo ignorado"
                return res
            candidates, links = [], []
            body_head = page.body[:3000].lower()
            if "<urlset" in body_head or "<sitemapindex" in body_head:
                pages, subs, images = parse_sitemap(page.body, page.url, cfg, _BAD_URL_HINTS)
                links, candidates = pages[:200] + subs, images[:100]
                res.from_sitemap = True
            elif any(t in page.ctype for t in _XML_TYPES) and ("<rss" in body_head or "<feed" in body_head
                                                                or "<rdf" in body_head):
                self._handle_feed_content(page, res)
            else:
                info = parse_page(page.body, page.url, cfg, _BAD_URL_HINTS)
                tag_noindex = "noindex" in page.x_robots or "none" in page.x_robots
                tag_noimg = "noimageindex" in page.x_robots
                if not (info.adult or info.noindex or info.noimageindex or tag_noindex or tag_noimg):
                    candidates = info.media
                    if cfg.get("VORTEX_DISCOVERY_ONLY_LICENSED") and not info.license:
                        candidates = []
                if not (info.adult or info.nofollow or "nofollow" in page.x_robots):
                    links = info.links
                if not info.adult:
                    for feed in info.feeds[: cfg.get("VORTEX_DISCOVERY_FEEDS_PER_DOMAIN", 3)]:
                        self._maybe_feed(feed, res)
            res.links = links
            if candidates and self._web_profile_id is not None:
                snap = SimpleNamespace(id=None, category=None, profile_id=self._web_profile_id,
                                       source_name=task.host)
                res.queued = self.e._process_candidates(snap, candidates)
        except RateLimited as exc:
            res.retry_after = exc.retry_after
        except UnsafeHost as exc:
            res.error = f"recusada: {exc}"
        except Exception as exc:
            res.error = f"erro: {str(exc)[:200]}"
        return res

    def _handle_feed_content(self, page, res):
        """A própria URL é um feed (ex.: semente de notícias): registra o feed
        e põe os links dos itens na fronteira."""
        import feedparser
        parsed = feedparser.parse(page.body.encode("utf-8", "replace"))
        if not parsed.entries:
            return
        with self._lock:
            new_feed = page.url not in self._feeds
            self._feeds.add(page.url)
        if new_feed:
            res.feeds.append((page.url, (parsed.feed.get("title") or "")[:80]))
        for entry in parsed.entries[:50]:
            url = normalize_url(getattr(entry, "link", "") or "")
            if url and should_follow(url, self.cfg):
                res.links.append(url)

    def _maybe_feed(self, feed_url, res):
        """Valida um feed descoberto numa página (1 requisição) e, se tiver
        itens, devolve pra criar a fonte."""
        import feedparser
        with self._lock:
            if feed_url in self._feeds or not should_follow(feed_url, self.cfg):
                return
            self._feeds.add(feed_url)
        try:
            page = safe_fetch(self._http(), feed_url, self.cfg, max_bytes=1_000_000)
            if page.status == 200 and page.body:
                parsed = feedparser.parse(page.body.encode("utf-8", "replace"))
                if parsed.entries:
                    res.feeds.append((feed_url, (parsed.feed.get("title") or "")[:80]))
        except Exception:
            pass

    # -- persistência (thread do laço; faz as escritas) --------------------
    def _persist(self, res):
        task, cfg = res.task, self.cfg
        with self.app.app_context():
            db = self.db
            dom = VortexDomain.query.filter_by(host=task.host).first()
            row = db.session.get(VortexFrontier, task.frontier_id) if task.frontier_id else None
            if res.retry_after:                        # 429: devolve a página à fila e espera
                if row:
                    row.status = "pending"
                if dom:
                    dom.next_fetch_at = utcnow() + timedelta(seconds=res.retry_after)
                self._commit()
                return
            self.pages += 1
            if res.blocked or res.error:
                self.errors += 1
                if row:
                    row.status = "failed"
                if dom and res.error:
                    dom.error_count += 1
                    if dom.error_count >= cfg["VORTEX_DISCOVERY_MAX_ERRORS"]:
                        dom.status = "dead"
                self._commit()
                return
            if dom:
                dom.error_count = 0
                dom.items_added += res.queued
            self.items_queued += res.queued
            self._commit()
            for feed_url, title in res.feeds:
                self._create_feed_source(task.host, feed_url, title)
            entries = [(u, task.depth + 1) if host_key(u) == task.host else (u, 0) for u in res.links]
            entries = [(u, d) for u, d in entries if d <= cfg["VORTEX_DISCOVERY_MAX_DEPTH"]]
            entries += [(m, 1) for m in res.sitemaps]
            if entries:
                level = self._frontier_level()
                same, other = vq.shape_entries(cfg, task.host, entries, level,
                                               from_sitemap=getattr(res, "from_sitemap", False))
                if same:
                    enqueue_urls(db, cfg, same, from_host=task.host)
                if other:
                    _added_o, new_doms = enqueue_urls(
                        db, cfg, other, from_host=task.host,
                        new_domain_limit=cfg["VORTEX_DISCOVERY_NEW_DOMAINS_PER_PAGE"])
                    self.new_domains += new_doms

    def _frontier_level(self):
        """"open" | "tight" | "full" (cache de 30 s; ver vortex_queue.level_for)."""
        now = time.monotonic()
        if now - self._counts.get("level_at", 0) > 30:
            self._counts["level_at"] = now
            self._counts["level"] = vq.level_for(
                VortexFrontier.query.filter_by(status="pending").count(), self.cfg)
        return self._counts.get("level", "open")

    def _trim(self):
        """Um lote do esvaziamento da fila (a cada poucos segundos enquanto houver excesso)."""
        out = vq.trim_step(self.app, self.db, self.cfg)
        self.trimmed += out["deleted"]
        self._counts["level"], self._counts["level_at"] = out["level"], time.monotonic()
        return out["deleted"]

    def _create_feed_source(self, host, feed_url, title):
        db, cfg = self.db, self.cfg
        if VortexCrawlSource.query.filter_by(origin="auto").count() >= cfg["VORTEX_DISCOVERY_MAX_AUTO_FEEDS"]:
            return
        dom = VortexDomain.query.filter_by(host=host).first()
        if dom is not None and dom.status in ("blocked", "dead"):
            return
        db.session.add(VortexCrawlSource(
            name=f"Auto • {title or host}"[:120], kind="rss", profile_id=self._web_profile_id,
            category=None, term=feed_url[:500], media="photo", enabled=True, origin="auto"))
        try:
            db.session.commit()
            self.feeds_created += 1
            if dom is not None:
                dom.feeds_found += 1
                self._commit()
        except IntegrityError:
            db.session.rollback()

    def _prune(self):
        try:
            vq.prune_finished(self.app, self.db, self.cfg)   # visitadas antigas, em lotes
        except Exception:
            self.db.session.rollback()
            log.exception("[vortex] descoberta: falha ao podar a fronteira")
