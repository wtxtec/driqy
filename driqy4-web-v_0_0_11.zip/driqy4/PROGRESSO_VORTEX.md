# PROGRESSO — GIFs + Crawler do Vortex + Busca estilo Pinterest

> **Índice geral e o que ainda resta (verificado em 10/11/2026): `PROGRESSO_INDICE.md`.**

> Arquivo de passagem de bastão entre sessões/IAs. Está igual nos dois
> projetos (`flutter_app/` e `driqy4/`). **Atualize ao fim de cada parte.**
> Regra do usuário: trabalhar em 4 partes, parar ao fim de cada uma e
> entregar os dois zips atualizados.

## Pedido original (resumo)
1. Arrumar os GIFs no Flutter (não reproduziam).
2. Crawler pro Vortex que indexa imagens e vídeos da internet e os mostra
   como se fossem publicados por um "perfil" do Vortex. Esses itens
   **não aparecem no feed**, só dentro do Vortex.
3. Busca eficiente estilo Pinterest: clica numa imagem e abre sugestões
   semelhantes.
4. Informações do conteúdo do Vortex (quantas imagens, quantos vídeos) e
   filtro por categoria.

## Status das partes

| Parte | Escopo | Status |
|---|---|---|
| 1 | Corrigir GIFs no Flutter | ✅ feita (precisa testar no aparelho) |
| 2 | Backend: modelos + crawler + perfis-robô + endpoints do Vortex | ✅ feita (18 testes passando; adaptadores não testados contra as APIs reais) |
| 3 | Backend: busca, "similares", estatísticas, categorias (+ site web) | ✅ feita (47 testes passando; falta ver a página web num navegador) |
| 4 | Flutter: busca, detalhe com similares, estatísticas, filtro, perfil-robô | ✅ feita na Parte 7 (sem perfil-robô; não compilado) |
| 5 | **Admin web** do Vortex: pausar/acelerar/desacelerar a indexação, tempo real, visão geral do indexado, apagar por categoria/fonte/site/perfil/tipo (só site; o Flutter NÃO usa) | ✅ feita (113 testes passando; página não aberta num navegador) |
| 6 | **Vortex por gosto**: sinais de clique/busca, perfil de gosto com decaimento, grade ordenada por nota única (sem cota pra posts de usuários), exploração, `POST /vortex/interact` | ✅ feita (142 testes passando; Flutter só envia o sinal de clique, não compilado) |

## Parte 1 — o que foi feito
Causa exata não confirmada (sem SDK Flutter no ambiente da IA); o servidor
estava correto (`/uploads` serve `image/gif`, `media_type=gif` é gravado).
O ponto frágil era o `Image.network` dividindo o `ImageStream` com os
"medidores" de tamanho (`_resolveImageSize`/`_measureImage`, que ouviam e
removiam listener do mesmo `NetworkImage`). Solução independente disso:

- **Novo** `lib/widgets/driqy_image.dart`:
  - `isGifMedia(url, mediaType)` — GIF por `media_type` ou extensão `.gif`.
  - `GifBytesCache` — cache LRU (40 MB) + dedupe de downloads.
  - `resolveImageSize(url, mediaType:)` — mede a mídia (GIF usa o cache).
  - `AnimatedGif` — baixa, decodifica com `dart:ui` e troca os quadros num
    `Timer` (quadros <=10 ms viram 100 ms); pausa com `TickerMode`
    (aba escondida do `IndexedStack`); libera codec/quadros no `dispose`;
    se falhar, cai num `Image.network`.
  - `DriqyImage` — usar **sempre** no lugar de `Image.network` para mídia
    de post/Vortex. GIF → `AnimatedGif`; resto → `Image.network`.
- Trocado em: `post_card.dart` (foto única + carrossel),
  `media_lightbox.dart`, `pictures_screen.dart` (`_VortexTile`).
  `_resolveImageSize` local foi removido (usar `resolveImageSize`).
- `ApiClient.postMultipart`: nome do arquivo de mídia agora sempre tem
  extensão válida (detecta GIF/PNG/WEBP/MP4/WEBM pelos bytes iniciais);
  antes um GIF vindo do Photo Picker sem extensão era recusado pelo servidor.
- Sem dependências novas (`http` já existia). Rodar `flutter pub get` não
  é necessário, mas não faz mal.

**Como testar:** postar um GIF pelo app → ver animando no feed, no carrossel,
no lightbox e na grade do Vortex. Se algum ainda ficar parado, ver o log
(`flutter run`) e se a URL responde com `Content-Type: image/gif`.

## Parte 2 — o que foi feito (backend)
Leia `VORTEX_CRAWLER.md` (em `driqy4/`) — resumo operacional completo.

- **Modelos** (`models.py`): `VortexProfile`, `VortexCrawlSource`,
  `VortexItem` (campos conforme o plano; **a coluna da fonte se chama `term`,
  não `query`** — `query` esconde o `Model.query` do Flask-SQLAlchemy).
  `db.create_all()` cria as tabelas sozinho (banco existente não precisa de
  migração).
- **`vortex_crawler.py`**: adaptadores `commons, openverse, pexels, pixabay,
  giphy, rss, page`; validação, dedupe (url_hash + dHash), categoria,
  poda, `crawl_source`, `crawl_all_sources`, `run_in_background`,
  `seed_vortex_defaults`. **`vortex_phash.py`**: dHash/Hamming (Pillow;
  `Pillow` entrou no `requirements.txt`). `SIMILAR_DISTANCE = 12` já definido
  pra Parte 3.
- **`config.py`**: bloco `VORTEX_*` (categorias, palavras-chave, perfis e 27
  fontes padrão, limites, chaves opcionais por env).
- **`app.py`**: seed na subida + job `crawl_vortex` (90 s depois de subir).
- **`api.py`**: `GET /vortex`, `/vortex/item/<id>`, `/vortex/profile/<handle>`
  (+ `serialize_vortex_item/profile`). `/pictures` ficou intacto.
- **Admin**: `/admin/vortex` (fontes, rodar agora, nova fonte; só admin) e
  `/admin/vortex/itens` (ocultar/restaurar; staff), abas novas no painel.
- **Testes**: `tests/` (pytest, HTTP simulado) — 18 passando. Rodar:
  `python -m pytest tests -q` dentro de `driqy4/`.

### Formato da peça em `/vortex` (o Flutter da Parte 4 deve seguir isto)
Campos: `key` ("c123" crawler / "45-0" usuário), `source` ("crawler"|"user"),
`item_id`, `post_id` (null no crawler), `media_url`, `thumb_url` (foto: versão
~600 px; vídeo: capa; usuário: null), `media_type`, `width`, `height`,
`duration_seconds`, `title`, `category`, `profile` (crawler) **ou** `author`
(usuário) — um dos dois é null —, `created_at`, `expires_at`,
`seconds_remaining`. **`PictureTile.fromJson` atual exige `post_id` e `author`
não nulos → tem que ser adaptado.** Na grade, usar `thumb_url ?? media_url`
para fotos; **vídeo do crawler = capa + ícone de play, sem autoplay na grade**
(o mp4 inteiro de dezenas de peças pesa demais); tocar no detalhe. GIF do
crawler usa `media_url` (animado) via `DriqyImage(mediaType: 'gif')`.
`Referer`: alguns hosts recusam hotlink sem User-Agent — `GifBytesCache` já
manda um UA; `Image.network` usa o padrão do Dart.

### Ainda NÃO verificado
- Os adaptadores foram escritos a partir da documentação das APIs e testados
  só com respostas simuladas; a sandbox da IA não tem acesso a elas. Na 1ª
  rodada real, olhar `last_status` de cada fonte em `/admin/vortex` e ajustar
  campos se alguma API tiver mudado. Pexels/Pixabay/Giphy ficam "puladas" até
  existirem as chaves no ambiente.
- Vídeos do Commons são `webm` (alguns VP9) — conferir se tocam no
  `video_player` do Android do usuário.
- A página web do Vortex (`/pictures`, `main.py::_vortex_tiles_page`,
  `templates/pictures.html`, `static/js/vortex.js`) ainda mostra só posts de
  usuários; integrar os itens do crawler ali faz parte da Parte 3.

## Parte 3 — o que foi feito (backend + site web)
Tudo novo está em **`vortex_search.py`** (módulo único: índice FTS5, busca,
similares, estatísticas, categorias, cursores). Detalhes de uso em
`VORTEX_CRAWLER.md`. Rodar os testes: `python -m pytest tests -q` (47).

### Endpoints novos (Bearer, prefixo `/api/v1`) — o Flutter da Parte 4 usa estes
- `GET /vortex/search?q=&category=&type=&cursor=` — busca nos itens do
  **crawler** (posts de usuários não têm texto). `q` obrigatório (>= 2 letras,
  senão 400). Resposta: `{query, tiles, total, total_capped, has_next,
  next_cursor, mode: "fts"|"like", relaxed}`. `tiles` têm **o mesmo formato**
  de `/vortex`. `relaxed=true` quando nenhuma peça tinha TODAS as palavras e
  mostramos as que têm ALGUMA (o app pode avisar). `total` para em 400
  (`total_capped=true` → mostrar "400+").
- `GET /vortex/item/<id>/related?cursor=` — "mais como este": `{tiles,
  has_next, next_cursor}`, mesmo formato de peça.
- `GET /vortex/item/<id>` agora devolve também `related` (1ª página, mesmo
  formato) → o detalhe abre com as sugestões numa chamada só; `?related=0`
  desliga. A página 2 em diante vem de `/related?cursor=<next_cursor>`.
- `GET /vortex/stats` → `{total, photos, gifs, videos, crawler_items,
  user_posts, profiles, by_category:[{slug,label,count}]}`. `photos/gifs/
  videos/total` somam crawler + posts de usuários ainda no ar; `by_category`
  só conta o crawler e só traz categorias com itens (maior → menor).
- `GET /vortex/categories[?category=<slug>][&all=1]` → `{categories:[{slug,
  label,count,photos,gifs,videos}], types:{all,photo,gif,video}}`. Sem
  `category`, `types` vale pro Vortex inteiro (use nos chips Tudo/Fotos/GIFs/
  Vídeos); com `category`, só pra ela. `all=1` inclui categorias vazias.
- Stats/categorias têm cache de 60 s (`VORTEX_STATS_TTL_SECONDS`).

### Regras que o Flutter precisa respeitar
- **Cursores são opacos.** `/vortex` usa `p..|c..`; busca e `related` usam
  `o30` (deslocamento numa lista ranqueada). Sempre reenviar `next_cursor`
  como veio. Se o crawler gravar itens novos entre duas páginas o ranking pode
  mudar um pouco → **ignorar peças cujo `key` já está na tela**.
- Busca e similares ficam limitadas a 400 / 150 resultados (config
  `VORTEX_SEARCH_MAX_RESULTS`, `VORTEX_RELATED_MAX_RESULTS`).
- Busca ignora acento e maiúscula, aceita prefixo ("cacho" acha cachoeira) e
  plural simples. Consulta com aspas/operadores não quebra (é sanitizada).

### Como funciona (resumo)
- **Índice**: tabela virtual `vortex_items_fts` (FTS5, "external content" de
  `vortex_items`) mantida por 3 gatilhos (insert/update/delete — a poda do
  crawler também passa por eles). `ensure_search_index` roda na subida
  (`app.py`), é idempotente e **reindexa sozinho** se a contagem não bater
  (banco da Parte 2 sem índice). Sem FTS5 no SQLite → busca LIKE (`mode:"like"`).
  Reindexar à mão: `python vortex_search.py --reindex`.
- **Ranking da busca**: bm25 (título 10, tags 6, categoria 3, descrição 2) 85 %
  + recência (meia-vida 30 dias) 15 %.
- **Similares**: candidatos por tags em comum (FTS), vizinhos de `phash` (cópia
  em memória, Hamming <= `SIMILAR_DISTANCE`=12) e mesma categoria. Quem tem
  sinal real (tag/título/phash) vem primeiro, ordenado por nota; depois o
  preenchimento por categoria. Mesmo perfil só desempata. Quase-duplicata
  (Hamming <= 4, a mesma imagem em outra URL) é omitida. Funciona sem `phash`.
- Medido com 60 mil itens sintéticos: busca 20–40 ms, similares ~40 ms,
  stats ~50 ms (sem cache).

### Site web (Flask/Jinja)
- `/pictures` agora mostra itens do crawler + posts de usuários (~30 %), com
  barra de busca, contador "N imagens • N GIFs • N vídeos", chips de categoria
  (`?categoria=`) e de tipo (`?tipo=photo|gif|video`), cursor composto igual ao
  da API. Com `?q=` só itens do crawler, na ordem de relevância.
- Peça do crawler: foto = miniatura, GIF = arquivo animado, **vídeo = capa +
  ▶ (sem autoplay)**, nome do perfil-robô ao passar o mouse, imagem quebrada
  some da grade (`onerror`), `referrerpolicy="no-referrer"` contra hotlink.
- Novo detalhe `/pictures/item/<id>`: mídia grande (vídeo com controles),
  perfil, descrição, categoria, crédito, licença, link da fonte (só http/https),
  tags (cada uma abre uma busca) e a grade "Mais como este" com rolagem
  infinita. Tocar numa sugestão abre o detalhe dela; Voltar desfaz.
- `vortex.js` agora lê os filtros de `data-more-url` (mesmo script serve grade,
  busca e detalhe). `sw.js`: cache `driqy-shell-v10`.
- Arquivos: `main.py` (rotas), `templates/pictures.html`, `_vortex_toolbar.html`,
  `_picture_tile.html`, `vortex_item.html`, `static/css/style.css`.

### Ainda NÃO verificado
- A página web foi coberta por testes de HTML, mas **não foi aberta num
  navegador** (sem navegador na sessão da IA): conferir o visual (chips,
  tiles do crawler, detalhe) em celular e PC.
- Os adaptadores do crawler continuam sem teste contra as APIs reais (ver Parte
  2): sem itens indexados, busca/similares/estatísticas mostram vazio.

## Parte 5 — Admin web do Vortex (pausa, velocidade, tempo real, apagar)
Pedido: o admin precisa ver e controlar o conteúdo do Vortex **só na web**
(nenhuma mudança no Flutter). Tudo está em `/admin/vortex/conteudo` (aba
"Vortex (conteúdo)", só admin; moderador continua só ocultando em
`/admin/vortex/itens`). Módulo novo: **`vortex_control.py`**.

- **Pausar / retomar**: para de buscar conteúdo NOVO (fontes e descoberta). O
  que já estava em andamento termina e o gravador esvazia a fila. A análise
  visual dos itens já indexados (thread `vortex-vision`) continua. "Rodar
  agora" e `crawl_all_sources` também respeitam a pausa.
- **Velocidade** 0,25x / 0,5x / 1x / 2x / 4x (aceita 0,1–4): escala (a) quantas
  fontes rodam em paralelo (`VORTEX_WORKERS` x fator; pool com folga de 4x),
  (b) a espera entre rodadas de cada fonte (`_scale_next_run`) e (c) quantos
  workers da descoberta. **Acelerar nunca fura limite de site/API**: intervalo
  por host (`HostLimiter.scale` só passa de 1 em modo lento), `Crawl-delay`,
  teto de páginas/hora e `Retry-After`/backoff de erro não são encurtados.
- **Onde fica o estado**: tabela `vortex_control` (chave/valor: `paused`,
  `speed`, `purge_seq`). Vale entre processos e sobrevive a reinício; o motor lê
  com cache de ~2 s (`IngestEngine.control()`).
- **Tempo real**: o motor grava a cada 2 s `instance/vortex_engine_stats.json`
  (thread `vortex-heartbeat`, com a série de itens gravados a cada 10 s nos
  últimos 30 min). `/admin/vortex/status` (JSON) usa o motor do próprio processo
  ou esse arquivo (admin e motor podem estar em processos diferentes) e devolve
  também controle, totais, fontes rodando, últimos itens e a exclusão em
  andamento. A página consulta a cada 2 s (pausa com a aba escondida).
- **Visão geral** (`vortex_control.overview`, cache 5 s): totais por tipo, 24 h,
  ocultos, por categoria / fonte / site (60 maiores) / perfil, itens por hora
  (24 h, horário de Brasília), cobertura da análise visual, URLs apagadas.
- **Apagar** (`POST /admin/vortex/conteudo/apagar`): filtros combinados com E
  (categoria, fonte, site de origem, perfil, tipo, só ocultos); exige pelo menos
  um filtro e digitar APAGAR; prévia com a contagem antes. Roda numa thread em
  lotes de 500 (estado em `instance/vortex_purge_job.json`, uma exclusão por
  vez). Opções: **lápide** (padrão ligado: guarda o `url_hash` em
  `vortex_tombstones` e o crawler não indexa a URL de novo), desligar as fontes
  que alimentam o que foi apagado, bloquear o site. O FTS é limpo pelos gatilhos
  existentes. Ao terminar sobe `purge_seq` e o motor **recarrega** URLs/dHashes
  conhecidos (`_load_known`) — por isso apagar SEM lápide permite reindexar na
  hora. "Liberar URLs apagadas" (`/conteudo/lapides/limpar`) apaga as lápides.
  Apagar um item só: botão em `/admin/vortex/itens` (admin).
- **Testes**: `tests/test_vortex_control.py` (28). `conftest.py` ganhou fixture
  autouse que isola cache e arquivos de `instance/` por teste.

### Ainda NÃO verificado (Parte 5)
- A página `/admin/vortex/conteudo` foi coberta por testes de rota/HTML e o JS
  passou em `node --check`, mas **não foi aberta num navegador**: conferir o
  visual no celular e no PC (cores usam `--accent`/`--border` do tema; se
  alguma não existir ali, ficam os padrões do CSS inline).
- Com vários processos (gunicorn) o painel depende do arquivo `instance/` ser
  compartilhado (mesma máquina). Em várias máquinas cada uma tem seu motor e
  seu arquivo; o controle (banco) vale pra todas, mas o painel mostra só uma.
- Excluir dezenas de milhares de itens enquanto o motor grava disputa o SQLite
  (WAL + `busy_timeout`, lotes de 500 com pausa de 50 ms): pode deixar a
  indexação mais lenta durante a exclusão. Se incomodar, pause antes.

## Arquitetura decidida para as partes 2–4 (seguir isso)

**Princípio:** itens do crawler NÃO são `Post`. O feed, o perfil, as
notificações, o ranking etc. só consultam `Post`, então os itens do
crawler nunca vazam pra lá. Só o Vortex consulta a nova tabela.

### Modelos novos (`models.py`) — Parte 2
- `VortexProfile` (o "perfil que publicou"): `id, handle (único, ex.
  "commons"), display_name, bio, avatar_url, source_site, is_active`.
  Um perfil por fonte/coleção (ex.: "Wikimedia Commons", "Openverse").
  **Não** é `User` (não loga, não aparece em busca de pessoas/ranking).
- `VortexItem`: `id, profile_id, media_type (photo|gif|video), media_url,
  thumb_url, width, height, title, description, tags (texto "a,b,c"),
  category (slug), source_url (página original), source_name, license,
  attribution, phash (dHash 64 bits em hex, opcional), url_hash (único,
  sha1 da media_url — evita duplicata), created_at, last_checked_at,
  is_active`. Índices em `category`, `media_type`, `profile_id`,
  `created_at`.
- `VortexCrawlSource`: fontes configuráveis (`kind`: api/rss/page,
  `url`, `query`, `category`, `profile_id`, `enabled`, `last_run_at`,
  `last_status`, `items_added`).
- Migração: `db.create_all()` já cria tabelas novas; se precisar de
  colunas, usar `_ensure_schema_upgrades` em `app.py`.

### Crawler (`vortex_crawler.py`) — Parte 2
- Mesmo estilo do `news_indexer.py` (leia ele antes) e agendado em
  `scheduler.py` (mesma proteção contra reloader duplicado).
- Fontes **legais/abertas** primeiro: Wikimedia Commons API, Openverse API
  (CC), e opcionais com chave em `config.py`/env (Pexels, Pixabay, Giphy).
  Páginas genéricas: respeitar `robots.txt`, User-Agent próprio, delay,
  limite por domínio, `og:image`/`og:video`. **Hotlink** (guarda URL +
  `source_url` + atribuição), não copia o arquivo.
- Valida cada item: HEAD/GET com `Content-Type` de imagem/vídeo, tamanho
  mínimo (ex. >= 200px), descarta pixel/ícone/logo (reaproveitar filtros do
  `news_indexer.py`), dedupe por `url_hash` e por `phash` próximo.
- Categoria: classificador por palavras-chave (padrão do
  `news_classifier.py`) + categoria padrão da fonte.
- Rotas admin (`admin.py`): listar fontes, rodar agora, ativar/desativar,
  ver contagem. Comando manual `python vortex_crawler.py --once`.

### Endpoints (`api.py`, prefixo `/api`) — Partes 2 e 3
- `GET /vortex` (prefixo real: `/api/v1`) — mistura **posts de usuários + itens do crawler** na
  grade (cursor próprio por tipo ou cursor composto; tile ganha
  `source: "user"|"crawler"`, `item_id`, `profile`). Filtros:
  `?category=&type=photo|gif|video`.
- `GET /vortex/search?q=&category=&type=&cursor=` — busca (SQLite FTS5
  sobre title/tags/description; fallback LIKE; ranking por bm25 +
  recência).
- `GET /vortex/item/<id>` — detalhe + `related` (ver abaixo).
- `GET /vortex/item/<id>/related?cursor=` — "mais como este": mesmo
  `category`/tags em comum (Jaccard) + distância de Hamming do `phash` +
  mesmo perfil como desempate.
- `GET /vortex/stats` — `{total, photos, gifs, videos, by_category:
  [{slug,label,count}], profiles, user_posts, crawler_items}`.
- `GET /vortex/categories` — slugs/rótulos (reaproveitar as categorias de
  notícias quando fizer sentido).
- `GET /vortex/profile/<handle>` — perfil-robô + seus itens (paginado).

### Flutter — Parte 4
Endpoints prontos (ver "Parte 3 — o que foi feito"): `/vortex` (grade),
`/vortex/search`, `/vortex/item/<id>` (já com `related`), `/vortex/item/<id>/related`,
`/vortex/stats`, `/vortex/categories`, `/vortex/profile/<handle>`.
- Modelo `PictureTile` ganha `source`, `itemId`, `profile`, `title`.
- `PicturesScreen`: barra de busca no topo, chips de categoria, chips de
  tipo (Tudo/Fotos/GIFs/Vídeos), cabeçalho de estatísticas
  ("N imagens • N vídeos • N GIFs").
- Novo `VortexDetailScreen`: mídia grande + título/atribuição/link da
  fonte + grade "Mais como este" (rolagem infinita) — tocar numa sugestão
  abre outro detalhe (pilha estilo Pinterest).
- Tile do crawler abre o detalhe do item (não `PostDetailScreen`); tile de
  usuário continua abrindo o post.
- Perfil-robô (`VortexProfileScreen`) simples: avatar, nome, bio, fonte,
  grade dos itens.
- Usar **`DriqyImage`** para toda mídia (GIFs!).

## Pendências / avisos
- Parte 4 (Flutter) não iniciada. (O admin web da Parte 5 não entra no Flutter: é só site.)
- Parte 1 não foi executada num aparelho real (sem Flutter na sessão da IA).

## Parte 6 — Vortex por GOSTO do usuário (backend + site + sinal no Flutter)
**Problema:** a grade reservava ~30 % de cada página para posts de usuários
(os mais novos primeiro) e o resto eram itens do crawler por id decrescente,
só embaralhados dentro da página. Nada aprendia com o que a pessoa clicava. O
app Flutter ainda lê o `/pictures` antigo (só posts de usuários, mais novo
primeiro).

**Agora:** tudo é ordenado por uma nota única de gosto. Módulo novo
**`vortex_taste.py`** (a docstring no topo explica o algoritmo inteiro).

- **Sinais** — tabela `vortex_interactions` (`models.VortexInteraction`;
  `create_all` cria sozinha). Tipos e pesos: `open` 1.0 (clique), `dwell` 0.8
  (tempo no detalhe), `like` 2.0, `search` 0.7 (as palavras viram interesse em
  tags), `less` -1.5 ("menos disso"). Guarda cópia de categoria/tipo/perfil/
  autor/tags da peça. Mesmo sinal na mesma peça em 20 s é ignorado. Poda >60
  dias.
- **Perfil** — soma dos sinais dos últimos 21 dias com decaimento exponencial
  (meia-vida 72 h; sinais das últimas 3 h valem 2x). Gera afinidade 0..1 por
  categoria, tag, tipo de mídia, perfil-robô e autor + `confidence` (poucos
  sinais = gosto pesa pouco; ~8 de peso = pesa 100 %). Mudou de interesse? Em
  poucos cliques o assunto novo passa o antigo.
- **Nota** = 4·gosto·confiança + 1·novidade (meia-vida 10 dias) + 0,5·
  popularidade (aberturas em 14 dias, todos os usuários) + 0,6·acaso.
  Peça aberta nas últimas 36 h é rebaixada (x0,25). **Posts de usuários e
  itens do crawler competem pela MESMA nota — sem cota e sem prioridade.**
  Post só tem autor+tipo como gosto, então o autor pesa 0,9 (mesmo teto de
  categoria+tags num item); autor desconhecido fica em pé de igualdade com
  item sem afinidade.
- **Montagem** — diversificação (não empilha o mesmo perfil/categoria) e
  **exploração**: 1 a cada 5 posições é fora do gosto conhecido, ordenada só
  por novidade+popularidade+acaso (item e post iguais), pra descobrir
  interesse novo e não virar bolha. Usuário novo = tudo é exploração.
- **Candidatos** — 700 mais novos + 350 de cada uma das 4 categorias
  favoritas + 120 de cada uma das 3 tags favoritas (FTS) + 250 aleatórios do
  acervo inteiro + 150 posts de usuários recentes. Medido: 30 mil itens →
  0,11 s na 1ª página, 1 ms nas seguintes.
- **Paginação** — a lista ranqueada fica numa sessão em memória (usuário +
  semente, 30 min). Páginas seguintes só fatiam (nada repete). Sinal novo no
  meio da rolagem → só a parte AINDA NÃO MOSTRADA é reordenada com o gosto
  novo. Sessão perdida (reinício/outro worker) → refaz com a mesma semente;
  o app continua ignorando `key` repetida. **Cursor novo: `t<semente>-<n>`
  (opaco).** Cursor antigo `p..|c..` continua funcionando no caminho
  cronológico antigo (rolagens já em andamento não quebram).

### Endpoints (Bearer, `/api/v1`)
- `GET /vortex` — agora por gosto. Mesmos filtros (`category`, `type`) e mesmo
  formato de peça. Com `category`, só itens do crawler.
- `GET /vortex/item/<id>` — **abrir o detalhe já registra `open`** sozinho.
- `GET /vortex/search` — a 1ª página com resultado registra `search`.
- **`POST /vortex/interact`** `{"kind":"open|dwell|like|less","item_id":N}` ou
  `{"kind":...,"post_id":N}` → `{"ok":true,"recorded":bool}`. Use para posts de
  usuários (abrir), `dwell`, `like` e `less`.
- `GET /pictures` (legado, o que o app usa hoje) — continua só com posts de
  usuários e o mesmo formato, mas **ordenado por gosto**; `next_cursor` segue
  inteiro (agora é um deslocamento, não um id de post).

### Site web
`/pictures` e `/api/pictures/mais` usam o mesmo motor. `pictures_item` registra
`open`; `vortex.js` envia `sendBeacon` para o novo `POST /api/pictures/interact`
ao clicar num post de usuário (`data-vortex-post-id` em `_picture_tile.html`).

### Flutter (mínimo; sem SDK no ambiente da IA, NÃO compilado)
`PicturesService.trackInteraction({postId, itemId, kind})` (fire-and-forget) e
chamada em `_PicturesScreenState._openPost`. Assim o app já aprende com o que
a pessoa abre, mesmo lendo o `/pictures` antigo. **A Parte 4 (Flutter
consumindo `/vortex`) continua pendente**: ao fazê-la, trocar `getPictures` por
`/vortex`, adaptar `PictureTile`, chamar `trackInteraction(kind:'like'/'less')`
nos botões e, se quiser, `dwell` ao sair do detalhe depois de ~8 s. A ordem
nova aparece ao abrir/atualizar o Vortex (nova semente) — e, na mesma rolagem,
nas páginas ainda não carregadas.

### Ajustes (constantes no topo de `vortex_taste.py`)
`HALF_LIFE_HOURS` (rapidez de esquecer), `EXPLORE_EVERY` (descoberta),
`SCALE_*`/`W_*` (pesos), `OPENED_PENALTY`, `POOL_*`. Testes:
`python -m pytest tests -q` → 142 passando (29 novos em
`tests/test_vortex_taste.py`).

### Não verificado / ideias
- Não há botão "menos disso" nem `like` no Vortex ainda (backend pronto).
- Impressões sem clique (peça mostrada e ignorada) ainda não contam como sinal
  negativo; só o clique, o `less` e o tempo contam.
- Seguir alguém NÃO dá bônus aos posts dele (de propósito, pra não
  reintroduzir prioridade por perfil); se quiser, é um peso a mais em
  `taste_score`.
- Sessões/perfis ficam em memória do processo: com vários workers cada um tem
  o seu (funciona, só pode repetir peça em casos raros — o app ignora `key`
  repetida).

## Parte 7 — Vortex sem lixo + "visto recentemente" + Flutter consumindo `/vortex`
**Problemas:** (1) o app Flutter lia o `/pictures` legado (só posts de usuários), então
nunca mostrava o conteúdo do crawler dentro do próprio Vortex; (2) a grade trazia QR codes,
logos gigantes e imagens repetidas; (3) o Vortex não respondia ao que a pessoa acabou de abrir.

### Backend — filtro anti-lixo (`vortex_quality.py`, novo)
- **Nome** (`check_text`): palavras FORTES (`qr`, `qrcode`, `barcode`, `logo`, `wordmark`,
  `favicon`, `sprite`, `placeholder`, `watermark`...) valem na URL, no título e nas tags; as FRACAS
  (`banner`, `badge`, `button`, `popup`, `default-image`...) só no caminho da URL (senão "Bruce
  Banner" seria barrado). Caminhos de tema/template do site também.
- **Pixels** (`inspect_bytes`, Pillow + numpy, sobre a miniatura): QR code (3 "olhos" 1:1:3:1:1
  confirmados em linha e coluna, formando um L), logo/arte chapada (poucas cores concentradas +
  quase sem degradê + contraste entre as cores dominantes + primeiro plano de poucas cores),
  recorte transparente, imagem em branco. Regras de logo só valem para FOTO (GIF/vídeo só QR/branco).
- **Repetidas** (`dedupe_existing`): agrupa por dHash (Hamming <= `VORTEX_DEDUPE_DISTANCE`=6), fica a
  de maior resolução, as outras viram `duplicate`; >= `VORTEX_REPEAT_TEMPLATE_MIN`=6 cópias = banner
  de site: some tudo (`repeated`).
- Item barrado: `is_active=False` + `junk_reason` (`qrcode|logo|blank|transparent|text|duplicate|
  repeated`); `manual_ok` = admin restaurou, o filtro nunca mais mexe. Colunas novas em
  `vortex_items`: `junk_reason`, `quality_version` (upgrade automático em `app.py`).
- **Onde roda:** no `enrich` (itens novos já entram analisados, com `quality_version`), no boot
  (`text_sweep`, sem rede), e no motor em segundo plano (`IngestEngine._quality_loop`: itens antigos +
  `dedupe_existing` a cada 30 min). Stats do motor ganharam `quality_*`. Liga/desliga:
  `VORTEX_QUALITY_ENABLED=0`. Linha de comando: `python vortex_quality.py [--text] [--rescan]
  [--dedupe [--dry-run]]`.
- **Admin:** `/admin/vortex/itens` filtra por motivo (`?motivo=auto|qrcode|logo|...`) e mostra o
  motivo; "Restaurar" grava `manual_ok`; botão "Limpar lixo agora" (`POST
  /admin/vortex/qualidade/limpar`, só admin) roda nome + repetidas na hora.
- **Grade** (`vortex_taste.py`): ignora por nome mesmo item ainda não analisado; não repete imagem
  quase igual (dHash <= `VORTEX_FEED_NEAR_DUP_DISTANCE`=9); no máx. `VORTEX_FEED_PER_SITE_MAX`=3 do
  mesmo site em `VORTEX_FEED_PER_SITE_WINDOW`=12 posições (cede se não houver outra opção).

### Backend — "o que acabei de ver"
- `recent_seed_ids`: últimas 4 peças abertas/curtidas nas últimas 48 h (a mais nova pesa mais,
  meia-vida 12 h, curtir x1,4; "menos disso" tira a peça). `recent_boost`: as parecidas
  (`related_items`) ganham bônus (`SCALE_RECENT`=2,4) e entram no pool de candidatos; as melhores
  ocupam as posições 1,4,7,10,13,16 (`RECENT_SLOTS`). A própria peça aberta continua rebaixada.
  Sinal novo no meio da rolagem reordena só o que ainda não foi mostrado (já era assim).
- **Novo endpoint** `GET /api/v1/vortex/recent?limit=&type=` → `{tiles}` (mais recente primeiro,
  sem repetir; mesmo formato de peça).

### Flutter (NÃO compilado — sem SDK na sessão da IA)
- `PictureTile` agora serve aos dois tipos de peça (`source`, `itemId`, `thumbUrl`, `title`,
  `profile`; `postId`/`author` ficam nulos no crawler). Novos modelos: `VortexProfile`,
  `VortexItemDetail`, `VortexStats`, `VortexCategory`.
- `PicturesService`: `getVortex`, `getRecent`, `getItem` (já com `related`), `getRelated`, `search`,
  `getStats`, `getCategories`; cursor é `String` OPACO. `getPictures` (legado) foi removido.
- `PicturesScreen` lê `/vortex`; ignora `key` repetida; busca, chips Tudo/Fotos/GIFs/Vídeos,
  chips de categoria, contador "N imagens • N GIFs • N vídeos", faixa "Vistos recentemente"
  (atualiza ao voltar de um detalhe). Peça do crawler = `VortexTileCard` (vídeo = capa + play, SEM
  autoplay); post de usuário segue com `_VortexTile` (autoplay) e agora manda `open`.
- Telas novas: `VortexDetailScreen` (mídia grande, vídeo com controles, perfil, crédito/licença,
  "Ver na fonte" só http/https, tags que abrem busca, "Mais como este" infinito empilhável,
  Curtir = `like`, "Menos disso" = `less` e volta, `dwell` ao ficar >= 8 s) e `VortexSearchScreen`.
- Não há dependência nova (`url_launcher` e `video_player` já existiam).

### Testes / não verificado
- Backend: `python -m pytest tests -q` → **182 passando** (40 novos em `tests/test_vortex_quality.py`).
  `test_control_cache_is_invalidated_by_writes` falhou UMA vez na suíte completa e passou nas
  rodadas seguintes (flutuação de cache por tempo; não relacionada).
- **Limiares do detector calibrados só com imagens sintéticas** (QR reais da lib `qrcode`, fotos/logos
  desenhados). Com dados reais pode haver falso positivo/negativo (ilustração multicolorida passa;
  foto muito chapada pode ser barrada). Olhar `/admin/vortex/itens?motivo=auto` na 1ª rodada e
  restaurar o que for engano. Ajustes: `classify_pixels`/`metrics` em `vortex_quality.py`.
- Flutter: não compilado nem rodado num aparelho. Se `flutter analyze` reclamar, o mais provável é
  detalhe de tipo em `vortex_detail_screen.dart` / `pictures_screen.dart`.
- Os itens antigos só somem da grade depois da varredura: nomes no boot; pixels e repetidas pelo
  motor (ou `python vortex_quality.py`), que precisa baixar as miniaturas.

---

# PLANO EM 8 PARTES — Vortex que entende o usuário (pedido de 30/10/2026)

> Regra do usuário: 8 partes; ao fim de cada uma, devolver os DOIS zips completos.
> **Atualize a tabela abaixo ao fim de cada parte.**

## Pedido original (resumo)
1. Coisas que o usuário já viu no Vortex voltam a aparecer.
2. Recomendação péssima: clica num carro e aparecem pessoas dançando, balões etc. Tem que mostrar
   outros carros e veículos de rodas (moto, caminhão, bicicleta...). Precisa **entender** o usuário.
3. Não viciar: o feed deve misturar o que o usuário gosta com coisas que ele PODE gostar, sem prendê-lo
   numa bolha.
4. Fundo do Vortex segue o tema (escuro → escuro, claro → claro) — web e Flutter.
5. A fila de indexação de links passou de 200 mil esperando: tornar **progressiva**, nunca passando
   duas vezes pela mesma fonte.

## Status

| Parte | Escopo | Status |
|---|---|---|
| 1 | **"O que já vi não volta"**: livro de vistos no banco (servido / visto / rejeitado), bloqueio + volta gradual, quase-duplicata (dHash), reciclagem quando o acervo acaba; envio de impressões pelo site e pelo Flutter | ✅ feita (23 testes novos; 595 no total) |
| 2 | **Fila de indexação progressiva**: teto de fila, orçamento por fonte, nunca repetir fonte na mesma rodada, esvaziar os 200 mil+ | ✅ feita (16 testes novos; 611 no total) |
| 3A | **Compreensão do conteúdo — o cérebro** (puro, sem banco): taxonomia de ~205 conceitos (carro → veículo de rodas ← moto, caminhão, bicicleta; balão de festa ≠ veículo; dança ≠ veículo), extrator título/tags/descrição/CLIP → conceitos com peso, parentesco `relation`/`similarity`, codificação pra gravar | ✅ feita (28 testes novos em `tests/test_vortex_concepts.py`) |
| 3B | **Compreensão do conteúdo — ligar no acervo**: colunas `concepts`/`concept_tags`/`concept_version`, preenchido no `enrich`, reprocessamento do acervo no motor, CLI/admin, reclassificação de "outros" | ✅ feita (ver abaixo) |
| 4 | **"Mais como este" novo**: relacionados por conceito/família (nunca "dançando" para "carro"), co-cliques, corte de relevância mínima | ✅ feita (6 testes novos; 682 no total) |
| 5 | **Perfil de interesse + anti-vício**: interesse por conceito, mistura interesse / adjacente / descoberta, limite de saturação por assunto, pausa/aviso de tempo | ✅ feita (11 testes novos; 693 no total) |
| 6 | **Tema no Flutter**: fundo do Vortex claro/escuro; "menos disso"/curtir na grade | ✅ feita (só Flutter; não compilado — ver abaixo) |
| 7 | **Tema no site** + ajustes visuais da grade web | ✅ feita (tema; sem curtir/"menos disso" na grade web — ver abaixo) |
| 8 | Testes finais, painel admin (fila/saúde da recomendação), documentação | ✅ feita (painel de saúde; 14 test_chat_* conferidos; curtir/"menos disso" na grade web) |

## Parte 1 — o que foi feito

**Causa:** o Vortex só lembrava do que a pessoa ABRIU (36 h) e de uma sessão em memória (30 min). Quem
saía e voltava recebia o mesmo topo do acervo, porque o ranking é determinístico sobre o mesmo
conjunto de candidatos.

**Solução — `vortex_seen.py` (novo) + tabela `vortex_seen` (`models.VortexSeen`, `create_all` cria):**
- Uma linha por (usuário, peça). Chave: `c<id>` (item do crawler) / `p<id>` (post de usuário).
- **servido** (o servidor entregou numa página): bloqueado `SERVED_BLOCK_HOURS`=36 h.
- **visto** (app/site confirmou na tela, ou abriu/curtiu): bloqueado `VIEWED_BLOCK_DAYS`=30 dias.
- **rejeitado** ("menos disso"): bloqueado `REJECTED_BLOCK_DAYS`=120 dias, nunca é reciclado.
- Depois do bloqueio a peça **volta aos poucos**: nota x0,3 → x1,0 em `SOFT_RAMP_DAYS`=30.
- **Imagem quase igual a uma já vista** (dHash ≤ 6, índice por faixas, sem N×M) também some.
- `vortex_taste.rank_keys` filtra bloqueados, busca `extra` linhas a mais em cada consulta do pool
  (senão o topo do acervo, já visto, esvaziaria o pool) e **recicla** as vistas há mais tempo se sobrar
  menos de 1 página de peças novas (grade nunca fica vazia). `ranked_page` marca o que serve.
  `record()` (open/like/dwell/less) também grava no livro.
- **Endpoints novos:** `POST /api/v1/vortex/seen` e `POST /api/pictures/seen`, corpo
  `{"keys": ["c12","p7"]}` (até 200).
- **Site:** `data-vkey` em cada peça (`_picture_tile.html`); `vortex.js` marca "vista" com ≥50 % visível
  por 700 ms e envia em lote (sendBeacon). `sw.js` → `driqy-shell-v47` (testes que fixam a versão foram
  atualizados).
- **Flutter:** `PicturesService.markViewed`; `pictures_screen.dart` mede visibilidade a cada 400 ms
  (mesma técnica dos vídeos), envia em lote, e descarrega o lote ao atualizar/fechar.
- Testes: `tests/test_vortex_seen.py` (23). `test_vortex_quality.py` ajustado (ele ranqueava 6x seguidas
  pro mesmo usuário; agora limpa o livro entre as rolagens, porque repetir é exatamente o que o livro
  impede).

**Não verificado:** Flutter NÃO compilado (sem SDK na sessão); `vortex.js` só passou em `node --check`;
site não aberto num navegador. "Relacionados" e "busca" ainda NÃO consultam o livro (Parte 4).

## Parte 2 — o que foi feito (fila de indexação progressiva)

**Causa dos 200 mil+ em espera:** a fronteira (`vortex_frontier`) aceitava até 500 mil URLs pendentes e cada
página visitada enfileirava até 150 links (profundidade até 4). Entrava muito mais do que saía, e poucos sites
gigantes ocupavam quase toda a fila.

**Solução — `vortex_queue.py` (novo; a docstring no topo explica tudo) + ligação em `vortex_discovery.py`:**
- **Teto global** `VORTEX_DISCOVERY_MAX_FRONTIER` (500 000 → **20 000**, aceita env). **Nível** da fila: `open`
  (<60 %), `tight` (60–100 %: só links rasos e limites x0,4), `full` (não entra link novo; a fila só anda).
- **Orçamento por página** (`shape_entries`): mesmo site 10 links, sitemap 40, sites de fora 16 (no máx. UM por
  site). Escolha estável: rasos primeiro, resto espalhado por hash. `MAX_DEPTH` 4 → 3.
- **Orçamento por site** (`limit_per_host`, chamado em `enqueue_urls`): no máx. `VORTEX_FRONTIER_PER_HOST_MAX`=40
  páginas esperando por site; a vaga reabre quando a página é visitada.
- **Esvaziar o passivo** (`trim_step`, chamado pelo laço da descoberta já na subida e a cada 15 s enquanto houver
  excesso, 300 s com a fila em dia): lotes de 3000, apaga (1) pendentes com mais de 7 dias, (2) o excesso por site
  (ficam as mais rasas/antigas), (3) o excesso global (saem as mais profundas/novas). Não trava o SQLite.
  À mão: `python vortex_queue.py --trim` / `--status`.
- **Nunca passar duas vezes pela mesma fonte:** `_pick` agora ordena por `last_fetch_at` (o site visitado há mais
  tempo primeiro), uma página por site por vez; páginas visitadas ficam registradas `done` por 30 dias
  (`DONE_KEEP_DAYS`, antes 7) e a URL não volta à fila enquanto a linha existir. Poda de visitadas agora em lotes.
- Stats do motor ganharam `frontier_level`, `frontier_cap`, `frontier_trimmed`; o painel
  `/admin/vortex/conteudo` mostra "teto / aberta|apertada|cheia / descartadas".
- Ajustes: constantes `VORTEX_FRONTIER_*` em `config.py`. Testes: `tests/test_vortex_queue.py` (16).

**Não verificado:** painel não aberto num navegador; medido com 210 mil linhas sintéticas (300 sites x 700): 67 passos de
3000, 198 mil apagadas em ~21 s de trabalho de banco (no motor real os passos ficam 15 s afastados, então o
passivo some em ~17 min), sobrando 12 mil (40 por site, nível "apertada"); com milhões de linhas não foi medido; fontes `rss/api` (VortexCrawlSource) seguem
com o agendamento por `next_run_at` de antes (já é uma rodada por fonte por vez).

## Parte 3A — o que foi feito (taxonomia de conceitos; módulo puro)

> O pedido do usuário foi **dividir a Parte 3 em duas** (3A e 3B), sempre entregando os dois zips
> completos. 3A = o "cérebro" que entende o conteúdo; 3B = ligar isso ao banco/acervo.

**Arquivo novo: `vortex_concepts.py`** (a docstring no topo explica tudo). Não acessa banco, rede nem
Flask — só texto -> conceitos — por isso é rápido de testar e seguro de importar de qualquer lugar.

- **Taxonomia** (`_RAW`): 14 domínios (os mesmos das categorias do Vortex, `carros`->`veiculo`,
  `viagens`->`lugares`) > famílias > conceitos > especializações. ~205 conceitos, ~16 mil formas de
  escrever (pt + en, sem acento, singular/plural gerado). Exemplos:
  `veiculo > veiculo_rodas > carro > carro_esportivo|carro_antigo|carro_corrida`, irmãos de `carro`:
  `moto, caminhao, bicicleta, onibus, trator`; `veiculo > aeronave > aviao|helicoptero|balao_ar_quente`;
  `pessoas > festa > balao|casamento` e `pessoas > atividade > danca|musico`.
  **Balão de festa vive em `pessoas`, não em `veiculo`** (era a queixa: clicava num carro e vinham
  balões e gente dançando). Só o balão de ar quente é veículo.
- **`extract(title, tags, description, visual_tags, category)`** -> `Understanding(concepts, domain,
  families, confidence, source)`: até 6 conceitos com peso 0..1. Casa por palavra inteira (nunca
  "car" dentro de "carpet"); **o termo mais longo vence** ("campo de futebol" = futebol, não "campo";
  "Rio de Janeiro" = cidade, não rio); termo ambíguo divide o peso; conceito geral nunca passa o
  específico que apareceu junto ("birthday party" não ganha de "balão"); fontes pesam
  título 1,0 / CLIP 1,0 / tags 0,8 / descrição 0,45. Nada casou -> usa só o domínio da categoria
  (`confidence` 0,15, `source="category"`).
- **CLIP**: os 163 rótulos de `Config.VORTEX_VISUAL_CONCEPTS` resolvem para conceito (teste garante).
  Rótulos ambíguos têm resposta fixa em `VISUAL_LABEL_OVERRIDES` (ex.: "balão" da categoria viagens =
  balão de ar quente; "tênis" = esporte).
- **`relation(a, b)`**: 1,0 igual · 0,8 pai/filho · 0,7 avô/neto · 0,65 irmãos · 0,5 tio/sobrinho · 0,4
  primos distantes · 0,25 só o mesmo domínio · **0 domínios diferentes**, salvo `LINKS` explícitos
  (bicicleta↔ciclismo 0,7; carro_corrida↔automobilismo 0,7; futebol↔estádio 0,6...).
  `similarity(a, b)` compara conjuntos (média simétrica ponderada). Resultado medido:
  "red sports car" × moto/caminhão/bicicleta/ônibus = **0,5** (carro "puro" × moto = 0,65), × avião =
  0,25, × dança/balão/pizza/gato/futebol = **0,0**.
- **Gravar/ler** (para a 3B): `encode(u)` -> `"carro_esportivo:1,estrada:0.55"` (<= 120 caracteres),
  `decode(texto)`, `concept_tags(u)` -> `" carro_esportivo carro veiculo_rodas veiculo "` (conceito +
  ancestrais, cercado de espaços) para achar "tudo que é veículo de rodas" por LIKE/FTS sem JOIN.
  `find_concepts(texto)` serve para entender a CONSULTA de busca. `related_concepts(id, min_score)`
  lista os parentes de um conceito (expansão de busca / "mais como este").
- **Velocidade**: ~0,12 ms por item (100 mil itens ≈ 12 s de CPU).
- **Testar à mão**: `python vortex_concepts.py "red sports car" "motorcycle"` (mostra conceitos e
  similaridade); `--stats` mostra contagens.
- **Ajustar o vocabulário**: editar `_RAW` (termos separados por vírgula), `DROP_TERMS` /
  `DROP_PAIRS` (tirar termo que dá falso positivo), `LINKS` (parentescos entre domínios),
  `TERMS_PER_CONCEPT` (corte da cauda longa). `CONCEPTS_VERSION` deve subir quando o vocabulário mudar
  (a 3B reprocessa os itens com versão antiga).

**Nada mudou no banco, na API, no site nem no Flutter na 3A** — o módulo ainda não é chamado por
ninguém. Por isso o comportamento do Vortex é o mesmo da Parte 2 até a 3B/4.

### Plano da Parte 3B (próxima)
1. `models.VortexItem`: colunas `concepts` (VARCHAR 160), `concept_tags` (VARCHAR 300),
   `concept_version` (INTEGER) + upgrade em `app.py` (`_ensure_schema_upgrades`) e índice parcial
   "pendentes" (como `quality_pending`).
2. `vortex_crawler.py`: no `enrich`/insert, chamar `vortex_concepts.extract` com título, tags,
   descrição, `visual_tags` e categoria; gravar `encode`/`concept_tags`/`CONCEPTS_VERSION`.
3. Reprocessar o acervo: laço no motor (`IngestEngine`, mesmo estilo do `_quality_loop`) em lotes,
   sem rede (só texto); de novo quando o CLIP preencher `visual_tags` depois. CLI
   `python vortex_concepts.py --reprocess [--limit N]`.
4. Item da categoria `outros` com conceito claro -> sugerir/gravar a categoria do domínio.
5. Stats do motor (`concepts_done/pending`), linha no painel `/admin/vortex/conteudo`, testes e
   atualização deste arquivo. **A Parte 4** é quem passa a usar isso nos "relacionados".

### Não verificado (3A)
- O vocabulário foi escrito à mão, sem olhar o acervo real: na 3B, olhar a distribuição de conceitos
  e itens sem nenhum conceito (`source="category"`/`"none"`) e acrescentar termos que faltam.
- Palavras que significam outra coisa em contexto (ex.: "orange" cor x fruta) ficam de fora de
  propósito; títulos muito curtos ou só com número não geram conceito.

## Parte 3B — o que foi feito (conceitos no banco)

- **Colunas** em `vortex_items`: `concepts` (`"carro_esportivo:1,estrada:0.84"`), `concept_tags`
  (`" carro_esportivo carro veiculo_rodas veiculo "`, p/ `LIKE '% veiculo_rodas %'`), `concept_version`.
  NULL = nunca analisado; `concepts=""` = analisado sem pista (guarda só o domínio da categoria).
  Upgrade automático em `app.py`.
- **`vortex_understand.py` (novo)**: `build_fields`, `suggest_category`, `process_batch`, `reprocess_all`,
  `coverage`, `cli`. UPDATE em lote só grava linha ainda desatualizada (não sobrescreve resultado mais novo do
  CLIP); troca de categoria só se a linha ainda estiver em "outros".
- **Quando roda**: item novo no `enrich`; acervo antigo em `IngestEngine._concepts_loop` (só texto, lotes de 500,
  mais novo primeiro, não é afetado por pausa/velocidade); recalcula em `_apply_clip` quando o CLIP preenche
  `visual_tags`. Desliga com `VORTEX_CONCEPTS_ENABLED=0`.
- **"outros"**: vira a categoria do domínio se confiança >= 0.6 (`VORTEX_CONCEPTS_RECLASSIFY_MIN_CONFIDENCE`).
  Nunca mexe em categoria definida pela fonte.
- **Admin**: bloco "Compreensão do conteúdo" + tile em tempo real em `/admin/vortex/conteudo`; filtro
  `?conceito=<id|nenhum>` e assunto principal por peça em `/admin/vortex/itens`.
- **CLI**: `python vortex_concepts.py --reprocess [--force] [--limit N]` e `--report` (conceitos mais comuns,
  itens sem conceito, palavras frequentes nesses títulos = o que falta no vocabulário).
- **Correções na 3A** (`CONCEPTS_VERSION` = 2): tags de aparência (cor/luz) nunca viram conceito ("rosa" não é flor);
  `tags`/descrição só CONFIRMAM o título (+25 %) em vez de somar; cenário (estrada, praia...) pesa x0,7 quando
  há assunto ("red sports car on a road" = carro); "sample" removido do vocabulário (virava laboratório).
- Testes: `tests/test_vortex_understand.py` (37).

### Não verificado / avisos
- Vocabulário escrito à mão, **não visto contra o acervo real**: rode `--reprocess` e depois `--report`.
- O SQLAlchemy emite `is_active IS 1`, que não casa com índices parciais do SQLite (vale também p/ os de visão e
  qualidade); a consulta de pendentes usa `(is_active, id)`. Com o teto de 60 mil itens custa poucos ms por ciclo.
- Flutter: nada mudou na 3B. Nada usa os conceitos ainda — a Parte 4 (relacionados) é quem passa a usar.

## Parte 4 — o que foi feito ("Mais como este" por conceito)

Só `vortex_search.related_items` mudou (edição cirúrgica; mesma assinatura, mesmo formato de resposta, **nada muda
no site nem no Flutter**: `/vortex/item/<id>`, `/related` e a página web já chamam essa função).

- **Candidatos por conceito/família**: `_concept_candidate_ids` busca em `concept_tags` (LIKE com espaços) os
  3 conceitos principais da peça + a família de cada um (carro -> todo `veiculo_rodas`), sem depender de tag ou categoria.
- **Corte por assunto**: `vcn.similarity(conceitos da peça, conceitos do candidato)`; abaixo de `_MIN_CONCEPT_SIM`=0,3 a peça
  é descartada (carro x dança/balão = 0; carro x avião = 0,25, também cai). Domínio-só NÃO passa.
- **Nota**: `+ _W_CONCEPT(6,0) x similaridade` (carro > moto/caminhão > ônibus). Os sinais antigos (CLIP, aparência, dHash,
  tags, título) continuam; o conceito só soma e filtra.
- **Peça de origem sem conceito** (acervo ainda não reprocessado / sem pista): comportamento IDÊNTICO ao da Parte 3.
- **Candidata ainda não analisada** (sem conceito): só entra se a nota passar `VORTEX_RELATED_MIN_SCORE` (padrão 0,9) e
  **nunca** serve de preenchimento por categoria quando a peça de origem tem assunto conhecido (lista fica curta, mas certa).
- **Co-cliques** (`coclick_counts`): quem abriu/curtiu a peça e outra em <= 2 h (60 dias), contando só >= 2 PESSOAS
  distintas; bônus até `_W_COCLICK`=1,5. Entra no pool, mas passa pelo mesmo corte por assunto. SQL usa `julianday`
  (SQLite); qualquer erro de banco devolve `{}` e a sugestão segue sem o sinal.
- Testes: `tests/test_vortex_related_concepts.py` (6).

### Não verificado / avisos (Parte 4)
- Vocabulário e limiares calibrados só com dados sintéticos. Depois de `python vortex_concepts.py --reprocess`, abrir
  algumas peças e conferir se faltam sugestões (se a lista ficar curta demais: baixar `_MIN_CONCEPT_SIM` ou
  `VORTEX_RELATED_MIN_SCORE`).
- Uma tag em comum (jaccard 1,0 ~ +4,6) ainda pode passar um parente de conceito sem tag (+3,9 de carro->moto): é proposital
  (tag igual é sinal forte), mas se incomodar subir `_W_CONCEPT`.
- "Relacionados" e busca ainda NÃO consultam o livro de vistos (Parte 1). Flutter: não mexido nem compilado.
- `recent_boost` (grade) usa `related_items`, então já herda o corte por assunto ("o que acabei de ver" mais certeiro).

## Parte 5 — o que foi feito (interesse por conceito + anti-vício)

Quase tudo em `vortex_taste.py` (a docstring ganhou os itens 7 e 8). Mesmo endpoint, mesmo formato de peça.

- **Sinal com conceito**: `vortex_interactions.concepts` (coluna nova, upgrade automático em `app.py`). `record` copia
  `item.concepts`; a busca grava os conceitos achados nas palavras (`find_concepts`: "moto" -> moto).
- **Perfil por conceito** (`Profile.concept`, `own_concept`, `top_concepts`): soma com o mesmo decaimento de 72 h e espalha o
  crédito pros ancestrais x0,6 por nível (carro 1,0; veículo de rodas 0,6; veículo 0,36). Peças antigas sem a coluna só não
  contam (nada quebra).
- **Nota**: quando a peça E o perfil têm conceito, `W_CONCEPT`=0,40 + categoria 0,20 + tag 0,15 + tipo 0,10 + perfil-robô
  0,15 (soma 1,0). Moto sai com ~0,6 de afinidade pra quem curte carro, avião ~0,36, dança 0. Sem conceito: cálculo antigo.
- **Candidatos**: o pool também busca por `concept_tags` dos 3 interesses principais (inclui a família).
- **Mistura a cada 5 posições** (`_assemble`): 3 interesse, 1 **adjacente** (slot%5==3: parentesco 0,4–0,8 com um interesse-base
  e conceito exato ainda não clicado — `adjacency`), 1 **descoberta** (slot%5==0: fora de tudo; adjacente não entra aqui).
  Clicou na moto algumas vezes (afinidade >= 0,3)? Ela vira interesse e para de ser adjacente.
- **Saturação** (`_cap_subject`, depois da limpeza): no máximo `SATURATION_MAX`=6 do mesmo DOMÍNIO em 12 posições
  (`VORTEX_FEED_SATURATION_WINDOW/MAX`); cede se só sobrou aquele assunto. Peça sem conceito nunca é limitada.
- **Aviso de pausa** (`wellbeing`): tempo CONTÍNUO (cliques + peças vistas; silêncio > 10 min zera). A cada 30 min (`level`)
  `suggest_break=true`. `VORTEX_BREAK_AFTER_MINUTES=0` desliga. Vai em `GET /api/v1/vortex` (`wellbeing`), na página
  `/pictures` (data-attributes) e em `/api/pictures/mais`. Site: faixa fixa com "Continuar" (reaparece só se o nível
  subir; `sessionStorage`), CSS `.vortex-break-notice`. Flutter: `PicturesPage.breakMinutes/breakLevel` + SnackBar em
  `pictures_screen.dart` (`_maybeShowBreakNotice`). `sw.js` -> `driqy-shell-v48` (testes atualizados).
- Testes: `tests/test_vortex_interest.py` (11).

### Não verificado / avisos (Parte 5)
- Flutter NÃO compilado (só o SnackBar e o parse do `wellbeing`); site/faixa não abertos num navegador.
- Pesos e limiares calibrados com dados sintéticos; sem o `--reprocess` da 3B quase nada tem conceito e a grade segue como antes.
- O aviso de tempo mede só atividade registrada (cliques/vistos); rolar sem peça nova confirmada não conta.
- Depois de uma mudança grande de gosto o "interesse" antigo some em dias (meia-vida 72 h), não horas.

## Parte 6 — o que foi feito (tema no Flutter + curtir / "menos disso" na grade)

**Só Flutter. O backend NÃO mudou** (já tinha `POST /api/v1/vortex/interact` com `like` e `less`, e o
`less` já bloqueia a peça por 120 dias no livro de vistos e derruba a afinidade/conceito).

### 1) Tema do Vortex (claro/escuro)
**Situação encontrada:** o app Flutter só tinha tema escuro (`MaterialApp(themeMode: dark)`, ~300 usos de
`AppColors` fixos escuros em ~40 arquivos) e o Vortex tinha `Colors.black` fixo. Virar o app inteiro para
claro deixaria telas ilegíveis, então o tema ficou **restrito ao Vortex** (sem tocar no resto do app).

- **`lib/theme/vortex_theme.dart` (novo)**
  - `VortexColors` (`dark` / `light` / `of(context)` pelo brilho do `Theme`): `bg`, `tileBg`, `searchBg`,
    `border`, `text`, `textMuted`. Escuro = **preto** (visual Pinterest pedido antes); claro = `#F7F4EE` (mesmo
    `--bg` do `[data-theme="light"]` do site). Para o escuro usar o fundo padrão do app (`#121016`), trocar
    `VortexColors.dark.bg` por `AppColors.bg`.
  - `VortexThemeController` (singleton `ChangeNotifier`): guarda `dark|light` em `SharedPreferences` na **mesma
    chave do site** (`driqy-theme`), padrão escuro; `load()` (chamado no `main` antes do `runApp`),
    `setBrightness`, `toggle`. **Não sincroniza com o servidor** (não existe preferência de tema no backend; o
    site guarda no `localStorage`).
  - `VortexThemeScope`: coloca `AppTheme.dark()`/`AppTheme.light()` em volta da tela (reconstrói quando o
    controlador muda). `VortexThemeButton`: ícone sol/lua.
- **`AppTheme.light()` (novo, em `app_theme.dart`)**: mesmos tokens claros do `style.css`. `dark()` ficou igual
  (só o `_textTheme` ganhou um parâmetro de cor opcional).
- **Telas**: `PicturesScreen`, `VortexDetailScreen` e `VortexSearchScreen` viraram um `StatelessWidget` fino
  (mesmo construtor de antes, **nenhum chamador mudou**) que envolve o corpo (`_PicturesBody`,
  `_VortexDetailBody`, `_VortexSearchBody`) num `VortexThemeScope`. Fundo do `Scaffold`, caixa "Buscar no
  Vortex", contador, "Você chegou ao fim", placeholders das peças e textos secundários usam `VortexColors`.
  Botão sol/lua: ao lado da caixa de busca da grade e na AppBar do detalhe e da busca.
  `DriqyTopBar` (pílula "Buscar no Driqy") também usa `VortexColors`: no tema escuro os valores são idênticos
  aos de antes, então o Feed não muda.
- O que fica **por cima da mídia** (play, duração, nome do perfil, anel de contagem) continua branco/preto fixo
  de propósito: depende da foto, não do tema.

### 2) Curtir / "Menos disso" na grade
- **Segurar uma peça** (grade principal, busca e "Mais como este") abre uma folha com **Abrir / Curtir / Menos
  disso** (`lib/widgets/vortex_tile_actions.dart`: `showVortexTileActions`, `reactToTile`, `VortexTileReactions`,
  `VortexLikedBadge`). Vale para peça do crawler E para post de usuário (usa `item_id` ou `post_id`).
- **Curtir**: envia `like`, põe um coração no canto da peça e avisa "Vamos mostrar mais coisas assim".
- **Menos disso**: envia `less` e a peça **some na hora**. Ela continua na lista interna (só não é desenhada)
  para as outras NÃO trocarem de coluna (a distribuição é round-robin pelo índice). O servidor também não a
  devolve mais (livro de vistos "rejeitado", 120 dias). Não há "desfazer" (o backend não tem sinal inverso).
- Estado de curtidas/escondidas vive no `State` da tela: ao atualizar/reabrir, o servidor já cuida (a peça
  rejeitada não volta; a curtida só aparece como coração durante a sessão da tela).
- `PinFrame`/`VortexTileCard`/`VortexMasonry` ganharam `onLongPress`, `liked` e `hidden` (todos opcionais).

### Testes / não verificado
- **Flutter NÃO compilado nem rodado** (sem SDK na sessão). Conferi só o balanço de parênteses/chaves. Se
  `flutter analyze` reclamar, os lugares mais prováveis são `vortex_theme.dart`, `vortex_tile_actions.dart` e a
  divisão wrapper/corpo nas três telas. Rodar também `flutter test test/vortex_theme_test.dart` (novo: cores
  claro/escuro, persistência do tema, botão sol/lua, reações).
- **Tema claro só vale dentro do Vortex.** Telas abertas a partir dele (post, perfil, mensagens) seguem escuras.
  Migrar o app todo = criar tokens de tema no lugar dos `AppColors` fixos e ligar o controlador ao `themeMode`.
- Mensagens › Aparência no Flutter continua sem opção de tema (só o botão sol/lua do Vortex troca).
- Backend: nada alterado nesta parte (suíte de testes não foi tocada).

### Dicas para a Parte 7 (tema no SITE)
- `static/css/style.css`, bloco "Vortex — visual Pinterest" (~linha 4899): `body.pictures-page` **força** tokens
  escuros (`--bg:#000; --surface:#121016; ...`) e `background:#000` mesmo no tema claro. É isso que precisa sair/ser
  condicionado a `[data-theme="dark"]`; no claro usar `var(--bg)`/`var(--surface)` do tema. Conferir também
  `.picture-tile` (`background:#1c1a24` fixo), `.vortex-break-notice` e a barra/chips de `_vortex_toolbar.html`.
- Qualquer mudança em CSS/JS: subir `static/sw.js` (`driqy-shell-v48` → `v49`) e atualizar os testes que fixam a
  versão (`test_mensagens_part1.py`, `test_ping_phase4a.py`, `test_ping_phase7.py` e quem mais der `grep`).
- O site já aceita `like`/`less` em `POST /api/pictures/interact` (`{kind, item_id|post_id}`); a Parte 7 pode
  ganhar o mesmo "segurar/botão ⋯ → Curtir / Menos disso" da grade web.

## Parte 7 — o que foi feito (tema no site)
- `static/css/style.css` (bloco "Vortex — visual Pinterest"): `body.pictures-page` agora usa `background: var(--bg)`; o
  preto + tokens escuros só valem sob `[data-theme="dark"] body.pictures-page`. No tema claro o fundo, as peças
  (`background: var(--surface-2)`), chips e busca usam os tokens claros do site. Nada mais é forçado.
- `static/sw.js` -> `driqy-shell-v49` (testes que fixam a versão atualizados via sed em `tests/`).
- Novo `tests/test_vortex_theme_site.py` (3). Rodados: ele + `test_mensagens_layout/part1`, `test_ping_phase4a/7` = 26 passando
  (a suíte inteira NÃO foi rodada de novo; é lenta, ~15 min).
- **Não verificado:** página não aberta num navegador no tema claro. Conferir contraste de `.picture-tile-by`,
  `.picture-tile-badge`, `.vortex-break-notice` e `vortex_item.html` (título/descrição) no claro.
- **Não feito:** curtir/"menos disso" na grade web (o endpoint `POST /api/pictures/interact` já aceita `like`/`less`;
  falta só um botão ⋯ no `_picture_tile.html` + `vortex.js`, escondendo a peça no clique).

## Parte 8 — o que foi feito (painel de saúde + conferência de testes)
- **Novo `vortex_health.py`** (só lê o banco): fila (pendentes, ritmo 24 h, ETA, falhas), recomendação (sinais por tipo
  em 24 h/7 d, pessoas ativas, taxa de "menos disso" e de curtida, livro de vistos com taxa de repetição), cobertura de
  conceitos e `alerts` em português. Limites no topo do arquivo (`LESS_RATE_WARN`=15%, `REPEAT_RATE_WARN`=25%,
  `CONCEPT_COVERAGE_WARN`=80%, `QUEUE_ETA_WARN_HOURS`=72).
- **Rotas admin** `/admin/vortex/saude` (página) e `/admin/vortex/saude.json`; aba "Vortex (saúde)" em `_admin_base.html`;
  template `templates/admin/vortex_health.html`. Só admin.
- `tests/test_vortex_health.py`: 8 testes passando.

### Conferência de testes (Parte 8)
- 24 arquivos fora do chat: passaram (318 testes). Todos os `test_vortex_*` passaram, incluindo os novos.
- `test_vortex_vision::test_clip_tags_category_and_semantic_related` falhou UMA vez rodando vários arquivos em paralelo
  (`arquitetura` != `natureza`); passa sozinho 3x e no código original. Parece instável sob carga (não investigado).
- Chat: os 14 arquivos `test_chat_phaseN.py` foram conferidos um por vez e **passam todos** (fechamento da Parte 8).
- Dica: rodar a suíte inteira de uma vez é muito lenta aqui; rode por arquivo.

### Fechamento da Parte 8 — o que faltava e foi feito
- **Curtir / "Menos disso" na grade web** (era a pendência da Parte 7): duas bolinhas (♥ e ✕) no canto inferior direito de
  cada peça (crawler e post de usuário), fora do `<a>` (não abrem o detalhe). Aparecem no hover/foco; em tela de toque ficam
  sempre visíveis. ♥ envia `like` e pinta a peça (`is-liked`); ✕ envia `less` e a peça some na hora (`hidden`; o servidor
  também para de entregá-la por 120 dias). Usa o `POST /api/pictures/interact` que já existia.
  Arquivos: `templates/_picture_tile_actions.html` (novo, incluído em `_picture_tile.html`), `static/js/vortex.js`,
  `static/css/style.css`. `sw.js` -> `driqy-shell-v50` (testes que fixam a versão atualizados).
- Testes novos: `tests/test_vortex_web_actions.py` (5). Reconferidos junto: theme_site, seen, health, mensagens e ping
  (103 passando).
- Os 14 `test_chat_phaseN.py` rodados um por vez: todos passam.

### Plano de 8 partes: concluído. Pendências abertas
- Flutter não compilado (`flutter analyze`, `flutter test`); site não visto num navegador (tema claro, bolinhas ♥/✕ nas
  peças — conferir contraste e se não cobrem o nome do perfil no celular); ~~tema claro só dentro do Vortex no Flutter~~ (**resolvido na Parte 9B: tema claro no app inteiro, ainda sem compilar**);
  vocabulário de conceitos/limiares e adaptadores do crawler sem teste com dados reais.
- ~~Sem "desfazer" para "menos disso"~~ → **resolvido na Parte 9** (backend `undo_less`, site e Flutter).

## Parte 9 — pendências da Parte 8 resolvidas (backend + site + Flutter)

### 9A — backend e site
- **Teste instável**: o laço de conceitos reclassificava a categoria só pelo texto, correndo contra o laço do CLIP
  (`vortex_understand.process_rows(clip_enabled=...)`: item que ainda vai passar pelo CLIP não é reclassificado só pelo texto).
  Não consegui reproduzir a falha original; a correção vem da leitura do código.
- **Desfazer "Menos disso"**: `vortex_taste.undo_less`, `vortex_seen.clear_rejected`; `kind: "undo_less"` aceito em
  `POST /api/pictures/interact` e `POST /api/v1/vortex/interact`. Site: aviso "Desfazer" (6 s) em `vortex.js`;
  `sw.js` -> `driqy-shell-v51`. Testes: `tests/test_vortex_undo_less.py`.
- **Não verificado**: site num navegador (contraste no tema claro, bolinhas ♥/✕ no celular).

### 9B — Flutter (desfazer "Menos disso" + tema claro no app inteiro)
- **Desfazer "Menos disso"**: SnackBar com ação "Desfazer" em `vortex_tile_actions.dart` (manda `undo_less`, peça volta).
- **Tema claro no app inteiro**: `AppColors` (bg, surface, surface2, border, text, textMuted, amber, rose, danger, onBrand)
  agora são getters que leem `AppColors.brightness`; `AppGradients` também. NÃO use `const` em widget que os receba.
  `VortexThemeController` atualiza `AppColors.brightness` e `main.dart` liga `themeMode` + reconstrói as telas abertas
  (`_RebuildOnTheme`). `VortexThemeScope` virou pass-through. Interruptor "Tema claro" em Mensagens › Notificações e sons › Aparência.
  `AppTheme.dark()` usa constantes próprias (`_Dk`). Os `const` que quebraram foram removidos com ajuda do analisador.
- **Verificação**: `dart analyze` (SDK Dart 3.13 + Flutter stable, SEM os pacotes do pub.dev) não achou erro do código do app;
  só erros de pacotes ausentes. NÃO foi rodado `flutter analyze`/`flutter test` de verdade: rode na sua máquina.
  `test/vortex_theme_test.dart` pode precisar de ajuste (o `VortexThemeScope` não aplica mais `Theme`).
- Telas com cores fixas fora de `AppColors` (ex.: `Colors.white`/`Colors.black`) não mudam com o tema; conferir visualmente no claro.
