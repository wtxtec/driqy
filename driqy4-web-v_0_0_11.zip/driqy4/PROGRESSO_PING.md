> **NOTA (out/2026): o Ping voltou a se chamar "Mensagens" e a tela de Configurações/foto/caneta foram removidas — ver `PROGRESSO_MENSAGENS.md`.**

# PROGRESSO — Ping (antigo "Mensagens") com layout estilo Telegram (10 fases)

> **Índice geral e o que ainda resta (verificado em 10/11/2026): `PROGRESSO_INDICE.md`.**
> Zips: o nome `..._ping_faseN.zip` citado abaixo é antigo; vale o padrão atual `driqy-flutter_v_0_0_N.zip` / `driqy4-web-v_0_0_N.zip`.

> Passagem de bastão entre sessões/IAs. Igual nos dois projetos
> (`driqy4/` e `flutter_app/`). **Atualize ao fim de cada fase** e pare ao
> terminar a fase. Continua o trabalho do `PROGRESSO_CHAT.md` (chat 1-para-1
> já existe e funciona; aqui só muda nome + layout/visual).

## Pedido original
1. Renomear **"Mensagens" → "Ping"**.
2. Ao entrar no Ping o **layout muda**:
   - **Desktop**: estilo **Telegram Web** — lista de conversas à esquerda
     (☰ + busca, aviso dispensável, linhas com avatar/hora/badge, botão
     flutuante de novo ping) e a conversa à direita, com fundo de padrão
     desenhado e estado vazio "Selecione uma conversa".
   - **Celular**: estilo **Telegram Android** — título, busca arredondada,
     aviso dispensável, lista, botão flutuante (novo ping) e **barra inferior
     flutuante em pílula** (Chats, Contatos, Configurações, Perfil).
3. Tudo **nas cores do Driqy** (âmbar `#f2a93b` → rosa `#e85d75`, fundo
   `#121016`; o roxo do Telegram vira o gradiente âmbar→rosa da marca).
4. Em **10 fases**, deixando este .md para a próxima IA.

## REGRA NOVA (fase 2): o Ping é um app À PARTE do Driqy — tipo Messenger
Dentro do Ping **não aparece a logo do Driqy, nem a barra de busca do topo
do site, nem a topbar/sidebar/bottom-nav do Driqy**. O cabeçalho do Ping
mostra **apenas o nome "Ping" e um botão de voltar** (que volta para o Driqy,
ex.: `url_for('main.feed')`; no Flutter, sai do Ping para a Home). A busca
estilo Telegram *dentro da lista de conversas* (Buscar no Ping) **continua**:
é parte do layout de referência e só filtra conversas. *(Suposição da IA da
fase 2 — se o usuário quiser sem essa busca também, remover na fase 4.)*
Impacto: fase 3 (shell sem chrome do Driqy), fase 7 (a pílula inferior
Chats/Contatos/Configurações/Perfil passa a ser a **única** navegação do Ping
no celular) e fase 9. A bottom-nav do Driqy **não** aparece no Ping.

## Regras do usuário (respeitar)
- Respostas curtas, em português do Brasil.
- Edições **cirúrgicas** (nada de reescrever arquivo inteiro sem necessidade).
- Entender os **riscos antes** de implementar (seção "Riscos").
- Mudança vale para **site desktop, site celular e Flutter** (backend só se
  precisar). Não entregar fase só num deles.
- **Entregar sempre os dois zips COMPLETOS** (projeto inteiro, não só os
  arquivos tocados): `driqy_flutter_ping_faseN.zip` e
  `driqy4-noticias-api_ping_faseN.zip` (N = fase concluída).
- Fazer **só a próxima fase** e parar.

## Status das fases

| # | Escopo | Status |
|---|---|---|
| 1 | Renomear "Mensagens" → "Ping" (rótulos visíveis, site + Flutter) | ✅ feita |
| 2 | Tokens de tema Ping (cores Driqy, padrão de fundo SVG, gradiente) — site (`--ping-*` no CSS) + Flutter (`ping_theme.dart`) | ✅ feita |
| 3 | "Modo Ping": ao entrar em `/mensagens/*` o site usa shell próprio **sem logo/busca/menus do Driqy** (cabeçalho = "Ping" + botão voltar ao Driqy; desktop 2 colunas ≥ 900px; celular 1 coluna). Flutter: Ping sai da `HomeShell`/abas e vira rota própria com `PingAppBar` | ✅ feita |
| 4a | Lista: ☰ (menu Arquivadas/Chamadas/privacidade) + busca "Buscar conversas" (filtra no cliente) + aviso dispensável — site + Flutter | ✅ feita |
| 4b | Lista: linhas estilo Telegram (avatar maior, hora, badge âmbar→rosa, fixada/silenciada) + FAB "novo ping" — site + Flutter | ✅ feita |
| 5a | Painel da conversa: cabeçalho estilo Telegram, fundo com padrão de doodles, bolhas nas cores Driqy — site + Flutter | ✅ feita |
| 5b | Painel da conversa: composer nas cores Driqy (campo pílula, botão enviar gradiente), estado vazio "Selecione uma conversa" refinado — site + Flutter | ✅ feita |
| 6a | Desktop: abrir conversa sem recarregar (fetch do fragmento + `history.pushState`, ciclo de vida do `chat-thread.js`) — só site (Flutter não se aplica) | ✅ feita |
| 6b | Botão ↓ com contador de não lidas (+ abrir na 1ª não lida), mensagem fixada — site + Flutter | ✅ feita |
| 7 | Celular: barra inferior flutuante em pílula (Chats, Contatos, Configurações, Perfil) + FAB — site mobile e Flutter; é a única navegação do Ping | ✅ feita |
| 8 | Telas "Contatos" e "Configurações" do Ping (reaproveitar seguidores/seguindo e `settings` existentes) — site + Flutter | ✅ feita |
| 9 | Flutter em tela larga (tablet/web): master-detail com `LayoutBuilder` ≥ 900; transições — só Flutter | ✅ feita |
| 10 | Polimento: tema claro, acessibilidade, `prefers-reduced-motion`, testes, bump do SW, revisão final dos riscos | ✅ feita |
| 11 | Aproximação final do Telegram (extra pedido depois) — site + Flutter | ✅ feita |
| 12 | Extra: visualização única (foto/vídeo/áudio) + ajuste da caixa de imagem — backend + site + Flutter | ✅ feita (Flutter não compilado) |

## Fase 1 — o que foi feito
Só rótulos visíveis; **nenhuma rota, id, classe ou canal mudou**.
- Site: `templates/base.html` (ícone da topbar `aria-label/title`, item da
  sidebar, item da barra inferior), `templates/messages_inbox.html` (título da
  aba e `<h1>`). `static/sw.js`: cache `driqy-shell-v26` → `v27`.
- Flutter: `home_shell.dart` (drawer e barra inferior), `driqy_top_bar.dart`
  (tooltip), `messages_inbox_screen.dart` (título), `push_notification_service.dart`
  (**só o nome** do canal Android; o **id `driqy_messages` NÃO mudou** — precisa
  bater com `push.py`).
- Decisão: o botão **"Mensagem"** no perfil/busca (ação de iniciar conversa)
  e os textos "Mensagem apagada", "Mensagem" (placeholder do composer) ficaram
  como estão. Se o usuário quiser "Ping" ali também, é fase futura.
- URL continua `/mensagens` (`chat_bp url_prefix` em `chat.py`): mudar quebraria
  links salvos, push e service worker. Se quiserem `/ping`, criar redirect 301.

## Fase 2 — o que foi feito (só tokens; nada usa ainda, visual igual)
- Site: bloco "Tokens do Ping" em `static/css/style.css` (logo antes de
  `* { box-sizing }`): `--ping-gradient`, `--ping-on-accent`, `--ping-bg`,
  `--ping-panel(-hover)`, `--ping-row-active`, `--ping-search-bg`,
  `--ping-bubble-in(-text)`, `--ping-bubble-out(-text)`, `--ping-badge(-muted)`,
  `--ping-pill-bg`, `--ping-radius-panel/pill`, `--ping-pattern` (doodles SVG
  em data-URI, âmbar no escuro / âmbar escuro no claro). Overrides do tema
  claro em `[data-theme="light"]`. Classe pronta: `.ping-bg` (cor + padrão).
  `sw.js` cache `v27` → `v28`. Teste: `tests/test_ping_phase2.py`.
- Flutter: `lib/theme/ping_theme.dart` — `PingColors.of(context)` (dark/light;
  o app hoje só tem tema escuro), `PingColors.gradient`, `PingBackground`
  (cor + `PingPatternPainter` com doodles desenhados em Canvas, determinístico).
  Teste: `test/ping_theme_test.dart` (**não rodado**, sem SDK).
- Para usar: fundo do painel da conversa = `.ping-bg` / `PingBackground`;
  balão enviado = `var(--ping-bubble-out)` / `PingColors.gradient`; linha
  selecionada = `var(--ping-row-active)`; FAB = `--ping-gradient`.

## Fase 3 — o que foi feito (shell do Ping, sem o chrome do Driqy)
**Site**
- Novo `templates/ping_base.html` (NÃO estende `base.html`): cabeçalho com botão
  voltar (`main.feed`) + "Ping"; flash; `.ping-shell` com `#ping-list-col`
  (`block ping_list`) e `#ping-main-col` (`block ping_main`); `block
  ping_active_username`; `block body_class` (usar `ping-view-list` ou
  `ping-view-main`). Scripts mantidos: `settings.js` (tema/som), SW,
  `chat-live.js`, `calls-api.js`, `call-ui.js`, `chat.js`, `ping-shell.js` +
  `block scripts`. **Não carrega** `notifications.js`, `search.js`, `ui.js`
  (são do chrome do Driqy).
- Novo `templates/_ping_list.html` = corpo antigo do inbox (barra Arquivadas/
  Chamadas/privacidade + `#chat-inbox-list`); h1/subtítulo só na visão
  "arquivadas". Incluído nas 3 páginas (`messages_inbox.html`,
  `messages_thread.html`, `calls_history.html`), todas agora estendem `ping_base`.
- `chat.py`: `_ping_list_ctx()` (conversas p/ a coluna esquerda) usado em
  `thread` (depois do commit que marca como lidas) e `calls_history`.
  **Custo**: a lista é montada a cada abertura de conversa; a fase 6 elimina.
- `static/js/ping-shell.js`: marca `.is-active` na linha da conversa aberta
  (MutationObserver só em `childList`, sem laço).
- CSS (fim do `style.css`, "Ping — shell próprio"): celular <900px = 1 coluna
  (`body.ping-view-list` mostra a lista, `ping-view-main` a conversa); desktop
  ≥900px = grade `minmax(300px,380px) 1fr` com painéis arredondados; `.cw-back`
  some no desktop. Tela vazia do desktop: `.ping-empty.ping-bg` com
  "Selecione uma conversa para começar" (fase 5 refina). `sw.js` `v29`.
- Testes: `tests/test_ping_phase3.py` (sem chrome do Driqy nas 3 páginas, duas
  colunas, scripts de chamada/ao vivo mantidos, lida antes de listar).
- As classes antigas `body.chat-page .content` ficaram no CSS mas não
  se aplicam mais (não existe `.content` no Ping); podem ser apagadas na fase 10.

**Flutter**
- Novo `lib/widgets/ping_app_bar.dart` (`PingAppBar`: voltar + "Ping").
- `messages_inbox_screen.dart`: usa `PingAppBar` (ação "Histórico de chamadas"
  foi pra barra; título duplicado "Ping" removido do corpo). Sem `DriqyTopBar`.
- `home_shell.dart`: o Ping **não é mais a aba 3**; o item "Ping" do Drawer e da
  barra inferior chamam `_openPing()` (push de `MessagesInboxScreen`). O
  `IndexedStack` agora tem 3 abas (Feed, Vortex, Notificações). Entradas que já
  empurravam a rota (ícone do topo, toque na notificação push) continuam iguais.
- **Não compilado/testado** (sem SDK): conferir `flutter analyze`. Ponto de
  atenção: o campo `onOpenMenu` de `MessagesInboxScreen` ficou sem uso (inofensivo).

## Fase 4a — o que foi feito (a fase 4 foi dividida em 4a/4b para não estourar tokens)
**Site**
- `_ping_list.html`: antes da barra antiga entram `.ping-searchbar` (botão ☰ `#ping-menu-btn` + `<input id="ping-search" placeholder="Buscar conversas">`) e `.ping-notice` (`#ping-notice`, dispensável). A barra antiga virou o **menu do ☰** (`#ping-menu`, começa `hidden`); **todos os ids do chat.js foram mantidos** (`chat-archived-link`, `chat-archived-count`, `chat-calls-link`, `chat-privacy-toggle`, `chat-inbox-list`). Na visão "arquivadas" não há ☰/aviso e a barra (com "Voltar") fica visível.
- `ping-shell.js`: o `return` antecipado agora só exige a lista (a marca `is-active` roda só se há conversa aberta); busca normaliza acentos, filtra com o atributo `hidden` nas linhas e reaplica via `MutationObserver` (`childList`) quando chat.js insere/remove linhas; aviso grava `ping-notice-v1` no `localStorage`.
- Placeholder é **"Buscar conversas"** (não "Buscar no Ping": o teste da fase 3 proíbe a string "Buscar no " por ser a busca do Driqy).
- CSS no fim do `style.css` ("fase 4a"); `sw.js` `v30`. Teste: `tests/test_ping_phase4a.py` (rodado: fases 2, 3 e 4a = 16 passando).
**Flutter** (`messages_inbox_screen.dart`)
- Texto explicativo + `SwitchListTile` saíram do corpo; entram `_searchBar()` (☰ `PopupMenuButton`: Arquivadas, Chamadas, "Mostrar online e visto por último" como `CheckedPopupMenuItem`; campo arredondado com `PingColors.searchBg`) e `_notice()` (flag `ping_notice_v1` em `shared_preferences`). Filtro em `_visible` (nome, @usuário, prévia); a linha "Arquivadas" some enquanto há busca.
- **Não compilado** (sem SDK): rodar `flutter analyze`. O ícone de chamadas na `PingAppBar` foi mantido (4b/7 decidem se sai).

## Fase 4b — o que foi feito (fase 4 completa)
**Site**
- CSS "fase 4b" (só dentro de `.ping-mode`, não afeta o resto do Driqy): linhas planas sem borda, avatar 52px, fixada com fundo `--ping-panel-hover`, badge em pílula com `--ping-gradient` (silenciada = `--ping-badge-muted`; na linha ativa vira invertida). Markup da linha (`_chat_inbox_row.html`) **não mudou** — o chat.js recria linhas a partir dele.
- Botão flutuante `#ping-fab` (sticky no fim da coluna da lista, gradiente) abre o painel `#ping-new` (busca de pessoas via `main.search_quick` = `/api/buscar`, 6 resultados) e cada resultado é um link para `/mensagens/<usuario>`. Esc/× fecham. Não aparece na visão "arquivadas". Lógica em `ping-shell.js`; `sw.js` `v31`.
- Testes: `tests/test_ping_phase4b.py` (fases 2, 3, 4a e 4b: 20 passando).
**Flutter** (`messages_inbox_screen.dart`)
- `floatingActionButton` com gradiente da marca → `_newPing()` abre `_NewPingSheet` (usa `SearchService.searchUsers`, debounce 250ms) e empurra `MessageThreadScreen`. Linhas: avatar raio 26, sem divisores, cantos 14, fixada com `panelHover`, badge em pílula. **Não compilado**: rodar `flutter analyze`.
- Limitação conhecida: a busca de pessoas não exclui o próprio usuário (abrir conversa consigo mesmo é tratado pelo backend; avaliar na fase 8, "Contatos").

## Fase 5a — o que foi feito (fase 5 dividida em 5a/5b)
**Site**: bloco CSS "fase 5a" no fim do `style.css`, **todo sob `.ping-mode`** (não afeta o resto do Driqy). Cabeçalho com `--ping-panel` e avatar 42px; `.cw-body/.cw-list` com `--ping-bg` + `--ping-pattern`; bolha recebida `--ping-bubble-in`, enviada `--ping-bubble-out` (gradiente), raio 18 com "rabinho" 5px; chip do dia sem borda; bolha só-emoji continua transparente; `.cw-composer` já usa `--ping-panel` (o resto do composer é a 5b). Markup/ids **não mudaram** (chat-thread.js intacto). `sw.js` `v32`. Teste: `tests/test_ping_phase5a.py` (fases 2–5a: 23 passando).
**Flutter**: `message_thread_screen.dart` — corpo dentro de `PingBackground`, `AppBar` com `PingColors.panel` sem elevação, avatar 20, nome w600; `message_bubble.dart` — recebida `bubbleIn` sem borda, textos via `PingColors`, raios 18/5; `date_separator.dart` — pílula `panel`. **Não compilado**: rodar `flutter analyze`. O estado de busca (borda âmbar na bolha achada) foi mantido.
- Atenção 5b: o `ChatComposer` (`lib/widgets/chat/chat_composer.dart`) e `.cw-field/.cw-send` ainda têm o visual antigo; o aviso "Nenhuma mensagem ainda" do Flutter também.

## Fase 5b — o que foi feito (fase 5 completa)
**Site**: CSS "fase 5b" (sob `.ping-mode`): `.cw-composer` flutua sobre o mesmo fundo de padrão; `.cw-field` em `--ping-panel` sem borda; botão enviar/mic com `--ping-gradient`; barra de resposta e painel de emojis em `--ping-panel`. Estado vazio (`messages_inbox.html`): `.ping-empty-card` com logo circular em gradiente + a pílula "Selecione uma conversa para começar". HTML do composer **intacto** (ids do chat-thread.js preservados; teste confere). `sw.js` `v33`. Teste: `tests/test_ping_phase5b.py` (fases 2–5b: 26 passando).
**Flutter**: `chat_composer.dart` — `Material` transparente (flutua sobre `PingBackground`), campo e barra de gravação em `PingColors.panel` sem borda; `message_thread_screen.dart` — estado vazio virou pílula `panel`. **Não compilado**: rodar `flutter analyze`.
- Não mexi: painel de emojis do Flutter (`emoji_panel.dart`) e o sheet de anexos continuam com o visual antigo (fase 10, polimento).

## Fase 6a — o que foi feito (fase 6 dividida em 6a/6b)
**Site (desktop ≥900px; celular continua com navegação normal)**
- `chat.py` `thread()`: com o cabeçalho `X-Ping-Fragment` devolve só `_ping_thread_main.html` (**não monta a lista** — elimina o custo apontado na fase 3) e continua marcando como lidas. `messages_thread.html` agora só faz `{% include "_ping_thread_main.html" %}` (todo o miolo: `#cw`, composer, modais, toast). Auto-conversa continua redirecionando.
- `ping_base.html`: `#ping-shell` ganhou `data-thread-script` (url do `chat-thread.js`).
- `chat-thread.js`: **ciclo de vida** — `listenOn()` registra os listeners de `document`/`window` e `window.__pingThreadDestroy()` limpa intervalos/timeouts, cancela gravação, fecha vídeo/lightbox, remove listeners; os handlers do `driqyLive` (que não tem `off`) ignoram eventos após `destroyed`. **Regra: todo listener novo em `document`/`window` deve usar `listenOn`**; timers novos entram no `destroy`. Teste confere que não sobrou `document.addEventListener` solto.
- `ping-shell.js`: clique numa linha da lista (sem Ctrl/Shift/menu ⋯) → fetch do fragmento + texto do script (cacheado) → destrói a instância anterior → troca `#ping-main-col` → `pushState` → roda o script de novo. `popstate` em thread reabre; voltar para a lista recarrega. Qualquer erro cai em `location.href` (nunca pior que antes). `data-active-username` agora é lido a cada vez.
- `sw.js` `v34`. Teste: `tests/test_ping_phase6a.py`; suíte completa do site: 429 passando, 3 puladas.
- **Não testado em navegador real** (só pytest + `new Function` de sintaxe): conferir no desktop trocar de conversa várias vezes, enviar áudio, abrir emoji, voltar/avançar, e que não há mensagens duplicadas.
**Flutter**: nada a mudar (a fase 6 é só do site; master-detail do Flutter é a fase 9).

## Fase 6b — o que foi feito (fase 6 completa)
**Decisões**: a mensagem fixada vale **só para mim** (como fixar conversa na fase 10 de chat): não notifica nem aparece para o outro lado, uma por conversa (fixar outra substitui). Guardada em `ConversationPref.pinned_message_id` (coluna nova, **sem FK** de propósito: se a mensagem some, a faixa só deixa de aparecer).
**Backend**
- `models.py` + migração em `app.py` (`_ensure_schema_upgrades`, idempotente): `conversation_prefs.pinned_message_id`.
- `api.py`: `GET/PUT/DELETE /api/v1/messages/<usuario>/pin` (`PUT {"message_id": int}`; sempre responde `{"pinned_message": {id, msg_type, preview, sender_id, mine, created_at} | null}`). 400 para id não inteiro/bool, mensagem apagada ou de chamada, conversa consigo mesmo; 404 se a mensagem não é desta conversa ou eu a apaguei "para mim". Dispara o evento `prefs` (outras abas/aparelhos refazem o fetch). `serialize_prefs` **não mudou** (testes da fase 10 comparam o dict exato).
- `GET /api/v1/messages/<usuario>` ganhou (aditivo): `pinned_message`, `first_unread_id`, `unread_count` (calculados **antes** de marcar como lidas). A faixa some sozinha se a mensagem foi apagada para todos ou escondida para mim.
- `chat.py thread()`: a página/fragmento marca como lidas **antes** do JS buscar a conversa, então o servidor passa `first_unread_id`/`unread_count` ao template → `data-first-unread` / `data-unread-count` no `#cw` (e `data-pin-url`).
**Site** (`_ping_thread_main.html`, `chat-thread.js`, CSS "fase 6b" sob `.ping-mode`, `sw.js` `v35`)
- Faixa `#cw-pinned` entre o cabeçalho e a lista (barra gradiente + "Mensagem fixada" + prévia; clicar rola até a mensagem, ✕ desafixa). Menu da mensagem ganhou "📌 Fixar/Desafixar" (some em apagadas, em envio local e em chamadas). A bolha fixada mostra 📌 no horário (entra na `itemSig`).
- **Não lidas**: ao abrir com não lidas, a conversa abre **na 1ª não lida** com o divisor "N mensagens não lidas" (`.cw-unread`); o botão ↓ mostra quantas ainda estão fora da tela. O contador agora é um `Set` (`unseen`): ids do parceiro cuja base ainda está abaixo do rodapé da lista (`pruneSeen()` em `requestAnimationFrame` no scroll); chegar ao fim zera. Mensagens novas que chegam com a lista rolada para cima entram no mesmo conjunto (substitui o antigo `newWhileAway`). Sem não lidas, abre no fim como antes.
- Regras da 6a mantidas: nenhum listener solto em `document`/`window`; o `destroy` cancela o `requestAnimationFrame`.
- Testes: `tests/test_ping_phase6b.py` (11). Fiz também um **smoke test com jsdom** (fora do repo; DOM simulado com layout falso): divisor, abrir na 1ª não lida, contador 6→3→0, fixar/desafixar pelo menu, clicar na faixa. Suíte completa do site: **440 passando, 3 puladas**. Os 3 testes antigos que conferiam `driqy-shell-v34` passaram a conferir `v35`.
**Flutter** (`message_service.dart`, `message_thread_screen.dart`)
- `DriqyPinned` + `MessageThread.pinned` + `MessageService.setPinnedMessage(username, id|null)`. Tela: `_PinnedBar` (gradiente da marca, toque rola até a mensagem com `_jumpToMessage`, ✕ desafixa); folha do toque longo ganhou "Fixar/Desafixar" (`_ReactionSheet.actPin`); `_load`/`_refresh` atualizam `_pinned` (outro aparelho fixar → aparece no próximo ciclo/evento). Botão ↓ ganhou `Badge` com mensagens novas recebidas enquanto estou longe do fim (zera ao chegar ao fim/tocar). Teste: `test/pinned_message_test.dart`.
- **Não compilado** (sem SDK): rodar `flutter analyze` e `flutter test`. Só conferi balanceamento de `()`/`{}`/`[]`. Usa `Badge` (Flutter ≥ 3.7, o app já usa Material 3).
- **Não feito no Flutter** (fica para a 9/10): abrir na 1ª não lida + divisor (a lista é `ListView.builder` lazy; precisa de índice estimado como o `_jumpToMessage`) e o 📌 dentro da bolha.
- **Não testado em navegador/aparelho real**: conferir no desktop (abrir conversa com não lidas, rolar e ver o contador cair, fixar/desafixar, trocar de conversa com e sem fixada, tema claro) e no celular.

## Fase 7 — o que foi feito (pílula inferior no celular)
**Site** (`ping_base.html`, CSS "fase 7" no fim do `style.css`, `chat.js`, `sw.js` `v36`)
- `<nav id="ping-tabbar">` no `ping_base.html` (só logado; **não** vai no fragmento da 6a): Chats (ativa, selo de não lidas `#chat-badge-pingtab`, atualizado pelo `pollBadge` do `chat.js`), Contatos → `/u/<eu>/seguindo`, Configurações → `main.edit_profile`, Perfil → `/u/<eu>` (avatar se houver). **Esses 3 destinos são provisórios** e saem do Ping (páginas do Driqy); a fase 8 troca por telas dentro do Ping.
- CSS: `display:none` por padrão; só `<900px` **e** `body.ping-view-list` (lista de conversas) mostra a pílula fixa (`--ping-panel`, raio 999, sombra). Dentro da conversa e do histórico de chamadas (`ping-view-main`) ela some, e no desktop nunca aparece. A lista ganhou `padding-bottom: 96px` e o FAB/painel "novo ping" sobem (`bottom: 84px`) para não ficar atrás.
- Teste novo: `tests/test_ping_phase7.py`. O teste da 5b agora corta o bloco CSS na marca da 6b (antes ia até o fim do arquivo e pegaria regras de fases seguintes). Testes antigos passam a conferir `driqy-shell-v36`.
**Flutter**: `lib/widgets/ping_tab_bar.dart` (`PingTabBar`) usado em `Scaffold.bottomNavigationBar` do `MessagesInboxScreen` (fora da visão "arquivadas"); o FAB sobe sozinho. Selo = soma de `conv.unread`. Contatos abre o seletor de pessoas do FAB (`_newPing`; a fase 8 troca por tela de Contatos), Configurações → `EditProfileScreen`, Perfil → `ProfileScreen` do usuário logado. Teste: `test/ping_tab_bar_test.dart`. **Não compilado** (sem SDK): rodar `flutter analyze` e `flutter test`.
- Não testado em navegador/aparelho real: conferir no celular (<900px) se a pílula não cobre o último item da lista, se o FAB fica acima dela, tema claro e o teclado (a busca da lista não deve empurrar a pílula).

## Fase 8 — o que foi feito (telas Contatos e Configurações dentro do Ping)
**Decisões**: Contatos = quem eu **sigo** (aba padrão) e quem me **segue**; tocar na pessoa abre a **conversa** (ícone à direita abre o perfil). Configurações = conta + atalhos + privacidade (+ aparência/som **só no site**). O **Perfil** da pílula continua apontando para a página de perfil do Driqy (sai do Ping; não era escopo desta fase). Nomes `contatos` e `configuracoes` entraram em `RESERVED_USERNAMES` (`auth.py`; contas antigas continuam valendo).
**Backend**
- `chat.py`: `GET /mensagens/contatos` (`?aba=seguidores`) e `GET /mensagens/configuracoes` (antes de `/<username>`; passam `ping_tab` e `_ping_list_ctx()` → no desktop a lista de conversas segue à esquerda). Sem banidos, A→Z, até 300.
- `api.py`: `GET /api/v1/contacts?tab=following|followers&q=&page=` (50/página) → `{users:[serialize_user], has_next, counts:{following, followers}}`. É o que o Flutter usa.
**Site**
- `templates/_ping_tabbar.html` (extraído do `ping_base.html`): aba ativa por `ping_tab` (`chats` padrão | `contacts` | `settings`); Contatos → `chat.contacts`, Configurações → `chat.settings`.
- `ping_contacts.html` / `ping_settings.html` (estendem `ping_base`, `body_class` = `ping-view-main ping-tabpage`). `static/js/ping-pages.js` (busca no cliente + toggle de privacidade `#ping-set-presence`; **sem listener em `document`/`window`**). Id da privacidade é diferente do `#chat-privacy-toggle` do ☰ (evita id duplicado no desktop); um sincroniza o outro.
- CSS "fase 8" no fim do `style.css`; a pílula agora também aparece (<900px) em `body.ping-tabpage`. `sw.js` `driqy-shell-v37`.
- Configurações reaproveita markup/ids do `base.html` (`.theme-option`, `#setting-sound`) → `settings.js` funciona sem mudar. "Sair da conta" também está lá.
- Testes: `tests/test_ping_phase8.py` (10); `test_ping_phase7.py` agora confere os novos destinos; testes antigos conferem `v37`. Suíte completa do site: **454 passando, 3 puladas**.
**Flutter** (`lib/screens/ping_contacts_screen.dart`, `ping_settings_screen.dart`, `ping_nav.dart`; `ping_tab_bar.dart`, `user_service.dart`, `messages_inbox_screen.dart`)
- `PingTab` (enum) + `PingTabBar(current:, onChats:)`; `PingNav.go/tabBar`: a lista de conversas fica sempre embaixo na pilha; Contatos↔Configurações usam `pushReplacement` (pilha não cresce); Chats = `maybePop`; Perfil = push.
- `UserService.getContacts` + `ContactsPage`. Contatos: abas Seguindo/Seguidores com contagem, busca com debounce (servidor), "Carregar mais". Configurações: conta, Editar perfil, Chamadas, Arquivadas, switch de privacidade (`MessageService.get/setShowPresence`). **Sem tema/som no Flutter** (app só tem tema escuro e não tem opção de som).
- O selo de não lidas nas telas novas é o valor de quando foram abertas (não atualiza ao vivo).
- Testes: `test/ping_contacts_test.dart`, `test/ping_tab_bar_test.dart` (+1). **Não compilado** (sem SDK): rodar `flutter analyze` e `flutter test`. Só conferi balanceamento de `()`/`{}`/`[]`.
- **Não testado em navegador/aparelho real**: conferir no celular a pílula em Contatos/Configurações (aba ativa, conteúdo não escondido atrás dela) e no desktop as duas colunas.

## Fase 9 — o que foi feito (Flutter em tela larga; o site não mudou)
**Flutter** (`lib/widgets/ping_wide.dart` novo; `messages_inbox_screen.dart`, `ping_contacts_screen.dart`, `ping_settings_screen.dart`, `ping_nav.dart`)
- `MessagesInboxScreen.build` agora tem `LayoutBuilder`: **≥ 900dp** (`kPingWideBreakpoint`, igual ao site) vira `Row` = lista (36% da largura, 320–400) + divisor + **`Navigator` próprio** (`_detailKey`) no painel direito; abaixo disso é a tela de antes (mobile intacto). A visão "arquivadas" continua tela cheia nos dois modos. `PingWide` (InheritedWidget) marca o painel direito.
- `_showDetail(page, username:)` abre conversa / Contatos / Configurações / Perfil / Chamadas **no painel direito** (`pushAndRemoveUntil` até a rota vazia, com fade `pingFadeRoute`); no celular devolve false e o push normal acontece. Rota da conversa tem `name: kPingThreadRoute` + argumento @usuário; `PingDetailObserver` informa a conversa aberta → a linha fica destacada (`_activeUsername`). Estado vazio = `PingEmptyDetail` ("Selecione uma conversa para começar", igual ao site).
- Contatos/Configurações no painel direito: `AppBar` com ✕ (fecha) no lugar de `PingAppBar`, **sem pílula** (a lista já está ao lado); `PingNav` usa `pingRoute` (fade no largo, Material no celular). Dentro do painel, abrir uma conversa a partir de Contatos empilha por cima (voltar retorna a Contatos).
- Botão voltar do Android no modo largo: `WillPopScope` fecha primeiro o painel direito (`maybePop`), só depois sai do Ping. O `WillPopScope` da conversa (fecha busca/edição) continua valendo.
- Trocar de largura (rotação/redimensionar) atravessando 900dp **perde o que estava aberto no painel direito** (a árvore muda) — aceito.
- Testes: `test/ping_wide_test.dart` (breakpoint, `PingWide.of`, estado vazio, observer). **Não compilado** (sem SDK): rodar `flutter analyze` (`withOpacity` pode gerar aviso de depreciação, inofensivo) e `flutter test`. Só conferi balanceamento de `()`/`{}`/`[]`.
- **Não testado em aparelho/tablet/web real**: conferir em tela ≥ 900dp trocar de conversa várias vezes (sem duplicar mensagens/polling), Contatos → conversa → voltar, destaque da linha, chamadas/vídeo abrindo por cima de tudo (usam a rota raiz), teclado e botão voltar.
- Site: nada mudou nesta fase (zip só leva o `PROGRESSO_PING.md` atualizado).

## Fase 10 — o que foi feito (polimento final; **todas as 10 fases concluídas**)
**Site**
- **Tema claro, contraste AA (≥ 4.5:1)**: texto branco sobre o gradiente claro estava em 3,4:1 → `--ping-gradient` do tema claro agora é `#a8590f → #b83a55` (5,1/5,6:1); aba ativa usava âmbar `#c8791b` sobre `#f0ece3` (2,9:1) → novo token `--ping-accent-text` (`#935008` no claro, âmbar no escuro); texto secundário em `.ping-mode` no claro `#6a6372` (4,9:1). Zona de soltar arquivo (`.cw-drop`) era um fundo escuro fixo com texto escuro no tema claro → agora usa `--ping-bg`.
- **Bug corrigido (vinha da fase 8)**: `aria-current="page"` saía escapado (`&#34;`) pelo Jinja na pílula e nos filtros → agora `|safe` (teste de regressão).
- **Acessibilidade**: filtro Seguindo/Seguidores virou `<nav aria-label>` + `aria-current` (era `role=tablist` em links); foco visível por teclado em todo o `.ping-mode`; alvos de toque 44px em `pointer: coarse`; `forced-colors` (aba/filtro ativo com contorno).
- **`prefers-reduced-motion`**: bloco `.ping-mode *` zera animações/transições (anel da marca incluído).
- **CSS morto removido**: `body.chat-page .content/.bottom-nav/.site-footer` (o Ping não tem `<main.content>` nem bottom-nav). Ficou `body.chat-page .flash-stack` e a classe `chat-page` (o `ping-shell.js` ainda a adiciona; inofensiva).
- `sw.js` → `driqy-shell-v38`; testes antigos conferem `v38`. Novo `tests/test_ping_phase10.py` (calcula contraste a partir do CSS, então quebra se alguém piorar as cores). Suíte completa do site: **461 passando, 3 puladas**.
**Flutter**
- `BrandRing` (anel da marca) para quando o sistema pede "remover animações"; `pingFadeRoute` sem fade nesse caso; aba da pílula com **um** rótulo de acessibilidade (inclui "N não lidas") em vez de ícone+texto+selo separados.
- O app Flutter é **só tema escuro** (`app_theme.dart`), então o par claro de `PingColors` não é exibido; os ajustes de contraste do claro ficaram só no site. Se um dia houver tema claro no Flutter, usar as mesmas cores do CSS.
- Teste novo: `test/ping_polish_test.dart`. **Continua sem compilar** (sem SDK): rodar `flutter analyze` e `flutter test`.
**Revisão dos riscos** (1–8 acima): 1 ids/classes do chat mantidos (nada removido); 2/3 shell próprio e scripts de chamadas/`chat-live` mantidos; 4 SW em v38; 5 fragmento da conversa sem vazamento (testes 6a/6b passam); 6 Flutter ainda não compilado; 7 tema claro auditado; 8 anel da marca gira e respeita movimento reduzido.
**Ideias futuras (fora do escopo das 10 fases)**: selo de não lidas ao vivo nas telas Contatos/Configurações (hoje é o valor de quando abriu); remover a classe `chat-page` quando nada mais depender; tema claro no Flutter; Perfil da pílula ainda sai do Ping.

## Fase 11 — aproximação final do Telegram (pedido extra após as 10 fases)
Pedido: deixar o Ping o mais parecido possível com os prints do Telegram (Web no desktop, Android no celular).
**Site** (`_ping_list.html`, `_chat_inbox_row.html`, CSS "fase 11" no fim do `style.css`, `sw.js` `driqy-shell-v39`)
- Desktop (≥900px): cabeçalho da conversa vira **pílula flutuante** (margem, raio 20, blur); o padrão de doodles agora cobre a coluna inteira (`.cw` tem o fundo; `.cw-body/.cw-list/.cw-composer` ficam transparentes); **composer com clipe à esquerda e emoji à direita** (só `order` no CSS — DOM e ids intactos); **avatar da conta** à direita da busca (`.ping-me`, abre Configurações).
- Celular (<900px): ☰ some do lado da busca e vira **⋮ no canto do cabeçalho** (mesmo `#ping-menu-btn`, `position: fixed`, só em `ping-view-list`); busca mais baixa; pílula com rótulos claros e aba ativa tingida de âmbar.
- Comum: aviso em **duas linhas** (título + subtítulo); nome da conversa peso 500; prévia de foto/vídeo/áudio/arquivo em cor de destaque (`.conv-preview-media`).
- Teste novo `tests/test_ping_phase11.py`; testes antigos conferem `v39`. Suíte: 463 passando + 3 do arquivo novo, 3 puladas.
**Flutter** (`messages_inbox_screen.dart`, `ping_tab_bar.dart`, `message_thread_screen.dart`)
- Menu extraído em `_menuButton()`: ⋮ na `PingAppBar` no celular, ☰ ao lado da busca em tela larga; ícone de telefone removido do cabeçalho (Chamadas está no menu). Busca mais baixa e largura total no celular; avatar da conta ao lado da busca em tela larga (`_meAvatar`); aviso em duas linhas; linhas ~72dp (`VisualDensity(vertical: -2)`), nome w500, prévia de mídia em âmbar; pílula com rótulos claros e aba ativa tingida.
- Tela larga: `_buildAppBar()` da conversa embrulha a barra numa pílula flutuante (`_buildAppBarCore()` é a barra de antes). **Não compilado** (sem SDK): rodar `flutter analyze` e `flutter test`.
**Não feito (de propósito)**: hora da lista no formato do Telegram (dia da semana / "15 de set") — `chat_short_time` e `chatListTime` seguem em HH:MM / Ontem / dd/mm/aa; câmera pequena acima do FAB; "Ping" no topo do desktop continua (regra do usuário: nome + voltar).

## Riscos (ler antes de mexer)
1. **JS do chat depende de ids/classes**: `#cw`, `#chat-inbox-list`,
   `data-updates-url`, `data-prefs-root`, `#chat-badge*` (`chat.js`,
   `chat-live.js`, `chat-thread.js`, `call-ui.js`). Manter todos; só
   adicionar wrappers/classes novas.
2. `body.chat-page` usa `height: calc(100vh - 70px)` (topbar) e esconde a
   `bottom-nav` no celular (`style.css` ~linhas 3991–4255). Esconder a topbar
   no modo Ping exige ajustar esses cálculos junto.
3. **O Ping sai do chrome do Driqy** (regra nova): o `base.html` traz topbar,
   sidebar, bottom-nav **e** os scripts globais. Ao criar o shell do Ping,
   **manter** os `<script>` que não são chrome: chamadas (`call-ui.js`,
   `calls-api.js`), `chat-live.js`, tema, service worker, PWA. Esconder só o
   visual. Preferir um `ping_base.html` próprio que reaproveite esses blocos.
   **Chamadas** (`call-ui.js`, toque de chamada recebida) são carregadas pelo
   `base.html`; se o shell Ping não estender o `base.html`, manter os mesmos
   `<script>` ou as chamadas deixam de tocar.
4. **Service worker** cacheia `style.css` cache-first: **subir
   `driqy-shell-vN` em toda fase que mexer em CSS/JS**, senão o celular
   mostra versão velha (já aconteceu).
5. Fragmento de conversa sem recarregar (fase 6): reinicializar `chat-thread.js`
   a cada troca (listeners, polling/WebSocket, gravação de áudio) e **limpar**
   ao sair, senão vaza e duplica mensagens.
6. Flutter **não foi compilado** em nenhuma sessão (sem SDK no ambiente da IA):
   revisar `()`/`{}`, imports e `const`; pedir `flutter analyze`/`flutter run`.
7. Tema claro (`[data-theme="light"]`) existe: toda cor nova precisa de par
   claro, senão o Ping fica ilegível nele.
8. Não confundir com `AppGradients.brandRing`/anel da marca: o anel do logo
   agora **gira** (CSS `spin`; Flutter `RotationTransition`) — não quebrar.

## Mapa rápido do código existente
- Site: `chat.py` (rotas `inbox`, `thread`, `calls_history`, `inbox_updates`,
  `unread_count`), `api.py` (REST usada pelo site e pelo Flutter),
  `templates/messages_inbox.html`, `messages_thread.html`,
  `_chat_inbox_row*.html`, `static/js/chat*.js`, CSS `.chat-inbox-*`, `.cw-*`.
- Flutter: `lib/screens/messages_inbox_screen.dart`,
  `message_thread_screen.dart`, `home_shell.dart` (abas; Ping = índice 3),
  `lib/widgets/chat/*`, `lib/theme/app_colors.dart`.
- Referências visuais do usuário: print do Telegram Web (2 colunas), tela
  vazia "Select a chat to start messaging" e print do Telegram Android
  (busca, aviso "Adicione seu aniversário", FAB, pílula inferior).

## Pendências / observações
- **Todas as 10 fases concluídas.** Próximos passos só se o usuário pedir (ver "Ideias futuras" na fase 10). Usuário quer devolução dos DOIS zips completos a cada entrega (`..._ping_faseN.zip`).
- Ao mexer no Ping no celular (<900px) lembrar: a fase 6a/6b só afeta o desktop em parte — no celular a troca de conversa continua por navegação normal, mas faixa fixada e divisor de não lidas valem nos dois.
- A barra "Buscar conversas" da lista (fase 4a) é a do Telegram, só filtra conversas — não é a busca do Driqy.


## Fase 12 (extra pedido em 25/10/2026) — visualização única + ajuste da caixa de imagem
Pedido: "opção de encaminhar mensagens, deletar, mandar mensagem de visualização única (áudio, imagem, vídeo) e ajustar a caixa de imagens do app".
**Encaminhar e apagar JÁ existiam** (chat fase 7/8; uma mensagem por vez; menu do toque longo no app / ☺ ou botão direito no site). Não foram refeitos.
Ainda **não existe** seleção de várias mensagens para encaminhar/apagar de uma vez (ideia futura; limite do servidor: 5 destinos).

**Backend (`driqy4/`)**
- `models.Message`: `view_once` (bool) e `view_once_opened_at`; migração em `app.py` (ALTER automático).
- Envio: `POST /messages/<usuario>` multipart aceita `view_once=1` só com foto/vídeo/áudio (senão 400). Legenda e miniatura de vídeo são **ignoradas** (o rótulo da lista é só "📷 Foto"); push vira "🔒 Foto de visualização única".
- `serialize_message`: `view_once`, `view_once_state` (`unopened|opened|expired`), `can_open_view_once` (só destinatário, só não aberta). **`media_url`, mime, tamanho, largura/altura e legenda NÃO vão na lista.**
- `POST /messages/<id>/view-once` (só destinatário): marca aberta e devolve `media_url` + metadados + `expires_in`; 2ª chamada = 410. `POST /messages/<id>/view-once/close` apaga a mídia do disco na hora (idempotente). Ambos avisam os dois lados (`update`, `kind=view_once`).
- `GET /messages/media/<id>` de visualização única: só o destinatário, só depois de aberta, só até `CHAT_VIEW_ONCE_WINDOW_SECONDS` (10 min; vídeo/áudio precisam de várias requisições Range), `no-store`, sem `?download`. Passou da janela → apaga e 410.
- Não aberta vence em `CHAT_VIEW_ONCE_TTL_SECONDS` (14 dias). `scheduler.purge_stale_view_once` roda a cada 30 min e limpa o disco.
- Bloqueado para visualização única: **encaminhar (400), fixar (400), copiar, miniatura**. "Apagar para todos" continua valendo (apaga o arquivo).
- Testes: `tests/test_view_once.py` (10). Suíte completa antes do ajuste do site: **473 passaram, 3 skipped**; depois rodados os testes de ping/chat relacionados (112 passaram).

**Site (desktop + celular)** — `_ping_thread_main.html`, `chat-thread.js`, `style.css`, `sw.js` `v40` (os testes das fases do Ping foram atualizados de v39 para v40)
- Pré-visualização de foto/vídeo ganhou a caixa "Visualização única" (desliga a legenda). Áudio: botão ① ao lado do microfone arma **só o próximo áudio**.
- Balão: círculo tracejado + "Foto/Vídeo/Áudio" + "Toque para abrir" / "Não aberta" / "Aberta" / "Expirada". Destinatário abre num visualizador próprio (sem download, sem menu de contexto, sem PiP); ao fechar chama `/close`.
- Menu da bolha: sem Copiar, Fixar e Encaminhar em visualização única.
- Caixa de imagem: largura acompanha a proporção (foto em pé fica mais estreita, altura máx. ~380 px).

**Flutter** (`flutter_app/`) — **NÃO compilado** (sem SDK): rodar `flutter analyze` e `flutter test test/view_once_test.dart`.
- `DriqyMessage`: `viewOnce`, `viewOnceState`, `canOpenViewOnce`, `withMedia()`; `previewText` = "🔒 Visualização única".
- `MessageService`: `viewOnce:` em `sendImage/sendVideo/sendAudio`; `openViewOnce`, `closeViewOnce`, `ViewOnceMedia`.
- `chat_image_preview_screen.dart` / `chat_video_preview_screen.dart`: botão ① (âmbar quando ligado), legenda desativada. `message_thread_screen.dart`: botão ① ao lado do clipe arma o próximo áudio; toque no balão abre; sem Encaminhar/Copiar/Fixar.
- Novo `screens/view_once_viewer.dart` (foto, vídeo via `ChatVideoPlayerScreen`, áudio via `AudioMessage`); sempre chama `closeViewOnce` no `finally`.
- **Caixa de imagem do balão** (`message_bubble.dart::_buildImage`): antes a largura era sempre `min(66% da tela, 300)` e a proporção ficava presa entre 0,55 e 2,0 com `BoxFit.cover`; agora a largura = `min(maxW, maxH × proporção)` (maxH = 50% da tela, máx. 380), com piso de 150, então foto em pé fica estreita e a legenda acompanha. **Se a mensagem não tem largura/altura** (mensagens antigas), segue o padrão 4:3 — ver pendências.

**Limites assumidos (dizer ao usuário)**
- **Não há bloqueio de captura de tela** nem no app (precisaria de `FLAG_SECURE`/plugin nativo) nem no site (impossível no navegador); outra pessoa ainda pode fotografar a tela com outro aparelho. O servidor garante: uma abertura, sem URL na lista, sem encaminhar, arquivo apagado ao fechar/vencer.
- Quem recebe a visualização única **não consegue reabrir** se o app fechar no meio (decisão: segurança > conveniência).
- Remetente nunca revê a própria visualização única.

**Pendências / ideias**
- Seleção múltipla de mensagens para encaminhar/apagar.
- Descobrir a proporção real de imagens sem `media_width/height` (hoje 4:3).
- `FLAG_SECURE` no Android (plugin `flutter_windowmanager`/`screen_protector`).

**Correção 25/10/2026 (após feedback)** — Flutter, NÃO compilado:
- Borda da foto: o `Align` do horário esticava o balão até 78% da tela e o gradiente sobrava nas laterais. `message_bubble.dart` agora fixa a largura do balão = largura da foto + 6 (`_imageBoxW`).
- Áudio enviando com relógio parado em 0:00: `audio_message.dart` passou a usar `createPositionStream(100–200 ms)` sem depender de `_playing` e marca "tocando" no toque. **Causa não reproduzida em aparelho**; se persistir, suspeitar de `_msgKeys` (GlobalKey por `m.id` em `message_thread_screen.dart`): quando a mensagem local vira a do servidor o id muda, o estado do `AudioMessage` é recriado e a reprodução/posição reinicia.


## Notícias v2 (pedido de 25/10/2026) — banco temporário de 3 dias + classificação + recomendação
Só backend (`driqy4/`); site e Flutter já consomem `/news` e `/api/v1/news` e **não mudaram** (a categoria e a ordem vêm do servidor).

**Banco de notícias temporário** — `news_bank.py`, tabela `news_bank` (`models.NewsBankItem`, criada sozinha pelo `create_all`)
- Cada notícia indexada ganha uma "ficha" calculada UMA vez: categoria, categorias **secundárias**, confiança, 14 termos normalizados (sem acento, singular, nomes próprios em destaque) e `story_id` (mesmo fato em vários veículos).
- Vence em `NEWS_BANK_TTL_DAYS = 3`. Apagado por `news_bank.purge_expired` (agendador a cada `NEWS_BANK_PURGE_MINUTES = 60`, independe da rede; e ao fim de cada indexação). Também saem fichas órfãs e o excedente acima de `NEWS_BANK_MAX_ITEMS = 6000`. A `NewsArticle` continua 14 dias.
- `news_bank.backfill` recria fichas só com o que já está no banco de dados (sem coletar nada): roda no 1º uso, depois de reinício limpo e em `maintain`.
- O recomendador (`news_recommender._build_raw_pool`) lê desse banco: tem 3 dias de todas as categorias à mão, cobertura/duplicatas vêm do `story_id` (não reagrupa a cada pedido). Abaixo de `NEWS_BANK_MIN_ITEMS = 40` ou em erro, usa o caminho antigo (consulta direta) — o banco nunca derruba o feed.
- Ver o estado: `python -c "from app import create_app; a=create_app(); a.app_context().push(); import news_bank; print(news_bank.stats())"`.

**Classificação** — `news_classifier.py` v2 (`classify()` antigo continua igual por fora)
- Causas dos erros: categoria da fonte tratada como verdade absoluta (feeds "G1 - Brasil" e "Folha - Cotidiano", marcados "geral", nunca eram classificados; "ESPN Geral", "Poder360" etc. mantinham a categoria mesmo com matéria de outro assunto), seção da URL e tags do feed ignoradas, texto sem normalizar (acento/plural), nomes ambíguos (Santos, Bahia, Fortaleza...) valendo peso cheio.
- Agora `classify_article` soma evidências: texto (título 1,5x), **seção da URL** (peso 4), **tags do feed** (3), **prior da fonte** (2, só desempata/sustenta). Prior só é derrubado se outra categoria o superar por >= 0,5. Fontes mistas continuam limitando só a evidência de texto.
- Clubes/cidades ambíguas viram peso 0,5; ~150 palavras novas por categoria (`config.NEWS_CATEGORY_KEYWORDS`, marcadas "v2").
- **Para corrigir as notícias JÁ salvas:** `python fix_news_categories.py` (reclassifica tudo e refaz as fichas do banco).

**Recomendação**
- Afinidade por assunto usa os termos normalizados do banco (mesmo vocabulário do perfil e dos candidatos).
- **Categorias secundárias**: um clique em matéria "economia + política" conta 30% para a secundária; matéria com secundária que o usuário escolheu/gosta ganha bônus pequeno (`WEIGHT_SECONDARY`).
- Testes: `tests/test_news_bank.py` (26). Suíte completa passou.

**Limites / pendências**
- Sem IA: a precisão depende das palavras-chave e das pistas (URL/tags). Matéria sem nenhuma pista continua em "geral" (de propósito: melhor "geral" do que errada).
- Não testado com os feeds reais (sem rede no ambiente): rode `fix_news_categories.py` e confira a distribuição por categoria.
- O banco guarda só 3 dias; perfil de quem não abre o app há mais tempo cai nos termos do título (`extract_terms`).
- Ideia futura: painel admin com `news_bank.stats()` e botão "reclassificar".
