"""
Vortex por GOSTO do usuário (em vez de "o mais novo primeiro").

Como funciona, em 4 passos:

1. SINAIS — cada clique/abertura, tempo olhando o detalhe, curtida, busca e
   "menos disso" vira uma linha em `vortex_interactions` (ver `record`). A
   linha guarda uma cópia da categoria, do tipo de mídia, do perfil, do
   autor e das tags da peça.

2. PERFIL DE GOSTO — `build_profile` soma os sinais dos últimos
   WINDOW_DAYS dias com DECAIMENTO EXPONENCIAL (meia-vida de
   HALF_LIFE_HOURS): o que a pessoa clicou hoje pesa muito mais que o de
   semana passada, e sinais das últimas horas valem em dobro (é "o que ela
   quer agora"). Se ela passa a gostar de outra coisa, bastam alguns cliques
   pra o novo assunto ultrapassar o antigo — sem ninguém configurar nada.
   Sai um mapa de afinidade (0..1) para categoria, tag, tipo de mídia,
   perfil-robô e autor, mais uma `confidence` (0..1): com poucos sinais o
   gosto pesa pouco, com bastante sinal ele manda.

3. PONTUAÇÃO — todas as peças candidatas (itens do crawler E posts de
   usuários, SEM cota reservada pra ninguém) recebem uma nota única:
   gosto (categoria + tags + tipo + perfil/autor) x confiança + um pouco de
   novidade + um pouco de popularidade + um tremor aleatório pequeno. Peça
   que o usuário abriu nas últimas horas é rebaixada. "Menos disso" derruba
   a afinidade (peso negativo).

4. MONTAGEM — diversificação (não empilhar o mesmo perfil/categoria) e
   EXPLORAÇÃO: a cada EXPLORE_EVERY posições entra uma peça fora do gosto
   conhecido, pra o app descobrir interesses novos e a grade não virar uma
   bolha. Sem nenhum sinal (usuário novo) tudo é "exploração": ordem por
   novidade + popularidade + acaso, igual pra itens e posts.

5. "O QUE EU ACABEI DE VER" — as últimas peças que a pessoa abriu/curtiu (até
   RECENT_SEEDS, nas últimas RECENT_HOURS h) viram SEMENTES: as peças parecidas
   com elas ("mais como este": imagem, tags, categoria) ganham um bônus forte
   e algumas ocupam posições fixas no começo da grade (RECENT_SLOTS). É isso que
   faz o Vortex responder na hora ao último clique, em vez de só ao gosto
   médio das últimas semanas.

6. LIMPEZA — a lista final nunca traz (a) peça com cara de logo/QR/banner pelo
   nome (mesmo que ainda não analisada), (b) imagem quase igual a outra que já
   está na lista (dHash), nem (c) mais que FEED_PER_SITE_MAX peças do mesmo
   site de origem em FEED_PER_SITE_WINDOW posições.

7. INTERESSE POR CONCEITO (Parte 5) — o perfil também soma os CONCEITOS das peças
   (carro, moto, gato...) e espalha o crédito para os ancestrais (clicar em carro
   dá 1,0 a "carro", ~0,6 a "veículo de rodas", ~0,36 a "veículo"), então quem
   gosta de carro ganha moto/caminhão como parente sem nunca ganhar dança. A nota
   usa isso (W_CONCEPT) quando a peça e o perfil têm conceitos; senão vale o
   cálculo antigo (categoria/tags).

8. MISTURA ANTI-BOLHA — a cada 5 posições: 3 de INTERESSE, 1 ADJACENTE (assunto
   parente de um interesse, mas que a pessoa ainda não clicou: moto pra quem
   gosta de carro) e 1 DESCOBERTA (fora de tudo que se conhece). Além disso, nenhum
   DOMÍNIO ocupa mais que SATURATION_MAX posições em SATURATION_WINDOW seguidas
   (cede só se não houver outra opção). `wellbeing` mede o tempo contínuo de uso
   e sugere uma pausa.

PAGINAÇÃO: a lista ranqueada de uma rolagem fica numa sessão em memória
(`_sessions`, chave = usuário + semente). Páginas seguintes só fatiam a
lista — nada se repete. Se o usuário gerou sinal novo no meio da rolagem
(abriu uma peça e voltou), só a PARTE AINDA NÃO MOSTRADA é reordenada com o
gosto atualizado. Se a sessão sumiu (reinício, outro worker), a lista é
refeita com a mesma semente e o app ignora `key` repetida (regra antiga do
Vortex). O cursor é opaco: "t<semente>-<deslocamento>".
"""
import math
import random
import re
import zlib
from collections import Counter
from datetime import timedelta

from sqlalchemy import func

from cache import TTLCache
from extensions import db
from models import Post, PostMedia, VortexInteraction, VortexItem, VortexProfile, utcnow
import vortex_concepts as vcn
import vortex_quality
import vortex_search as vsearch
import vortex_seen as vseen

VORTEX_TYPES = ("photo", "gif", "video")

# ---------------------------------------------------------------------------
# sinais
# ---------------------------------------------------------------------------
EVENT_WEIGHTS = {
    "open": 1.0,      # abriu a peça (o clique)
    "dwell": 0.8,     # ficou olhando o detalhe (o cliente manda; soma ao clique)
    "like": 2.0,      # curtiu / salvou
    "search": 0.7,    # pesquisou algo (as palavras viram interesse em tags)
    "less": -1.5,     # "menos disso"
}
VALID_KINDS = tuple(EVENT_WEIGHTS)
DEDUPE_SECONDS = 20          # o mesmo sinal na mesma peça dentro disso é ignorado
PRUNE_AFTER_DAYS = 60

# ---------------------------------------------------------------------------
# perfil de gosto
# ---------------------------------------------------------------------------
HALF_LIFE_HOURS = 72.0       # o gosto "esquece" pela metade a cada 3 dias
FRESH_HOURS = 3.0            # sinais dessa janela valem FRESH_BOOST x
FRESH_BOOST = 2.0
WINDOW_DAYS = 21
MAX_EVENTS = 800
CONFIDENCE_FULL = 8.0        # soma de pesos (já com decaimento) pra gosto valer 100 %
TOP_TAGS = 40                # tags mais fortes que entram no perfil

# ---------------------------------------------------------------------------
# pontuação
# ---------------------------------------------------------------------------
W_CATEGORY = 0.40
W_TAG = 0.30
W_TYPE = 0.10
W_SOURCE = 0.20              # perfil-robô (itens do crawler)
# posts de usuários não têm categoria nem tags: o AUTOR é todo o gosto que dá
# pra medir neles, então pesa o que categoria+tags+perfil pesam num item. O
# tipo de mídia vale o MESMO que nos itens (W_TYPE): um post de autor
# desconhecido fica em pé de igualdade com um item sem afinidade, não acima.
W_POST_AUTHOR = 0.90
W_POST_TYPE = W_TYPE
SCALE_TASTE = 4.0
SCALE_RECENCY = 1.0
SCALE_POPULARITY = 0.5
SCALE_JITTER = 0.6
RECENCY_HALF_LIFE_DAYS = 10.0
OPENED_COOLDOWN_HOURS = 36
OPENED_PENALTY = 0.25

# Parte 5: interesse por conceito
W_CONCEPT = 0.40             # com conceito: categoria/tag/perfil diminuem pra somar 1,0
W_CATEGORY_C, W_TAG_C, W_SOURCE_C = 0.20, 0.15, 0.15
CONCEPT_SPREAD = 0.6         # crédito que sobe pro pai (x0,6 por nível)
TOP_CONCEPTS = 6
ADJACENT_MIN_RELATION = 0.4  # parentesco mínimo/máximo (exclusivo) pra ser "adjacente"
ADJACENT_MAX_RELATION = 0.8
ADJACENT_KNOWN_AFFINITY = 0.3   # já clicou nesse conceito exato? então é interesse, não adjacente
ADJACENT_TOP_CONCEPTS = 5
ADJACENT_MIN_AFFINITY = 0.3  # só conceitos com pelo menos isso entram como "interesse-base"
POOL_PER_CONCEPT = 200
POOL_TOP_CONCEPTS = 3

# ---------------------------------------------------------------------------
# montagem
# ---------------------------------------------------------------------------
ADJACENT_SLOT = 3            # posição (slot % EXPLORE_EVERY == 3) reservada ao adjacente
SATURATION_WINDOW = 12       # nenhum assunto (domínio) passa de SATURATION_MAX em SATURATION_WINDOW posições
SATURATION_MAX = 6
EXPLORE_EVERY = 5            # 1 a cada 5 posições é fora do gosto conhecido
EXPLORE_MIN_CONFIDENCE = 0.15
DIVERSITY_PROFILE_WINDOW = 3
DIVERSITY_PROFILE_PENALTY = 0.6
DIVERSITY_CATEGORY_WINDOW = 4
DIVERSITY_CATEGORY_PENALTY = 0.85
MAX_RANKED = 600             # tamanho máximo da lista ranqueada de uma sessão

# candidatos
POOL_RECENT = 700            # itens mais novos
POOL_PER_CATEGORY = 350      # por categoria favorita
POOL_TOP_CATEGORIES = 4
POOL_PER_TAG = 120
POOL_TOP_TAGS = 3
POOL_RANDOM = 250            # amostra aleatória do acervo inteiro (descoberta)
POOL_USER_POSTS = 150

# "o que acabei de ver"
RECENT_HOURS = 48.0          # só cliques dessa janela viram semente
RECENT_SEEDS = 4             # quantas peças recentes puxam parecidas
RECENT_SEED_DECAY = (1.0, 0.75, 0.55, 0.4)   # peso por posição (0 = a mais recente)
RECENT_HALF_LIFE_HOURS = 12.0
RECENT_RELATED = 60          # parecidas buscadas por semente
SCALE_RECENT = 2.4           # peso do bônus na nota
RECENT_SLOTS = (1, 4, 7, 10, 13, 16)   # posições (0-based) reservadas às melhores parecidas
RECENT_SLOT_MIN = 0.25       # bônus mínimo (0..1) pra merecer posição reservada

# limpeza da grade (valores padrão; o Config pode mudar)
FEED_NEAR_DUP_DISTANCE = 9
FEED_PER_SITE_WINDOW = 12
FEED_PER_SITE_MAX = 3
_CLEAN_LOOKAHEAD = 80

# aviso de tempo (pausa)
BREAK_AFTER_MINUTES = 30     # 0 desliga
SESSION_GAP_MINUTES = 10     # silêncio maior que isso encerra a "sessão contínua"

_related_cache = TTLCache(ttl_seconds=600, max_entries=256)
_profile_cache = TTLCache(ttl_seconds=600, max_entries=512)
_sessions = TTLCache(ttl_seconds=1800, max_entries=512)
_popularity_cache = TTLCache(ttl_seconds=300, max_entries=2)
_postmeta_cache = TTLCache(ttl_seconds=45, max_entries=8)

_cursor_re = re.compile(r"^t(\d{1,12})-(\d{1,6})$")


# ===========================================================================
# registro de sinais
# ===========================================================================

def _norm_tags(raw_tags, limit=12):
    out = []
    for t in raw_tags or []:
        t = vsearch._strip_accents((t or "").strip().lower())
        if t and t not in out:
            out.append(t)
        if len(out) >= limit:
            break
    return out


def record(user_id, kind, item=None, post=None, query=None, weight=None):
    """Grava um sinal de gosto. `item` = VortexItem, `post` = Post, `query` =
    texto buscado (kind='search'). Devolve True se gravou (False = inválido ou
    repetido logo em seguida). Nunca levanta por falha de gravação."""
    if kind not in EVENT_WEIGHTS or not user_id:
        return False
    row = VortexInteraction(
        user_id=user_id, kind=kind,
        weight=float(EVENT_WEIGHTS[kind] if weight is None else weight),
    )
    if item is not None:
        row.item_id = item.id
        row.category = item.category
        row.media_type = item.media_type
        row.profile_id = item.profile_id
        row.tags = ",".join(_norm_tags(item.tag_list + item.visual_tag_list)) or None
        row.concepts = item.concepts or None
    elif post is not None:
        row.post_id = post.id
        row.author_id = post.user_id
        media = next((m for m in post.display_media if m["media_type"] in VORTEX_TYPES), None)
        row.media_type = media["media_type"] if media else None
    elif kind == "search" and query:
        tokens = _norm_tags(vsearch.tokenize_query(query), limit=6)
        if not tokens:
            return False
        row.tags = ",".join(tokens)
        try:   # as palavras da busca também viram interesse em conceito (busca "moto" -> moto)
            found = vcn.find_concepts(query, limit=2)
            row.concepts = vcn.encode(vcn.Understanding([(c, 1.0) for c in found], None, [], 1.0, "text"))[:160] or None
        except Exception:
            row.concepts = None
    else:
        return False

    try:
        recent = VortexInteraction.query.filter(
            VortexInteraction.user_id == user_id, VortexInteraction.kind == kind,
            VortexInteraction.created_at >= utcnow() - timedelta(seconds=DEDUPE_SECONDS),
        )
        if row.item_id is not None:
            recent = recent.filter(VortexInteraction.item_id == row.item_id)
        elif row.post_id is not None:
            recent = recent.filter(VortexInteraction.post_id == row.post_id)
        else:
            recent = recent.filter(VortexInteraction.tags == row.tags)
        if recent.first() is not None:
            return False
        db.session.add(row)
        db.session.commit()
    except Exception:  # sinal de gosto nunca pode derrubar a requisição
        db.session.rollback()
        return False
    # abrir/curtir/dwell/"menos disso" também contam como VISTO no livro de vistos
    # (a peça não volta por semanas; "menos disso" bloqueia ainda mais)
    if kind in ("open", "like", "dwell", "less"):
        seen_key = vseen.key_for(item=item, post=post)
        if seen_key:
            vseen.mark_viewed(user_id, [seen_key], rejected=(kind == "less"))
    if random.random() < 0.01:
        prune_old()
        vseen.prune()
    return True


def undo_less(user_id, item=None, post=None):
    """Desfaz o \"menos disso\" de uma peça: apaga os sinais `less` dela e tira a marca de
    rejeitada do livro de vistos. Devolve quantos sinais foram apagados (0 = nada a desfazer)."""
    if item is None and post is None:
        return 0
    try:
        q = VortexInteraction.query.filter(VortexInteraction.user_id == user_id,
                                           VortexInteraction.kind == "less")
        q = q.filter(VortexInteraction.item_id == item.id) if item is not None \
            else q.filter(VortexInteraction.post_id == post.id)
        removed = q.delete(synchronize_session=False)
        db.session.commit()
    except Exception:
        db.session.rollback()
        return 0
    vseen.clear_rejected(user_id, [vseen.key_for(item=item, post=post)])
    _profile_cache.clear()      # o carimbo (maior id) pode não mudar se o `less` não era o último
    _related_cache.clear()
    return removed or 0


def prune_old(days=PRUNE_AFTER_DAYS):
    """Apaga sinais antigos (já não pesam: o decaimento os zera bem antes)."""
    try:
        VortexInteraction.query.filter(
            VortexInteraction.created_at < utcnow() - timedelta(days=days)
        ).delete(synchronize_session=False)
        db.session.commit()
    except Exception:
        db.session.rollback()


def _stamp(user_id):
    """Marca barata do estado dos sinais do usuário (maior id)."""
    return db.session.query(func.coalesce(func.max(VortexInteraction.id), 0)).filter(
        VortexInteraction.user_id == user_id
    ).scalar() or 0


# ===========================================================================
# perfil de gosto
# ===========================================================================

class Profile:
    __slots__ = ("category", "tag", "media", "source", "author", "confidence",
                 "stamp", "opened_items", "opened_posts", "top_categories", "top_tags",
                 "concept", "own_concept", "top_concepts")

    def __init__(self):
        self.concept, self.own_concept, self.top_concepts = {}, {}, []
        self.category, self.tag, self.media = {}, {}, {}
        self.source, self.author = {}, {}
        self.confidence = 0.0
        self.stamp = 0
        self.opened_items, self.opened_posts = set(), set()
        self.top_categories, self.top_tags = [], []

    def __repr__(self):  # ajuda em log/depuração
        return (f"<Profile conf={self.confidence:.2f} cats={self.top_categories[:3]} "
                f"tags={self.top_tags[:3]}>")


def _normalize(counter):
    """Soma por chave -> afinidade 0..1 (a maior vira 1; negativas viram 0)."""
    positives = {k: v for k, v in counter.items() if v > 0}
    top = max(positives.values(), default=0.0)
    if top <= 0:
        return {}
    return {k: v / top for k, v in positives.items()}


def build_profile(user_id, now=None):
    now = now or utcnow()
    stamp = _stamp(user_id)
    cached = _profile_cache.get(user_id)
    if cached is not None and cached.stamp == stamp:
        return cached

    since = now - timedelta(days=WINDOW_DAYS)
    rows = (
        VortexInteraction.query
        .filter(VortexInteraction.user_id == user_id, VortexInteraction.created_at >= since)
        .order_by(VortexInteraction.id.desc()).limit(MAX_EVENTS).all()
    )
    prof = Profile()
    prof.stamp = stamp
    cats, tags, media = Counter(), Counter(), Counter()
    sources, authors = Counter(), Counter()
    concepts, own = Counter(), Counter()
    total = 0.0
    opened_cut = now - timedelta(hours=OPENED_COOLDOWN_HOURS)

    for r in rows:
        age_h = max((now - r.created_at).total_seconds() / 3600.0, 0.0)
        w = r.weight * math.pow(0.5, age_h / HALF_LIFE_HOURS)
        if age_h <= FRESH_HOURS and w > 0:
            w *= FRESH_BOOST
        if w > 0:
            total += w
        if r.created_at >= opened_cut and r.kind in ("open", "like", "dwell"):
            if r.item_id is not None:
                prof.opened_items.add(r.item_id)
            if r.post_id is not None:
                prof.opened_posts.add(r.post_id)
        if r.category:
            cats[r.category] += w
        if r.media_type:
            media[r.media_type] += w
        if r.profile_id is not None:
            sources[r.profile_id] += w
        if r.author_id is not None:
            authors[r.author_id] += w
        for cid, cw in vcn.decode(r.concepts):
            own[cid] += w * cw
            level, node = 0, cid
            for anc in vcn.ancestors(cid, include_self=True):
                concepts[anc] += w * cw * math.pow(CONCEPT_SPREAD, level)
                level += 1
        tag_list = [t for t in (r.tags or "").split(",") if t]
        if tag_list:
            share = w / math.sqrt(len(tag_list))
            for t in tag_list:
                tags[t] += share

    prof.concept = _normalize(concepts)
    prof.own_concept = _normalize(own)
    prof.top_concepts = [c for c, _ in sorted(prof.own_concept.items(), key=lambda kv: -kv[1])][:TOP_CONCEPTS]
    prof.category = _normalize(cats)
    prof.media = _normalize(media)
    prof.source = _normalize(sources)
    prof.author = _normalize(authors)
    tag_aff = _normalize(tags)
    top_tags = sorted(tag_aff.items(), key=lambda kv: -kv[1])[:TOP_TAGS]
    prof.tag = dict(top_tags)
    prof.top_tags = [t for t, _ in top_tags]
    prof.top_categories = [c for c, _ in sorted(prof.category.items(), key=lambda kv: -kv[1])]
    prof.confidence = min(1.0, total / CONFIDENCE_FULL)
    _profile_cache.set(user_id, prof)
    return prof


# ===========================================================================
# candidatos
# ===========================================================================

class Cand:
    """Peça candidata, só com o necessário pra pontuar (sem carregar o modelo)."""
    __slots__ = ("key", "kind", "obj_id", "category", "media_type", "source_id",
                 "tags", "created_at", "phash", "site", "concepts", "cset", "domain")

    def __init__(self, key, kind, obj_id, category, media_type, source_id, tags, created_at,
                 phash=None, site=None, concepts=(), cset=frozenset(), domain=None):
        self.concepts, self.cset, self.domain = concepts, cset, domain
        self.key, self.kind, self.obj_id = key, kind, obj_id
        self.category, self.media_type, self.source_id = category, media_type, source_id
        self.tags, self.created_at = tags, created_at
        self.phash, self.site = phash, site


def _item_cands(ids):
    if not ids:
        return []
    rows = (
        VortexItem.query.join(VortexProfile, VortexItem.profile_id == VortexProfile.id)
        .filter(VortexItem.id.in_(list(ids)),
                VortexItem.is_active.is_(True), VortexProfile.is_active.is_(True))
        .with_entities(VortexItem.id, VortexItem.category, VortexItem.media_type,
                       VortexItem.profile_id, VortexItem.tags, VortexItem.visual_tags,
                       VortexItem.created_at, VortexItem.phash, VortexItem.source_name,
                       VortexItem.media_url, VortexItem.title, VortexItem.source_url,
                       VortexItem.junk_reason, VortexItem.concepts, VortexItem.concept_tags)
        .all()
    )
    out = []
    for r in rows:
        # peça com cara de logo/QR/banner pelo nome some da grade mesmo que o
        # filtro de pixels ainda não tenha passado nela (liberada por admin = fica)
        if r.junk_reason != "manual_ok" and vortex_quality.check_text(
                r.media_url, r.title, r.tags, r.source_url):
            continue
        raw = [t for t in f"{r.tags or ''},{r.visual_tags or ''}".split(",") if t]
        try:
            ph = int(r.phash, 16) if r.phash else None
        except ValueError:
            ph = None
        site = (r.source_name or "").strip().lower() or None
        cl = vcn.decode(r.concepts)
        cset = frozenset((r.concept_tags or "").split()) if cl else frozenset()
        domain = vcn.root_of(cl[0][0]) if cl else None
        out.append(Cand(f"c{r.id}", "c", r.id, r.category, r.media_type, r.profile_id,
                        frozenset(_norm_tags(raw, limit=30)), r.created_at, ph, site,
                        tuple(cl), cset, domain))
    return out


def _sample_random_ids(category, media_type, n):
    """Amostra aleatória do acervo inteiro (sem ORDER BY random(), que varre
    a tabela): sorteia ids no intervalo [min, max] e deixa o banco filtrar."""
    lo, hi = db.session.query(func.min(VortexItem.id), func.max(VortexItem.id)).one()
    if not hi:
        return []
    rng = random.Random()
    picks = {rng.randint(lo, hi) for _ in range(n * 2)}
    q = vsearch.item_query(category, media_type).filter(VortexItem.id.in_(list(picks)))
    return [i.id for i in q.with_entities(VortexItem.id).limit(n).all()]


def _collect_item_ids(app, profile, category, media_type, skip=frozenset()):
    """Ids candidatos. `skip` = itens que a pessoa já viu (livro de vistos): cada
    consulta busca `extra` linhas a mais pra que, DEPOIS de tirar os vistos,
    ainda sobrem POOL_* peças novas (senão o topo do acervo, que ela já viu
    todo, esvaziaria o pool e a grade voltaria a repetir)."""
    extra = min(len(skip), 4000)
    ids = set()
    ids.update(r.id for r in vsearch.item_query(category, media_type)
               .with_entities(VortexItem.id).order_by(VortexItem.id.desc())
               .limit(POOL_RECENT + extra).all())
    if not category:
        for cat in profile.top_categories[:POOL_TOP_CATEGORIES]:
            ids.update(r.id for r in vsearch.item_query(cat, media_type)
                       .with_entities(VortexItem.id).order_by(VortexItem.id.desc())
                       .limit(POOL_PER_CATEGORY + extra).all())
    for tag in profile.top_tags[:POOL_TOP_TAGS]:
        tokens = vsearch.tokenize_query(tag)
        if not tokens:
            continue
        try:
            rows, _engine = vsearch._run_search(app, tokens, "and", category, media_type,
                                                POOL_PER_TAG + extra)
        except Exception:
            continue
        ids.update(r[0] for r in rows)
    for cid in profile.top_concepts[:POOL_TOP_CONCEPTS]:   # Parte 5: tudo do assunto/família
        ids.update(r.id for r in vsearch.item_query(category, media_type)
                   .filter(VortexItem.concept_tags.contains(f" {cid} ", autoescape=True))
                   .with_entities(VortexItem.id).order_by(VortexItem.id.desc())
                   .limit(POOL_PER_CONCEPT + extra).all())
    ids.update(_sample_random_ids(category, media_type, POOL_RANDOM))
    if skip:
        ids -= set(skip)
    return ids


def _user_post_cands(media_type):
    types = (media_type,) if media_type else VORTEX_TYPES
    cache_key = ",".join(types)
    cached = _postmeta_cache.get(cache_key)
    if cached is None:
        has_visual = Post.id.in_(
            db.session.query(PostMedia.post_id).filter(PostMedia.media_type.in_(types))
        )
        posts = (
            Post.query.filter(Post.expires_at > utcnow())
            .filter(db.or_(Post.post_type.in_(types), has_visual))
            .order_by(Post.id.desc()).limit(POOL_USER_POSTS).all()
        )
        cached = []
        for p in posts:
            media = next((m for m in p.display_media if m["media_type"] in types), None)
            if media is not None:
                cached.append((p.id, p.user_id, media["media_type"], p.created_at))
        _postmeta_cache.set(cache_key, cached)
    return [Cand(f"p{pid}", "p", pid, None, mt, uid, frozenset(), created)
            for pid, uid, mt, created in cached]


def _popularity(now):
    """Aberturas por peça nos últimos 14 dias (todos os usuários), em cache."""
    cached = _popularity_cache.get("pop")
    if cached is not None:
        return cached
    since = now - timedelta(days=14)
    rows = (
        db.session.query(VortexInteraction.item_id, func.count(VortexInteraction.id))
        .filter(VortexInteraction.item_id.isnot(None), VortexInteraction.kind == "open",
                VortexInteraction.created_at >= since)
        .group_by(VortexInteraction.item_id).all()
    )
    pop = {"c": {i: n for i, n in rows}}
    pop["max"] = max((math.log1p(n) for n in pop["c"].values()), default=0.0)
    _popularity_cache.set("pop", pop)
    return pop


# ===========================================================================
# pontuação e montagem
# ===========================================================================

def _jitter(seed, key):
    """Número estável em [0,1) para (semente, peça): o mesmo scroll não muda
    de ordem entre páginas, mas cada abertura nova (semente nova) embaralha."""
    h = (seed * 1000003) ^ zlib.crc32(key.encode())
    return random.Random(h).random()


def concept_affinity(c, profile):
    """0..1: o melhor crédito do perfil entre o conceito da peça e seus ancestrais."""
    return max((profile.concept.get(x, 0.0) for x in c.cset), default=0.0)


def adjacency(c, profile):
    """Parentesco (0..1) da peça com um interesse-base, SE for 'adjacente': assunto
    parente (carro -> moto) que a pessoa ainda não clicou. 0 = não é adjacente."""
    if not c.concepts or not profile.top_concepts:
        return 0.0
    own = [cid for cid, _w in c.concepts]
    if any(profile.own_concept.get(cid, 0.0) >= ADJACENT_KNOWN_AFFINITY for cid in own):
        return 0.0     # já é interesse conhecido
    best = 0.0
    for top in profile.top_concepts[:ADJACENT_TOP_CONCEPTS]:
        if profile.own_concept.get(top, 0.0) < ADJACENT_MIN_AFFINITY:
            continue
        for cid in own:
            r = vcn.relation(top, cid)
            if ADJACENT_MIN_RELATION <= r < ADJACENT_MAX_RELATION + 1e-9 and r > best:
                best = r
    return best


def taste_score(c, profile):
    """Parte 'gosto' da nota (0..1) — sem recência, popularidade ou acaso."""
    if profile.confidence <= 0:
        return 0.0
    if c.kind == "p":
        return (W_POST_AUTHOR * profile.author.get(c.source_id, 0.0)
                + W_POST_TYPE * profile.media.get(c.media_type, 0.0)) * profile.confidence
    cat = profile.category.get(c.category, 0.0) if c.category else 0.0
    matched = sorted((profile.tag[t] for t in c.tags if t in profile.tag), reverse=True)[:3]
    tag = min(1.0, sum(matched) / 2.0)
    media = profile.media.get(c.media_type, 0.0)
    src = profile.source.get(c.source_id, 0.0)
    if c.cset and profile.concept:     # Parte 5: assunto parente conta (moto pra quem curte carro)
        con = concept_affinity(c, profile)
        return (W_CONCEPT * con + W_CATEGORY_C * cat + W_TAG_C * tag + W_TYPE * media
                + W_SOURCE_C * src) * profile.confidence
    return (W_CATEGORY * cat + W_TAG * tag + W_TYPE * media + W_SOURCE * src) * profile.confidence


def _recency(created_at, now):
    if not created_at:
        return 0.3
    age_days = max((now - created_at).total_seconds() / 86400.0, 0.0)
    return math.pow(0.5, age_days / RECENCY_HALF_LIFE_DAYS)


def score_cand(c, profile, now, seed, pop, recent=None):
    s = SCALE_TASTE * taste_score(c, profile)
    s += SCALE_RECENCY * _recency(c.created_at, now)
    if recent:
        s += SCALE_RECENT * min(1.0, recent.get(c.key, 0.0))
    if c.kind == "c" and pop["max"]:
        s += SCALE_POPULARITY * (math.log1p(pop["c"].get(c.obj_id, 0)) / pop["max"])
    s += SCALE_JITTER * _jitter(seed, c.key)
    opened = profile.opened_items if c.kind == "c" else profile.opened_posts
    if c.obj_id in opened:
        s *= OPENED_PENALTY
    return s


def _diversify(scored):
    """scored: [(Cand, nota)] por nota desc. Penaliza (não descarta) repetir o
    mesmo perfil/categoria dentro de poucas posições."""
    remaining = list(scored)
    out, recent_src, recent_cat = [], [], []
    while remaining:
        best_i, best_val = 0, -math.inf
        for i, (c, s) in enumerate(remaining[:80]):   # só olha o topo: O(n) no total
            adj = s
            if (c.kind, c.source_id) in recent_src:
                adj *= DIVERSITY_PROFILE_PENALTY
            if c.category and c.category in recent_cat:
                adj *= DIVERSITY_CATEGORY_PENALTY
            if adj > best_val:
                best_val, best_i = adj, i
        c, _s = remaining.pop(best_i)
        out.append(c)
        recent_src.append((c.kind, c.source_id))
        recent_src[:] = recent_src[-DIVERSITY_PROFILE_WINDOW:]
        if c.category:
            recent_cat.append(c.category)
            recent_cat[:] = recent_cat[-DIVERSITY_CATEGORY_WINDOW:]
    return out


def _is_outside_taste(c, profile, recent=None):
    if recent and recent.get(c.key, 0.0) > 0:
        return False
    if profile.confidence < EXPLORE_MIN_CONFIDENCE:
        return True
    if c.category and profile.category.get(c.category, 0.0) >= 0.2:
        return False
    if any(t in profile.tag for t in c.tags):
        return False
    if c.cset and profile.concept and concept_affinity(c, profile) >= 0.2:
        return False
    return True


def _explore_score(c, now, seed, pop):
    """Nota SEM gosto (novidade + popularidade + acaso): a exploração tem que
    tratar item e post de igual pra igual, senão vira prioridade disfarçada."""
    s = SCALE_RECENCY * _recency(c.created_at, now) + SCALE_JITTER * _jitter(seed + 17, c.key)
    if c.kind == "c" and pop["max"]:
        s += SCALE_POPULARITY * (math.log1p(pop["c"].get(c.obj_id, 0)) / pop["max"])
    return s


def _assemble(scored_sorted, profile, now, seed, pop, recent=None):
    """Ordem final: topo diversificado + 1 peça de exploração a cada
    EXPLORE_EVERY posições (quando já há gosto conhecido)."""
    ranked = _diversify(scored_sorted)
    if profile.confidence < EXPLORE_MIN_CONFIDENCE:
        return ranked
    explore = sorted(
        (c for c, _s in scored_sorted if _is_outside_taste(c, profile, recent)),
        key=lambda c: _explore_score(c, now, seed, pop), reverse=True,
    )
    adj_scores = {}
    if profile.top_concepts:
        for c, _s in scored_sorted:
            a = adjacency(c, profile)
            if a > 0:
                adj_scores[c.key] = a
    adjacent = sorted(
        (c for c, _s in scored_sorted if c.key in adj_scores),
        key=lambda c: adj_scores[c.key] + 0.5 * _explore_score(c, now, seed, pop), reverse=True)
    adjacent_iter = iter(adjacent)
    explore = [c for c in explore if c.key not in adj_scores]
    explore_iter = iter(explore)
    out, used = [], set()
    main_iter = iter(ranked)
    while len(out) < MAX_RANKED:
        slot = len(out) + 1
        pick = None
        if adjacent and slot % EXPLORE_EVERY == ADJACENT_SLOT:
            for c in adjacent_iter:
                if c.key not in used:
                    pick = c
                    break
        if pick is None and slot % EXPLORE_EVERY == 0:
            for c in explore_iter:
                if c.key not in used:
                    pick = c
                    break
        if pick is None:
            for c in main_iter:
                if c.key not in used:
                    pick = c
                    break
        if pick is None:
            break
        used.add(pick.key)
        out.append(pick)
    return out


# ===========================================================================
# "o que eu acabei de ver"
# ===========================================================================

def recent_seed_ids(user_id, now=None, limit=RECENT_SEEDS):
    """[(item_id, peso)] das últimas peças do crawler que a pessoa abriu/curtiu
    (mais recente primeiro, sem repetir). O peso junta a posição (a última
    pesa mais), a idade (meia-vida de RECENT_HALF_LIFE_HOURS) e o tipo de sinal
    (curtir vale mais). Peça marcada com 'menos disso' depois não conta."""
    now = now or utcnow()
    since = now - timedelta(hours=RECENT_HOURS)
    rows = (
        VortexInteraction.query
        .filter(VortexInteraction.user_id == user_id, VortexInteraction.item_id.isnot(None),
                VortexInteraction.created_at >= since,
                VortexInteraction.kind.in_(("open", "like", "dwell", "less")))
        .order_by(VortexInteraction.id.desc()).limit(80).all()
    )
    disliked = {r.item_id for r in rows if r.kind == "less"}
    seeds, seen = [], set()
    for r in rows:
        if r.kind == "less" or r.item_id in seen or r.item_id in disliked:
            continue
        seen.add(r.item_id)
        pos_w = RECENT_SEED_DECAY[min(len(seeds), len(RECENT_SEED_DECAY) - 1)]
        age_h = max((now - r.created_at).total_seconds() / 3600.0, 0.0)
        w = pos_w * math.pow(0.5, age_h / RECENT_HALF_LIFE_HOURS)
        if r.kind == "like":
            w *= 1.4
        seeds.append((r.item_id, w))
        if len(seeds) >= limit:
            break
    return seeds


def _related_ids(app, item_id):
    """Ids das peças parecidas com `item_id` (ordem de relevância), em cache."""
    cached = _related_cache.get(item_id)
    if cached is not None:
        return cached
    item = VortexItem.query.get(item_id)
    ids = []
    if item is not None and item.is_active:
        try:
            result = vsearch.related_items(app, item, offset=0, limit=RECENT_RELATED)
            ids = [i.id for i in result["items"]]
        except Exception:   # sugestão nunca derruba a grade
            ids = []
    _related_cache.set(item_id, ids)
    return ids


def recent_boost(app, user_id, now=None):
    """{'c<id>': bônus 0..1} das peças parecidas com o que a pessoa viu há
    pouco. A própria peça aberta fica de fora (a grade já a rebaixa)."""
    boost = {}
    seeds = recent_seed_ids(user_id, now)
    opened = {item_id for item_id, _w in seeds}
    for item_id, weight in seeds:
        ids = _related_ids(app, item_id)
        n = max(1, len(ids))
        for rank, other in enumerate(ids):
            if other in opened:
                continue
            gain = weight * math.pow(1.0 - rank / n, 0.8)
            key = f"c{other}"
            boost[key] = min(1.0, boost.get(key, 0.0) + gain)
    return boost


def recent_items(user_id, limit=20, media_type=None):
    """Peças do crawler que a pessoa abriu/curtiu há pouco (a mais recente
    primeiro, sem repetir), prontas pra uma faixa "Vistos recentemente"."""
    rows = (
        VortexInteraction.query
        .filter(VortexInteraction.user_id == user_id, VortexInteraction.item_id.isnot(None),
                VortexInteraction.kind.in_(("open", "like", "dwell")))
        .order_by(VortexInteraction.id.desc()).limit(300).all()
    )
    ids, seen = [], set()
    for r in rows:
        if r.item_id in seen:
            continue
        seen.add(r.item_id)
        ids.append(r.item_id)
        if len(ids) >= limit * 2:
            break
    items = vsearch.load_items(ids)
    if media_type:
        items = [i for i in items if i.media_type == media_type]
    return items[:limit]


# ===========================================================================
# limpeza da sequência final
# ===========================================================================

def _popcount(x):
    return bin(x).count("1")


def _clean_sequence(ranked, near_dup=FEED_NEAR_DUP_DISTANCE, window=FEED_PER_SITE_WINDOW,
                    per_site=FEED_PER_SITE_MAX):
    """Tira imagem quase igual a outra já escolhida (dHash) e espalha o mesmo
    site de origem (no máx. `per_site` em `window` posições; se não houver
    outra opção no topo da fila, cede). Não reordena além disso."""
    queue = list(ranked)
    out, hashes = [], []

    def is_dup(c):
        return c.phash is not None and any(_popcount(c.phash ^ h) <= near_dup for h in hashes)

    while queue:
        pick_i = None
        for i, c in enumerate(queue[:_CLEAN_LOOKAHEAD]):
            if is_dup(c):
                continue
            if c.site and sum(1 for k in out[-window:] if k.site == c.site) >= per_site:
                continue
            pick_i = i
            break
        if pick_i is None:   # só sobrou site repetido (ou nada): cede no site, nunca na cópia
            for i, c in enumerate(queue):
                if not is_dup(c):
                    pick_i = i
                    break
        if pick_i is None:   # o resto é tudo cópia de algo que já está na lista
            break
        c = queue.pop(pick_i)
        # as cópias que a escolha acabou de tornar redundantes saem da fila
        out.append(c)
        if c.phash is not None:
            hashes.append(c.phash)
            queue = [q for q in queue if not (q.phash is not None
                                              and _popcount(q.phash ^ c.phash) <= near_dup)]
    return out


def _cap_subject(ranked, window=SATURATION_WINDOW, limit=SATURATION_MAX):
    """Anti-vício: no máximo `limit` peças do mesmo DOMÍNIO (veículo, animal...) em
    `window` posições seguidas. Se só sobrou aquele assunto no topo da fila, cede.
    Peça sem conceito não conta (nunca é limitada)."""
    queue = list(ranked)
    out = []
    while queue:
        pick_i = None
        for i, c in enumerate(queue[:_CLEAN_LOOKAHEAD]):
            if c.domain and sum(1 for k in out[-(window - 1):] if k.domain == c.domain) >= limit:
                continue
            pick_i = i
            break
        out.append(queue.pop(pick_i if pick_i is not None else 0))
    return out


def _inject_recent(ranked, recent, slots=RECENT_SLOTS, minimum=RECENT_SLOT_MIN):
    """Põe as melhores parecidas com o que a pessoa viu há pouco nas posições
    reservadas do começo (se ainda não estiverem lá em cima)."""
    if not recent:
        return ranked
    best = sorted((c for c in ranked if recent.get(c.key, 0.0) >= minimum),
                  key=lambda c: recent[c.key], reverse=True)
    if not best:
        return ranked
    out = list(ranked)
    placed = set()
    for pos, c in zip(slots, best):
        if pos >= len(out):
            break
        if c.key in placed:
            continue
        current = out.index(c)
        if current <= pos:    # já está num lugar tão bom quanto o reservado
            placed.add(c.key)
            continue
        out.pop(current)
        out.insert(pos, c)
        placed.add(c.key)
    return out


RECYCLE_MIN_PAGES = 1       # com menos de 1 página de peças NOVAS, completa reciclando as vistas há mais tempo
RECYCLE_FILL_PAGES = 2      # ...até chegar a 2 páginas


def _recycle(ledger, category, media_type, include_items, include_users, need):
    """O acervo NOVO acabou pra esta pessoa: em vez de uma grade vazia, volta
    com as peças vistas há MAIS tempo (ordem: a mais antiga primeiro). Respeita
    filtros de tipo/categoria. Nunca traz 'menos disso'."""
    out = []
    if include_items:
        keys = [k for k in ledger.oldest_blocked("c", need * 3)
                if not ledger.rows[k].rejected]
        cands = _item_cands([int(k[1:]) for k in keys])
        if media_type:
            cands = [c for c in cands if c.media_type == media_type]
        if category:
            cands = [c for c in cands if c.category == category]
        order = {k: i for i, k in enumerate(keys)}
        cands.sort(key=lambda c: order.get(c.key, 0))
        out += cands
    if include_users and not category:
        keys = {k for k in ledger.oldest_blocked("p", need * 3) if not ledger.rows[k].rejected}
        out += [c for c in _user_post_cands(media_type) if c.key in keys]
    return out[:need]


def rank_keys(app, user_id, category=None, media_type=None, include_users=True,
              seed=0, include_items=True):
    """Lista ranqueada completa (até MAX_RANKED chaves 'c<id>'/'p<id>').

    Livro de vistos (vortex_seen): peça já servida/vista/rejeitada NÃO entra;
    imagem quase igual a uma que a pessoa viu também não; peça que acabou de
    sair do bloqueio entra com nota reduzida; se sobrar pouca coisa nova, a
    grade é completada reciclando as vistas há mais tempo."""
    now = utcnow()
    profile = build_profile(user_id, now)
    cfg = app.config if app is not None else {}
    ledger = vseen.load(user_id, now)
    blocked = ledger.blocked_keys()
    recent = recent_boost(app, user_id, now) if (include_items and not category) else {}
    cands = []
    if include_items:
        ids = _collect_item_ids(app, profile, category, media_type,
                                skip={int(k[1:]) for k in blocked if k[0] == "c"})
        ids.update(int(k[1:]) for k in recent if k not in blocked)
        cands = _item_cands(ids)
        if media_type:   # parecidas de outro tipo não entram quando há filtro de tipo
            cands = [c for c in cands if c.media_type == media_type]
    if include_users and not category:
        cands += _user_post_cands(media_type)
    if blocked:
        cands = [c for c in cands if c.key not in blocked]
    near = vseen.seen_phash_index(ledger) if include_items else None
    if near is not None and near.size:
        cands = [c for c in cands if not (c.kind == "c" and near.near(c.phash))]
    soft = ledger.soft_factors()
    pop = _popularity(now)
    scored = sorted(
        ((c, score_cand(c, profile, now, seed, pop, recent) * soft.get(c.key, 1.0))
         for c in cands),
        key=lambda cs: cs[1], reverse=True)
    ranked = _assemble(scored, profile, now, seed, pop, recent)
    ranked = _inject_recent(ranked, recent)
    ranked = _clean_sequence(
        ranked,
        near_dup=cfg.get("VORTEX_FEED_NEAR_DUP_DISTANCE", FEED_NEAR_DUP_DISTANCE),
        window=cfg.get("VORTEX_FEED_PER_SITE_WINDOW", FEED_PER_SITE_WINDOW),
        per_site=cfg.get("VORTEX_FEED_PER_SITE_MAX", FEED_PER_SITE_MAX),
    )
    ranked = _cap_subject(ranked,
                          window=cfg.get("VORTEX_FEED_SATURATION_WINDOW", SATURATION_WINDOW),
                          limit=cfg.get("VORTEX_FEED_SATURATION_MAX", SATURATION_MAX))
    keys = [c.key for c in ranked]
    psize = vsearch.page_size(app) if app is not None else 30
    if len(keys) < psize * RECYCLE_MIN_PAGES and blocked:
        have = set(keys)
        extra = _recycle(ledger, category, media_type, include_items, include_users,
                         psize * RECYCLE_FILL_PAGES - len(keys))
        keys += [c.key for c in extra if c.key not in have]
    return keys, profile.stamp


# ===========================================================================
# aviso de tempo (pausa)
# ===========================================================================

def wellbeing(user_id, now=None, app=None):
    """Tempo CONTÍNUO de uso do Vortex e se vale sugerir uma pausa.

    Atividade = cliques (vortex_interactions) + peças confirmadas na tela (vortex_seen).
    Sessão contínua = sequência de atividades sem silêncio maior que
    SESSION_GAP_MINUTES até agora. Devolve {minutes, level, suggest_break, message};
    `level` sobe a cada BREAK_AFTER_MINUTES (o cliente só reexibe quando sobe).
    Desligar: VORTEX_BREAK_AFTER_MINUTES=0."""
    cfg = app.config if app is not None else {}
    after = cfg.get("VORTEX_BREAK_AFTER_MINUTES", BREAK_AFTER_MINUTES)
    out = {"minutes": 0, "level": 0, "suggest_break": False, "message": None}
    if not user_id or not after:
        return out
    now = now or utcnow()
    since = now - timedelta(hours=6)
    try:
        stamps = [r[0] for r in db.session.query(VortexInteraction.created_at).filter(
            VortexInteraction.user_id == user_id, VortexInteraction.created_at >= since).all()]
        from models import VortexSeen
        stamps += [r[0] for r in db.session.query(VortexSeen.last_viewed_at).filter(
            VortexSeen.user_id == user_id, VortexSeen.last_viewed_at.isnot(None),
            VortexSeen.last_viewed_at >= since).all()]
    except Exception:
        db.session.rollback()
        return out
    stamps = sorted(s for s in stamps if s and s <= now)
    if not stamps:
        return out
    gap = timedelta(minutes=SESSION_GAP_MINUTES)
    if now - stamps[-1] > gap:
        return out
    start = stamps[-1]
    for s in reversed(stamps[:-1]):
        if start - s > gap:
            break
        start = s
    minutes = int((now - start).total_seconds() // 60)
    out["minutes"] = minutes
    out["level"] = minutes // after
    if out["level"] >= 1:
        out["suggest_break"] = True
        out["message"] = (f"Você está no Vortex há {minutes} minutos seguidos. "
                          "Que tal uma pausa rápida?")
    return out


# ===========================================================================
# paginação
# ===========================================================================

def parse_cursor(raw):
    """'t<semente>-<deslocamento>' -> (semente, deslocamento) ou None."""
    m = _cursor_re.match((raw or "").strip())
    return (int(m.group(1)), int(m.group(2))) if m else None


def format_cursor(seed, offset):
    return f"t{seed}-{offset}"


def new_seed():
    return random.randint(1, 2_000_000_000)


def ranked_page(app, user_id, cursor=None, category=None, media_type=None,
                include_users=True, page_size=None, include_items=True):
    """Uma página da grade personalizada.

    `cursor`: None (nova rolagem) ou o `next_cursor` devolvido antes. Devolve
    dict {keys, has_next, next_cursor}. `keys` = ['c12', 'p7', ...]. Quem
    chama carrega os objetos (load_objects)."""
    page_size = page_size or vsearch.page_size(app)
    parsed = parse_cursor(cursor)
    seed, offset = parsed if parsed else (new_seed(), 0)

    skey = (user_id, seed, category or "", media_type or "",
            bool(include_users), bool(include_items))
    session = _sessions.get(skey)
    stamp = _stamp(user_id)
    if session is None:
        ids, stamp = rank_keys(app, user_id, category, media_type, include_users, seed,
                               include_items)
        session = {"ids": ids, "stamp": stamp}
    elif session["stamp"] != stamp and offset > 0:
        # sinal novo no meio da rolagem: reordena só o que ainda não foi mostrado
        fresh, stamp = rank_keys(app, user_id, category, media_type, include_users, seed,
                                 include_items)
        shown = session["ids"][:offset]
        shown_set = set(shown)
        session = {"ids": shown + [k for k in fresh if k not in shown_set], "stamp": stamp}
    _sessions.set(skey, session)

    ids = session["ids"]
    page = ids[offset:offset + page_size]
    has_next = offset + page_size < len(ids)
    # livro de vistos: o que sai nesta página não deve voltar nas próximas aberturas
    vseen.mark_served(user_id, page)
    return {
        "keys": page,
        "has_next": has_next,
        "next_cursor": format_cursor(seed, offset + page_size) if has_next else None,
    }


def load_objects(keys):
    """{'c12': VortexItem, 'p7': Post}. Peça que sumiu entre o ranqueamento e
    agora (apagada/expirada) simplesmente não aparece no dict."""
    item_ids = [int(k[1:]) for k in keys if k.startswith("c")]
    post_ids = [int(k[1:]) for k in keys if k.startswith("p")]
    out = {}
    if item_ids:
        for it in vsearch.load_items(item_ids):
            out[f"c{it.id}"] = it
    if post_ids:
        now = utcnow()
        for p in Post.query.filter(Post.id.in_(post_ids), Post.expires_at > now).all():
            out[f"p{p.id}"] = p
    return out


def clear_caches():
    """Zera os caches em memória (usado pelos testes)."""
    for c in (_profile_cache, _sessions, _popularity_cache, _postmeta_cache, _related_cache):
        c.clear()
