"""Dados dos widgets do painel direito (Parte 4 do layout): Em alta, Notícias, Vortex e
Quem está online. Só leitura: nenhuma função aqui grava no banco nem marca nada como "visto"."""
from datetime import timedelta

from flask import current_app, url_for

from extensions import db
from models import Comment, Like, Post, User, VortexItem, VortexSeen, utcnow

SNIPPET = 90
_KIND_LABEL = {"photo": "📷 Foto", "video": "🎬 Vídeo", "gif": "GIF", "audio": "🎧 Áudio"}


def _upload(name):
    return url_for("serve_upload", filename=name) if name else None


def _user_brief(u):
    return {"username": u.username, "display_name": u.display_label, "avatar_url": _upload(u.avatar_filename),
            "accent_color": u.accent_color or current_app.config["DEFAULT_ACCENT"]}


def trending_posts(viewer, limit=5):
    """Posts no ar (últimos 7 dias) mais comentados/curtidos. Pontos: curtida 2, comentário 3,
    +1 se for de hoje; empate vai para o mais novo. Sem banidos; posts sem reação ficam de fora."""
    now = utcnow()
    posts = (Post.query.join(User, User.id == Post.user_id)
             .filter(User.is_banned.is_(False), Post.expires_at > now, Post.created_at > now - timedelta(days=7))
             .order_by(Post.created_at.desc()).limit(200).all())
    if not posts:
        return []
    ids = [p.id for p in posts]
    likes = dict(db.session.query(Like.post_id, db.func.count(Like.id)).filter(Like.post_id.in_(ids))
                 .group_by(Like.post_id).all())
    comments = dict(db.session.query(Comment.post_id, db.func.count(Comment.id)).filter(Comment.post_id.in_(ids))
                    .group_by(Comment.post_id).all())
    rows = []
    for p in posts:
        l, c = likes.get(p.id, 0), comments.get(p.id, 0)
        if not (l or c):
            continue
        score = 2 * l + 3 * c + (1 if p.created_at > now - timedelta(days=1) else 0)
        rows.append((score, p.created_at, p, l, c))
    rows.sort(key=lambda t: (t[0], t[1]), reverse=True)
    out = []
    for _s, _t, p, l, c in rows[:limit]:
        text = " ".join((p.text_content or "").split())
        if len(text) > SNIPPET:
            text = text[:SNIPPET].rstrip() + "…"
        out.append({"id": p.id, "url": url_for("main.post_detail", post_id=p.id), "author": _user_brief(p.author),
                    "snippet": text or _KIND_LABEL.get(p.post_type, "Post"), "likes": l, "comments": c})
    return out


def news_headlines(viewer, limit=4):
    """Manchetes personalizadas (mesmo recomendador do feed de Notícias, já sem previsão de outras cidades)."""
    from news_recommender import recommended_articles
    articles, _more = recommended_articles(viewer, limit=limit)
    return [{"id": a.id, "title": a.title, "source": a.source.name if a.source else "",
             "url": url_for("news.open_article", article_id=a.id),
             "image_url": url_for("news.article_image", article_id=a.id, w=480) if a.image_url else None}
            for a in articles[:limit]]


def vortex_preview(viewer, limit=6):
    """As peças (fotos/GIFs) mais novas do Vortex, sem as que o usuário marcou "menos disso".
    Não registra nada no livro de vistos."""
    q = VortexItem.query.filter(VortexItem.is_active.is_(True), VortexItem.media_type.in_(("photo", "gif")),
                                VortexItem.thumb_url.isnot(None))
    rejected = [r[0] for r in db.session.query(VortexSeen.key)
                .filter(VortexSeen.user_id == viewer.id, VortexSeen.rejected.is_(True), VortexSeen.key.like("c%"))]
    rejected_ids = [int(k[1:]) for k in rejected if k[1:].isdigit()]
    if rejected_ids:
        q = q.filter(~VortexItem.id.in_(rejected_ids))
    items = q.order_by(VortexItem.created_at.desc(), VortexItem.id.desc()).limit(limit).all()
    return [{"id": i.id, "thumb_url": i.thumb_url, "title": i.title or "",
             "url": url_for("main.pictures")} for i in items]


def online_now(viewer, limit=8):
    """Quem usou o site nos últimos ONLINE_WINDOW_SECONDS. Respeita a privacidade do chat:
    quem escondeu "online" (show_presence) não aparece — e, como no chat, quem esconde o seu
    também não vê o dos outros."""
    if not viewer.show_presence:
        return {"hidden": True, "count": 0, "users": []}
    since = utcnow() - timedelta(seconds=current_app.config.get("ONLINE_WINDOW_SECONDS", 300))
    q = User.query.filter(User.is_banned.is_(False), User.show_presence.is_(True), User.id != viewer.id,
                          User.last_seen_at.isnot(None), User.last_seen_at > since)
    count = q.count()
    users = q.order_by(User.last_seen_at.desc()).limit(limit).all()
    return {"hidden": False, "count": count,
            "users": [{**_user_brief(u), "profile_url": url_for("main.profile", username=u.username)} for u in users]}
