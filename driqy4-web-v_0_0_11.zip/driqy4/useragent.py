"""
Extração simples de dispositivo / navegador / sistema operacional a partir
do cabeçalho User-Agent, sem depender de biblioteca externa (evita mais uma
dependência só pra isso). Não é perfeito, mas é o suficiente pra segmentar
as visitas no painel de analytics do admin (ex.: "quantos acessos vieram de
celular vs computador").
"""
import re


def parse_user_agent(ua):
    """Retorna (device, browser, os) a partir da string de User-Agent.
    device é sempre um de: "mobile", "tablet", "desktop"."""
    ua = ua or ""
    low = ua.lower()

    if "ipad" in low or ("android" in low and "mobile" not in low):
        device = "tablet"
    elif re.search(r"mobi|iphone|ipod", low):
        device = "mobile"
    else:
        device = "desktop"

    if "edg/" in low:
        browser = "Edge"
    elif "opr/" in low or "opera" in low:
        browser = "Opera"
    elif "crios" in low:
        browser = "Chrome (iOS)"
    elif "fxios" in low:
        browser = "Firefox (iOS)"
    elif "chrome" in low and "chromium" not in low:
        browser = "Chrome"
    elif "firefox" in low:
        browser = "Firefox"
    elif "safari" in low:
        browser = "Safari"
    else:
        browser = "Outro"

    if "windows" in low:
        os_name = "Windows"
    elif "android" in low:
        os_name = "Android"
    elif "iphone" in low or "ipad" in low or "ipod" in low:
        os_name = "iOS"
    elif "mac os" in low or "macintosh" in low:
        os_name = "macOS"
    elif "linux" in low:
        os_name = "Linux"
    else:
        os_name = "Outro"

    return device, browser, os_name
