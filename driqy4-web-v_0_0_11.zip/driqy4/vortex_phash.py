"""
Impressão visual (dHash de 64 bits) das imagens do Vortex.

Usada pelo crawler pra descartar quase-duplicatas e, na busca, pra achar
imagens parecidas ("mais como este"). Precisa do Pillow; sem ele as funções
devolvem None e o resto do Vortex continua funcionando (só sem esse sinal).

dHash: reduz a imagem pra 9x8 em tons de cinza e compara cada pixel com o
vizinho da direita (64 comparações = 64 bits). Imagens parecidas têm hashes
com poucos bits diferentes (distância de Hamming pequena).
"""
from io import BytesIO

try:  # Pillow é opcional
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None

# distância de Hamming até a qual duas imagens contam como "a mesma"
DUPLICATE_DISTANCE = 4
# até aqui contam como "parecidas" (usado nos similares, parte 3)
SIMILAR_DISTANCE = 12


def dhash_from_bytes(data):
    """Devolve o dHash em hex (16 caracteres) ou None se não der pra ler."""
    if Image is None or not data:
        return None
    try:
        img = Image.open(BytesIO(data))
        img.seek(0)  # GIF: primeiro quadro
        img = img.convert("L").resize((9, 8), Image.Resampling.LANCZOS)
        px = list(img.tobytes())
    except Exception:
        return None
    bits = 0
    for row in range(8):
        for col in range(8):
            left = px[row * 9 + col]
            right = px[row * 9 + col + 1]
            bits = (bits << 1) | (1 if left > right else 0)
    return f"{bits:016x}"


def image_size_from_bytes(data):
    """(largura, altura) da imagem em `data`, ou None."""
    if Image is None or not data:
        return None
    try:
        with Image.open(BytesIO(data)) as img:
            return img.size
    except Exception:
        return None


def hamming(a, b):
    """Bits diferentes entre dois hashes hex. 64 se algum for inválido."""
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except (TypeError, ValueError):
        return 64
